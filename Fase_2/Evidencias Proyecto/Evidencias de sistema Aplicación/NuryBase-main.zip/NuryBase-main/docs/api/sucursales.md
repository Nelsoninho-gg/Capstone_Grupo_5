# API de sucursales

Implementación para PostgREST, siguiendo el patrón de usuarios: listado y
edición sobre `public.sucursales`, y alta mediante el RPC `crear_sucursal`.
La pestaña Sucursales consume estos endpoints para listar, crear, editar y
activar o desactivar sucursales, con formularios y tarjetas responsivas.

## Instalación

En la base conectada a PostgREST, aplicar con una cuenta que pueda gestionar
el esquema y los permisos:

```powershell
psql --dbname $env:DATABASE_URL -v ON_ERROR_STOP=1 -f database/migrations/20260930_sucursales_api.sql
```

La migración requiere los roles existentes `nury_admin`, `nury_cajero`,
`nury_bodeguero` y `web_anon`. Se puede aplicar nuevamente sin duplicar
funciones ni disparadores. Conserva los registros y los permisos de lectura
existentes de cajero y bodeguero. Termina con `NOTIFY pgrst, 'reload schema'`.

El esquema base incorpora la función y las validaciones para instalaciones
nuevas. También se debe aplicar la migración después de configurar los roles
para otorgar los permisos de la API.

## Contrato

Todas las filas incluyen `id`, `nombre`, `direccion`, `telefono`, `activo`
y `creado_en`. Dirección y teléfono admiten `null`. La aplicación envía el JWT
de la sesión mediante su interceptor de autenticación.

| Operación | Método y ruta | Servicio Angular |
| --- | --- | --- |
| Listar activas e inactivas | `GET /sucursales` | `listar()` |
| Listar solo activas, por nombre | `GET /sucursales?activo=eq.true&order=nombre.asc` | `listarActivas()` |
| Crear | `POST /rpc/crear_sucursal` | `crear(datos)` |
| Editar por ID | `PATCH /sucursales?id=eq.4` | `actualizar(4, cambios)` |
| Activar o desactivar | `PATCH /sucursales?id=eq.4` con `activo` | `actualizarEstado(4, false)` |

El listado de administración pide:

```http
GET /sucursales?select=id,nombre,direccion,telefono,activo,creado_en&order=id.asc
```

Creación:

```http
POST /rpc/crear_sucursal
Content-Type: application/json

{
  "p_nombre": "Nury Providencia",
  "p_direccion": "Av. Providencia 123",
  "p_telefono": "+56 9 1234 5678",
  "p_activo": true
}
```

El RPC también permite omitir dirección, teléfono y estado: sus valores por
defecto son `null`, `null` y `true`. Devuelve un arreglo con la sucursal creada;
el servicio Angular extrae esa fila.

Edición parcial:

```http
PATCH /sucursales?id=eq.4&select=id,nombre,direccion,telefono,activo,creado_en
Content-Type: application/json
Prefer: return=representation

{
  "direccion": "Av. Providencia 456",
  "telefono": null,
  "activo": false
}
```

La edición devuelve un arreglo con la fila actualizada. Si el ID no existe,
PostgREST devuelve un arreglo vacío; el servicio lo convierte en un error
para que el formulario no anuncie un guardado inexistente.

## Validaciones y permisos

- Nombre obligatorio, único según la restricción existente y de hasta
  120 caracteres. Se rechazan nombres vacíos o compuestos solo por espacios.
- Dirección de hasta 200 caracteres y teléfono de hasta 30 caracteres.
- El alta y la edición recortan espacios exteriores. Dirección y teléfono
  vacíos se guardan como `null`.
- Estado booleano obligatorio. Se pueden crear y editar sucursales inactivas.
- Solo `nury_admin` recibe permisos de creación y edición sobre nombre,
  dirección, teléfono y estado. El ID y la fecha de creación no son editables.
- El RPC se ejecuta con los permisos del solicitante (`SECURITY INVOKER`).
  Los demás roles no pueden ejecutarlo ni insertar o actualizar sucursales.

Los errores de datos conservan sus códigos SQL: `23505` para nombres
duplicados, `23514` para nombres vacíos, `23502` para campos obligatorios
nulos y `22001` para valores demasiado largos. Los permisos usan `42501`.
El servicio propaga los errores HTTP de PostgREST para que la interfaz los
pueda presentar.

## Verificación local

- Pruebas HTTP de Angular: listado completo, listado activo, contrato RPC,
  edición parcial, estado, respuestas vacías y error por nombre duplicado.
- Integración SQL en una base PostgreSQL temporal: creación, edición,
  normalización, duplicados, campos obligatorios, longitudes, permisos y
  protección del ID y de la fecha de creación.
- La prueba SQL está en `database/tests/sucursales_api.sql` y revierte las
  filas de prueba con `ROLLBACK`.

El usuario confirmó la aplicación de la migración en la base de datos.
La interfaz se verifica localmente con respuestas simuladas; esas pruebas
no acreditan una ejecución de los endpoints sobre `api.nury.cl`.
