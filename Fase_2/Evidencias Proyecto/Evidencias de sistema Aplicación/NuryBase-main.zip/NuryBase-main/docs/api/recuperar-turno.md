# Recuperación de turnos — 12 de octubre de 2026

El mensaje «Ya existe un turno activo» aparecía junto a «Aún no inicias tu turno»
porque el navegador solo recuperaba el turno desde `sessionStorage`. Cerrar la
pestaña, perder el almacenamiento o iniciar otra sesión podía perder esa copia
sin cerrar el turno real de PostgreSQL. Además, la copia local podía conservar
un turno que se había cerrado desde otra pestaña.

Caja y POS consultan ahora `POST /rpc/fn_recuperar_turno` al entrar. La función
usa la identidad validada del JWT y devuelve el turno abierto de ese usuario en
su sucursal junto con todas sus ventas y detalles. Incluye ventas anuladas para
restaurar su historial, pero estas no suman a la cuadratura. Los precios de los
ítems se recuperan del detalle vendido, aunque el precio actual del producto haya
cambiado. Los datos adicionales del comprobante solo conservados en el navegador,
como autorizaciones y vuelto, se mantienen cuando todavía existe la caché.

Mientras se comprueba el turno se bloquean las operaciones. Un fallo de red no se
interpreta como caja cerrada: se muestra un error con un botón Reintentar.
La confirmación de que ya no existe un turno abierto descarta la copia local.
Al cambiar de usuario o sucursal se limpia el estado compartido, y las respuestas
tardías de la sesión anterior o anteriores a un cierre no pueden reabrir el turno.

Si otra pestaña abrió el turno entre la consulta y el botón Iniciar Turno, se
recupera el turno existente al recibir el rechazo por duplicado. Se conserva el
monto inicial original. Caja muestra la fecha de apertura y permite Continuar
vendiendo o Cerrar turno mediante el flujo de cuadratura existente.

## Instalación

Aplicar `database/migrations/20261012_recuperar_turno.sql` con el propietario de
las tablas antes de publicar el frontend. Requiere las migraciones
`0003_apertura_control_turno.sql` y `20261012_permisos_cajero.sql`, incluidos los
roles y la identidad JWT descritos en `docs/api/permisos-cajero.md`.

La migración agrega una función de consulta y sus permisos. No altera, abre,
cierra ni elimina turnos o ventas existentes. No se cierran automáticamente los
turnos antiguos: el cajero revisa la fecha y realiza el cierre correspondiente.

## Verificación

`database/tests/recuperar_turno.sql` se ejecuta en una base de pruebas limpia con
el esquema y las migraciones aplicados. Comprueba turnos antiguos aún abiertos,
ventas vigentes y anuladas, precios históricos, turnos cerrados, sucursales,
identidad y permisos. Sus datos se revierten con ROLLBACK.

Verificado en PostgreSQL local con la migración aplicada dos veces. También se
verificaron la recuperación sin caché, fallos de red y reintentos, cambio de usuario,
respuestas tardías y el rechazo de una apertura duplicada en las pruebas de Angular.

Compilación de producción aprobada; 337 pruebas de Angular aprobadas y 18 pruebas
de recuperación y menú aprobadas tras los últimos ajustes. En navegador local,
con la API simulada, se verificaron recuperación sin caché, historial, error y
reintento, apertura duplicada y vistas de 1440 y 390 px sin desbordamiento horizontal.
No se aplicó la migración a la base del servidor.
