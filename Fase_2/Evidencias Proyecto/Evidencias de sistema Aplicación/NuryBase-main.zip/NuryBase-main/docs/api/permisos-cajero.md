# Permisos de cajero — 12 de octubre de 2026

El cajero ve «Anulación de ventas» en el menú principal y puede consultar y
anular sus propias ventas, incluidas las de turnos anteriores. El administrador
conserva el historial de su sucursal y puede anular ventas de otros cajeros o sin
cajero. La opción ya no pertenece al submenú Administración.

En «Maestro de productos», el cajero puede consultar, crear y editar nombre,
categoría, precio de compra, precio de venta y código de barras. Los productos
nuevos quedan activos. El cambio de estado, la eliminación y la gestión de
recetas siguen disponibles para el administrador.

## Aplicación en la base de datos

Aplicar `database/migrations/20261012_permisos_cajero.sql` con el propietario
de las tablas **antes de publicar el frontend**. Requiere los roles JWT
`nury_admin`, `nury_cajero`, `nury_bodeguero` y `web_anon` del sistema de login.
La migración es transaccional y se puede ejecutar nuevamente. Agrega
`precio_compra` si el esquema inicial todavía no tiene el campo utilizado por
el Maestro; los valores existentes se conservan.

El JWT validado por PostgREST debe contener `role` y el ID numérico del usuario
en `user_id`, `usuario_id`, `sub` o `id`. El ID se contrasta con un usuario activo
de `public.usuarios` y su rol registrado. Una sesión sin esa identidad o con
un rol incompatible no puede leer ventas propias ni anularlas. El código de
`public.login` no está incluido en este checkout; comprobar este contrato en
los tokens del entorno al instalar la migración y renovar la sesión si fue
necesario actualizar el login.

`POST /rpc/fn_anular_venta` recibe solamente:

```json
{ "p_venta_id": 123, "p_motivo": "Error al cobrar" }
```

El servidor comprueba la propiedad de la venta, bloquea la fila durante la
operación, exige un motivo de 5 a 250 caracteres y registra el actor desde el
JWT y la fecha en UTC. No permite repetir la anulación. El cajero no tiene
permisos para modificar directamente `ventas` o `detalle_venta`.

La lectura por PostgREST usa políticas de filas sobre ventas y detalles. Los
permisos por columna permiten editar los datos del producto, pero bloquean
`activo`, `id`, `creado_en` y DELETE, aunque se envíe una petición directa.

## Verificación

Ejecutar `database/tests/permisos_cajero.sql` en una base de pruebas con el
esquema, roles y migración aplicados. La prueba crea sus propias filas y termina
con ROLLBACK. Cubre anulación propia, ventas ajenas en la misma y otra sucursal,
ventas sin cajero, auditoría, motivos inválidos, repetición, lectura del detalle,
sesiones inválidas, alta y edición de productos, bloqueo de estado y eliminación,
y conservación de las operaciones del administrador.

Validado en una instancia temporal local de PostgreSQL 18: migración aplicada
dos veces y prueba SQL aprobada. Angular: 29 suites y 326 pruebas aprobadas;
compilación de producción aprobada. No se aplicó SQL al entorno de producción.
