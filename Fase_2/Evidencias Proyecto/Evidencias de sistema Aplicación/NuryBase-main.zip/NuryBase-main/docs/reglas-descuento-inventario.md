# Reglas de descuento de inventario al vender

Definidas en H2.5 T01. Las aplica la base de datos al confirmar la venta, sin pasos manuales:
`fn_registrar_venta_idempotente` → `fn_registrar_venta` → trigger `fn_aplicar_venta` en cada
línea de `detalle_venta`, todo en una sola transacción.

## 1. Consumo por receta

Para un producto **con receta**, cada insumo descuenta:

```
consumo = recetas.cantidad_necesaria × detalle_venta.cantidad
```

- Si varios productos de la misma venta comparten un ingrediente, cada línea descuenta lo
  suyo y el total es la suma. Ejemplo: pan con 0,300 kg de harina y empanada con 0,100 kg;
  vender 2 panes y 3 empanadas descuenta 2 × 0,300 + 3 × 0,100 = **0,900 kg** de harina.
- Cada descuento deja una fila `venta` en el kardex (`movimientos_stock`) con la cantidad
  negativa, el stock resultante, la sucursal y el número de venta (ver `v_movimientos_articulos`).

## 2. Unidad de medida

- La cantidad de la receta está siempre en la **unidad base del ingrediente**
  (`ingredientes.unidad_id`), que queda fija desde que se crea (H3.3).
- No hay conversión de unidades al vender: si el queso se mide en gramos, la receta dice
  cuántos gramos lleva.
- La base lo asegura con `trg_recetas_unidad_base` (migración `20261027_receta_unidad_base.sql`):
  si `recetas.unidad_id` viene vacía la completa con la del ingrediente, y si viene distinta la
  rechaza.

## 3. Productos sin receta (H3.2)

- Un producto **sin receta** (reventa, por ejemplo una Coca-Cola) descuenta su propio stock
  por sucursal en `stock_producto_sucursal`, en unidades: vender 2 descuenta 2.
- Si todavía no tenía fila de stock en esa sucursal, se crea en 0 y queda en negativo.

## 4. Saldo negativo permitido

- La venta **nunca se bloquea** por falta de stock: el saldo puede quedar negativo.
- El POS avisa qué quedó con stock insuficiente (H2.5 T04, `fn_stock_insuficiente_venta`) e
  Inventario lo muestra como descuadre, para cargar la compra o ajustar.

## 5. Reintentos y anulación

- Cada venta lleva una clave única (H2.5 T05): un reintento con la misma clave devuelve la
  venta ya registrada y no vuelve a descontar.
- Anular una venta repone exactamente lo que descontó, leyendo el kardex (H3.2 T08, migración 0007).

## Pruebas

- `database/tests/reglas_consumo_receta.sql`: las cuatro reglas.
- `database/tests/stock_insuficiente_venta.sql`: stock insuficiente y aviso al POS.
- `database/tests/venta_idempotente.sql`: reintentos, fallos y tiempo (≤ 2 s).
- `database/tests/reponer_stock_anulacion.sql`: anulación.
