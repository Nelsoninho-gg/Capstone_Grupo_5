# Registro y Bitácora de Pruebas Unitarias — NuryBase

Este documento mantiene el inventario y resultado real de las pruebas ejecutadas. Debe actualizarse cada vez que una IA o participante cree o ejecute pruebas.

## Resumen de última ejecución

- **Fecha:** 23 de octubre de 2026
- **Rama:** `Patricio2_branch` (con `origin/develop` integrado hasta `eac4d6b`)
- **Entorno:** Angular 22.1 / Vitest 4.1.11 / Node 24
- **Suites:** 44 aprobadas de 44 (+1 suite: app-icon.component.spec.ts)
- **Pruebas:** 642 aprobadas de 642 (+7 pruebas)
- **Duración:** 24.97 segundos
- **Resultado:** PASS, 0 fallos y 0 omitidas
- **Comando:** `ng test --watch=false`
- **Build:** `npm run build` aprobado, 0 errores y 0 advertencias
- **Base de datos:** Migraciones de permisos, no negatividad y zona horaria aplicadas y verificadas en PostgreSQL / VPS.

## Reemplazo de emojis por iconos vectoriales Lucide (Option 1) — 23-10-2026

- **Componente SVG Standalone (`AppIconComponent`):** Creado en `src/app/shared/components/app-icon/app-icon.component.ts` con selector `<app-icon [name]="name" [size]="size" />`. Contiene los paths vectoriales limpios y oficiales de Lucide (`banknote`, `credit-card`, `ticket`, `key-round`, `check-circle` / `circle-check`) con `stroke="currentColor"`.
- **Integración en Apertura y Cierre de Caja (`features/caja`):**
  - En `caja.model.ts`: `PAYMENT_METHOD_META` actualizado con identificadores vectoriales (`'banknote'`, `'credit-card'`, `'ticket'`).
  - En `cierre-caja.component.ts`: Importado `AppIconComponent` en sus `imports`.
  - En `cierre-caja.component.html`: reemplazados emojis de inicio (`key-round`), turno cerrado (`check-circle`), desgloses y boletas con `<app-icon>`.
  - En `cierre-caja.component.css`: alineación vertical con `inline-flex`/`flex`, `align-items: center`, `gap: 8px`, herencia de color `#3d5334`.
- **Integración en Modal de Pago POS (`features/pos`):**
  - En `payment-modal.component.ts`: Importado `AppIconComponent`.
  - En `payment-modal.component.html`: botones de medio de pago con íconos vectoriales (`banknote` para Efectivo, `credit-card` para Débito/Crédito, `ticket` para Pluxee/Edenred).
  - En `payment-modal.component.css`: `.method-icon` centrado en 24×24 con color adaptable (#5c7149 inactivo, #384c2d activo).
- **Pruebas y Build:**
  - Nueva suite `app-icon.component.spec.ts` (7 pruebas unitarias).
  - 44/44 suites y 642/642 pruebas unitarias aprobadas (100% PASS).
  - `npm run build` aprobado con 0 errores y 0 advertencias.

## Cierre de correcciones de base de datos — 22-10-2026

- **Historial de ajustes bodeguero (Pedido 11):** Aplicada la migración `database/migrations/20261021_historial_ajustes_bodeguero.sql` en producción/VPS. Concede `SELECT` en `movimientos_stock` y en `usuarios (id, nombre)`. Resuelve el error 403 en Inventario > "Mermas y ajustes".
- **Stock mínimo bodeguero y no negatividad (Pedidos 4 y 6):** Nueva migración `database/migrations/20261022_stock_minimo_bodeguero.sql` y prueba `database/tests/stock_minimo_bodeguero.sql`. Restricción `CHECK (stock_minimo >= 0)` en `stock_sucursal` y `stock_producto_sucursal`, y `GRANT UPDATE (stock_minimo)` para `nury_bodeguero`. Aplicada en VPS.
- **Zona horaria en movimientos (Pedido 10):** Nueva migración `database/migrations/20261022_movimientos_timestamptz.sql` y prueba `database/tests/movimientos_timestamptz.sql`. Convierte `movimientos_stock.creado_en` a `TIMESTAMPTZ` con `DEFAULT now()`. Aplicada en VPS.
- **Validación Angular:** Suite completa ejecutada con **43/43 suites y 635/635 pruebas aprobadas (100% PASS)** sin regresiones.


## Ajustes visuales pedidos por Patricio — 21-10-2026

- Cambios: "Nury's" con mayúscula (menú, cabecera del POS y login); medios de pago en dos filas parejas; aviso de efectivo pendiente en tamaño de texto; Sodexo se muestra como Pluxee (la clave interna sigue siendo `sodexo`); anulación de ventas responsiva (tarjetas cuando la tabla no cabe, sin scroll lateral de 375 a 1440 px).
- Historial de ajustes del bodeguero: la API respondía 403 en `movimientos_stock` y `usuarios`. Nueva migración `database/migrations/20261021_historial_ajustes_bodeguero.sql` y su prueba `database/tests/historial_ajustes_bodeguero.sql`, **pendientes de aplicar en el VPS**.
- Sin casos nuevos de Vitest (solo textos y estilos); las expectativas existentes siguen pasando: **43/43 suites y 635/635 pruebas**.
- Se reemplazaron los marcadores de conflicto (`<<<<<<<`/`>>>>>>>`) que venían commiteados en el resumen desde `39ee64c`.
- Verificado en el navegador con sesión real (sucursal de desarrollo): bodeguero en Mermas y ajustes (403 confirmado), admin en POS, modal de pago y anulación en 375, 900 y 1280 px. No se cobró ni se anuló nada.

## Retiro de la pantalla de facturas — 15-10-2026

- Eliminados el componente, plantilla, estilos y datos de ejemplo de la pantalla, junto con su ruta, entrada del menú, ícono exclusivo y referencia en los destinos del login.
- Actualizadas las expectativas existentes del sidebar para administrador y bodeguero; sin casos nuevos.
- Verificado que el código fuente y el build de producción ya no contienen referencias a la pantalla eliminada.
- Primera ejecución mediante `npm test`: npm no propagó los argumentos del runner y se interrumpió sin resultado. La ejecución directa de Angular CLI indicada arriba finalizó con **35/35 suites y 425/425 pruebas aprobadas**.

> El registro del 19-09 indicaba 69 pruebas en esta rama. La implementación anterior de anulación sigue pendiente de reconstrucción y verificación.

## Inventario por suite — 20-10-2026

| Archivo | Pruebas | Estado |
| --- | ---: | --- |
| `src/app/app.routes.spec.ts` | 2 | PASS |
| `src/app/app.spec.ts` | 3 | PASS |
| `src/app/core/api/ingredientes-api.service.spec.ts` | 5 | PASS |
| `src/app/core/api/productos-api.service.spec.ts` | 5 | PASS |
| `src/app/core/api/recetas-api.service.spec.ts` | 4 | PASS |
| `src/app/core/api/stock-api.service.spec.ts` | 10 | PASS |
| `src/app/core/api/recetas-api.service.spec.ts` | 5 | PASS |
| `src/app/core/api/stock-api.service.spec.ts` | 8 | PASS |
| `src/app/core/api/sucursales-api.service.spec.ts` | 8 | PASS |
| `src/app/core/api/turnos-api.service.spec.ts` | 1 | PASS |
| `src/app/core/api/ventas-api.service.spec.ts` | 10 | PASS |
| `src/app/core/guards/auth.guard.spec.ts` | 19 | PASS |
| `src/app/core/services/app-loader.service.spec.ts` | 5 | PASS |
| `src/app/core/services/barcode-scanner.spec.ts` | 5 | PASS |
| `src/app/core/services/conexion.service.spec.ts` | 3 | PASS |
| `src/app/features/anulacion-venta/pages/anulacion-venta/anulacion-venta.spec.ts` | 14 | PASS |
| `src/app/features/auth/pages/login/login.component.spec.ts` | 12 | PASS |
| `src/app/features/auth/services/auth.service.spec.ts` | 7 | PASS |
| `src/app/features/caja/pages/cierre-caja/cierre-caja.component.spec.ts` | 21 | PASS |
| `src/app/features/caja/services/caja.service.spec.ts` | 11 | PASS |
| `src/app/features/gestion-negocio/pages/gestion-negocio/gestion-negocio.spec.ts` | 5 | PASS |
| `src/app/features/gestion-negocio/pages/sucursales/sucursales.spec.ts` | 9 | PASS |
| `src/app/features/inventario/components/ajuste-inventario/ajuste-inventario.spec.ts` | 19 | PASS |
| `src/app/features/inventario/components/reporte-mermas/reporte-mermas.spec.ts` | 18 | PASS |
| `src/app/features/inventario/models/fallo-ajuste.spec.ts` | 18 | PASS |
| `src/app/features/inventario/models/fallo-minimo.spec.ts` | 11 | PASS |
| `src/app/features/inventario/models/inventario.model.spec.ts` | 24 | PASS |
| `src/app/features/inventario/pages/inventario/inventario.spec.ts` | 74 | PASS |
| `src/app/features/inventario/services/inventario.service.spec.ts` | 22 | PASS |
| `src/app/features/pos/components/payment-modal/payment-modal.component.spec.ts` | 19 | PASS |
| `src/app/features/inventario/components/ajuste-inventario/ajuste-inventario.spec.ts` | 20 | PASS |
| `src/app/features/inventario/components/reporte-mermas/reporte-mermas.spec.ts` | 13 | PASS |
| `src/app/features/inventario/models/fallo-ajuste.spec.ts` | 18 | PASS |
| `src/app/features/inventario/models/fallo-minimo.spec.ts` | 9 | PASS |
| `src/app/features/inventario/models/inventario.model.spec.ts` | 21 | PASS |
| `src/app/features/inventario/pages/inventario/inventario.spec.ts` | 66 | PASS |
| `src/app/features/inventario/services/inventario.service.spec.ts` | 18 | PASS |
| `src/app/features/pos/components/payment-modal/payment-modal.component.spec.ts` | 21 | PASS |
| `src/app/features/pos/models/pos-icons.spec.ts` | 4 | PASS |
| `src/app/features/pos/pages/pos-layout/pos-layout.component.spec.ts` | 22 | PASS |
| `src/app/features/pos/services/pos.service.spec.ts` | 30 | PASS |
| `src/app/features/pos/services/recuperar-turno.spec.ts` | 8 | PASS |
| `src/app/features/products/components/receta-producto-modal/receta-producto-modal.spec.ts` | 6 | PASS |
| `src/app/features/products/pages/product-master/product-master.spec.ts` | 25 | PASS |
| `src/app/layout/sidebar/sidebar.spec.ts` | 10 | PASS |
| `src/app/shared/components/app-icon/app-icon.component.spec.ts` | 7 | PASS |
| `src/app/shared/components/coffee-loader/coffee-loader.spec.ts` | 7 | PASS |

## Recetas: versiones, conexión con el descuento y prueba integral (H5.3 T06, T07 y T08) — ejecución del 27-10-2026

- **H5.3 T06** (conservar la versión usada en ventas anteriores): ya se cumplía desde H2.5 T02 (`20261020_versiones_receta.sql`): cada cambio de receta crea una versión, `trg_detalle_venta_receta_version` guarda en cada línea de venta la versión vigente y `fn_aplicar_venta` descuenta los insumos de esa versión. Editar solo afecta a las ventas futuras; la anulación devuelve lo descontado en su momento (desde el kardex).
- **H5.3 T07** (conectar recetas con H2.5 y H3.2): ya se cumplía: la receta del Maestro es la que lee la venta; con insumos descuenta ingredientes (H2.5), sin receta o sin insumos descuenta el stock propio (H3.2).
- **H5.3 T08**: `database/tests/recetas_integral_h53.sql`: (1) creación; (2) validaciones: cantidad 0, otra unidad, duplicado e ingrediente inactivo rechazados; (3) venta con la receta original (pan −2, queso −30, bebida −2 de stock propio) que guarda su versión; (4) edición (queso 40, se agrega jamón) crea versión nueva; (5) la venta siguiente usa la versión nueva (queso −40, jamón −20); (6) la venta anterior conserva su versión, su kardex (30 de queso, sin jamón) y al anularla devuelve 30 de queso, no 40; `fn_versiones_receta` muestra las versiones; (7) productos normales: la bebida sin receta ni versiones; al quitar todos los insumos el sándwich pasa a stock propio sin cambiar ventas anteriores; (8) permisos de recetas por rol. Falla sin `20261020_versiones_receta.sql` y pasa con ella; siguen pasando `validaciones_receta.sql` y `permisos_recetas.sql`. Front ya cubierto: `receta-producto-modal.spec.ts` (69 en products) y `recetas-api.service.spec.ts`.

## Panel y alertas al día sin recargar (H3.2 T06) — ejecución del 27-10-2026

- Revisión: el panel de Inventario (H3.4) y sus alertas de mínimo (H3.5) solo volvían a consultar al abrir, al reconectar y tras una acción propia; una venta hecha en el POS no se veía hasta recargar. No había canal de tiempo real (H3.4 T06 descartada: sin WebSockets).
- Decisión (27-10): consulta liviana periódica con detección de cambios.
- `database/migrations/20261027_version_inventario.sql`: `fn_version_inventario()` (STABLE, SECURITY DEFINER, para admin y bodeguero) devuelve `{stock, movimientos}`: huella md5 del stock actual y del mínimo de cada fila de `stock_sucursal` y `stock_producto_sucursal` (cambia con ventas, anulaciones, compras, ajustes, mermas y también al editar un mínimo, que no deja movimiento) y el id del último movimiento del kardex. 0,04 ms por consulta en la base de prueba.
- Inventario: mientras la pestaña está visible, cada 2 s (`INTERVALO_REVISION_MS`) pide la versión; si cambió el stock recarga las existencias sin ocultar los datos (estados, alertas y contadores se recalculan solos) y si hay movimientos nuevos refresca el reporte de mermas. Pestaña oculta: no consulta; al volver, revisa de inmediato. Si una consulta falla, mantiene los datos y sigue revisando. `StockApiService.versionInventario()` e `InventarioService.versionInventario()`.
- Pruebas: `database/tests/version_inventario.sql` (no cambia sin cambios; cambia con una venta de compuesto, una de reventa y un cambio de mínimo; liviana; permisos), falla sin la migración y pasa con ella. `inventario.spec.ts` +4 con tiempo simulado (revisa cada 2 s y recarga solo si cambió, un mínimo también recarga, pausa con la pestaña oculta, un fallo no borra los datos) y `stock-api.service.spec.ts` +1. `features/inventario` y `core/api`: 18/18 archivos y 260/260 pruebas. `ngc` sin errores.

## Prueba integral del descuento por ventas (H3.2 T07) — ejecución del 27-10-2026

- `database/tests/descuento_integral_h32.sql`, en una transacción con dos sucursales, pan y queso compartidos por sándwich y tostada, y una bebida de reventa: (1) producto normal: 2 bebidas descuentan 2 de su stock, sin ingredientes; (2) compuesto: 3 sándwiches descuentan 6 de pan y 90 de queso, sin stock propio; (3) venta mixta con ingredientes compartidos (pan −8, queso −120, bebida −1, 5 movimientos); (4) sucursales: la B queda intacta y no se vende donde no hay turno; (5) reintento con la misma clave: misma venta, sin descuento nuevo; (6) fallo a mitad de venta: se conservan todos los valores anteriores (ventas, movimientos, stock y clave) y la misma clave sirve para reintentar corregida; (7) anulación: repone exactamente lo descontado, una sola vez; (8) el kardex cuadra con el stock.
- Falla sin `20261026_venta_idempotente.sql` y pasa con todas las migraciones de H2.5 y H3.2.
- Se complementa con: `venta_concurrente.py` (concurrencia real: 320/320 ventas simultáneas sin errores), `detalle_venta_una_vez.sql` (no admite líneas nuevas en una venta ya registrada, con dos transacciones reales), `venta_concurrente.sql`, `venta_idempotente.sql`, `stock_insuficiente_venta.sql`, `reglas_consumo_receta.sql` y `reponer_stock_anulacion.sql`.

## Ventas simultáneas y sucursal de la venta (H3.2 T05) — ejecución del 27-10-2026

- Revisión: sin cantidades perdidas ya se cumplía (venta, compra, ajuste y anulación bloquean la fila de stock con `FOR UPDATE` antes de calcular el saldo) y el descuento usa `ventas.sucursal_id`, con turno abierto del cajero en esa sucursal.
- **Riesgo encontrado:** cada línea bloquea sus filas en el orden en que llegan; dos ventas con los mismos ingredientes en orden cruzado se esperaban una a la otra y PostgreSQL cortaba una con `deadlock detected`. Reproducido con `database/tests/venta_concurrente.py` (4 conexiones × 10 ventas): **17 de 40 ventas fallaron**, aunque las que entraron cuadraban.
- `database/migrations/20261027_venta_concurrente.sql`: `fn_registrar_venta_idempotente` llama antes de registrar a `fn_bloquear_stock_venta(sucursal, items)`, que crea en 0 las filas de stock que falten (como haría la venta) y bloquea todas las que tocará la venta en su sucursal, siempre en el mismo orden (ingredientes por id, luego productos sin receta por id). `fn_registrar_venta` no cambia. `fn_bloquear_stock_venta` no es ejecutable desde la API.
- Con la migración: **320 de 320 ventas simultáneas** (8 conexiones × 40) sin errores, stock exacto (harina 9360, bebida 9680) y la otra sucursal intacta; de 16 s a 0,4 s en el caso de 40 ventas.
- Prueba `database/tests/venta_concurrente.sql`: descuenta solo en la sucursal de la venta (pan y bebida de la sucursal B intactos, kardex con la sucursal correcta), no vende donde el cajero no tiene turno, el bloqueo previo solo crea filas en la sucursal de la venta y no es ejecutable por el cajero. Siguen pasando `venta_idempotente`, `detalle_venta_una_vez`, `stock_insuficiente_venta`, `reponer_stock_anulacion`, `reglas_consumo_receta`, `venta_empleado` (10/10, con datos de muestra), `movimientos_articulos`, `catalogo_integral_h33` y `validaciones_receta`.

## Consumos aplicados una sola vez por venta (H3.2 T03) — ejecución del 27-10-2026

- Revisión: los consumos por receta (H2.5) y el stock propio (H3.2) ya eran un único proceso: `fn_aplicar_venta` corre una vez por línea de `detalle_venta` dentro de la transacción de `fn_registrar_venta`. Los reintentos del POS no duplican (H2.5 T05).
- **Faltaba:** el trigger solo actúa al insertar. Verificado en producción (27-10): el admin tiene INSERT, UPDATE y DELETE sobre `detalle_venta` (cajero y bodeguero no), así que por la API se podía agregar una línea a una venta ya registrada o anulada (descontaba otra vez), cambiar producto o cantidad (el stock no se ajustaba) o borrar una línea (no se devolvía).
- `database/migrations/20261027_detalle_venta_una_vez.sql`: `trg_ventas_en_curso` (AFTER INSERT en `ventas`) marca la venta en una variable local de la transacción (`set_config(..., true)`); `trg_detalle_venta_una_vez` (BEFORE INSERT/UPDATE/DELETE en `detalle_venta`) solo acepta líneas mientras la venta está en curso y no anulada, rechaza cambiar `venta_id`, `producto_id` o `cantidad`, y rechaza borrar líneas salvo al borrar la venta completa (CASCADE). Primero se probó comparar `creado_en` con `now()`, pero falla si dos transacciones van en un mismo envío (comparten la hora de inicio); la marca de transacción no depende de eso. El front no inserta, modifica ni borra líneas de venta.
- Prueba `database/tests/detalle_venta_una_vez.sql` con dos transacciones reales: venta mixta (sándwich con receta + bebida) que descuenta una vez cada consumo; luego agregar, cambiar cantidad o producto y borrar una línea se rechazan y el stock no cambia; la anulación repone todo y a la venta anulada no se le agregan líneas; limpieza final borrando la venta completa. Falla sin la migración y pasa con ella. Siguen pasando `venta_idempotente`, `stock_insuficiente_venta`, `reponer_stock_anulacion`, `reglas_consumo_receta`, `venta_empleado`, `movimientos_articulos`, `receta_ingrediente_activo` y `validaciones_receta`.

## Prueba integral del catálogo (H3.3 T08) — ejecución del 27-10-2026

- `database/tests/catalogo_integral_h33.sql`, en una sola transacción: (1) ambos tipos en `v_articulos` con su unidad (materia prima en su unidad, producto en "un") y el producto con receta fuera de bodega; (2) duplicados de nombre y de código de barras ignorando mayúsculas y espacios; (3) unidad obligatoria y fija; (4) desactivar materia prima y producto: siguen en el catálogo como inactivos, conservan receta, stock y movimientos (`v_movimientos_articulos`), y no se pueden asociar a una receta nueva ni vender; (5) permisos: bodeguero lee el catálogo y los movimientos, crea y desactiva materias primas sin cambiar unidad ni borrar, no toca productos; cajero sin acceso.
- Falla sin `20261027_nombres_unicos_normalizados.sql` y pasa con todas las migraciones de H3.3. Pasan también, con la misma base, las pruebas de cada tarea: `modelo_articulos`, `unidad_fija_ingrediente`, `catalogo_materias_primas_bodeguero`, `nombres_unicos_normalizados`, `receta_ingrediente_activo` y `movimientos_articulos`.
- Front que cubre la historia: `ingredientes-maestro.spec.ts` (14), `catalogo.model.spec.ts`, `catalogo.service.spec.ts`, `product-master.spec.ts` (pestañas por rol, duplicados) y `movimientos-articulo.spec.ts`.

## Validaciones de la receta (H5.3 T05) — ejecución del 27-10-2026

- Revisión: cantidad positiva (`CHECK cantidad_necesaria > 0`), sin duplicados (`UNIQUE (producto_id, ingrediente_id)`), unidad base y compatible (`trg_recetas_unidad_base`, H2.5 T01) y materias primas activas (`trg_recetas_ingrediente_activo`, H3.3 T07) ya estaban en la base.
- Modal de receta: (1) al quitar el **último** insumo pide confirmar, porque el producto queda sin receta y se vende descontando su propio stock ("al menos un ingrediente"); (2) la cantidad acepta hasta 3 decimales (la columna es NUMERIC(12,3) y redondeaba sin avisar); (3) un 400 de la base muestra su mensaje (unidad, inactivo) en vez de "La cantidad debe ser mayor a 0" para todo.
- Pruebas: `database/tests/validaciones_receta.sql` (cantidad 0 y negativa, otra unidad, ingrediente inactivo, duplicado, venta con receta que descuenta el ingrediente y producto sin insumos que pasa a stock propio) y `receta-producto-modal.spec.ts` +4 (confirmar el último, quitar sin preguntar si quedan otros, cantidades válidas, mensaje de la base). `features/products`: 5/5 archivos y 69/69 pruebas.

## Campos obligatorios y duplicados ignorando mayúsculas y espacios (H3.3 T05) — ejecución del 27-10-2026

- Alcance acordado: **ingredientes y productos**, para el **nombre** y también el **código de barras** (pedido de Sebastián: cada producto suele tener código y no debe repetirse aunque cambien mayúsculas o espacios).
- `database/migrations/20261027_nombres_unicos_normalizados.sql`: `fn_nombre_normalizado` (minúsculas, sin espacios en los extremos ni repetidos) y `fn_codigo_normalizado` (mayúsculas, sin espacios), ambas IMMUTABLE; índices únicos `ux_{ingredientes,productos}_nombre_normalizado` y `ux_{ingredientes,productos}_codigo_normalizado` (parciales, solo con código); trigger `fn_limpiar_nombre_y_codigo` que guarda el nombre limpio y el código sin espacios (vacío → NULL) y rechaza un nombre vacío (22023); CHECK de nombre no vacío. El ensayo lista primero los duplicados que impedirían crear los índices.
- Bloqueo del cambio de unidad: ya se cumplía de forma más estricta (`trg_ingredientes_unidad_fija` lo rechaza siempre, 20261023).
- Front: `catalogo.model.ts` suma `limpiarNombre`, `claveNombre`, `claveCodigo` y `codigoRepetido` (las tildes sí cuentan: "Piña" ≠ "Pina", igual que la base). Pestaña Ingredientes y formulario de productos del Maestro avisan nombre o código repetido antes de guardar y envían el nombre limpio y el código sin espacios.
- Pruebas: `database/tests/nombres_unicos_normalizados.sql` (limpieza; nombre y código repetidos con otras mayúsculas o espacios rechazados en las dos tablas; nombre vacío rechazado; código vacío a NULL; editar el mismo artículo permitido; unidad fija). Falla sin la migración y pasa con ella; `modelo_articulos.sql` y `stock_insuficiente_venta.sql` siguen pasando. Front: `catalogo.model.spec.ts` +3, `ingredientes-maestro.spec.ts` +1, `product-master.spec.ts` +1. `features/products` e `inventario`: 15/15 archivos y 274/274 pruebas. `ngc` sin errores.

## Permisos y desactivación sin borrar (H3.3 T07) — ejecución del 27-10-2026

- Revisión: permisos (admin y bodeguero sobre ingredientes, con permisos por columna y sin DELETE; productos solo admin) y desactivación (`activo = false`, sin borrar recetas, movimientos ni stock) ya se cumplían. La venta (`fn_registrar_venta`) y el ingreso de facturas (`fn_ingresar_factura_xml`) ya rechazaban artículos inactivos.
- **Faltaba:** por la API se podía agregar un ingrediente inactivo a una receta (la pantalla solo ofrece activos). `database/migrations/20261027_receta_ingrediente_activo.sql`: trigger `trg_recetas_ingrediente_activo` (BEFORE INSERT o UPDATE OF ingrediente_id) que lo rechaza (22023). Las recetas que ya lo tienen se conservan: se puede editar la cantidad, vender y quitarlo.
- **Arreglo en el modal de receta:** solo cargaba ingredientes activos, así que un insumo que se desactivó después aparecía como "Insumo desconocido". Ahora carga todos (`listar(false)`), muestra el nombre con la etiqueta "Inactivo" y para agregar solo ofrece activos.
- Pruebas: `database/tests/receta_ingrediente_activo.sql` (desactivar conserva receta y stock; agregar o cambiar a inactivo rechazado; la receta anterior sigue descontando; reactivar permite volver a usarlo). Falla sin la migración y pasa con ella; `reglas_consumo_receta.sql` sigue pasando. `receta-producto-modal.spec.ts` +2. `features/products`: 5/5 archivos y 60/60 pruebas. `ngc` sin errores.

## Ingredientes al Maestro de Productos — ejecución del 27-10-2026

- `origin/develop` integrado hasta `e0622a1` (merge del PR #81). Merge sin conflictos.
- Pedido de Sebastián: las materias primas que estaban en Inventario → Catálogo pasan al **Maestro de Productos**, en dos pestañas: **Productos** e **Ingredientes**.
- Se movió el componente con `git mv` a `features/products/components/ingredientes-maestro` (antes `features/inventario/components/catalogo-articulos`), junto con `catalogo.model.ts` y `catalogo.service.ts` y sus pruebas. Ahora lista solo materias primas (`v_articulos?tipo=eq.materia_prima`): sin filtro ni columna de tipo, sin acciones de productos. Textos en "ingrediente". Conserva: búsqueda, crear/editar con unidad fija, nombre repetido, activar/desactivar sin borrar y Movimientos.
- **Inventario** queda con Existencias y Mermas y ajustes (se quitó la pestaña Catálogo; `?vista=catalogo` abre Existencias). Movimientos sigue en Existencias.
- **Maestro:** pestañas con `role="tablist"` y la pestaña en la URL (`?vista=ingredientes`). Roles: admin ve ambas y edita todo; **bodeguero** entra al Maestro (ruta y menú), ve los productos sin editarlos y administra Ingredientes; cajero sigue solo con Productos, sin pestañas. "Nuevo producto" solo en la pestaña Productos.
- `/inventario/ingredientes` redirige ahora a `/product-master?vista=ingredientes`.
- Celular: el componente define el contenedor `inventory` para usar las mismas reglas (tabla a tarjetas, controles de 44 px, diálogo desde abajo); las pestañas del Maestro ocupan el ancho con 44 px de alto bajo 640 px.
- Pruebas: `product-master.spec.ts` +3 (pestañas para admin, bodeguero sin edición de productos, cajero sin pestañas), `ingredientes-maestro.spec.ts` adaptada (13), `catalogo.service.spec.ts` adaptada, `inventario.spec.ts` (sin Catálogo), `sidebar.spec.ts` (bodeguero ve el Maestro) y `app.routes.spec.ts` (nueva redirección). `features/products`, `features/inventario`, `layout` y rutas: 17/17 archivos y 280/280 pruebas. `ngc` sin errores. Sin cambios en la base.

## Reglas de cálculo del consumo por receta (H2.5 T01) — ejecución del 27-10-2026

- `origin/develop` sin cambios desde `b92f3db`.
- Revisión de `fn_aplicar_venta` (0004): consumo = `cantidad_necesaria × cantidad vendida`, ingredientes compartidos sumados por línea, productos sin receta con stock propio (H3.2) y saldo negativo permitido ya se cumplían. **Faltaba asegurar la unidad base:** `recetas.unidad_id` es columna propia y la venta la ignora; por la API se podía guardar una receta en "g" para un ingrediente en "kg".
- `database/migrations/20261027_receta_unidad_base.sql`: trigger `trg_recetas_unidad_base` (BEFORE INSERT/UPDATE de `unidad_id` o `ingrediente_id`) que completa la unidad vacía con la del ingrediente y rechaza una distinta (22023). Verificado en producción antes: ninguna receta tenía otra unidad. No cambia la pantalla (ya envía la unidad del ingrediente).
- `docs/reglas-descuento-inventario.md`: las reglas escritas para el equipo, con ejemplo y las pruebas que las cubren.
- Prueba `database/tests/reglas_consumo_receta.sql`: unidad completada, unidad distinta rechazada al crear y al editar, editar la cantidad permitido; venta con pan y empanada que comparten harina (0,900 kg), queso en negativo (−20 g) y bebida sin receta (−1 un). Falla sin la migración y pasa con ella; `stock_insuficiente_venta.sql` y `reponer_stock_anulacion.sql` siguen pasando.

## Venta idempotente y pruebas del descuento al vender (H2.5 T05 y T07) — ejecución del 26-10-2026

- **Problema encontrado:** el POS no enviaba ningún identificador por venta. Si la base guardaba la venta pero la respuesta no llegaba (corte de red o los 15 s de espera), el carrito seguía lleno y al volver a cobrar quedaban dos ventas y el inventario descontado dos veces.
- **Base:** `database/migrations/20261026_venta_idempotente.sql`. Tabla `ventas_idempotencia` (clave UUID, venta, cajero; sin acceso para los roles de la app) y `fn_registrar_venta_idempotente(p_clave, …mismos parámetros…)`, SECURITY DEFINER, para admin y cajero. Bloquea la clave (`pg_advisory_xact_lock`), devuelve la venta original si la clave ya existe y, si no, llama a `fn_registrar_venta` sin cambios y guarda la clave en la misma transacción. Rechaza la clave de otro cajero y una clave vacía. **No modifica `fn_registrar_venta`.**
- **POS:** `VentasApiService.registrar` llama a la función nueva con `p_clave`. `PosService` genera un UUID por venta (`shared/utils/clave-unica.ts`) y lo reutiliza solo si se reintenta la misma venta (mismo carrito, medio de pago, cajero y sucursal); al confirmarse o al cambiar la venta, la clave es nueva. El descuento de inventario sigue siendo el de siempre: `fn_aplicar_venta` dentro de la misma transacción, sin pasos manuales.
- **H2.5 T07 — `database/tests/venta_idempotente.sql`:** (1) cantidades múltiples con pan y queso compartidos por sándwich y tostada, y stock insuficiente (queso −20, bebida −2); (2) reintento con la misma clave: misma venta, sin ventas ni movimientos nuevos; (3) venta con un producto inexistente: no deja venta, descuento ni clave, y la misma clave sirve para reintentar ya corregida; (4) clave de otro cajero rechazada; (5) sin clave, rechazada; (6) venta de 20 líneas con 40 movimientos: **10,5 ms** en el Postgres local (máximo 2 s); permisos. Falla sin la migración y pasa con ella. Los casos de `stock_insuficiente_venta.sql` siguen vigentes.
- Pruebas nuevas en `pos.service.spec.ts` (+3): UUID por venta y otro para la siguiente; reintento tras un fallo con la misma clave y el carrito intacto; venta cambiada antes de reintentar lleva clave nueva. `features/pos`, `core/api` y rutas: 14/14 archivos y 137/137 pruebas. `ngc` sin errores.
- **Orden de despliegue:** aplicar la migración en el VPS antes de publicar el front; el POS nuevo llama a `fn_registrar_venta_idempotente`.

## Relación entre ventas y movimientos (H3.2 T01) y permisos de recetas (H5.3 T03) — ejecución del 26-10-2026

- `origin/develop` sin cambios desde `b92f3db`.
- **H3.2 T01 — base:** `database/migrations/20261026_movimientos_articulos.sql`, vista `v_movimientos_articulos`: una fila por movimiento del kardex con tipo, venta (`venta_id`), artículo y tipo de artículo (de `v_articulos`, H3.3), cantidad, unidad, stock resultante, fecha y sucursal. Un producto que vendió como reventa y después recibió receta conserva sus movimientos antiguos (nombre desde `productos`, unidad "un"). SELECT para admin y bodeguero, no para cajero. Ensayo en producción revisado el 26-10 (ventas 34 a 68, con anulaciones y materias primas en g). Prueba `database/tests/movimientos_articulos.sql`.
- **H3.2 T01 — pantalla:** botón "Movimientos" en cada fila de Existencias (historial de esa sucursal) y del Catálogo (todas las sucursales). Diálogo `components/movimientos-articulo` con fecha y hora, tipo, origen ("Venta #67", "Anulación de la venta #49", "Factura #12", "Ajuste manual"), cantidad con signo y unidad, stock resultante y sucursal; filtros por tipo; los 100 más recientes. Celular: tarjetas, filtros de 44 px y la tercera acción de Existencias baja de línea si no cabe.
- **H5.3 T03:** `RecetasApiService` ya tenía consultar, agregar, editar (solo cantidad), quitar y versiones, con sus pruebas, y el botón Receta es solo para admin. Permisos verificados en producción el 26-10: admin con SELECT/INSERT/UPDATE/DELETE en `recetas`; cajero y bodeguero sin escritura (el bodeguero lee solo `producto_id`); las ventas del cajero pasan por `fn_registrar_venta` (SECURITY DEFINER). Queda fijado en `database/tests/permisos_recetas.sql`. Se corrigió un comentario fuera de lugar en `recetas-api.service.ts`.
- Pruebas nuevas: `movimientos.model.spec.ts` (3), `movimientos.service.spec.ts` (2), `movimientos-articulo.spec.ts` (5), `catalogo-articulos.spec.ts` +1, `inventario.spec.ts` +1. `features/inventario`: 13/13 archivos y 234/234 pruebas. `ngc` sin errores. Las dos pruebas SQL pasan en el Postgres local.

## Retiro de la pantalla antigua de Ingredientes (H3.3 T04) — ejecución del 25-10-2026

- `origin/develop` sin cambios desde `b92f3db`.
- `/inventario/ingredientes` ahora redirige a `/inventario?vista=catalogo`, así los enlaces guardados abren la pestaña Catálogo. La ruta ya no tiene guard propio: lo aplica `/inventario` (admin y bodeguero, igual que antes).
- Se elimina `src/app/features/ingredientes/` (`catalogo-ingredientes` y sus rutas). No tenía pruebas ni entrada en el menú; nadie más la importaba (`ngc` y `tsc` del spec sin errores).
- Inventario guarda la pestaña en la URL (`?vista=mermas` / `?vista=catalogo`; Existencias sin parámetro) con `replaceUrl`, para no llenar el historial. Al recargar se mantiene la pestaña; un valor desconocido abre Existencias (`vistaDesdeUrl`).
- `IngredientesApiService` se mantiene: lo usa el Catálogo.
- Pruebas nuevas: `app.routes.spec.ts` +1 (redirección con `RouterTestingHarness`) e `inventario.spec.ts` +3 (valores válidos de la URL, apertura directa del Catálogo y la URL al cambiar de pestaña). `features/inventario`, `core`, `layout` y rutas: 25/25 archivos y 316/316 pruebas. `ngc` sin errores.

## Catálogo de Inventario conectado a la base (H3.3 T03) — ejecución del 25-10-2026

- `origin/develop` integrado hasta `b92f3db` (merge del PR #80: iconos Lucide en caja y POS, stock mínimo para bodeguero y `creado_en` con zona horaria). Merge sin conflictos.
- `services/catalogo.service.ts` deja los datos de ejemplo y usa la base:
  - Listado desde la vista `v_articulos` (materias primas y productos sin receta), ordenado por nombre; unidades desde `UnidadesMedidaApiService`.
  - Crear y editar materias primas con `IngredientesApiService` (`crear` / `actualizar`). Al editar solo se envían nombre y código de barras: la unidad nunca viaja, y si alguien la cambia por la API el trigger `trg_ingredientes_unidad_fija` lo rechaza.
  - Activar o desactivar con `IngredientesApiService.actualizarEstado` (materias primas) o `ProductosApiService.actualizarEstado` (productos). No se borra nada.
  - Después de cada cambio se vuelve a leer la fila desde `v_articulos`, así la pantalla muestra lo que quedó guardado, incluida la abreviatura de la unidad.
  - Errores en palabras simples: nombre repetido (409), sin permisos (401/403), sin conexión (0) y el mensaje de la base en los 400 (por ejemplo el del trigger de unidad fija).
- `IngredientesApiService.actualizar` acepta cambios parciales (`Partial<IngredienteActualizacion>`), para no pisar la categoría ni el estado al editar desde el Catálogo. La pantalla antigua de Ingredientes sigue enviando todos los campos, sin cambios.
- Pantalla: sin la etiqueta "Datos de ejemplo"; si falla activar o desactivar, se avisa en una franja roja y la fila queda como estaba. Se quitó `enUso` del modelo (no se usaba: la unidad queda fija siempre).
- Errores 409: distingue nombre repetido de código de barras repetido (ambos son UNIQUE en `ingredientes`).
- **Hallazgo de permisos (25-10, verificado en producción):** `nury_bodeguero` solo tenía SELECT sobre `ingredientes`, `productos` y `unidades_medida`, sin INSERT, UPDATE ni uso de `ingredientes_id_seq`. Al bodeguero le fallaba guardar también en la pantalla antigua de Ingredientes. Se agrega `database/migrations/20261025_catalogo_materias_primas_bodeguero.sql` (**aplicada en producción el 25-10**; ensayo verificado: permisos nuevos en true y unidad, costo y `productos.activo` en false): INSERT (nombre, unidad_id, categoria_id, codigo_barras), UPDATE (nombre, codigo_barras, activo, categoria_id) y USAGE de la secuencia. Nunca `unidad_id` ni `costo_unitario_promedio`, sin DELETE. Prueba `database/tests/catalogo_materias_primas_bodeguero.sql`: falla sin la migración y pasa con ella (Postgres de prueba con los permisos de lectura del VPS).
- Productos de reventa (decisión del 25-10): el bodeguero los ve pero no los activa ni desactiva, porque eso los saca de la venta en el POS; en su lugar ve "Lo gestiona el administrador". Sin permisos nuevos en `productos`.
- Probado en el front (`npm start`) con un usuario bodeguero, en computadora y celular: listado real, crear, editar con unidad bloqueada, nombre repetido, desactivar/activar y productos con "Lo gestiona el administrador".
- Pruebas nuevas: `catalogo.service.spec.ts` (9) y `catalogo-articulos.spec.ts` +1 (falla al cambiar estado) con el caso del bodeguero ampliado. `features/inventario` y `core/api`: 18/18 archivos y 265/265 pruebas. `ngc` sin errores.

## Sección Catálogo en Inventario (H3.3 T01) y ajuste de stock en celular — ejecución del 21-10-2026

- `origin/develop` integrado hasta `eac4d6b` (merge del PR #76, H3.3 T02).
- Pestaña nueva **"Catálogo"** en Inventario, junto a Existencias y Mermas y ajustes (`components/catalogo-articulos`):
  - Listado con nombre (y código de barras), tipo (materia prima / producto), unidad y estado (activo / inactivo), ordenado por nombre.
  - Búsqueda sin tildes por nombre o código de barras y filtro por tipo con conteo; "Limpiar filtros" cuando no hay coincidencias; carga con esqueleto y error con "Reintentar".
  - Modal de materia prima (crear y editar): nombre obligatorio y sin repetir, unidad obligatoria y fija desde la creación (criterio de H3.3: queda asociada permanentemente; al editar siempre está bloqueada) y código de barras opcional.
  - Productos normales: solo se listan y se activan o desactivan; "Editar en el Maestro" solo para admin (el bodeguero no tiene acceso al Maestro).
  - Desactivar no borra: el artículo queda inactivo y conserva su historial.
  - **Datos de ejemplo** (`services/catalogo.service.ts`, con la etiqueta en pantalla): H3.3 T03 lo conecta a `v_articulos` y a guardar.
  - Celular: usa las reglas compartidas de Inventario (`@container inventory`): la tabla pasa a tarjetas, campos de 16 px, botones de 44 px y el modal se abre desde abajo.
- Modal "Ajustar stock" en celular (≤ 640 px): se abre desde abajo como los otros diálogos, campos de 16 px (sin zoom del iPhone) y botones de 44 px. Sin cambios en computadora.
- Revisado contra los criterios de aceptación de H3.3 (nombre único y unidad obligatorios, sin duplicados, unidad permanente, edición sin perder historial, listado con unidad para el bodeguero): cumple en pantalla y en la base:
  - `database/migrations/20261023_unidad_fija_ingrediente.sql` (**aplicada en producción el 23-10**; verificado: cambiar la unidad del Queso da "no se puede cambiar: queda fija desde que se crea la materia prima"): el trigger `trg_ingredientes_unidad_fija` rechaza siempre el cambio de unidad, no solo cuando la materia prima está en uso. Prueba `database/tests/unidad_fija_ingrediente.sql` (2 casos; falla sin la migración y pasa con ella). `modelo_articulos.sql` actualizado a la regla nueva.
  - `database/migrations/20261023_unidad_lamina.sql` (**aplicada el 23-10**): unidad "Lámina" (`lám`), que pedía el criterio entre sus ejemplos.
- Pruebas nuevas: `catalogo.model.spec.ts` (4) y `catalogo-articulos.spec.ts` (10); `inventario.spec.ts` +1 (tercera pestaña). `features/inventario`: 9/9 archivos y 209/209 pruebas. `ngc` sin errores.

## Modelo de artículos del Catálogo de Inventario (H3.3 T02) — ejecución del 21-10-2026

- Antes de empezar se integró `origin/develop` hasta `96229ac` (avance rápido: PR #73 de Patricio, reporte real de ajustes y mermas, y PR #75 de Nelson, facturas XML).
- Un **artículo** es lo que tiene stock propio en bodega; no es una tabla nueva. Migración `database/migrations/20261021_modelo_articulos.sql` (**aplicada en producción el 21-10**: ensayo y real sin errores; `v_existencias_articulos` devolvió materias primas con su unidad y productos sin receta en "un", sin el sándwich con receta):
  - `v_articulos`: tipo (`materia_prima` desde `ingredientes`, `producto` desde `productos` sin receta), id, nombre, unidad (la del ingrediente; "un" para productos, que no se venden por peso), código de barras, activo y fecha de creación.
  - `v_existencias_articulos`: existencias de cada artículo por sucursal (`stock_sucursal` / `stock_producto_sucursal`) con unidad, stock y mínimo.
  - Ambas leen con los permisos de su dueño y solo admin y bodeguero pueden consultarlas: en producción el bodeguero **no tiene lectura sobre `recetas`** (ni a nivel de columna, verificado el 21-10) y la vista la necesita para excluir los productos con receta. No expone ingredientes ni cantidades de recetas.
  - Trigger `trg_ingredientes_unidad_fija`: la unidad de una materia prima con recetas, movimientos o stock no se puede cambiar (antes solo lo cuidaba la pantalla de ingredientes).
- Prueba SQL `database/tests/modelo_articulos.sql` (5 casos): catálogo con unidad e inactivos, producto con receta excluido, existencias por sucursal, unidad fija solo en uso y permisos, con el bodeguero consultando sin lectura sobre `recetas`. Mutación verificada: si los productos con receta entran al catálogo, falla el caso 2. `versiones_receta.sql` y `ajuste_stock_permisos.sql` siguen en PASS.
- Decisión para T01/T03/T04 (Sebastián, a prueba): en el Catálogo se crean y editan materias primas; los productos normales se listan y desactivan, y para crearlos o editarlos se va al Maestro de Productos (precio de venta). Si no resulta, se descarta.
- **Hallazgo:** como el bodeguero no puede leer `recetas`, hoy le fallan tres pantallas que consultan `GET /recetas?select=producto_id` para descartar productos con receta: el panel de Inventario (`InventarioService.listarExistencias`), el modal "Ajustar stock" (`AjusteInventario`) y la carga de facturas XML (`CargaFactura`). Con admin funcionan. **Resuelto el 21-10:** `GRANT SELECT (producto_id) ON recetas TO nury_bodeguero` aplicado en producción y verificado (`producto_id` true, `cantidad_necesaria` false); queda registrado en `database/migrations/20261021_permiso_recetas_bodeguero.sql` con su prueba `database/tests/permiso_recetas_bodeguero.sql`. A futuro esas pantallas pueden pasar a `v_articulos` / `v_existencias_articulos` (H3.3 T03).
- Sin cambios de Angular en esta tarea.

## Versión de receta usada en cada venta (H2.5 T02) — ejecución del 20-10-2026

- `origin/develop` sin cambios nuevos al empezar (`05608ee`). Nelson_Branch2 trae solo facturas XML: no toca recetas ni ventas.
- Decisión de Sebastián: se guarda la receta actual de cada producto compuesto como una versión y cada edición crea una versión nueva.
- Migración `database/migrations/20261020_versiones_receta.sql` (**no aplicada en el VPS**):
  - Tablas `recetas_version` (producto, número, vigente desde, creada por) y `recetas_version_detalle` (copia de los insumos). `recetas` sigue siendo la receta editable: el Maestro de Productos no cambia.
  - Trigger en `recetas`: cada cambio crea una versión con la copia completa; una sentencia de varias filas crea una sola y un cambio que deja la receta igual no crea ninguna. Quitar todos los insumos deja una versión vacía (el producto pasa a reventa). Guarda quién editó (`fn_usuario_actual_id`).
  - Las recetas existentes quedan como versión 1.
  - `detalle_venta.receta_version_id`: un trigger `BEFORE INSERT` guarda la versión vigente (la decide la base, no el cliente) y `fn_aplicar_venta` descuenta los insumos de esa versión, no de `recetas`. Así lo descontado y lo registrado coinciden aunque la receta se edite durante la venta. Cambio sobre la de 0004 limitado a 3 líneas (diff revisado).
- `fn_versiones_receta(p_producto_id)`: historial para el Maestro (número, vigente desde, autor, insumos y qué se agregó, quitó o cambió respecto de la versión anterior), `SECURITY DEFINER` para no dar lectura sobre `usuarios`; admin y cajero (los roles del Maestro).
- Maestro de Productos: el modal de receta muestra en una línea "Versión N desde el … · autor", debajo lo que cambió ("Queso 50 → 100 g", "+ Palta 30 g", "− Pan 2 un") y un "Ver versiones anteriores" plegado con los cambios de cada una. Se vuelve a pedir tras agregar, cambiar o quitar un insumo. Si la base todavía no tiene la función, la línea no se muestra y el modal funciona igual.
- Prueba SQL `database/tests/versiones_receta.sql` (8 casos): versión 1 al crear la receta, venta con su versión y descuento correcto, edición con autor y sin versión duplicada, agregar y quitar insumos con historial de la venta anterior, reventa sin versión, receta vaciada como reventa y versión enviada por el cliente ignorada, e historial del Maestro (orden, autor, insumos, cambios de cada versión, versión vacía, reventa sin versiones y permisos). Carga inicial probada aparte (receta previa → versión 1 con sus 2 insumos). Mutación verificada: sin la comparación de "receta igual", falla el caso 1.
- Los tests SQL de anulación, stock insuficiente, permisos e idempotencia del ajuste siguen en PASS con la migración.
- `recetas-api.service.spec.ts` pasa de 4 a 5 y `receta-producto-modal.spec.ts` (suite nueva, 6): línea de versión con sus cambios, historial plegado con los de cada versión, versión que deja el producto sin insumos, sin historial con una versión, recarga tras editar, base sin la función y producto simple.
- Resultado: `features` 360/360 (inventario + productos 196, POS + caja + auth + anulación + gestión 164). El grupo `core`/`layout`/`shared`/`app` (96) no pudo arrancar en la VM en esta última corrida ("Timeout waiting for worker"); pasó completo antes del cambio de los cambios por versión, y solo cambió la interfaz `VersionRecetaApi`. **Pendiente: `npm test` completo en la máquina de Sebastián.**

## Integración con `develop` (PR #71), aviso de stock insuficiente (H2.5 T04) y cantidades enteras en el ajuste — ejecución del 20-10-2026

- Se integró `origin/develop` hasta `05608ee` (PR #71 de Patricio: consulta real de existencias, mínimo en la base, sucursales según permisos y ajuste idempotente con la `0008`). Conflictos resueltos en `ajuste-inventario.spec.ts`, `inventario.service.spec.ts` y este registro, conservando las pruebas de ambos lados:
  - La prueba del 403 del modal se reescribió con los helpers de Patricio y el mensaje nuevo de `fallo-ajuste.ts`.
  - Las 3 pruebas del ajuste simulado de `InventarioService` quedan eliminadas (como en `develop`); la prueba de tiempo de respuesta de T09 se adaptó a la consulta real.
  - `database/tests/ajuste_stock_permisos.sql` usa la firma nueva de `fn_ajustar_stock` (con `uuid`).
- H2.5 T04: `fn_stock_insuficiente_venta` (migración `20261017_stock_insuficiente_venta.sql`, **no aplicada en el VPS**) y aviso en el modal de pago. `pos.service.spec.ts` pasa de 27 a 30, `payment-modal.component.spec.ts` de 19 a 21 y `ventas-api.service.spec.ts` de 9 a 10.
- Productos de reventa solo con cantidades enteras en el ajuste: 1 prueba nueva en `ajuste-inventario.spec.ts`.
- `ajuste_stock_idempotente.sql` de Patricio, que no se había podido ejecutar, pasa sus 6 casos con la `0008` en la base de prueba.
- Resultado: 35/35 suites y 449/449 pruebas.

## Reintentos del ajuste de stock sin aplicarlo dos veces (H3.6 T06) — ejecución del 17-10-2026

- `origin/develop` sin cambios nuevos al empezar.
- Base: `database/migrations/0008_ajuste_stock_idempotente.sql` agrega `clave_idempotencia` (UUID, índice único) a `movimientos_stock` y el parámetro `p_clave` a `fn_ajustar_stock`. Con la misma clave y los mismos datos devuelve el movimiento ya registrado sin tocar el stock; con otros datos lo rechaza (22023). Sin clave funciona como antes. **No aplicada en el VPS.**
- Prueba SQL: `database/tests/ajuste_stock_idempotente.sql` (6 casos, termina en `ROLLBACK`). **No ejecutada:** esta máquina no tiene Docker ni `psql`. Debe correrse en una base de pruebas antes de aplicar la 0008.
- Pantalla: el modal `ajuste-inventario` genera una clave por ajuste (`nuevaClave`, UUID v4 también fuera de https) y la repite si se reintenta con los mismos datos. Los errores se interpretan con `fallo-ajuste.ts` (antes sin uso): distingue sin conexión, sesión vencida, permisos y función no publicada, y en los rechazos de la base muestra el texto de `fn_ajustar_stock`. Ante un corte, el botón pasa a "Reintentar ajuste" y los datos quedan en el formulario. Con stock insuficiente o artículo inexistente vuelve a consultar el stock. Se eliminó `mensajeDeError`.
- `ajuste-inventario.spec.ts` pasa de 13 a 18: reintento tras un corte con la misma clave, clave nueva si cambian los datos, texto de la base y stock refrescado con 23514, sesión vencida y UUID sin `randomUUID`.
- `fallo-ajuste.spec.ts` pasa de 17 a 18: mensajes de datos inválidos con el texto de la base, stock negativo con el texto de la base y mensaje de conexión que no promete que no pasó nada.
- `stock-api.service.spec.ts` sigue en 8: el envío incluye `p_clave`.
- Resultado: 35/35 suites y 434/434 pruebas en 2 corridas consecutivas. `npm run build` aprobado, 0 errores y 0 advertencias.
- No se probó en el navegador: la pantalla usa la API compartida del VPS, donde la 0008 no está aplicada, y probarla ahí registraría ajustes reales.

## Reporte de mermas conectado a la base (H3.6 T07) y casos límite del panel de stock (H3.5 T09) — ejecución del 20-10-2026

- **Comando:** `npm test -- --watch=false --reporters=verbose`; `npm run build`.
- **Resultado:** 35 suites, 462/462 aprobadas en 3 corridas consecutivas; build con 0 errores y 0 advertencias.
- **H3.6 T07** (`listarMermas()` lee `movimientos_stock`: ajustes y mermas con cantidad negativa, con artículo, sucursal y usuario):
  - `stock-api.service.spec.ts` pasa de 8 a 10: parámetros de `listarSalidasManuales` con y sin sucursal.
  - `inventario.service.spec.ts` pasa de 17 a 21: se quitó la prueba de los datos de ejemplo; se agregaron el mapeo de un ingrediente y un producto, el admin con la sucursal del filtro o con todas, `hasta` enviado como el día siguiente (31-12 → 01-01), el bodeguero forzado a su sucursal y el bodeguero sin sucursal.
  - `reporte-mermas.spec.ts` pasa de 13 a 15: mensaje de falta de permiso con 403 (sin Reintentar) y "—" cuando el ajuste no tiene usuario.
- **H3.5 T09** (solo pruebas, sin cambios de código de producción):
  - `inventario.model.spec.ts` pasa de 21 a 24: stock negativo con mínimo 0, stock igual al mínimo con 3 decimales, faltante de 0,001 y conteo de agotados con mínimo 0.
  - `fallo-minimo.spec.ts` pasa de 9 a 11: 403 sin código y 22P02 con el mensaje genérico.
  - `inventario.spec.ts` pasa de 60 a 74: más mínimos inválidos (espacios, `-0,5`, `1e3`, `1000000000`) y válidos (punto decimal, espacios, 3 decimales, máximo de NUMERIC(12,3)), artículo agotado que sigue con alerta con mínimo 0, y el mismo artículo en dos sucursales (estado, alerta y conteo por sucursal; el mínimo solo cambia en la fila editada).
  - Cobertura revisada contra la tarjeta: los filtros combinados, "superior al mínimo" y los permisos de lectura por rol ya estaban cubiertos.
- **Otro cambio en el inventario:** `ajuste-inventario.spec.ts` figura con 19 (antes 18) por la prueba de `3e7ff94` (solo cantidades enteras al ajustar productos de reventa), que llegó con `develop`; no es de estas tareas.
- **Hallazgo sin corregir:** `validarMinimo('-0')` rechaza el valor con "Usa como máximo 3 decimales." en vez de "El mínimo no puede ser negativo.". No hay riesgo de datos.
- **Sin probar en el navegador contra la API real:** la consulta de mermas se verificó con pruebas y build; falta abrir el reporte con sesión de admin.
- **Ajuste del mismo día (filtro por tipo y hora UTC):** el reporte pasó a mostrar todos los ajustes manuales (entradas y salidas, con signo) y a tener el filtro "Todos los ajustes" / "Solo mermas"; las fechas de la base se leen como UTC y se muestran en hora de Chile. 466/466 y build sin advertencias.
  - `stock-api.service.spec.ts` sigue en 10: sin filtro por signo, límites con hora UTC y `tipo_movimiento=eq.merma` con "Solo mermas".
  - `inventario.service.spec.ts` pasa de 21 a 22: mapeo con signo, clase y hora UTC; fecha que ya trae zona; medianoche local convertida a UTC en los dos extremos del periodo.
  - `reporte-mermas.spec.ts` pasa de 15 a 18: totales que separan salidas y entradas, vista "Solo mermas" (consulta, conteo y estado vacío) y entradas con signo +.
  - **Verificado en el navegador** el 20-10-2026 con sesión de admin contra la API real: 10 ajustes en los últimos 7 días, horas en hora de Chile (el ajuste de las 17:50 aparece a las 17:50), "Registrado por" con el usuario en los ajustes nuevos y "—" en los antiguos, y "Solo mermas" vacío porque la base aún guarda todo como `ajuste`.

## Limpieza del ajuste simulado en `InventarioService` — ejecución del 17-10-2026

- `origin/develop` sin cambios nuevos al empezar.
- El ajuste real lo registra `AjusteInventario` con `fn_ajustar_stock`, así que `InventarioService.registrarAjuste` (simulado en memoria) ya no tenía uso fuera de sus pruebas. Se eliminaron el método, su estado (`existencias`, `resultadosPorClave`, `reemplazar`), el helper `errorPostgrest` y los tipos `SolicitudAjuste` y `ResultadoAjuste`. El reporte de mermas sigue con datos de ejemplo.
- `inventario.service.spec.ts` pasa de 20 a 17: se quitaron las 3 pruebas del ajuste simulado (descuento, reintento idempotente y rechazo por stock insuficiente). Los rechazos reales de `fn_ajustar_stock` ya los cubre `fallo-ajuste.spec.ts`. La idempotencia no tiene reemplazo: `fn_ajustar_stock` no recibe clave de idempotencia (queda registrado como pendiente).
- `inventario.spec.ts` sigue en 60: solo se quitó `registrarAjuste` del doble del servicio.
- Resultado: 35/35 suites y 428/428 pruebas. `npm run build` aprobado, 0 errores y 0 advertencias.

## Panel por dispositivo y sucursales según permisos (H3.4 T08) — ejecución del 16-10-2026

- `origin/develop` sin cambios nuevos al empezar.
- Sucursales según permisos:
  - El modal de ajuste (`ajuste-inventario`) cargaba todas las sucursales activas, así que un bodeguero podía ajustar stock de otra tienda. Ahora usa la misma regla del panel (`sucursalesAutorizadas`): el admin elige entre todas; el bodeguero solo ve la suya y queda elegida; sin sucursal no ve ninguna y se le explica por qué.
  - El encabezado del panel nombra lo que se consulta: "en todas las sucursales" para el admin y "de {su sucursal}" para el bodeguero.
  - El filtro de sucursal ya se ocultaba cuando hay una sola.
- Bodeguero sin sucursal: Patricio indicó que no deberían existir usuarios así. La base solo lo impedía para el cajero (`CHECK (rol <> 'cajero' OR sucursal_id IS NOT NULL)`) y el formulario de usuarios también. Ahora el formulario exige sucursal al cajero y al bodeguero; el admin puede quedar sin ella. El panel mantiene su mensaje por si aparece uno creado directo en la base. Consulta de solo lectura: hoy ningún usuario activo está sin sucursal.
- Dispositivos, revisado en vivo con datos reales: a 375 px (teléfono) tarjetas de una columna, botones y filtros de 44 px, sin desplazamiento horizontal, modal del mínimo como hoja inferior y modal de ajuste desplazable hasta "Aplicar ajuste"; a 768 px (tablet) tarjetas en dos columnas; a 1280 px tabla completa. No hizo falta cambiar estilos.
- `ajuste-inventario.spec.ts` pasa de 10 a 13: admin con todas las sucursales, bodeguero limitado a la suya y preseleccionada, y bodeguero sin sucursal.
- `gestion-negocio.spec.ts` pasa de 1 a 5: cajero y bodeguero sin sucursal rechazados, bodeguero con sucursal creado y admin sin sucursal permitido.
- `inventario.spec.ts` pasa de 57 a 60: encabezado para bodeguero, admin y bodeguero sin sucursal.
- Resultado: 35/35 suites y 431/431 pruebas en 2 corridas consecutivas. `npm run build` aprobado, 0 errores y 0 advertencias.

## Edición del mínimo conectada a la base (H3.5 T05) — ejecución del 16-10-2026

- `origin/develop` sin cambios nuevos al empezar (rama en `8d42e58`).
- El mínimo se guarda en la base:
  - `StockApiService.actualizarMinimo` hace un PATCH solo de `stock_minimo` en `stock_sucursal` o `stock_producto_sucursal`, filtrando por artículo y sucursal, y devuelve el valor guardado (`null` si la fila no existe). No toca `stock_actual`, así que no interfiere con ventas ni ajustes simultáneos.
  - `InventarioService.actualizarMinimo` usa `articuloId` y `sucursalId` de la existencia y falla con `MinimoSinFilaError` si la fila ya no está.
  - `interpretarFalloMinimo` (`features/inventario/models/fallo-minimo.ts`) da un mensaje por fallo: sin conexión, sesión vencida, sin permiso (403), mínimo negativo (23514, para cuando exista la restricción de H3.5 T02), número fuera de rango (22003), fila inexistente (además vuelve a consultar las existencias) y error del servidor. Todos aclaran que el mínimo no se modificó.
  - Las validaciones del formulario (vacío, negativo, no numérico, más de 3 decimales y máximo de NUMERIC(12,3)) se mantienen.
- `stock-api.service.spec.ts` pasa de 6 a 8: PATCH del producto (método, cuerpo, filtros, `select` y `Prefer`) y fila inexistente del ingrediente.
- `fallo-minimo.spec.ts` (suite nueva, 9): cada estado y código, y la fila inexistente que pide actualizar.
- `inventario.service.spec.ts` pasa de 17 a 20: producto, materia prima y fila inexistente.
- `inventario.spec.ts` pasa de 55 a 57: mensaje de permiso y reconsulta cuando la fila ya no existe.
- Verificación contra `api.nury.cl` con la sesión de admin de Patricio, solo en "Nury Providencia (Equipo de desarrollo)":
  - Permiso: un PATCH con filtro que no coincide con ninguna fila (id −1) respondió 200 en ambas tablas, sin modificar nada.
  - CHAPARRITA con mínimo 10: la base guardó 10 con `stock_actual` intacto (6), la fila pasó a "Crítico" con "Faltan 4 un para el mínimo" y el aviso sumó "1 en estado crítico".
  - Se restauró a 0 desde el mismo panel: la base volvió a 0 y la alerta de crítico desapareció.
- Resultado: 35/35 suites y 421/421 pruebas en 2 corridas consecutivas. `npm run build` aprobado, 0 errores y 0 advertencias.

## Consulta real de existencias en Inventario (H3.4 T03 y T04) — ejecución del 16-10-2026

- Antes de empezar se integró `origin/develop` hasta `5740f59` (avance rápido). Durante el trabajo Sebastián subió a `develop` el PR #68 (`cbec80c`), que tocaba los mismos archivos del panel. Para no mezclar, Patricio pidió descartar los cambios locales (se guardó un respaldo), traer `develop` hasta `2feb292` (avance rápido, sin conflictos) y rehacer el trabajo encima.
- Lo que trae `develop`:
  - Sebastián (PR #67 y #68): el ajuste real de stock (`fn_ajustar_stock`) se abre como modal desde "Ajustar stock" y desde "Ajustar" en cada fila (`ajuste-inventario`, 10 pruebas). Se eliminaron la pestaña "Ajuste de stock" y el formulario de descuento de ejemplo (`components/ajuste-stock` y sus 41 pruebas).
  - Antes ya habían llegado la reposición de stock al anular (`0007`, Sebastián) y la venta a empleado (H2.12, Maher).
  - Con eso la base quedó en 387 pruebas y 34 suites, todas aprobadas.
- El panel deja los datos de ejemplo y lee el stock real:
  - `StockApiService.listarStockIngredientes` y `listarStockProductos` consultan `stock_sucursal` y `stock_producto_sucursal` con el nombre del artículo, la unidad (solo ingredientes) y la sucursal. Solo incluyen artículos y sucursales activos (`!inner`) y, si se indica, una sola sucursal.
  - `InventarioService.listarExistencias` une ambas, deja fuera las filas de productos con receta (descuentan ingredientes), usa "un" como unidad de los productos y ordena por sucursal y artículo. Solo lista filas que ya existen: no completa con ceros los artículos sin stock registrado (decisión de Patricio).
  - Sucursales autorizadas (`sucursalesAutorizadas`): el admin ve todas; el bodeguero, solo la suya; sin sucursal asignada no se consulta nada y el panel lo explica. La base todavía no restringe la lectura por sucursal.
  - `ExistenciaStock` suma `articuloId` (ingrediente_id o producto_id) para conectar el mínimo.
  - Se quitó la etiqueta "Datos de ejemplo" de Existencias; el reporte de mermas la mantiene.
- El faltante para el mínimo (H3.5 T06) ya no aparece con mínimo 0, porque con stock negativo solo repetía el descuadre.
- `stock-api.service.spec.ts` pasa de 4 a 6: parámetros de las dos consultas, con y sin sucursal.
- `inventario.service.spec.ts` pasa de 4 a 17:
  - Sucursales autorizadas por rol (5).
  - Mapeo de ingredientes y productos con números en texto, orden, filas por sucursal, exclusión de productos con receta y unidad vacía.
  - Consulta del admin y del bodeguero, y bodeguero sin sucursal.
  - Las pruebas de las mermas y del descuento de ejemplo se mantienen sin depender de la consulta.
- `inventario.spec.ts` pasa de 52 a 55: bodeguero sin sucursal, sin etiqueta de datos de ejemplo y faltante oculto con mínimo 0.
- Verificación contra `api.nury.cl` con la sesión de admin de Patricio (solo lectura):
  - 8 filas reales de "Nury Providencia (Equipo de desarrollo)": 7 productos y 1 ingrediente (Queso, en g).
  - 6 empanadas como "Agotado" con descuadre, el aviso de 6 agotados y sin faltantes con mínimo 0.
  - "Ajustar" en la fila de CHAPARRITA abre el modal de Sebastián con el artículo elegido y su stock real (6). Se cerró sin guardar.
- Resultado: 34/34 suites y 405/405 pruebas en 2 corridas consecutivas. `npm run build` aprobado, 0 errores y 0 advertencias.

## Pruebas del panel de Inventario: actualización, tiempo de respuesta, reconexión, permisos, sucursales y estados (H3.4 T09) — ejecución del 16-10-2026

- Antes de empezar se sincronizó con `origin/develop` (sin cambios nuevos, `5740f59`).
- Contexto: desde el 16-10 el botón "Ajustar stock" del panel y el de cada fila abren como modal el ajuste real (`AjusteInventario`, `fn_ajustar_stock`). Se eliminó el modal de ejemplo `components/ajuste-stock` con su spec (41 pruebas), por eso la suite total baja respecto del 14-10.
- Cobertura de T09, criterio por criterio:
  - **Actualización:** hora "Actualizado a las …" visible tras la carga y renovada al volver a consultar después de un ajuste, con la cantidad nueva en la tabla (nuevo). Reconsulta tras ajustar (16-10).
  - **Tiempo de respuesta:** mientras la respuesta está pendiente se mantiene el estado de carga sin filas, y los datos aparecen en cuanto llegan, con una sola consulta (nuevo). `InventarioService.listarExistencias` no agrega espera propia: entrega las filas apenas la API responde (nuevo; adaptado el 20-10 a la consulta real de H3.4 T03, el tiempo total depende de la API).
  - **Reconexión:** ya cubierta en H3.4 T07 (datos visibles y aviso al desconectar, reconsulta sin ocultar datos, fallo con reintento, recarga si la carga inicial falló, respuesta tardía descartada, reconsulta de mermas).
  - **Permisos:** acceso a `/inventario` solo para admin y bodeguero, ya cubierto en `auth.guard.spec.ts`. Nuevo: si la base rechaza con 403, el modal muestra "Tu usuario no tiene permiso para registrar ajustes de stock. El stock no se modificó." (mensaje de `fallo-ajuste.ts` desde H3.6 T06) y no informa éxito al panel. Nuevo test SQL `database/tests/ajuste_stock_permisos.sql`: admin y bodeguero pueden ejecutar `fn_ajustar_stock`, cajero y `web_anon` no; el cajero recibe permiso denegado y solo queda el ajuste del bodeguero.
  - **Separación entre sucursales (nuevo):** el mismo artículo aparece una vez por sucursal con su cantidad, mínimo y estado; al elegir una sucursal solo se muestran y cuentan sus artículos; editar el mínimo en una fila no cambia la otra sucursal; el ajuste se abre en la sucursal de la fila.
  - **Estados de carga, vacío y error:** ya cubiertos (esqueleto y `aria-busy`, "Aún no hay existencias registradas.", sin coincidencias con "Limpiar filtros", error con "Reintentar").
- Al integrar con `develop` (20-10, PR #71 de Patricio) se suman: 6 pruebas en `inventario.spec.ts`, 1 en `ajuste-inventario.spec.ts` (403) y 1 en `inventario.service.spec.ts`.
- No se hizo verificación en navegador en esta ejecución (pendiente en la máquina de Sebastián).
- Nota de entorno: en la VM Linux de Cowork los `node_modules` son de Windows; las pruebas corren apuntando a binarios Linux descargados fuera del proyecto (`@esbuild/linux-x64` y `@rolldown/binding-linux-x64-gnu`), sin modificar `node_modules`.
- Resultado del 16-10, antes de integrar: 34/34 suites y 395/395 pruebas.

## Filtros combinables por estado y tipo y alertas visuales (H3.5 T06) — ejecución del 14-10-2026

- Antes de empezar se sincronizó con `origin/develop` (sin cambios nuevos).
- La regla de filtrado pasa del componente al modelo (`features/inventario/models/inventario.model.ts`) como funciones puras: `filtrarExistencias` combina estado, tipo, sucursal y texto (todos a la vez), `cumpleFiltroEstado`, `contarEstados`, `tieneDescuadre`, `faltanteParaMinimo` y `normalizarTexto`.
- Conteos que respetan los demás filtros: las opciones de los selectores de estado y de tipo muestran cuántos registros quedan al elegirlas (por ejemplo "Críticos (2)"), y las tarjetas de resumen cuentan con el tipo, la sucursal y la búsqueda aplicados.
- El aviso de alertas sigue contando toda la sucursal consultada: filtrar por tipo o buscar no esconde que hay agotados. "Ver alertas" y "Ver descuadres" quitan el tipo y la búsqueda para que la lista muestre exactamente lo que el aviso anunció, y siguen visibles mientras otro filtro esconda alguna alerta.
- Filtros aplicados visibles: "Mostrando X de Y registros", un chip por filtro que se quita de a uno y "Limpiar filtros".
- Alertas visuales: el aviso es rojo con ✕ si hay algún agotado y ámbar si solo hay críticos. Cada fila agotada o crítica indica cuánto falta para el mínimo ("Faltan 0,4 kg para el mínimo").
- `inventario.model.spec.ts` (suite nueva, 21): cada filtro de estado, combinaciones de estado, tipo, sucursal y texto, búsqueda sin tildes, orden original, conteos y faltante con decimales.
- `inventario.spec.ts` pasa de 44 a 53: conteos por opción con los otros filtros, tarjetas filtradas por tipo, aviso de la sucursal completa con filtros activos, "Ver alertas" desde una lista filtrada, sucursal conservada, chips y limpieza, color por gravedad, faltante por fila y retiro de la alerta al volver a estable. La prueba de columnas incluye el texto del faltante.
- Verificación en navegador (`/inventario`, sesión simulada de bodeguero que luego se eliminó): materias primas + "Con alerta" con aviso rojo de la sucursal completa, chips y faltantes a 1400 px; productos + "Con alerta" a 375 px con "Ver alertas" visible y sin desplazamiento horizontal.
- Resultado: 34/34 suites y 400/400 pruebas en 2 corridas consecutivas. `npm run build` aprobado, 0 errores y 0 advertencias.

## Mensajes de resultado del descuento manual de stock (H3.6 T05) — ejecución del 14-10-2026

- Antes de empezar se integró `origin/develop` (avance rápido hasta `884b2a8`, sin conflictos). Trae de Sebastián `fn_ajustar_stock` (`database/migrations/0005_ajuste_stock.sql`), `StockApiService` y la pantalla `/inventario/ajuste-stock`, además de permisos de cajero, recuperación de turno y recetas. Suma las suites `recetas-api` (4), `stock-api` (4), `turnos-api` (1) y `recuperar-turno` (8), y casos nuevos en otras suites de develop.
- El formulario de descuento (validaciones y confirmación de H3.6 T01) ahora distingue cada fallo del registro con `interpretarFalloAjuste` (`features/inventario/models/fallo-ajuste.ts`), que sigue los códigos de `fn_ajustar_stock`:
  - Sin conexión o error del servidor: se queda en la confirmación con "Reintentar" y la misma clave de idempotencia.
  - Stock insuficiente (23514), artículo o sucursal inexistente (23503) y datos inválidos (22023): vuelve al formulario con el aviso para corregir. En los dos primeros, y con producto con receta, el panel vuelve a consultar las existencias y el formulario valida contra el stock nuevo.
  - Sesión vencida (401), sin permiso (403 o 42501) y función no publicada (PGRST202): bloquea la confirmación y explica el motivo.
  - Todos los mensajes aclaran que el stock no se modificó.
- El servicio de ejemplo rechaza con la misma forma que PostgREST (`HttpErrorResponse` con `code` y `message`).
- `fallo-ajuste.spec.ts` (suite nueva, 17): cada código y estado HTTP, los textos de datos inválidos, cuándo pedir actualizar el stock y el error inesperado.
- `ajuste-stock.spec.ts` pasa de 35 a 41: vuelta al formulario por stock cambiado con validación contra el stock nuevo y clave nueva, datos inválidos, bloqueo por sesión y por permiso, función no disponible y reintento tras perder la conexión.
- `inventario.spec.ts` pasa de 43 a 44: el aviso del formulario vuelve a consultar las existencias sin cerrarlo.
- `inventario.service.spec.ts`: el rechazo por sobre el stock ahora se verifica con el código 23514.
- Verificación en navegador (`/inventario`, sesión simulada de bodeguero que luego se eliminó): rechazo por stock cambiado, vuelta al paso 1 con el aviso, foco en la cantidad, panel actualizado a 1 kg y validación "No puedes descontar más que el stock disponible (1 kg)". Confirmación bloqueada por permisos a 375 px. Sin desplazamiento horizontal ni errores de consola.
- Resultado: 33/33 suites y 370/370 pruebas en 2 corridas consecutivas. `npm run build` aprobado, 0 errores y 0 advertencias.

## Indicador de desconexión y recuperación al reconectar en Inventario (H3.4 T07) — ejecución del 08-10-2026

- Antes de empezar se sincronizó con `origin/develop` (sin cambios nuevos).
- Nuevo `core/services/conexion.service.ts`: sigue los eventos `online`/`offline` del navegador y avisa cada reconexión, incluso un corte breve entre dos renderizados. El canal de tiempo real (H3.4 T06) podrá sumar ahí su propio estado.
- El indicador y el aviso de desconexión del panel (H3.4 T01) ahora se activan de verdad. Al reconectar, el panel vuelve a consultar las existencias sin ocultar los últimos datos: muestra "Actualizando..." y la tabla atenuada con `aria-busy`. Si la carga inicial había fallado, la repite completa. El reporte de mermas también vuelve a consultar.
- Si la consulta tras reconectar falla, los datos anteriores siguen visibles y atenuados, el indicador dice "Datos sin actualizar" y aparece un aviso con "Reintentar". Una respuesta tardía de una reconexión anterior se descarta.
- `conexion.service.spec.ts` (suite nueva, 3): estado inicial del navegador, eventos y aviso de cada reconexión, y liberación de los listeners al destruir la app.
- `inventario.spec.ts` pasa de 38 a 43. La prueba de desconexión ahora usa el evento real `offline` en lugar de fijar el estado a mano, y se suman: reconsulta sin perder los datos, fallo con reintento, recarga cuando la carga inicial había fallado, respuesta tardía descartada y reconsulta de mermas.
- Verificación en navegador (`/inventario`, sesión simulada de bodeguero que luego se eliminó): desconexión, "Actualizando..." al reconectar, vuelta a "En línea" y aviso "Datos sin actualizar" con "Reintentar" a 800 px y 375 px, sin desplazamiento horizontal ni errores de consola.
- Resultado: 28/28 suites y 313/313 pruebas en 2 corridas consecutivas (12.05 a 13.01 s). `npm run build` aprobado, 0 errores y 0 advertencias.

## Filtro "Con descuadre" en Existencias — ejecución del 08-10-2026

- El filtro "Estado de stock" suma la opción "Con descuadre", que muestra solo los artículos con stock negativo y se combina con los filtros de tipo, sucursal y texto. El aviso de alertas tiene el acceso directo "Ver descuadres", que aplica el filtro y se oculta cuando ya está activo.
- El contador del panel ahora usa singular ("1 registro"); antes decía "1 registros".
- `inventario.spec.ts` pasa de 37 a 38. La prueba nueva cubre:
  - El acceso directo desde el aviso y el valor que queda en el filtro.
  - El conteo en singular.
  - La diferencia con el filtro de agotados, que también incluye el stock en cero.
  - El estado vacío al combinar el filtro con una sucursal sin descuadres.
- Validación en navegador (localhost con sesión de bodeguero simulada, sin llamadas al VPS): con "Ver descuadres" queda solo Leche entera de Nury Ñuñoa, con −2 L y la etiqueta de descuadre.
- Resultado automático: 27/27 suites aprobadas y 305/305 pruebas exitosas en dos corridas seguidas. Compilación de producción sin errores ni advertencias.

## Etiqueta de descuadre para stock negativo en Inventario — ejecución del 08-10-2026

- Las ventas descuentan stock aunque no alcance (`fn_aplicar_venta` no valida y `stock_sucursal` no tiene restricción de mínimo cero), así que un stock negativo indica compras o conteos sin registrar.
- Esas filas mantienen el estado "Agotado" del criterio de H3.5 y suman una etiqueta "Descuadre" con su explicación. El aviso de alertas agrega cuántos artículos de la sucursal consultada tienen stock negativo.
- El formulario de descuento distingue los dos bloqueos. Con stock en cero dice "Este artículo no tiene stock disponible"; con stock negativo explica el descuadre y pide ingresar primero la compra o el conteo pendiente.
- Pruebas:
  - `inventario.spec.ts` pasa de 36 a 37. La nueva prueba distingue descuadre de stock en cero, revisa el texto del aviso y que desaparezca al filtrar una sucursal sin negativos. La prueba del listado ahora espera "Agotado Descuadre" en la fila negativa.
  - `ajuste-stock.spec.ts` pasa de 34 a 35. El caso de bloqueo se separó en stock cero y stock negativo, cada uno con su mensaje.
- Validación en navegador (localhost con sesión de bodeguero simulada, sin llamadas al VPS): la etiqueta se ve bajo el estado a 1100 px sin desbordar la tabla, y en las tarjetas a 375 px sin desplazamiento horizontal.
- Resultado automático: 27/27 suites aprobadas y 304/304 pruebas exitosas en dos corridas seguidas. Compilación de producción sin errores ni advertencias.

## Descuento manual de stock y consulta de mermas en Inventario (H3.6 T01) — ejecución del 08-10-2026

- Antes de empezar se integró `origin/develop` (catálogo de ingredientes H3.3, Edenred en lugar de Pluxee y las mismas correcciones de `caja.service.spec.ts` y `pos-layout`). Hubo conflicto en `app.routes.ts` (se conservaron `inventario/ingredientes` e `inventario`) y en `caja.service.spec.ts` (misma limpieza de `sessionStorage`; se dejó la versión de `develop` con el comentario explicativo). Tras el merge: 24/24 suites y 245/245 pruebas, build limpio. El merge suma `ingredientes-api.service.spec.ts` (5 pruebas).
- Inventario ahora tiene pestañas "Existencias" y "Mermas y ajustes", y un botón "Descontar stock" en la cabecera y en cada fila con stock.
- Formulario de descuento (`AjusteStock`), en dos pasos:
  - Datos: sucursal; artículo agrupado por tipo, con la marca "sin stock"; stock, unidad y estado actuales; cantidad; motivo con sugerencias; vista previa del stock resultante.
  - Confirmación: resumen con el usuario que registra el ajuste.
  - Bloquea artículos con stock ≤ 0.
  - Valida: cantidad positiva, hasta 3 decimales y sin superar el stock; motivo obligatorio, que no puede estar vacío ni tener solo espacios, con máximo 200 caracteres.
  - Solo admin y bodeguero confirman. Cada revisión genera una clave de idempotencia y los reintentos reutilizan esa misma clave.
- Reporte de mermas (`ReporteMermas`):
  - Filtros de sucursal y periodo: hoy, 7 días, 30 días, este mes o personalizado. El rango personalizado se valida.
  - Totales agrupados por artículo y unidad (`agruparMermas`) y detalle con fecha, hora, cantidad con unidad, motivo, usuario y sucursal.
  - Estados de carga, vacío y error con reintento. Vuelve a consultar después de cada ajuste.
- Los estilos comunes pasaron a `features/inventario/styles/inventario-base.css`. `inventario.css` bajó de 18,3 kB a 11,8 kB, lejos del límite de advertencia de 20 kB.
- `InventarioService` sigue con datos de ejemplo en memoria: el descuento se refleja en las existencias y el reporte, y una clave repetida no descuenta dos veces. El servicio real queda para H3.6 T03 y el reporte real para H3.6 T07.
- Pruebas nuevas:
  - `ajuste-stock.spec.ts` (34):
    - 12 casos de `validarCantidadAjuste` y 5 de `validarMotivo`.
    - Apertura desde la fila y foco; artículos por sucursal y tipo; sucursal del usuario; bloqueo sin stock.
    - Errores de artículo, cantidad y motivo; sugerencia de motivo y vista previa.
    - Resumen de confirmación y volver; confirmación con datos normalizados.
    - Error con reintento usando la misma clave; clave nueva si cambian los datos.
    - Rol no autorizado; cierre con Cancelar o Escape, bloqueado mientras guarda.
  - `reporte-mermas.spec.ts` (13):
    - 3 casos de `agruparMermas`.
    - Consulta por defecto de 7 días, con totales y detalle.
    - Sucursal inicial y filtro de sucursal; periodos hoy, 30 días y mes; validación del rango personalizado.
    - Estado vacío; carga y error con reintento; nueva consulta tras un ajuste; un solo filtro de sucursal.
  - `inventario.service.spec.ts` (4): descuento con registro completo, reintento sin doble descuento, rechazo por sobre el stock y filtro de mermas por sucursal y periodo.
  - `inventario.spec.ts` pasa de 30 a 36: botón general deshabilitado al cargar, "Descontar" solo con stock, apertura desde la fila y por sucursal, actualización de fila, tarjetas y alertas tras el ajuste, cancelación y pestaña de mermas.
- Validación en navegador (localhost con sesión de bodeguero simulada, sin llamadas al VPS):
  - Descuento de 2,5 kg de Café en grano: la fila, las tarjetas, la alerta y el reporte se actualizaron sin recargar.
  - Tabla a 1100 px; se ajustó el relleno de las celdas porque las dos acciones desbordaban 49 px.
  - Tarjetas a 800 px.
  - Formulario como hoja inferior y reporte en tarjetas a 375 px, sin desplazamiento horizontal.
- Resultado automático: 27/27 suites aprobadas y 302/302 pruebas exitosas en dos corridas seguidas. Compilación de producción sin errores ni advertencias.

## Estados, alertas y edición del stock mínimo en Inventario (H3.5 T01) — ejecución del 07-10-2026

- Regla de estados según el criterio de H3.5 (`calcularEstadoStock`): agotado si el stock es ≤ 0; crítico si es positivo y menor que el mínimo; estable si es positivo e igual o mayor que el mínimo.
- El panel suma la columna Mínimo, la etiqueta de estado por fila, una franja de color en filas agotadas o críticas, tarjetas de resumen por estado (que también filtran), un aviso con el total de alertas de la sucursal consultada y el filtro "Estado de stock", combinable con tipo, sucursal y texto.
- Modal "Stock mínimo": muestra stock y estado actuales, acepta coma o punto decimal, rechaza vacío, negativo, texto no numérico y más de 3 decimales (`NUMERIC(12,3)`), y anticipa el estado resultante antes de guardar. Guarda con datos de ejemplo hasta H3.5 T03.
- `inventario.spec.ts` pasa de 8 a 30 pruebas:
  - 7 casos de `calcularEstadoStock`: negativo, cero, cero con mínimo cero, menor, igual y mayor al mínimo, y positivo con mínimo cero.
  - Listado con mínimo y estado; clases de alerta por fila y conteo por estado.
  - Aviso de alertas por sucursal consultada y botón "Ver alertas"; sin aviso cuando todo está estable.
  - Filtro de estado combinado con tipo y texto; tarjetas de resumen como filtro activable.
  - Edición: datos actuales, 4 valores inválidos con su mensaje, vista previa del estado, guardado con decimal con coma, mínimo 0 válido, error al guardar y cierre con Cancelar o Escape.
- Validación en navegador (localhost con sesión de bodeguero simulada, sin llamadas al VPS): tabla completa a 1100 px, tarjetas a 800 px y modal tipo hoja inferior a 375 px, sin desplazamiento horizontal. Se detectó que el `box-shadow` de la franja oscurecía en Chrome los bordes de la primera columna; se reemplazó por un fondo.
- Resultado automático: 23/23 suites aprobadas, 240/240 pruebas exitosas en dos ejecuciones seguidas. Compilación en modo producción sin errores ni advertencias (`npm run build`).

## Intermitencia de `caja.service.spec.ts` — corrección del 07-10-2026

- **Síntoma:** en cerca de 1 de 5 corridas fallaban 6 pruebas de cierre con diferencia de efectivo y de boletas. `pos.salesHistory()` traía ventas `id: 999` de otras pruebas (p. ej. "expected [ { id: 999, … }, …(3) ] to have a length of 1 but got 4") y el cierre lanzaba "Debes justificar la diferencia de efectivo antes de cerrar el turno.".
- **Causa:** el runner de Angular para Vitest (`@angular/build:unit-test`) usa `isolate: false` por defecto, así que todos los specs comparten el mismo `sessionStorage` de jsdom. Algunos specs dejaban ahí una sesión iniciada (`nury_session`, usuario 1) y un turno con ventas (`nury_turno`, usuario 1, ventas id 999), sin limpiarlos al terminar. `caja.service.spec.ts` usa el `AuthService` real y no limpiaba `sessionStorage`, así que el constructor de `PosService` restauraba ese turno ajeno (`restoreTurno`). Solo fallaba cuando el orden de los archivos dejaba ambas claves antes de esta suite, por eso era intermitente.
- **Reproducción determinista:** se sembraron temporalmente en el `beforeEach` de `caja.service.spec.ts` una sesión del usuario 1 y un `nury_turno` con 3 ventas id 999. La suite falló con los mismos mensajes ("Debes justificar…", "to have a length of 1 but got 4"). La siembra se retiró después.
- **Descartado:** `new Date()` en `FAKE_TURNO` y el `timeout(15000)` de `completeSale`. `CajaService` no filtra ventas por `hora_inicio`, y con `of(...)` síncrono el `timeout` nunca se dispara.
- **Corrección (solo pruebas, sin cambios de producción):**
  - `caja.service.spec.ts`: `sessionStorage.clear()` en `beforeEach` y `afterEach`, igual que `cierre-caja.component.spec.ts`.
  - `payment-modal.component.spec.ts`: `afterEach(() => sessionStorage.clear())` para no dejar sus ventas (usuario 1, id 999) a los specs siguientes.
  - `auth.service.spec.ts`: el `afterEach` también limpia `sessionStorage` para no dejar la sesión iniciada.
- **Comportamiento de producción:** no es un bug. Restaurar el turno del mismo usuario desde `sessionStorage` es la funcionalidad buscada (turno persistente al recargar, 30-09-2026).
- **Inventario corregido:** `caja.service.spec.ts` tiene 10 pruebas, no 26; con 10 el total de la tabla da 218.
- **Resultado automático:** `npm test -- --watch=false --reporters=verbose` ejecutado 8 veces seguidas: 8/8 corridas con 23/23 suites y 218/218 pruebas aprobadas, 0 fallos (conteo sobre el árbol de trabajo, que incluía el panel de Inventario aún sin commitear). `npm run build` sin errores ni advertencias.

## Panel de Inventario y ruta `/inventario` (H3.4 T01) — ejecución del 07-10-2026

- Se crea la ruta `/inventario` (admin y bodeguero), que ya aparecía en el menú pero no existía. El bodeguero entra ahí al iniciar sesión, en lugar de `/sin-acceso`.
- El panel usa datos de ejemplo (`InventarioService`) hasta que H3.4 T03 conecte la consulta real; la vista lo indica con la etiqueta "Datos de ejemplo".
- `inventario.spec.ts` (suite nueva, 8 pruebas):
  - Estado de carga con filas de esqueleto, filtros deshabilitados y `aria-busy`.
  - Listado con nombre, tipo, cantidad (formato es-CL, admite negativos), unidad y sucursal.
  - Estado vacío sin existencias.
  - Estado de error con "Reintentar" que vuelve a consultar.
  - Estado sin conexión: indicador "Sin conexión", aviso y datos atenuados pero visibles.
  - Filtros por texto sin tildes, tipo de artículo y sucursal.
  - "Limpiar filtros" cuando ningún artículo coincide.
  - El filtro de sucursal se oculta cuando hay una sola sucursal.
- `auth.guard.spec.ts`: 3 casos nuevos de acceso a `/inventario` (bodeguero y admin permitidos, cajero rechazado).
- `login.component.spec.ts`: las 3 pruebas del bodeguero ahora esperan `/inventario` como destino por defecto.
- `pos-layout.component.spec.ts`: la suite no compilaba en `develop` porque asignaba `isRegisterOpen.set(false)`, que ahora es un `computed`; se reemplazó por `posService.turnoActivo.set(null)`, igual que el resto de la suite.
- Validación en navegador (localhost con sesión de bodeguero simulada, sin llamadas al VPS): carga, listado, error y sin conexión en escritorio; tarjetas en tablet (768 px) y móvil (375 px) sin desplazamiento horizontal.
- **Prueba intermitente detectada (no relacionada con este cambio):** en 1 de 5 ejecuciones fallaron 6 pruebas de `caja.service.spec.ts` (cierres con diferencia de efectivo y boletas) porque el historial de ventas traía ventas de pruebas anteriores. Las otras 4 ejecuciones pasaron 218/218. **Resuelto el 07-10-2026** (ver sección "Intermitencia de `caja.service.spec.ts`").
- Resultado automático: 23/23 suites aprobadas, 218/218 pruebas exitosas. Compilación en modo producción sin errores ni advertencias (`npm run build`).

## Turno de caja persistente al recargar o volver a la URL — ejecución del 30-09-2026

- Problema: con un turno abierto, recargar o volver a entrar a `nury.cl` mantenía la sesión, pero mostraba "Aún no inicias tu turno" y perdía las ventas del turno. El turno solo vivía en memoria (`PosService`), mientras la sesión sí se guardaba en `sessionStorage`.
- `pos.service.spec.ts`: 5 pruebas nuevas (bloque "turno persistente entre recargas").
  - Tras una recarga se conserva la caja abierta con sus ventas, y las fechas vuelven como `Date`.
  - Se conservan también las ventas anuladas del turno.
  - Tras cerrar el turno, una recarga parte con la caja cerrada y sin datos guardados.
  - Un turno abierto no se traspasa a otro usuario en la misma pestaña.
  - Un turno guardado corrupto se descarta sin romper el POS.
- `app.routes.spec.ts` (suite nueva, 2 pruebas): la raíz lleva a `caja` sin turno abierto y a `pos` con turno abierto.
- `payment-modal.component.spec.ts`: ahora limpia `sessionStorage` antes de cada prueba, para que el turno guardado no se filtre entre pruebas.
- Validación en navegador (localhost con sesión de cajero simulada): con el turno iniciado, al recargar `/caja` se muestra "Turno actual · Cerrar turno" en lugar de "Iniciar Turno".
- Resultado automático: 20/20 suites aprobadas, 183/183 pruebas exitosas. Compilación en modo producción sin errores ni advertencias (`npm run build`).

## Loader "taza de café" en el login y el catálogo del POS — ejecución del 29-09-2026

- `coffee-loader.spec.ts` (suite nueva, 7 pruebas):
  - No se muestra si la vista ya está cargada, ni si la carga termina antes de 200 ms (sin destello).
  - Si apareció, se mantiene al menos 900 ms, luego hace el soplido (`blowing`) y desaparece al cabo de 1 s.
  - Dibuja la estela de vapor (trazado SVG cerrado) mientras está visible.
  - Avisa "La conexión está lenta" a los 6 s de carga.
  - En error muestra el mensaje con `role="alert"` y el botón "Reintentar" (emite `retry`); al reintentar la taza sigue en pantalla.
  - Con `showDelay = 0` aparece de inmediato como capa de pantalla completa.
- `app-loader.service.spec.ts` (suite nueva, 5 pruebas):
  - Sin sesión en curso está listo y las vistas usan su propio loader (`join` devuelve `false`).
  - Tras iniciar sesión sigue cargando hasta que termina la navegación y cada vista sumada está lista; después se cierra y una recarga posterior no lo reabre.
  - Termina apenas navega si la vista no carga nada más.
  - Si una vista falla informa error y reintenta solo esa vista; si falla la navegación, la reintenta.
- `login.component.spec.ts`: tras un login exitoso la entrada a la app queda cubierta por la taza a pantalla completa.
- `app.spec.ts`: la taza de pantalla completa no aparece hasta que se inicia una sesión.
- `pos.service.spec.ts`: el estado de carga del catálogo pasa a `ready` al recibir productos y a `error` si la API falla.
- `pos-layout.component.spec.ts`: 3 pruebas nuevas.
  - Un catálogo ya cargado no se cubre con la taza.
  - Si el catálogo falla, la taza sobre el catálogo muestra el error, se oculta el aviso de "sin productos" y "Reintentar" vuelve a pedir el catálogo.
  - Recién iniciada la sesión, el POS se suma a la taza de pantalla completa en vez de mostrar la suya.
- Resultado automático: 17/17 suites aprobadas, 143/143 pruebas exitosas. Compilación en modo producción sin errores ni advertencias (`npm run build`).

## Ventas: listado por sucursal en `VentasApiService` — ejecución del 01-10-2026

- **Rama:** `Patricio2_branch`
- `ventas-api.service.spec.ts` (suite nueva, 8 pruebas):
  - `listar` con una sucursal usa `sucursal_id=eq.N`, orden `fecha_venta.desc,id.desc` y no depende del turno abierto.
  - Con varias sucursales (admin multi-sucursal) usa `in.(1,2,3)` y elimina duplicados.
  - Sin sucursales no hace ninguna petición y devuelve `[]`, para no exponer ventas de otras sucursales.
  - `soloVigentes` agrega `anulada=eq.false`.
  - Rango de fechas inclusivo: `gte.<desde>T00:00:00` y `lt.<día siguiente>T00:00:00`, incluido el cambio de año.
  - `anular` sigue siendo un `PATCH` con `anulada=eq.false`, envía el motivo y falla si la venta no existe o ya estaba anulada.
- Alcance: solo el servicio; ninguna pantalla lo usa todavía. La lectura se verificó a mano con `GET /ventas` (200) contra `api.nury.cl` con sesión de admin.
- Pendiente de confirmar en el servidor: columna `anulada_motivo` (no apareció en `select=*`) y permiso de lectura de `ventas` para el rol cajero.
- Resultado automático (solo servicio): 21/21 suites aprobadas, 195/195 pruebas exitosas. Compilación en modo producción sin errores ni advertencias (`npm run build`).

### Pantalla de anulación conectada a `listar` — 01-10-2026

- `listar` recibe `desde`/`hasta` como instantes (el servidor guarda `fecha_venta` en UTC, así el filtro "hoy" no se corta de noche) y `incluirDetalle` para traer productos con `detalle_venta(...productos(nombre))`.
- `anulacion-venta.spec.ts` (suite nueva, 9 pruebas; las 3 últimas se detallan más abajo): carga el historial de la sucursal del usuario sin turno abierto; sin sucursal no consulta; error de carga visible; motivo de mínimo 5 caracteres antes de anular; anular envía el motivo, marca la fila y sincroniza el turno local; si anular falla, la venta sigue vigente y se muestra el error.
- `pos.service.spec.ts`: `sincronizarAnulacion` descuenta del turno una venta anulada desde otra pantalla e ignora ventas de otros turnos.
- Filtro por cajero (lista y tarjetas de totales; se combina con la búsqueda de texto; incluye "Sin cajero"): +1 prueba. El error de anulación muestra la respuesta del servidor (`El servidor rechazó la anulación (error 400): ...`): +1 prueba.
- Filtro por estado con botones **Todas / Vigentes / Anuladas** (`aria-pressed`; se combina con el filtro por cajero y la búsqueda; las tarjetas de totales no cambian con el estado): +1 prueba que recorre los tres botones, los combina con el cajero y verifica el mensaje "No hay ventas que coincidan con los filtros." cuando no hay resultados.
- Resultado automático (reejecutado el 01-10-2026, 18:54): 22/22 suites aprobadas, 205/205 pruebas exitosas. `npm run build` sin errores ni advertencias. Los avisos de *sourcemap* de `@zxing/browser` que imprime Vitest vienen de `node_modules` y no son del proyecto.
- Verificación visual en navegador (01-10-2026, sesión de admin iniciada por Patricio, `api.nury.cl`, sucursal 1, 11 ventas del día): **Todas** muestra TK-4 a TK-14; **Anuladas** muestra solo TK-8; **Vigentes** muestra las otras 10. Solo un botón queda con `aria-pressed="true"` y las tarjetas no cambian (10 vigentes, $72.300, 1 anulada). Solo se filtró; no se anuló ni se registró nada.
- Ícono de pestaña: se reemplazó el `favicon.ico` de Angular por uno propio elegido por Patricio: taza con barras de crecimiento, sin fondo ni vapor, taza y plato verde `#344337`, barras y café dorado `#c0935f`. En modo oscuro el SVG cambia la taza y el plato a crema `#f5f1e5` (`prefers-color-scheme`) para que no se pierda en pestañas oscuras. Son `public/favicon.svg` y `public/favicon.ico` (16/32/48 px, versión clara generada desde el mismo SVG) y se enlazaron en `src/index.html`. Se revisó a 16 px en pestaña clara y oscura. Ambos responden 200 en `ng serve` y se copian a `dist/`; `npm run build` sin errores ni advertencias. No requiere pruebas unitarias.
- **Intermitencia previa:** `caja.service.spec.ts` (6 pruebas) falla en algunas corridas con `salesHistory` con más ventas de las esperadas (estado compartido, usa el `AuthService` real y el `sessionStorage` del turno). También ocurre sobre el árbol sin estos cambios (1 de 4 corridas). No se atribuye a este cambio. **Resuelto el 07-10-2026** (ver sección "Intermitencia de `caja.service.spec.ts`").
- Revisión manual en navegador contra `api.nury.cl` (sesión de admin, sucursal 1): el historial muestra las 9 ventas del día con cajero y productos; filtro por cajero, búsqueda, rango de fechas y modal verificados. La primera anulación de TK-8 falló: el servidor respondía `42703 column ventas.anulada_motivo does not exist` (migración `0002_add_anulada_motivo_to_ventas.sql` sin aplicar en `api.nury.cl`). Tras crear la columna (`ALTER TABLE ventas ADD COLUMN IF NOT EXISTS anulada_motivo TEXT` + `NOTIFY pgrst, 'reload schema'`, ejecutado por Patricio en pgAdmin el 01-10-2026), **TK-8 se anuló con motivo "prueba"**: la API guarda `anulada=true`, `anulada_motivo='prueba'`, `anulada_por=1` (la sesión era de Nelson) y `anulada_en`; la pantalla la marca "Anulada", descuenta el total vigente ($68.400 → $65.400) y persiste al recargar.

## POS: comanda en modal móvil y categorías unificadas — ejecución del 29-09-2026

- `pos.service.spec.ts`: nueva prueba que verifica que las categorías con la misma palabra inicial se unifican en una sola pestaña (`ALIMENTOS - EMPANADAS` + `ALIMENTOS - SANDWICH` → `ALIMENTOS`; `Empanada Pino` + `EMPANADAS QUESO` → `Empanada`), ignorando mayúsculas, tildes y plural simple, y que las categorías sin palabra compartida conservan su nombre sin segmentos repetidos (`HELADOS - HELADOS` → `HELADOS`).
- `pos-layout.component.spec.ts`: 3 pruebas nuevas.
  - El filtro y el contador de la pestaña unificada incluyen todas sus subcategorías, y la búsqueda de texto encuentra productos por su subcategoría original.
  - El botón flotante del carrito abre la comanda como modal (`role="dialog"`) y el fondo la cierra.
  - "Continuar al pago" cierra el modal de la comanda y abre el modal de pago.
- Resultado automático: 14/14 suites aprobadas, 119/119 pruebas exitosas. Compilación en modo producción sin errores ni advertencias (`npm run build`).

## POS: íconos de producto por categoría — ejecución del 29-09-2026

- `pos-icons.spec.ts` (suite nueva, 4 pruebas):
  - Cada una de las categorías reales del catálogo recibe su ícono específico (empanada, chaparrita con ícono propio, handroll, sándwich, completo, pizza, café, lata, chicle, galleta, helado, lápiz, etc.).
  - Respaldo en orden: nombre del producto → familia (`ALIMENTOS`, `BEBESTIBLES`, `GOLOSINAS`, `HELADOS`) → bolsa genérica.
  - Alimentos, golosinas y helados nunca usan el ícono de vaso con bombilla.
  - Una clave de ícono desconocida usa la bolsa genérica.
- `pos.service.spec.ts`: el producto cargado desde la API recibe el ícono de su categoría (`ALIMENTOS - EMPANADAS` → `empanada`).
- `pos-layout.component.spec.ts`: cada tarjeta del catálogo dibuja el ícono asignado a su producto.
- Revisión visual de los 34 íconos en una hoja de muestra.
- Resultado automático: 15/15 suites aprobadas, 125/125 pruebas exitosas. Compilación en modo producción sin errores ni advertencias (`npm run build`).

## Retiro de perfiles demo del Login — ejecución del 25-09-2026

- Se retiró la sección de botones de acceso rápido y perfiles de demostración (`quick-access-section`, `demoAccounts`) de la pantalla de login (`login.component.html`, `login.component.ts`, `login.component.css`).
- Se validó mediante prueba unitaria en `login.component.spec.ts` que los botones y tarjetas de perfil de prueba no se renderizan en el template.
- Se configuró el consumo dinámico de `environment.apiUrl` en las suites de pruebas de autenticación y API para soportar cualquier URL de endpoint sin desacoples.
- Se aseguró el aislamiento de `TestBed` en `barcode-scanner.spec.ts`.
- Resultado automático: 13/13 suites aprobadas, 107/107 pruebas exitosas. Compilación en modo producción sin errores ni advertencias (`npm run build`).

## AuthGuard y sesión — ejecución del 19-09-2026

- Redirección exacta a `/login?returnUrl=%2Fpos` cuando no existe sesión.
- Acceso permitido con sesión válida.
- Bloqueo inmediato después de cerrar sesión.
- Bloqueo y limpieza de una sesión expirada.
- Restauración de sesión vigente desde `sessionStorage`.
- Expiración del TTL de 8 horas sin necesidad de recargar la pestaña.
- Regreso a una ruta interna solicitada después del login.
- Rechazo de `returnUrl` externo y fallback seguro a `/pos`.

## Roles UI por usuario de PostgreSQL — ejecución del 19-09-2026

- El sidebar no fija roles localmente: consume `AuthService.currentUser().rol`, obtenido desde `public.login()` mediante PostgREST.
- Cajero: muestra Home, Punto de venta y Caja.
- Bodeguero: muestra Home, Maestro Productos e Inventario.
- Administrador: muestra todas las opciones disponibles.
- Sin usuario autenticado: no renderiza enlaces dependientes de rol.
- Verificación de integración local: las tres cuentas de desarrollo devolvieron desde PostgreSQL los roles `cajero`, `admin` y `bodeguero` esperados.
- El login envía al bodeguero a `/product-master` y descarta un `returnUrl` al POS, que no está visible para su rol.
- Resultado automático: 5/5 pruebas del sidebar, 8/8 del login y 69/69 pruebas totales aprobadas.
- Validación asistida en navegador integrado: cajero, administrador y bodeguero mostraron sus menús esperados; aprobada por Patricio el 19 de septiembre de 2026.

### Revalidación — 25-09-2026

- `npm test -- --watch=false --reporters=verbose`: 13/13 suites y 107/107 pruebas aprobadas; incluye que bodeguero no ve ni puede abrir `/product-master`.
- `npm run build`: compilación de producción aprobada, sin errores ni advertencias.

## Procedimiento obligatorio

1. Ejecutar `npm test -- --watch=false --reporters=verbose`.
2. Registrar suites, casos nuevos, fecha, rama y resultado real.
3. Ejecutar `npm run build` y registrar errores o advertencias.
4. No marcar una tarea como finalizada hasta completar también su revisión manual cuando corresponda.

## Catálogo POS con categorías reales — 24-09-2026

- **Rama:** `Patricio2_branch`
- **Cambios:** Categorías derivadas del campo `productos.categoria`; filtro por nombre real; “Sin categoría” para valores vacíos.
- **Pruebas:** `npm test -- --watch=false --reporters=verbose` no pudo completar la compilación del bundle. Angular/esbuild reportó `Acceso denegado` al leer directorios del workspace y resolver CSS y dependencias locales. Una primera ejecución también detectó fixtures numéricos; fueron actualizados al nuevo tipo string antes del segundo intento.
- **Resultado:** Sin conteo de pruebas ejecutadas; suite bloqueada antes de su inicio por acceso al filesystem. No registrar como PASS.
- **Build:** `npm run build` también falló antes de compilar por `Acceso denegado` al resolver archivos del workspace y estilos globales; no atribuido a errores de TypeScript del cambio.

## Lector y carga de factura XML (H3.1 T03 y T04) — 16-10-2026

- **Rama:** Nelson_Branch2
- **Cambios:** src/app/features/facturas/ (lector DTE 33, página de carga y previsualización, rutas) y ruta inventario/facturas para admin y bodeguero en pp.routes.ts.
- **Pruebas:** 
px ng test --watch=false --include="src/app/features/facturas/**/*.spec.ts": 2/2 suites y 40/40 pruebas aprobadas (lector: 35; página: 5).
- **Pruebas completas:** 
px ng test --watch=false: 36/36 suites y 427/427 pruebas aprobadas.
- **Build:** 
px ng build: compilación aprobada, sin errores.
- **Pendiente:** revisión visual con sesión iniciada y datos reales (la guía la exige para cambios de interfaz). No registrar T04 como finalizada hasta completarla.
- **Revisión visual (16-10-2026):** navegador integrado con sesión iniciada, a 1440, 1280, 1101, 1100, 768 y 390 px. Factura válida de 17 líneas, tipo 34 y archivo no XML. Correcciones: el cuadro de totales ya no se estira a la altura del cuadro del emisor; el error dice «El archivo … no se puede ingresar». Sin desplazamiento horizontal en móvil (la tabla se desplaza dentro de su contenedor). Foco visible con teclado. Observación ajena a esta pantalla: en móvil el botón flotante del menú tapa el contenido al pasar por encima.
- **Pruebas después de las correcciones:** 2/2 suites y 40/40 pruebas de facturas aprobadas.
## Asociación de líneas con el catálogo (H3.1 T05) — 16-10-2026

- **Rama:** Nelson_Branch2
- **Cambios:** src/app/features/facturas/models/asociacion-lineas.ts y selector por línea en la página de carga (materias primas activas, productos activos sin receta o «No corresponde a inventario»), con contador de líneas pendientes. T04: la tabla indica si los montos son netos o con IVA.
- **Pruebas:** 
px ng test --watch=false: 37/37 suites y 439/439 pruebas aprobadas (facturas: 3 suites, 52 pruebas).
- **Build:** 
px ng build: compilación aprobada, sin errores.
- **Revisión visual:** navegador integrado con sesión y catálogo real (1 materia prima, 355 productos sin receta) a ~800 px: asociar, marcar no inventariable y contador. Se corrigió que el selector perdiera la opción elegida al redibujarse (prueba de regresión agregada) y se juntó el código del proveedor con la descripción para que la columna del catálogo quepa. Pendiente: revisión en móvil (el panel se cerró).- **Buscador por línea (16-10-2026):** campo «Buscar por nombre…» sobre cada selector; filtra materias primas y productos sin importar mayúsculas ni tildes, exige todas las palabras y conserva el artículo ya elegido. 
px ng test --watch=false: 37/37 suites y 446/446 pruebas aprobadas (facturas: 59). 
px ng build: aprobado. Revisión visual pendiente (el panel pidió iniciar sesión de nuevo).- **Revisión visual del buscador y móvil (16-10-2026):** con sesión y catálogo real. «empanada queso» deja 6 productos en la línea 1 sin afectar a las demás; lo elegido se conserva al cambiar la búsqueda. Corregido: «Sin coincidencias» no aparecía si ya había un artículo elegido. Corregido en móvil (390 px): la tabla medía 655 px y el selector quedaba fuera de la vista; ahora, hasta 768 px, cada línea es una tarjeta con etiquetas, sin desplazamiento lateral. En 1280 px sigue siendo tabla. 
px ng test --watch=false: 37/37 suites y 447/447 pruebas aprobadas. 
px ng build: aprobado.
## Menú «Cargar factura» — 17-10-2026

- **Rama:** Nelson_Branch2
- **Cambios:** opción «Cargar factura» en el menú lateral para admin y bodeguero (sidebar.ts, ícono en sidebar.html). La ruta pasa a /facturas/cargar para que el menú no marque «Inventario» al mismo tiempo. Pruebas del menú actualizadas.
- **Pruebas:** 
px ng test --watch=false: 37/37 suites y 447/447 pruebas aprobadas.
- **Build:** 
px ng build: aprobado.- **Revisión visual:** navegador integrado con sesión de administrador. La opción aparece con su ícono y nombre (menú contraído, expandido y móvil a 390 px); al abrirla solo se marca «Cargar factura», no «Inventario».

## Rediseño de «Cargar factura» — 17-10-2026

- **Rama:** Nelson_Branch2
- **Cambios:** la pantalla sigue el estilo del Maestro de productos: encabezado con subtítulo, zona de carga (también acepta arrastrar y soltar), tarjetas de resumen (proveedor, folio, total, líneas por asociar), avisos y errores con ícono, panel de datos del documento y tabla de líneas con cabeceras en mayúsculas. Bajo 1100 px las líneas pasan a tarjetas (dos columnas entre 801 y 1100 px, una en móvil).
- **Pruebas:** 
px ng test --watch=false: 37/37 suites y 448/448 pruebas aprobadas (nueva: arrastrar y soltar).
- **Build:** 
px ng build: aprobado.
- **Revisión visual:** navegador integrado con sesión a 1440, 1280, 1100, ancho del panel (~770) y 390 px; estado vacío, factura válida y tipo 34. Corregido durante la revisión: a 1100 px la descripción quedaba en ~100 px, por eso las tarjetas empiezan en 1100 px.
## Equivalencias y cantidad a ingresar (H3.1 T06) — 17-10-2026

- **Rama:** Nelson_Branch2
- **Base de datos (sin aplicar):** database/migrations/20261017_equivalencias_lineas_xml.sql y su .ENSAYO.sql (termina en ROLLBACK y prueba las reglas con filas de ejemplo). Agrega unidades_por_presentacion y cantidad_ingreso (columna calculada) a acturas_xml_pendientes_lineas, con reglas de equivalencia positiva y solo en líneas con artículo.
- **Pantalla:** cada línea asociada a un artículo pide «Cada presentación trae» con la unidad del catálogo (kg, L… o un) y muestra «Se sumarán X un (cantidad × equivalencia)». Acepta coma decimal y hasta 3 decimales. La línea sigue pendiente hasta tener una equivalencia válida; al cambiar de artículo se pide de nuevo.
- **Pruebas:** 
px ng test --watch=false: 37/37 suites y 472/472 pruebas aprobadas (facturas: 85).
- **Build:** 
px ng build: aprobado.
- **Pendiente:** ensayo y aplicación del SQL en pgAdmin; revisión visual en el navegador (el servidor de desarrollo estaba detenido).- **Revisión visual (17-10-2026):** navegador integrado con sesión y catálogo real. Línea con producto y equivalencia 1: «Se sumarán 16 un (16 × 1)». Línea con la materia prima Queso (en g) y 500,5: «Se sumarán 10.010 g (20 × 500,5)». Línea «No corresponde a inventario»: sin equivalencia. Equivalencia 0: error en terracota y la línea sigue pendiente. El contador baja al completar cada línea. Móvil (390 px) sin desplazamiento lateral. Corregido: faltaba el espacio entre la unidad y el paréntesis («16 un(16 × 1)»). 
px ng test --watch=false: 472/472; 
px ng build: aprobado.
## Permisos y sucursal de ingreso (H3.1 T07) — 17-10-2026

- **Rama:** Nelson_Branch2
- **Regla:** admin ingresa en cualquier sucursal activa; bodeguero solo en la suya (usuarios.sucursal_id) y sin sucursal asignada no puede ingresar; cajero y otros roles no ingresan. Supuesto: «resto de roles» se leyó como los de inventario (admin y bodeguero), igual que el menú y la ruta.
- **Servidor (sin aplicar):** database/migrations/20261017_permisos_ingreso_facturas.sql y su .ENSAYO.sql (termina en ROLLBACK; 18 pruebas con admin, bodeguero con y sin sucursal, cajero y un JWT que no corresponde al usuario). Agrega n_actor_ingreso(), n_validar_sucursal_ingreso(), un disparador que valida la sucursal y fija cargado_por, y RLS en las dos tablas de pendientes.
- **Pantalla:** panel «Sucursal que recibirá el stock» (el admin elige; el bodeguero ve la suya fija) y «Sucursal de destino» en los datos del documento. Sin permiso, no se muestra la zona de carga.
- **Pruebas:** 
px ng test --watch=false: 38/38 suites y 492/492 pruebas aprobadas (facturas: 105). 
px ng build: aprobado.
- **Pendiente:** ensayo y aplicación del SQL en pgAdmin; revisión visual en el navegador.- **Revisión visual (17-10-2026):** navegador integrado con sesión de administrador con sucursal propia. El selector lista las 9 sucursales activas reales y deja preseleccionada la del usuario. Al cargar una factura, «Sucursal de destino» encabeza los datos del documento y cambia al instante al elegir otra (probado con Vitacura). Sin elegir: borde terracota, «Elige la sucursal antes de confirmar la factura.» y «Sin elegir» en los datos. Móvil (390 px) sin desplazamiento lateral. **No probado en el navegador:** las vistas de bodeguero con sucursal, sin sucursal y de cajero, porque requieren iniciar sesión con esos roles; sí tienen pruebas automáticas.
## Confirmación transaccional e identidad única (H3.1 T08 y H3.7 T02) — 17-10-2026

- **Rama:** Nelson_Branch2
- **Servidor (sin aplicar):** database/migrations/20261017_ingresar_factura_xml.sql y su .ENSAYO.sql. Agrega a acturas_compra el origen y la identidad (RUT emisor normalizado + tipo + folio) con restricción única; las facturas manuales quedan fuera (NULL). n_ingresar_factura_xml vuelve a leer el XML en el servidor, valida permiso, sucursal, duplicados, totales y cada línea, y en una transacción crea la factura, el respaldo con el XML original y el detalle de compra (el stock lo suma n_aplicar_compra). Costo = monto neto ÷ cantidad a ingresar; el redondeo de precio_unitario (2 decimales) queda en descuento_monto para que el detalle sume exacto.
- **Prueba de los SQL en una base PostgreSQL 18 temporal** (esquema del repositorio + migraciones, borrada al terminar): ensayo T06 4/4, ensayo T07 18/18, ensayo T08 30/30 con el motivo de cada rechazo a la vista; el script de T08 se aplicó dos veces sin error. También se ingresó el XML real de ejemplo (17 líneas): el detalle suma exactamente el neto (.373) y todo se revirtió.
- **Corregido en los ensayos:** pgAdmin solo muestra la última instrucción, así que los resultados ahora salen como avisos; el ensayo de T06 ya no depende de datos existentes.
- **Pantalla:** barra fija «Confirmar ingreso» que dice qué falta; «Confirmando…» y doble clic ignorado; éxito con folio, sucursal y líneas; errores traducidos (ya ingresada, permisos, datos, conexión con «Reintentar»).
- **Pruebas:** 
px ng test --watch=false: 40/40 suites y 515/515 pruebas aprobadas. 
px ng build: aprobado.
- **Revisión visual:** con sesión de administrador, la barra indica las líneas pendientes y se activa al completar. Corregido en móvil: el botón flotante del menú tapaba «Confirmar ingreso». **No se pulsó Confirmar** contra el servidor real (T08 no está aplicado allí).

## Facturas ingresadas con carga en modal y rediseño — 26-10-2026

- **Rama:** Nelson_Branch2
- **Cambios:** «Facturas ingresadas» es la vista principal de Facturas; «Cargar factura» abre la carga en un modal (sin cierre al hacer clic fuera ni mientras se confirma). Cada factura pasa a una tarjeta compacta: proveedor, folio, RUT y emisión; sucursal, quién y cuándo, y líneas al stock; total a la derecha. Neto, IVA y archivo quedan en «Ver detalle». El modal es angosto sin factura y ancho con la tabla de líneas; su encabezado queda fijo al desplazarse (en el celular, solo el título). La razón social del proveedor ocupa hasta dos líneas.
- **Pruebas:** `npx ng test --watch=false`: 50/50 suites y 690/690 pruebas aprobadas.
- **Build:** `npx ng build`: aprobado.
- **Revisión visual:** navegador integrado con sesión de administrador a 1180, 768 y 375 px: lista, detalle abierto, modal vacío y modal con una factura ficticia de 4 líneas (folio 99999901, cargada en el navegador). **No se confirmó** ningún ingreso.
