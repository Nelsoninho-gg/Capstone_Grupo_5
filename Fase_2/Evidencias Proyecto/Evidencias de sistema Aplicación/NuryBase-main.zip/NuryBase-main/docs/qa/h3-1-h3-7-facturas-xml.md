# Revisión de aceptación: H3.1 Ingreso por factura XML y H3.7 Protección contra duplicados

Fecha: 20 de octubre de 2026. Rama: `Nelson_Branch2`.

Historias: [H3.1](https://trello.com/c/ZpJyd4sL) y [H3.7](https://trello.com/c/5hbY2XYG).
Tareas de prueba: H3.1 T11 (flujo completo) y H3.7 T08 (protección contra duplicados).

## Resultado

Todos los casos que piden las dos tarjetas están cubiertos con pruebas automáticas (pantalla y servidor), salvo los que solo se pueden ver en el navegador con una sesión real. Esos quedan en el recorrido manual del final. H3.1 T10 (panel sin recargar) no se prueba aquí: depende del mecanismo de tiempo real de H3.4.

### H3.1 T11: flujo completo

| Caso de la tarjeta | Evidencia | Resultado |
| --- | --- | --- |
| Factura de mercadería | Ensayo `20261017_ingresar_factura_xml` (A01, B02). Pantalla: «sends the original file, the branch and each line». | Cumple |
| Factura solo de servicios | Ensayo `20261017_ingresar_factura_xml` A02 y V13 (no suma stock). Pantalla: «sends a non-inventory line». | Cumple |
| Factura mixta | Ensayo `20261017_ingresar_factura_xml` A01 (2 líneas a stock y 1 flete). | Cumple |
| Campos opcionales ausentes | Lector: `TpoCodigo` vacío y sin `IndMntBruto` (la factura de ejemplo). Pantalla y servidor: las facturas de prueba no traen vencimiento, forma de pago ni receptor (en la pantalla) y se ingresan. | Cumple |
| XML inválidos | Lector: no XML, dañado, sin DTE, varios documentos, tipo ≠ 33, RUT con DV incorrecto, fecha imposible, totales que no cuadran, líneas sin cantidad, precio o monto, codificación desconocida. Servidor: A08, A09, A10. | Cumple |
| Asociaciones pendientes | Pantalla: «explains why the invoice cannot be confirmed yet», «keeps an associated line pending…». Servidor: A05, A06, A11. | Cumple |
| Conversiones (equivalencias) | `asociacion-lineas.spec.ts`; pantalla: coma decimal, valor inválido, cambio de artículo. Servidor: A12 (más de 3 decimales) y costos por unidad. Ensayo `20261017_equivalencias_lineas_xml`. | Cumple |
| Cancelación sin modificar stock | Pantalla: «returns to the empty state when the invoice is cancelled, without saving anything» (no llama al servidor) y «shows the preview… without saving anything». | Cumple |
| Permisos | `permiso-ingreso.spec.ts`; pantalla: bodeguero con sucursal fija, sin sucursal, cajero. Ensayo `20261017_permisos_ingreso_facturas` (18 pruebas) y B01 (bodeguero en otra sucursal). | Cumple |
| Fallos durante el guardado sin cambios parciales | Servidor: V11 (los ingresos rechazados no dejaron nada). Pantalla: errores de conexión, sesión, permisos y datos con su mensaje. | Cumple |
| Cantidades incorporadas | Servidor: V01–V10 del ensayo de ingreso (stock, kardex y costos). Consulta de ingresos: L03 y L04. | Cumple |

### H3.7 T08: protección contra duplicados

| Caso de la tarjeta | Evidencia | Resultado |
| --- | --- | --- |
| Archivo repetido | Ensayo `20261020_intentos_factura_duplicada` A02. Probado en la app el 20/10 por el responsable. | Cumple |
| Archivo renombrado o con otro contenido | Ensayo de ingreso A04; ensayo de intentos A03 y V04 (otra huella SHA-256). | Cumple |
| Identificadores equivalentes | `database/tests/facturas_xml_duplicados.sql`: RUT con «k» minúscula (T02), con puntos y ceros (T03), folio con ceros a la izquierda (T04). | Cumple |
| Datos incompletos | Consulta `20261020_consultar_factura_ingresada` C07. Lector: RUT, tipo o folio faltantes. Pantalla: «blocks an invoice whose identity is incomplete». | Cumple |
| Mismo folio con distinto emisor | `facturas_xml_duplicados.sql` T05 (se ingresa como otra factura). Consulta C05. | Cumple |
| Mismo folio con distinto tipo | `facturas_xml_duplicados.sql` T06 (se rechaza por el tipo, no como duplicado). Consulta C04. | Cumple |
| Cancelación | Igual que en H3.1 T11: cancelar no llama al servidor. | Cumple |
| Doble clic | Pantalla: «disables the button while confirming and ignores a second click». | Cumple |
| Concurrencia (dos sesiones a la vez) | Prueba con dos conexiones reales en una base temporal (ver abajo). | Cumple |
| Fallos y respuestas perdidas | Pantalla: «shows the existing entry when a retry finds the invoice already entered», «offers a retry after losing the connection». Consulta C09 y V02. | Cumple |
| Intentos desde otra sucursal | Ensayo de intentos A03, B01, B02, C01. | Cumple |

## Evidencia automatizada

**Pantalla (Vitest, 146 pruebas, todas OK el 20/10/2026):**
`src/app/features/facturas/models/lector-dte.spec.ts`, `asociacion-lineas.spec.ts`, `fallo-ingreso.spec.ts`, `permiso-ingreso.spec.ts`, `pages/carga-factura/carga-factura.spec.ts` y `pages/ingresos-factura/ingresos-factura.spec.ts`. La suite completa del proyecto dio 583/583.

**Servidor (ensayos SQL que terminan en ROLLBACK, todos OK):**

| Archivo | Pruebas | Dónde se ejecutó |
| --- | ---: | --- |
| `database/migrations/20261017_equivalencias_lineas_xml.ENSAYO.sql` | 4 | Servidor (17/10) |
| `database/migrations/20261017_permisos_ingreso_facturas.ENSAYO.sql` | 18 | Servidor (17/10) |
| `database/migrations/20261017_ingresar_factura_xml.ENSAYO.sql` | 30 | Servidor (17/10) |
| `database/migrations/20261020_consultar_factura_ingresada.ENSAYO.sql` | 16 | Servidor y base temporal (20/10) |
| `database/migrations/20261020_intentos_factura_duplicada.ENSAYO.sql` | 21 | Servidor y base temporal (20/10) |
| `database/migrations/20261020_consulta_ingresos_factura.ENSAYO.sql` | 19 | Servidor y base temporal (20/10) |
| `database/tests/facturas_xml_duplicados.sql` | 9 | Base temporal (20/10) |

La base temporal es un PostgreSQL 18 local con `database/schema_nury.sql` y las migraciones. Se probó con `nury_admin` como superusuario (como en el servidor) y como rol normal.

**Concurrencia (20/10/2026, base temporal).** Dos conexiones confirmaron la misma factura como admin, una desde cada sucursal:

| Sesión | Inicio | Resultado | Fin |
| --- | --- | --- | --- |
| A | 18:07:15 | Ingresada (factura 21, 1 línea a stock). Mantuvo la transacción abierta 4 s. | 18:07:19 |
| B | 18:07:17 | Esperó el candado de A; al confirmar A, devolvió `{"ya_ingresada": true}`. | 18:07:19 |

Después: 1 factura, 1 línea de compra, 1 intento registrado, 1 movimiento de stock y el stock sumado una sola vez. Esta prueba deja datos, así que no se ejecuta en el servidor.

## Recorrido manual para revisión del equipo

Con sesión de admin y con la de un bodeguero, en `facturas/cargar` y `facturas/ingresos`. Para revisar la base, usa las consultas de solo lectura del final.

| # | Paso | Resultado esperado | Resultado |
| --- | --- | --- | --- |
| 1 | Cargar un XML de mercadería nuevo y asociar todas sus líneas | Previsualización con emisor, folio y totales. «Todo listo» al completar las líneas. || OK |
| 2 | Confirmar | «Factura N ingresada en …». La factura aparece en «Ingresos de facturas» con sus líneas. || OK |
| 3 | Volver a cargar el mismo XML | Aviso rojo «Esta factura ya fue ingresada» con quién, cuándo y dónde. Botón deshabilitado. || OK |
| 4 | Cargar el mismo XML con otro nombre de archivo | El mismo aviso del paso 3. || OK |
| 5 | Cargar un XML que no sea factura 33 (tipo 34) o un archivo que no sea XML | Error que explica el motivo. No se puede confirmar. || OK |
| 6 | Cargar un XML válido y pulsar «Cancelar» | Vuelve a la pantalla vacía. El stock no cambia. || OK |
| 7 | Factura con una línea de servicio marcada «No corresponde a inventario» | Se ingresa y esa línea no suma stock. En «Ingresos de facturas» aparece como excluida. || OK |
| 8 | Como bodeguero: cargar una factura | La sucursal es la suya, fija. En «Ingresos de facturas» solo ve las de su sucursal. || OK |
| 9 | Como cajero | No ve «Cargar factura» ni «Ingresos de facturas» en el menú. || OK |
| 10 | En «Ingresos de facturas»: «Descargar XML» | Baja el archivo original con su nombre. || OK |
| 11 | En «Ingresos de facturas»: la factura de los pasos 3 y 4 | Muestra los intentos repetidos con usuario, sucursal y archivo. || OK |
| 12 | Desconectar la red y confirmar una factura completa | Mensaje de que no se sabe si se ingresó y botón «Reintentar». Al reconectar y reintentar: se ingresa, o avisa que ya estaba ingresada sin sumar stock. || OK |

Ejecutado el 20/10/2026 por el responsable con usuarios admin, bodeguero y cajero, usando los XML ficticios de `pruebas-facturas` (folios 90000004 a 90000008). Los 12 pasos dieron el resultado esperado.

Consultas de verificación (solo lectura):

```sql
-- Últimas facturas ingresadas y sus líneas a stock
SELECT f.id, f.folio, f.sucursal_id, f.origen, count(d.id) AS lineas_a_stock
FROM facturas_compra f
LEFT JOIN detalle_factura_compra d ON d.factura_id = f.id
GROUP BY f.id ORDER BY f.id DESC LIMIT 10;
```

```sql
-- Intentos repetidos registrados
SELECT id, creado_en, usuario_id, sucursal_solicitada_id, folio, factura_compra_id, xml_nombre
FROM intentos_factura_duplicada ORDER BY id DESC LIMIT 10;
```

```sql
-- Stock de materias primas por sucursal
SELECT i.nombre, s.sucursal_id, s.stock_actual
FROM stock_sucursal s JOIN ingredientes i ON i.id = s.ingrediente_id
ORDER BY i.nombre;
```
