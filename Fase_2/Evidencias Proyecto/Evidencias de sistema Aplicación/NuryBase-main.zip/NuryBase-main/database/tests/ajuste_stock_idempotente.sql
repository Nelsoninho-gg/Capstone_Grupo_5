-- H3.6 T06 - Reintentos de fn_ajustar_stock con clave de idempotencia.
-- Ejecutar con el propietario en una base de pruebas con el esquema y las
-- migraciones hasta 0008_ajuste_stock_idempotente.sql.
-- Todo se revierte al terminar.
\set ON_ERROR_STOP on
BEGIN;

CREATE TEMP TABLE caso_t06 (suc INTEGER, harina INTEGER, bebida INTEGER);

DO $$
DECLARE
    c caso_t06%ROWTYPE;
    unidad INTEGER;
BEGIN
    INSERT INTO public.sucursales (nombre) VALUES ('T06 sucursal') RETURNING id INTO c.suc;
    INSERT INTO public.unidades_medida (nombre, abreviatura) VALUES ('T06 unidad', 't06') RETURNING id INTO unidad;
    INSERT INTO public.ingredientes (nombre, unidad_id) VALUES ('T06 harina', unidad) RETURNING id INTO c.harina;
    INSERT INTO public.productos (nombre, precio_venta) VALUES ('T06 bebida', 1000) RETURNING id INTO c.bebida;
    INSERT INTO public.stock_sucursal (ingrediente_id, sucursal_id, stock_actual) VALUES (c.harina, c.suc, 10);
    INSERT INTO public.stock_producto_sucursal (producto_id, sucursal_id, stock_actual) VALUES (c.bebida, c.suc, 5);
    INSERT INTO caso_t06 SELECT c.*;
END;
$$;

DO $$
DECLARE
    c caso_t06%ROWTYPE;
    k1 UUID := 'aaaaaaaa-0000-4000-8000-000000000001';
    k2 UUID := 'aaaaaaaa-0000-4000-8000-000000000002';
    k3 UUID := 'aaaaaaaa-0000-4000-8000-000000000003';
    primero  public.movimientos_stock;
    reintento public.movimientos_stock;
    stock NUMERIC;
BEGIN
    SELECT * INTO c FROM caso_t06;

    -- 1) Un reintento con la misma clave devuelve el mismo movimiento y no descuenta otra vez.
    primero   := public.fn_ajustar_stock(c.suc, -2, 'Merma', c.harina, NULL, k1);
    reintento := public.fn_ajustar_stock(c.suc, -2, 'Merma', c.harina, NULL, k1);
    SELECT stock_actual INTO stock FROM stock_sucursal WHERE ingrediente_id = c.harina AND sucursal_id = c.suc;
    IF stock <> 8 OR reintento.id <> primero.id OR reintento.stock_resultante <> 8 THEN
        RAISE EXCEPTION 'Caso 1: el reintento volvió a aplicar el ajuste (stock %)', stock;
    END IF;
    IF (SELECT count(*) FROM movimientos_stock WHERE clave_idempotencia = k1) <> 1 THEN
        RAISE EXCEPTION 'Caso 1: la clave quedó en más de un movimiento';
    END IF;

    -- 2) Otra clave es otro ajuste.
    PERFORM public.fn_ajustar_stock(c.suc, -2, 'Merma', c.harina, NULL, k2);
    SELECT stock_actual INTO stock FROM stock_sucursal WHERE ingrediente_id = c.harina AND sucursal_id = c.suc;
    IF stock <> 6 THEN
        RAISE EXCEPTION 'Caso 2: se esperaba stock 6 y quedó %', stock;
    END IF;

    -- 3) La misma clave con otros datos se rechaza y no toca el stock.
    BEGIN
        PERFORM public.fn_ajustar_stock(c.suc, -3, 'Merma', c.harina, NULL, k1);
        RAISE EXCEPTION 'Caso 3: se aceptó una clave repetida con otra cantidad';
    EXCEPTION WHEN SQLSTATE '22023' THEN
        NULL;
    END;
    SELECT stock_actual INTO stock FROM stock_sucursal WHERE ingrediente_id = c.harina AND sucursal_id = c.suc;
    IF stock <> 6 THEN
        RAISE EXCEPTION 'Caso 3: el rechazo modificó el stock (%)', stock;
    END IF;

    -- 4) Un aumento de un producto de reventa reintentado tampoco se suma dos veces.
    PERFORM public.fn_ajustar_stock(c.suc, 4, 'Carga inicial', NULL, c.bebida, k3);
    PERFORM public.fn_ajustar_stock(c.suc, 4, 'Carga inicial', NULL, c.bebida, k3);
    SELECT stock_actual INTO stock FROM stock_producto_sucursal WHERE producto_id = c.bebida AND sucursal_id = c.suc;
    IF stock <> 9 THEN
        RAISE EXCEPTION 'Caso 4: se esperaba stock 9 y quedó %', stock;
    END IF;

    -- 5) Sin clave se comporta como antes: cada llamada es un ajuste nuevo.
    PERFORM public.fn_ajustar_stock(c.suc, -1, 'Conteo', c.harina);
    PERFORM public.fn_ajustar_stock(c.suc, -1, 'Conteo', c.harina);
    SELECT stock_actual INTO stock FROM stock_sucursal WHERE ingrediente_id = c.harina AND sucursal_id = c.suc;
    IF stock <> 4 THEN
        RAISE EXCEPTION 'Caso 5: se esperaba stock 4 y quedó %', stock;
    END IF;

    -- 6) Un rechazo (stock insuficiente) no deja la clave usada: corregido, se puede registrar.
    BEGIN
        PERFORM public.fn_ajustar_stock(c.suc, -50, 'Merma', c.harina, NULL, 'aaaaaaaa-0000-4000-8000-000000000004');
        RAISE EXCEPTION 'Caso 6: se aceptó dejar el stock en negativo';
    EXCEPTION WHEN SQLSTATE '23514' THEN
        NULL;
    END;
    IF EXISTS (SELECT 1 FROM movimientos_stock WHERE clave_idempotencia = 'aaaaaaaa-0000-4000-8000-000000000004') THEN
        RAISE EXCEPTION 'Caso 6: el rechazo dejó un movimiento con la clave';
    END IF;

    RAISE NOTICE 'ajuste_stock_idempotente: 6 casos OK';
END;
$$;

ROLLBACK;
