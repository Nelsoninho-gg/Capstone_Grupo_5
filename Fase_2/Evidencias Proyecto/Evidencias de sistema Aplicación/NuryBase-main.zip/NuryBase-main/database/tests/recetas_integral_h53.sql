-- H5.3 T08 - Prueba integral de recetas: creación, edición, permisos, validaciones,
-- productos normales y conservación de ventas anteriores.
-- Cubre también H5.3 T06 (cada venta conserva la versión de receta con que se vendió) y
-- H5.3 T07 (la receta alimenta el consumo de H2.5 y el descuento de H3.2).
-- Base de pruebas con las migraciones de H2.5, H3.2, H3.3 y H5.3 (versiones de receta, unidad
-- base, ingrediente activo, venta idempotente) y los permisos de recetas del VPS.
-- Todo se revierte al terminar.
\set ON_ERROR_STOP on
BEGIN;
DO $$
DECLARE
    suc INTEGER; cajero INTEGER; g INTEGER; kg INTEGER;
    pan INTEGER; queso INTEGER; jamon INTEGER; sandwich INTEGER; bebida INTEGER;
    v1 INTEGER; v2 INTEGER; v3 INTEGER; v4 INTEGER;
    ver_v1 INTEGER; ver_v2 INTEGER; n INTEGER;
BEGIN
    INSERT INTO sucursales (nombre) VALUES ('RI sucursal') RETURNING id INTO suc;
    INSERT INTO usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('RI cajero', 'ri-cajero', 'x', 'cajero', suc) RETURNING id INTO cajero;
    INSERT INTO turnos (usuario_id, sucursal_id, hora_inicio) VALUES (cajero, suc, now());
    INSERT INTO unidades_medida (nombre, abreviatura) VALUES ('RI gramo', 'gri') RETURNING id INTO g;
    INSERT INTO unidades_medida (nombre, abreviatura) VALUES ('RI kilo', 'kri') RETURNING id INTO kg;
    INSERT INTO ingredientes (nombre, unidad_id) VALUES ('RI Pan', g) RETURNING id INTO pan;
    INSERT INTO ingredientes (nombre, unidad_id) VALUES ('RI Queso', g) RETURNING id INTO queso;
    INSERT INTO ingredientes (nombre, unidad_id) VALUES ('RI Jamón', g) RETURNING id INTO jamon;
    INSERT INTO productos (nombre, precio_venta) VALUES ('RI Sandwich', 3000) RETURNING id INTO sandwich;
    INSERT INTO productos (nombre, precio_venta) VALUES ('RI Bebida', 1000) RETURNING id INTO bebida;
    INSERT INTO stock_sucursal (ingrediente_id, sucursal_id, stock_actual) VALUES
        (pan, suc, 100), (queso, suc, 1000), (jamon, suc, 1000);
    INSERT INTO stock_producto_sucursal (producto_id, sucursal_id, stock_actual) VALUES (bebida, suc, 10);

    -- 1) Creación: pan 2 y queso 30 -------------------------------------------------------
    INSERT INTO recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id) VALUES
        (sandwich, pan, 2, g), (sandwich, queso, 30, g);
    SELECT count(*) INTO n FROM recetas WHERE producto_id = sandwich;
    IF n <> 2 THEN RAISE EXCEPTION 'Caso 1: la receta debía tener 2 insumos (tiene %)', n; END IF;

    -- 2) Validaciones al crear o editar -----------------------------------------------------
    BEGIN
        INSERT INTO recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id) VALUES (sandwich, jamon, 0, g);
        RAISE EXCEPTION 'Caso 2: aceptó cantidad 0';
    EXCEPTION WHEN check_violation THEN NULL;
    END;
    BEGIN
        INSERT INTO recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id) VALUES (sandwich, jamon, 20, kg);
        RAISE EXCEPTION 'Caso 2: aceptó una unidad distinta a la del ingrediente';
    EXCEPTION WHEN invalid_parameter_value THEN NULL;
    END;
    BEGIN
        INSERT INTO recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id) VALUES (sandwich, pan, 1, g);
        RAISE EXCEPTION 'Caso 2: aceptó el mismo ingrediente dos veces';
    EXCEPTION WHEN unique_violation THEN NULL;
    END;
    UPDATE ingredientes SET activo = false WHERE id = jamon;
    BEGIN
        INSERT INTO recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id) VALUES (sandwich, jamon, 20, g);
        RAISE EXCEPTION 'Caso 2: aceptó un ingrediente inactivo';
    EXCEPTION WHEN invalid_parameter_value THEN NULL;
    END;
    UPDATE ingredientes SET activo = true WHERE id = jamon;

    -- 3) Venta 1 con la receta original (H5.3 T07: consumo H2.5 + descuento H3.2) -----------
    v1 := fn_registrar_venta_idempotente('a5a5a5a5-0000-4000-8000-000000000001', suc, cajero, 'efectivo',
        '[{"producto":"RI Sandwich","cantidad":1},{"producto":"RI Bebida","cantidad":2}]');
    SELECT receta_version_id INTO ver_v1 FROM detalle_venta WHERE venta_id = v1 AND producto_id = sandwich;
    IF ver_v1 IS NULL THEN RAISE EXCEPTION 'Caso 3: la venta no guardó la versión de la receta'; END IF;
    IF (SELECT stock_actual FROM stock_sucursal WHERE ingrediente_id = pan) <> 98
       OR (SELECT stock_actual FROM stock_sucursal WHERE ingrediente_id = queso) <> 970
       OR (SELECT stock_actual FROM stock_producto_sucursal WHERE producto_id = bebida) <> 8 THEN
        RAISE EXCEPTION 'Caso 3: la venta no descontó según la receta y el stock propio';
    END IF;

    -- 4) Edición: queso 30 → 40 y se agrega jamón 20 --------------------------------------
    UPDATE recetas SET cantidad_necesaria = 40 WHERE producto_id = sandwich AND ingrediente_id = queso;
    INSERT INTO recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id) VALUES (sandwich, jamon, 20, g);
    IF (SELECT count(*) FROM recetas_version WHERE producto_id = sandwich) < 2 THEN
        RAISE EXCEPTION 'Caso 4: editar la receta no creó una versión nueva';
    END IF;

    -- 5) Venta 2 con la receta nueva: solo afecta a ventas futuras (H5.3 T06) ---------------
    v2 := fn_registrar_venta_idempotente('a5a5a5a5-0000-4000-8000-000000000002', suc, cajero, 'efectivo',
        '[{"producto":"RI Sandwich","cantidad":1}]');
    SELECT receta_version_id INTO ver_v2 FROM detalle_venta WHERE venta_id = v2;
    IF ver_v2 = ver_v1 THEN RAISE EXCEPTION 'Caso 5: la venta nueva usó la versión anterior'; END IF;
    IF (SELECT stock_actual FROM stock_sucursal WHERE ingrediente_id = queso) <> 930
       OR (SELECT stock_actual FROM stock_sucursal WHERE ingrediente_id = jamon) <> 980 THEN
        RAISE EXCEPTION 'Caso 5: la venta nueva no descontó con la receta editada';
    END IF;

    -- 6) Conservación de la venta anterior -------------------------------------------------
    -- Sigue apuntando a su versión, con queso 30 y sin jamón.
    IF (SELECT receta_version_id FROM detalle_venta WHERE venta_id = v1 AND producto_id = sandwich) <> ver_v1
       OR (SELECT cantidad_necesaria FROM recetas_version_detalle WHERE version_id = ver_v1 AND ingrediente_id = queso) <> 30
       OR EXISTS (SELECT 1 FROM recetas_version_detalle WHERE version_id = ver_v1 AND ingrediente_id = jamon) THEN
        RAISE EXCEPTION 'Caso 6: la venta anterior perdió su versión de receta';
    END IF;
    -- Su kardex no cambió: 30 de queso, sin jamón.
    IF (SELECT -cantidad FROM movimientos_stock WHERE referencia_tipo = 'venta' AND referencia_id = v1 AND ingrediente_id = queso) <> 30
       OR EXISTS (SELECT 1 FROM movimientos_stock WHERE referencia_tipo = 'venta' AND referencia_id = v1 AND ingrediente_id = jamon) THEN
        RAISE EXCEPTION 'Caso 6: el kardex de la venta anterior cambió';
    END IF;
    -- Anularla devuelve lo que se descontó en su momento (30 de queso), no la receta actual.
    UPDATE ventas SET anulada = true WHERE id = v1;
    PERFORM fn_reponer_stock_anulacion(v1, 'prueba H5.3 T08');
    IF (SELECT stock_actual FROM stock_sucursal WHERE ingrediente_id = queso) <> 960
       OR (SELECT stock_actual FROM stock_sucursal WHERE ingrediente_id = jamon) <> 980 THEN
        RAISE EXCEPTION 'Caso 6: la anulación no devolvió lo de la venta original';
    END IF;
    -- El historial de versiones muestra el cambio.
    SELECT count(*) INTO n FROM fn_versiones_receta(sandwich);
    IF n < 2 THEN RAISE EXCEPTION 'Caso 6: fn_versiones_receta no muestra las versiones'; END IF;

    -- 7) Productos normales -----------------------------------------------------------------
    -- La bebida nunca tuvo receta: descontó su propio stock (caso 3) y no creó versiones.
    IF EXISTS (SELECT 1 FROM recetas_version WHERE producto_id = bebida)
       OR (SELECT receta_version_id FROM detalle_venta WHERE venta_id = v1 AND producto_id = bebida) IS NOT NULL THEN
        RAISE EXCEPTION 'Caso 7: un producto normal quedó con receta';
    END IF;
    -- Si se quitan todos los insumos, el sándwich pasa a stock propio en las ventas futuras.
    DELETE FROM recetas WHERE producto_id = sandwich;
    v3 := fn_registrar_venta_idempotente('a5a5a5a5-0000-4000-8000-000000000003', suc, cajero, 'efectivo',
        '[{"producto":"RI Sandwich","cantidad":1}]');
    IF (SELECT receta_version_id FROM detalle_venta WHERE venta_id = v3) IS NOT NULL
       OR (SELECT stock_actual FROM stock_producto_sucursal WHERE producto_id = sandwich AND sucursal_id = suc) <> -1
       OR (SELECT stock_actual FROM stock_sucursal WHERE ingrediente_id = pan) <> 98 THEN  -- 100 −2 −2 +2 (anulación), sin cambio por esta venta
        RAISE EXCEPTION 'Caso 7: sin insumos debía descontar el stock propio';
    END IF;
    -- La venta 2 (con receta) sigue intacta.
    IF (SELECT receta_version_id FROM detalle_venta WHERE venta_id = v2) <> ver_v2 THEN
        RAISE EXCEPTION 'Caso 7: quitar la receta cambió una venta anterior';
    END IF;

    RAISE NOTICE 'recetas H5.3: creación, validaciones, edición, versiones y productos normales OK';
END $$;

-- 8) Permisos ---------------------------------------------------------------------------
DO $$
DECLARE priv TEXT;
BEGIN
    FOREACH priv IN ARRAY ARRAY['SELECT', 'INSERT', 'UPDATE', 'DELETE'] LOOP
        IF NOT has_table_privilege('nury_admin', 'public.recetas', priv)
           OR has_table_privilege('nury_cajero', 'public.recetas', priv)
           OR has_table_privilege('nury_bodeguero', 'public.recetas', priv) THEN
            RAISE EXCEPTION 'Caso 8: permiso % de recetas incorrecto', priv;
        END IF;
    END LOOP;
    IF NOT has_column_privilege('nury_bodeguero', 'public.recetas', 'producto_id', 'SELECT')
       OR NOT has_function_privilege('nury_admin', 'public.fn_versiones_receta(integer)', 'EXECUTE') THEN
        RAISE EXCEPTION 'Caso 8: permisos de lectura de recetas incorrectos';
    END IF;
    RAISE NOTICE 'recetas_integral_h53: OK';
END $$;
ROLLBACK;
