-- Historial de ajustes para el bodeguero (20261021_historial_ajustes_bodeguero.sql).
\set ON_ERROR_STOP on
BEGIN;
DO $$
BEGIN
    IF NOT has_table_privilege('nury_bodeguero', 'public.movimientos_stock', 'SELECT')
       OR has_table_privilege('nury_bodeguero', 'public.movimientos_stock', 'INSERT,UPDATE,DELETE') THEN
        RAISE EXCEPTION 'El bodeguero debe leer movimientos_stock sin modificarlo directamente';
    END IF;
    IF NOT has_column_privilege('nury_bodeguero', 'public.usuarios', 'nombre', 'SELECT')
       OR has_column_privilege('nury_bodeguero', 'public.usuarios', 'password_hash', 'SELECT')
       OR has_column_privilege('nury_bodeguero', 'public.usuarios', 'identificador_acceso', 'SELECT') THEN
        RAISE EXCEPTION 'El bodeguero debe leer solo id y nombre de usuarios';
    END IF;
END $$;
SET LOCAL ROLE nury_bodeguero;
DO $$
BEGIN
    PERFORM id FROM public.movimientos_stock LIMIT 1;          -- permitido
    PERFORM id, nombre FROM public.usuarios LIMIT 1;           -- permitido
    BEGIN
        PERFORM password_hash FROM public.usuarios LIMIT 1;
        RAISE EXCEPTION 'El bodeguero pudo leer password_hash';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
    RAISE NOTICE 'historial_ajustes_bodeguero: OK';
END $$;
RESET ROLE;
ROLLBACK;
