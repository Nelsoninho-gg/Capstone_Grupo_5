-- H3.2 T06 - fn_version_inventario cambia con cada cambio confirmado de stock o mínimo
-- (20261027_version_inventario.sql). Base de pruebas; todo se revierte.
\set ON_ERROR_STOP on
BEGIN;
DO $$
DECLARE
    suc INTEGER; cajero INTEGER; un INTEGER; pan INTEGER; bebida INTEGER;
    v0 JSONB; v1 JSONB; v2 JSONB; v3 JSONB; v4 JSONB;
    inicio TIMESTAMPTZ; ms NUMERIC;
BEGIN
    INSERT INTO sucursales (nombre) VALUES ('VI2 sucursal') RETURNING id INTO suc;
    INSERT INTO usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('VI2 cajero', 'vi2-cajero', 'x', 'cajero', suc) RETURNING id INTO cajero;
    INSERT INTO turnos (usuario_id, sucursal_id, hora_inicio) VALUES (cajero, suc, now());
    INSERT INTO unidades_medida (nombre, abreviatura) VALUES ('VI2 gramo', 'gvi2') RETURNING id INTO un;
    INSERT INTO ingredientes (nombre, unidad_id) VALUES ('VI2 Pan', un) RETURNING id INTO pan;
    INSERT INTO productos (nombre, precio_venta) VALUES ('VI2 Sandwich', 3000);
    INSERT INTO productos (nombre, precio_venta) VALUES ('VI2 Bebida', 1000) RETURNING id INTO bebida;
    INSERT INTO recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id)
    SELECT id, pan, 2, un FROM productos WHERE nombre = 'VI2 Sandwich';
    INSERT INTO stock_sucursal (ingrediente_id, sucursal_id, stock_actual, stock_minimo) VALUES (pan, suc, 10, 2);
    INSERT INTO stock_producto_sucursal (producto_id, sucursal_id, stock_actual) VALUES (bebida, suc, 5);

    v0 := fn_version_inventario();
    IF v0 <> fn_version_inventario() THEN RAISE EXCEPTION 'Sin cambios, la versión no debe cambiar'; END IF;

    -- Venta de un compuesto: cambia el stock y el kardex.
    PERFORM fn_registrar_venta_idempotente('c2c2c2c2-0000-4000-8000-000000000001', suc, cajero, 'efectivo',
        '[{"producto":"VI2 Sandwich","cantidad":1}]');
    v1 := fn_version_inventario();
    IF v1->>'stock' = v0->>'stock' OR (v1->>'movimientos')::bigint <= (v0->>'movimientos')::bigint THEN
        RAISE EXCEPTION 'La venta no cambió la versión';
    END IF;

    -- Venta de un producto normal.
    PERFORM fn_registrar_venta_idempotente('c2c2c2c2-0000-4000-8000-000000000002', suc, cajero, 'efectivo',
        '[{"producto":"VI2 Bebida","cantidad":1}]');
    v2 := fn_version_inventario();
    IF v2->>'stock' = v1->>'stock' THEN RAISE EXCEPTION 'La venta de reventa no cambió la versión'; END IF;

    -- Cambiar un mínimo (no deja movimiento) también cambia la versión: afecta las alertas.
    UPDATE stock_sucursal SET stock_minimo = 9 WHERE ingrediente_id = pan AND sucursal_id = suc;
    v3 := fn_version_inventario();
    IF v3->>'stock' = v2->>'stock' THEN RAISE EXCEPTION 'El cambio de mínimo no cambió la versión'; END IF;
    IF v3->>'movimientos' <> v2->>'movimientos' THEN RAISE EXCEPTION 'Un mínimo no es un movimiento'; END IF;

    -- Es liviana: muy por debajo de los 2 s del ciclo.
    inicio := clock_timestamp();
    FOR i IN 1..50 LOOP v4 := fn_version_inventario(); END LOOP;
    ms := EXTRACT(EPOCH FROM clock_timestamp() - inicio) * 1000 / 50;
    IF ms > 200 THEN RAISE EXCEPTION 'fn_version_inventario tarda % ms', ms; END IF;
    RAISE NOTICE 'fn_version_inventario: % ms por consulta', round(ms, 2);
END $$;
DO $$
BEGIN
    IF NOT has_function_privilege('nury_bodeguero', 'public.fn_version_inventario()', 'EXECUTE')
       OR NOT has_function_privilege('nury_admin', 'public.fn_version_inventario()', 'EXECUTE')
       OR has_function_privilege('nury_cajero', 'public.fn_version_inventario()', 'EXECUTE') THEN
        RAISE EXCEPTION 'Permisos de fn_version_inventario incorrectos';
    END IF;
    RAISE NOTICE 'version_inventario: OK';
END $$;
ROLLBACK;
