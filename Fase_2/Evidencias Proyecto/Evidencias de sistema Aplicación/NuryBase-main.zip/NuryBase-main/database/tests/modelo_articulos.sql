-- H3.3 T02 - Modelo de artículos (migración 20261021_modelo_articulos.sql).
-- Ejecutar con el propietario en una base de pruebas con el esquema, los roles JWT y las
-- migraciones hasta 20261023_unidad_fija_ingrediente.sql. Todo se revierte al terminar.
\set ON_ERROR_STOP on
BEGIN;

CREATE TEMP TABLE caso (suc INTEGER, kg INTEGER, g INTEGER, cafe INTEGER, harina INTEGER,
                        bebida INTEGER, galleta INTEGER, sandwich INTEGER);
GRANT SELECT ON caso TO nury_bodeguero;

DO $$
DECLARE c caso%ROWTYPE;
BEGIN
    INSERT INTO sucursales (nombre) VALUES ('Artículos sucursal') RETURNING id INTO c.suc;
    INSERT INTO unidades_medida (nombre, abreviatura) VALUES ('Kilo art', 'kga') RETURNING id INTO c.kg;
    INSERT INTO unidades_medida (nombre, abreviatura) VALUES ('Gramo art', 'gra') RETURNING id INTO c.g;
    INSERT INTO ingredientes (nombre, unidad_id) VALUES ('Café art', c.kg) RETURNING id INTO c.cafe;
    INSERT INTO ingredientes (nombre, unidad_id, activo) VALUES ('Harina art', c.kg, FALSE) RETURNING id INTO c.harina;
    INSERT INTO productos (nombre, precio_venta, codigo_barras) VALUES ('Bebida art', 1000, '780000000001') RETURNING id INTO c.bebida;
    INSERT INTO productos (nombre, precio_venta, activo) VALUES ('Galleta art', 500, FALSE) RETURNING id INTO c.galleta;
    INSERT INTO productos (nombre, precio_venta) VALUES ('Sándwich art', 3000) RETURNING id INTO c.sandwich;
    INSERT INTO recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id) VALUES (c.sandwich, c.cafe, 1, c.kg);
    INSERT INTO stock_sucursal (ingrediente_id, sucursal_id, stock_actual, stock_minimo) VALUES (c.cafe, c.suc, 4.25, 2);
    INSERT INTO stock_producto_sucursal (producto_id, sucursal_id, stock_actual) VALUES (c.bebida, c.suc, 12), (c.sandwich, c.suc, 3);
    INSERT INTO caso SELECT c.*;
END $$;

-- 1) Catálogo: materias primas con su unidad y productos normales en "un"; activos e inactivos.
DO $$
DECLARE c caso%ROWTYPE; r RECORD;
BEGIN
    SELECT * INTO c FROM caso;
    SELECT * INTO r FROM v_articulos WHERE tipo = 'materia_prima' AND articulo_id = c.cafe;
    IF r.nombre <> 'Café art' OR r.unidad <> 'kga' OR r.unidad_id <> c.kg OR NOT r.activo THEN
        RAISE EXCEPTION 'Caso 1: materia prima incorrecta: %', row_to_json(r);
    END IF;
    SELECT * INTO r FROM v_articulos WHERE tipo = 'producto' AND articulo_id = c.bebida;
    IF r.unidad <> 'un' OR r.unidad_id IS NOT NULL OR r.codigo_barras <> '780000000001' THEN
        RAISE EXCEPTION 'Caso 1: producto incorrecto: %', row_to_json(r);
    END IF;
    IF (SELECT activo FROM v_articulos WHERE tipo = 'materia_prima' AND articulo_id = c.harina)
       OR (SELECT activo FROM v_articulos WHERE tipo = 'producto' AND articulo_id = c.galleta) THEN
        RAISE EXCEPTION 'Caso 1: los inactivos deben aparecer con activo = false';
    END IF;
END $$;

-- 2) Un producto con receta no es artículo, ni en el catálogo ni en las existencias.
DO $$
DECLARE c caso%ROWTYPE;
BEGIN
    SELECT * INTO c FROM caso;
    IF EXISTS (SELECT 1 FROM v_articulos WHERE tipo = 'producto' AND articulo_id = c.sandwich)
       OR EXISTS (SELECT 1 FROM v_existencias_articulos WHERE tipo = 'producto' AND articulo_id = c.sandwich) THEN
        RAISE EXCEPTION 'Caso 2: el producto con receta aparece como artículo';
    END IF;
END $$;

-- 3) Existencias por sucursal con unidad, stock y mínimo.
DO $$
DECLARE c caso%ROWTYPE; r RECORD;
BEGIN
    SELECT * INTO c FROM caso;
    SELECT * INTO r FROM v_existencias_articulos WHERE tipo = 'materia_prima' AND articulo_id = c.cafe AND sucursal_id = c.suc;
    IF r.stock_actual <> 4.25 OR r.stock_minimo <> 2 OR r.unidad <> 'kga' OR r.sucursal <> 'Artículos sucursal' THEN
        RAISE EXCEPTION 'Caso 3: existencia de materia prima incorrecta: %', row_to_json(r);
    END IF;
    SELECT * INTO r FROM v_existencias_articulos WHERE tipo = 'producto' AND articulo_id = c.bebida AND sucursal_id = c.suc;
    IF r.stock_actual <> 12 OR r.unidad <> 'un' THEN
        RAISE EXCEPTION 'Caso 3: existencia de producto incorrecta: %', row_to_json(r);
    END IF;
END $$;

-- 4) La unidad de una materia prima no cambia, esté o no en uso (criterio de H3.3;
--    desde 20261023_unidad_fija_ingrediente.sql). Los demás datos sí se editan.
DO $$
DECLARE c caso%ROWTYPE;
BEGIN
    SELECT * INTO c FROM caso;
    BEGIN
        UPDATE ingredientes SET unidad_id = c.g WHERE id = c.cafe;
        RAISE EXCEPTION 'Caso 4: se cambió la unidad de una materia prima en uso';
    EXCEPTION WHEN invalid_parameter_value THEN NULL;
    END;
    BEGIN
        UPDATE ingredientes SET unidad_id = c.g WHERE id = c.harina;      -- sin recetas ni stock
        RAISE EXCEPTION 'Caso 4: se cambió la unidad de una materia prima sin uso';
    EXCEPTION WHEN invalid_parameter_value THEN NULL;
    END;
    UPDATE ingredientes SET nombre = 'Café art molido' WHERE id = c.cafe; -- otros cambios siguen permitidos
    IF (SELECT nombre FROM v_articulos WHERE tipo = 'materia_prima' AND articulo_id = c.cafe) <> 'Café art molido' THEN
        RAISE EXCEPTION 'Caso 4: no se pudo editar el nombre';
    END IF;
END $$;

-- 5) Permisos: lectura para admin y bodeguero, no para cajero ni anónimo. El bodeguero
--    ve el catálogo aunque no pueda leer recetas (como en producción).
DO $$
BEGIN
    IF NOT has_table_privilege('nury_admin', 'public.v_articulos', 'SELECT')
       OR NOT has_table_privilege('nury_bodeguero', 'public.v_existencias_articulos', 'SELECT')
       OR has_table_privilege('nury_cajero', 'public.v_articulos', 'SELECT')
       OR has_table_privilege('web_anon', 'public.v_existencias_articulos', 'SELECT') THEN
        RAISE EXCEPTION 'Caso 5: permisos de las vistas incorrectos';
    END IF;
    IF has_any_column_privilege('nury_bodeguero', 'public.recetas', 'SELECT') THEN
        RAISE EXCEPTION 'Caso 5: la prueba supone un bodeguero sin lectura sobre recetas';
    END IF;
END $$;
SET LOCAL ROLE nury_bodeguero;
DO $$
DECLARE c caso%ROWTYPE;
BEGIN
    SELECT * INTO c FROM caso;
    IF NOT EXISTS (SELECT 1 FROM v_articulos WHERE tipo = 'producto' AND articulo_id = c.bebida)
       OR EXISTS (SELECT 1 FROM v_articulos WHERE tipo = 'producto' AND articulo_id = c.sandwich)
       OR (SELECT stock_actual FROM v_existencias_articulos WHERE tipo = 'producto' AND articulo_id = c.bebida) <> 12 THEN
        RAISE EXCEPTION 'Caso 5: el bodeguero no ve el catálogo correcto';
    END IF;
    RAISE NOTICE 'modelo_articulos: 5 casos OK';
END $$;
RESET ROLE;

ROLLBACK;
