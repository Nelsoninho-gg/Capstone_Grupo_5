-- H5.3 T05 - Validaciones de la receta: al menos un ingrediente, materias primas activas,
-- cantidades positivas en unidad base, unidades compatibles y sin duplicados.
-- Base de pruebas con las migraciones hasta 20261027_receta_ingrediente_activo.sql.
-- Todo se revierte al terminar.
\set ON_ERROR_STOP on
BEGIN;
DO $$
DECLARE
    suc INTEGER; cajero INTEGER; kg INTEGER; g INTEGER;
    harina INTEGER; queso INTEGER; pan INTEGER; venta INTEGER;
BEGIN
    INSERT INTO sucursales (nombre) VALUES ('VR sucursal') RETURNING id INTO suc;
    INSERT INTO usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('VR cajero', 'vr-cajero', 'x', 'cajero', suc) RETURNING id INTO cajero;
    INSERT INTO unidades_medida (nombre, abreviatura) VALUES ('VR Kilo', 'vkg') RETURNING id INTO kg;
    INSERT INTO unidades_medida (nombre, abreviatura) VALUES ('VR Gramo', 'vg') RETURNING id INTO g;
    INSERT INTO ingredientes (nombre, unidad_id) VALUES ('VR Harina', kg) RETURNING id INTO harina;
    INSERT INTO ingredientes (nombre, unidad_id, activo) VALUES ('VR Queso', g, false) RETURNING id INTO queso;
    INSERT INTO productos (nombre, precio_venta) VALUES ('VR Pan', 500) RETURNING id INTO pan;

    -- Cantidades positivas: 0 y negativas se rechazan (CHECK cantidad_necesaria > 0).
    BEGIN
        INSERT INTO recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id) VALUES (pan, harina, 0, kg);
        RAISE EXCEPTION 'Aceptó cantidad 0';
    EXCEPTION WHEN check_violation THEN NULL;
    END;
    BEGIN
        INSERT INTO recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id) VALUES (pan, harina, -1, kg);
        RAISE EXCEPTION 'Aceptó cantidad negativa';
    EXCEPTION WHEN check_violation THEN NULL;
    END;

    -- Unidad base / unidades compatibles: otra unidad se rechaza (trg_recetas_unidad_base).
    BEGIN
        INSERT INTO recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id) VALUES (pan, harina, 250, g);
        RAISE EXCEPTION 'Aceptó gramos para un ingrediente en kilos';
    EXCEPTION WHEN invalid_parameter_value THEN NULL;
    END;

    -- Materias primas activas: un ingrediente inactivo se rechaza (trg_recetas_ingrediente_activo).
    BEGIN
        INSERT INTO recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id) VALUES (pan, queso, 30, g);
        RAISE EXCEPTION 'Aceptó un ingrediente inactivo';
    EXCEPTION WHEN invalid_parameter_value THEN NULL;
    END;

    -- Válido.
    INSERT INTO recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id) VALUES (pan, harina, 0.250, kg);

    -- Sin duplicados: el mismo ingrediente dos veces en la receta se rechaza (UNIQUE).
    BEGIN
        INSERT INTO recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id) VALUES (pan, harina, 0.100, kg);
        RAISE EXCEPTION 'Aceptó el mismo ingrediente dos veces';
    EXCEPTION WHEN unique_violation THEN NULL;
    END;

    -- Al menos un ingrediente: un producto tiene receta si y solo si tiene al menos un insumo.
    -- Con su insumo, la venta descuenta la harina (0,250 kg), no stock propio.
    INSERT INTO stock_sucursal (ingrediente_id, sucursal_id, stock_actual) VALUES (harina, suc, 1);
    INSERT INTO ventas (sucursal_id, cajero_id) VALUES (suc, cajero) RETURNING id INTO venta;
    INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_lista, precio_unitario) VALUES (venta, pan, 1, 500, 500);
    IF (SELECT stock_actual FROM stock_sucursal WHERE ingrediente_id = harina AND sucursal_id = suc) <> 0.750
       OR EXISTS (SELECT 1 FROM stock_producto_sucursal WHERE producto_id = pan) THEN
        RAISE EXCEPTION 'Con receta debía descontar el ingrediente';
    END IF;
    -- Sin insumos deja de tener receta: v_articulos lo muestra como producto (stock propio).
    DELETE FROM recetas WHERE producto_id = pan;
    IF NOT EXISTS (SELECT 1 FROM v_articulos WHERE tipo = 'producto' AND articulo_id = pan) THEN
        RAISE EXCEPTION 'Sin insumos debía pasar a producto con stock propio';
    END IF;

    RAISE NOTICE 'validaciones_receta: OK';
END $$;
ROLLBACK;
