-- H3.2 T07 - Prueba integral del descuento de inventario por ventas: productos normales,
-- compuestos, ventas mixtas, sucursales, fallos y reintentos (y anulación una sola vez).
-- La concurrencia real se prueba aparte con database/tests/venta_concurrente.py (varias
-- conexiones a la vez).
-- Base de pruebas con todas las migraciones de H2.5 y H3.2 (hasta 20261027_venta_concurrente).
-- Todo se revierte al terminar.
\set ON_ERROR_STOP on
BEGIN;
DO $$
DECLARE
    a INTEGER; b INTEGER; cajero INTEGER; g INTEGER;
    pan INTEGER; queso INTEGER; bebida INTEGER; sandwich INTEGER; tostada INTEGER;
    k_normal  UUID := 'b3b3b3b3-0000-4000-8000-000000000001';
    k_comp    UUID := 'b3b3b3b3-0000-4000-8000-000000000002';
    k_mixta   UUID := 'b3b3b3b3-0000-4000-8000-000000000003';
    k_falla   UUID := 'b3b3b3b3-0000-4000-8000-000000000004';
    v1 INTEGER; v2 INTEGER; v3 INTEGER; v3b INTEGER; v4 INTEGER;
    ventas_antes INTEGER; movs_antes INTEGER;

    -- stock actual de un ingrediente o producto en una sucursal
    s_pan_a NUMERIC; s_queso_a NUMERIC; s_beb_a NUMERIC; s_pan_b NUMERIC; s_beb_b NUMERIC;
BEGIN
    INSERT INTO sucursales (nombre) VALUES ('DI A') RETURNING id INTO a;
    INSERT INTO sucursales (nombre) VALUES ('DI B') RETURNING id INTO b;
    INSERT INTO usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('DI cajero', 'di-cajero', 'x', 'cajero', a) RETURNING id INTO cajero;
    INSERT INTO turnos (usuario_id, sucursal_id, hora_inicio) VALUES (cajero, a, now());
    INSERT INTO unidades_medida (nombre, abreviatura) VALUES ('DI gramo', 'gdi') RETURNING id INTO g;
    INSERT INTO ingredientes (nombre, unidad_id) VALUES ('DI Pan', g) RETURNING id INTO pan;
    INSERT INTO ingredientes (nombre, unidad_id) VALUES ('DI Queso', g) RETURNING id INTO queso;
    INSERT INTO productos (nombre, precio_venta) VALUES ('DI Bebida', 1000) RETURNING id INTO bebida;
    INSERT INTO productos (nombre, precio_venta) VALUES ('DI Sandwich', 3000) RETURNING id INTO sandwich;
    INSERT INTO productos (nombre, precio_venta) VALUES ('DI Tostada', 2000) RETURNING id INTO tostada;
    -- Compuestos que comparten ingredientes.
    INSERT INTO recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id) VALUES
        (sandwich, pan, 2, g), (sandwich, queso, 30, g), (tostada, pan, 1, g), (tostada, queso, 15, g);
    -- Stock en dos sucursales.
    INSERT INTO stock_sucursal (ingrediente_id, sucursal_id, stock_actual) VALUES
        (pan, a, 100), (queso, a, 1000), (pan, b, 100), (queso, b, 1000);
    INSERT INTO stock_producto_sucursal (producto_id, sucursal_id, stock_actual) VALUES (bebida, a, 10), (bebida, b, 10);

    -- 1) Producto normal: vender 2 bebidas descuenta 2 de su propio stock --------------------
    v1 := fn_registrar_venta_idempotente(k_normal, a, cajero, 'efectivo', '[{"producto":"DI Bebida","cantidad":2}]');
    SELECT stock_actual INTO s_beb_a FROM stock_producto_sucursal WHERE producto_id = bebida AND sucursal_id = a;
    IF s_beb_a <> 8 THEN RAISE EXCEPTION 'Caso 1: la bebida quedó en %, se esperaba 8', s_beb_a; END IF;
    IF EXISTS (SELECT 1 FROM movimientos_stock WHERE referencia_id = v1 AND referencia_tipo = 'venta' AND ingrediente_id IS NOT NULL) THEN
        RAISE EXCEPTION 'Caso 1: un producto normal descontó ingredientes';
    END IF;

    -- 2) Producto compuesto: 3 sándwiches descuentan 6 de pan y 90 de queso -----------------
    v2 := fn_registrar_venta_idempotente(k_comp, a, cajero, 'debito', '[{"producto":"DI Sandwich","cantidad":3}]');
    SELECT stock_actual INTO s_pan_a FROM stock_sucursal WHERE ingrediente_id = pan AND sucursal_id = a;
    SELECT stock_actual INTO s_queso_a FROM stock_sucursal WHERE ingrediente_id = queso AND sucursal_id = a;
    IF s_pan_a <> 94 OR s_queso_a <> 910 THEN
        RAISE EXCEPTION 'Caso 2: pan % y queso %, se esperaban 94 y 910', s_pan_a, s_queso_a;
    END IF;
    IF EXISTS (SELECT 1 FROM stock_producto_sucursal WHERE producto_id = sandwich) THEN
        RAISE EXCEPTION 'Caso 2: un producto compuesto descontó stock propio';
    END IF;

    -- 3) Venta mixta con ingredientes compartidos: 2 sándwiches + 4 tostadas + 1 bebida ------
    v3 := fn_registrar_venta_idempotente(k_mixta, a, cajero, 'efectivo',
        '[{"producto":"DI Sandwich","cantidad":2},{"producto":"DI Tostada","cantidad":4},{"producto":"DI Bebida","cantidad":1}]');
    -- Pan: 2×2 + 4×1 = 8 → 86. Queso: 2×30 + 4×15 = 120 → 790. Bebida → 7.
    SELECT stock_actual INTO s_pan_a FROM stock_sucursal WHERE ingrediente_id = pan AND sucursal_id = a;
    SELECT stock_actual INTO s_queso_a FROM stock_sucursal WHERE ingrediente_id = queso AND sucursal_id = a;
    SELECT stock_actual INTO s_beb_a FROM stock_producto_sucursal WHERE producto_id = bebida AND sucursal_id = a;
    IF s_pan_a <> 86 OR s_queso_a <> 790 OR s_beb_a <> 7 THEN
        RAISE EXCEPTION 'Caso 3: pan %, queso %, bebida %; se esperaban 86, 790 y 7', s_pan_a, s_queso_a, s_beb_a;
    END IF;
    IF (SELECT count(*) FROM movimientos_stock WHERE referencia_tipo = 'venta' AND referencia_id = v3) <> 5 THEN
        RAISE EXCEPTION 'Caso 3: se esperaban 5 movimientos (pan y queso por cada compuesto, y la bebida)';
    END IF;

    -- 4) Sucursales: nada de lo anterior tocó la sucursal B ---------------------------------
    SELECT stock_actual INTO s_pan_b FROM stock_sucursal WHERE ingrediente_id = pan AND sucursal_id = b;
    SELECT stock_actual INTO s_beb_b FROM stock_producto_sucursal WHERE producto_id = bebida AND sucursal_id = b;
    IF s_pan_b <> 100 OR s_beb_b <> 10
       OR EXISTS (SELECT 1 FROM movimientos_stock WHERE referencia_tipo = 'venta' AND referencia_id IN (v1, v2, v3) AND sucursal_id <> a) THEN
        RAISE EXCEPTION 'Caso 4: las ventas de A tocaron la sucursal B';
    END IF;
    -- Sin turno en B, no se puede vender en B.
    BEGIN
        PERFORM fn_registrar_venta_idempotente('b3b3b3b3-0000-4000-8000-000000000009', b, cajero, 'efectivo',
            '[{"producto":"DI Bebida","cantidad":1}]');
        RAISE EXCEPTION 'Caso 4: vendió en una sucursal sin turno';
    EXCEPTION WHEN invalid_authorization_specification THEN NULL;
    END;

    -- 5) Reintento: la misma clave devuelve la misma venta sin descontar otra vez ------------
    SELECT count(*) INTO ventas_antes FROM ventas;
    SELECT count(*) INTO movs_antes FROM movimientos_stock;
    v3b := fn_registrar_venta_idempotente(k_mixta, a, cajero, 'efectivo',
        '[{"producto":"DI Sandwich","cantidad":2},{"producto":"DI Tostada","cantidad":4},{"producto":"DI Bebida","cantidad":1}]');
    IF v3b <> v3 OR (SELECT count(*) FROM ventas) <> ventas_antes OR (SELECT count(*) FROM movimientos_stock) <> movs_antes
       OR (SELECT stock_actual FROM stock_sucursal WHERE ingrediente_id = pan AND sucursal_id = a) <> 86 THEN
        RAISE EXCEPTION 'Caso 5: el reintento duplicó la venta o el descuento';
    END IF;

    -- 6) Fallo a mitad de venta: la primera línea es válida y la segunda no ------------------
    BEGIN
        PERFORM fn_registrar_venta_idempotente(k_falla, a, cajero, 'efectivo',
            '[{"producto":"DI Sandwich","cantidad":1},{"producto":"DI No existe","cantidad":1}]');
        RAISE EXCEPTION 'Caso 6: la venta con un producto inexistente no falló';
    EXCEPTION WHEN raise_exception THEN
        IF SQLERRM LIKE 'Caso 6%' THEN RAISE; END IF;
    END;
    -- Se conservan los valores anteriores: ni venta, ni descuento, ni movimientos, ni clave.
    IF (SELECT count(*) FROM ventas) <> ventas_antes OR (SELECT count(*) FROM movimientos_stock) <> movs_antes
       OR (SELECT stock_actual FROM stock_sucursal WHERE ingrediente_id = pan AND sucursal_id = a) <> 86
       OR EXISTS (SELECT 1 FROM ventas_idempotencia WHERE clave = k_falla) THEN
        RAISE EXCEPTION 'Caso 6: la venta fallida dejó cambios';
    END IF;
    -- La misma clave sirve para reintentar ya corregida.
    v4 := fn_registrar_venta_idempotente(k_falla, a, cajero, 'efectivo', '[{"producto":"DI Sandwich","cantidad":1}]');
    IF (SELECT stock_actual FROM stock_sucursal WHERE ingrediente_id = pan AND sucursal_id = a) <> 84 THEN
        RAISE EXCEPTION 'Caso 6: el reintento corregido no descontó';
    END IF;

    -- 7) Anulación: repone exactamente lo descontado, una sola vez ---------------------------
    UPDATE ventas SET anulada = true WHERE id = v3;
    PERFORM fn_reponer_stock_anulacion(v3, 'prueba H3.2 T07');
    IF (SELECT stock_actual FROM stock_sucursal WHERE ingrediente_id = pan AND sucursal_id = a) <> 92
       OR (SELECT stock_actual FROM stock_sucursal WHERE ingrediente_id = queso AND sucursal_id = a) <> 880
       OR (SELECT stock_actual FROM stock_producto_sucursal WHERE producto_id = bebida AND sucursal_id = a) <> 8 THEN
        RAISE EXCEPTION 'Caso 7: la anulación no repuso lo descontado';
    END IF;
    BEGIN
        PERFORM fn_reponer_stock_anulacion(v3, 'otra vez');
        RAISE EXCEPTION 'Caso 7: se repuso dos veces';
    EXCEPTION WHEN unique_violation THEN NULL;
    END;
    -- Que una venta ya registrada no admita líneas nuevas se prueba en detalle_venta_una_vez.sql,
    -- con dos transacciones reales (acá todo ocurre en una sola).

    -- 8) El kardex cuadra con el stock: saldo inicial + suma de movimientos = stock actual ---
    IF 100 + (SELECT sum(cantidad) FROM movimientos_stock WHERE ingrediente_id = pan AND sucursal_id = a)
       <> (SELECT stock_actual FROM stock_sucursal WHERE ingrediente_id = pan AND sucursal_id = a) THEN
        RAISE EXCEPTION 'Caso 8: el kardex del pan no cuadra con su stock';
    END IF;

    RAISE NOTICE 'descuento_integral_h32: OK';
END $$;
ROLLBACK;
