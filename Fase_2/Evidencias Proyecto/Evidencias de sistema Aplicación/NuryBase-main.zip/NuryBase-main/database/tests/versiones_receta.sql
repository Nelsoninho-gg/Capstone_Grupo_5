-- H2.5 T02 - Versión de receta usada en cada venta (migración 20261020_versiones_receta.sql).
-- Ejecutar con el propietario en una base de pruebas con el esquema, los roles JWT y las
-- migraciones hasta 20261020_versiones_receta.sql. Todo se revierte al terminar.
\set ON_ERROR_STOP on
BEGIN;

CREATE TEMP TABLE caso (suc INTEGER, admin INTEGER, unidad INTEGER, pan INTEGER, queso INTEGER,
                        palta INTEGER, sandwich INTEGER, bebida INTEGER, r_pan INTEGER);

CREATE FUNCTION pg_temp.vender(p_suc INTEGER, p_producto INTEGER, p_cantidad NUMERIC)
RETURNS public.detalle_venta LANGUAGE plpgsql AS $$
DECLARE v_venta INTEGER; v_linea public.detalle_venta;
BEGIN
    INSERT INTO public.ventas (sucursal_id) VALUES (p_suc) RETURNING id INTO v_venta;
    INSERT INTO public.detalle_venta (venta_id, producto_id, cantidad, precio_lista, precio_unitario)
    VALUES (v_venta, p_producto, p_cantidad, 3000, 3000) RETURNING * INTO v_linea;
    RETURN v_linea;
END $$;

CREATE FUNCTION pg_temp.versiones(p_producto INTEGER) RETURNS INTEGER LANGUAGE sql AS $$
    SELECT count(*)::int FROM public.recetas_version WHERE producto_id = p_producto
$$;

CREATE FUNCTION pg_temp.stock(p_ing INTEGER, p_suc INTEGER) RETURNS NUMERIC LANGUAGE sql AS $$
    SELECT stock_actual FROM public.stock_sucursal WHERE ingrediente_id = p_ing AND sucursal_id = p_suc
$$;

-- Datos: sándwich con receta (2 pan + 30 queso) y una bebida de reventa.
DO $$
DECLARE c caso%ROWTYPE;
BEGIN
    INSERT INTO sucursales (nombre) VALUES ('Receta sucursal') RETURNING id INTO c.suc;
    INSERT INTO usuarios (nombre, identificador_acceso, password_hash, rol)
        VALUES ('Admin receta', 'admin.receta', 'x', 'admin') RETURNING id INTO c.admin;
    INSERT INTO unidades_medida (nombre, abreviatura) VALUES ('Unidad receta', 'urc') RETURNING id INTO c.unidad;
    INSERT INTO ingredientes (nombre, unidad_id) VALUES ('Pan receta', c.unidad) RETURNING id INTO c.pan;
    INSERT INTO ingredientes (nombre, unidad_id) VALUES ('Queso receta', c.unidad) RETURNING id INTO c.queso;
    INSERT INTO ingredientes (nombre, unidad_id) VALUES ('Palta receta', c.unidad) RETURNING id INTO c.palta;
    INSERT INTO productos (nombre, precio_venta) VALUES ('Sándwich receta', 3000) RETURNING id INTO c.sandwich;
    INSERT INTO productos (nombre, precio_venta) VALUES ('Bebida receta', 1000) RETURNING id INTO c.bebida;
    INSERT INTO stock_sucursal (ingrediente_id, sucursal_id, stock_actual) VALUES
        (c.pan, c.suc, 100), (c.queso, c.suc, 1000), (c.palta, c.suc, 500);
    INSERT INTO stock_producto_sucursal (producto_id, sucursal_id, stock_actual) VALUES (c.bebida, c.suc, 10);

    -- 1) Crear la receta en una sola sentencia deja una sola versión, la 1.
    INSERT INTO recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id)
        VALUES (c.sandwich, c.pan, 2, c.unidad), (c.sandwich, c.queso, 30, c.unidad);
    SELECT id INTO c.r_pan FROM recetas WHERE producto_id = c.sandwich AND ingrediente_id = c.pan;
    IF pg_temp.versiones(c.sandwich) <> 1
       OR (SELECT count(*) FROM recetas_version_detalle d JOIN recetas_version v ON v.id = d.version_id
            WHERE v.producto_id = c.sandwich AND v.numero = 1) <> 2 THEN
        RAISE EXCEPTION 'Caso 1: se esperaba una versión 1 con 2 insumos';
    END IF;
    INSERT INTO caso SELECT c.*;
END $$;

-- 2) La venta guarda la versión vigente y descuenta sus ingredientes.
DO $$
DECLARE c caso%ROWTYPE; v_linea detalle_venta;
BEGIN
    SELECT * INTO c FROM caso;
    v_linea := pg_temp.vender(c.suc, c.sandwich, 2);
    IF v_linea.receta_version_id IS DISTINCT FROM
       (SELECT id FROM recetas_version WHERE producto_id = c.sandwich AND numero = 1) THEN
        RAISE EXCEPTION 'Caso 2: la línea no guardó la versión 1 (%)', v_linea.receta_version_id;
    END IF;
    IF pg_temp.stock(c.pan, c.suc) <> 96 OR pg_temp.stock(c.queso, c.suc) <> 940 THEN
        RAISE EXCEPTION 'Caso 2: descuento incorrecto (pan %, queso %)', pg_temp.stock(c.pan, c.suc), pg_temp.stock(c.queso, c.suc);
    END IF;
END $$;

-- 3) Editar la receta (con sesión de admin) crea la versión 2; un cambio que la deja igual, no.
SELECT set_config('request.jwt.claims',
    json_build_object('role', 'nury_admin', 'user_id', (SELECT admin FROM caso))::text, true);
DO $$
DECLARE c caso%ROWTYPE;
BEGIN
    SELECT * INTO c FROM caso;
    UPDATE recetas SET cantidad_necesaria = 3 WHERE id = c.r_pan;
    UPDATE recetas SET cantidad_necesaria = 3 WHERE id = c.r_pan;          -- sin cambio real
    IF pg_temp.versiones(c.sandwich) <> 2 THEN
        RAISE EXCEPTION 'Caso 3: se esperaban 2 versiones, hay %', pg_temp.versiones(c.sandwich);
    END IF;
    IF (SELECT creada_por FROM recetas_version WHERE producto_id = c.sandwich AND numero = 2) <> c.admin
       OR (SELECT creada_por FROM recetas_version WHERE producto_id = c.sandwich AND numero = 1) IS NOT NULL THEN
        RAISE EXCEPTION 'Caso 3: autor de las versiones incorrecto';
    END IF;
END $$;

-- 4) Agregar y quitar insumos crean una versión cada uno; la venta nueva usa la última
--    y la venta anterior conserva la suya (historial).
DO $$
DECLARE c caso%ROWTYPE; v_linea detalle_venta; v_v4 INTEGER;
BEGIN
    SELECT * INTO c FROM caso;
    INSERT INTO recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id) VALUES (c.sandwich, c.palta, 50, c.unidad);
    DELETE FROM recetas WHERE producto_id = c.sandwich AND ingrediente_id = c.queso;
    SELECT id INTO v_v4 FROM recetas_version WHERE producto_id = c.sandwich AND numero = 4;
    IF v_v4 IS NULL OR pg_temp.versiones(c.sandwich) <> 4 THEN
        RAISE EXCEPTION 'Caso 4: se esperaban 4 versiones, hay %', pg_temp.versiones(c.sandwich);
    END IF;
    IF (SELECT array_agg(ingrediente_id ORDER BY ingrediente_id) FROM recetas_version_detalle WHERE version_id = v_v4)
       <> ARRAY[c.pan, c.palta] THEN
        RAISE EXCEPTION 'Caso 4: la versión 4 no tiene pan y palta';
    END IF;

    v_linea := pg_temp.vender(c.suc, c.sandwich, 1);
    IF v_linea.receta_version_id <> v_v4
       OR pg_temp.stock(c.pan, c.suc) <> 93 OR pg_temp.stock(c.palta, c.suc) <> 450
       OR pg_temp.stock(c.queso, c.suc) <> 940 THEN
        RAISE EXCEPTION 'Caso 4: la venta no usó la versión 4 (pan %, palta %, queso %)',
            pg_temp.stock(c.pan, c.suc), pg_temp.stock(c.palta, c.suc), pg_temp.stock(c.queso, c.suc);
    END IF;
    IF (SELECT count(*) FROM detalle_venta d JOIN recetas_version v ON v.id = d.receta_version_id
         WHERE d.producto_id = c.sandwich AND v.numero = 1) <> 1 THEN
        RAISE EXCEPTION 'Caso 4: la primera venta perdió su versión 1';
    END IF;
END $$;

-- 5) Un producto de reventa no lleva versión y descuenta su propio stock.
DO $$
DECLARE c caso%ROWTYPE; v_linea detalle_venta;
BEGIN
    SELECT * INTO c FROM caso;
    v_linea := pg_temp.vender(c.suc, c.bebida, 2);
    IF v_linea.receta_version_id IS NOT NULL
       OR (SELECT stock_actual FROM stock_producto_sucursal WHERE producto_id = c.bebida AND sucursal_id = c.suc) <> 8
       OR pg_temp.versiones(c.bebida) <> 0 THEN
        RAISE EXCEPTION 'Caso 5: la venta de reventa no quedó sin versión';
    END IF;
END $$;

-- 6) Quitar todos los insumos deja una versión vacía: el producto pasa a ser de reventa.
DO $$
DECLARE c caso%ROWTYPE; v_linea detalle_venta;
BEGIN
    SELECT * INTO c FROM caso;
    DELETE FROM recetas WHERE producto_id = c.sandwich;
    IF pg_temp.versiones(c.sandwich) <> 5
       OR EXISTS (SELECT 1 FROM recetas_version_detalle d JOIN recetas_version v ON v.id = d.version_id
                   WHERE v.producto_id = c.sandwich AND v.numero = 5) THEN
        RAISE EXCEPTION 'Caso 6: se esperaba una versión 5 vacía';
    END IF;
    v_linea := pg_temp.vender(c.suc, c.sandwich, 1);
    IF v_linea.receta_version_id IS NOT NULL OR pg_temp.stock(c.pan, c.suc) <> 93
       OR (SELECT stock_actual FROM stock_producto_sucursal WHERE producto_id = c.sandwich AND sucursal_id = c.suc) <> -1 THEN
        RAISE EXCEPTION 'Caso 6: sin receta la venta debía descontar el stock propio';
    END IF;
END $$;

-- 7) La versión la decide la base aunque quien inserta envíe otra.
DO $$
DECLARE c caso%ROWTYPE; v_venta INTEGER; v_version INTEGER;
BEGIN
    SELECT * INTO c FROM caso;
    INSERT INTO ventas (sucursal_id) VALUES (c.suc) RETURNING id INTO v_venta;
    INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_lista, precio_unitario, receta_version_id)
    VALUES (v_venta, c.bebida, 1, 1000, 1000,
            (SELECT id FROM recetas_version WHERE producto_id = c.sandwich AND numero = 1))
    RETURNING receta_version_id INTO v_version;
    IF v_version IS NOT NULL THEN
        RAISE EXCEPTION 'Caso 7: se aceptó una versión enviada por el cliente';
    END IF;
END $$;

-- 8) El historial del Maestro: de la más nueva a la más antigua, con autor e insumos.
DO $$
DECLARE c caso%ROWTYPE; v RECORD;
BEGIN
    SELECT * INTO c FROM caso;
    IF (SELECT array_agg(numero) FROM fn_versiones_receta(c.sandwich)) <> ARRAY[5, 4, 3, 2, 1] THEN
        RAISE EXCEPTION 'Caso 8: orden de versiones incorrecto';
    END IF;
    SELECT * INTO v FROM fn_versiones_receta(c.sandwich) WHERE numero = 2;
    IF v.creada_por <> 'Admin receta' OR v.insumos <> 2 THEN
        RAISE EXCEPTION 'Caso 8: versión 2 incorrecta: %', row_to_json(v);
    END IF;
    SELECT * INTO v FROM fn_versiones_receta(c.sandwich) WHERE numero = 5;
    IF v.insumos <> 0 OR EXISTS (SELECT 1 FROM fn_versiones_receta(c.bebida)) THEN
        RAISE EXCEPTION 'Caso 8: versión vacía o reventa incorrectas';
    END IF;
    -- Qué cambió en cada versión respecto de la anterior.
    IF (SELECT cambios FROM fn_versiones_receta(c.sandwich) WHERE numero = 1) IS NOT NULL THEN
        RAISE EXCEPTION 'Caso 8: la versión 1 no tiene versión anterior con que compararse';
    END IF;
    IF (SELECT cambios FROM fn_versiones_receta(c.sandwich) WHERE numero = 2)
       <> '[{"tipo": "modificado", "ingrediente": "Pan receta", "unidad": "urc", "antes": 2, "despues": 3}]'::jsonb
       OR (SELECT cambios FROM fn_versiones_receta(c.sandwich) WHERE numero = 3)
       <> '[{"tipo": "agregado", "ingrediente": "Palta receta", "unidad": "urc", "antes": null, "despues": 50}]'::jsonb
       OR (SELECT cambios FROM fn_versiones_receta(c.sandwich) WHERE numero = 4)
       <> '[{"tipo": "quitado", "ingrediente": "Queso receta", "unidad": "urc", "antes": 30, "despues": null}]'::jsonb
       OR (SELECT jsonb_array_length(cambios) FROM fn_versiones_receta(c.sandwich) WHERE numero = 5) <> 2 THEN
        RAISE EXCEPTION 'Caso 8: cambios por versión incorrectos: %',
            (SELECT jsonb_agg(jsonb_build_object('v', numero, 'c', cambios)) FROM fn_versiones_receta(c.sandwich));
    END IF;
    IF NOT has_function_privilege('nury_cajero', 'public.fn_versiones_receta(integer)', 'EXECUTE')
       OR has_function_privilege('web_anon', 'public.fn_versiones_receta(integer)', 'EXECUTE') THEN
        RAISE EXCEPTION 'Caso 8: permisos de fn_versiones_receta incorrectos';
    END IF;
    RAISE NOTICE 'versiones_receta: 8 casos OK';
END $$;

ROLLBACK;
