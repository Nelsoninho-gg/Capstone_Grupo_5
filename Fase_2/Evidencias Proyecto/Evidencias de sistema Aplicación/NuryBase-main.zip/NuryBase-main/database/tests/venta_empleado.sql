-- H2.12 T06 — Pruebas de la venta a empleado en la base de datos.
--
-- Requiere las migraciones 0004, 0005, 0006 y 0007 aplicadas.
--
-- Todo corre dentro de un único bloque que termina con un error a propósito,
-- así PostgreSQL deshace todas las ventas, turnos y movimientos de stock de
-- la prueba: no queda nada guardado (solo se consumen números de venta).
--
-- Resultado:
--   - Si todo está bien, el último mensaje es
--     "TODAS LAS PRUEBAS PASARON ... se deshizo todo".
--   - Si algo falla, el mensaje empieza con "FALLO" e indica qué caso.
-- Cada caso aprobado deja una línea NOTICE "OK ..." en la pestaña Messages.

DO $$
DECLARE
    c_pct CONSTANT NUMERIC := 30;
    v_cajero      INTEGER;
    v_sucursal    INTEGER;
    v_empleado    INTEGER;
    v_inactivo    INTEGER;
    p1            RECORD;
    p2            RECORD;
    v             RECORD;
    v_id          INTEGER;
    v_id_anular   INTEGER;
    v_subtotal    NUMERIC;
    v_desc        NUMERIC;
    v_medio       TEXT;
    v_ids         INTEGER[] := '{}';
    v_esperado    NUMERIC := 0;
    v_cuadratura  NUMERIC;
    v_precio_antes NUMERIC;
    v_casos       INTEGER := 0;
BEGIN
    -- Datos de prueba ---------------------------------------------------------
    SELECT usuario_id, sucursal_id INTO v_cajero, v_sucursal
      FROM turnos WHERE hora_fin IS NULL ORDER BY hora_inicio DESC LIMIT 1;
    IF v_cajero IS NULL THEN
        SELECT u.id, s.id INTO v_cajero, v_sucursal
          FROM usuarios u CROSS JOIN sucursales s
         WHERE u.activo ORDER BY u.id, s.id LIMIT 1;
        INSERT INTO turnos (usuario_id, sucursal_id, hora_inicio)
        VALUES (v_cajero, v_sucursal, now());
    END IF;

    SELECT id INTO v_empleado FROM usuarios WHERE activo ORDER BY id LIMIT 1;
    SELECT id INTO v_inactivo FROM usuarios WHERE NOT activo ORDER BY id LIMIT 1;
    SELECT nombre, precio_venta INTO p1 FROM productos WHERE activo ORDER BY id LIMIT 1;
    SELECT nombre, precio_venta INTO p2 FROM productos WHERE activo ORDER BY id OFFSET 1 LIMIT 1;
    v_precio_antes := p1.precio_venta;

    -- 1) Un producto ------------------------------------------------------------
    v_id := fn_registrar_venta(v_sucursal, v_cajero, 'efectivo',
        jsonb_build_array(jsonb_build_object('producto', p1.nombre, 'cantidad', 1)),
        'empleado', v_empleado);
    SELECT * INTO v FROM ventas WHERE id = v_id;
    v_subtotal := p1.precio_venta;
    v_desc := ROUND(v_subtotal * c_pct / 100);
    IF v.tipo_venta <> 'empleado' OR NOT v.venta_especial OR v.empleado_id <> v_empleado
        OR v.descuento_porcentaje <> c_pct OR v.descuento_monto <> v_desc
        OR v.total <> v_subtotal - v_desc THEN
        RAISE EXCEPTION 'FALLO 1 (un producto): descuento % total %, esperado % y %',
            v.descuento_monto, v.total, v_desc, v_subtotal - v_desc;
    END IF;
    v_ids := v_ids || v_id; v_esperado := v_esperado + v.total; v_id_anular := v_id;
    v_casos := v_casos + 1;
    RAISE NOTICE 'OK 1. Un producto: subtotal $%, descuento $%, total $%', v_subtotal, v_desc, v.total;

    -- 2) Varios productos y cantidades ---------------------------------------------
    v_id := fn_registrar_venta(v_sucursal, v_cajero, 'efectivo',
        jsonb_build_array(
            jsonb_build_object('producto', p1.nombre, 'cantidad', 2),
            jsonb_build_object('producto', p2.nombre, 'cantidad', 3)),
        'empleado', v_empleado);
    SELECT * INTO v FROM ventas WHERE id = v_id;
    v_subtotal := p1.precio_venta * 2 + p2.precio_venta * 3;
    v_desc := ROUND(v_subtotal * c_pct / 100);
    IF v.descuento_monto <> v_desc OR v.total <> v_subtotal - v_desc THEN
        RAISE EXCEPTION 'FALLO 2 (varios productos): descuento % total %, esperado % y %',
            v.descuento_monto, v.total, v_desc, v_subtotal - v_desc;
    END IF;
    v_ids := v_ids || v_id; v_esperado := v_esperado + v.total;
    v_casos := v_casos + 1;
    RAISE NOTICE 'OK 2. Varios productos (2 + 3 unidades): subtotal $%, descuento $%, total $%',
        v_subtotal, v_desc, v.total;

    -- 3) Redondeo a pesos (hacia arriba y hacia abajo) ------------------------------
    -- $1.995 × 30% = $598,5 → $599 ; $1.001 × 30% = $300,3 → $300
    v_id := fn_registrar_venta(v_sucursal, v_cajero, 'efectivo',
        jsonb_build_array(jsonb_build_object('producto', p1.nombre, 'cantidad', 1, 'precio_unitario', 1995)),
        'empleado', v_empleado);
    SELECT * INTO v FROM ventas WHERE id = v_id;
    IF v.descuento_monto <> 599 OR v.total <> 1396 THEN
        RAISE EXCEPTION 'FALLO 3a (redondeo 598,5): descuento % total %, esperado 599 y 1396',
            v.descuento_monto, v.total;
    END IF;
    v_ids := v_ids || v_id; v_esperado := v_esperado + v.total;

    v_id := fn_registrar_venta(v_sucursal, v_cajero, 'efectivo',
        jsonb_build_array(jsonb_build_object('producto', p1.nombre, 'cantidad', 1, 'precio_unitario', 1001)),
        'empleado', v_empleado);
    SELECT * INTO v FROM ventas WHERE id = v_id;
    IF v.descuento_monto <> 300 OR v.total <> 701 THEN
        RAISE EXCEPTION 'FALLO 3b (redondeo 300,3): descuento % total %, esperado 300 y 701',
            v.descuento_monto, v.total;
    END IF;
    v_ids := v_ids || v_id; v_esperado := v_esperado + v.total;
    v_casos := v_casos + 1;
    RAISE NOTICE 'OK 3. Redondeo: $598,5 → $599 y $300,3 → $300';

    -- 4) Todos los medios de pago ----------------------------------------------------
    FOREACH v_medio IN ARRAY ARRAY['efectivo', 'debito', 'credito', 'sodexo', 'edenred'] LOOP
        v_id := fn_registrar_venta(v_sucursal, v_cajero, v_medio,
            jsonb_build_array(jsonb_build_object('producto', p1.nombre, 'cantidad', 1)),
            'empleado', v_empleado);
        SELECT * INTO v FROM ventas WHERE id = v_id;
        IF v.medio_pago <> v_medio OR v.descuento_monto <> ROUND(p1.precio_venta * c_pct / 100) THEN
            RAISE EXCEPTION 'FALLO 4 (medio de pago %): medio % descuento %',
                v_medio, v.medio_pago, v.descuento_monto;
        END IF;
        v_ids := v_ids || v_id; v_esperado := v_esperado + v.total;
    END LOOP;
    v_casos := v_casos + 1;
    RAISE NOTICE 'OK 4. Medios de pago: efectivo, débito, crédito, Sodexo y Edenred con el mismo descuento';

    -- 5) Código de venta distinto y venta normal sin cambios ------------------------
    SELECT * INTO v FROM ventas WHERE id = v_ids[1];
    IF v.codigo_venta <> 'EMP-' || v.id THEN
        RAISE EXCEPTION 'FALLO 5a (código empleado): %', v.codigo_venta;
    END IF;
    v_id := fn_registrar_venta(v_sucursal, v_cajero, 'efectivo',
        jsonb_build_array(jsonb_build_object('producto', p1.nombre, 'cantidad', 1)));
    SELECT * INTO v FROM ventas WHERE id = v_id;
    IF v.codigo_venta <> 'TK-' || v.id OR v.tipo_venta <> 'normal' OR v.venta_especial
        OR v.empleado_id IS NOT NULL OR v.descuento_monto <> 0 OR v.total <> p1.precio_venta THEN
        RAISE EXCEPTION 'FALLO 5b (venta normal): código % tipo % descuento % total %',
            v.codigo_venta, v.tipo_venta, v.descuento_monto, v.total;
    END IF;
    v_ids := v_ids || v_id; v_esperado := v_esperado + v.total;
    v_casos := v_casos + 1;
    RAISE NOTICE 'OK 5. Código distinto: EMP-% (empleado) y % (normal, sin descuento)',
        v_ids[1], v.codigo_venta;

    -- 6) Validaciones del servidor ------------------------------------------------
    BEGIN
        PERFORM fn_registrar_venta(v_sucursal, v_cajero, 'efectivo',
            jsonb_build_array(jsonb_build_object('producto', p1.nombre, 'cantidad', 1)), 'empleado', NULL);
        RAISE EXCEPTION 'FALLO 6a: se registró una venta a empleado sin empleado';
    EXCEPTION WHEN OTHERS THEN
        IF SQLERRM NOT LIKE 'Debes indicar el empleado%' THEN RAISE; END IF;
    END;
    BEGIN
        PERFORM fn_registrar_venta(v_sucursal, v_cajero, 'efectivo',
            jsonb_build_array(jsonb_build_object('producto', p1.nombre, 'cantidad', 1)), 'normal', v_empleado);
        RAISE EXCEPTION 'FALLO 6b: se registró una venta normal con empleado';
    EXCEPTION WHEN OTHERS THEN
        IF SQLERRM NOT LIKE 'Una venta normal no lleva empleado%' THEN RAISE; END IF;
    END;
    BEGIN
        PERFORM fn_registrar_venta(v_sucursal, v_cajero, 'efectivo',
            jsonb_build_array(jsonb_build_object('producto', p1.nombre, 'cantidad', 1)), 'vip', v_empleado);
        RAISE EXCEPTION 'FALLO 6c: se aceptó un tipo de venta inválido';
    EXCEPTION WHEN OTHERS THEN
        IF SQLERRM NOT LIKE 'Tipo de venta no válido%' THEN RAISE; END IF;
    END;
    IF v_inactivo IS NOT NULL THEN
        BEGIN
            PERFORM fn_registrar_venta(v_sucursal, v_cajero, 'efectivo',
                jsonb_build_array(jsonb_build_object('producto', p1.nombre, 'cantidad', 1)), 'empleado', v_inactivo);
            RAISE EXCEPTION 'FALLO 6d: se aceptó un empleado deshabilitado';
        EXCEPTION WHEN OTHERS THEN
            IF SQLERRM NOT LIKE 'El empleado no existe o está deshabilitado%' THEN RAISE; END IF;
        END;
    END IF;
    v_casos := v_casos + 1;
    RAISE NOTICE 'OK 6. Validaciones: rechaza sin empleado, normal con empleado, tipo inválido%',
        CASE WHEN v_inactivo IS NULL THEN ' (no hay usuarios deshabilitados para probar ese caso)'
             ELSE ' y empleado deshabilitado' END;

    -- 7) El precio del maestro no cambia --------------------------------------------
    IF (SELECT precio_venta FROM productos WHERE nombre = p1.nombre) <> v_precio_antes THEN
        RAISE EXCEPTION 'FALLO 7: cambió el precio del producto en el maestro';
    END IF;
    v_casos := v_casos + 1;
    RAISE NOTICE 'OK 7. Precio del maestro sin cambios: % sigue en $%', p1.nombre, v_precio_antes;

    -- 8) Anulación: conserva el tipo de venta y el descuento ----------------------
    SELECT * INTO v FROM ventas WHERE id = v_id_anular;
    v_esperado := v_esperado - v.total;  -- deja de contar en la cuadratura
    UPDATE ventas
       SET anulada = TRUE, anulada_en = now(), anulada_por = v_cajero, anulada_motivo = 'Prueba T06'
     WHERE id = v_id_anular AND anulada = FALSE;
    SELECT * INTO v FROM ventas WHERE id = v_id_anular;
    IF NOT v.anulada OR v.tipo_venta <> 'empleado' OR NOT v.venta_especial
        OR v.descuento_monto <> ROUND(p1.precio_venta * c_pct / 100)
        OR v.codigo_venta <> 'EMP-' || v.id THEN
        RAISE EXCEPTION 'FALLO 8 (anulación): tipo % descuento % código %',
            v.tipo_venta, v.descuento_monto, v.codigo_venta;
    END IF;
    v_casos := v_casos + 1;
    RAISE NOTICE 'OK 8. Anulación: % queda anulada y conserva tipo empleado y descuento $%',
        v.codigo_venta, v.descuento_monto;

    -- 9) Cuadratura: suma lo cobrado con descuento y excluye la anulada ---------
    SELECT COALESCE(SUM(total), 0) INTO v_cuadratura
      FROM ventas WHERE id = ANY (v_ids) AND anulada = FALSE;
    IF v_cuadratura <> v_esperado THEN
        RAISE EXCEPTION 'FALLO 9 (cuadratura): suma % esperado %', v_cuadratura, v_esperado;
    END IF;
    v_casos := v_casos + 1;
    RAISE NOTICE 'OK 9. Cuadratura: $% (montos con descuento, sin la venta anulada)', v_cuadratura;

    -- 10) Permisos de la lista de empleados ---------------------------------------
    IF NOT has_function_privilege('nury_cajero', 'public.fn_listar_empleados()', 'EXECUTE')
        OR NOT has_function_privilege('nury_admin', 'public.fn_listar_empleados()', 'EXECUTE')
        OR has_function_privilege('web_anon', 'public.fn_listar_empleados()', 'EXECUTE') THEN
        RAISE EXCEPTION 'FALLO 10: permisos incorrectos en fn_listar_empleados';
    END IF;
    IF EXISTS (SELECT 1 FROM fn_listar_empleados() e JOIN usuarios u ON u.id = e.id WHERE NOT u.activo) THEN
        RAISE EXCEPTION 'FALLO 10: la lista de empleados incluye usuarios deshabilitados';
    END IF;
    v_casos := v_casos + 1;
    RAISE NOTICE 'OK 10. Lista de empleados: solo usuarios activos; cajero y admin pueden verla, sin sesión no';

    RAISE EXCEPTION 'TODAS LAS PRUEBAS PASARON (% de 10). Se deshizo todo: no quedó ninguna venta guardada.',
        v_casos;
END;
$$;
