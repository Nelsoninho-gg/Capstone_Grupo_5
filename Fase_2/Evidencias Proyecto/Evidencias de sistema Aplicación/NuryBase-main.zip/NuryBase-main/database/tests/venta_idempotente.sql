-- H2.5 T05 y T07 - Venta idempotente y descuento de inventario al confirmar la venta.
-- Base de pruebas con el esquema, los roles y las migraciones hasta
-- 20261026_venta_idempotente.sql. Todo se revierte al terminar.
--
-- Casos (T07): cantidades múltiples, ingredientes compartidos, stock insuficiente, fallo de
-- la venta, reintentos con la misma clave y tiempo de actualización del inventario (≤ 2 s).
\set ON_ERROR_STOP on
BEGIN;
DO $$
DECLARE
    suc INTEGER; cajero INTEGER; otro INTEGER; un INTEGER;
    pan INTEGER; queso INTEGER; bebida INTEGER;
    k1 UUID := 'a1a1a1a1-0000-4000-8000-000000000001';
    k2 UUID := 'a1a1a1a1-0000-4000-8000-000000000002';
    k3 UUID := 'a1a1a1a1-0000-4000-8000-000000000003';
    items JSONB;
    v1 INTEGER; v1b INTEGER; v2 INTEGER; v3 INTEGER;
    ventas_antes INTEGER; movs_antes INTEGER; n INTEGER;
    inicio TIMESTAMPTZ; segundos NUMERIC;
BEGIN
    INSERT INTO sucursales (nombre) VALUES ('VI sucursal') RETURNING id INTO suc;
    INSERT INTO usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('VI cajero', 'vi-cajero', 'x', 'cajero', suc) RETURNING id INTO cajero;
    INSERT INTO usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('VI cajero 2', 'vi-cajero-2', 'x', 'cajero', suc) RETURNING id INTO otro;
    INSERT INTO turnos (usuario_id, sucursal_id, hora_inicio) VALUES (cajero, suc, now()), (otro, suc, now());
    INSERT INTO unidades_medida (nombre, abreviatura) VALUES ('VI gramo', 'gvi') RETURNING id INTO un;
    INSERT INTO ingredientes (nombre, unidad_id) VALUES ('VI Pan', un) RETURNING id INTO pan;
    INSERT INTO ingredientes (nombre, unidad_id) VALUES ('VI Queso', un) RETURNING id INTO queso;
    INSERT INTO productos (nombre, precio_venta) VALUES ('VI Sandwich', 3000), ('VI Tostada', 2000);
    INSERT INTO productos (nombre, precio_venta) VALUES ('VI Bebida', 1000) RETURNING id INTO bebida;
    -- Pan y queso los comparten sándwich y tostada; la bebida es de reventa.
    INSERT INTO recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id)
    SELECT p.id, i.id, c.cant, un
      FROM (VALUES ('VI Sandwich', pan, 2), ('VI Sandwich', queso, 30),
                   ('VI Tostada', pan, 1), ('VI Tostada', queso, 15)) c(prod, ing, cant)
      JOIN productos p ON p.nombre = c.prod JOIN ingredientes i ON i.id = c.ing;
    INSERT INTO stock_sucursal (ingrediente_id, sucursal_id, stock_actual) VALUES (pan, suc, 8), (queso, suc, 100);
    INSERT INTO stock_producto_sucursal (producto_id, sucursal_id, stock_actual) VALUES (bebida, suc, 1);

    -- 1) Cantidades múltiples, ingredientes compartidos y stock insuficiente -----------
    items := '[{"producto":"VI Sandwich","cantidad":3},{"producto":"VI Tostada","cantidad":2},
               {"producto":"VI Bebida","cantidad":3}]';
    v1 := fn_registrar_venta_idempotente(k1, suc, cajero, 'efectivo', items);
    -- Pan: 3×2 + 2×1 = 8 (justo). Queso: 3×30 + 2×15 = 120 de 100. Bebida: 3 de 1.
    IF (SELECT stock_actual FROM stock_sucursal WHERE ingrediente_id = pan AND sucursal_id = suc) <> 0
       OR (SELECT stock_actual FROM stock_sucursal WHERE ingrediente_id = queso AND sucursal_id = suc) <> -20
       OR (SELECT stock_actual FROM stock_producto_sucursal WHERE producto_id = bebida AND sucursal_id = suc) <> -2 THEN
        RAISE EXCEPTION 'Caso 1: el descuento no cuadra';
    END IF;
    SELECT count(*) INTO n FROM movimientos_stock WHERE referencia_tipo = 'venta' AND referencia_id = v1;
    IF n <> 5 THEN RAISE EXCEPTION 'Caso 1: se esperaban 5 movimientos (2 pan, 2 queso, 1 bebida), hay %', n; END IF;

    -- 2) Reintento con la misma clave: misma venta, sin volver a descontar -------------
    SELECT count(*) INTO ventas_antes FROM ventas;
    SELECT count(*) INTO movs_antes FROM movimientos_stock;
    v1b := fn_registrar_venta_idempotente(k1, suc, cajero, 'efectivo', items);
    IF v1b <> v1 THEN RAISE EXCEPTION 'Caso 2: el reintento devolvió otra venta (% y %)', v1, v1b; END IF;
    IF (SELECT count(*) FROM ventas) <> ventas_antes OR (SELECT count(*) FROM movimientos_stock) <> movs_antes
       OR (SELECT stock_actual FROM stock_sucursal WHERE ingrediente_id = pan AND sucursal_id = suc) <> 0 THEN
        RAISE EXCEPTION 'Caso 2: el reintento duplicó la venta o el descuento';
    END IF;

    -- 3) Fallo: un producto inexistente no deja venta, descuento ni clave ---------------
    BEGIN
        PERFORM fn_registrar_venta_idempotente(k2, suc, cajero, 'efectivo',
            '[{"producto":"VI Sandwich","cantidad":1},{"producto":"VI No existe","cantidad":1}]');
        RAISE EXCEPTION 'Caso 3: la venta con un producto inexistente no falló';
    EXCEPTION WHEN raise_exception THEN
        IF SQLERRM LIKE 'Caso 3%' THEN RAISE; END IF;
    END;
    IF (SELECT count(*) FROM ventas) <> ventas_antes OR (SELECT count(*) FROM movimientos_stock) <> movs_antes
       OR EXISTS (SELECT 1 FROM ventas_idempotencia WHERE clave = k2) THEN
        RAISE EXCEPTION 'Caso 3: la venta fallida dejó datos';
    END IF;
    -- ...y la misma clave sirve para reintentar ya corregida.
    v2 := fn_registrar_venta_idempotente(k2, suc, cajero, 'efectivo', '[{"producto":"VI Sandwich","cantidad":1}]');
    IF v2 = v1 OR (SELECT stock_actual FROM stock_sucursal WHERE ingrediente_id = pan AND sucursal_id = suc) <> -2 THEN
        RAISE EXCEPTION 'Caso 3: el reintento tras el fallo no registró la venta';
    END IF;

    -- 4) La clave de otro cajero se rechaza ---------------------------------------------
    BEGIN
        PERFORM fn_registrar_venta_idempotente(k1, suc, otro, 'efectivo', items);
        RAISE EXCEPTION 'Caso 4: se aceptó la clave de otro cajero';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;

    -- 5) Sin clave no se registra ------------------------------------------------------
    BEGIN
        PERFORM fn_registrar_venta_idempotente(NULL, suc, cajero, 'efectivo', items);
        RAISE EXCEPTION 'Caso 5: se registró una venta sin clave';
    EXCEPTION WHEN invalid_parameter_value THEN NULL;
    END;

    -- 6) Tiempo: una venta de 20 líneas actualiza el inventario en ≤ 2 s ---------------
    SELECT jsonb_agg(jsonb_build_object('producto', CASE WHEN g % 2 = 0 THEN 'VI Sandwich' ELSE 'VI Tostada' END,
                                        'cantidad', 2))
      INTO items FROM generate_series(1, 20) g;
    inicio := clock_timestamp();
    v3 := fn_registrar_venta_idempotente(k3, suc, cajero, 'efectivo', items);
    segundos := EXTRACT(EPOCH FROM clock_timestamp() - inicio);
    SELECT count(*) INTO n FROM movimientos_stock WHERE referencia_tipo = 'venta' AND referencia_id = v3;
    IF n <> 40 THEN RAISE EXCEPTION 'Caso 6: se esperaban 40 movimientos, hay %', n; END IF;
    IF segundos > 2 THEN RAISE EXCEPTION 'Caso 6: la venta tardó % s (máximo 2 s)', segundos; END IF;
    RAISE NOTICE 'venta de 20 líneas e inventario actualizado en % ms', round(segundos * 1000, 1);
END $$;

DO $$
DECLARE
    firma TEXT := 'public.fn_registrar_venta_idempotente(uuid, integer, integer, character varying, jsonb, character varying, integer)';
BEGIN
    IF NOT has_function_privilege('nury_cajero', firma, 'EXECUTE')
       OR NOT has_function_privilege('nury_admin', firma, 'EXECUTE')
       OR has_function_privilege('nury_bodeguero', firma, 'EXECUTE')
       OR has_table_privilege('nury_cajero', 'public.ventas_idempotencia', 'SELECT') THEN
        RAISE EXCEPTION 'Permisos de la venta idempotente incorrectos';
    END IF;
    RAISE NOTICE 'venta_idempotente: OK';
END $$;
ROLLBACK;
