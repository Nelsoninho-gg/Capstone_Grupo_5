-- H3.4 T09 - Permisos del ajuste de stock (fn_ajustar_stock, migraciones 0005 y 0008).
-- Ejecutar con el propietario en una base de pruebas con el esquema, los roles
-- JWT y las migraciones hasta 0008_ajuste_stock_idempotente.sql. Todo se revierte al terminar.
\set ON_ERROR_STOP on
BEGIN;

CREATE TEMP TABLE caso_permisos (sucursal INTEGER, producto INTEGER);
GRANT SELECT ON caso_permisos TO nury_admin, nury_bodeguero, nury_cajero, web_anon;

DO $$
DECLARE
    v_sucursal INTEGER;
    v_producto INTEGER;
BEGIN
    INSERT INTO public.sucursales (nombre) VALUES ('Permisos ajuste') RETURNING id INTO v_sucursal;
    INSERT INTO public.productos (nombre, precio_venta) VALUES ('Permisos ajuste producto', 1000)
        RETURNING id INTO v_producto;
    INSERT INTO caso_permisos VALUES (v_sucursal, v_producto);
END;
$$;

-- Admin y bodeguero pueden ajustar; cajero y anónimo reciben "permiso denegado".
DO $$
DECLARE
    c caso_permisos%ROWTYPE;
    rol TEXT;
    puede BOOLEAN;
BEGIN
    SELECT * INTO c FROM caso_permisos;
    FOREACH rol IN ARRAY ARRAY['nury_admin', 'nury_bodeguero', 'nury_cajero', 'web_anon'] LOOP
        puede := has_function_privilege(rol, 'public.fn_ajustar_stock(integer,numeric,text,integer,integer,uuid)', 'EXECUTE');
        IF puede <> (rol IN ('nury_admin', 'nury_bodeguero')) THEN
            RAISE EXCEPTION 'Permiso inesperado de % sobre fn_ajustar_stock: %', rol, puede;
        END IF;
    END LOOP;
END;
$$;

SET LOCAL ROLE nury_bodeguero;
SELECT public.fn_ajustar_stock(sucursal, 5, 'Prueba permisos bodeguero', NULL, producto) FROM caso_permisos;
RESET ROLE;

SET LOCAL ROLE nury_cajero;
DO $$
DECLARE c caso_permisos%ROWTYPE;
BEGIN
    SELECT * INTO c FROM caso_permisos;
    BEGIN
        PERFORM public.fn_ajustar_stock(c.sucursal, 5, 'Prueba permisos cajero', NULL, c.producto);
        RAISE EXCEPTION 'nury_cajero pudo ajustar stock';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
END;
$$;
RESET ROLE;

-- Solo quedó el ajuste del bodeguero, en su sucursal.
DO $$
DECLARE c caso_permisos%ROWTYPE;
BEGIN
    SELECT * INTO c FROM caso_permisos;
    IF (SELECT stock_actual FROM public.stock_producto_sucursal
         WHERE producto_id = c.producto AND sucursal_id = c.sucursal) <> 5
    OR (SELECT count(*) FROM public.movimientos_stock
         WHERE producto_id = c.producto AND tipo_movimiento = 'ajuste') <> 1 THEN
        RAISE EXCEPTION 'El resultado de los ajustes no es el esperado';
    END IF;
END;
$$;

\echo 'PASS: admin y bodeguero ajustan stock; cajero y anónimo no pueden.'
ROLLBACK;
