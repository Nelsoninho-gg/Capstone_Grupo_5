-- Permisos del bodeguero sobre materias primas (20261025_catalogo_materias_primas_bodeguero.sql).
\set ON_ERROR_STOP on
BEGIN;
DO $$
BEGIN
    IF NOT has_column_privilege('nury_bodeguero', 'public.ingredientes', 'nombre', 'INSERT')
       OR NOT has_column_privilege('nury_bodeguero', 'public.ingredientes', 'unidad_id', 'INSERT')
       OR NOT has_column_privilege('nury_bodeguero', 'public.ingredientes', 'activo', 'UPDATE')
       OR NOT has_sequence_privilege('nury_bodeguero', 'public.ingredientes_id_seq', 'USAGE') THEN
        RAISE EXCEPTION 'Al bodeguero le faltan permisos para crear o editar materias primas';
    END IF;
    IF has_column_privilege('nury_bodeguero', 'public.ingredientes', 'unidad_id', 'UPDATE')
       OR has_column_privilege('nury_bodeguero', 'public.ingredientes', 'costo_unitario_promedio', 'UPDATE')
       OR has_table_privilege('nury_bodeguero', 'public.ingredientes', 'DELETE')
       OR has_column_privilege('nury_bodeguero', 'public.productos', 'activo', 'UPDATE') THEN
        RAISE EXCEPTION 'El bodeguero tiene más permisos de los necesarios';
    END IF;
END $$;
SET LOCAL ROLE nury_bodeguero;
DO $$
DECLARE
    v_id INTEGER;
BEGIN
    INSERT INTO public.ingredientes (nombre, unidad_id, categoria_id, codigo_barras)
    VALUES ('Prueba bodeguero', (SELECT id FROM public.unidades_medida LIMIT 1), NULL, NULL)
    RETURNING id INTO v_id;
    UPDATE public.ingredientes SET nombre = 'Prueba bodeguero 2', codigo_barras = '999', activo = false
     WHERE id = v_id;
    BEGIN
        UPDATE public.ingredientes SET costo_unitario_promedio = 1 WHERE id = v_id;
        RAISE EXCEPTION 'El bodeguero pudo cambiar el costo promedio';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
    BEGIN
        DELETE FROM public.ingredientes WHERE id = v_id;
        RAISE EXCEPTION 'El bodeguero pudo borrar una materia prima';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
    RAISE NOTICE 'catalogo_materias_primas_bodeguero: OK';
END $$;
RESET ROLE;
ROLLBACK;
