-- H5.3 T03 - Permisos de los servicios de recetas (RecetasApiService).
-- Fija los permisos verificados en producción el 26-10-2026: solo el admin consulta,
-- guarda, edita y quita insumos de recetas. El cajero no toca la tabla recetas
-- (sus ventas descuentan ingredientes a través de fn_registrar_venta, SECURITY DEFINER) y
-- el bodeguero solo sabe qué productos tienen receta (recetas.producto_id).
\set ON_ERROR_STOP on
BEGIN;
DO $$
DECLARE
    priv TEXT;
BEGIN
    FOREACH priv IN ARRAY ARRAY['SELECT', 'INSERT', 'UPDATE', 'DELETE'] LOOP
        IF NOT has_table_privilege('nury_admin', 'public.recetas', priv) THEN
            RAISE EXCEPTION 'El admin no tiene % sobre recetas', priv;
        END IF;
        IF has_table_privilege('nury_cajero', 'public.recetas', priv) THEN
            RAISE EXCEPTION 'El cajero no debe tener % sobre recetas', priv;
        END IF;
        IF has_table_privilege('nury_bodeguero', 'public.recetas', priv) THEN
            RAISE EXCEPTION 'El bodeguero no debe tener % sobre toda la tabla recetas', priv;
        END IF;
    END LOOP;

    IF NOT has_column_privilege('nury_bodeguero', 'public.recetas', 'producto_id', 'SELECT')
       OR has_column_privilege('nury_bodeguero', 'public.recetas', 'cantidad_necesaria', 'SELECT') THEN
        RAISE EXCEPTION 'El bodeguero debe leer solo recetas.producto_id';
    END IF;

    -- Historial de versiones (H2.5 T02): admin y cajero (el cajero entra al Maestro), solo lectura.
    IF NOT has_function_privilege('nury_admin', 'public.fn_versiones_receta(integer)', 'EXECUTE')
       OR has_function_privilege('nury_bodeguero', 'public.fn_versiones_receta(integer)', 'EXECUTE') THEN
        RAISE EXCEPTION 'Las versiones de receta son para admin y cajero, no para el bodeguero';
    END IF;

    IF NOT (SELECT bool_and(prosecdef) FROM pg_proc WHERE proname = 'fn_registrar_venta') THEN
        RAISE EXCEPTION 'fn_registrar_venta debe ser SECURITY DEFINER: el cajero no lee recetas';
    END IF;
    RAISE NOTICE 'permisos_recetas: OK';
END $$;
ROLLBACK;
