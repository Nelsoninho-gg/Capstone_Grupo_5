-- Prueba de restricciones y permisos de stock mínimo para bodeguero.
\set ON_ERROR_STOP on
BEGIN;

DO $$
BEGIN
    -- Verificar privilegios de UPDATE sobre stock_minimo exclusivamente
    IF NOT has_column_privilege('nury_bodeguero', 'public.stock_sucursal', 'stock_minimo', 'UPDATE')
       OR NOT has_column_privilege('nury_bodeguero', 'public.stock_producto_sucursal', 'stock_minimo', 'UPDATE') THEN
        RAISE EXCEPTION 'El bodeguero debe tener UPDATE en stock_minimo';
    END IF;

    -- Verificar que NO tenga UPDATE sobre stock_actual
    IF has_column_privilege('nury_bodeguero', 'public.stock_sucursal', 'stock_actual', 'UPDATE')
       OR has_column_privilege('nury_bodeguero', 'public.stock_producto_sucursal', 'stock_actual', 'UPDATE') THEN
        RAISE EXCEPTION 'El bodeguero no debe poder modificar stock_actual directamente';
    END IF;
END $$;

DO $$
BEGIN
    RAISE NOTICE 'stock_minimo_bodeguero: OK';
END $$;

RESET ROLE;
ROLLBACK;
