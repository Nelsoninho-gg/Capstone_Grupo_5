-- H3.3 T05 - Campos obligatorios y duplicados ignorando mayúsculas y espacios
-- (20261027_nombres_unicos_normalizados.sql). Base de pruebas; todo se revierte.
\set ON_ERROR_STOP on
BEGIN;
DO $$
DECLARE
    un INTEGER; v TEXT; c TEXT;
BEGIN
    INSERT INTO unidades_medida (nombre, abreviatura) VALUES ('NU kilo', 'nkg') RETURNING id INTO un;

    -- Se guarda limpio: sin espacios en los extremos ni repetidos; código sin espacios.
    INSERT INTO ingredientes (nombre, unidad_id, codigo_barras)
    VALUES ('  NU   Harina  000 ', un, ' 780 0001 ') RETURNING nombre, codigo_barras INTO v, c;
    IF v <> 'NU Harina 000' OR c <> '7800001' THEN
        RAISE EXCEPTION 'No limpió el ingrediente: "%" / "%"', v, c;
    END IF;

    -- Duplicado de nombre con otras mayúsculas o espacios: rechazado.
    BEGIN
        INSERT INTO ingredientes (nombre, unidad_id) VALUES ('nu harina   000', un);
        RAISE EXCEPTION 'Aceptó un nombre de ingrediente repetido';
    EXCEPTION WHEN unique_violation THEN NULL;
    END;
    -- Duplicado de código de barras con espacios o minúsculas: rechazado.
    BEGIN
        INSERT INTO ingredientes (nombre, unidad_id, codigo_barras) VALUES ('NU Otra', un, '7800 001');
        RAISE EXCEPTION 'Aceptó un código de ingrediente repetido';
    EXCEPTION WHEN unique_violation THEN NULL;
    END;

    -- Productos: mismo comportamiento.
    INSERT INTO productos (nombre, precio_venta, codigo_barras) VALUES ('NU Coca-Cola 591ml', 1000, 'abc123');
    SELECT codigo_barras INTO c FROM productos WHERE nombre = 'NU Coca-Cola 591ml';
    BEGIN
        INSERT INTO productos (nombre, precio_venta) VALUES ('NU COCA-COLA  591ML ', 1000);
        RAISE EXCEPTION 'Aceptó un nombre de producto repetido';
    EXCEPTION WHEN unique_violation THEN NULL;
    END;
    BEGIN
        INSERT INTO productos (nombre, precio_venta, codigo_barras) VALUES ('NU Pepsi', 1000, 'ABC 123');
        RAISE EXCEPTION 'Aceptó un código de producto repetido (abc123 / ABC 123)';
    EXCEPTION WHEN unique_violation THEN NULL;
    END;

    -- Nombre obligatorio: vacío o solo espacios, rechazado.
    BEGIN
        INSERT INTO ingredientes (nombre, unidad_id) VALUES ('   ', un);
        RAISE EXCEPTION 'Aceptó un ingrediente sin nombre';
    EXCEPTION WHEN invalid_parameter_value THEN NULL;
    END;
    BEGIN
        UPDATE productos SET nombre = '' WHERE nombre = 'NU Coca-Cola 591ml';
        RAISE EXCEPTION 'Aceptó un producto sin nombre';
    EXCEPTION WHEN invalid_parameter_value THEN NULL;
    END;
    -- Código vacío se guarda como NULL (no choca con otros sin código).
    INSERT INTO productos (nombre, precio_venta, codigo_barras) VALUES ('NU Sin código 1', 500, '  ');
    INSERT INTO productos (nombre, precio_venta, codigo_barras) VALUES ('NU Sin código 2', 500, '');
    IF EXISTS (SELECT 1 FROM productos WHERE nombre LIKE 'NU Sin código%' AND codigo_barras IS NOT NULL) THEN
        RAISE EXCEPTION 'El código vacío no quedó en NULL';
    END IF;

    -- Editar el mismo artículo sin cambiar el nombre sigue permitido.
    UPDATE ingredientes SET nombre = 'NU HARINA 000' WHERE nombre = 'NU Harina 000';

    -- La unidad sigue fija (criterio 3, 20261023_unidad_fija_ingrediente.sql).
    BEGIN
        UPDATE ingredientes SET unidad_id = (SELECT id FROM unidades_medida WHERE id <> un LIMIT 1)
         WHERE nombre = 'NU HARINA 000';
        RAISE EXCEPTION 'Se cambió la unidad del ingrediente';
    EXCEPTION WHEN invalid_parameter_value THEN NULL;
    END;

    RAISE NOTICE 'nombres_unicos_normalizados: OK';
END $$;
ROLLBACK;
