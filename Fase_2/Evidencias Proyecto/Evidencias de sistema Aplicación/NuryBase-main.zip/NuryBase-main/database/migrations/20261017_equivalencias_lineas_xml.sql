-- Equivalencias y cantidad a ingresar en las líneas de facturas XML (H3.1 T06).
--
-- Cada línea del XML trae la cantidad en la unidad de compra (bolsas, cajas…).
-- Antes de sumar stock, el usuario confirma cuántas unidades del catálogo trae
-- cada presentación (nunca se deduce del nombre). La base calcula la cantidad a
-- ingresar, separada de la cantidad original del XML.
--
--   cantidad                   QtyItem del XML, tal como vino (ya existía).
--   unidades_por_presentacion  equivalencia confirmada por el usuario. NULL = falta confirmarla.
--   cantidad_ingreso           cantidad × unidades_por_presentacion, en la unidad del catálogo
--                              (unidad del ingrediente, o unidades si es producto).
--
-- Reglas que la base exige (validación en servidor):
--   - la equivalencia, si está, es mayor que cero;
--   - solo hay equivalencia en líneas asociadas a una materia prima o a un producto
--     (no en líneas pendientes ni «No corresponde a inventario»).
-- Que todas las líneas inventariables tengan equivalencia antes de confirmar se
-- comprueba en la función de confirmación (H3.1 T08).
--
-- REQUIERE: 20261016_facturas_xml_pendientes.sql aplicado antes.
--
-- ANTES DE APLICAR EN PRODUCCIÓN:
--   a) Revisar el script completo con el responsable.
--   b) Correr primero 20261017_equivalencias_lineas_xml.ENSAYO.sql (termina en ROLLBACK).
--   c) Después de aplicar: NOTIFY pgrst, 'reload schema';

BEGIN;

ALTER TABLE public.facturas_xml_pendientes_lineas
    ADD COLUMN IF NOT EXISTS unidades_por_presentacion NUMERIC(12,3);

ALTER TABLE public.facturas_xml_pendientes_lineas
    ADD COLUMN IF NOT EXISTS cantidad_ingreso NUMERIC(14,3)
        GENERATED ALWAYS AS (cantidad * unidades_por_presentacion) STORED;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint
                    WHERE conrelid = 'public.facturas_xml_pendientes_lineas'::regclass
                      AND conname = 'facturas_xml_lineas_equivalencia_positiva') THEN
        ALTER TABLE public.facturas_xml_pendientes_lineas
            ADD CONSTRAINT facturas_xml_lineas_equivalencia_positiva
            CHECK (unidades_por_presentacion IS NULL OR unidades_por_presentacion > 0);
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_constraint
                    WHERE conrelid = 'public.facturas_xml_pendientes_lineas'::regclass
                      AND conname = 'facturas_xml_lineas_equivalencia_con_articulo') THEN
        ALTER TABLE public.facturas_xml_pendientes_lineas
            ADD CONSTRAINT facturas_xml_lineas_equivalencia_con_articulo
            CHECK (unidades_por_presentacion IS NULL
                   OR num_nonnulls(ingrediente_id, producto_id) = 1);
    END IF;
END $$;

COMMIT;
