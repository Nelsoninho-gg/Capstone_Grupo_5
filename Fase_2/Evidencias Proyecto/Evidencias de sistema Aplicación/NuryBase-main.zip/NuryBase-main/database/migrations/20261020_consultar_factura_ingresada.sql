-- Consulta «¿esta factura ya fue ingresada?» (H3.7 T03) y recuperación de un ingreso
-- cuya respuesta no llegó (H3.7 T05).
--
-- fn_consultar_factura_ingresada(rut_emisor, tipo_documento, folio) busca la identidad
-- de la factura (RUT normalizado + tipo + folio, la misma de la restricción única de
-- facturas_compra) y responde:
--   - identificacion_completa = false si el RUT, el tipo o el folio faltan o no son
--     válidos. No es un error: la pantalla muestra el aviso de «identificación incompleta».
--   - ingresada = false si no existe un ingreso confirmado.
--   - ingresada = true si existe. Cuánto se cuenta depende de los permisos (decidido el
--     20/10/2026):
--       * admin, o bodeguero de la sucursal donde se ingresó: todo el detalle (id de la
--         factura, sucursal, fecha, quién la ingresó, cuántas líneas sumaron stock).
--       * bodeguero de otra sucursal: solo que ya fue ingresada. No ve sucursal, fecha
--         ni usuario, igual que no ve esas filas en las tablas (RLS).
--       * cajero y anónimos: sin acceso.
--
-- Recuperar un ingreso (T05): si la respuesta de la confirmación se perdió, el usuario
-- reintenta y la restricción única rechaza la factura repetida, así que nunca se suma
-- stock dos veces. Esta consulta le devuelve el ingreso existente (ingresada_por_ti,
-- ingresada_en y las líneas) para que la pantalla le informe que sí se completó.
--
-- No modifica fn_ingresar_factura_xml ni el esquema.
--
-- REQUIERE: 20261017_permisos_ingreso_facturas.sql y 20261017_ingresar_factura_xml.sql.
--
-- ANTES DE APLICAR EN PRODUCCIÓN:
--   a) Revisar el script completo con el responsable.
--   b) Correr primero 20261020_consultar_factura_ingresada.ENSAYO.sql (termina en ROLLBACK).
--   c) Después de aplicar: NOTIFY pgrst, 'reload schema';

BEGIN;

CREATE OR REPLACE FUNCTION public.fn_consultar_factura_ingresada(
    p_rut_emisor     TEXT,
    p_tipo_documento SMALLINT,
    p_folio          BIGINT
)
RETURNS JSONB
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_actor    RECORD;
    v_rut_norm TEXT;
    v_factura  RECORD;
    v_inv      INTEGER;
    v_otras    INTEGER;
BEGIN
    SELECT * INTO v_actor FROM public.fn_actor_ingreso();
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Tu usuario no está autorizado para ingresar facturas'
            USING ERRCODE = '42501';
    END IF;

    v_rut_norm := public.fn_normalizar_rut(p_rut_emisor);
    IF v_rut_norm IS NULL OR p_tipo_documento IS NULL OR p_folio IS NULL OR p_folio <= 0 THEN
        RETURN jsonb_build_object('identificacion_completa', FALSE, 'ingresada', FALSE);
    END IF;

    SELECT f.id AS factura_id, f.sucursal_id, s.nombre AS sucursal,
           x.id AS xml_id, x.confirmado_por, x.confirmado_en, u.nombre AS ingresada_por
      INTO v_factura
      FROM public.facturas_compra f
      LEFT JOIN public.sucursales s ON s.id = f.sucursal_id
      LEFT JOIN public.facturas_xml_pendientes x ON x.factura_id = f.id
      LEFT JOIN public.usuarios u ON u.id = x.confirmado_por
     WHERE f.rut_emisor_normalizado = v_rut_norm
       AND f.tipo_documento = p_tipo_documento
       AND f.folio = p_folio;
    IF NOT FOUND THEN
        RETURN jsonb_build_object('identificacion_completa', TRUE, 'ingresada', FALSE);
    END IF;

    -- Otra sucursal: se sabe que ya existe, pero no dónde, cuándo ni quién.
    IF v_actor.rol NOT IN ('admin', 'administrador')
       AND v_factura.sucursal_id IS DISTINCT FROM v_actor.sucursal_id THEN
        RETURN jsonb_build_object('identificacion_completa', TRUE, 'ingresada', TRUE,
                                  'puede_ver_detalle', FALSE);
    END IF;

    SELECT count(*) FILTER (WHERE NOT COALESCE(l.no_corresponde_inventario, FALSE)),
           count(*) FILTER (WHERE COALESCE(l.no_corresponde_inventario, FALSE))
      INTO v_inv, v_otras
      FROM public.facturas_xml_pendientes_lineas l
     WHERE l.factura_xml_id = v_factura.xml_id;

    RETURN jsonb_build_object(
        'identificacion_completa', TRUE,
        'ingresada', TRUE,
        'puede_ver_detalle', TRUE,
        'factura_compra_id', v_factura.factura_id,
        'factura_xml_id', v_factura.xml_id,
        'sucursal_id', v_factura.sucursal_id,
        'sucursal', v_factura.sucursal,
        'ingresada_en', v_factura.confirmado_en,
        'ingresada_por', v_factura.ingresada_por,
        'ingresada_por_ti', COALESCE(v_factura.confirmado_por = v_actor.usuario_id, FALSE),
        'lineas_inventario', v_inv,
        'lineas_no_inventario', v_otras);
END;
$$;

REVOKE ALL ON FUNCTION public.fn_consultar_factura_ingresada(text, smallint, bigint)
    FROM PUBLIC, web_anon, nury_cajero;
GRANT EXECUTE ON FUNCTION public.fn_consultar_factura_ingresada(text, smallint, bigint)
    TO nury_admin, nury_bodeguero;

COMMIT;
