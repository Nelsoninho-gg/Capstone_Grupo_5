-- H2.12 T01/T04 — Venta a empleados: lista de empleados para el POS.
--
-- El cajero necesita elegir qué empleado compra, pero no debe leer la tabla
-- `usuarios` completa (tiene el hash de la contraseña y datos de acceso).
-- Esta función devuelve solo el id y el nombre de los usuarios activos.
--
-- Requiere 0004_venta_empleado.sql y 0005_venta_empleado_descuento.sql.

BEGIN;

-- Mismo dueño que fn_registrar_venta.
SET LOCAL ROLE nury_admin;

CREATE OR REPLACE FUNCTION public.fn_listar_empleados()
RETURNS TABLE (id INTEGER, nombre VARCHAR)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = 'pg_catalog', 'public', 'pg_temp'
AS $function$
    SELECT u.id, u.nombre
      FROM public.usuarios u
     WHERE u.activo = TRUE
     ORDER BY u.nombre;
$function$;

REVOKE ALL ON FUNCTION public.fn_listar_empleados() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.fn_listar_empleados() TO nury_cajero, nury_admin;

COMMIT;
