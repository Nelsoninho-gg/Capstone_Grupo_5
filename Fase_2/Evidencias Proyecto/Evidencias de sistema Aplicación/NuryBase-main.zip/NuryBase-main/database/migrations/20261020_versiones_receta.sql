-- H2.5 T02 - Obtener la receta vigente y sus ingredientes al confirmar la venta,
-- identificando la versión utilizada.
--
-- Decisión (Sebastián, 2026-10-20): se guarda la receta actual de cada producto compuesto
-- como una versión, y cada vez que se edita la receta se crea una versión nueva.
--   - recetas sigue siendo la receta editable (el Maestro de Productos no cambia).
--   - Cada cambio en recetas (agregar, cambiar cantidad o quitar un insumo) crea una
--     versión nueva con la copia completa de los ingredientes. Una sentencia que cambia
--     varias filas crea una sola versión, y un cambio que deja la receta igual no crea
--     ninguna. Si se quitan todos los insumos queda una versión vacía: el producto pasa
--     a ser de reventa.
--   - Al insertar una línea de venta se guarda en detalle_venta.receta_version_id la
--     versión vigente del producto (NULL si no tiene receta) y fn_aplicar_venta descuenta
--     los ingredientes de esa versión. Así cada venta sabe con qué receta se hizo.
--
-- Contenido:
--   T01  tablas recetas_version y recetas_version_detalle
--   T02  fn_versionar_receta() + trigger en recetas
--   T03  versión 1 de las recetas que ya existen
--   T04  detalle_venta.receta_version_id + trigger que la completa
--   T05  fn_aplicar_venta descontando por la versión (reemplaza la de 0004)
--   T06  fn_versiones_receta(): historial que muestra el Maestro de Productos
--
-- Requiere: 0004_stock_producto_reventa.sql y 20261012_permisos_cajero.sql
-- (fn_usuario_actual_id, para registrar quién editó la receta).
--
-- ANTES DE APLICAR EN PRODUCCIÓN:
--   a) Confirmar que fn_aplicar_venta de producción es la de 0004 (T05 la reemplaza):
--        SELECT pg_get_functiondef('public.fn_aplicar_venta()'::regprocedure);
--   b) Correr database/tests/versiones_receta.sql en una base de pruebas y luego
--      20261020_versiones_receta.ENSAYO.sql (termina en ROLLBACK).
--   c) Después de aplicar: NOTIFY pgrst, 'reload schema';

BEGIN;

-- T01) Versiones de receta --------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.recetas_version (
    id            SERIAL PRIMARY KEY,
    producto_id   INTEGER NOT NULL REFERENCES public.productos(id),
    numero        INTEGER NOT NULL CHECK (numero > 0),
    vigente_desde TIMESTAMP NOT NULL DEFAULT now(),
    creada_por    INTEGER REFERENCES public.usuarios(id),   -- NULL: carga inicial o cambio sin sesión
    UNIQUE (producto_id, numero)
);

CREATE TABLE IF NOT EXISTS public.recetas_version_detalle (
    id                 SERIAL PRIMARY KEY,
    version_id         INTEGER NOT NULL REFERENCES public.recetas_version(id) ON DELETE CASCADE,
    ingrediente_id     INTEGER NOT NULL REFERENCES public.ingredientes(id),
    cantidad_necesaria NUMERIC(12,3) NOT NULL CHECK (cantidad_necesaria > 0),
    unidad_id          INTEGER NOT NULL REFERENCES public.unidades_medida(id),
    UNIQUE (version_id, ingrediente_id)
);

-- Lectura para administración (historial de recetas). Se escriben solo por trigger.
GRANT SELECT ON public.recetas_version, public.recetas_version_detalle TO nury_admin;

-- T02) Una versión nueva por cada cambio de la receta --------------------------
CREATE OR REPLACE FUNCTION public.fn_versionar_receta(p_producto_id INTEGER)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $function$
DECLARE
    v_ultima  public.recetas_version%ROWTYPE;
    v_version INTEGER;
BEGIN
    -- Ordena los cambios simultáneos de una misma receta. NO KEY UPDATE no bloquea las
    -- ventas (la FK de detalle_venta solo toma KEY SHARE sobre el producto).
    PERFORM 1 FROM public.productos WHERE id = p_producto_id FOR NO KEY UPDATE;
    IF NOT FOUND THEN
        RETURN;  -- el producto se está eliminando junto con su receta
    END IF;

    SELECT * INTO v_ultima
      FROM public.recetas_version
     WHERE producto_id = p_producto_id
     ORDER BY numero DESC
     LIMIT 1;

    IF FOUND THEN
        -- Sin cambios reales respecto de la última versión: no se crea otra.
        IF NOT EXISTS (
            (SELECT ingrediente_id, cantidad_necesaria, unidad_id
               FROM public.recetas WHERE producto_id = p_producto_id
             EXCEPT
             SELECT ingrediente_id, cantidad_necesaria, unidad_id
               FROM public.recetas_version_detalle WHERE version_id = v_ultima.id)
            UNION ALL
            (SELECT ingrediente_id, cantidad_necesaria, unidad_id
               FROM public.recetas_version_detalle WHERE version_id = v_ultima.id
             EXCEPT
             SELECT ingrediente_id, cantidad_necesaria, unidad_id
               FROM public.recetas WHERE producto_id = p_producto_id)
        ) THEN
            RETURN;
        END IF;
    ELSIF NOT EXISTS (SELECT 1 FROM public.recetas WHERE producto_id = p_producto_id) THEN
        RETURN;  -- nunca tuvo receta
    END IF;

    INSERT INTO public.recetas_version (producto_id, numero, creada_por)
    VALUES (p_producto_id, COALESCE(v_ultima.numero, 0) + 1, public.fn_usuario_actual_id())
    RETURNING id INTO v_version;

    INSERT INTO public.recetas_version_detalle (version_id, ingrediente_id, cantidad_necesaria, unidad_id)
    SELECT v_version, ingrediente_id, cantidad_necesaria, unidad_id
      FROM public.recetas
     WHERE producto_id = p_producto_id;
END;
$function$;

REVOKE ALL ON FUNCTION public.fn_versionar_receta(integer) FROM PUBLIC;

CREATE OR REPLACE FUNCTION public.fn_recetas_versionar()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $function$
BEGIN
    -- Los triggers AFTER ROW se ejecutan al terminar la sentencia y ya ven todas sus
    -- filas: la primera crea la versión y las siguientes la encuentran igual.
    IF TG_OP IN ('INSERT', 'UPDATE') THEN
        PERFORM public.fn_versionar_receta(NEW.producto_id);
    END IF;
    IF TG_OP = 'DELETE' OR (TG_OP = 'UPDATE' AND OLD.producto_id <> NEW.producto_id) THEN
        PERFORM public.fn_versionar_receta(OLD.producto_id);
    END IF;
    RETURN NULL;
END;
$function$;

DROP TRIGGER IF EXISTS trg_recetas_versionar ON public.recetas;
CREATE TRIGGER trg_recetas_versionar
    AFTER INSERT OR UPDATE OR DELETE ON public.recetas
    FOR EACH ROW EXECUTE FUNCTION public.fn_recetas_versionar();

-- T03) Las recetas actuales quedan como versión 1 -------------------------------
INSERT INTO public.recetas_version (producto_id, numero)
SELECT DISTINCT r.producto_id, 1
  FROM public.recetas r
 WHERE NOT EXISTS (SELECT 1 FROM public.recetas_version v WHERE v.producto_id = r.producto_id);

INSERT INTO public.recetas_version_detalle (version_id, ingrediente_id, cantidad_necesaria, unidad_id)
SELECT v.id, r.ingrediente_id, r.cantidad_necesaria, r.unidad_id
  FROM public.recetas_version v
  JOIN public.recetas r ON r.producto_id = v.producto_id
 WHERE v.numero = 1
   AND NOT EXISTS (SELECT 1 FROM public.recetas_version_detalle d WHERE d.version_id = v.id);

-- T04) Cada línea de venta guarda la versión con que se hizo --------------------
ALTER TABLE public.detalle_venta
    ADD COLUMN IF NOT EXISTS receta_version_id INTEGER REFERENCES public.recetas_version(id);

CREATE INDEX IF NOT EXISTS idx_detalle_venta_receta_version
    ON public.detalle_venta (receta_version_id)
    WHERE receta_version_id IS NOT NULL;

CREATE OR REPLACE FUNCTION public.fn_detalle_venta_receta_version()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $function$
DECLARE
    v_version INTEGER;
BEGIN
    -- La versión la decide la base, no quien registra la venta.
    SELECT v.id INTO v_version
      FROM public.recetas_version v
     WHERE v.producto_id = NEW.producto_id
     ORDER BY v.numero DESC
     LIMIT 1;

    -- Una versión vacía (se quitaron todos los insumos) significa "sin receta".
    IF v_version IS NOT NULL
       AND NOT EXISTS (SELECT 1 FROM public.recetas_version_detalle WHERE version_id = v_version) THEN
        v_version := NULL;
    END IF;

    NEW.receta_version_id := v_version;
    RETURN NEW;
END;
$function$;

DROP TRIGGER IF EXISTS trg_detalle_venta_receta_version ON public.detalle_venta;
CREATE TRIGGER trg_detalle_venta_receta_version
    BEFORE INSERT ON public.detalle_venta
    FOR EACH ROW EXECUTE FUNCTION public.fn_detalle_venta_receta_version();

-- T05) fn_aplicar_venta descuenta los ingredientes de esa versión ---------------
-- Igual a la de 0004 salvo: v_tiene_receta, la receta recorrida y el costo de la alerta
-- de margen salen de recetas_version_detalle de NEW.receta_version_id.
CREATE OR REPLACE FUNCTION public.fn_aplicar_venta() RETURNS TRIGGER AS $$
DECLARE
    v_sucursal_id  INTEGER;
    v_tiene_receta BOOLEAN;
    receta_row     RECORD;
    v_stock_previo NUMERIC(12,3);
    v_descuento    NUMERIC(12,3);
    v_nuevo_stock  NUMERIC(12,3);
    v_costo_receta NUMERIC(12,2);
BEGIN
    SELECT sucursal_id INTO v_sucursal_id FROM ventas WHERE id = NEW.venta_id;

    -- H2.5 T02: la versión de receta la fijó trg_detalle_venta_receta_version al insertar
    -- la línea; se descuentan exactamente sus ingredientes, aunque la receta cambie después.
    v_tiene_receta := NEW.receta_version_id IS NOT NULL;

    IF v_tiene_receta THEN
        FOR receta_row IN
            SELECT ingrediente_id, cantidad_necesaria
              FROM recetas_version_detalle
             WHERE version_id = NEW.receta_version_id
        LOOP
            v_descuento := receta_row.cantidad_necesaria * NEW.cantidad;

            INSERT INTO stock_sucursal (ingrediente_id, sucursal_id, stock_actual, stock_minimo)
            VALUES (receta_row.ingrediente_id, v_sucursal_id, 0, 0)
            ON CONFLICT (ingrediente_id, sucursal_id) DO NOTHING;

            SELECT stock_actual INTO v_stock_previo
              FROM stock_sucursal
             WHERE ingrediente_id = receta_row.ingrediente_id AND sucursal_id = v_sucursal_id
             FOR UPDATE;

            v_nuevo_stock := v_stock_previo - v_descuento;

            UPDATE stock_sucursal
               SET stock_actual = v_nuevo_stock,
                   actualizado_en = now()
             WHERE ingrediente_id = receta_row.ingrediente_id AND sucursal_id = v_sucursal_id;

            INSERT INTO movimientos_stock
                (ingrediente_id, sucursal_id, tipo_movimiento, cantidad, stock_resultante, referencia_tipo, referencia_id)
            VALUES
                (receta_row.ingrediente_id, v_sucursal_id, 'venta', -v_descuento, v_nuevo_stock, 'venta', NEW.venta_id);
        END LOOP;
    ELSE
        -- Producto de reventa: descuenta su propio stock en la sucursal de la venta.
        v_descuento := NEW.cantidad;

        INSERT INTO stock_producto_sucursal (producto_id, sucursal_id, stock_actual, stock_minimo)
        VALUES (NEW.producto_id, v_sucursal_id, 0, 0)
        ON CONFLICT (producto_id, sucursal_id) DO NOTHING;

        SELECT stock_actual INTO v_stock_previo
          FROM stock_producto_sucursal
         WHERE producto_id = NEW.producto_id AND sucursal_id = v_sucursal_id
         FOR UPDATE;

        v_nuevo_stock := v_stock_previo - v_descuento;

        UPDATE stock_producto_sucursal
           SET stock_actual = v_nuevo_stock,
               actualizado_en = now()
         WHERE producto_id = NEW.producto_id AND sucursal_id = v_sucursal_id;

        INSERT INTO movimientos_stock
            (producto_id, sucursal_id, tipo_movimiento, cantidad, stock_resultante, referencia_tipo, referencia_id)
        VALUES
            (NEW.producto_id, v_sucursal_id, 'venta', -v_descuento, v_nuevo_stock, 'venta', NEW.venta_id);
    END IF;

    -- Alerta de margen: si la línea trae promoción y el precio aplicado queda bajo el costo de receta, se registra (no bloquea)
    IF NEW.promocion_id IS NOT NULL THEN
        SELECT COALESCE(SUM(r.cantidad_necesaria * i.costo_unitario_promedio), 0)
          INTO v_costo_receta
          FROM recetas_version_detalle r JOIN ingredientes i ON i.id = r.ingrediente_id
         WHERE r.version_id = NEW.receta_version_id;

        IF NEW.precio_unitario < v_costo_receta THEN
            INSERT INTO alertas_margen (promocion_id, producto_id, costo_receta, precio_aplicado, venta_id)
            VALUES (NEW.promocion_id, NEW.producto_id, v_costo_receta, NEW.precio_unitario, NEW.venta_id);
        END IF;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- T06) Historial para el Maestro de Productos ------------------------------------
-- Versiones de la receta de un producto, de la más nueva a la más antigua, con el
-- nombre de quien la editó y qué insumos se agregaron, quitaron o cambiaron respecto
-- de la anterior. Función aparte para no dar lectura sobre usuarios.
CREATE OR REPLACE FUNCTION public.fn_versiones_receta(p_producto_id INTEGER)
RETURNS TABLE (numero INTEGER, vigente_desde TIMESTAMP, creada_por VARCHAR, insumos INTEGER, cambios JSONB)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $function$
    WITH versiones AS (
        SELECT v.*, lag(v.id) OVER (ORDER BY v.numero) AS anterior_id
          FROM public.recetas_version v
         WHERE v.producto_id = p_producto_id
    )
    SELECT v.numero,
           v.vigente_desde,
           u.nombre::VARCHAR,
           (SELECT count(*)::INTEGER FROM public.recetas_version_detalle d WHERE d.version_id = v.id),
           -- Qué cambió respecto de la versión anterior (NULL en la primera):
           -- [{tipo: agregado|quitado|modificado, ingrediente, unidad, antes, despues}]
           CASE WHEN v.anterior_id IS NOT NULL THEN COALESCE((
               SELECT jsonb_agg(jsonb_build_object(
                          'tipo', c.tipo, 'ingrediente', i.nombre, 'unidad', um.abreviatura,
                          'antes', c.antes, 'despues', c.despues) ORDER BY i.nombre)
                 FROM (
                     SELECT COALESCE(n.ingrediente_id, a.ingrediente_id) AS ingrediente_id,
                            COALESCE(n.unidad_id, a.unidad_id) AS unidad_id,
                            CASE WHEN a.ingrediente_id IS NULL THEN 'agregado'
                                 WHEN n.ingrediente_id IS NULL THEN 'quitado'
                                 ELSE 'modificado' END AS tipo,
                            a.cantidad_necesaria AS antes,
                            n.cantidad_necesaria AS despues
                       FROM (SELECT * FROM public.recetas_version_detalle WHERE version_id = v.id) n
                       FULL JOIN (SELECT * FROM public.recetas_version_detalle WHERE version_id = v.anterior_id) a
                         ON a.ingrediente_id = n.ingrediente_id
                      WHERE a.ingrediente_id IS NULL OR n.ingrediente_id IS NULL
                         OR a.cantidad_necesaria <> n.cantidad_necesaria OR a.unidad_id <> n.unidad_id
                 ) c
                 JOIN public.ingredientes i ON i.id = c.ingrediente_id
                 LEFT JOIN public.unidades_medida um ON um.id = c.unidad_id
           ), '[]'::JSONB) END
      FROM versiones v
      LEFT JOIN public.usuarios u ON u.id = v.creada_por
     ORDER BY v.numero DESC;
$function$;

REVOKE ALL ON FUNCTION public.fn_versiones_receta(integer) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.fn_versiones_receta(integer) TO nury_admin, nury_cajero;

COMMIT;
