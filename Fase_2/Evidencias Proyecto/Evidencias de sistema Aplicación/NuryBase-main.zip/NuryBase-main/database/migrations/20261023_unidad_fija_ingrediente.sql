-- H3.3 - La unidad de medida queda asociada permanentemente a la materia prima.
--
-- Criterio de aceptación: "La unidad de medida definida queda asociada permanentemente
-- al insumo y se usa como base para todos los cálculos de recetas y descuentos de stock."
--
-- 20261021_modelo_articulos.sql solo impedía cambiarla cuando el ingrediente ya estaba en
-- uso (recetas, movimientos o stock). La pantalla nunca la cambia al editar, pero por la
-- API todavía se podía cambiar la de un ingrediente sin uso. Esta migración reemplaza la
-- función del trigger trg_ingredientes_unidad_fija para que el cambio se rechace siempre.
-- Si se eligió mal la unidad al crear, se desactiva ese ingrediente y se crea otro.
--
-- ANTES DE APLICAR EN PRODUCCIÓN:
--   a) Correr database/tests/unidad_fija_ingrediente.sql en una base de pruebas y luego
--      20261023_unidad_fija_ingrediente.ENSAYO.sql (termina en ROLLBACK).
--   b) No requiere NOTIFY pgrst: no cambia la API.

BEGIN;

CREATE OR REPLACE FUNCTION public.fn_ingrediente_unidad_fija()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $function$
BEGIN
    IF NEW.unidad_id IS DISTINCT FROM OLD.unidad_id THEN
        RAISE EXCEPTION 'La unidad de "%" no se puede cambiar: queda fija desde que se crea la materia prima', OLD.nombre
            USING ERRCODE = '22023';
    END IF;
    RETURN NEW;
END;
$function$;

COMMIT;
