-- Facturas XML sin confirmar (H3.1 T02 + H3.7 T02).
--
-- Contexto: una factura XML cargada pero no confirmada debe guardarse en una
-- tabla propia. Si sus líneas se insertaran en detalle_factura_compra, el
-- trigger fn_aplicar_compra (AFTER INSERT) sumaría stock antes de confirmar.
-- Por eso la carga guarda aquí, y solo al confirmar (H3.1 T08) se crean
-- facturas_compra y detalle_factura_compra en una sola transacción.
--
-- Este script solo CREA tablas nuevas. No modifica facturas_compra ni
-- detalle_factura_compra y no toca stock.
--
-- ANTES DE APLICAR EN PRODUCCIÓN:
--   a) Revisar el script completo con el responsable.
--   b) Correr primero 20261016_facturas_xml_pendientes.ENSAYO.sql (termina en ROLLBACK).
--   c) Después de aplicar: NOTIFY pgrst, 'reload schema';

BEGIN;

-- Cabecera de la factura XML pendiente ----------------------------------------

CREATE TABLE IF NOT EXISTS public.facturas_xml_pendientes (
    id                      SERIAL PRIMARY KEY,
    sucursal_id             INTEGER NOT NULL REFERENCES public.sucursales(id),
    cargado_por             INTEGER NOT NULL REFERENCES public.usuarios(id),
    estado                  VARCHAR(20) NOT NULL DEFAULT 'pendiente'
                                CHECK (estado IN ('pendiente','confirmada','cancelada')),

    -- Identidad del documento tal como viene en el XML.
    tipo_documento          SMALLINT NOT NULL CHECK (tipo_documento = 33),  -- solo factura electrónica
    folio                   BIGINT NOT NULL CHECK (folio > 0),
    rut_emisor              VARCHAR(12) NOT NULL,                             -- ej. '82623500-4'
    rut_emisor_normalizado  VARCHAR(12) NOT NULL,                             -- sin puntos, guion en su sitio, DV en mayúscula (lo calcula la carga)

    -- Datos informativos. El RUT receptor NO se valida (decisión 16/10/2026).
    razon_social_emisor     VARCHAR(150),
    rut_receptor            VARCHAR(12),
    fecha_emision           DATE NOT NULL,
    fecha_vencimiento       DATE,
    forma_pago              SMALLINT,
    orden_compra_referencia VARCHAR(60),                                     -- folio de la referencia tipo 801, si viene

    -- Totales tal como vienen en el XML.
    monto_neto              NUMERIC(12,2) NOT NULL,
    monto_iva               NUMERIC(12,2) NOT NULL,
    tasa_iva                NUMERIC(5,2),
    monto_total             NUMERIC(12,2) NOT NULL,

    -- Respaldo del archivo original.
    xml_original            BYTEA NOT NULL,                                  -- bytes tal cual llegaron
    xml_nombre              VARCHAR(255),
    xml_sha256              CHAR(64) NOT NULL,                               -- para detectar archivo repetido (H3.7)
    detalle_incluye_iva     BOOLEAN NOT NULL DEFAULT FALSE,                  -- sin IndMntNeto: se asume neto (supuesto registrado)

    -- Al confirmar (H3.1 T08).
    factura_id              INTEGER REFERENCES public.facturas_compra(id),
    confirmado_por          INTEGER REFERENCES public.usuarios(id),
    confirmado_en           TIMESTAMP,

    creado_en               TIMESTAMP NOT NULL DEFAULT now(),
    CHECK ((estado = 'confirmada') = (factura_id IS NOT NULL))
);

CREATE INDEX IF NOT EXISTS idx_facturas_xml_pendientes_identidad
    ON public.facturas_xml_pendientes(rut_emisor_normalizado, tipo_documento, folio);

CREATE INDEX IF NOT EXISTS idx_facturas_xml_pendientes_sucursal
    ON public.facturas_xml_pendientes(sucursal_id, estado);

-- Líneas del XML, con su asociación al catálogo (H3.1 T05/T06) -----------------

CREATE TABLE IF NOT EXISTS public.facturas_xml_pendientes_lineas (
    id                          SERIAL PRIMARY KEY,
    factura_xml_id              INTEGER NOT NULL REFERENCES public.facturas_xml_pendientes(id) ON DELETE CASCADE,
    numero_linea                INTEGER NOT NULL CHECK (numero_linea > 0),     -- NroLinDet

    -- Datos tal como vienen en el XML.
    codigo_tipo                 VARCHAR(20),                                   -- TpoCodigo (viene vacío en el ejemplo)
    codigo_proveedor            VARCHAR(60),                                   -- VlrCodigo
    descripcion                 VARCHAR(255) NOT NULL,                         -- NmbItem (puede traer el código pegado)
    cantidad                    NUMERIC(12,3) NOT NULL CHECK (cantidad > 0),   -- QtyItem, en unidad de compra
    precio_unitario             NUMERIC(14,4) NOT NULL CHECK (precio_unitario >= 0),  -- PrcItem
    monto                       NUMERIC(12,2) NOT NULL,                        -- MontoItem

    -- Asociación con el catálogo. Se completa en H3.1 T05/T06; queda NULL hasta entonces.
    ingrediente_id              INTEGER REFERENCES public.ingredientes(id),
    producto_id                 INTEGER REFERENCES public.productos(id),
    no_corresponde_inventario   BOOLEAN NOT NULL DEFAULT FALSE,                -- servicios, etc.

    UNIQUE (factura_xml_id, numero_linea),
    CHECK (num_nonnulls(ingrediente_id, producto_id) <= 1),
    CHECK (NOT (no_corresponde_inventario AND num_nonnulls(ingrediente_id, producto_id) > 0))
);

-- Mismo dueño y permisos que las tablas de factura existentes -----------------
-- (se copian de facturas_compra; revisar antes de aplicar).

DO $$
DECLARE
    v_owner TEXT;
    r       RECORD;
    t       TEXT;
BEGIN
    SELECT pg_get_userbyid(relowner) INTO v_owner
      FROM pg_class WHERE oid = 'public.facturas_compra'::regclass;

    FOREACH t IN ARRAY ARRAY['facturas_xml_pendientes', 'facturas_xml_pendientes_lineas'] LOOP
        EXECUTE format('ALTER TABLE public.%I OWNER TO %I', t, v_owner);
        EXECUTE format('ALTER SEQUENCE public.%I OWNER TO %I', t || '_id_seq', v_owner);

        FOR r IN
            SELECT CASE WHEN a.grantee = 0 THEN 'PUBLIC' ELSE quote_ident(pg_get_userbyid(a.grantee)) END AS grantee,
                   a.privilege_type
              FROM pg_class c, LATERAL aclexplode(c.relacl) a
             WHERE c.oid = 'public.facturas_compra'::regclass
               AND a.grantee <> c.relowner
        LOOP
            EXECUTE format('GRANT %s ON public.%I TO %s', r.privilege_type, t, r.grantee);
        END LOOP;
    END LOOP;
END $$;

COMMIT;
