-- ENSAYO de 20261020_intentos_factura_duplicada.sql (H3.7 T07).
-- Aplica el mismo cambio (el bloque entre «Cambio a ensayar» y «Datos de ejemplo» es
-- copia exacta del script real), repite facturas como admin y bodeguero, revisa lo
-- guardado y quién puede ver los intentos, y termina en ROLLBACK: no deja nada aplicado.
--
-- REQUIERE aplicados: 20261016_facturas_xml_pendientes.sql,
-- 20261017_equivalencias_lineas_xml.sql, 20261017_permisos_ingreso_facturas.sql y
-- 20261017_ingresar_factura_xml.sql.
--
-- Resultado: pestaña «Messages» de pgAdmin. Cada prueba aparece como «OK | ...» y al
-- final «ENSAYO COMPLETO». Si alguna falla, el ensayo termina con error: ejecuta
-- ROLLBACK; solo y pégame los avisos.

BEGIN;

-- Cambio a ensayar (igual al script real) ----------------------------------------------

-- 1) Tabla de intentos ------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS public.intentos_factura_duplicada (
    id                      SERIAL PRIMARY KEY,
    creado_en               TIMESTAMP NOT NULL DEFAULT now(),
    usuario_id              INTEGER NOT NULL REFERENCES public.usuarios(id),
    sucursal_solicitada_id  INTEGER NOT NULL REFERENCES public.sucursales(id),
    rut_emisor_normalizado  VARCHAR(12) NOT NULL,
    tipo_documento          SMALLINT NOT NULL,
    folio                   BIGINT NOT NULL,
    factura_compra_id       INTEGER NOT NULL REFERENCES public.facturas_compra(id),
    sucursal_factura_id     INTEGER NOT NULL REFERENCES public.sucursales(id),
    resultado               VARCHAR(20) NOT NULL DEFAULT 'rechazado'
                            CHECK (resultado IN ('rechazado')),
    xml_nombre              VARCHAR(255),
    xml_sha256              VARCHAR(64)
);

CREATE INDEX IF NOT EXISTS idx_intentos_factura_duplicada_factura
    ON public.intentos_factura_duplicada (factura_compra_id, creado_en DESC);

-- 2) Acceso: solo lectura según el rol --------------------------------------------------

ALTER TABLE public.intentos_factura_duplicada ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS intentos_duplicada_admin ON public.intentos_factura_duplicada;
CREATE POLICY intentos_duplicada_admin ON public.intentos_factura_duplicada
    FOR SELECT TO nury_admin USING (TRUE);

DROP POLICY IF EXISTS intentos_duplicada_bodeguero ON public.intentos_factura_duplicada;
CREATE POLICY intentos_duplicada_bodeguero ON public.intentos_factura_duplicada
    FOR SELECT TO nury_bodeguero
    USING (sucursal_solicitada_id = (SELECT a.sucursal_id FROM public.fn_actor_ingreso() a)
        OR sucursal_factura_id    = (SELECT a.sucursal_id FROM public.fn_actor_ingreso() a));

REVOKE ALL ON public.intentos_factura_duplicada
    FROM PUBLIC, web_anon, nury_cajero, nury_admin, nury_bodeguero;
REVOKE ALL ON SEQUENCE public.intentos_factura_duplicada_id_seq
    FROM PUBLIC, web_anon, nury_cajero, nury_admin, nury_bodeguero;
GRANT SELECT ON public.intentos_factura_duplicada TO nury_admin, nury_bodeguero;

-- 3) Ingreso completo de la factura (igual a 20261017, salvo el bloque marcado) ----------

CREATE OR REPLACE FUNCTION public.fn_ingresar_factura_xml(
    p_sucursal_id INTEGER,
    p_xml_base64  TEXT,
    p_xml_nombre  TEXT,
    p_lineas      JSONB
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    c_documento CONSTANT TEXT := '//*[local-name()="Documento"]';
    c_tamano_maximo CONSTANT INTEGER := 5 * 1024 * 1024;

    v_actor            INTEGER;
    v_bytes            BYTEA;
    v_contenido        BYTEA;
    v_codificacion     TEXT;
    v_texto            TEXT;
    v_doc              XML;
    v_cantidad_docs    INTEGER;

    v_tipo             TEXT;
    v_folio_txt        TEXT;
    v_folio            BIGINT;
    v_fecha_txt        TEXT;
    v_fecha            DATE;
    v_venc_txt         TEXT;
    v_venc             DATE;
    v_rut              TEXT;
    v_rut_norm         TEXT;
    v_neto             NUMERIC;
    v_exento           NUMERIC;
    v_iva              NUMERIC;
    v_total            NUMERIC;
    v_tasa             NUMERIC;
    v_otros_txt        TEXT;
    v_otros            NUMERIC;
    v_incluye_iva      BOOLEAN;
    v_forma_pago       TEXT;
    v_orden_compra     TEXT;

    v_existente        INTEGER;
    v_suc_existente    INTEGER;
    v_intento          INTEGER;
    v_proveedor        INTEGER;
    v_factura          INTEGER;
    v_pendiente        INTEGER;

    v_total_lineas     INTEGER;
    v_numeros          INTEGER[] := '{}';
    v_pos              INTEGER;
    v_nro              INTEGER;
    v_nro_txt          TEXT;
    v_desc             TEXT;
    v_codigo           TEXT;
    v_codigo_tipo      TEXT;
    v_qty_txt          TEXT;
    v_qty              NUMERIC;
    v_prc_txt          TEXT;
    v_prc              NUMERIC;
    v_monto_txt        TEXT;
    v_monto            NUMERIC;

    v_cuenta           INTEGER;
    v_asoc             JSONB;
    v_ingrediente      INTEGER;
    v_producto         INTEGER;
    v_no_inventario    BOOLEAN;
    v_equivalencia     NUMERIC;
    v_unidad           INTEGER;
    v_cantidad         NUMERIC;
    v_costo            NUMERIC;
    v_precio           NUMERIC;

    v_sin_asociar      INTEGER := 0;
    v_sin_equivalencia INTEGER := 0;
    v_lineas_stock     INTEGER := 0;
    v_lineas_otras     INTEGER := 0;
BEGIN
    -- Permiso y sucursal (42501 si no corresponde).
    v_actor := public.fn_validar_sucursal_ingreso(p_sucursal_id);

    IF p_lineas IS NULL OR jsonb_typeof(p_lineas) <> 'array' THEN
        RAISE EXCEPTION 'Indica qué hacer con cada línea de la factura' USING ERRCODE = '22023';
    END IF;

    -- Archivo ------------------------------------------------------------------
    BEGIN
        v_bytes := decode(COALESCE(p_xml_base64, ''), 'base64');
    EXCEPTION WHEN OTHERS THEN
        RAISE EXCEPTION 'El archivo no llegó completo. Vuelve a elegirlo.' USING ERRCODE = '22023';
    END;
    IF length(v_bytes) = 0 THEN
        RAISE EXCEPTION 'El archivo está vacío.' USING ERRCODE = '22023';
    END IF;
    IF length(v_bytes) > c_tamano_maximo THEN
        RAISE EXCEPTION 'El archivo pesa más de 5 MB.' USING ERRCODE = '22023';
    END IF;

    -- Codificación declarada en <?xml ... encoding="..."?>; sin declaración, UTF-8.
    IF substring(v_bytes FROM 1 FOR 3) = '\xefbbbf'::BYTEA THEN
        v_contenido := substring(v_bytes FROM 4);
        v_codificacion := 'UTF8';
    ELSE
        v_contenido := v_bytes;
        v_codificacion := COALESCE(
            substring(convert_from(substring(v_bytes FROM 1 FOR 200), 'LATIN1')
                      FROM '^\s*<\?xml[^>]*encoding\s*=\s*["'']([^"'']+)["'']'),
            'UTF8');
    END IF;

    BEGIN
        v_texto := convert_from(v_contenido, v_codificacion);
    EXCEPTION WHEN OTHERS THEN
        RAISE EXCEPTION 'El archivo declara una codificación desconocida o tiene caracteres inválidos (%).',
            v_codificacion USING ERRCODE = '22023';
    END;
    -- El texto ya está en la codificación de la base: se quita la declaración.
    v_texto := regexp_replace(v_texto, '^\s*<\?xml[^>]*\?>', '');

    BEGIN
        v_doc := XMLPARSE(DOCUMENT v_texto);
    EXCEPTION WHEN OTHERS THEN
        RAISE EXCEPTION 'El archivo no es un XML válido o está dañado.' USING ERRCODE = '22023';
    END;

    v_cantidad_docs := (xpath('count(' || c_documento || ')', v_doc))[1]::TEXT::NUMERIC::INTEGER;
    IF v_cantidad_docs = 0 THEN
        RAISE EXCEPTION 'El archivo no contiene un documento tributario electrónico (DTE).' USING ERRCODE = '22023';
    END IF;
    IF v_cantidad_docs > 1 THEN
        RAISE EXCEPTION 'El archivo contiene % documentos. Carga una factura a la vez.', v_cantidad_docs
            USING ERRCODE = '22023';
    END IF;

    -- Encabezado ----------------------------------------------------------------
    v_tipo := public.fn_dte_texto(v_doc, 'Encabezado/IdDoc/TipoDTE');
    IF v_tipo IS NULL THEN
        RAISE EXCEPTION 'No indica el tipo de documento (TipoDTE).' USING ERRCODE = '22023';
    END IF;
    IF v_tipo <> '33' THEN
        RAISE EXCEPTION 'El documento es tipo %. Solo se aceptan facturas electrónicas (tipo 33).', v_tipo
            USING ERRCODE = '22023';
    END IF;

    v_folio_txt := public.fn_dte_texto(v_doc, 'Encabezado/IdDoc/Folio');
    IF v_folio_txt IS NULL OR v_folio_txt !~ '^[0-9]{1,18}$' OR v_folio_txt::BIGINT <= 0 THEN
        RAISE EXCEPTION 'El folio falta o no es un número válido.' USING ERRCODE = '22023';
    END IF;
    v_folio := v_folio_txt::BIGINT;

    v_fecha_txt := public.fn_dte_texto(v_doc, 'Encabezado/IdDoc/FchEmis');
    BEGIN
        IF v_fecha_txt !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$' THEN
            RAISE EXCEPTION 'fecha';
        END IF;
        v_fecha := v_fecha_txt::DATE;
    EXCEPTION WHEN OTHERS THEN
        RAISE EXCEPTION 'La fecha de emisión falta o no es válida.' USING ERRCODE = '22023';
    END;
    IF v_fecha IS NULL THEN
        RAISE EXCEPTION 'La fecha de emisión falta o no es válida.' USING ERRCODE = '22023';
    END IF;

    v_venc_txt := public.fn_dte_texto(v_doc, 'Encabezado/IdDoc/FchVenc');
    IF v_venc_txt IS NOT NULL THEN
        BEGIN
            IF v_venc_txt !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$' THEN
                RAISE EXCEPTION 'fecha';
            END IF;
            v_venc := v_venc_txt::DATE;
        EXCEPTION WHEN OTHERS THEN
            RAISE EXCEPTION 'La fecha de vencimiento no es válida.' USING ERRCODE = '22023';
        END;
    END IF;

    v_rut := public.fn_dte_texto(v_doc, 'Encabezado/Emisor/RUTEmisor');
    IF v_rut IS NULL THEN
        RAISE EXCEPTION 'No indica el RUT del emisor.' USING ERRCODE = '22023';
    END IF;
    v_rut_norm := public.fn_normalizar_rut(v_rut);
    IF v_rut_norm IS NULL THEN
        RAISE EXCEPTION 'El RUT del emisor (%) no es válido.', v_rut USING ERRCODE = '22023';
    END IF;

    v_neto   := CASE WHEN public.fn_dte_texto(v_doc, 'Encabezado/Totales/MntNeto') ~ '^-?[0-9]+$'
                     THEN public.fn_dte_texto(v_doc, 'Encabezado/Totales/MntNeto')::NUMERIC END;
    v_iva    := CASE WHEN public.fn_dte_texto(v_doc, 'Encabezado/Totales/IVA') ~ '^-?[0-9]+$'
                     THEN public.fn_dte_texto(v_doc, 'Encabezado/Totales/IVA')::NUMERIC END;
    v_total  := CASE WHEN public.fn_dte_texto(v_doc, 'Encabezado/Totales/MntTotal') ~ '^-?[0-9]+$'
                     THEN public.fn_dte_texto(v_doc, 'Encabezado/Totales/MntTotal')::NUMERIC END;
    v_exento := CASE WHEN public.fn_dte_texto(v_doc, 'Encabezado/Totales/MntExe') ~ '^-?[0-9]+$'
                     THEN public.fn_dte_texto(v_doc, 'Encabezado/Totales/MntExe')::NUMERIC ELSE 0 END;
    v_tasa   := CASE WHEN public.fn_dte_texto(v_doc, 'Encabezado/Totales/TasaIVA') ~ '^[0-9]+(\.[0-9]+)?$'
                     THEN public.fn_dte_texto(v_doc, 'Encabezado/Totales/TasaIVA')::NUMERIC END;
    IF v_neto IS NULL THEN
        RAISE EXCEPTION 'Falta el monto neto (MntNeto) o no es un número entero.' USING ERRCODE = '22023';
    END IF;
    IF v_iva IS NULL THEN
        RAISE EXCEPTION 'Falta el IVA o no es un número entero.' USING ERRCODE = '22023';
    END IF;
    IF v_total IS NULL THEN
        RAISE EXCEPTION 'Falta el monto total (MntTotal) o no es un número entero.' USING ERRCODE = '22023';
    END IF;

    v_otros_txt := (xpath('sum(' || c_documento || '/*[local-name()="Encabezado"]/*[local-name()="Totales"]'
                          || '/*[local-name()="ImptoReten"]/*[local-name()="MontoImp"])', v_doc))[1]::TEXT;
    IF v_otros_txt !~ '^-?[0-9]+(\.[0-9]+)?$' THEN
        RAISE EXCEPTION 'Los impuestos adicionales (ImptoReten) no son números válidos.' USING ERRCODE = '22023';
    END IF;
    v_otros := v_otros_txt::NUMERIC;

    IF v_neto + v_exento + v_iva + v_otros <> v_total THEN
        RAISE EXCEPTION 'Los totales no cuadran: neto, exento, IVA e impuestos suman %, pero el total informado es %.',
            v_neto + v_exento + v_iva + v_otros, v_total USING ERRCODE = '22023';
    END IF;

    v_incluye_iva := COALESCE(public.fn_dte_texto(v_doc, 'Encabezado/IdDoc/IndMntBruto') = '1', FALSE);
    v_forma_pago := public.fn_dte_texto(v_doc, 'Encabezado/IdDoc/FmaPago');
    v_orden_compra := NULLIF(btrim((xpath('string(' || c_documento
        || '/*[local-name()="Referencia"][*[local-name()="TpoDocRef"]="801"][1]/*[local-name()="FolioRef"])',
        v_doc))[1]::TEXT), '');

    -- ¿Ya fue ingresada? (H3.7) -------------------------------------------------------
    -- El candado serializa dos confirmaciones de la misma factura (doble clic o dos
    -- sesiones): la segunda espera y luego ve la primera. La restricción única es la
    -- última defensa (si dos solicitudes chocan igual, la restricción rechaza a la segunda).
    PERFORM pg_advisory_xact_lock(hashtext('factura_xml:' || v_rut_norm || ':33:' || v_folio));

    SELECT f.id, f.sucursal_id INTO v_existente, v_suc_existente
      FROM public.facturas_compra f
     WHERE f.rut_emisor_normalizado = v_rut_norm AND f.tipo_documento = 33 AND f.folio = v_folio;
    IF FOUND THEN
        -- H3.7 T07: se registra el intento y se devuelve el resultado. No se lanza error: un
        -- error deshace la transacción y el registro se perdería. No se guarda nada más.
        INSERT INTO public.intentos_factura_duplicada
            (usuario_id, sucursal_solicitada_id, rut_emisor_normalizado, tipo_documento, folio,
             factura_compra_id, sucursal_factura_id, xml_nombre, xml_sha256)
        VALUES
            (v_actor, p_sucursal_id, v_rut_norm, 33, v_folio,
             v_existente, v_suc_existente, left(p_xml_nombre, 255), encode(sha256(v_bytes), 'hex'))
        RETURNING id INTO v_intento;
        RETURN jsonb_build_object('ya_ingresada', TRUE, 'intento_id', v_intento);
    END IF;

    -- Proveedor por RUT; si no existe queda NULL (decidido el 16/10/2026).
    SELECT p.id INTO v_proveedor
      FROM public.proveedores p
     WHERE public.fn_normalizar_rut(p.rut) = v_rut_norm
     LIMIT 1;

    -- Cabeceras ------------------------------------------------------------------
    INSERT INTO public.facturas_compra
        (proveedor_id, sucursal_id, numero_factura, fecha_factura, monto_neto, monto_iva,
         monto_impuestos_especificos, monto_total, estado, origen,
         rut_emisor_normalizado, tipo_documento, folio)
    VALUES
        (v_proveedor, p_sucursal_id, v_folio::TEXT, v_fecha, v_neto, v_iva,
         v_otros, v_total, 'confirmada', 'xml',
         v_rut_norm, 33, v_folio)
    RETURNING id INTO v_factura;

    INSERT INTO public.facturas_xml_pendientes
        (sucursal_id, cargado_por, estado, tipo_documento, folio, rut_emisor, rut_emisor_normalizado,
         razon_social_emisor, rut_receptor, fecha_emision, fecha_vencimiento, forma_pago,
         orden_compra_referencia, monto_neto, monto_iva, tasa_iva, monto_total,
         xml_original, xml_nombre, xml_sha256, detalle_incluye_iva,
         factura_id, confirmado_por, confirmado_en)
    VALUES
        (p_sucursal_id, v_actor, 'confirmada', 33, v_folio, left(v_rut, 12), v_rut_norm,
         left(public.fn_dte_texto(v_doc, 'Encabezado/Emisor/RznSoc'), 150),
         left(public.fn_dte_texto(v_doc, 'Encabezado/Receptor/RUTRecep'), 12),
         v_fecha, v_venc,
         CASE WHEN v_forma_pago ~ '^[0-9]{1,4}$' THEN v_forma_pago::SMALLINT END,
         left(v_orden_compra, 60), v_neto, v_iva, v_tasa, v_total,
         v_bytes, left(p_xml_nombre, 255), encode(sha256(v_bytes), 'hex'), v_incluye_iva,
         v_factura, v_actor, now())
    RETURNING id INTO v_pendiente;

    -- Líneas -------------------------------------------------------------------------
    v_total_lineas := (xpath('count(' || c_documento || '/*[local-name()="Detalle"])', v_doc))[1]::TEXT::NUMERIC::INTEGER;
    IF v_total_lineas = 0 THEN
        RAISE EXCEPTION 'La factura no trae líneas de detalle.' USING ERRCODE = '22023';
    END IF;

    FOR v_pos IN 1..v_total_lineas LOOP
        v_nro_txt := public.fn_dte_texto(v_doc, 'NroLinDet', v_pos);
        v_nro := CASE WHEN v_nro_txt ~ '^[0-9]{1,9}$' THEN v_nro_txt::INTEGER ELSE v_pos END;
        IF v_nro = ANY (v_numeros) THEN
            RAISE EXCEPTION 'La factura repite el número de línea %.', v_nro USING ERRCODE = '22023';
        END IF;
        v_numeros := v_numeros || v_nro;

        v_desc := public.fn_dte_texto(v_doc, 'NmbItem', v_pos);
        v_codigo := public.fn_dte_texto(v_doc, 'CdgItem/VlrCodigo', v_pos);
        v_codigo_tipo := public.fn_dte_texto(v_doc, 'CdgItem/TpoCodigo', v_pos);
        v_qty_txt := public.fn_dte_texto(v_doc, 'QtyItem', v_pos);
        v_prc_txt := public.fn_dte_texto(v_doc, 'PrcItem', v_pos);
        v_monto_txt := public.fn_dte_texto(v_doc, 'MontoItem', v_pos);

        IF v_desc IS NULL THEN
            RAISE EXCEPTION 'Línea %: falta la descripción del artículo.', v_nro USING ERRCODE = '22023';
        END IF;
        IF v_qty_txt IS NULL OR v_qty_txt !~ '^[0-9]+(\.[0-9]+)?$' OR v_qty_txt::NUMERIC <= 0 THEN
            RAISE EXCEPTION 'Línea %: la cantidad falta o no es mayor que cero.', v_nro USING ERRCODE = '22023';
        END IF;
        IF v_prc_txt IS NULL OR v_prc_txt !~ '^[0-9]+(\.[0-9]+)?$' THEN
            RAISE EXCEPTION 'Línea %: falta el precio unitario.', v_nro USING ERRCODE = '22023';
        END IF;
        IF v_monto_txt IS NULL OR v_monto_txt !~ '^-?[0-9]+$' THEN
            RAISE EXCEPTION 'Línea %: falta el monto de la línea.', v_nro USING ERRCODE = '22023';
        END IF;
        v_qty := v_qty_txt::NUMERIC;
        v_prc := v_prc_txt::NUMERIC;
        v_monto := v_monto_txt::NUMERIC;

        -- Qué eligió el usuario para esta línea.
        SELECT count(*) INTO v_cuenta
          FROM jsonb_array_elements(p_lineas) e
         WHERE e->>'numero_linea' = v_nro::TEXT;
        IF v_cuenta > 1 THEN
            RAISE EXCEPTION 'La línea % aparece más de una vez en la asociación.', v_nro USING ERRCODE = '22023';
        END IF;
        SELECT e INTO v_asoc
          FROM jsonb_array_elements(p_lineas) e
         WHERE e->>'numero_linea' = v_nro::TEXT;

        v_ingrediente := CASE WHEN v_asoc->>'ingrediente_id' ~ '^[0-9]{1,9}$'
                              THEN (v_asoc->>'ingrediente_id')::INTEGER END;
        v_producto := CASE WHEN v_asoc->>'producto_id' ~ '^[0-9]{1,9}$'
                           THEN (v_asoc->>'producto_id')::INTEGER END;
        v_no_inventario := COALESCE(v_asoc->'no_corresponde_inventario' = 'true'::JSONB, FALSE);
        v_equivalencia := CASE WHEN jsonb_typeof(v_asoc->'unidades_por_presentacion') = 'number'
                               THEN (v_asoc->>'unidades_por_presentacion')::NUMERIC END;

        IF num_nonnulls(v_ingrediente, v_producto) + (CASE WHEN v_no_inventario THEN 1 ELSE 0 END) > 1 THEN
            RAISE EXCEPTION 'La línea % tiene más de una clasificación.', v_nro USING ERRCODE = '22023';
        END IF;

        IF v_asoc IS NULL OR (num_nonnulls(v_ingrediente, v_producto) = 0 AND NOT v_no_inventario) THEN
            v_sin_asociar := v_sin_asociar + 1;
            CONTINUE;
        END IF;

        IF v_no_inventario THEN
            INSERT INTO public.facturas_xml_pendientes_lineas
                (factura_xml_id, numero_linea, codigo_tipo, codigo_proveedor, descripcion,
                 cantidad, precio_unitario, monto, no_corresponde_inventario)
            VALUES
                (v_pendiente, v_nro, left(v_codigo_tipo, 20), left(v_codigo, 60), left(v_desc, 255),
                 v_qty, v_prc, v_monto, TRUE);
            v_lineas_otras := v_lineas_otras + 1;
            CONTINUE;
        END IF;

        IF v_equivalencia IS NULL OR v_equivalencia <= 0 OR v_equivalencia <> round(v_equivalencia, 3) THEN
            v_sin_equivalencia := v_sin_equivalencia + 1;
            CONTINUE;
        END IF;

        IF v_ingrediente IS NOT NULL THEN
            SELECT i.unidad_id INTO v_unidad
              FROM public.ingredientes i
             WHERE i.id = v_ingrediente AND i.activo;
            IF NOT FOUND THEN
                RAISE EXCEPTION 'Línea %: la materia prima elegida no existe o está inactiva.', v_nro
                    USING ERRCODE = '22023';
            END IF;
        ELSE
            IF NOT EXISTS (SELECT 1 FROM public.productos p WHERE p.id = v_producto AND p.activo) THEN
                RAISE EXCEPTION 'Línea %: el producto elegido no existe o está inactivo.', v_nro
                    USING ERRCODE = '22023';
            END IF;
            IF EXISTS (SELECT 1 FROM public.recetas r WHERE r.producto_id = v_producto) THEN
                RAISE EXCEPTION 'Línea %: el producto elegido tiene receta; su stock sale de sus ingredientes.', v_nro
                    USING ERRCODE = '22023';
            END IF;
            v_unidad := NULL;
        END IF;

        v_cantidad := round(v_qty * v_equivalencia, 3);
        IF v_cantidad <= 0 THEN
            RAISE EXCEPTION 'Línea %: la cantidad a ingresar es demasiado pequeña.', v_nro USING ERRCODE = '22023';
        END IF;

        INSERT INTO public.facturas_xml_pendientes_lineas
            (factura_xml_id, numero_linea, codigo_tipo, codigo_proveedor, descripcion,
             cantidad, precio_unitario, monto, ingrediente_id, producto_id, unidades_por_presentacion)
        VALUES
            (v_pendiente, v_nro, left(v_codigo_tipo, 20), left(v_codigo, 60), left(v_desc, 255),
             v_qty, v_prc, v_monto, v_ingrediente, v_producto, v_equivalencia);

        -- Costo neto de la línea; si los montos incluyen IVA, se le descuenta.
        v_costo := CASE WHEN v_incluye_iva
                        THEN round(v_monto / (1 + COALESCE(v_tasa, 19) / 100), 2)
                        ELSE v_monto END;
        v_precio := round(v_costo / v_cantidad, 2);

        -- El stock lo suma fn_aplicar_compra (AFTER INSERT), una sola vez por fila.
        INSERT INTO public.detalle_factura_compra
            (factura_id, ingrediente_id, producto_id, codigo_proveedor, unidades_por_presentacion,
             cantidad, unidad_id, precio_unitario, descuento_monto)
        VALUES
            (v_factura, v_ingrediente, v_producto, left(v_codigo, 30),
             CASE WHEN v_equivalencia = round(v_equivalencia, 2) AND v_equivalencia < 100000000
                  THEN v_equivalencia END,
             v_cantidad, v_unidad, v_precio,
             -- Diferencia de redondeo de precio_unitario (2 decimales): así subtotal_neto
             -- es exactamente el monto de la línea.
             round(v_cantidad * v_precio, 2) - v_costo);

        v_lineas_stock := v_lineas_stock + 1;
    END LOOP;

    IF v_sin_asociar > 0 THEN
        RAISE EXCEPTION 'Faltan asociar % línea(s): elige un artículo o márcalas como «No corresponde a inventario».',
            v_sin_asociar USING ERRCODE = '22023';
    END IF;
    IF v_sin_equivalencia > 0 THEN
        RAISE EXCEPTION 'Falta la equivalencia de % línea(s) asociadas a un artículo.', v_sin_equivalencia
            USING ERRCODE = '22023';
    END IF;
    IF EXISTS (SELECT 1 FROM jsonb_array_elements(p_lineas) e
                WHERE NOT (e->>'numero_linea' ~ '^[0-9]{1,9}$'
                           AND (e->>'numero_linea')::INTEGER = ANY (v_numeros))) THEN
        RAISE EXCEPTION 'La asociación menciona líneas que no están en la factura.' USING ERRCODE = '22023';
    END IF;

    RETURN jsonb_build_object(
        'factura_compra_id', v_factura,
        'factura_xml_id', v_pendiente,
        'lineas_inventario', v_lineas_stock,
        'lineas_no_inventario', v_lineas_otras);
END;
$$;

-- Solo roles de inventario. Las funciones auxiliares no se publican como RPC.
REVOKE ALL ON FUNCTION public.fn_ingresar_factura_xml(integer, text, text, jsonb)
    FROM PUBLIC, web_anon, nury_cajero;
GRANT EXECUTE ON FUNCTION public.fn_ingresar_factura_xml(integer, text, text, jsonb)
    TO nury_admin, nury_bodeguero;

-- Datos de ejemplo (se descartan con el ROLLBACK) -----------------------------------

CREATE TEMP TABLE _resultados (prueba TEXT, resultado TEXT);
GRANT ALL ON _resultados TO PUBLIC;

CREATE TEMP TABLE _casos (
    s1 INTEGER, s2 INTEGER, s3 INTEGER, admin INTEGER, bod_s1 INTEGER, bod_s2 INTEGER, bod_s3 INTEGER,
    cajero INTEGER, ingrediente INTEGER, producto INTEGER
);
GRANT SELECT ON _casos TO PUBLIC;

CREATE TEMP TABLE _xml (caso TEXT PRIMARY KEY, b64 TEXT, asoc JSONB);
GRANT SELECT ON _xml TO PUBLIC;

-- Factura de ensayo en ISO-8859-1 (emisor 76.086.428-5): queso, producto de reventa y flete.
-- Neto 12.940 + 32.464 + 5.000 = 50.404; IVA 9.577; total 59.981.
CREATE FUNCTION pg_temp.dte(p_folio BIGINT, p_tipo TEXT DEFAULT '33', p_relleno TEXT DEFAULT '')
RETURNS TEXT
LANGUAGE sql
AS $f$
    SELECT '<?xml version="1.0" encoding="ISO-8859-1"?>'
        || '<SetDTE><DTE version="1.0"><Documento ID="E' || p_folio || '">'
        || '<Encabezado><IdDoc><TipoDTE>' || p_tipo || '</TipoDTE><Folio>' || p_folio || '</Folio>'
        || '<FchEmis>2026-10-15</FchEmis></IdDoc>'
        || '<Emisor><RUTEmisor>76.086.428-5</RUTEmisor><RznSoc>Proveedor de ensayo</RznSoc></Emisor>'
        || '<Receptor><RUTRecep>11111111-1</RUTRecep></Receptor>'
        || '<Totales><MntNeto>50404</MntNeto><TasaIVA>19</TasaIVA><IVA>9577</IVA>'
        || '<MntTotal>59981</MntTotal></Totales></Encabezado>'
        || '<Detalle><NroLinDet>1</NroLinDet><CdgItem><TpoCodigo/><VlrCodigo>Q1</VlrCodigo></CdgItem>'
        || '<NmbItem>Queso</NmbItem><QtyItem>20</QtyItem><PrcItem>647</PrcItem>'
        || '<MontoItem>12940</MontoItem></Detalle>'
        || '<Detalle><NroLinDet>2</NroLinDet><CdgItem><TpoCodigo/><VlrCodigo>P2</VlrCodigo></CdgItem>'
        || '<NmbItem>Pinguino 2p 80g</NmbItem><QtyItem>16</QtyItem><PrcItem>2029</PrcItem>'
        || '<MontoItem>32464</MontoItem></Detalle>'
        || '<Detalle><NroLinDet>3</NroLinDet><NmbItem>Flete</NmbItem><QtyItem>1</QtyItem>'
        || '<PrcItem>5000</PrcItem><MontoItem>5000</MontoItem></Detalle>'
        || '</Documento></DTE></SetDTE>' || p_relleno
$f$;

CREATE FUNCTION pg_temp.b64(p_xml TEXT) RETURNS TEXT LANGUAGE sql
AS $f$ SELECT encode(convert_to(p_xml, 'LATIN1'), 'base64') $f$;

DO $$
DECLARE
    g INTEGER; s1 INTEGER; s2 INTEGER; s3 INTEGER;
    adm INTEGER; b1 INTEGER; b2 INTEGER; b3 INTEGER; caj INTEGER;
    ing INTEGER; prod INTEGER; completa JSONB;
BEGIN
    SELECT id INTO g FROM public.unidades_medida WHERE abreviatura = 'g';
    INSERT INTO public.sucursales (nombre) VALUES ('Ensayo T07 S1') RETURNING id INTO s1;
    INSERT INTO public.sucursales (nombre) VALUES ('Ensayo T07 S2') RETURNING id INTO s2;
    INSERT INTO public.sucursales (nombre) VALUES ('Ensayo T07 S3') RETURNING id INTO s3;
    INSERT INTO public.usuarios (nombre, identificador_acceso, password_hash, rol)
        VALUES ('Admin ensayo T07', 'ensayo-t07-admin', 'x', 'admin') RETURNING id INTO adm;
    INSERT INTO public.usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('Bodeguero S1 ensayo T07', 'ensayo-t07-bod1', 'x', 'bodeguero', s1) RETURNING id INTO b1;
    INSERT INTO public.usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('Bodeguero S2 ensayo T07', 'ensayo-t07-bod2', 'x', 'bodeguero', s2) RETURNING id INTO b2;
    INSERT INTO public.usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('Bodeguero S3 ensayo T07', 'ensayo-t07-bod3', 'x', 'bodeguero', s3) RETURNING id INTO b3;
    INSERT INTO public.usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('Cajero ensayo T07', 'ensayo-t07-cajero', 'x', 'cajero', s1) RETURNING id INTO caj;
    INSERT INTO public.ingredientes (nombre, unidad_id) VALUES ('Ensayo T07 Queso', g) RETURNING id INTO ing;
    INSERT INTO public.productos (nombre, precio_venta) VALUES ('Ensayo T07 Pinguino', 1000) RETURNING id INTO prod;
    INSERT INTO _casos VALUES (s1, s2, s3, adm, b1, b2, b3, caj, ing, prod);

    completa := jsonb_build_array(
        jsonb_build_object('numero_linea', 1, 'ingrediente_id', ing, 'unidades_por_presentacion', 500.5),
        jsonb_build_object('numero_linea', 2, 'producto_id', prod, 'unidades_por_presentacion', 6),
        jsonb_build_object('numero_linea', 3, 'no_corresponde_inventario', TRUE));

    INSERT INTO _xml VALUES
        ('ok',            pg_temp.b64(pg_temp.dte(990002001)), completa),
        ('renombrado',    pg_temp.b64(pg_temp.dte(990002001, p_relleno => '   ')), completa),
        ('tipo34',        pg_temp.b64(pg_temp.dte(990002002, '34')), completa),
        ('otra_factura',  pg_temp.b64(pg_temp.dte(990002003)), completa);
END $$;

-- Fase A: admin ------------------------------------------------------------------------

SELECT set_config('request.jwt.claims', json_build_object('role', 'nury_admin', 'user_id', admin)::text, TRUE)
  FROM _casos;
SET LOCAL ROLE nury_admin;

DO $$
DECLARE
    c    _casos%ROWTYPE;
    x    RECORD;
    resp JSONB;
    n    INTEGER;
BEGIN
    SELECT * INTO c FROM _casos;

    SELECT * INTO x FROM _xml WHERE caso = 'ok';
    resp := public.fn_ingresar_factura_xml(c.s1, x.b64, 'ok.xml', x.asoc);
    INSERT INTO _resultados VALUES ('A01 el primer ingreso sigue funcionando (2 líneas a stock, 1 no inventariable)',
        CASE WHEN resp->>'lineas_inventario' = '2' AND resp->>'lineas_no_inventario' = '1'
              AND resp->>'ya_ingresada' IS NULL
             THEN 'OK' ELSE 'FALLA: ' || resp::TEXT END);

    resp := public.fn_ingresar_factura_xml(c.s1, x.b64, 'ok.xml', x.asoc);
    INSERT INTO _resultados VALUES ('A02 el mismo archivo otra vez: devuelve «ya ingresada» sin error',
        CASE WHEN resp->>'ya_ingresada' = 'true' AND resp->>'intento_id' IS NOT NULL
             THEN 'OK' ELSE 'FALLA: ' || resp::TEXT END);

    SELECT * INTO x FROM _xml WHERE caso = 'renombrado';
    resp := public.fn_ingresar_factura_xml(c.s2, x.b64, 'otro_nombre.xml', x.asoc);
    INSERT INTO _resultados VALUES ('A03 el mismo folio con otro nombre y desde otra sucursal también se registra',
        CASE WHEN resp->>'ya_ingresada' = 'true' THEN 'OK' ELSE 'FALLA: ' || resp::TEXT END);

    SELECT * INTO x FROM _xml WHERE caso = 'tipo34';
    BEGIN
        PERFORM public.fn_ingresar_factura_xml(c.s1, x.b64, 'tipo34.xml', x.asoc);
        INSERT INTO _resultados VALUES ('A04 un documento inválido sigue siendo un error', 'FALLA: se aceptó');
    EXCEPTION WHEN SQLSTATE '22023' THEN
        INSERT INTO _resultados VALUES ('A04 un documento inválido sigue siendo un error', 'OK');
    END;

    SELECT count(*) INTO n FROM public.intentos_factura_duplicada;
    INSERT INTO _resultados VALUES ('A05 el admin ve los 2 intentos registrados',
        CASE WHEN n = 2 THEN 'OK' ELSE 'FALLA: ' || n END);

    SELECT * INTO x FROM _xml WHERE caso = 'otra_factura';
    resp := public.fn_ingresar_factura_xml(c.s1, x.b64, 'otra.xml', x.asoc);
    INSERT INTO _resultados VALUES ('A06 otra factura distinta se ingresa normalmente',
        CASE WHEN resp->>'lineas_inventario' = '2' THEN 'OK' ELSE 'FALLA: ' || resp::TEXT END);
END $$;

RESET ROLE;

-- Fase B: bodeguero de S2 repite la factura desde su propia sucursal --------------------

SELECT set_config('request.jwt.claims', json_build_object('role', 'nury_bodeguero', 'user_id', bod_s2)::text, TRUE)
  FROM _casos;
SET LOCAL ROLE nury_bodeguero;

DO $$
DECLARE
    c    _casos%ROWTYPE;
    x    RECORD;
    resp JSONB;
    n    INTEGER;
BEGIN
    SELECT * INTO c FROM _casos;

    SELECT * INTO x FROM _xml WHERE caso = 'ok';
    resp := public.fn_ingresar_factura_xml(c.s2, x.b64, 'ok.xml', x.asoc);
    INSERT INTO _resultados VALUES ('B01 el bodeguero que repite la factura en su sucursal queda registrado',
        CASE WHEN resp->>'ya_ingresada' = 'true' THEN 'OK' ELSE 'FALLA: ' || resp::TEXT END);

    SELECT count(*) INTO n FROM public.intentos_factura_duplicada;
    INSERT INTO _resultados VALUES ('B02 el bodeguero de S2 ve los 2 intentos pedidos desde S2 y ninguno más',
        CASE WHEN n = 2 THEN 'OK' ELSE 'FALLA: ' || n END);

    BEGIN
        INSERT INTO public.intentos_factura_duplicada
            (usuario_id, sucursal_solicitada_id, rut_emisor_normalizado, tipo_documento, folio,
             factura_compra_id, sucursal_factura_id)
        VALUES (c.bod_s2, c.s2, '76086428-5', 33, 1, 1, c.s1);
        INSERT INTO _resultados VALUES ('B03 el bodeguero no inserta intentos a mano', 'FALLA: se aceptó');
    EXCEPTION WHEN insufficient_privilege THEN
        INSERT INTO _resultados VALUES ('B03 el bodeguero no inserta intentos a mano', 'OK');
    END;
END $$;

RESET ROLE;

-- Fase C: bodeguero de S1 (donde se ingresó la factura) ------------------------------------

SELECT set_config('request.jwt.claims', json_build_object('role', 'nury_bodeguero', 'user_id', bod_s1)::text, TRUE)
  FROM _casos;
SET LOCAL ROLE nury_bodeguero;

DO $$
DECLARE
    n INTEGER;
BEGIN
    SELECT count(*) INTO n FROM public.intentos_factura_duplicada;
    INSERT INTO _resultados VALUES ('C01 el bodeguero de la sucursal donde se ingresó ve los 3 intentos sobre su factura',
        CASE WHEN n = 3 THEN 'OK' ELSE 'FALLA: ' || n END);
END $$;

RESET ROLE;

-- Fase D: bodeguero de S3, ajeno a todo --------------------------------------------------

SELECT set_config('request.jwt.claims', json_build_object('role', 'nury_bodeguero', 'user_id', bod_s3)::text, TRUE)
  FROM _casos;
SET LOCAL ROLE nury_bodeguero;

DO $$
DECLARE
    c    _casos%ROWTYPE;
    x    RECORD;
    n    INTEGER;
BEGIN
    SELECT * INTO c FROM _casos;

    SELECT count(*) INTO n FROM public.intentos_factura_duplicada;
    INSERT INTO _resultados VALUES ('D01 un bodeguero ajeno a la factura no ve ningún intento',
        CASE WHEN n = 0 THEN 'OK' ELSE 'FALLA: ' || n END);

    SELECT * INTO x FROM _xml WHERE caso = 'ok';
    BEGIN
        PERFORM public.fn_ingresar_factura_xml(c.s1, x.b64, 'ok.xml', x.asoc);
        INSERT INTO _resultados VALUES ('D02 el bodeguero no puede probar con la sucursal de otro', 'FALLA: se aceptó');
    EXCEPTION WHEN insufficient_privilege THEN
        INSERT INTO _resultados VALUES ('D02 el bodeguero no puede probar con la sucursal de otro', 'OK');
    END;
END $$;

RESET ROLE;

-- Fase E: cajero y anónimo ---------------------------------------------------------------

SELECT set_config('request.jwt.claims', json_build_object('role', 'nury_cajero', 'user_id', cajero)::text, TRUE)
  FROM _casos;
SET LOCAL ROLE nury_cajero;

DO $$
BEGIN
    PERFORM count(*) FROM public.intentos_factura_duplicada;
    INSERT INTO _resultados VALUES ('E01 el cajero no puede consultar los intentos', 'FALLA: se aceptó');
EXCEPTION WHEN insufficient_privilege THEN
    INSERT INTO _resultados VALUES ('E01 el cajero no puede consultar los intentos', 'OK');
END $$;

RESET ROLE;

SET LOCAL ROLE web_anon;

DO $$
BEGIN
    PERFORM count(*) FROM public.intentos_factura_duplicada;
    INSERT INTO _resultados VALUES ('E02 un anónimo no puede consultar los intentos', 'FALLA: se aceptó');
EXCEPTION WHEN insufficient_privilege THEN
    INSERT INTO _resultados VALUES ('E02 un anónimo no puede consultar los intentos', 'OK');
END $$;

RESET ROLE;

-- Fase V: lo guardado, visto como propietario ------------------------------------------------

DO $$
DECLARE
    c        _casos%ROWTYPE;
    r        RECORD;
    v_cuenta INTEGER;
    v_sha    TEXT;
BEGIN
    SELECT * INTO c FROM _casos;

    SELECT count(*) INTO v_cuenta FROM public.intentos_factura_duplicada;
    INSERT INTO _resultados VALUES ('V01 hay exactamente 3 intentos guardados (A02, A03 y B01)',
        CASE WHEN v_cuenta = 3 THEN 'OK' ELSE 'FALLA: ' || v_cuenta END);

    SELECT i.* INTO r FROM public.intentos_factura_duplicada i WHERE i.xml_nombre = 'otro_nombre.xml';
    INSERT INTO _resultados VALUES ('V02 el intento guarda usuario, sucursal pedida, identidad y resultado',
        CASE WHEN r.usuario_id = c.admin AND r.sucursal_solicitada_id = c.s2
                  AND r.rut_emisor_normalizado = '76086428-5' AND r.tipo_documento = 33
                  AND r.folio = 990002001 AND r.resultado = 'rechazado' AND r.creado_en IS NOT NULL
             THEN 'OK' ELSE 'FALLA: ' || row_to_json(r)::TEXT END);

    INSERT INTO _resultados VALUES ('V03 el intento apunta al ingreso existente y a su sucursal',
        CASE WHEN r.factura_compra_id = (SELECT f.id FROM public.facturas_compra f WHERE f.folio = 990002001)
                  AND r.sucursal_factura_id = c.s1
             THEN 'OK' ELSE 'FALLA: ' || row_to_json(r)::TEXT END);

    SELECT encode(sha256(decode(b64, 'base64')), 'hex') INTO v_sha FROM _xml WHERE caso = 'ok';
    INSERT INTO _resultados VALUES ('V04 el mismo archivo guarda la misma huella; el renombrado con otro byte, otra',
        CASE WHEN (SELECT xml_sha256 FROM public.intentos_factura_duplicada
                    WHERE xml_nombre = 'ok.xml' AND usuario_id = c.admin) = v_sha
                  AND r.xml_sha256 <> v_sha AND length(r.xml_sha256) = 64
             THEN 'OK' ELSE 'FALLA' END);

    SELECT count(*) INTO v_cuenta FROM public.facturas_compra WHERE folio IN (990002001, 990002003);
    INSERT INTO _resultados VALUES ('V05 solo hay una factura por folio (los intentos no crearon otra)',
        CASE WHEN v_cuenta = 2 THEN 'OK' ELSE 'FALLA: ' || v_cuenta END);

    SELECT count(*) INTO v_cuenta FROM public.detalle_factura_compra d
      JOIN public.facturas_compra f ON f.id = d.factura_id WHERE f.folio = 990002001;
    INSERT INTO _resultados VALUES ('V06 los intentos no repitieron líneas de compra (stock una sola vez)',
        CASE WHEN v_cuenta = 2 THEN 'OK' ELSE 'FALLA: ' || v_cuenta || ' líneas' END);

    SELECT count(*) INTO v_cuenta FROM public.facturas_compra WHERE folio = 990002002;
    SELECT v_cuenta + count(*) INTO v_cuenta FROM public.facturas_xml_pendientes WHERE folio = 990002002;
    INSERT INTO _resultados VALUES ('V07 el documento inválido no dejó ni factura ni intento',
        CASE WHEN v_cuenta = 0 AND (SELECT count(*) FROM public.intentos_factura_duplicada WHERE folio = 990002002) = 0
             THEN 'OK' ELSE 'FALLA' END);
END $$;

-- pgAdmin solo muestra el resultado de la última instrucción: por eso cada prueba se
-- informa como aviso (pestaña «Messages») y el ensayo falla con error si alguna no da OK.
DO $$
DECLARE
    r       RECORD;
    fallas  INTEGER := 0;
BEGIN
    FOR r IN SELECT prueba, resultado FROM _resultados ORDER BY prueba LOOP
        RAISE NOTICE '% | %', r.resultado, r.prueba;
        IF r.resultado <> 'OK' THEN
            fallas := fallas + 1;
        END IF;
    END LOOP;

    IF fallas > 0 THEN
        RAISE EXCEPTION 'El ensayo tiene % prueba(s) con FALLA: revisa los avisos de arriba', fallas;
    END IF;
    RAISE NOTICE 'ENSAYO COMPLETO: todas las pruebas dieron OK';
END $$;

ROLLBACK;
