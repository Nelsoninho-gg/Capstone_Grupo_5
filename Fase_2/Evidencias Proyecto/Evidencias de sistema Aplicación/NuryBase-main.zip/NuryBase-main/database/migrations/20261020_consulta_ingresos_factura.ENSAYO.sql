-- ENSAYO de 20261020_consulta_ingresos_factura.sql (H3.1 T09).
-- Aplica el mismo cambio (el bloque entre «Cambio a ensayar» y «Datos de ejemplo» es
-- copia exacta del script real), ingresa dos facturas de ejemplo, repite una, las consulta
-- y descarga como admin, bodegueros de cada sucursal, cajero y anónimo, y termina en
-- ROLLBACK: no deja nada aplicado.
--
-- REQUIERE aplicados: 20261017_permisos_ingreso_facturas.sql, 20261017_ingresar_factura_xml.sql
-- y 20261020_intentos_factura_duplicada.sql.
--
-- Resultado: pestaña «Messages» de pgAdmin. Cada prueba aparece como «OK | ...» y al
-- final «ENSAYO COMPLETO». Si alguna falla, el ensayo termina con error: ejecuta
-- ROLLBACK; solo y pégame los avisos.

BEGIN;

-- Cambio a ensayar (igual al script real) ----------------------------------------------

-- 1) Listado de ingresos -----------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.fn_listar_ingresos_factura(p_limite INTEGER DEFAULT 100)
RETURNS JSONB
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_actor RECORD;
    v_admin BOOLEAN;
BEGIN
    SELECT * INTO v_actor FROM public.fn_actor_ingreso();
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Tu usuario no está autorizado para consultar ingresos de facturas'
            USING ERRCODE = '42501';
    END IF;
    v_admin := v_actor.rol IN ('admin', 'administrador');

    RETURN COALESCE((
        SELECT jsonb_agg(ingreso ORDER BY orden DESC, id DESC)
          FROM (
            SELECT x.id, x.confirmado_en AS orden,
                   jsonb_build_object(
                       'factura_xml_id', x.id,
                       'factura_compra_id', x.factura_id,
                       'folio', x.folio,
                       'tipo_documento', x.tipo_documento,
                       'rut_emisor', x.rut_emisor,
                       'razon_social_emisor', x.razon_social_emisor,
                       'proveedor', p.nombre,
                       'fecha_emision', x.fecha_emision,
                       'monto_neto', x.monto_neto,
                       'monto_iva', x.monto_iva,
                       'monto_total', x.monto_total,
                       'detalle_incluye_iva', x.detalle_incluye_iva,
                       'xml_nombre', x.xml_nombre,
                       'sucursal_id', x.sucursal_id,
                       'sucursal', s.nombre,
                       'ingresada_por', u.nombre,
                       'ingresada_en', x.confirmado_en,
                       'lineas', COALESCE((
                           SELECT jsonb_agg(jsonb_build_object(
                                      'numero_linea', l.numero_linea,
                                      'codigo_proveedor', l.codigo_proveedor,
                                      'descripcion', l.descripcion,
                                      'cantidad', l.cantidad,
                                      'precio_unitario', l.precio_unitario,
                                      'monto', l.monto,
                                      'tipo', CASE WHEN l.ingrediente_id IS NOT NULL THEN 'ingrediente'
                                                   WHEN l.producto_id IS NOT NULL THEN 'producto'
                                                   ELSE 'no-inventario' END,
                                      'articulo', COALESCE(i.nombre, pr.nombre),
                                      'unidad', CASE WHEN l.ingrediente_id IS NOT NULL THEN um.abreviatura
                                                     WHEN l.producto_id IS NOT NULL THEN 'un' END,
                                      'unidades_por_presentacion', l.unidades_por_presentacion,
                                      'cantidad_ingreso', l.cantidad_ingreso)
                                  ORDER BY l.numero_linea)
                             FROM public.facturas_xml_pendientes_lineas l
                             LEFT JOIN public.ingredientes i ON i.id = l.ingrediente_id
                             LEFT JOIN public.unidades_medida um ON um.id = i.unidad_id
                             LEFT JOIN public.productos pr ON pr.id = l.producto_id
                            WHERE l.factura_xml_id = x.id), '[]'::jsonb),
                       'intentos_duplicados', COALESCE((
                           SELECT jsonb_agg(jsonb_build_object(
                                      'creado_en', d.creado_en,
                                      'usuario', du.nombre,
                                      'sucursal_solicitada', ds.nombre,
                                      'xml_nombre', d.xml_nombre)
                                  ORDER BY d.creado_en DESC, d.id DESC)
                             FROM public.intentos_factura_duplicada d
                             LEFT JOIN public.usuarios du ON du.id = d.usuario_id
                             LEFT JOIN public.sucursales ds ON ds.id = d.sucursal_solicitada_id
                            WHERE d.factura_compra_id = x.factura_id), '[]'::jsonb)
                   ) AS ingreso
              FROM public.facturas_xml_pendientes x
              LEFT JOIN public.facturas_compra f ON f.id = x.factura_id
              LEFT JOIN public.proveedores p ON p.id = f.proveedor_id
              LEFT JOIN public.sucursales s ON s.id = x.sucursal_id
              LEFT JOIN public.usuarios u ON u.id = x.confirmado_por
             WHERE x.estado = 'confirmada'
               AND (v_admin OR x.sucursal_id = v_actor.sucursal_id)
             ORDER BY x.confirmado_en DESC, x.id DESC
             LIMIT GREATEST(LEAST(COALESCE(p_limite, 100), 500), 1)
          ) t
    ), '[]'::jsonb);
END;
$$;

REVOKE ALL ON FUNCTION public.fn_listar_ingresos_factura(integer) FROM PUBLIC, web_anon, nury_cajero;
GRANT EXECUTE ON FUNCTION public.fn_listar_ingresos_factura(integer) TO nury_admin, nury_bodeguero;

-- 2) XML original para descargar ----------------------------------------------------------

CREATE OR REPLACE FUNCTION public.fn_xml_factura(p_factura_xml_id INTEGER)
RETURNS JSONB
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_actor RECORD;
    v_xml   RECORD;
BEGIN
    SELECT * INTO v_actor FROM public.fn_actor_ingreso();
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Tu usuario no está autorizado para descargar facturas'
            USING ERRCODE = '42501';
    END IF;

    SELECT x.xml_nombre, x.xml_original, x.folio INTO v_xml
      FROM public.facturas_xml_pendientes x
     WHERE x.id = p_factura_xml_id
       AND x.estado = 'confirmada'
       AND (v_actor.rol IN ('admin', 'administrador') OR x.sucursal_id = v_actor.sucursal_id);
    -- Mismo mensaje si no existe o si es de otra sucursal: no revela qué facturas hay.
    IF NOT FOUND THEN
        RAISE EXCEPTION 'La factura no existe o no tienes acceso a ella'
            USING ERRCODE = '42501';
    END IF;

    RETURN jsonb_build_object(
        'xml_nombre', COALESCE(v_xml.xml_nombre, 'factura-' || v_xml.folio || '.xml'),
        'xml_base64', encode(v_xml.xml_original, 'base64'));
END;
$$;

REVOKE ALL ON FUNCTION public.fn_xml_factura(integer) FROM PUBLIC, web_anon, nury_cajero;
GRANT EXECUTE ON FUNCTION public.fn_xml_factura(integer) TO nury_admin, nury_bodeguero;

-- Datos de ejemplo (se descartan con el ROLLBACK) -----------------------------------

CREATE TEMP TABLE _resultados (prueba TEXT, resultado TEXT);
GRANT ALL ON _resultados TO PUBLIC;

CREATE TEMP TABLE _casos (
    s1 INTEGER, s2 INTEGER, admin INTEGER, bod_s1 INTEGER, bod_s2 INTEGER, cajero INTEGER,
    ingrediente INTEGER, producto INTEGER
);
GRANT SELECT ON _casos TO PUBLIC;

CREATE TEMP TABLE _xml (caso TEXT PRIMARY KEY, b64 TEXT, asoc JSONB);
GRANT SELECT ON _xml TO PUBLIC;

-- Ids de las facturas ingresadas en la fase A, para las fases siguientes.
CREATE TEMP TABLE _ids (caso TEXT PRIMARY KEY, factura_xml_id INTEGER);
GRANT ALL ON _ids TO PUBLIC;

-- Factura de ensayo en ISO-8859-1 (emisor 76.086.428-5): queso, producto de reventa y flete.
-- Neto 12.940 + 32.464 + 5.000 = 50.404; IVA 9.577; total 59.981.
CREATE FUNCTION pg_temp.dte(p_folio BIGINT)
RETURNS TEXT
LANGUAGE sql
AS $f$
    SELECT '<?xml version="1.0" encoding="ISO-8859-1"?>'
        || '<SetDTE><DTE version="1.0"><Documento ID="E' || p_folio || '">'
        || '<Encabezado><IdDoc><TipoDTE>33</TipoDTE><Folio>' || p_folio || '</Folio>'
        || '<FchEmis>2026-10-15</FchEmis></IdDoc>'
        || '<Emisor><RUTEmisor>76.086.428-5</RUTEmisor><RznSoc>Proveedor de ensayo</RznSoc></Emisor>'
        || '<Receptor><RUTRecep>11111111-1</RUTRecep></Receptor>'
        || '<Totales><MntNeto>50404</MntNeto><TasaIVA>19</TasaIVA><IVA>9577</IVA>'
        || '<MntTotal>59981</MntTotal></Totales></Encabezado>'
        || '<Detalle><NroLinDet>1</NroLinDet><CdgItem><TpoCodigo/><VlrCodigo>Q1</VlrCodigo></CdgItem>'
        || '<NmbItem>Queso</NmbItem><QtyItem>20</QtyItem><PrcItem>647</PrcItem>'
        || '<MontoItem>12940</MontoItem></Detalle>'
        || '<Detalle><NroLinDet>2</NroLinDet><CdgItem><TpoCodigo/><VlrCodigo>P2</VlrCodigo></CdgItem>'
        || '<NmbItem>Pinguino 2p 80g</NmbItem><QtyItem>16</QtyItem><PrcItem>2029</PrcItem>'
        || '<MontoItem>32464</MontoItem></Detalle>'
        || '<Detalle><NroLinDet>3</NroLinDet><NmbItem>Flete</NmbItem><QtyItem>1</QtyItem>'
        || '<PrcItem>5000</PrcItem><MontoItem>5000</MontoItem></Detalle>'
        || '</Documento></DTE></SetDTE>'
$f$;

CREATE FUNCTION pg_temp.b64(p_xml TEXT) RETURNS TEXT LANGUAGE sql
AS $f$ SELECT encode(convert_to(p_xml, 'LATIN1'), 'base64') $f$;

DO $$
DECLARE
    g INTEGER; s1 INTEGER; s2 INTEGER; adm INTEGER; b1 INTEGER; b2 INTEGER; caj INTEGER;
    ing INTEGER; prod INTEGER; completa JSONB;
BEGIN
    SELECT id INTO g FROM public.unidades_medida WHERE abreviatura = 'g';
    INSERT INTO public.sucursales (nombre) VALUES ('Ensayo T09 S1') RETURNING id INTO s1;
    INSERT INTO public.sucursales (nombre) VALUES ('Ensayo T09 S2') RETURNING id INTO s2;
    INSERT INTO public.usuarios (nombre, identificador_acceso, password_hash, rol)
        VALUES ('Admin ensayo T09', 'ensayo-t09-admin', 'x', 'admin') RETURNING id INTO adm;
    INSERT INTO public.usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('Bodeguero S1 ensayo T09', 'ensayo-t09-bod1', 'x', 'bodeguero', s1) RETURNING id INTO b1;
    INSERT INTO public.usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('Bodeguero S2 ensayo T09', 'ensayo-t09-bod2', 'x', 'bodeguero', s2) RETURNING id INTO b2;
    INSERT INTO public.usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('Cajero ensayo T09', 'ensayo-t09-cajero', 'x', 'cajero', s1) RETURNING id INTO caj;
    INSERT INTO public.ingredientes (nombre, unidad_id) VALUES ('Ensayo T09 Queso', g) RETURNING id INTO ing;
    INSERT INTO public.productos (nombre, precio_venta) VALUES ('Ensayo T09 Pinguino', 1000) RETURNING id INTO prod;
    -- Si el RUT ya existe en proveedores se usa ese; si no, se crea uno de ensayo.
    INSERT INTO public.proveedores (nombre, rut) VALUES ('Proveedor ensayo T09', '76086428-5')
        ON CONFLICT (rut) DO NOTHING;
    INSERT INTO _casos VALUES (s1, s2, adm, b1, b2, caj, ing, prod);

    completa := jsonb_build_array(
        jsonb_build_object('numero_linea', 1, 'ingrediente_id', ing, 'unidades_por_presentacion', 500.5),
        jsonb_build_object('numero_linea', 2, 'producto_id', prod, 'unidades_por_presentacion', 6),
        jsonb_build_object('numero_linea', 3, 'no_corresponde_inventario', TRUE));

    INSERT INTO _xml VALUES
        ('f1', pg_temp.b64(pg_temp.dte(990003001)), completa),
        ('f2', pg_temp.b64(pg_temp.dte(990003002)), completa);
END $$;

-- Fase A: admin ingresa dos facturas, repite una y consulta ------------------------------

SELECT set_config('request.jwt.claims', json_build_object('role', 'nury_admin', 'user_id', admin)::text, TRUE)
  FROM _casos;
SET LOCAL ROLE nury_admin;

DO $$
DECLARE
    c     _casos%ROWTYPE;
    x     RECORD;
    resp  JSONB;
    lista JSONB;
    f1    JSONB;
    xml   JSONB;
BEGIN
    SELECT * INTO c FROM _casos;

    SELECT * INTO x FROM _xml WHERE caso = 'f1';
    resp := public.fn_ingresar_factura_xml(c.s1, x.b64, 'f1.xml', x.asoc);
    INSERT INTO _ids VALUES ('f1', (resp->>'factura_xml_id')::INTEGER);
    -- Intento repetido desde otra sucursal (queda en intentos_factura_duplicada).
    PERFORM public.fn_ingresar_factura_xml(c.s2, x.b64, 'f1-copia.xml', x.asoc);

    SELECT * INTO x FROM _xml WHERE caso = 'f2';
    resp := public.fn_ingresar_factura_xml(c.s2, x.b64, 'f2.xml', x.asoc);
    INSERT INTO _ids VALUES ('f2', (resp->>'factura_xml_id')::INTEGER);

    -- Solo se miran las facturas de ensayo: la base puede tener otras reales.
    lista := (SELECT jsonb_agg(e) FROM jsonb_array_elements(public.fn_listar_ingresos_factura(500)) e
               WHERE (e->>'folio')::BIGINT IN (990003001, 990003002));
    INSERT INTO _resultados VALUES ('L01 el admin ve las dos facturas, la más reciente primero',
        CASE WHEN jsonb_array_length(lista) = 2 AND lista->0->>'folio' = '990003002'
             THEN 'OK' ELSE 'FALLA: ' || COALESCE(lista::TEXT, 'sin filas') END);

    f1 := lista->1;
    INSERT INTO _resultados VALUES ('L02 cabecera: proveedor, totales, sucursal, quién y cuándo, archivo',
        CASE WHEN f1->>'proveedor' IS NOT NULL AND f1->>'razon_social_emisor' = 'Proveedor de ensayo'
                  AND (f1->>'monto_total')::NUMERIC = 59981 AND f1->>'sucursal' = 'Ensayo T09 S1'
                  AND f1->>'ingresada_por' = 'Admin ensayo T09' AND f1->>'ingresada_en' IS NOT NULL
                  AND f1->>'xml_nombre' = 'f1.xml' AND f1->>'factura_compra_id' IS NOT NULL
             THEN 'OK' ELSE 'FALLA: ' || f1::TEXT END);

    INSERT INTO _resultados VALUES ('L03 materia prima: artículo, unidad, equivalencia y cantidad incorporada',
        CASE WHEN f1->'lineas'->0->>'tipo' = 'ingrediente' AND f1->'lineas'->0->>'articulo' = 'Ensayo T09 Queso'
                  AND f1->'lineas'->0->>'unidad' = 'g'
                  AND (f1->'lineas'->0->>'unidades_por_presentacion')::NUMERIC = 500.5
                  AND (f1->'lineas'->0->>'cantidad_ingreso')::NUMERIC = 10010
                  AND f1->'lineas'->0->>'descripcion' = 'Queso' AND (f1->'lineas'->0->>'cantidad')::NUMERIC = 20
             THEN 'OK' ELSE 'FALLA: ' || (f1->'lineas'->0)::TEXT END);

    INSERT INTO _resultados VALUES ('L04 producto de reventa: en unidades',
        CASE WHEN f1->'lineas'->1->>'tipo' = 'producto' AND f1->'lineas'->1->>'unidad' = 'un'
                  AND (f1->'lineas'->1->>'cantidad_ingreso')::NUMERIC = 96
             THEN 'OK' ELSE 'FALLA: ' || (f1->'lineas'->1)::TEXT END);

    INSERT INTO _resultados VALUES ('L05 línea excluida: sin artículo ni cantidad incorporada',
        CASE WHEN f1->'lineas'->2->>'tipo' = 'no-inventario' AND f1->'lineas'->2->>'articulo' IS NULL
                  AND f1->'lineas'->2->>'cantidad_ingreso' IS NULL AND f1->'lineas'->2->>'descripcion' = 'Flete'
             THEN 'OK' ELSE 'FALLA: ' || (f1->'lineas'->2)::TEXT END);

    INSERT INTO _resultados VALUES ('L06 intento repetido: quién, desde dónde y con qué archivo',
        CASE WHEN jsonb_array_length(f1->'intentos_duplicados') = 1
                  AND f1->'intentos_duplicados'->0->>'usuario' = 'Admin ensayo T09'
                  AND f1->'intentos_duplicados'->0->>'sucursal_solicitada' = 'Ensayo T09 S2'
                  AND f1->'intentos_duplicados'->0->>'xml_nombre' = 'f1-copia.xml'
                  AND jsonb_array_length(lista->0->'intentos_duplicados') = 0
             THEN 'OK' ELSE 'FALLA: ' || (f1->'intentos_duplicados')::TEXT END);

    INSERT INTO _resultados VALUES ('L07 el listado no trae el XML (se descarga aparte)',
        CASE WHEN NOT (f1 ? 'xml_original') AND NOT (f1 ? 'xml_base64') THEN 'OK' ELSE 'FALLA' END);

    INSERT INTO _resultados VALUES ('L08 el límite recorta el listado',
        CASE WHEN jsonb_array_length(public.fn_listar_ingresos_factura(1)) = 1 THEN 'OK' ELSE 'FALLA' END);

    xml := public.fn_xml_factura((SELECT factura_xml_id FROM _ids WHERE caso = 'f1'));
    SELECT * INTO x FROM _xml WHERE caso = 'f1';
    INSERT INTO _resultados VALUES ('X01 el admin descarga el XML original, byte a byte',
        CASE WHEN decode(xml->>'xml_base64', 'base64') = decode(x.b64, 'base64') AND xml->>'xml_nombre' = 'f1.xml'
             THEN 'OK' ELSE 'FALLA: ' || COALESCE(xml->>'xml_nombre', 'sin nombre') END);

    BEGIN
        PERFORM public.fn_xml_factura(-1);
        INSERT INTO _resultados VALUES ('X02 una factura que no existe no se descarga', 'FALLA: se aceptó');
    EXCEPTION WHEN insufficient_privilege THEN
        INSERT INTO _resultados VALUES ('X02 una factura que no existe no se descarga', 'OK');
    END;
END $$;

RESET ROLE;

-- Fase B: bodeguero de S1 --------------------------------------------------------------------

SELECT set_config('request.jwt.claims', json_build_object('role', 'nury_bodeguero', 'user_id', bod_s1)::text, TRUE)
  FROM _casos;
SET LOCAL ROLE nury_bodeguero;

DO $$
DECLARE
    lista JSONB;
BEGIN
    lista := public.fn_listar_ingresos_factura(500);
    INSERT INTO _resultados VALUES ('B01 el bodeguero de S1 solo ve las facturas de su sucursal',
        CASE WHEN jsonb_array_length(lista) >= 1
                  AND NOT EXISTS (SELECT 1 FROM jsonb_array_elements(lista) e
                                   WHERE (e->>'sucursal_id')::INTEGER <> (SELECT s1 FROM _casos))
                  AND EXISTS (SELECT 1 FROM jsonb_array_elements(lista) e WHERE e->>'folio' = '990003001')
             THEN 'OK' ELSE 'FALLA: ' || lista::TEXT END);

    INSERT INTO _resultados VALUES ('B02 y ve el intento repetido hecho desde otra sucursal sobre su factura',
        CASE WHEN (SELECT jsonb_array_length(e->'intentos_duplicados') FROM jsonb_array_elements(lista) e
                    WHERE e->>'folio' = '990003001') = 1
             THEN 'OK' ELSE 'FALLA' END);

    PERFORM public.fn_xml_factura((SELECT factura_xml_id FROM _ids WHERE caso = 'f1'));
    INSERT INTO _resultados VALUES ('B03 descarga el XML de su sucursal', 'OK');

    BEGIN
        PERFORM public.fn_xml_factura((SELECT factura_xml_id FROM _ids WHERE caso = 'f2'));
        INSERT INTO _resultados VALUES ('B04 no descarga el XML de otra sucursal', 'FALLA: se aceptó');
    EXCEPTION WHEN insufficient_privilege THEN
        INSERT INTO _resultados VALUES ('B04 no descarga el XML de otra sucursal', 'OK');
    END;
END $$;

RESET ROLE;

-- Fase C: bodeguero de S2 --------------------------------------------------------------------

SELECT set_config('request.jwt.claims', json_build_object('role', 'nury_bodeguero', 'user_id', bod_s2)::text, TRUE)
  FROM _casos;
SET LOCAL ROLE nury_bodeguero;

DO $$
DECLARE
    lista JSONB;
BEGIN
    lista := public.fn_listar_ingresos_factura(500);
    INSERT INTO _resultados VALUES ('C01 el bodeguero de S2 ve su factura y no la de S1',
        CASE WHEN EXISTS (SELECT 1 FROM jsonb_array_elements(lista) e WHERE e->>'folio' = '990003002')
                  AND NOT EXISTS (SELECT 1 FROM jsonb_array_elements(lista) e WHERE e->>'folio' = '990003001')
             THEN 'OK' ELSE 'FALLA: ' || lista::TEXT END);
END $$;

RESET ROLE;

-- Fase D: sin permiso ------------------------------------------------------------------------

SELECT set_config('request.jwt.claims', json_build_object('role', 'nury_cajero', 'user_id', cajero)::text, TRUE)
  FROM _casos;
SET LOCAL ROLE nury_cajero;

DO $$
BEGIN
    BEGIN
        PERFORM public.fn_listar_ingresos_factura(10);
        INSERT INTO _resultados VALUES ('D01 el cajero no consulta ingresos', 'FALLA: se aceptó');
    EXCEPTION WHEN insufficient_privilege THEN
        INSERT INTO _resultados VALUES ('D01 el cajero no consulta ingresos', 'OK');
    END;
    BEGIN
        PERFORM public.fn_xml_factura((SELECT factura_xml_id FROM _ids WHERE caso = 'f1'));
        INSERT INTO _resultados VALUES ('D02 el cajero no descarga XML', 'FALLA: se aceptó');
    EXCEPTION WHEN insufficient_privilege THEN
        INSERT INTO _resultados VALUES ('D02 el cajero no descarga XML', 'OK');
    END;
END $$;

RESET ROLE;

SET LOCAL ROLE web_anon;

DO $$
BEGIN
    PERFORM public.fn_listar_ingresos_factura(10);
    INSERT INTO _resultados VALUES ('D03 un anónimo no consulta ingresos', 'FALLA: se aceptó');
EXCEPTION WHEN insufficient_privilege THEN
    INSERT INTO _resultados VALUES ('D03 un anónimo no consulta ingresos', 'OK');
END $$;

RESET ROLE;

-- Un JWT cuyo rol no coincide con el rol real del usuario no vale (rol bodeguero, usuario admin).
SELECT set_config('request.jwt.claims', json_build_object('role', 'nury_bodeguero', 'user_id', admin)::text, TRUE)
  FROM _casos;
SET LOCAL ROLE nury_bodeguero;

DO $$
BEGIN
    PERFORM public.fn_listar_ingresos_factura(10);
    INSERT INTO _resultados VALUES ('D04 un JWT con rol que no coincide con el usuario no consulta', 'FALLA: se aceptó');
EXCEPTION WHEN insufficient_privilege THEN
    INSERT INTO _resultados VALUES ('D04 un JWT con rol que no coincide con el usuario no consulta', 'OK');
END $$;

RESET ROLE;

-- pgAdmin solo muestra el resultado de la última instrucción: por eso cada prueba se
-- informa como aviso (pestaña «Messages») y el ensayo falla con error si alguna no da OK.
DO $$
DECLARE
    r       RECORD;
    fallas  INTEGER := 0;
BEGIN
    FOR r IN SELECT prueba, resultado FROM _resultados ORDER BY prueba LOOP
        RAISE NOTICE '% | %', r.resultado, r.prueba;
        IF r.resultado <> 'OK' THEN
            fallas := fallas + 1;
        END IF;
    END LOOP;

    IF fallas > 0 THEN
        RAISE EXCEPTION 'El ensayo tiene % prueba(s) con FALLA: revisa los avisos de arriba', fallas;
    END IF;
    RAISE NOTICE 'ENSAYO COMPLETO: todas las pruebas dieron OK';
END $$;

ROLLBACK;
