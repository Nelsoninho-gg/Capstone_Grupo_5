-- Requiere los roles JWT nury_admin, nury_cajero, nury_bodeguero y web_anon.
-- El JWT de login debe identificar al usuario con user_id, usuario_id, sub o id.
-- Aplicar con el propietario de las tablas. No modifica ventas ni productos existentes.
BEGIN;

-- El Maestro ya usa este campo; algunos esquemas iniciales todavía no lo incluyen.
ALTER TABLE public.productos ADD COLUMN IF NOT EXISTS precio_compra NUMERIC(12,2);

CREATE OR REPLACE FUNCTION public.fn_usuario_actual_id()
RETURNS INTEGER
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
    WITH sesion AS (
        SELECT COALESCE(NULLIF(current_setting('request.jwt.claims', TRUE), ''), '{}')::jsonb AS claims
    ), identidad AS (
        SELECT claims->>'role' AS rol,
               COALESCE(claims->>'user_id', claims->>'usuario_id', claims->>'sub', claims->>'id') AS id
          FROM sesion
    )
    SELECT u.id
      FROM public.usuarios u, identidad i
     WHERE u.id = CASE WHEN i.id ~ '^[0-9]{1,10}$' THEN i.id::bigint ELSE NULL END
       AND u.activo
       AND CASE WHEN u.rol IN ('admin', 'administrador') THEN 'nury_admin'
                WHEN u.rol = 'cajero' THEN 'nury_cajero' END = i.rol;
$$;

REVOKE ALL ON FUNCTION public.fn_usuario_actual_id() FROM PUBLIC, web_anon, nury_bodeguero;
GRANT EXECUTE ON FUNCTION public.fn_usuario_actual_id() TO nury_admin, nury_cajero;

-- El historial y su detalle quedan limitados al cajero autenticado.
ALTER TABLE public.ventas ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.detalle_venta ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS ventas_admin ON public.ventas;
CREATE POLICY ventas_admin ON public.ventas TO nury_admin USING (TRUE) WITH CHECK (TRUE);
DROP POLICY IF EXISTS ventas_cajero_lectura ON public.ventas;
CREATE POLICY ventas_cajero_lectura ON public.ventas FOR SELECT TO nury_cajero
    USING (cajero_id = (SELECT public.fn_usuario_actual_id()));
DROP POLICY IF EXISTS ventas_cajero_limite ON public.ventas;
CREATE POLICY ventas_cajero_limite ON public.ventas AS RESTRICTIVE FOR SELECT TO nury_cajero
    USING (cajero_id = (SELECT public.fn_usuario_actual_id()));

DROP POLICY IF EXISTS detalle_venta_admin ON public.detalle_venta;
CREATE POLICY detalle_venta_admin ON public.detalle_venta TO nury_admin USING (TRUE) WITH CHECK (TRUE);
DROP POLICY IF EXISTS detalle_venta_cajero_lectura ON public.detalle_venta;
CREATE POLICY detalle_venta_cajero_lectura ON public.detalle_venta FOR SELECT TO nury_cajero
    USING (EXISTS (SELECT 1 FROM public.ventas v WHERE v.id = venta_id));
DROP POLICY IF EXISTS detalle_venta_cajero_limite ON public.detalle_venta;
CREATE POLICY detalle_venta_cajero_limite ON public.detalle_venta AS RESTRICTIVE FOR SELECT TO nury_cajero
    USING (EXISTS (SELECT 1 FROM public.ventas v WHERE v.id = venta_id));

GRANT USAGE ON SCHEMA public TO nury_admin, nury_cajero;
GRANT SELECT ON public.ventas, public.detalle_venta, public.productos TO nury_admin, nury_cajero;
REVOKE INSERT, UPDATE, DELETE ON public.ventas, public.detalle_venta FROM PUBLIC, web_anon, nury_cajero;
REVOKE INSERT, UPDATE, DELETE ON public.productos FROM PUBLIC, web_anon, nury_cajero;

-- También elimina grants por columna de versiones anteriores de la API.
DO $$
DECLARE
    tabla TEXT;
    columnas TEXT;
BEGIN
    FOREACH tabla IN ARRAY ARRAY['ventas', 'detalle_venta', 'productos'] LOOP
        SELECT string_agg(quote_ident(column_name), ', ')
          INTO columnas FROM information_schema.columns
         WHERE table_schema = 'public' AND table_name = tabla;
        EXECUTE format('REVOKE INSERT (%s), UPDATE (%s) ON public.%I FROM PUBLIC, web_anon, nury_cajero',
                       columnas, columnas, tabla);
    END LOOP;
END;
$$;

-- El cajero mantiene alta y edición de datos, sin eliminar ni cambiar activo.
GRANT INSERT (nombre, categoria, precio_compra, precio_venta, codigo_barras),
      UPDATE (nombre, categoria, precio_compra, precio_venta, codigo_barras)
    ON public.productos TO nury_cajero;
GRANT USAGE ON SEQUENCE public.productos_id_seq TO nury_cajero;

CREATE OR REPLACE FUNCTION public.fn_anular_venta(p_venta_id INTEGER, p_motivo TEXT)
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    actor_id INTEGER := public.fn_usuario_actual_id();
    actor_rol TEXT;
    venta public.ventas%ROWTYPE;
BEGIN
    IF actor_id IS NULL THEN
        RAISE EXCEPTION 'La sesión no identifica a un usuario autorizado' USING ERRCODE = '42501';
    END IF;
    SELECT rol INTO actor_rol FROM public.usuarios WHERE id = actor_id;
    IF p_motivo IS NULL OR length(btrim(p_motivo)) < 5 OR length(btrim(p_motivo)) > 250 THEN
        RAISE EXCEPTION 'El motivo debe tener entre 5 y 250 caracteres' USING ERRCODE = '22023';
    END IF;

    -- Bloquea la fila para impedir dos anulaciones concurrentes.
    SELECT * INTO venta FROM public.ventas WHERE id = p_venta_id FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'La venta no existe o ya estaba anulada.' USING ERRCODE = '22023';
    END IF;
    IF actor_rol = 'cajero' AND venta.cajero_id IS DISTINCT FROM actor_id THEN
        RAISE EXCEPTION 'Solo puedes anular tus propias ventas' USING ERRCODE = '42501';
    END IF;
    IF venta.anulada THEN
        RAISE EXCEPTION 'La venta no existe o ya estaba anulada.' USING ERRCODE = '22023';
    END IF;

    UPDATE public.ventas
       SET anulada = TRUE, anulada_por = actor_id,
           anulada_en = clock_timestamp() AT TIME ZONE 'UTC', anulada_motivo = btrim(p_motivo)
     WHERE id = p_venta_id;
    RETURN p_venta_id;
END;
$$;

REVOKE ALL ON FUNCTION public.fn_anular_venta(integer, text) FROM PUBLIC, web_anon, nury_bodeguero;
GRANT EXECUTE ON FUNCTION public.fn_anular_venta(integer, text) TO nury_admin, nury_cajero;

NOTIFY pgrst, 'reload schema';
COMMIT;
