-- Requiere los roles JWT existentes: nury_admin, nury_cajero,
-- nury_bodeguero y web_anon. No altera las sucursales registradas.
BEGIN;

ALTER TABLE public.sucursales
    DROP CONSTRAINT IF EXISTS sucursales_nombre_no_vacio;
ALTER TABLE public.sucursales
    ADD CONSTRAINT sucursales_nombre_no_vacio CHECK (btrim(nombre) <> '');

CREATE OR REPLACE FUNCTION public.fn_normalizar_sucursal()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public, pg_temp
AS $$
BEGIN
    NEW.nombre := btrim(NEW.nombre);
    NEW.direccion := NULLIF(btrim(NEW.direccion), '');
    NEW.telefono := NULLIF(btrim(NEW.telefono), '');
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_normalizar_sucursal ON public.sucursales;
CREATE TRIGGER trg_normalizar_sucursal
BEFORE INSERT OR UPDATE OF nombre, direccion, telefono ON public.sucursales
FOR EACH ROW EXECUTE FUNCTION public.fn_normalizar_sucursal();

CREATE OR REPLACE FUNCTION public.crear_sucursal(
    p_nombre VARCHAR(120),
    p_direccion VARCHAR(200) DEFAULT NULL,
    p_telefono VARCHAR(30) DEFAULT NULL,
    p_activo BOOLEAN DEFAULT TRUE
)
RETURNS TABLE (
    id INTEGER,
    nombre VARCHAR(120),
    direccion VARCHAR(200),
    telefono VARCHAR(30),
    activo BOOLEAN,
    creado_en TIMESTAMP
)
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = public, pg_temp
AS $$
BEGIN
    RETURN QUERY
    INSERT INTO public.sucursales AS s (nombre, direccion, telefono, activo)
    VALUES (p_nombre, p_direccion, p_telefono, p_activo)
    RETURNING s.id, s.nombre, s.direccion, s.telefono, s.activo, s.creado_en;
END;
$$;

-- Solo el administrador puede dar de alta o editar sucursales.
-- Se conservan los permisos de lectura existentes de cajero y bodeguero.
REVOKE INSERT, UPDATE ON public.sucursales
    FROM PUBLIC, web_anon, nury_cajero, nury_bodeguero, nury_admin;
GRANT USAGE ON SCHEMA public TO nury_admin;
GRANT SELECT ON public.sucursales TO nury_admin;
GRANT INSERT (nombre, direccion, telefono, activo),
      UPDATE (nombre, direccion, telefono, activo)
    ON public.sucursales TO nury_admin;
GRANT USAGE ON SEQUENCE public.sucursales_id_seq TO nury_admin;

REVOKE ALL ON FUNCTION public.crear_sucursal(
    character varying, character varying, character varying, boolean
) FROM PUBLIC, web_anon, nury_cajero, nury_bodeguero;
GRANT EXECUTE ON FUNCTION public.crear_sucursal(
    character varying, character varying, character varying, boolean
) TO nury_admin;

NOTIFY pgrst, 'reload schema';
COMMIT;
