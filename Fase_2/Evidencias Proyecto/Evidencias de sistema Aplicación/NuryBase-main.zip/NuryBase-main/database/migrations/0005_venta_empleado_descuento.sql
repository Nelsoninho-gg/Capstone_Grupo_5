-- H2.12 T03 — Venta a empleados: cálculo del descuento en el servidor.
--
-- fn_registrar_venta recibe dos parámetros nuevos, ambos opcionales:
--   - p_tipo_venta:  'normal' (por defecto) o 'empleado'.
--   - p_empleado_id: usuario que compra; obligatorio si la venta es a empleado.
--
-- En una venta a empleado la base de datos calcula el descuento fijo del 30%
-- sobre el total de la venta, redondeado a pesos, y guarda:
--   descuento_porcentaje = 30, descuento_monto y total = subtotal − descuento.
-- El porcentaje no se recibe desde el POS: no es editable.
--
-- No modifica precios: detalle_venta conserva precio_lista y precio_unitario
-- de cada producto, y el maestro de productos no se toca.
--
-- El POS actual sigue funcionando sin cambios: si no envía los parámetros
-- nuevos, la venta se registra como 'normal' igual que antes.
--
-- Cuerpo basado en 0003_apertura_control_turno.sql (exige turno activo).
-- Requiere 0004_venta_empleado.sql aplicada antes.

BEGIN;

-- La función original es de nury_admin: se recrea con ese mismo dueño.
SET LOCAL ROLE nury_admin;

-- Agregar parámetros cambia la firma, así que la función se reemplaza.
DROP FUNCTION public.fn_registrar_venta(integer, integer, character varying, jsonb);

CREATE FUNCTION public.fn_registrar_venta(
    p_sucursal_id INTEGER,
    p_cajero_id INTEGER,
    p_medio_pago CHARACTER VARYING,
    p_items JSONB,
    p_tipo_venta CHARACTER VARYING DEFAULT 'normal',
    p_empleado_id INTEGER DEFAULT NULL
)
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'pg_catalog', 'public', 'pg_temp'
AS $function$
DECLARE
    -- Descuento fijo de venta a empleado (H2.12). Por ahora no es editable.
    c_descuento_empleado CONSTANT NUMERIC(5,2) := 30;

    v_venta_id      INTEGER;
    v_turno_id      INTEGER;
    v_tipo_venta    VARCHAR(20) := COALESCE(p_tipo_venta, 'normal');
    item            JSONB;
    v_producto_id   INTEGER;
    v_precio_lista  NUMERIC(12,2);
    v_precio_final  NUMERIC(12,2);
    v_promocion_id  INTEGER;
    v_cantidad      NUMERIC(12,3);
    v_subtotal      NUMERIC(12,2);
    v_descuento     NUMERIC(12,2);
BEGIN
    IF jsonb_array_length(p_items) = 0 THEN
        RAISE EXCEPTION 'La venta no tiene productos';
    END IF;

    IF v_tipo_venta NOT IN ('normal', 'empleado') THEN
        RAISE EXCEPTION 'Tipo de venta no válido: %', v_tipo_venta
            USING ERRCODE = '22023';
    END IF;

    IF v_tipo_venta = 'empleado' THEN
        IF p_empleado_id IS NULL THEN
            RAISE EXCEPTION 'Debes indicar el empleado que compra'
                USING ERRCODE = '22023';
        END IF;

        IF NOT EXISTS (
            SELECT 1 FROM public.usuarios WHERE id = p_empleado_id AND activo = TRUE
        ) THEN
            RAISE EXCEPTION 'El empleado no existe o está deshabilitado'
                USING ERRCODE = '22023';
        END IF;
    ELSIF p_empleado_id IS NOT NULL THEN
        RAISE EXCEPTION 'Una venta normal no lleva empleado'
            USING ERRCODE = '22023';
    END IF;

    SELECT id INTO v_turno_id
      FROM public.turnos
     WHERE usuario_id = p_cajero_id
       AND sucursal_id = p_sucursal_id
       AND hora_fin IS NULL
     ORDER BY hora_inicio DESC
     LIMIT 1;

    IF v_turno_id IS NULL THEN
        RAISE EXCEPTION 'No hay un turno activo para este cajero en esta sucursal; debes abrir turno antes de vender'
            USING ERRCODE = '28000';
    END IF;

    INSERT INTO ventas (sucursal_id, cajero_id, medio_pago, turno_id, tipo_venta, empleado_id)
    VALUES (p_sucursal_id, p_cajero_id, p_medio_pago, v_turno_id, v_tipo_venta, p_empleado_id)
    RETURNING id INTO v_venta_id;

    FOR item IN SELECT * FROM jsonb_array_elements(p_items)
    LOOP
        SELECT id, precio_venta INTO v_producto_id, v_precio_lista
          FROM productos
         WHERE nombre = item->>'producto' AND activo = TRUE;

        IF v_producto_id IS NULL THEN
            RAISE EXCEPTION 'Producto no encontrado o inactivo: %', item->>'producto';
        END IF;

        v_cantidad     := (item->>'cantidad')::NUMERIC;
        v_promocion_id := NULLIF(item->>'promocion_id', '')::INTEGER;
        v_precio_final := COALESCE((item->>'precio_unitario')::NUMERIC, v_precio_lista);

        INSERT INTO detalle_venta (venta_id, producto_id, promocion_id, cantidad, precio_lista, precio_unitario)
        VALUES (v_venta_id, v_producto_id, v_promocion_id, v_cantidad, v_precio_lista, v_precio_final);
    END LOOP;

    -- El trigger trg_actualizar_total_venta ya dejó total = suma de los
    -- subtotales. En una venta a empleado se descuenta el 30% sobre ese
    -- total, redondeado a pesos.
    IF v_tipo_venta = 'empleado' THEN
        SELECT COALESCE(SUM(subtotal), 0) INTO v_subtotal
          FROM detalle_venta
         WHERE venta_id = v_venta_id;

        v_descuento := ROUND(v_subtotal * c_descuento_empleado / 100, 0);

        UPDATE ventas
           SET descuento_porcentaje = c_descuento_empleado,
               descuento_monto      = v_descuento,
               total                = v_subtotal - v_descuento
         WHERE id = v_venta_id;
    END IF;

    RETURN v_venta_id;
END;
$function$;

-- Mismos permisos que tenía la función original (PUBLIC, nury_admin y nury_cajero).
GRANT EXECUTE ON FUNCTION public.fn_registrar_venta(integer, integer, character varying, jsonb, character varying, integer)
    TO PUBLIC, nury_admin, nury_cajero;

COMMIT;
