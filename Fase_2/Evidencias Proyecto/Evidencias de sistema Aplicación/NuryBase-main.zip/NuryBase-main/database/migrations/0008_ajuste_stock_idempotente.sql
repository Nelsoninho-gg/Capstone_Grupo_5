-- H3.6 T06 - Reintentos de un ajuste de stock sin descuentos ni aumentos repetidos.
--
-- Problema: si la conexión se corta después de que fn_ajustar_stock aplicó el
-- ajuste pero antes de que llegue la respuesta, la pantalla no sabe si se aplicó.
-- Al reintentar, la base no tenía cómo reconocer la operación y la aplicaba otra vez.
--
-- Solución: la pantalla manda una clave (UUID) por operación y la repite en cada
-- reintento del mismo ajuste.
--   - Si la clave ya existe en el kardex, se devuelve ese movimiento sin tocar el stock.
--   - Si existe con otros datos (sucursal, ítem o cantidad), se rechaza.
--   - Un bloqueo por clave impide que dos reintentos simultáneos la apliquen dos veces;
--     además, un índice único lo impide en la base aunque alguien se salte la función.
--   - Sin clave (p_clave NULL) se comporta igual que antes.
-- Los ajustes simultáneos de un mismo ítem ya los ordena el FOR UPDATE de la fila de
-- stock: cada uno suma o resta sobre el stock que dejó el anterior.
--
-- Contenido:
--   T01  columna clave_idempotencia en movimientos_stock
--   T02  índice único de la clave
--   T03  fn_ajustar_stock con p_clave (reemplaza la de 0005_ajuste_stock.sql)
--
-- Requiere: 0005_ajuste_stock.sql.
--
-- ANTES DE APLICAR EN PRODUCCIÓN:
--   a) Confirmar que fn_ajustar_stock de producción es la de 0005 (T03 la reemplaza completa):
--        SELECT pg_get_functiondef('public.fn_ajustar_stock(integer,numeric,text,integer,integer)'::regprocedure);
--   b) Correr database/tests/ajuste_stock_idempotente.sql en una base de pruebas.
--   c) Después de aplicar: NOTIFY pgrst, 'reload schema';
--   d) Desplegar la pantalla que envía p_clave DESPUÉS de esta migración: la función
--      anterior no conoce p_clave y PostgREST rechazaría el ajuste (PGRST202).

BEGIN;

-- T01) Clave de la operación que originó el movimiento --------------------------
ALTER TABLE public.movimientos_stock
    ADD COLUMN IF NOT EXISTS clave_idempotencia UUID;

-- T02) Una clave, un solo movimiento -------------------------------------------
CREATE UNIQUE INDEX IF NOT EXISTS ux_movimientos_clave_idempotencia
    ON public.movimientos_stock (clave_idempotencia)
    WHERE clave_idempotencia IS NOT NULL;

-- T03) fn_ajustar_stock con clave -----------------------------------------------
-- Se elimina la firma anterior: si convivieran las dos, PostgREST no sabría cuál llamar.
DROP FUNCTION IF EXISTS public.fn_ajustar_stock(integer, numeric, text, integer, integer);

CREATE FUNCTION public.fn_ajustar_stock(
    p_sucursal_id    INTEGER,
    p_cantidad       NUMERIC,
    p_motivo         TEXT,
    p_ingrediente_id INTEGER DEFAULT NULL,
    p_producto_id    INTEGER DEFAULT NULL,
    p_clave          UUID DEFAULT NULL
)
RETURNS public.movimientos_stock
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $function$
DECLARE
    v_motivo       TEXT := btrim(COALESCE(p_motivo, ''));
    v_stock_previo NUMERIC(12,3);
    v_nuevo_stock  NUMERIC(12,3);
    v_mov          public.movimientos_stock%ROWTYPE;
BEGIN
    -- Debe indicarse exactamente uno de los dos ítems.
    IF (p_ingrediente_id IS NULL) = (p_producto_id IS NULL) THEN
        RAISE EXCEPTION 'Indica un ingrediente o un producto (solo uno de los dos)'
            USING ERRCODE = '22023';
    END IF;

    -- Reintento de una operación ya registrada: se devuelve el mismo movimiento.
    IF p_clave IS NOT NULL THEN
        PERFORM pg_advisory_xact_lock(hashtextextended(p_clave::text, 0));

        SELECT * INTO v_mov
          FROM public.movimientos_stock
         WHERE clave_idempotencia = p_clave;

        IF FOUND THEN
            IF v_mov.tipo_movimiento <> 'ajuste'
               OR v_mov.sucursal_id <> p_sucursal_id
               OR v_mov.ingrediente_id IS DISTINCT FROM p_ingrediente_id
               OR v_mov.producto_id IS DISTINCT FROM p_producto_id
               OR v_mov.cantidad <> round(p_cantidad, 3) THEN
                RAISE EXCEPTION 'Este ajuste ya se registró con otros datos. Revisa el stock antes de registrar uno nuevo'
                    USING ERRCODE = '22023';
            END IF;
            RETURN v_mov;
        END IF;
    END IF;

    IF p_cantidad IS NULL OR p_cantidad = 0 THEN
        RAISE EXCEPTION 'La cantidad del ajuste es obligatoria y no puede ser 0'
            USING ERRCODE = '22023';
    END IF;

    IF v_motivo = '' THEN
        RAISE EXCEPTION 'El motivo del ajuste es obligatorio'
            USING ERRCODE = '22023';
    END IF;

    IF NOT EXISTS (SELECT 1 FROM public.sucursales WHERE id = p_sucursal_id) THEN
        RAISE EXCEPTION 'La sucursal indicada no existe'
            USING ERRCODE = '23503';
    END IF;

    IF p_ingrediente_id IS NOT NULL THEN
        IF NOT EXISTS (SELECT 1 FROM public.ingredientes WHERE id = p_ingrediente_id) THEN
            RAISE EXCEPTION 'El ingrediente indicado no existe'
                USING ERRCODE = '23503';
        END IF;

        INSERT INTO public.stock_sucursal (ingrediente_id, sucursal_id, stock_actual, stock_minimo)
        VALUES (p_ingrediente_id, p_sucursal_id, 0, 0)
        ON CONFLICT (ingrediente_id, sucursal_id) DO NOTHING;

        SELECT stock_actual INTO v_stock_previo
          FROM public.stock_sucursal
         WHERE ingrediente_id = p_ingrediente_id AND sucursal_id = p_sucursal_id
         FOR UPDATE;
    ELSE
        IF NOT EXISTS (SELECT 1 FROM public.productos WHERE id = p_producto_id) THEN
            RAISE EXCEPTION 'El producto indicado no existe'
                USING ERRCODE = '23503';
        END IF;

        -- Un producto con receta no tiene stock propio: su stock son sus ingredientes.
        IF EXISTS (SELECT 1 FROM public.recetas WHERE producto_id = p_producto_id) THEN
            RAISE EXCEPTION 'Este producto tiene receta: su stock se ajusta a través de sus ingredientes'
                USING ERRCODE = '22023';
        END IF;

        INSERT INTO public.stock_producto_sucursal (producto_id, sucursal_id, stock_actual, stock_minimo)
        VALUES (p_producto_id, p_sucursal_id, 0, 0)
        ON CONFLICT (producto_id, sucursal_id) DO NOTHING;

        SELECT stock_actual INTO v_stock_previo
          FROM public.stock_producto_sucursal
         WHERE producto_id = p_producto_id AND sucursal_id = p_sucursal_id
         FOR UPDATE;
    END IF;

    v_nuevo_stock := v_stock_previo + p_cantidad;

    -- Un ajuste de salida no puede dejar el stock en negativo. Una entrada sí se
    -- permite aunque el stock siga negativo (p. ej. para regularizar ventas de prueba).
    IF p_cantidad < 0 AND v_nuevo_stock < 0 THEN
        RAISE EXCEPTION 'El ajuste dejaría el stock en negativo (actual: %, ajuste: %)',
            v_stock_previo, p_cantidad
            USING ERRCODE = '23514';
    END IF;

    IF p_ingrediente_id IS NOT NULL THEN
        UPDATE public.stock_sucursal
           SET stock_actual = v_nuevo_stock, actualizado_en = now()
         WHERE ingrediente_id = p_ingrediente_id AND sucursal_id = p_sucursal_id;
    ELSE
        UPDATE public.stock_producto_sucursal
           SET stock_actual = v_nuevo_stock, actualizado_en = now()
         WHERE producto_id = p_producto_id AND sucursal_id = p_sucursal_id;
    END IF;

    INSERT INTO public.movimientos_stock
        (ingrediente_id, producto_id, sucursal_id, tipo_movimiento, cantidad,
         stock_resultante, referencia_tipo, nota, clave_idempotencia)
    VALUES
        (p_ingrediente_id, p_producto_id, p_sucursal_id, 'ajuste', p_cantidad,
         v_nuevo_stock, 'ajuste_manual', v_motivo, p_clave)
    RETURNING * INTO v_mov;

    RETURN v_mov;
END;
$function$;

-- Solo roles de inventario. PostgREST publica únicamente lo ejecutable por el rol de la sesión.
REVOKE ALL ON FUNCTION public.fn_ajustar_stock(integer, numeric, text, integer, integer, uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.fn_ajustar_stock(integer, numeric, text, integer, integer, uuid)
    TO nury_admin, nury_bodeguero;

COMMIT;
