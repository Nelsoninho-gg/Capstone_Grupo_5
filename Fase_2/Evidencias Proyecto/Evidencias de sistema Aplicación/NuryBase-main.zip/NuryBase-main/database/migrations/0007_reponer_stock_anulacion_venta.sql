-- H3.2 T08 - Reponer el stock al anular una venta.
--
-- Al anular una venta se devuelve al stock exactamente lo que esa venta
-- descontó, con movimientos de signo contrario en el kardex:
--   - Se leen los movimientos 'venta' que dejó fn_aplicar_venta para esa venta
--     (referencia_tipo = 'venta', referencia_id = id de la venta) y se suma por
--     ítem (ingrediente o producto de reventa) y sucursal.
--   - Por cada ítem se inserta un movimiento 'anulacion_venta' con la cantidad
--     contraria, en la MISMA sucursal del descuento, vinculado a la venta
--     original (mismo referencia_tipo / referencia_id) y se suma al stock.
--   - Se usa el kardex y no la receta actual: si la receta cambió después de la
--     venta, igual se devuelve lo que realmente se descontó.
--   - Una venta sin movimientos (p. ej. anterior al control de stock) se anula
--     igual; simplemente no hay nada que reponer.
--
-- Una sola vez por anulación:
--   - fn_anular_venta ya bloquea la fila de la venta y rechaza las anuladas.
--   - Además, un índice único impide en la base que exista más de una
--     reposición por venta, ítem y sucursal, aunque alguien se salte la función.
--
-- Todo ocurre en la misma transacción que marca la venta como anulada: si la
-- reposición falla, la venta tampoco queda anulada.
--
-- Contenido:
--   T01  tipo de movimiento 'anulacion_venta'
--   T02  índice único de reposición por venta
--   T03  fn_reponer_stock_anulacion (interna, no expuesta en la API)
--   T04  fn_anular_venta llama a la reposición
--
-- Requiere: 0004, 0005, 0006 y 20261012_permisos_cajero.sql.
--
-- ANTES DE APLICAR EN PRODUCCIÓN:
--   a) Comparar fn_anular_venta de producción con la de este script (T04 la
--      reemplaza completa; solo se agrega la llamada a la reposición):
--        SELECT pg_get_functiondef('public.fn_anular_venta(integer,text)'::regprocedure);
--   b) Confirmar el CHECK actual del tipo de movimiento:
--        SELECT conname, pg_get_constraintdef(oid) FROM pg_constraint
--         WHERE conrelid = 'public.movimientos_stock'::regclass AND contype = 'c';
--   c) Correr primero 0007_reponer_stock_anulacion_venta.ENSAYO.sql (termina en ROLLBACK).
--   d) Después de aplicar: NOTIFY pgrst, 'reload schema';

BEGIN;

-- T01) Nuevo tipo de movimiento ------------------------------------------------
-- Se reemplaza el CHECK que lista los tipos (se busca por su definición, sin
-- depender del nombre que le haya puesto Postgres).
DO $$
DECLARE
    v_con TEXT;
BEGIN
    FOR v_con IN
        SELECT conname FROM pg_constraint
         WHERE conrelid = 'public.movimientos_stock'::regclass
           AND contype = 'c'
           AND pg_get_constraintdef(oid) ILIKE '%tipo_movimiento%'
    LOOP
        EXECUTE format('ALTER TABLE public.movimientos_stock DROP CONSTRAINT %I', v_con);
    END LOOP;
END $$;

ALTER TABLE public.movimientos_stock
    ADD CONSTRAINT movimientos_stock_tipo_movimiento_check
    CHECK (tipo_movimiento IN ('compra', 'venta', 'ajuste', 'merma', 'anulacion_venta'));

-- T02) Una sola reposición por venta, ítem y sucursal -------------------------
CREATE UNIQUE INDEX IF NOT EXISTS ux_movimientos_anulacion_venta
    ON public.movimientos_stock (
        referencia_id, sucursal_id,
        COALESCE(ingrediente_id, 0), COALESCE(producto_id, 0)
    )
    WHERE tipo_movimiento = 'anulacion_venta';

-- T03) Reposición del stock de una venta ---------------------------------------
-- Interna: la llama fn_anular_venta. No se expone en PostgREST.
CREATE OR REPLACE FUNCTION public.fn_reponer_stock_anulacion(p_venta_id INTEGER, p_motivo TEXT)
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $function$
DECLARE
    mov            RECORD;
    v_reponer      NUMERIC(12,3);
    v_stock_previo NUMERIC(12,3);
    v_nuevo_stock  NUMERIC(12,3);
    v_nota         TEXT := format('Anulación de la venta #%s', p_venta_id)
                           || COALESCE(': ' || NULLIF(btrim(p_motivo), ''), '');
    v_filas        INTEGER := 0;
BEGIN
    IF EXISTS (SELECT 1 FROM public.movimientos_stock
                WHERE tipo_movimiento = 'anulacion_venta'
                  AND referencia_tipo = 'venta'
                  AND referencia_id = p_venta_id) THEN
        RAISE EXCEPTION 'El stock de la venta #% ya fue repuesto', p_venta_id
            USING ERRCODE = '23505';
    END IF;

    -- Orden fijo (ingredientes y luego productos, por id) para evitar bloqueos cruzados.
    FOR mov IN
        SELECT sucursal_id, ingrediente_id, producto_id, SUM(cantidad) AS total
          FROM public.movimientos_stock
         WHERE tipo_movimiento = 'venta'
           AND referencia_tipo = 'venta'
           AND referencia_id = p_venta_id
         GROUP BY sucursal_id, ingrediente_id, producto_id
        HAVING SUM(cantidad) <> 0
         ORDER BY sucursal_id, ingrediente_id NULLS LAST, producto_id NULLS LAST
    LOOP
        v_reponer := -mov.total;   -- la venta descontó (negativo); se devuelve en positivo

        IF mov.ingrediente_id IS NOT NULL THEN
            INSERT INTO public.stock_sucursal (ingrediente_id, sucursal_id, stock_actual, stock_minimo)
            VALUES (mov.ingrediente_id, mov.sucursal_id, 0, 0)
            ON CONFLICT (ingrediente_id, sucursal_id) DO NOTHING;

            SELECT stock_actual INTO v_stock_previo
              FROM public.stock_sucursal
             WHERE ingrediente_id = mov.ingrediente_id AND sucursal_id = mov.sucursal_id
             FOR UPDATE;

            v_nuevo_stock := v_stock_previo + v_reponer;

            UPDATE public.stock_sucursal
               SET stock_actual = v_nuevo_stock, actualizado_en = now()
             WHERE ingrediente_id = mov.ingrediente_id AND sucursal_id = mov.sucursal_id;
        ELSE
            INSERT INTO public.stock_producto_sucursal (producto_id, sucursal_id, stock_actual, stock_minimo)
            VALUES (mov.producto_id, mov.sucursal_id, 0, 0)
            ON CONFLICT (producto_id, sucursal_id) DO NOTHING;

            SELECT stock_actual INTO v_stock_previo
              FROM public.stock_producto_sucursal
             WHERE producto_id = mov.producto_id AND sucursal_id = mov.sucursal_id
             FOR UPDATE;

            v_nuevo_stock := v_stock_previo + v_reponer;

            UPDATE public.stock_producto_sucursal
               SET stock_actual = v_nuevo_stock, actualizado_en = now()
             WHERE producto_id = mov.producto_id AND sucursal_id = mov.sucursal_id;
        END IF;

        INSERT INTO public.movimientos_stock
            (ingrediente_id, producto_id, sucursal_id, tipo_movimiento, cantidad,
             stock_resultante, referencia_tipo, referencia_id, nota)
        VALUES
            (mov.ingrediente_id, mov.producto_id, mov.sucursal_id, 'anulacion_venta', v_reponer,
             v_nuevo_stock, 'venta', p_venta_id, v_nota);

        v_filas := v_filas + 1;
    END LOOP;

    RETURN v_filas;   -- cantidad de ítems repuestos
END;
$function$;

REVOKE ALL ON FUNCTION public.fn_reponer_stock_anulacion(integer, text) FROM PUBLIC;

-- T04) fn_anular_venta: misma lógica de 20261012_permisos_cajero.sql + reposición
CREATE OR REPLACE FUNCTION public.fn_anular_venta(p_venta_id INTEGER, p_motivo TEXT)
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    actor_id INTEGER := public.fn_usuario_actual_id();
    actor_rol TEXT;
    venta public.ventas%ROWTYPE;
BEGIN
    IF actor_id IS NULL THEN
        RAISE EXCEPTION 'La sesión no identifica a un usuario autorizado' USING ERRCODE = '42501';
    END IF;
    SELECT rol INTO actor_rol FROM public.usuarios WHERE id = actor_id;
    IF p_motivo IS NULL OR length(btrim(p_motivo)) < 5 OR length(btrim(p_motivo)) > 250 THEN
        RAISE EXCEPTION 'El motivo debe tener entre 5 y 250 caracteres' USING ERRCODE = '22023';
    END IF;

    -- Bloquea la fila para impedir dos anulaciones concurrentes.
    SELECT * INTO venta FROM public.ventas WHERE id = p_venta_id FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'La venta no existe o ya estaba anulada.' USING ERRCODE = '22023';
    END IF;
    IF actor_rol = 'cajero' AND venta.cajero_id IS DISTINCT FROM actor_id THEN
        RAISE EXCEPTION 'Solo puedes anular tus propias ventas' USING ERRCODE = '42501';
    END IF;
    IF venta.anulada THEN
        RAISE EXCEPTION 'La venta no existe o ya estaba anulada.' USING ERRCODE = '22023';
    END IF;

    UPDATE public.ventas
       SET anulada = TRUE, anulada_por = actor_id,
           anulada_en = clock_timestamp() AT TIME ZONE 'UTC', anulada_motivo = btrim(p_motivo)
     WHERE id = p_venta_id;

    -- H3.2 T08: devuelve al stock lo que descontó la venta (misma transacción).
    PERFORM public.fn_reponer_stock_anulacion(p_venta_id, p_motivo);

    RETURN p_venta_id;
END;
$$;

REVOKE ALL ON FUNCTION public.fn_anular_venta(integer, text) FROM PUBLIC, web_anon, nury_bodeguero;
GRANT EXECUTE ON FUNCTION public.fn_anular_venta(integer, text) TO nury_admin, nury_cajero;

-- fn_anular_venta corre como su dueño y llama a la reposición: ese dueño debe poder ejecutarla.
DO $$
DECLARE
    v_owner TEXT;
BEGIN
    SELECT pg_get_userbyid(proowner) INTO v_owner
      FROM pg_proc WHERE oid = 'public.fn_anular_venta(integer,text)'::regprocedure;
    EXECUTE format('GRANT EXECUTE ON FUNCTION public.fn_reponer_stock_anulacion(integer, text) TO %I', v_owner);
END $$;

COMMIT;
