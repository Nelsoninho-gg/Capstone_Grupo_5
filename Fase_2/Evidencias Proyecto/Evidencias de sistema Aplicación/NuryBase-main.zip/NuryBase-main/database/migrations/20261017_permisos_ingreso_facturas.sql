-- Permisos y sucursal para el ingreso de facturas XML (H3.1 T07).
--
-- Regla (decidida el 16/10/2026):
--   - admin: puede ingresar facturas en cualquier sucursal activa.
--   - bodeguero: solo en su propia sucursal (usuarios.sucursal_id). Sin sucursal
--     asignada no puede ingresar.
--   - cajero y cualquier otro rol: no ingresan facturas.
--
-- Se valida aquí, en PostgreSQL, y no solo en pantalla:
--   1. fn_actor_ingreso(): identifica al usuario de la sesión por el JWT, igual que
--      fn_usuario_actual_id() (que no reconoce al bodeguero y no se modifica).
--   2. fn_validar_sucursal_ingreso(): rechaza una sucursal que el usuario no puede usar.
--      La reutilizará la confirmación transaccional (H3.1 T08).
--   3. Disparador sobre facturas_xml_pendientes: valida la sucursal al insertar o
--      modificarla y fija cargado_por con el usuario real, no con lo que envíe el cliente.
--   4. RLS: el bodeguero solo ve y toca filas de su sucursal; el admin, todas.
--      Los demás roles quedan sin acceso.
--
-- REQUIERE: 20261016_facturas_xml_pendientes.sql aplicado, y los roles JWT
-- nury_admin, nury_cajero, nury_bodeguero y web_anon (ver 20261012_permisos_cajero.sql).
--
-- ANTES DE APLICAR EN PRODUCCIÓN:
--   a) Revisar el script completo con el responsable.
--   b) Correr primero 20261017_permisos_ingreso_facturas.ENSAYO.sql (termina en ROLLBACK).
--   c) Después de aplicar: NOTIFY pgrst, 'reload schema';

BEGIN;

-- 1) Quién es el usuario de la sesión ------------------------------------------

CREATE OR REPLACE FUNCTION public.fn_actor_ingreso()
RETURNS TABLE (usuario_id INTEGER, rol TEXT, sucursal_id INTEGER)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
    WITH sesion AS (
        SELECT COALESCE(NULLIF(current_setting('request.jwt.claims', TRUE), ''), '{}')::jsonb AS claims
    ), identidad AS (
        SELECT claims->>'role' AS rol_jwt,
               COALESCE(claims->>'user_id', claims->>'usuario_id', claims->>'sub', claims->>'id') AS id
          FROM sesion
    )
    SELECT u.id, u.rol::TEXT, u.sucursal_id
      FROM public.usuarios u, identidad i
     WHERE u.id = CASE WHEN i.id ~ '^[0-9]{1,10}$' THEN i.id::bigint ELSE NULL END
       AND u.activo
       -- El rol del JWT debe coincidir con el rol real del usuario en la base.
       AND CASE WHEN u.rol IN ('admin', 'administrador') THEN 'nury_admin'
                WHEN u.rol = 'bodeguero' THEN 'nury_bodeguero' END = i.rol_jwt;
$$;

REVOKE ALL ON FUNCTION public.fn_actor_ingreso() FROM PUBLIC, web_anon, nury_cajero;
GRANT EXECUTE ON FUNCTION public.fn_actor_ingreso() TO nury_admin, nury_bodeguero;

-- 2) ¿Puede este usuario ingresar en esa sucursal? --------------------------------

CREATE OR REPLACE FUNCTION public.fn_validar_sucursal_ingreso(p_sucursal_id INTEGER)
RETURNS INTEGER
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_actor  RECORD;
BEGIN
    SELECT * INTO v_actor FROM public.fn_actor_ingreso();
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Tu usuario no está autorizado para ingresar facturas'
            USING ERRCODE = '42501';
    END IF;

    IF p_sucursal_id IS NULL THEN
        RAISE EXCEPTION 'Indica la sucursal que recibirá el stock'
            USING ERRCODE = '22023';
    END IF;

    IF NOT EXISTS (SELECT 1 FROM public.sucursales WHERE id = p_sucursal_id AND activo) THEN
        RAISE EXCEPTION 'La sucursal indicada no existe o está inactiva'
            USING ERRCODE = '23503';
    END IF;

    IF v_actor.rol NOT IN ('admin', 'administrador') THEN
        IF v_actor.sucursal_id IS NULL THEN
            RAISE EXCEPTION 'Tu usuario no tiene una sucursal asignada: no puede ingresar facturas'
                USING ERRCODE = '42501';
        END IF;
        IF v_actor.sucursal_id <> p_sucursal_id THEN
            RAISE EXCEPTION 'Solo puedes ingresar facturas en tu propia sucursal'
                USING ERRCODE = '42501';
        END IF;
    END IF;

    RETURN v_actor.usuario_id;
END;
$$;

REVOKE ALL ON FUNCTION public.fn_validar_sucursal_ingreso(integer) FROM PUBLIC, web_anon, nury_cajero;
GRANT EXECUTE ON FUNCTION public.fn_validar_sucursal_ingreso(integer) TO nury_admin, nury_bodeguero;

-- 3) Disparador sobre la factura pendiente ---------------------------------------

CREATE OR REPLACE FUNCTION public.fn_facturas_xml_permisos()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public, pg_temp
AS $$
DECLARE
    v_usuario INTEGER;
BEGIN
    v_usuario := public.fn_validar_sucursal_ingreso(NEW.sucursal_id);

    IF TG_OP = 'INSERT' THEN
        -- Quien carga es quien tiene la sesión, no lo que envíe el cliente.
        NEW.cargado_por := v_usuario;
    ELSE
        -- Quién cargó la factura no se cambia después.
        NEW.cargado_por := OLD.cargado_por;
    END IF;

    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_facturas_xml_permisos ON public.facturas_xml_pendientes;
CREATE TRIGGER trg_facturas_xml_permisos
BEFORE INSERT OR UPDATE ON public.facturas_xml_pendientes
FOR EACH ROW EXECUTE FUNCTION public.fn_facturas_xml_permisos();

-- 4) Acceso a las tablas ----------------------------------------------------------

ALTER TABLE public.facturas_xml_pendientes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.facturas_xml_pendientes_lineas ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS facturas_xml_admin ON public.facturas_xml_pendientes;
CREATE POLICY facturas_xml_admin ON public.facturas_xml_pendientes
    TO nury_admin USING (TRUE) WITH CHECK (TRUE);

DROP POLICY IF EXISTS facturas_xml_bodeguero ON public.facturas_xml_pendientes;
CREATE POLICY facturas_xml_bodeguero ON public.facturas_xml_pendientes
    TO nury_bodeguero
    USING (sucursal_id = (SELECT a.sucursal_id FROM public.fn_actor_ingreso() a))
    WITH CHECK (sucursal_id = (SELECT a.sucursal_id FROM public.fn_actor_ingreso() a));

-- Las líneas siguen a su factura: la subconsulta ya está filtrada por la política anterior.
DROP POLICY IF EXISTS facturas_xml_lineas_admin ON public.facturas_xml_pendientes_lineas;
CREATE POLICY facturas_xml_lineas_admin ON public.facturas_xml_pendientes_lineas
    TO nury_admin USING (TRUE) WITH CHECK (TRUE);

DROP POLICY IF EXISTS facturas_xml_lineas_bodeguero ON public.facturas_xml_pendientes_lineas;
CREATE POLICY facturas_xml_lineas_bodeguero ON public.facturas_xml_pendientes_lineas
    TO nury_bodeguero
    USING (EXISTS (SELECT 1 FROM public.facturas_xml_pendientes f WHERE f.id = factura_xml_id))
    WITH CHECK (EXISTS (SELECT 1 FROM public.facturas_xml_pendientes f WHERE f.id = factura_xml_id));

-- Solo admin y bodeguero llegan a las tablas. Se reemplazan los permisos copiados de
-- facturas_compra en 20261016 (el cajero y web_anon no deben tener ninguno).
REVOKE ALL ON public.facturas_xml_pendientes, public.facturas_xml_pendientes_lineas
    FROM PUBLIC, web_anon, nury_cajero;
REVOKE ALL ON SEQUENCE public.facturas_xml_pendientes_id_seq, public.facturas_xml_pendientes_lineas_id_seq
    FROM PUBLIC, web_anon, nury_cajero;

GRANT USAGE ON SCHEMA public TO nury_admin, nury_bodeguero;
GRANT SELECT, INSERT, UPDATE ON public.facturas_xml_pendientes TO nury_admin, nury_bodeguero;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.facturas_xml_pendientes_lineas TO nury_admin, nury_bodeguero;
GRANT USAGE ON SEQUENCE public.facturas_xml_pendientes_id_seq,
                        public.facturas_xml_pendientes_lineas_id_seq TO nury_admin, nury_bodeguero;

COMMIT;
