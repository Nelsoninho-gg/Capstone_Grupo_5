-- H3.3 T07 - No se puede agregar un ingrediente inactivo a una receta.
--
-- Desactivar un artículo no borra nada: sus recetas, movimientos y stock se conservan. Lo que
-- no se permite es usarlo en asociaciones NUEVAS. La venta (fn_registrar_venta) y el ingreso
-- de facturas (fn_ingresar_factura_xml) ya rechazaban artículos inactivos; faltaban las
-- recetas: la pantalla solo ofrece ingredientes activos, pero por la API se podía agregar uno
-- inactivo.
--
-- trg_recetas_ingrediente_activo (BEFORE INSERT o UPDATE OF ingrediente_id): rechaza un
-- ingrediente inactivo. Las recetas que ya lo tienen siguen igual y se puede seguir editando
-- su cantidad o quitarlo.
--
-- ANTES DE APLICAR EN PRODUCCIÓN: correr 20261027_receta_ingrediente_activo.ENSAYO.sql
-- (termina en ROLLBACK) y la prueba database/tests/receta_ingrediente_activo.sql.

BEGIN;

CREATE OR REPLACE FUNCTION public.fn_recetas_ingrediente_activo()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $function$
DECLARE
    v_nombre TEXT;
BEGIN
    IF TG_OP = 'UPDATE' AND NEW.ingrediente_id = OLD.ingrediente_id THEN
        RETURN NEW;
    END IF;

    SELECT nombre INTO v_nombre
      FROM public.ingredientes
     WHERE id = NEW.ingrediente_id AND NOT activo;

    IF FOUND THEN
        RAISE EXCEPTION '"%" está inactivo: no se puede agregar a una receta', v_nombre
            USING ERRCODE = '22023';
    END IF;
    RETURN NEW;
END;
$function$;

REVOKE ALL ON FUNCTION public.fn_recetas_ingrediente_activo() FROM PUBLIC;

DROP TRIGGER IF EXISTS trg_recetas_ingrediente_activo ON public.recetas;
CREATE TRIGGER trg_recetas_ingrediente_activo
    BEFORE INSERT OR UPDATE OF ingrediente_id ON public.recetas
    FOR EACH ROW EXECUTE FUNCTION public.fn_recetas_ingrediente_activo();

COMMIT;
