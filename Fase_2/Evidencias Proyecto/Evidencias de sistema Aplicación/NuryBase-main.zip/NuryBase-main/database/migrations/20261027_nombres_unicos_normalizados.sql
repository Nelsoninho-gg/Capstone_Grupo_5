-- H3.3 T05 - Validaciones de campos obligatorios y duplicados (ignorando mayúsculas y
-- espacios) en ingredientes y productos: nombre y código de barras.
--
-- Antes: UNIQUE (nombre) y UNIQUE (codigo_barras) distinguían mayúsculas y espacios, así que
-- por la API se podían crear "Harina", "harina" y "Harina  " como artículos distintos, o dos
-- productos con "ABC123" y "abc 123"; y un nombre de solo espacios pasaba el NOT NULL.
--
--   - fn_nombre_normalizado(texto): minúsculas, sin espacios en los extremos y con los
--     espacios internos repetidos reducidos a uno. IMMUTABLE para poder indexarla.
--   - ux_ingredientes_nombre_normalizado y ux_productos_nombre_normalizado: índices únicos
--     sobre ese valor. Un duplicado da 23505 → PostgREST 409 (la app muestra "Ya existe...").
--   - fn_codigo_normalizado(texto): código de barras en mayúsculas y sin ningún espacio.
--   - ux_ingredientes_codigo_normalizado y ux_productos_codigo_normalizado: índices únicos
--     parciales (solo filas con código).
--   - fn_limpiar_nombre_y_codigo (BEFORE INSERT/UPDATE OF nombre, codigo_barras): guarda el
--     nombre sin espacios en los extremos ni repetidos y el código sin espacios (vacío → NULL),
--     y rechaza un nombre vacío (22023).
--   - CHECK nombre no vacío en las dos tablas.
--
-- El tercer criterio (bloquear el cambio de unidad) ya se cumple de forma más estricta:
-- trg_ingredientes_unidad_fija lo rechaza siempre (20261023_unidad_fija_ingrediente.sql).
--
-- ANTES DE APLICAR EN PRODUCCIÓN: correr 20261027_nombres_unicos_normalizados.ENSAYO.sql
-- (termina en ROLLBACK). Si muestra duplicados, hay que resolverlos antes (renombrar o
-- desactivar y renombrar), porque el índice único no se puede crear con ellos.
-- Debe ejecutarla el dueño de las tablas ingredientes y productos.

BEGIN;

CREATE OR REPLACE FUNCTION public.fn_nombre_normalizado(p_nombre TEXT)
RETURNS TEXT
LANGUAGE sql
IMMUTABLE
PARALLEL SAFE
AS $function$
    SELECT lower(regexp_replace(btrim(p_nombre), '\s+', ' ', 'g'));
$function$;

COMMENT ON FUNCTION public.fn_nombre_normalizado(text) IS
    'Nombre para comparar duplicados (H3.3 T05): minúsculas, sin espacios en los extremos ni repetidos.';

CREATE OR REPLACE FUNCTION public.fn_codigo_normalizado(p_codigo TEXT)
RETURNS TEXT
LANGUAGE sql
IMMUTABLE
PARALLEL SAFE
AS $function$
    SELECT upper(regexp_replace(p_codigo, '\s', '', 'g'));
$function$;

COMMENT ON FUNCTION public.fn_codigo_normalizado(text) IS
    'Código de barras para comparar duplicados (H3.3 T05): mayúsculas y sin espacios.';

CREATE OR REPLACE FUNCTION public.fn_limpiar_nombre_y_codigo()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = pg_catalog, public, pg_temp
AS $function$
BEGIN
    NEW.nombre := regexp_replace(btrim(NEW.nombre), '\s+', ' ', 'g');
    IF NEW.nombre = '' THEN
        RAISE EXCEPTION 'El nombre es obligatorio' USING ERRCODE = '22023';
    END IF;
    NEW.codigo_barras := NULLIF(regexp_replace(NEW.codigo_barras, '\s', '', 'g'), '');
    RETURN NEW;
END;
$function$;

REVOKE ALL ON FUNCTION public.fn_limpiar_nombre_y_codigo() FROM PUBLIC;

DROP TRIGGER IF EXISTS trg_ingredientes_limpiar_nombre ON public.ingredientes;
CREATE TRIGGER trg_ingredientes_limpiar_nombre
    BEFORE INSERT OR UPDATE OF nombre, codigo_barras ON public.ingredientes
    FOR EACH ROW EXECUTE FUNCTION public.fn_limpiar_nombre_y_codigo();

DROP TRIGGER IF EXISTS trg_productos_limpiar_nombre ON public.productos;
CREATE TRIGGER trg_productos_limpiar_nombre
    BEFORE INSERT OR UPDATE OF nombre, codigo_barras ON public.productos
    FOR EACH ROW EXECUTE FUNCTION public.fn_limpiar_nombre_y_codigo();

ALTER TABLE public.ingredientes DROP CONSTRAINT IF EXISTS ingredientes_nombre_no_vacio;
ALTER TABLE public.ingredientes ADD CONSTRAINT ingredientes_nombre_no_vacio CHECK (btrim(nombre) <> '');
ALTER TABLE public.productos DROP CONSTRAINT IF EXISTS productos_nombre_no_vacio;
ALTER TABLE public.productos ADD CONSTRAINT productos_nombre_no_vacio CHECK (btrim(nombre) <> '');

CREATE UNIQUE INDEX IF NOT EXISTS ux_ingredientes_nombre_normalizado
    ON public.ingredientes (public.fn_nombre_normalizado(nombre));
CREATE UNIQUE INDEX IF NOT EXISTS ux_productos_nombre_normalizado
    ON public.productos (public.fn_nombre_normalizado(nombre));

CREATE UNIQUE INDEX IF NOT EXISTS ux_ingredientes_codigo_normalizado
    ON public.ingredientes (public.fn_codigo_normalizado(codigo_barras))
    WHERE codigo_barras IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS ux_productos_codigo_normalizado
    ON public.productos (public.fn_codigo_normalizado(codigo_barras))
    WHERE codigo_barras IS NOT NULL;

COMMIT;
