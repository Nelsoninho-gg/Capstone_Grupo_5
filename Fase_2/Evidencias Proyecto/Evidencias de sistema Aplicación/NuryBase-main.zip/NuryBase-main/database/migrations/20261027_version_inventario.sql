-- H3.2 T06 - Los cambios confirmados llegan al panel de Inventario (H3.4) y a sus alertas
-- de stock mínimo (H3.5) sin recargar, en 2 segundos o menos.
--
-- No hay canal de tiempo real (H3.4 T06 se descartó: sin WebSockets). En su lugar el panel
-- pregunta cada 2 s, mientras está visible, una "versión" muy liviana del inventario y solo
-- vuelve a cargar las existencias cuando cambió.
--
-- fn_version_inventario() devuelve:
--   - stock: huella (md5) del stock actual y del mínimo de cada fila de stock_sucursal y
--     stock_producto_sucursal. Cambia con ventas, anulaciones, compras, ajustes, mermas y
--     también al editar un mínimo (que no deja movimiento en el kardex).
--   - movimientos: id del último movimiento del kardex (para refrescar el reporte de mermas).
-- Solo lectura (STABLE). SECURITY DEFINER para que el bodeguero no necesite leer el kardex
-- completo. Ejecutable por admin y bodeguero, como el panel.
--
-- ANTES DE APLICAR EN PRODUCCIÓN: correr 20261027_version_inventario.ENSAYO.sql (termina en
-- ROLLBACK) y la prueba database/tests/version_inventario.sql.

BEGIN;

CREATE OR REPLACE FUNCTION public.fn_version_inventario()
RETURNS JSONB
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $function$
    SELECT jsonb_build_object(
        'stock', md5(coalesce((
            SELECT string_agg(concat_ws(':', t, item_id, sucursal_id, stock_actual, stock_minimo), ','
                              ORDER BY t, item_id, sucursal_id)
              FROM (SELECT 'i' AS t, ingrediente_id AS item_id, sucursal_id, stock_actual, stock_minimo
                      FROM public.stock_sucursal
                    UNION ALL
                    SELECT 'p', producto_id, sucursal_id, stock_actual, stock_minimo
                      FROM public.stock_producto_sucursal) s), '')),
        'movimientos', coalesce((SELECT max(id) FROM public.movimientos_stock), 0)
    );
$function$;

COMMENT ON FUNCTION public.fn_version_inventario() IS
    'Versión liviana del inventario (H3.2 T06): el panel la consulta cada 2 s y recarga solo si cambió.';

REVOKE ALL ON FUNCTION public.fn_version_inventario() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.fn_version_inventario() TO nury_admin, nury_bodeguero;

COMMIT;

NOTIFY pgrst, 'reload schema';
