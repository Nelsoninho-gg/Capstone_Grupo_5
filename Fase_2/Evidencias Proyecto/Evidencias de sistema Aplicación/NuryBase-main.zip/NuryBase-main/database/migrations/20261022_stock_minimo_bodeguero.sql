-- Mínimo de stock no negativo y permiso de edición para el bodeguero (Pedidos 4 y 6).
--
-- Contexto (2026-10-22):
-- 1. Pedido 4: El frontend ya validaba que stock_minimo fuera >= 0; se agrega la
--    restricción formal CHECK en stock_sucursal y stock_producto_sucursal.
-- 2. Pedido 6: El equipo confirmó que el rol nury_bodeguero debe tener la facultad
--    de editar los mínimos de stock desde el panel de Inventario (evitando el error 403).
--    Siguiendo el principio de menor privilegio, se otorga UPDATE únicamente sobre la
--    columna stock_minimo, sin permitir modificar stock_actual ni columnas de auditoría.
--
-- APLICADA EN PRODUCCIÓN/VPS el 2026-10-22 por dev_patricio (con rol nury_admin).
-- Requiere ser ejecutada por el dueño de las tablas (nury_admin).

SET ROLE nury_admin;

BEGIN;

-- Restricción de no negatividad para mínimos de stock
ALTER TABLE public.stock_sucursal
    DROP CONSTRAINT IF EXISTS stock_minimo_no_negativo,
    ADD CONSTRAINT stock_minimo_no_negativo CHECK (stock_minimo >= 0);

ALTER TABLE public.stock_producto_sucursal
    DROP CONSTRAINT IF EXISTS stock_producto_minimo_no_negativo,
    ADD CONSTRAINT stock_producto_minimo_no_negativo CHECK (stock_minimo >= 0);

-- Permiso de actualización exclusivo para la columna stock_minimo
GRANT UPDATE (stock_minimo) ON public.stock_sucursal TO nury_bodeguero;
GRANT UPDATE (stock_minimo) ON public.stock_producto_sucursal TO nury_bodeguero;

COMMIT;

NOTIFY pgrst, 'reload schema';

RESET ROLE;
