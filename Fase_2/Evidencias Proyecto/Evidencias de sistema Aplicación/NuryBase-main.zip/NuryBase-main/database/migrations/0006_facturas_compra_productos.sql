-- Facturas de compra con líneas de PRODUCTO (reventa) y presentaciones en caja.
--
-- Contexto: hasta ahora una línea de factura solo podía ser un ingrediente y el
-- trigger de compra solo sumaba a stock_sucursal. Las facturas de proveedores
-- de bebidas (ej. CCU) traen productos de reventa comprados por CAJA (1 CJ = 12
-- unidades). Este script deja la base lista para recibirlas:
--
--   T01  detalle_factura_compra admite producto_id (ingrediente_id pasa a
--        nullable, exactamente uno de los dos) y unidad_id solo es obligatoria
--        para ingredientes.
--   T02  Presentaciones: se puede cargar la línea tal como viene impresa
--        (cantidad_presentaciones + precio_presentacion) y la base calcula las
--        unidades base, el precio por unidad y, si falta, el monto del descuento.
--   T03  codigos_proveedor_producto: código SKU del proveedor -> producto.
--   T04  fn_aplicar_compra con la rama de producto: suma a
--        stock_producto_sucursal, deja kardex con producto_id y actualiza
--        productos.precio_compra al ÚLTIMO costo real por unidad.
--
-- Reglas (confirmadas 2026-10-10):
--   - El costo de compra del producto = último costo real por unidad
--     (precio con descuento + flete + impuesto específico de la línea, sin IVA).
--   - La cantidad se carga en cajas y la base convierte a unidades.
--   - Un producto CON receta no se compra: su stock sale de sus ingredientes.
--
-- REQUIERE: 0004_stock_producto_reventa.sql aplicado antes.
--
-- ANTES DE APLICAR EN PRODUCCIÓN:
--   a) Revisar la función de compra actual (T04 la reemplaza completa; sus
--      atributos SECURITY DEFINER / search_path se conservan automáticamente):
--        SELECT pg_get_functiondef('public.fn_aplicar_compra()'::regprocedure);
--   b) Revisar las columnas reales del detalle:
--        SELECT column_name, data_type, is_nullable
--          FROM information_schema.columns
--         WHERE table_name = 'detalle_factura_compra' ORDER BY ordinal_position;
--   c) Correr primero 0006_facturas_compra_productos.ENSAYO.sql (termina en ROLLBACK).
--   d) Después de aplicar: NOTIFY pgrst, 'reload schema';
--
-- Limitaciones conocidas (no se resuelven aquí):
--   - Anular una factura (estado = 'anulada') NO revierte el stock; igual que hoy
--     con los ingredientes.
--   - precio_unitario tiene 2 decimales: una caja dividida en unidades puede
--     perder centavos (ej. 5.251 / 12 = 437,58). Es una diferencia de fracciones
--     de peso por línea.
--   - El flete de la factura se reparte a mano en la columna `flete` de cada línea.

BEGIN;

-- Algunas bases ya tienen precio_compra (la agregó otro integrante); en las que
-- no, se crea. Si ya existe, esta sentencia no hace nada.
ALTER TABLE public.productos
    ADD COLUMN IF NOT EXISTS precio_compra NUMERIC(12,2);

-- T01) Líneas de producto en el detalle ----------------------------------------

ALTER TABLE public.detalle_factura_compra
    ALTER COLUMN ingrediente_id DROP NOT NULL;

ALTER TABLE public.detalle_factura_compra
    ADD COLUMN IF NOT EXISTS producto_id INTEGER REFERENCES public.productos(id);

ALTER TABLE public.detalle_factura_compra
    ALTER COLUMN unidad_id DROP NOT NULL;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint
                    WHERE conrelid = 'public.detalle_factura_compra'::regclass
                      AND conname = 'detalle_factura_compra_un_solo_item') THEN
        ALTER TABLE public.detalle_factura_compra
            ADD CONSTRAINT detalle_factura_compra_un_solo_item
            CHECK ((ingrediente_id IS NULL) <> (producto_id IS NULL));
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_constraint
                    WHERE conrelid = 'public.detalle_factura_compra'::regclass
                      AND conname = 'detalle_factura_compra_unidad_ingrediente') THEN
        -- La unidad de medida solo tiene sentido para ingredientes.
        ALTER TABLE public.detalle_factura_compra
            ADD CONSTRAINT detalle_factura_compra_unidad_ingrediente
            CHECK (ingrediente_id IS NULL OR unidad_id IS NOT NULL);
    END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_detalle_factura_compra_producto
    ON public.detalle_factura_compra(producto_id) WHERE producto_id IS NOT NULL;

-- T02) Presentaciones (cajas) ---------------------------------------------------

ALTER TABLE public.detalle_factura_compra
    ADD COLUMN IF NOT EXISTS cantidad_presentaciones NUMERIC(12,3),  -- ej. 7 (cajas), tal como viene en la factura
    ADD COLUMN IF NOT EXISTS precio_presentacion     NUMERIC(12,2);  -- ej. 5139 (precio de una caja), antes de descuento

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint
                    WHERE conrelid = 'public.detalle_factura_compra'::regclass
                      AND conname = 'detalle_factura_compra_presentacion_check') THEN
        ALTER TABLE public.detalle_factura_compra
            ADD CONSTRAINT detalle_factura_compra_presentacion_check
            CHECK ((cantidad_presentaciones IS NULL OR cantidad_presentaciones > 0)
               AND (precio_presentacion IS NULL OR precio_presentacion >= 0));
    END IF;
END $$;

-- Se ejecuta ANTES de insertar: completa cantidad / precio_unitario /
-- descuento_monto a partir de lo que trae la factura impresa. Las columnas
-- generadas (subtotal_neto, total_linea) se calculan después, con los valores ya
-- completados. Si la línea ya viene en unidades base, no cambia nada.
CREATE OR REPLACE FUNCTION public.fn_normalizar_detalle_factura()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = pg_catalog, public, pg_temp
AS $$
BEGIN
    IF NEW.cantidad_presentaciones IS NOT NULL THEN
        IF COALESCE(NEW.unidades_por_presentacion, 0) <= 0 THEN
            RAISE EXCEPTION 'Indica cuántas unidades trae cada presentación (caja)'
                USING ERRCODE = '22023';
        END IF;
        NEW.cantidad := NEW.cantidad_presentaciones * NEW.unidades_por_presentacion;
    END IF;

    IF NEW.precio_presentacion IS NOT NULL THEN
        IF COALESCE(NEW.unidades_por_presentacion, 0) <= 0 THEN
            RAISE EXCEPTION 'Indica cuántas unidades trae cada presentación (caja)'
                USING ERRCODE = '22023';
        END IF;
        NEW.precio_unitario := ROUND(NEW.precio_presentacion / NEW.unidades_por_presentacion, 2);
    END IF;

    -- Si la factura informa solo el porcentaje de descuento, se calcula el monto.
    IF COALESCE(NEW.descuento_monto, 0) = 0
       AND COALESCE(NEW.descuento_porcentaje, 0) > 0
       AND NEW.cantidad IS NOT NULL
       AND NEW.precio_unitario IS NOT NULL THEN
        NEW.descuento_monto := ROUND(NEW.cantidad * NEW.precio_unitario * NEW.descuento_porcentaje / 100, 2);
    END IF;

    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_detalle_factura_compra_normalizar ON public.detalle_factura_compra;
CREATE TRIGGER trg_detalle_factura_compra_normalizar
BEFORE INSERT ON public.detalle_factura_compra
FOR EACH ROW EXECUTE FUNCTION public.fn_normalizar_detalle_factura();

-- T03) Códigos de proveedor para productos -------------------------------------

CREATE TABLE IF NOT EXISTS public.codigos_proveedor_producto (
    id                          SERIAL PRIMARY KEY,
    proveedor_id                INTEGER NOT NULL REFERENCES public.proveedores(id),
    producto_id                 INTEGER NOT NULL REFERENCES public.productos(id),
    codigo                      VARCHAR(30) NOT NULL,      -- ej. 'INT1-871207' (columna "Código" de la factura)
    descripcion_proveedor       VARCHAR(150),               -- texto tal cual en la factura
    unidades_por_presentacion   NUMERIC(10,2) NOT NULL DEFAULT 1 CHECK (unidades_por_presentacion > 0),  -- ej. 12 por caja
    UNIQUE (proveedor_id, codigo)
);

CREATE INDEX IF NOT EXISTS idx_codigos_proveedor_producto_producto
    ON public.codigos_proveedor_producto(producto_id);

-- Mismo dueño y mismos permisos que el mapeo equivalente de ingredientes.
DO $$
DECLARE
    v_owner TEXT;
    r       RECORD;
BEGIN
    SELECT pg_get_userbyid(relowner) INTO v_owner
      FROM pg_class WHERE oid = 'public.codigos_proveedor_ingrediente'::regclass;

    EXECUTE format('ALTER TABLE public.codigos_proveedor_producto OWNER TO %I', v_owner);
    EXECUTE format('ALTER SEQUENCE public.codigos_proveedor_producto_id_seq OWNER TO %I', v_owner);

    FOR r IN
        SELECT CASE WHEN a.grantee = 0 THEN 'PUBLIC' ELSE quote_ident(pg_get_userbyid(a.grantee)) END AS grantee,
               a.privilege_type
          FROM pg_class c, LATERAL aclexplode(c.relacl) a
         WHERE c.oid = 'public.codigos_proveedor_ingrediente'::regclass
           AND a.grantee <> c.relowner
    LOOP
        EXECUTE format('GRANT %s ON public.codigos_proveedor_producto TO %s', r.privilege_type, r.grantee);
    END LOOP;
END $$;

-- T04) fn_aplicar_compra con la rama de producto -------------------------------

-- CREATE OR REPLACE reinicia los atributos de la función; se guardan los de la
-- versión actual (SECURITY DEFINER, search_path) para reponerlos después.
CREATE TEMP TABLE _atributos_fn_compra ON COMMIT DROP AS
SELECT prosecdef, proconfig
  FROM pg_proc
 WHERE oid = 'public.fn_aplicar_compra()'::regprocedure;

CREATE OR REPLACE FUNCTION public.fn_aplicar_compra() RETURNS TRIGGER AS $$
DECLARE
    v_sucursal_id    INTEGER;
    v_stock_previo   NUMERIC(12,3);
    v_costo_previo   NUMERIC(12,2);
    v_nuevo_stock    NUMERIC(12,3);
    v_nuevo_costo    NUMERIC(12,2);
    v_costo_real_linea NUMERIC(12,4);  -- costo real por unidad base de ESTA compra (con descuento, flete e impuesto)
BEGIN
    SELECT sucursal_id INTO v_sucursal_id FROM facturas_compra WHERE id = NEW.factura_id;

    -- Costo real por unidad de ESTA línea: precio de lista, menos descuento, más flete e
    -- impuesto específico prorrateados sobre la cantidad — lo que realmente costó cada unidad puesta en la sucursal.
    v_costo_real_linea := NEW.total_linea / NEW.cantidad;

    IF NEW.ingrediente_id IS NOT NULL THEN
        -- Asegura que exista la fila de stock para ese ingrediente en esa sucursal
        INSERT INTO stock_sucursal (ingrediente_id, sucursal_id, stock_actual, stock_minimo)
        VALUES (NEW.ingrediente_id, v_sucursal_id, 0, 0)
        ON CONFLICT (ingrediente_id, sucursal_id) DO NOTHING;

        SELECT stock_actual INTO v_stock_previo
          FROM stock_sucursal
         WHERE ingrediente_id = NEW.ingrediente_id AND sucursal_id = v_sucursal_id
         FOR UPDATE;

        SELECT costo_unitario_promedio INTO v_costo_previo
          FROM ingredientes WHERE id = NEW.ingrediente_id
          FOR UPDATE;

        v_nuevo_stock := v_stock_previo + NEW.cantidad;

        -- Costo promedio ponderado global: (stock_previo*costo_previo + compra*costo_real) / stock_nuevo
        IF v_nuevo_stock > 0 THEN
            v_nuevo_costo := ((v_stock_previo * v_costo_previo) + (NEW.cantidad * v_costo_real_linea)) / v_nuevo_stock;
        ELSE
            v_nuevo_costo := v_costo_real_linea;
        END IF;

        UPDATE stock_sucursal
           SET stock_actual = v_nuevo_stock,
               actualizado_en = now()
         WHERE ingrediente_id = NEW.ingrediente_id AND sucursal_id = v_sucursal_id;

        UPDATE ingredientes
           SET costo_unitario_promedio = v_nuevo_costo,
               actualizado_en = now()
         WHERE id = NEW.ingrediente_id;

        INSERT INTO movimientos_stock
            (ingrediente_id, sucursal_id, tipo_movimiento, cantidad, stock_resultante, referencia_tipo, referencia_id)
        VALUES
            (NEW.ingrediente_id, v_sucursal_id, 'compra', NEW.cantidad, v_nuevo_stock, 'factura_compra', NEW.factura_id);
    ELSE
        -- Producto de reventa: stock propio por sucursal.
        IF EXISTS (SELECT 1 FROM recetas WHERE producto_id = NEW.producto_id) THEN
            RAISE EXCEPTION 'Este producto tiene receta: no se compra directamente, su stock sale de sus ingredientes'
                USING ERRCODE = '22023';
        END IF;

        INSERT INTO stock_producto_sucursal (producto_id, sucursal_id, stock_actual, stock_minimo)
        VALUES (NEW.producto_id, v_sucursal_id, 0, 0)
        ON CONFLICT (producto_id, sucursal_id) DO NOTHING;

        SELECT stock_actual INTO v_stock_previo
          FROM stock_producto_sucursal
         WHERE producto_id = NEW.producto_id AND sucursal_id = v_sucursal_id
         FOR UPDATE;

        v_nuevo_stock := v_stock_previo + NEW.cantidad;

        UPDATE stock_producto_sucursal
           SET stock_actual = v_nuevo_stock,
               actualizado_en = now()
         WHERE producto_id = NEW.producto_id AND sucursal_id = v_sucursal_id;

        -- Costo de compra del producto = último costo real por unidad.
        UPDATE productos
           SET precio_compra = ROUND(v_costo_real_linea, 2)
         WHERE id = NEW.producto_id;

        INSERT INTO movimientos_stock
            (producto_id, sucursal_id, tipo_movimiento, cantidad, stock_resultante, referencia_tipo, referencia_id)
        VALUES
            (NEW.producto_id, v_sucursal_id, 'compra', NEW.cantidad, v_nuevo_stock, 'factura_compra', NEW.factura_id);
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DO $$
DECLARE
    v_secdef BOOLEAN;
    v_config TEXT[];
    v_item   TEXT;
BEGIN
    SELECT prosecdef, proconfig INTO v_secdef, v_config FROM _atributos_fn_compra;

    IF v_secdef THEN
        ALTER FUNCTION public.fn_aplicar_compra() SECURITY DEFINER;
    END IF;

    IF v_config IS NOT NULL THEN
        FOREACH v_item IN ARRAY v_config LOOP
            EXECUTE format('ALTER FUNCTION public.fn_aplicar_compra() SET %s TO %s',
                           split_part(v_item, '=', 1),
                           substr(v_item, strpos(v_item, '=') + 1));
        END LOOP;
    END IF;
END $$;

COMMIT;
