-- H2.12 T05 — Venta a empleados: marca booleana de venta especial.
--
-- venta_especial = true  → venta a empleado, con descuento.
-- venta_especial = false → venta normal, sin descuento.
--
-- La calcula la base de datos a partir de tipo_venta (0004), así nunca
-- puede quedar distinta de ese valor. No se escribe desde el POS.

BEGIN;

ALTER TABLE public.ventas
    ADD COLUMN IF NOT EXISTS venta_especial BOOLEAN
        GENERATED ALWAYS AS (tipo_venta = 'empleado') STORED;

COMMENT ON COLUMN public.ventas.venta_especial IS
    'true si es venta a empleado (con descuento); false si es venta normal. Calculada desde tipo_venta.';

COMMIT;
