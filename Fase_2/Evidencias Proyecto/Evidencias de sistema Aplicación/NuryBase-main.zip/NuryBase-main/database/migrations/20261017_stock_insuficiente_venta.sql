-- H2.5 T04 - Devolver al POS los ingredientes (y productos de reventa) que
-- quedaron con stock insuficiente después de una venta.
--
-- Cómo se conecta con el descuento de H3.2: la venta descuenta stock en el
-- trigger fn_aplicar_venta, que deja un movimiento 'venta' en el kardex por cada
-- ingrediente de la receta (o por el producto de reventa). Esta función lee esos
-- movimientos: no recalcula recetas ni vuelve a tocar el stock.
--
-- Regla (opción A acordada): la venta NO se bloquea por falta de stock; el stock
-- puede quedar negativo. Esta función solo informa, para que el POS avise.
--
-- "Insuficiente" = el stock que había antes de la venta no alcanzaba para lo que
-- la venta consumió, es decir, el stock quedó bajo cero después del descuento.
-- Un ingrediente compartido por varios productos de la misma venta se evalúa con
-- el consumo sumado (H2.5 T03).
--
-- No modifica fn_registrar_venta (la mantienen otros integrantes): el POS llama a
-- esta función justo después de registrar la venta.
--
-- Requiere: 0004_stock_producto_reventa.sql y 20261012_permisos_cajero.sql
-- (fn_usuario_actual_id).
--
-- ANTES DE APLICAR EN PRODUCCIÓN:
--   a) Correr 20261017_stock_insuficiente_venta.ENSAYO.sql (termina en ROLLBACK).
--   b) Después de aplicar: NOTIFY pgrst, 'reload schema';

BEGIN;

CREATE OR REPLACE FUNCTION public.fn_stock_insuficiente_venta(p_venta_id INTEGER)
RETURNS TABLE (
    tipo           TEXT,           -- 'ingrediente' o 'producto'
    item_id        INTEGER,
    nombre         TEXT,
    sucursal_id    INTEGER,
    unidad         TEXT,
    requerido      NUMERIC,        -- lo que consumió la venta (sumado si se comparte)
    disponible     NUMERIC,        -- stock que había antes de la venta
    faltante       NUMERIC,        -- lo que no alcanzó a cubrir el stock
    stock_actual   NUMERIC         -- stock que quedó después de la venta
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $function$
DECLARE
    v_actor_id  INTEGER := public.fn_usuario_actual_id();
    v_actor_rol TEXT;
    v_cajero_id INTEGER;
BEGIN
    IF v_actor_id IS NULL THEN
        RAISE EXCEPTION 'La sesión no identifica a un usuario autorizado' USING ERRCODE = '42501';
    END IF;

    SELECT cajero_id INTO v_cajero_id FROM public.ventas WHERE id = p_venta_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'La venta no existe' USING ERRCODE = '22023';
    END IF;

    -- Igual que en la anulación: un cajero solo consulta sus propias ventas.
    SELECT rol INTO v_actor_rol FROM public.usuarios WHERE id = v_actor_id;
    IF v_actor_rol = 'cajero' AND v_cajero_id IS DISTINCT FROM v_actor_id THEN
        RAISE EXCEPTION 'Solo puedes consultar tus propias ventas' USING ERRCODE = '42501';
    END IF;

    RETURN QUERY
    WITH movs AS (
        SELECT m.id, m.ingrediente_id, m.producto_id, m.sucursal_id, m.cantidad, m.stock_resultante
          FROM public.movimientos_stock m
         WHERE m.tipo_movimiento = 'venta'
           AND m.referencia_tipo = 'venta'
           AND m.referencia_id = p_venta_id
    ), por_item AS (
        SELECT DISTINCT ON (mv.ingrediente_id, mv.producto_id, mv.sucursal_id)
               mv.ingrediente_id, mv.producto_id, mv.sucursal_id,
               -SUM(mv.cantidad) OVER w AS requerido,
               mv.stock_resultante AS final            -- el último movimiento del ítem en la venta
          FROM movs mv
        WINDOW w AS (PARTITION BY mv.ingrediente_id, mv.producto_id, mv.sucursal_id)
         ORDER BY mv.ingrediente_id, mv.producto_id, mv.sucursal_id, mv.id DESC
    )
    SELECT CASE WHEN p.ingrediente_id IS NOT NULL THEN 'ingrediente' ELSE 'producto' END,
           COALESCE(p.ingrediente_id, p.producto_id),
           COALESCE(i.nombre, pr.nombre)::TEXT,
           p.sucursal_id,
           CASE WHEN p.ingrediente_id IS NOT NULL THEN um.abreviatura::TEXT ELSE 'unid.' END,
           p.requerido,
           p.final + p.requerido,
           LEAST(p.requerido, -p.final),
           p.final
      FROM por_item p
      LEFT JOIN public.ingredientes i     ON i.id = p.ingrediente_id
      LEFT JOIN public.unidades_medida um ON um.id = i.unidad_id
      LEFT JOIN public.productos pr       ON pr.id = p.producto_id
     WHERE p.final < 0
     ORDER BY 3;
END;
$function$;

REVOKE ALL ON FUNCTION public.fn_stock_insuficiente_venta(integer) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.fn_stock_insuficiente_venta(integer) TO nury_admin, nury_cajero;

COMMIT;
