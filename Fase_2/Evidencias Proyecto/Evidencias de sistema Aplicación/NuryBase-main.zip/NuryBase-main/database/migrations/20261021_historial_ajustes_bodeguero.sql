-- Lectura del historial de ajustes y mermas para el bodeguero.
--
-- Hallazgo (2026-10-21): en Inventario > "Mermas y ajustes" el bodeguero recibía
-- "Tu rol no tiene permiso para ver el reporte de mermas". La API respondía 403
-- ("permission denied for table movimientos_stock") y, al pedir el responsable,
-- también fallaba usuarios. Con admin funcionaba.
--
-- Se concede lectura de movimientos_stock (el bodeguero ya ajusta stock con
-- fn_ajustar_stock) y solo id y nombre de usuarios, para mostrar quién hizo el
-- ajuste sin exponer credenciales, hash ni rol.
--
-- PENDIENTE DE APLICAR EN EL VPS. Es idempotente. Debe ejecutarla el dueño de las tablas.

BEGIN;

GRANT SELECT ON public.movimientos_stock TO nury_bodeguero;
GRANT SELECT (id, nombre) ON public.usuarios TO nury_bodeguero;

COMMIT;

NOTIFY pgrst, 'reload schema';
