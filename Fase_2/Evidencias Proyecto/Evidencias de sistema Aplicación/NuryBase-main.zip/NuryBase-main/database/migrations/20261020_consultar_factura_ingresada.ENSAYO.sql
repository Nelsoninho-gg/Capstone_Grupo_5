-- ENSAYO de 20261020_consultar_factura_ingresada.sql (H3.7 T03 y T05).
-- Aplica el mismo cambio (el bloque entre «Cambio a ensayar» y «Datos de ejemplo» es
-- copia exacta del script real), ingresa una factura de ejemplo como admin, la consulta
-- como admin, bodeguero de la misma sucursal, bodeguero de otra, cajero y anónimo, y
-- termina en ROLLBACK: no deja nada aplicado.
--
-- REQUIERE aplicados: 20261016_facturas_xml_pendientes.sql,
-- 20261017_equivalencias_lineas_xml.sql, 20261017_permisos_ingreso_facturas.sql y
-- 20261017_ingresar_factura_xml.sql.
--
-- Resultado: pestaña «Messages» de pgAdmin. Cada prueba aparece como «OK | ...» y al
-- final «ENSAYO COMPLETO». Si alguna falla, el ensayo termina con error: ejecuta
-- ROLLBACK; solo y pégame los avisos.

BEGIN;

-- Cambio a ensayar (igual al script real) ----------------------------------------------

CREATE OR REPLACE FUNCTION public.fn_consultar_factura_ingresada(
    p_rut_emisor     TEXT,
    p_tipo_documento SMALLINT,
    p_folio          BIGINT
)
RETURNS JSONB
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_actor    RECORD;
    v_rut_norm TEXT;
    v_factura  RECORD;
    v_inv      INTEGER;
    v_otras    INTEGER;
BEGIN
    SELECT * INTO v_actor FROM public.fn_actor_ingreso();
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Tu usuario no está autorizado para ingresar facturas'
            USING ERRCODE = '42501';
    END IF;

    v_rut_norm := public.fn_normalizar_rut(p_rut_emisor);
    IF v_rut_norm IS NULL OR p_tipo_documento IS NULL OR p_folio IS NULL OR p_folio <= 0 THEN
        RETURN jsonb_build_object('identificacion_completa', FALSE, 'ingresada', FALSE);
    END IF;

    SELECT f.id AS factura_id, f.sucursal_id, s.nombre AS sucursal,
           x.id AS xml_id, x.confirmado_por, x.confirmado_en, u.nombre AS ingresada_por
      INTO v_factura
      FROM public.facturas_compra f
      LEFT JOIN public.sucursales s ON s.id = f.sucursal_id
      LEFT JOIN public.facturas_xml_pendientes x ON x.factura_id = f.id
      LEFT JOIN public.usuarios u ON u.id = x.confirmado_por
     WHERE f.rut_emisor_normalizado = v_rut_norm
       AND f.tipo_documento = p_tipo_documento
       AND f.folio = p_folio;
    IF NOT FOUND THEN
        RETURN jsonb_build_object('identificacion_completa', TRUE, 'ingresada', FALSE);
    END IF;

    -- Otra sucursal: se sabe que ya existe, pero no dónde, cuándo ni quién.
    IF v_actor.rol NOT IN ('admin', 'administrador')
       AND v_factura.sucursal_id IS DISTINCT FROM v_actor.sucursal_id THEN
        RETURN jsonb_build_object('identificacion_completa', TRUE, 'ingresada', TRUE,
                                  'puede_ver_detalle', FALSE);
    END IF;

    SELECT count(*) FILTER (WHERE NOT COALESCE(l.no_corresponde_inventario, FALSE)),
           count(*) FILTER (WHERE COALESCE(l.no_corresponde_inventario, FALSE))
      INTO v_inv, v_otras
      FROM public.facturas_xml_pendientes_lineas l
     WHERE l.factura_xml_id = v_factura.xml_id;

    RETURN jsonb_build_object(
        'identificacion_completa', TRUE,
        'ingresada', TRUE,
        'puede_ver_detalle', TRUE,
        'factura_compra_id', v_factura.factura_id,
        'factura_xml_id', v_factura.xml_id,
        'sucursal_id', v_factura.sucursal_id,
        'sucursal', v_factura.sucursal,
        'ingresada_en', v_factura.confirmado_en,
        'ingresada_por', v_factura.ingresada_por,
        'ingresada_por_ti', COALESCE(v_factura.confirmado_por = v_actor.usuario_id, FALSE),
        'lineas_inventario', v_inv,
        'lineas_no_inventario', v_otras);
END;
$$;

REVOKE ALL ON FUNCTION public.fn_consultar_factura_ingresada(text, smallint, bigint)
    FROM PUBLIC, web_anon, nury_cajero;
GRANT EXECUTE ON FUNCTION public.fn_consultar_factura_ingresada(text, smallint, bigint)
    TO nury_admin, nury_bodeguero;

-- Datos de ejemplo (se descartan con el ROLLBACK) -----------------------------------

CREATE TEMP TABLE _resultados (prueba TEXT, resultado TEXT);
GRANT ALL ON _resultados TO PUBLIC;

CREATE TEMP TABLE _casos (
    s1 INTEGER, s2 INTEGER, admin INTEGER, bod_s1 INTEGER, bod_s2 INTEGER, cajero INTEGER,
    ingrediente INTEGER, producto INTEGER
);
GRANT SELECT ON _casos TO PUBLIC;

CREATE TEMP TABLE _xml (caso TEXT PRIMARY KEY, b64 TEXT, asoc JSONB);
GRANT SELECT ON _xml TO PUBLIC;

-- Factura de ensayo en ISO-8859-1 (emisor 76.086.428-5): queso, producto de reventa y flete.
-- Neto 12.940 + 32.464 + 5.000 = 50.404; IVA 9.577; total 59.981.
CREATE FUNCTION pg_temp.dte(p_folio BIGINT)
RETURNS TEXT
LANGUAGE sql
AS $f$
    SELECT '<?xml version="1.0" encoding="ISO-8859-1"?>'
        || '<SetDTE><DTE version="1.0"><Documento ID="E' || p_folio || '">'
        || '<Encabezado><IdDoc><TipoDTE>33</TipoDTE><Folio>' || p_folio || '</Folio>'
        || '<FchEmis>2026-10-15</FchEmis></IdDoc>'
        || '<Emisor><RUTEmisor>76.086.428-5</RUTEmisor><RznSoc>Proveedor de ensayo</RznSoc></Emisor>'
        || '<Receptor><RUTRecep>11111111-1</RUTRecep></Receptor>'
        || '<Totales><MntNeto>50404</MntNeto><TasaIVA>19</TasaIVA><IVA>9577</IVA>'
        || '<MntTotal>59981</MntTotal></Totales></Encabezado>'
        || '<Detalle><NroLinDet>1</NroLinDet><CdgItem><TpoCodigo/><VlrCodigo>Q1</VlrCodigo></CdgItem>'
        || '<NmbItem>Queso</NmbItem><QtyItem>20</QtyItem><PrcItem>647</PrcItem>'
        || '<MontoItem>12940</MontoItem></Detalle>'
        || '<Detalle><NroLinDet>2</NroLinDet><CdgItem><TpoCodigo/><VlrCodigo>P2</VlrCodigo></CdgItem>'
        || '<NmbItem>Pinguino 2p 80g</NmbItem><QtyItem>16</QtyItem><PrcItem>2029</PrcItem>'
        || '<MontoItem>32464</MontoItem></Detalle>'
        || '<Detalle><NroLinDet>3</NroLinDet><NmbItem>Flete</NmbItem><QtyItem>1</QtyItem>'
        || '<PrcItem>5000</PrcItem><MontoItem>5000</MontoItem></Detalle>'
        || '</Documento></DTE></SetDTE>'
$f$;

DO $$
DECLARE
    g INTEGER; s1 INTEGER; s2 INTEGER; adm INTEGER; b1 INTEGER; b2 INTEGER; caj INTEGER;
    ing INTEGER; prod INTEGER;
BEGIN
    SELECT id INTO g FROM public.unidades_medida WHERE abreviatura = 'g';
    INSERT INTO public.sucursales (nombre) VALUES ('Ensayo T20 S1') RETURNING id INTO s1;
    INSERT INTO public.sucursales (nombre) VALUES ('Ensayo T20 S2') RETURNING id INTO s2;
    INSERT INTO public.usuarios (nombre, identificador_acceso, password_hash, rol)
        VALUES ('Admin ensayo T20', 'ensayo-t20-admin', 'x', 'admin') RETURNING id INTO adm;
    INSERT INTO public.usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('Bodeguero S1 ensayo T20', 'ensayo-t20-bod1', 'x', 'bodeguero', s1) RETURNING id INTO b1;
    INSERT INTO public.usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('Bodeguero S2 ensayo T20', 'ensayo-t20-bod2', 'x', 'bodeguero', s2) RETURNING id INTO b2;
    INSERT INTO public.usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('Cajero ensayo T20', 'ensayo-t20-cajero', 'x', 'cajero', s1) RETURNING id INTO caj;
    INSERT INTO public.ingredientes (nombre, unidad_id) VALUES ('Ensayo T20 Queso', g) RETURNING id INTO ing;
    INSERT INTO public.productos (nombre, precio_venta) VALUES ('Ensayo T20 Pinguino', 1000) RETURNING id INTO prod;
    INSERT INTO _casos VALUES (s1, s2, adm, b1, b2, caj, ing, prod);

    INSERT INTO _xml VALUES ('ok',
        encode(convert_to(pg_temp.dte(990001001), 'LATIN1'), 'base64'),
        jsonb_build_array(
            jsonb_build_object('numero_linea', 1, 'ingrediente_id', ing, 'unidades_por_presentacion', 500.5),
            jsonb_build_object('numero_linea', 2, 'producto_id', prod, 'unidades_por_presentacion', 6),
            jsonb_build_object('numero_linea', 3, 'no_corresponde_inventario', TRUE)));
END $$;

-- Fase A: admin ------------------------------------------------------------------------

SELECT set_config('request.jwt.claims', json_build_object('role', 'nury_admin', 'user_id', admin)::text, TRUE)
  FROM _casos;
SET LOCAL ROLE nury_admin;

DO $$
DECLARE
    c        _casos%ROWTYPE;
    x        RECORD;
    resp     JSONB;
BEGIN
    SELECT * INTO c FROM _casos;

    resp := public.fn_consultar_factura_ingresada('76.086.428-5', 33::smallint, 990001001);
    INSERT INTO _resultados VALUES ('C01 antes del ingreso: no está ingresada',
        CASE WHEN resp->>'ingresada' = 'false' AND resp->>'identificacion_completa' = 'true'
             THEN 'OK' ELSE 'FALLA: ' || resp::TEXT END);

    SELECT * INTO x FROM _xml WHERE caso = 'ok';
    PERFORM public.fn_ingresar_factura_xml(c.s1, x.b64, 'ok.xml', x.asoc);

    -- El RUT puede venir con puntos, como en el XML.
    resp := public.fn_consultar_factura_ingresada('76.086.428-5', 33::smallint, 990001001);
    INSERT INTO _resultados VALUES ('C02 admin ve el ingreso completo (sucursal, líneas y que fue él)',
        CASE WHEN resp->>'ingresada' = 'true' AND resp->>'puede_ver_detalle' = 'true'
                  AND (resp->>'sucursal_id')::INTEGER = c.s1
                  AND resp->>'sucursal' = 'Ensayo T20 S1'
                  AND resp->>'ingresada_por_ti' = 'true'
                  AND resp->>'ingresada_por' = 'Admin ensayo T20'
                  AND resp->>'lineas_inventario' = '2' AND resp->>'lineas_no_inventario' = '1'
                  AND resp->>'factura_compra_id' IS NOT NULL AND resp->>'ingresada_en' IS NOT NULL
             THEN 'OK' ELSE 'FALLA: ' || resp::TEXT END);

    resp := public.fn_consultar_factura_ingresada('76086428-5', 33::smallint, 990001001);
    INSERT INTO _resultados VALUES ('C03 el RUT sin puntos da el mismo resultado',
        CASE WHEN resp->>'ingresada' = 'true' THEN 'OK' ELSE 'FALLA: ' || resp::TEXT END);

    resp := public.fn_consultar_factura_ingresada('76086428-5', 34::smallint, 990001001);
    INSERT INTO _resultados VALUES ('C04 el mismo folio con otro tipo de documento no cuenta',
        CASE WHEN resp->>'ingresada' = 'false' THEN 'OK' ELSE 'FALLA: ' || resp::TEXT END);

    resp := public.fn_consultar_factura_ingresada('77654321-7', 33::smallint, 990001001);
    INSERT INTO _resultados VALUES ('C05 el mismo folio de otro emisor no cuenta',
        CASE WHEN resp->>'ingresada' = 'false' THEN 'OK' ELSE 'FALLA: ' || resp::TEXT END);

    resp := public.fn_consultar_factura_ingresada('76086428-5', 33::smallint, 990001002);
    INSERT INTO _resultados VALUES ('C06 otro folio del mismo emisor no cuenta',
        CASE WHEN resp->>'ingresada' = 'false' THEN 'OK' ELSE 'FALLA: ' || resp::TEXT END);

    INSERT INTO _resultados VALUES ('C07 identificación incompleta: RUT inválido, sin tipo o folio inválido',
        CASE WHEN (public.fn_consultar_factura_ingresada('76086428-4', 33::smallint, 990001001))
                       ->>'identificacion_completa' = 'false'
                  AND (public.fn_consultar_factura_ingresada(NULL, 33::smallint, 990001001))
                       ->>'identificacion_completa' = 'false'
                  AND (public.fn_consultar_factura_ingresada('76086428-5', NULL, 990001001))
                       ->>'identificacion_completa' = 'false'
                  AND (public.fn_consultar_factura_ingresada('76086428-5', 33::smallint, NULL))
                       ->>'identificacion_completa' = 'false'
                  AND (public.fn_consultar_factura_ingresada('76086428-5', 33::smallint, 0))
                       ->>'identificacion_completa' = 'false'
                  AND (public.fn_consultar_factura_ingresada('76086428-4', 33::smallint, 990001001))
                       ->>'ingresada' = 'false'
             THEN 'OK' ELSE 'FALLA' END);

    -- T05: tras un reintento rechazado, la consulta devuelve el ingreso existente. El rechazo
    -- es un error 23505 (20261017) o el resultado «ya_ingresada» (desde 20261020_intentos).
    BEGIN
        resp := public.fn_ingresar_factura_xml(c.s1, x.b64, 'ok.xml', x.asoc);
        IF resp->>'ya_ingresada' IS DISTINCT FROM 'true' THEN
            RAISE EXCEPTION 'se aceptó';
        END IF;
    EXCEPTION WHEN unique_violation THEN
        NULL;
    END;
    resp := public.fn_consultar_factura_ingresada('76086428-5', 33::smallint, 990001001);
    INSERT INTO _resultados VALUES ('C09 el reintento se rechaza y la consulta devuelve el ingreso existente',
        CASE WHEN resp->>'ingresada_por_ti' = 'true' AND resp->>'lineas_inventario' = '2'
             THEN 'OK' ELSE 'FALLA: ' || resp::TEXT END);
END $$;

RESET ROLE;

-- Fase B: bodegueros -----------------------------------------------------------------------

SELECT set_config('request.jwt.claims', json_build_object('role', 'nury_bodeguero', 'user_id', bod_s1)::text, TRUE)
  FROM _casos;
SET LOCAL ROLE nury_bodeguero;

DO $$
DECLARE
    c    _casos%ROWTYPE;
    resp JSONB;
BEGIN
    SELECT * INTO c FROM _casos;

    resp := public.fn_consultar_factura_ingresada('76086428-5', 33::smallint, 990001001);
    INSERT INTO _resultados VALUES ('B01 bodeguero de la misma sucursal ve el detalle, pero no fue él',
        CASE WHEN resp->>'puede_ver_detalle' = 'true' AND (resp->>'sucursal_id')::INTEGER = c.s1
                  AND resp->>'ingresada_por_ti' = 'false' AND resp->>'ingresada_por' = 'Admin ensayo T20'
             THEN 'OK' ELSE 'FALLA: ' || resp::TEXT END);
END $$;

RESET ROLE;

SELECT set_config('request.jwt.claims', json_build_object('role', 'nury_bodeguero', 'user_id', bod_s2)::text, TRUE)
  FROM _casos;
SET LOCAL ROLE nury_bodeguero;

DO $$
DECLARE
    resp JSONB;
BEGIN
    resp := public.fn_consultar_factura_ingresada('76086428-5', 33::smallint, 990001001);
    INSERT INTO _resultados VALUES ('B02 bodeguero de otra sucursal sabe que está ingresada, sin ver dónde ni quién',
        CASE WHEN resp->>'ingresada' = 'true' AND resp->>'puede_ver_detalle' = 'false'
                  AND NOT (resp ? 'sucursal') AND NOT (resp ? 'sucursal_id')
                  AND NOT (resp ? 'factura_compra_id') AND NOT (resp ? 'ingresada_por')
                  AND NOT (resp ? 'ingresada_en')
             THEN 'OK' ELSE 'FALLA: ' || resp::TEXT END);
END $$;

RESET ROLE;

-- Fase C: sin permiso -----------------------------------------------------------------------

SELECT set_config('request.jwt.claims', json_build_object('role', 'nury_cajero', 'user_id', cajero)::text, TRUE)
  FROM _casos;
SET LOCAL ROLE nury_cajero;

DO $$
BEGIN
    PERFORM public.fn_consultar_factura_ingresada('76086428-5', 33::smallint, 990001001);
    INSERT INTO _resultados VALUES ('D01 el cajero no puede consultar', 'FALLA: se aceptó');
EXCEPTION WHEN insufficient_privilege THEN
    INSERT INTO _resultados VALUES ('D01 el cajero no puede consultar', 'OK');
END $$;

RESET ROLE;

SET LOCAL ROLE web_anon;

DO $$
BEGIN
    PERFORM public.fn_consultar_factura_ingresada('76086428-5', 33::smallint, 990001001);
    INSERT INTO _resultados VALUES ('D02 un usuario anónimo no puede consultar', 'FALLA: se aceptó');
EXCEPTION WHEN insufficient_privilege THEN
    INSERT INTO _resultados VALUES ('D02 un usuario anónimo no puede consultar', 'OK');
END $$;

RESET ROLE;

-- Un JWT cuyo rol no coincide con el rol real del usuario no vale (rol bodeguero, usuario admin).
SELECT set_config('request.jwt.claims', json_build_object('role', 'nury_bodeguero', 'user_id', admin)::text, TRUE)
  FROM _casos;
SET LOCAL ROLE nury_bodeguero;

DO $$
BEGIN
    PERFORM public.fn_consultar_factura_ingresada('76086428-5', 33::smallint, 990001001);
    INSERT INTO _resultados VALUES ('D03 un JWT con rol que no coincide con el usuario no puede consultar',
        'FALLA: se aceptó');
EXCEPTION WHEN insufficient_privilege THEN
    INSERT INTO _resultados VALUES ('D03 un JWT con rol que no coincide con el usuario no puede consultar', 'OK');
END $$;

RESET ROLE;

-- Fase V: verificación de lo guardado, como propietario ------------------------------------

DO $$
DECLARE
    v_cuenta INTEGER;
BEGIN
    SELECT count(*) INTO v_cuenta FROM public.facturas_compra WHERE folio = 990001001;
    INSERT INTO _resultados VALUES ('V01 consultar y reintentar no crearon otro ingreso',
        CASE WHEN v_cuenta = 1 THEN 'OK' ELSE 'FALLA: ' || v_cuenta || ' facturas' END);

    SELECT count(*) INTO v_cuenta FROM public.detalle_factura_compra d
      JOIN public.facturas_compra f ON f.id = d.factura_id WHERE f.folio = 990001001;
    INSERT INTO _resultados VALUES ('V02 el reintento no repitió las líneas de compra (stock una sola vez)',
        CASE WHEN v_cuenta = 2 THEN 'OK' ELSE 'FALLA: ' || v_cuenta || ' líneas' END);

    SELECT count(*) INTO v_cuenta FROM public.movimientos_stock m
      JOIN _casos c ON m.ingrediente_id = c.ingrediente;
    INSERT INTO _resultados VALUES ('V03 el ingrediente tiene un solo movimiento de entrada',
        CASE WHEN v_cuenta = 1 THEN 'OK' ELSE 'FALLA: ' || v_cuenta || ' movimientos' END);
END $$;

-- pgAdmin solo muestra el resultado de la última instrucción: por eso cada prueba se
-- informa como aviso (pestaña «Messages») y el ensayo falla con error si alguna no da OK.
DO $$
DECLARE
    r       RECORD;
    fallas  INTEGER := 0;
BEGIN
    FOR r IN SELECT prueba, resultado FROM _resultados ORDER BY prueba LOOP
        RAISE NOTICE '% | %', r.resultado, r.prueba;
        IF r.resultado <> 'OK' THEN
            fallas := fallas + 1;
        END IF;
    END LOOP;

    IF fallas > 0 THEN
        RAISE EXCEPTION 'El ensayo tiene % prueba(s) con FALLA: revisa los avisos de arriba', fallas;
    END IF;
    RAISE NOTICE 'ENSAYO COMPLETO: todas las pruebas dieron OK';
END $$;

ROLLBACK;
