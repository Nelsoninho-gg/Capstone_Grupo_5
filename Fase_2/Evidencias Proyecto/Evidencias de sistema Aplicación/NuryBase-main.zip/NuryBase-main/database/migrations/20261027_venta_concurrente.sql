-- H3.2 T05 - Ventas simultáneas sin perder cantidades, descontando solo en la sucursal de la
-- venta.
--
-- Ya se cumplía:
--   - Sin pérdidas: fn_aplicar_venta (y compra, ajuste y anulación) bloquea la fila de stock
--     con SELECT ... FOR UPDATE antes de calcular y escribir el saldo. Una segunda venta del
--     mismo ítem espera a la primera y parte del saldo ya descontado.
--   - Sucursal: el descuento usa ventas.sucursal_id, y fn_registrar_venta exige que el cajero
--     tenga turno abierto en esa sucursal.
--
-- Faltaba: cada línea bloquea sus filas en el orden en que llegan. Dos ventas simultáneas con
-- los mismos ingredientes en orden distinto (sándwich+tostada y tostada+sándwich) pueden
-- quedar esperando una a la otra; PostgreSQL corta una con "deadlock detected" y el cajero ve
-- un error.
--
-- fn_registrar_venta_idempotente ahora, después de la revisión de la clave y antes de llamar a
-- fn_registrar_venta, crea (si faltan) y bloquea TODAS las filas de stock que la venta va a
-- tocar en la sucursal de la venta, siempre en el mismo orden: primero ingredientes por id,
-- luego productos por id. Así las ventas simultáneas se ordenan en fila en vez de cruzarse.
-- Lo demás de la función no cambia.
--
-- ANTES DE APLICAR EN PRODUCCIÓN: correr 20261027_venta_concurrente.ENSAYO.sql (termina en
-- ROLLBACK) y las pruebas database/tests/venta_concurrente.sql y venta_concurrente.py.

BEGIN;

CREATE OR REPLACE FUNCTION public.fn_registrar_venta_idempotente(
    p_clave UUID,
    p_sucursal_id INTEGER,
    p_cajero_id INTEGER,
    p_medio_pago CHARACTER VARYING,
    p_items JSONB,
    p_tipo_venta CHARACTER VARYING DEFAULT 'normal',
    p_empleado_id INTEGER DEFAULT NULL
)
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $function$
DECLARE
    v_existente public.ventas_idempotencia%ROWTYPE;
    v_venta_id  INTEGER;
BEGIN
    IF p_clave IS NULL THEN
        RAISE EXCEPTION 'Falta la clave única de la venta' USING ERRCODE = '22023';
    END IF;

    -- Dos envíos simultáneos de la misma venta: el segundo espera al primero.
    PERFORM pg_advisory_xact_lock(hashtextextended(p_clave::text, 0));

    SELECT * INTO v_existente FROM public.ventas_idempotencia WHERE clave = p_clave;
    IF FOUND THEN
        IF v_existente.cajero_id IS DISTINCT FROM p_cajero_id THEN
            RAISE EXCEPTION 'La clave de esta venta pertenece a otro cajero' USING ERRCODE = '42501';
        END IF;
        RETURN v_existente.venta_id;  -- reintento: la venta ya quedó registrada
    END IF;

    -- H3.2 T05: bloquear de una vez, y en orden fijo, todo el stock que tocará la venta.
    PERFORM public.fn_bloquear_stock_venta(p_sucursal_id, p_items);

    v_venta_id := public.fn_registrar_venta(
        p_sucursal_id, p_cajero_id, p_medio_pago, p_items, p_tipo_venta, p_empleado_id);

    INSERT INTO public.ventas_idempotencia (clave, venta_id, cajero_id)
    VALUES (p_clave, v_venta_id, p_cajero_id);

    RETURN v_venta_id;
END;
$function$;

-- Crea las filas de stock que falten (en 0, como haría la venta) y las bloquea en orden.
CREATE OR REPLACE FUNCTION public.fn_bloquear_stock_venta(p_sucursal_id INTEGER, p_items JSONB)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $function$
DECLARE
    v_productos    INTEGER[];
    v_ingredientes INTEGER[];
    v_reventa      INTEGER[];
BEGIN
    SELECT coalesce(array_agg(DISTINCT p.id), '{}')
      INTO v_productos
      FROM jsonb_array_elements(p_items) item
      JOIN public.productos p ON p.nombre = item->>'producto' AND p.activo;

    SELECT coalesce(array_agg(DISTINCT r.ingrediente_id), '{}')
      INTO v_ingredientes
      FROM public.recetas r
     WHERE r.producto_id = ANY (v_productos);

    SELECT coalesce(array_agg(u.producto_id), '{}')
      INTO v_reventa
      FROM unnest(v_productos) AS u(producto_id)
     WHERE NOT EXISTS (SELECT 1 FROM public.recetas r WHERE r.producto_id = u.producto_id);

    -- 1) Ingredientes de los productos con receta, por id.
    INSERT INTO public.stock_sucursal (ingrediente_id, sucursal_id, stock_actual, stock_minimo)
    SELECT i, p_sucursal_id, 0, 0 FROM unnest(v_ingredientes) i ORDER BY i
    ON CONFLICT (ingrediente_id, sucursal_id) DO NOTHING;

    PERFORM 1 FROM public.stock_sucursal
     WHERE sucursal_id = p_sucursal_id AND ingrediente_id = ANY (v_ingredientes)
     ORDER BY ingrediente_id
       FOR UPDATE;

    -- 2) Productos sin receta (stock propio, H3.2), por id.
    INSERT INTO public.stock_producto_sucursal (producto_id, sucursal_id, stock_actual, stock_minimo)
    SELECT p, p_sucursal_id, 0, 0 FROM unnest(v_reventa) p ORDER BY p
    ON CONFLICT (producto_id, sucursal_id) DO NOTHING;

    PERFORM 1 FROM public.stock_producto_sucursal
     WHERE sucursal_id = p_sucursal_id AND producto_id = ANY (v_reventa)
     ORDER BY producto_id
       FOR UPDATE;
END;
$function$;

REVOKE ALL ON FUNCTION public.fn_bloquear_stock_venta(integer, jsonb) FROM PUBLIC;

COMMIT;
