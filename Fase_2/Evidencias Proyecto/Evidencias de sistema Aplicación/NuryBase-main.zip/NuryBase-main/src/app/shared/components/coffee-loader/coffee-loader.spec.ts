import { ComponentFixture, TestBed } from '@angular/core/testing';
import {
  BLOW_END_MS,
  CoffeeLoader,
  LoadStatus,
  MIN_VISIBLE_MS,
  SLOW_AFTER_MS,
} from './coffee-loader';

describe('CoffeeLoader', () => {
  let fixture: ComponentFixture<CoffeeLoader>;

  const overlay = (): HTMLElement | null => fixture.nativeElement.querySelector('.coffee-loader');

  function create(status: LoadStatus, inputs: Record<string, unknown> = {}): void {
    fixture = TestBed.createComponent(CoffeeLoader);
    fixture.componentRef.setInput('status', status);
    Object.entries(inputs).forEach(([name, value]) => fixture.componentRef.setInput(name, value));
    fixture.detectChanges();
  }

  function setStatus(status: LoadStatus): void {
    fixture.componentRef.setInput('status', status);
    fixture.detectChanges();
  }

  function advance(ms: number): void {
    vi.advanceTimersByTime(ms);
    fixture.detectChanges();
  }

  beforeEach(() => {
    vi.useFakeTimers({
      toFake: [
        'setTimeout',
        'clearTimeout',
        'performance',
        'requestAnimationFrame',
        'cancelAnimationFrame',
      ],
    });
    TestBed.configureTestingModule({ imports: [CoffeeLoader] });
  });

  afterEach(() => {
    fixture?.destroy();
    vi.useRealTimers();
  });

  it('stays hidden when the view is already loaded', () => {
    create('ready');
    expect(overlay()).toBeNull();
  });

  it('never shows the cup when loading finishes before the show delay', () => {
    create('loading');
    advance(100);
    expect(overlay()).toBeNull();

    setStatus('ready');
    advance(2000);
    expect(overlay()).toBeNull();
  });

  it('keeps the cup a minimum time, blows the steam and then disappears', () => {
    create('loading');
    advance(250);
    expect(overlay()).not.toBeNull();
    expect(overlay()!.getAttribute('role')).toBe('status');

    setStatus('ready');
    advance(100);
    expect(overlay()!.classList).not.toContain('blowing');

    advance(MIN_VISIBLE_MS);
    expect(overlay()!.classList).toContain('blowing');

    advance(BLOW_END_MS);
    expect(overlay()).toBeNull();
  });

  it('draws the steam ribbon while the cup is visible', () => {
    create('loading');
    advance(250);
    advance(32);

    const steam = fixture.nativeElement.querySelector('.steam') as SVGPathElement;
    expect(steam.getAttribute('d')).toMatch(/^M[\d.]+ [\d.]+C.*Z$/);
  });

  it('warns about a slow connection while it keeps loading', () => {
    create('loading');
    advance(SLOW_AFTER_MS + 10);
    expect(fixture.nativeElement.textContent).toContain('La conexión está lenta');
  });

  it('shows the error with a retry button and keeps the cup while retrying', () => {
    create('loading', { errorMessage: 'No pudimos cargar el catálogo.' });
    const retry = vi.fn();
    fixture.componentInstance.retry.subscribe(retry);

    setStatus('error');
    expect(overlay()!.getAttribute('role')).toBe('alert');
    expect(overlay()!.textContent).toContain('No pudimos cargar el catálogo.');

    (fixture.nativeElement.querySelector('.loader-retry') as HTMLButtonElement).click();
    expect(retry).toHaveBeenCalledTimes(1);

    setStatus('loading');
    expect(overlay()).not.toBeNull();
    expect(fixture.nativeElement.querySelector('.loader-retry')).toBeNull();
  });

  it('shows immediately as a fullscreen overlay when showDelay is 0', () => {
    create('loading', { fullscreen: true, showDelay: 0 });
    expect(overlay()!.classList).toContain('fullscreen');
  });
});
