import {
  Component,
  DestroyRef,
  ElementRef,
  computed,
  effect,
  inject,
  input,
  output,
  signal,
  untracked,
  viewChild,
} from '@angular/core';

export type LoadStatus = 'loading' | 'ready' | 'error';

type Phase = 'waiting' | 'visible' | 'blowing' | 'leaving' | 'error' | 'gone';

/** Si apareció, la taza se queda al menos esto para que se alcance a ver el vapor. */
export const MIN_VISIBLE_MS = 900;
/** Desde aquí se avisa que la conexión está lenta. */
export const SLOW_AFTER_MS = 6000;
/** El soplido dura esto; a los BLOW_LEAVE_MS el loader empieza a desvanecerse. */
export const BLOW_END_MS = 1000;
const BLOW_LEAVE_MS = 650;

// Geometría de la estela de vapor (unidades del viewBox 160×160).
// La base parte a la altura del borde de la taza, que la tapa: el vapor "sale" del café.
const STEAM_BASE_X = 80;
const STEAM_BASE_Y = 80;
const STEAM_LENGTH = 90;
const STEAM_POINTS = 36;
const STEAM_WIDTH = 60;
const TAU = 2 * Math.PI;

const clamp01 = (v: number) => Math.min(1, Math.max(0, v));
const smoothstep = (v: number) => v * v * (3 - 2 * v);
const easeOut = (v: number) => 1 - Math.pow(1 - v, 3);

let nextId = 0;

/**
 * Taza de café con una estela de vapor que ondula mientras carga y que se
 * sopla (se dobla hacia la derecha y desaparece) cuando la vista está lista.
 *
 * - Si la carga termina antes de `showDelay`, no se muestra (evita un destello).
 * - Si alcanzó a mostrarse, se queda al menos MIN_VISIBLE_MS antes del soplido.
 * - Con conexión lenta avisa a los SLOW_AFTER_MS; con error, el vapor se apaga
 *   y se ofrece reintentar.
 */
@Component({
  selector: 'app-coffee-loader',
  standalone: true,
  templateUrl: './coffee-loader.html',
  styleUrl: './coffee-loader.css',
})
export class CoffeeLoader {
  readonly status = input<LoadStatus>('loading');
  /** Cubre toda la pantalla; si no, cubre el contenedor posicionado más cercano. */
  readonly fullscreen = input(false);
  readonly showDelay = input(200);
  readonly errorMessage = input('No pudimos cargar. Revisa tu conexión.');
  readonly retry = output<void>();

  protected readonly phase = signal<Phase>('gone');
  protected readonly slow = signal(false);
  protected readonly isVisible = computed(() => this.phase() !== 'waiting' && this.phase() !== 'gone');
  protected readonly isBlowing = computed(() => this.phase() === 'blowing' || this.phase() === 'leaving');
  protected readonly label = computed(() => {
    if (this.phase() === 'error') return this.errorMessage();
    return this.slow() ? 'La conexión está lenta, seguimos preparando…' : 'Cargando';
  });

  // Ids únicos: puede haber más de un loader en pantalla (sesión y catálogo)
  protected readonly gradientId = `coffee-steam-fade-${nextId}`;
  protected readonly blurId = `coffee-steam-blur-${nextId++}`;

  private readonly steamPath = viewChild<ElementRef<SVGPathElement>>('steamPath');
  private readonly steamWrap = viewChild<ElementRef<SVGGElement>>('steamWrap');
  private readonly steamGradient = viewChild<ElementRef<SVGLinearGradientElement>>('steamGradient');

  private timers: ReturnType<typeof setTimeout>[] = [];
  private frameId: number | null = null;
  private shownAt = 0;
  private blowStart: number | null = null;
  private coolStart: number | null = null;
  private readonly reducedMotion =
    typeof window !== 'undefined' ? window.matchMedia?.('(prefers-reduced-motion: reduce)') : undefined;

  constructor() {
    effect(() => {
      const status = this.status();
      untracked(() => this.onStatusChange(status));
    });
    // La animación del vapor corre solo mientras la taza está en pantalla
    effect(() => {
      const path = this.steamPath();
      untracked(() => (path ? this.startSteam() : this.stopSteam()));
    });
    inject(DestroyRef).onDestroy(() => {
      this.clearTimers();
      this.stopSteam();
    });
  }

  protected onRetry(): void {
    this.retry.emit();
  }

  private onStatusChange(status: LoadStatus): void {
    this.clearTimers();
    if (status === 'loading') {
      this.startLoading();
    } else if (status === 'ready') {
      this.finishLoading();
    } else {
      this.showError();
    }
  }

  private startLoading(): void {
    this.slow.set(false);
    this.blowStart = null;
    this.coolStart = null;
    // Al reintentar desde un error la taza ya está en pantalla: sigue ahí
    if (this.phase() === 'error' || this.showDelay() <= 0) {
      this.show();
    } else {
      this.phase.set('waiting');
      this.later(() => this.show(), this.showDelay());
    }
    this.later(() => this.slow.set(true), SLOW_AFTER_MS);
  }

  private show(): void {
    this.phase.set('visible');
    this.shownAt = performance.now();
  }

  private finishLoading(): void {
    const phase = this.phase();
    if (phase === 'waiting' || phase === 'error') {
      // Cargó antes de que la taza apareciera: la vista se muestra directo
      this.phase.set('gone');
      return;
    }
    if (phase !== 'visible') return;

    const wait = Math.max(0, MIN_VISIBLE_MS - (performance.now() - this.shownAt));
    this.later(() => this.blow(), wait);
  }

  private blow(): void {
    this.phase.set('blowing');
    this.blowStart = performance.now();
    const reduced = this.prefersReducedMotion();
    this.later(() => this.phase.set('leaving'), reduced ? 0 : BLOW_LEAVE_MS);
    this.later(() => this.phase.set('gone'), reduced ? 350 : BLOW_END_MS);
  }

  private showError(): void {
    if (!this.isVisible()) this.shownAt = performance.now();
    this.slow.set(false);
    this.phase.set('error');
    // Sin soplido: el vapor se apaga de a poco, como un café que se enfría
    this.coolStart = performance.now();
  }

  private later(fn: () => void, ms: number): void {
    this.timers.push(setTimeout(fn, ms));
  }

  private clearTimers(): void {
    this.timers.forEach(clearTimeout);
    this.timers = [];
  }

  private prefersReducedMotion(): boolean {
    return this.reducedMotion?.matches ?? false;
  }

  // ---- Estela de vapor ----

  private startSteam(): void {
    if (this.frameId !== null) return;
    this.drawSteam(performance.now());
    if (typeof requestAnimationFrame !== 'function') return;

    const loop = (now: number) => {
      this.drawSteam(now);
      this.frameId = requestAnimationFrame(loop);
    };
    this.frameId = requestAnimationFrame(loop);
  }

  private stopSteam(): void {
    if (this.frameId !== null) cancelAnimationFrame(this.frameId);
    this.frameId = null;
  }

  private drawSteam(now: number): void {
    const path = this.steamPath()?.nativeElement;
    const wrap = this.steamWrap()?.nativeElement;
    const gradient = this.steamGradient()?.nativeElement;
    if (!path || !wrap || !gradient) return;

    const still = this.prefersReducedMotion();
    // Tiempo desde el soplido, con un pequeño retraso para que llegue la ráfaga
    const blown = this.blowStart === null || still ? 0 : Math.max(0, (now - this.blowStart) / 1000 - 0.08);
    const bend = easeOut(clamp01(blown / 0.4));
    const time = still ? 0 : now / 1000 + blown * 3; // con viento, la ola corre más rápido

    const { outline, first, last } = steamRibbon(
      time,
      bend,
      1 - 0.45 * bend,
      60 * clamp01((blown - 0.2) / 0.65) ** 2,
    );
    path.setAttribute('d', `${smoothPath(outline)}Z`);

    // El degradado sigue la estela: opaco junto a la taza, transparente en la punta
    gradient.setAttribute('x1', first[0].toFixed(2));
    gradient.setAttribute('y1', first[1].toFixed(2));
    gradient.setAttribute('x2', last[0].toFixed(2));
    gradient.setAttribute('y2', last[1].toFixed(2));

    const blowFade = 1 - clamp01((blown - 0.5) / 0.35);
    const coolFade = this.coolStart === null ? 1 : 1 - clamp01((now - this.coolStart) / 1800);
    wrap.style.opacity = String(Math.min(blowFade, coolFade));
  }
}

type Point = [number, number];

/**
 * Contorno de la cinta de vapor: casi tan ancha como la taza al salir, se afina
 * hacia la punta y se mece de izquierda a derecha.
 * `bend` 0 = vertical, 1 = doblada en horizontal hacia la derecha (soplido).
 */
function steamRibbon(time: number, bend: number, ampScale: number, drift: number) {
  const sideA: Point[] = [];
  const sideB: Point[] = [];
  const step = (STEAM_LENGTH * (1 + 0.6 * bend)) / STEAM_POINTS; // el viento estira la estela
  let x = STEAM_BASE_X;
  let y = STEAM_BASE_Y;
  let first: Point = [x, y];
  let last: Point = [x, y];

  for (let i = 0; i <= STEAM_POINTS; i++) {
    const s = i / STEAM_POINTS; // 0 = sale de la taza, 1 = punta
    // La base sale recta y el resto se dobla con el viento, como una llama
    const angle = -Math.PI / 2 + bend * (Math.PI / 2) * smoothstep(clamp01((s - 0.08) / 0.4));
    if (i > 0) {
      x += Math.cos(angle) * step;
      y += Math.sin(angle) * step;
    }
    const nx = -Math.sin(angle);
    const ny = Math.cos(angle);

    const sway = (2 + 14 * s) * ampScale * Math.sin(TAU * 1.1 * s - time * 2.4);
    const cx = x + nx * sway + drift * s;
    const cy = y + ny * sway;

    const half = (STEAM_WIDTH / 2) * (1 - 0.35 * bend) * Math.pow(1 - s, 0.75);
    // Cada borde tiembla por su cuenta para que no parezca un tubo rígido
    const soft = Math.min(1, half / 8);
    const wobbleA = 2.5 * soft * Math.sin(TAU * 2 * s - time * 3.1);
    const wobbleB = 2.5 * soft * Math.sin(TAU * 2 * s - time * 2.7 + 1.7);

    sideA.push([cx + nx * (half + wobbleA), cy + ny * (half + wobbleA)]);
    sideB.push([cx - nx * (half + wobbleB), cy - ny * (half + wobbleB)]);
    if (i === 0) first = [cx, cy];
    last = [cx, cy];
  }

  // Sube por un borde y baja por el otro (la punta es un solo punto)
  return { outline: sideA.concat(sideB.reverse().slice(1)), first, last };
}

/** Curva suave (Catmull-Rom → Bézier) que pasa por todos los puntos. */
function smoothPath(points: Point[]): string {
  const f = (n: number) => n.toFixed(2);
  let d = `M${f(points[0][0])} ${f(points[0][1])}`;
  for (let i = 0; i < points.length - 1; i++) {
    const p0 = points[i - 1] ?? points[i];
    const p1 = points[i];
    const p2 = points[i + 1];
    const p3 = points[i + 2] ?? p2;
    const c1x = p1[0] + (p2[0] - p0[0]) / 6;
    const c1y = p1[1] + (p2[1] - p0[1]) / 6;
    const c2x = p2[0] - (p3[0] - p1[0]) / 6;
    const c2y = p2[1] - (p3[1] - p1[1]) / 6;
    d += `C${f(c1x)} ${f(c1y)} ${f(c2x)} ${f(c2y)} ${f(p2[0])} ${f(p2[1])}`;
  }
  return d;
}
