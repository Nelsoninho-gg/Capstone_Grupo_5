import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AppIconComponent, AppIconName } from './app-icon.component';

describe('AppIconComponent', () => {
  let fixture: ComponentFixture<AppIconComponent>;
  let component: AppIconComponent;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AppIconComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(AppIconComponent);
    component = fixture.componentInstance;
  });

  it('renders with default size 24 and banknote icon', () => {
    fixture.detectChanges();
    const svg = fixture.nativeElement.querySelector('svg');
    expect(svg).toBeTruthy();
    expect(svg.getAttribute('width')).toBe('24');
    expect(svg.getAttribute('height')).toBe('24');
    expect(svg.querySelector('rect')).toBeTruthy();
  });

  const icons: AppIconName[] = [
    'banknote',
    'credit-card',
    'ticket',
    'key-round',
    'check-circle',
    'circle-check',
  ];

  for (const iconName of icons) {
    it(`renders valid SVG elements for icon "${iconName}"`, () => {
      component.name = iconName;
      component.size = 32;
      fixture.detectChanges();

      const svg = fixture.nativeElement.querySelector('svg');
      expect(svg).toBeTruthy();
      expect(svg.getAttribute('width')).toBe('32');
      expect(svg.getAttribute('height')).toBe('32');
      // Has either path, rect, line or circle
      const hasChildren = svg.children.length > 0;
      expect(hasChildren).toBe(true);
    });
  }
});
