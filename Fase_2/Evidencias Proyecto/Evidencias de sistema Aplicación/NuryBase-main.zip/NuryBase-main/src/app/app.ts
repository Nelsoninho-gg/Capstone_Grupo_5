import { Component, inject, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { AppLoaderService } from './core/services/app-loader.service';
import { CoffeeLoader } from './shared/components/coffee-loader/coffee-loader';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, CoffeeLoader],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  readonly title = signal('NuryBase');
  readonly appLoader = inject(AppLoaderService);
}
