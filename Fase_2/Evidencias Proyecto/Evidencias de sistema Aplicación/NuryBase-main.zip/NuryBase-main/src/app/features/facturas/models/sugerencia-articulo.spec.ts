import { ArticuloCatalogo } from './asociacion-lineas';
import { indexarCatalogo, sugerirArticulo } from './sugerencia-articulo';

/** Parte del catálogo real (26-10-2026), con los artículos que compiten entre sí. */
const PRODUCTOS = [
  'ALFAJOR BON O BON BLANCO 40G', 'ALFAJOR BON O BON CLASICO 60G', 'ALFAJOR LAGUITO', 'ALFAJOR SANTIAGO', 'ALFI',
  'BARRA CEREAL BAR SABORES', 'BARRA CHOC KIT KAT 41.5G', 'BARRA CHOC TRENCITO 24G',
  'BOT AGUA BENEDICTINO CON GAS 500ML', 'BOT AGUA BENEDICTINO SIN GAS 500ML', 'BOT COCA COLA SIN AZUC 591ML',
  'BOT POWERADE FROZEN BLAST 600ML', 'BOT POWERADE FROZEN BLAST 850ML', 'BROWNIE CHIP', 'BROWNIE CHOC',
  'CAJA LECHE CHOCOLATE AVENA SOPROLE 200ML', 'CAJA LECHE NATURAL AVENA SOPROLE 200ML', 'DE TODITO ORIGINAL 50G',
  'DELICIA', 'GALLETA BON O BON 95G', 'GALLETA DE VINO', 'GALLETA DONUTS CHOC BLCO 100G', 'GALLETA NIK',
  'GALLETA OREO ORIGINAL', 'GALLETAS CON CHOCOLATE', 'GALLETAS MOGUL FRUTILLA 88 GRM', 'GALLETON AVENA CHOCOLATE',
  'GALLETON AVENA PASAS', 'HELADO CRAZY FRAMBUESA', 'MUFFIN CHPS CHOCOLATE', 'PAN DE MIEL', 'SANDWICH PALTA SOLO',
  'SANDWICH POLLO', 'TAKIS CHILI LIMON', 'TAKIS FUEGO 56G', 'TAKIS ORIGINAL 56G', 'TAKIS XPLOSION 56G',
].map((nombre, id): ArticuloCatalogo => ({ tipo: 'producto', id, nombre, unidad: 'un' }));

const INGREDIENTES: ArticuloCatalogo[] = [
  { tipo: 'ingrediente', id: 1, nombre: 'Aceite vegetal', unidad: 'L' },
  { tipo: 'ingrediente', id: 2, nombre: 'Azúcar', unidad: 'kg' },
  { tipo: 'ingrediente', id: 3, nombre: 'Harina', unidad: 'kg' },
];

const indice = indexarCatalogo([...INGREDIENTES, ...PRODUCTOS]);
const sugerido = (descripcion: string) => sugerirArticulo(descripcion, indice)?.nombre ?? null;

describe('sugerirArticulo', () => {
  it('matches the supplier description even with codes, sizes and packaging words', () => {
    expect(sugerido('964740 Takis Original CH 1p 49g FLOW BAR')).toBe('TAKIS ORIGINAL 56G');
    expect(sugerido('964742 Takis Fuego CH 1p 49g FLOW BAR')).toBe('TAKIS FUEGO 56G');
    expect(sugerido('502660Brownie Chip 1p 62g Bolsa NUR')).toBe('BROWNIE CHIP');
    expect(sugerido('501601 Alfi SP 3p 60g BOLSA MLA')).toBe('ALFI');
    expect(sugerido('502662 Delicia Frambuesa 1p 40g Bolsa NUR')).toBe('DELICIA');
  });

  it('accepts a single word that only one article has', () => {
    expect(sugerido('25746 Laguito 2p 70g LDS')).toBe('ALFAJOR LAGUITO');
  });

  it('ignores accents, case and abbreviations', () => {
    expect(sugerido('HARINA SIN POLVOS 25 KG')).toBe('Harina');
    expect(sugerido('azucar granulada 1 kg')).toBe('Azúcar');
    expect(sugerido('Aceite Vegetal 5L')).toBe('Aceite vegetal');
  });

  it('leaves the line pending when only common words match', () => {
    expect(sugerido('502658 Alfajor Chileno 1p 43g Bolsa NUR')).toBeNull();
    expect(sugerido('964624 Galleta ChioChoc SAz NC 1p 128g TUBO NUR')).toBeNull();
    expect(sugerido('502661Brownie Sin Azucar 1p 50g Bolsa NU')).toBeNull();
    expect(sugerido('2779Pan Blanco Sandwich 1p 700g Bolsa HO')).toBeNull();
    expect(sugerido('Flete y despacho')).toBeNull();
  });

  it('does not guess between equivalent articles, unless the size tells them apart', () => {
    expect(sugerido('Powerade Frozen Blast')).toBeNull();
    expect(sugerido('Powerade Frozen Blast 850 ml')).toBe('BOT POWERADE FROZEN BLAST 850ML');
    expect(sugerido('Agua Benedictino sin gas 500 cc')).toBe('BOT AGUA BENEDICTINO SIN GAS 500ML');
  });

  it('reads the first known word as the kind of product', () => {
    expect(sugerido('Brownie sin azúcar')).toBeNull();
    expect(sugerido('Bebida Coca Cola sin azúcar 591 ml')).toBe('BOT COCA COLA SIN AZUC 591ML');
  });

  it('returns null for an empty description or catalog', () => {
    expect(sugerido('  ')).toBeNull();
    expect(sugerirArticulo('Takis Original', indexarCatalogo([]))).toBeNull();
  });
});
