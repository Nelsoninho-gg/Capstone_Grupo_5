export type TipoArticulo = 'producto' | 'materia_prima';

export type EstadoStock = 'agotado' | 'critico' | 'estable';

/** Existencia de un artículo en una sucursal, tal como la muestra el panel de Inventario. */
export interface ExistenciaStock {
  /** Clave única de la fila: el mismo artículo aparece una vez por sucursal. */
  id: string;
  /** ingrediente_id si es materia prima o producto_id si es producto. */
  articuloId: number;
  articulo: string;
  tipo: TipoArticulo;
  /** Puede ser negativa: las ventas descuentan aunque falte stock (ver fn_aplicar_venta). */
  cantidad: number;
  /** Mínimo configurado para esta sucursal, en la misma unidad que la cantidad (≥ 0). */
  stockMinimo: number;
  unidad: string;
  sucursalId: number;
  sucursal: string;
}

/** Clave de la fila: un ingrediente y un producto pueden compartir id, pero no tipo. */
export function claveExistencia(
  tipo: TipoArticulo,
  articuloId: number,
  sucursalId: number,
): string {
  return `${tipo}-${articuloId}-${sucursalId}`;
}

/**
 * Criterio de H3.5: agotado si el stock es menor o igual a cero; crítico si es
 * positivo y menor que el mínimo; estable si es positivo e igual o mayor que el
 * mínimo. H3.5 T04 lleva esta misma regla a la base de datos.
 */
export function calcularEstadoStock(cantidad: number, stockMinimo: number): EstadoStock {
  if (cantidad <= 0) return 'agotado';
  return cantidad < stockMinimo ? 'critico' : 'estable';
}

/**
 * Stock negativo: las ventas descuentan aunque falte stock (fn_aplicar_venta), así que
 * un negativo indica compras o conteos sin registrar.
 */
export function tieneDescuadre(existencia: ExistenciaStock): boolean {
  return existencia.cantidad < 0;
}

/** Cuánto hay que reponer para llegar al mínimo; 0 si ya lo alcanza. Redondea como NUMERIC(12,3). */
export function faltanteParaMinimo(existencia: ExistenciaStock): number {
  const faltante = Math.round((existencia.stockMinimo - existencia.cantidad) * 1000) / 1000;
  return Math.max(faltante, 0);
}

export type FiltroTipo = TipoArticulo | 'todos';
/** "alertas" agrupa agotados y críticos; "descuadre" son los de stock negativo. */
export type FiltroEstado = EstadoStock | 'alertas' | 'descuadre' | 'todos';

/** Filtros del panel (H3.5 T06). Todos se combinan: una existencia debe cumplirlos a la vez. */
export interface CriteriosExistencias {
  texto: string;
  tipo: FiltroTipo;
  estado: FiltroEstado;
  /** null incluye todas las sucursales cargadas. */
  sucursalId: number | null;
}

export const CRITERIOS_SIN_FILTRO: CriteriosExistencias = {
  texto: '',
  tipo: 'todos',
  estado: 'todos',
  sucursalId: null,
};

export function cumpleFiltroEstado(existencia: ExistenciaStock, filtro: FiltroEstado): boolean {
  const estado = calcularEstadoStock(existencia.cantidad, existencia.stockMinimo);
  switch (filtro) {
    case 'todos':
      return true;
    case 'alertas':
      return estado !== 'estable';
    case 'descuadre':
      return tieneDescuadre(existencia);
    default:
      return estado === filtro;
  }
}

export function filtrarExistencias(
  existencias: ExistenciaStock[],
  criterios: CriteriosExistencias,
): ExistenciaStock[] {
  const texto = normalizarTexto(criterios.texto);
  return existencias.filter(
    (existencia) =>
      (criterios.sucursalId === null || existencia.sucursalId === criterios.sucursalId) &&
      (criterios.tipo === 'todos' || existencia.tipo === criterios.tipo) &&
      cumpleFiltroEstado(existencia, criterios.estado) &&
      (!texto || normalizarTexto(existencia.articulo).includes(texto)),
  );
}

export interface ConteoEstados extends Record<EstadoStock, number> {
  /** Agotados más críticos. */
  alertas: number;
  descuadre: number;
  total: number;
}

export function contarEstados(existencias: ExistenciaStock[]): ConteoEstados {
  const conteo: ConteoEstados = {
    agotado: 0,
    critico: 0,
    estable: 0,
    alertas: 0,
    descuadre: 0,
    total: existencias.length,
  };
  for (const existencia of existencias) {
    const estado = calcularEstadoStock(existencia.cantidad, existencia.stockMinimo);
    conteo[estado]++;
    if (estado !== 'estable') conteo.alertas++;
    if (tieneDescuadre(existencia)) conteo.descuadre++;
  }
  return conteo;
}

/** Compara sin mayúsculas ni tildes: "cafe" encuentra "Café en grano". */
export function normalizarTexto(texto: string): string {
  return texto.trim().toLocaleLowerCase('es').normalize('NFD').replace(/[̀-ͯ]/g, '');
}

/** Ajuste corrige o carga stock; merma registra una pérdida (siempre es una salida). */
export type ClaseAjuste = 'ajuste' | 'merma';

/**
 * Movimiento manual de stock (H3.6) con su motivo y quién lo registró, leído de
 * movimientos_stock (H3.6 T07).
 */
export interface AjusteStock {
  id: number;
  existenciaId: string;
  articulo: string;
  tipo: TipoArticulo;
  clase: ClaseAjuste;
  /** En la unidad del artículo: positiva entra, negativa sale. */
  cantidad: number;
  unidad: string;
  motivo: string;
  /** null en los ajustes anteriores al 20-10-2026, cuando la base empezó a guardar el usuario. */
  usuario: string | null;
  sucursalId: number;
  sucursal: string;
  fecha: Date;
}

export interface FiltroMermas {
  /** null consulta todas las sucursales visibles para el usuario. */
  sucursalId: number | null;
  /** Fechas locales en formato AAAA-MM-DD; ambos extremos se incluyen. */
  desde: string;
  hasta: string;
  /** true deja solo las mermas; false trae todos los ajustes manuales, mermas incluidas. */
  soloMermas: boolean;
}

export interface TotalMerma {
  articulo: string;
  tipo: TipoArticulo;
  unidad: string;
  /** Lo que salió y lo que entró, ambos positivos: no se compensan entre sí. */
  salida: number;
  entrada: number;
  ajustes: number;
}

/** Totales del reporte: un artículo con dos unidades distintas no se suma en una sola fila. */
export function agruparMermas(ajustes: AjusteStock[]): TotalMerma[] {
  const totales = new Map<string, TotalMerma>();
  for (const ajuste of ajustes) {
    const clave = `${ajuste.articulo}\u0000${ajuste.unidad}`;
    const total = totales.get(clave) ?? {
      articulo: ajuste.articulo,
      tipo: ajuste.tipo,
      unidad: ajuste.unidad,
      salida: 0,
      entrada: 0,
      ajustes: 0,
    };
    // Se redondea a 3 decimales, como NUMERIC(12,3), para evitar 0,30000000000000004.
    if (ajuste.cantidad < 0) {
      total.salida = Math.round((total.salida - ajuste.cantidad) * 1000) / 1000;
    } else {
      total.entrada = Math.round((total.entrada + ajuste.cantidad) * 1000) / 1000;
    }
    total.ajustes++;
    totales.set(clave, total);
  }
  return [...totales.values()].sort(
    (a, b) => a.articulo.localeCompare(b.articulo, 'es') || a.unidad.localeCompare(b.unidad, 'es'),
  );
}
