import { TestBed } from '@angular/core/testing';
import { NEVER, of, throwError } from 'rxjs';
import { ProductosApiService } from '../../../core/api/productos-api.service';
import { VentasApiService } from '../../../core/api/ventas-api.service';
import { TurnosApiService, TurnoApi } from '../../../core/api/turnos-api.service';
import { UsuariosApiService } from '../../../core/api/usuarios-api.service';
import { AuthService } from '../../auth/services/auth.service';
import { PosProduct } from '../models/pos.model';
import { PosService } from './pos.service';

const TEST_PRODUCT: PosProduct = {
  id: 1,
  nombre: 'Café Espresso Doble',
  categoriaId: 'BEBESTIBLES - CAFÉ',
  categoriaNombre: 'BEBESTIBLES - CAFÉ',
  codigoInterno: 'NUR-101',
  codigoBarras: '7801234501018',
  precioVenta: 2600,
  icono: '☕',
  descripcion: 'Producto exclusivo para pruebas.',
  activo: true,
};

describe('PosService', () => {
  let service: PosService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: ProductosApiService, useValue: { listar: () => NEVER } },
        { provide: VentasApiService, useValue: { registrar: () => of(999) } },
      ],
    });
    service = TestBed.inject(PosService);
    service.catalog.set([TEST_PRODUCT]);
    service.clearCart();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should support products loaded into the catalog with internal codes (H2.3)', () => {
    const products = service.catalog();
    expect(products.length).toBeGreaterThan(0);
    expect(products.some((p) => p.codigoInterno.startsWith('NUR-'))).toBe(true);
  });

  it('should add products to cart and calculate total correctly', () => {
    const product = service.catalog()[0];
    service.addToCart(product);

    expect(service.cart().length).toBe(1);
    expect(service.total()).toBe(product.precioVenta);

    // Añadir de nuevo debe incrementar cantidad
    service.addToCart(product);
    expect(service.cart().length).toBe(1);
    expect(service.cart()[0].cantidad).toBe(2);
    expect(service.total()).toBe(product.precioVenta * 2);
  });

  it('should add product by internal code or barcode (H2.1 & H2.3)', () => {
    const success = service.addByCode('NUR-101');
    expect(success).toBe(true);
    expect(service.cart().length).toBe(1);
    expect(service.cart()[0].producto.codigoInterno).toBe('NUR-101');
  });

  it('assigns the category icon to products loaded from the API', () => {
    const api = TestBed.inject(ProductosApiService);
    vi.spyOn(api, 'listar').mockReturnValue(
      of([
        {
          id: 7,
          nombre: 'EMPANADA PINO',
          categoria: 'ALIMENTOS - EMPANADAS',
          precio_compra: 1200,
          precio_venta: 2500,
          codigo_barras: null,
          activo: true,
          creado_en: '2026-09-29T12:00:00Z',
        },
      ]),
    );

    service.cargarCatalogoDesdeApi();

    expect(service.catalog()[0].icono).toBe('empanada');
    expect(service.catalogStatus()).toBe('ready');
  });

  it('marks the catalog load as failed so the POS can offer a retry', () => {
    const api = TestBed.inject(ProductosApiService);
    vi.spyOn(api, 'listar').mockReturnValue(throwError(() => new Error('Sin conexión')));
    vi.spyOn(console, 'error').mockImplementation(() => {});

    service.cargarCatalogoDesdeApi();

    expect(service.catalogStatus()).toBe('error');
  });

  it('unifies categories that share their leading word into a single POS tab', () => {
    const withCategory = (id: number, categoriaNombre: string): PosProduct => ({
      ...TEST_PRODUCT,
      id,
      categoriaId: categoriaNombre,
      categoriaNombre,
    });
    service.catalog.set([
      withCategory(1, 'ALIMENTOS - EMPANADAS'),
      withCategory(2, 'ALIMENTOS - SANDWICH'),
      withCategory(3, 'Empanada Pino'),
      withCategory(4, 'EMPANADAS QUESO'),
      withCategory(5, 'BEBESTIBLES - CAFÉ'),
      withCategory(6, 'HELADOS - HELADOS'),
    ]);

    expect(service.categories().map((c) => c.nombre)).toEqual([
      'Todos',
      'ALIMENTOS',
      'BEBESTIBLES - CAFÉ',
      'Empanada',
      'HELADOS',
    ]);
    expect(service.categoryGroupOf(service.catalog()[5])).toBe('HELADOS');
    expect(service.categoryGroupOf(service.catalog()[1])).toBe('ALIMENTOS');
    expect(service.categoryGroupOf(service.catalog()[3])).toBe('Empanada');
    expect(service.categoryGroupOf(service.catalog()[4])).toBe('BEBESTIBLES - CAFÉ');
  });

  it('should complete sale and compute correct change (H2.4)', () => {
    const product = service.catalog()[0];
    service.addToCart(product);
    const total = service.total();

    let sale: import('../models/pos.model').CompletedSale | undefined;
    service
      .completeSale(
        'efectivo',
        total + 2000,
        { id: 1, nombre: 'Camila Rojas' },
        { id: 1, nombre: 'Nury Providencia' },
      )
      .subscribe((result) => (sale = result));

    expect(sale?.id).toBe(999); // 999 es el id que devuelve el mock de VentasApiService
    expect(sale?.vuelto).toBe(2000);
    expect(sale?.medioPago).toBe('efectivo');
    expect(service.cart().length).toBe(0);
    expect(service.salesHistory().length).toBe(1);
  });
});

describe('PosService — venta a empleado (H2.12)', () => {
  const CAJERO = { id: 7, nombre: 'Camila Rojas' };
  const SUCURSAL = { id: 1, nombre: 'Nury Providencia' };
  const EMPLEADOS = [
    { id: 5, nombre: 'Ana Pérez' },
    { id: 9, nombre: 'Luis Soto' },
  ];
  // 1.995 × 30% = 598,5 → se redondea a 599 pesos.
  const PRODUCTO_REDONDEO: PosProduct = { ...TEST_PRODUCT, id: 2, nombre: 'Kuchen', precioVenta: 1995 };

  let service: PosService;
  let registrar: ReturnType<typeof vi.fn>;
  let listarEmpleados: ReturnType<typeof vi.fn>;

  beforeEach(() => {
    registrar = vi.fn(() => of(31));
    listarEmpleados = vi.fn(() => of(EMPLEADOS));
    TestBed.configureTestingModule({
      providers: [
        { provide: ProductosApiService, useValue: { listar: () => NEVER } },
        { provide: VentasApiService, useValue: { registrar } },
        { provide: UsuariosApiService, useValue: { listarEmpleados } },
      ],
    });
    service = TestBed.inject(PosService);
    service.catalog.set([TEST_PRODUCT, PRODUCTO_REDONDEO]);
    service.clearCart();
  });

  it('starts as a normal sale without discount', () => {
    service.addToCart(TEST_PRODUCT);

    expect(service.ventaEmpleado()).toBe(false);
    expect(service.subtotal()).toBe(2600);
    expect(service.descuento()).toBe(0);
    expect(service.total()).toBe(2600);
    expect(listarEmpleados).not.toHaveBeenCalled();
  });

  it('applies 30% over the total rounded to pesos and loads the employees once', () => {
    service.addToCart(PRODUCTO_REDONDEO);
    service.setVentaEmpleado(true);

    expect(service.subtotal()).toBe(1995);
    expect(service.descuento()).toBe(599);
    expect(service.total()).toBe(1396);
    expect(service.empleados()).toEqual(EMPLEADOS);
    expect(service.empleadosStatus()).toBe('ready');

    service.setVentaEmpleado(false);
    service.setVentaEmpleado(true);
    expect(listarEmpleados).toHaveBeenCalledTimes(1);
  });

  it('recalculates subtotal, discount and total when adding, changing or removing products', () => {
    service.setVentaEmpleado(true);

    service.addToCart(TEST_PRODUCT);
    expect([service.subtotal(), service.descuento(), service.total()]).toEqual([2600, 780, 1820]);

    service.addToCart(PRODUCTO_REDONDEO);
    expect([service.subtotal(), service.descuento(), service.total()]).toEqual([4595, 1379, 3216]);

    service.updateQuantity(TEST_PRODUCT.id, 1);
    expect([service.subtotal(), service.descuento(), service.total()]).toEqual([7195, 2159, 5036]);

    service.updateQuantity(TEST_PRODUCT.id, -1);
    service.removeFromCart(PRODUCTO_REDONDEO.id);
    expect([service.subtotal(), service.descuento(), service.total()]).toEqual([2600, 780, 1820]);

    service.removeFromCart(TEST_PRODUCT.id);
    expect([service.subtotal(), service.descuento(), service.total()]).toEqual([0, 0, 0]);
  });

  it('removes the discount and the employee when the option is unchecked', () => {
    service.addToCart(TEST_PRODUCT);
    service.setVentaEmpleado(true);
    service.seleccionarEmpleado(5);

    service.setVentaEmpleado(false);

    expect(service.empleadoSeleccionado()).toBeNull();
    expect(service.descuento()).toBe(0);
    expect(service.total()).toBe(2600);
  });

  it('does not register an employee sale until the employee is selected', () => {
    service.addToCart(TEST_PRODUCT);
    service.setVentaEmpleado(true);
    expect(service.faltaEmpleado()).toBe(true);

    let error: Error | undefined;
    service.completeSale('efectivo', 1820, CAJERO, SUCURSAL).subscribe({ error: (e) => (error = e) });

    expect(error?.message).toBe('Selecciona el empleado que compra.');
    expect(registrar).not.toHaveBeenCalled();
    expect(service.cart()).toHaveLength(1);
  });

  it('registers the employee sale with its employee and an EMP- code, then starts the next sale as normal', () => {
    service.addToCart(TEST_PRODUCT);
    service.setVentaEmpleado(true);
    service.seleccionarEmpleado(5);

    let sale: import('../models/pos.model').CompletedSale | undefined;
    service.completeSale('debito', 1820, CAJERO, SUCURSAL).subscribe((result) => (sale = result));

    expect(registrar).toHaveBeenCalledWith(
      expect.objectContaining({ p_tipo_venta: 'empleado', p_empleado_id: 5, p_medio_pago: 'debito' }),
    );
    // El precio del producto no cambia: el descuento lo aplica la venta.
    expect(registrar.mock.calls[0][0].p_items[0].precio_unitario).toBe(2600);
    expect(sale).toEqual(
      expect.objectContaining({
        ticketFolio: 'EMP-31',
        tipoVenta: 'empleado',
        empleadoNombre: 'Ana Pérez',
        subtotal: 2600,
        descuento: 780,
        total: 1820,
      }),
    );
    expect(service.catalog()[0].precioVenta).toBe(2600);
    expect(service.cart()).toHaveLength(0);
    expect(service.ventaEmpleado()).toBe(false);
    expect(service.empleadoSeleccionado()).toBeNull();
  });

  it.each(['efectivo', 'debito', 'credito', 'sodexo', 'edenred'] as const)(
    'applies the same employee discount when paying with %s (T06)',
    (medioPago) => {
      service.addToCart(TEST_PRODUCT);
      service.addToCart(PRODUCTO_REDONDEO);
      service.setVentaEmpleado(true);
      service.seleccionarEmpleado(9);

      let sale: import('../models/pos.model').CompletedSale | undefined;
      service.completeSale(medioPago, service.total(), CAJERO, SUCURSAL).subscribe((r) => (sale = r));

      expect(registrar).toHaveBeenCalledWith(
        expect.objectContaining({ p_medio_pago: medioPago, p_tipo_venta: 'empleado', p_empleado_id: 9 }),
      );
      // $2.600 + $1.995 = $4.595; 30% = $1.378,5 → $1.379; total $3.216.
      expect(sale).toEqual(
        expect.objectContaining({ medioPago, subtotal: 4595, descuento: 1379, total: 3216 }),
      );
    },
  );

  it('keeps sending a normal sale exactly as before', () => {
    service.addToCart(TEST_PRODUCT);

    let sale: import('../models/pos.model').CompletedSale | undefined;
    service.completeSale('efectivo', 3000, CAJERO, SUCURSAL).subscribe((result) => (sale = result));

    const payload = registrar.mock.calls[0][0];
    expect(payload).not.toHaveProperty('p_tipo_venta');
    expect(payload).not.toHaveProperty('p_empleado_id');
    expect(sale?.ticketFolio).toBe('TK-31');
    expect(sale?.tipoVenta).toBe('normal');
    expect(sale?.total).toBe(2600);
  });

  describe('unique key per sale (H2.5 T05)', () => {
    const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
    const claves = () => registrar.mock.calls.map((llamada) => llamada[0].p_clave);

    it('sends a UUID with every sale and a new one for the next sale', () => {
      service.addToCart(TEST_PRODUCT);
      service.completeSale('efectivo', 3000, CAJERO, SUCURSAL).subscribe();
      service.addToCart(TEST_PRODUCT);
      service.completeSale('efectivo', 3000, CAJERO, SUCURSAL).subscribe();

      expect(claves()[0]).toMatch(UUID);
      expect(claves()[1]).toMatch(UUID);
      expect(claves()[1]).not.toBe(claves()[0]);
    });

    it('retries a failed sale with the same key and keeps the cart', () => {
      registrar.mockReturnValueOnce(throwError(() => new Error('timeout')));
      service.addToCart(TEST_PRODUCT);

      service.completeSale('efectivo', 3000, CAJERO, SUCURSAL).subscribe({ error: () => undefined });
      expect(service.cart()).toHaveLength(1);
      let sale: import('../models/pos.model').CompletedSale | undefined;
      service.completeSale('efectivo', 3000, CAJERO, SUCURSAL).subscribe((r) => (sale = r));

      expect(claves()).toHaveLength(2);
      expect(claves()[1]).toBe(claves()[0]);
      expect(sale?.id).toBe(31);
      expect(service.cart()).toHaveLength(0);
    });

    it('uses a new key if the sale changes before retrying', () => {
      registrar.mockReturnValueOnce(throwError(() => new Error('timeout')));
      service.addToCart(TEST_PRODUCT);
      service.completeSale('efectivo', 3000, CAJERO, SUCURSAL).subscribe({ error: () => undefined });

      service.addToCart(TEST_PRODUCT);
      service.completeSale('efectivo', 6000, CAJERO, SUCURSAL).subscribe();
      registrar.mockReturnValueOnce(throwError(() => new Error('timeout')));
      service.addToCart(TEST_PRODUCT);
      service.completeSale('efectivo', 3000, CAJERO, SUCURSAL).subscribe({ error: () => undefined });
      service.completeSale('debito', 2600, CAJERO, SUCURSAL).subscribe();

      // Otro carrito y otro medio de pago: cada uno es una venta distinta.
      expect(new Set(claves()).size).toBe(4);
    });
  });

  it('marks the employee list as failed so the cashier can retry', () => {
    listarEmpleados.mockReturnValueOnce(throwError(() => new Error('sin red')));
    vi.spyOn(console, 'error').mockImplementation(() => undefined);

    service.setVentaEmpleado(true);
    expect(service.empleadosStatus()).toBe('error');

    service.cargarEmpleados();
    expect(service.empleadosStatus()).toBe('ready');
    expect(service.empleados()).toEqual(EMPLEADOS);
  });
});

describe('PosService — turno persistente entre recargas', () => {
  const CAJERO = { id: 7, nombre: 'Camila Rojas' };
  const SUCURSAL = { id: 1, nombre: 'Nury Providencia' };

  // Turno falso que devuelve el mock de TurnosApiService, como si viniera
  // de fn_abrir_turno/fn_cerrar_turno en producción.
  function fakeTurno(usuarioId: number, cerrado = false): TurnoApi {
    return {
      id: 42,
      usuario_id: usuarioId,
      sucursal_id: SUCURSAL.id,
      hora_inicio: new Date().toISOString(),
      hora_fin: cerrado ? new Date().toISOString() : null,
      creado_en: new Date().toISOString(),
      monto_inicial: 0,
    };
  }

  // Simula una carga completa de la página: módulo nuevo e instancia nueva de PosService,
  // con sessionStorage intacto y la sesión del usuario indicado ya restaurada.
  function loadPosService(usuarioId: number): PosService {
    TestBed.resetTestingModule();
    TestBed.configureTestingModule({
      providers: [
        { provide: ProductosApiService, useValue: { listar: () => NEVER } },
        { provide: VentasApiService, useValue: { registrar: () => of(999) } },
        { provide: AuthService, useValue: { currentUser: () => ({ id: usuarioId, sucursalId: SUCURSAL.id }) } },
        {
          provide: TurnosApiService,
          useValue: {
            abrir: () => of(fakeTurno(usuarioId)),
            cerrar: () => of(fakeTurno(usuarioId, true)),
          },
        },
      ],
    });
    const pos = TestBed.inject(PosService);
    pos.catalog.set([TEST_PRODUCT]);
    return pos;
  }

  beforeEach(() => sessionStorage.clear());
  afterEach(() => sessionStorage.clear());

  it('keeps the open register and its sales after a reload', () => {
    const before = loadPosService(CAJERO.id);
    before.abrirTurno(CAJERO.id, SUCURSAL.id, 0).subscribe();
    before.addToCart(TEST_PRODUCT);
    before.completeSale('efectivo', 5000, CAJERO, SUCURSAL).subscribe();

    const after = loadPosService(CAJERO.id);

    expect(after.isRegisterOpen()).toBe(true);
    expect(after.salesHistory().length).toBe(1);
    expect(after.salesHistory()[0].total).toBe(TEST_PRODUCT.precioVenta);
    expect(after.salesHistory()[0].fecha).toBeInstanceOf(Date);
  });

  it('keeps voided sales of the shift after a reload', () => {
    const before = loadPosService(CAJERO.id);
    TestBed.inject(VentasApiService).anular = () => of(undefined);
    before.abrirTurno(CAJERO.id, SUCURSAL.id, 0).subscribe();
    before.addToCart(TEST_PRODUCT);
    before.completeSale('efectivo', 5000, CAJERO, SUCURSAL).subscribe();
    before.anularVenta(999, 'Error de digitación').subscribe();

    const after = loadPosService(CAJERO.id);

    expect(after.salesHistory().length).toBe(0);
    expect(after.anuladasTurno().length).toBe(1);
    expect(after.anuladasTurno()[0].anuladaEn).toBeInstanceOf(Date);
    expect(after.anuladasTurno()[0].venta.fecha).toBeInstanceOf(Date);
  });

  it('reflects in the shift a sale voided elsewhere and ignores sales of other shifts', () => {
    const pos = loadPosService(CAJERO.id);
    pos.abrirTurno(CAJERO.id, SUCURSAL.id, 0).subscribe();
    pos.addToCart(TEST_PRODUCT);
    pos.completeSale('efectivo', 5000, CAJERO, SUCURSAL).subscribe();

    pos.sincronizarAnulacion(12345, 'Venta de otro turno');
    expect(pos.salesHistory().length).toBe(1);
    expect(pos.anuladasTurno()).toEqual([]);

    pos.sincronizarAnulacion(999, 'Anulada por el administrador');
    expect(pos.salesHistory().length).toBe(0);
    expect(pos.anuladasTurno()[0].motivo).toBe('Anulada por el administrador');
  });

  it('starts closed after a reload once the shift was closed', () => {
    const before = loadPosService(CAJERO.id);
    before.abrirTurno(CAJERO.id, SUCURSAL.id, 0).subscribe();
    before.resetSalesHistory();
    before.cerrarTurnoActivo().subscribe();

    const after = loadPosService(CAJERO.id);

    expect(after.isRegisterOpen()).toBe(false);
    expect(sessionStorage.getItem('nury_turno')).toBeNull();
  });

  it('does not hand an open shift to a different user in the same tab', () => {
    loadPosService(CAJERO.id).abrirTurno(CAJERO.id, SUCURSAL.id, 0).subscribe();

    const otroUsuario = loadPosService(99);

    expect(otroUsuario.isRegisterOpen()).toBe(false);
    expect(otroUsuario.salesHistory()).toEqual([]);
  });

  it('ignores a corrupted stored shift', () => {
    sessionStorage.setItem('nury_turno', '{no es json');

    const pos = loadPosService(CAJERO.id);

    expect(pos.isRegisterOpen()).toBe(false);
    expect(sessionStorage.getItem('nury_turno')).toBeNull();
  });
});

describe('PosService — stock insuficiente al vender (H2.5 T04)', () => {
  const CAJERO = { id: 7, nombre: 'Camila Rojas' };
  const SUCURSAL = { id: 1, nombre: 'Nury Providencia' };
  const QUESO = {
    tipo: 'ingrediente' as const,
    item_id: 3,
    nombre: 'Queso',
    sucursal_id: 1,
    unidad: 'g',
    requerido: 120,
    disponible: 100,
    faltante: 20,
    stock_actual: -20,
  };

  let service: PosService;
  let stockInsuficiente: ReturnType<typeof vi.fn>;

  beforeEach(() => {
    sessionStorage.clear();
    stockInsuficiente = vi.fn(() => of([QUESO]));
    TestBed.configureTestingModule({
      providers: [
        { provide: ProductosApiService, useValue: { listar: () => NEVER } },
        { provide: VentasApiService, useValue: { registrar: () => of(50), stockInsuficiente } },
      ],
    });
    service = TestBed.inject(PosService);
    service.catalog.set([TEST_PRODUCT]);
    service.clearCart();
    service.addToCart(TEST_PRODUCT);
  });

  afterEach(() => sessionStorage.clear());

  it('returns with the sale the ingredients that were left without enough stock', () => {
    let sale: import('../models/pos.model').CompletedSale | undefined;
    service.completeSale('efectivo', 5000, CAJERO, SUCURSAL).subscribe((r) => (sale = r));

    expect(stockInsuficiente).toHaveBeenCalledWith(50);
    expect(sale?.stockInsuficiente).toEqual([
      { nombre: 'Queso', unidad: 'g', requerido: 120, disponible: 100, faltante: 20 },
    ]);
    expect(service.salesHistory()[0].stockInsuficiente).toHaveLength(1);
  });

  it('returns an empty list when the stock was enough', () => {
    stockInsuficiente.mockReturnValue(of([]));
    let sale: import('../models/pos.model').CompletedSale | undefined;
    service.completeSale('efectivo', 5000, CAJERO, SUCURSAL).subscribe((r) => (sale = r));

    expect(sale?.stockInsuficiente).toEqual([]);
  });

  it('keeps the sale registered, without warning, when the stock query fails', () => {
    stockInsuficiente.mockReturnValue(throwError(() => new Error('offline')));
    let sale: import('../models/pos.model').CompletedSale | undefined;
    let error: unknown;
    service
      .completeSale('efectivo', 5000, CAJERO, SUCURSAL)
      .subscribe({ next: (r) => (sale = r), error: (e) => (error = e) });

    expect(error).toBeUndefined();
    expect(sale?.id).toBe(50);
    expect(sale?.stockInsuficiente).toBeUndefined();
    expect(service.cart()).toHaveLength(0);
    expect(service.salesHistory()).toHaveLength(1);
  });
});
