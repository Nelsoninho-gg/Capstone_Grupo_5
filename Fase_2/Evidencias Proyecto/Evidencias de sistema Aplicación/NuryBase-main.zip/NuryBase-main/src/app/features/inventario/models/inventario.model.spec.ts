import {
  CRITERIOS_SIN_FILTRO,
  CriteriosExistencias,
  ExistenciaStock,
  FiltroEstado,
  contarEstados,
  cumpleFiltroEstado,
  faltanteParaMinimo,
  filtrarExistencias,
  normalizarTexto,
} from './inventario.model';

function existencia(
  articulo: string,
  cambios: Partial<ExistenciaStock> & Pick<ExistenciaStock, 'cantidad' | 'stockMinimo'>,
): ExistenciaStock {
  return {
    id: articulo,
    articuloId: 0,
    articulo,
    tipo: 'materia_prima',
    unidad: 'kg',
    sucursalId: 1,
    sucursal: 'Nury Providencia',
    ...cambios,
  };
}

const cafe = existencia('Café en grano', { cantidad: 4.25, stockMinimo: 2 });
const azucar = existencia('Azúcar', { cantidad: 0.6, stockMinimo: 1 });
const leche = existencia('Leche entera', { cantidad: 0, stockMinimo: 3, unidad: 'l' });
const agua = existencia('Agua mineral 500 ml', {
  tipo: 'producto',
  cantidad: -2,
  stockMinimo: 12,
  unidad: 'un',
  sucursalId: 2,
  sucursal: 'Nury Ñuñoa',
});
const galletas = existencia('Galletas de avena', {
  tipo: 'producto',
  cantidad: 3,
  stockMinimo: 10,
  unidad: 'un',
});
const todas = [cafe, azucar, leche, agua, galletas];

function filtrar(criterios: Partial<CriteriosExistencias>): string[] {
  return filtrarExistencias(todas, { ...CRITERIOS_SIN_FILTRO, ...criterios }).map(
    (e) => e.articulo,
  );
}

describe('cumpleFiltroEstado', () => {
  it.each<[FiltroEstado, boolean[]]>([
    ['todos', [true, true, true, true, true]],
    ['alertas', [false, true, true, true, true]],
    ['agotado', [false, false, true, true, false]],
    ['critico', [false, true, false, false, true]],
    ['estable', [true, false, false, false, false]],
    ['descuadre', [false, false, false, true, false]],
  ])('filtro "%s"', (filtro, esperado) => {
    expect(todas.map((e) => cumpleFiltroEstado(e, filtro))).toEqual(esperado);
  });
});

describe('filtrarExistencias', () => {
  it('returns every item without filters', () => {
    expect(filtrar({})).toHaveLength(todas.length);
  });

  it('combines state and type', () => {
    expect(filtrar({ estado: 'alertas', tipo: 'producto' })).toEqual([
      'Agua mineral 500 ml',
      'Galletas de avena',
    ]);
    expect(filtrar({ estado: 'critico', tipo: 'materia_prima' })).toEqual(['Azúcar']);
    expect(filtrar({ estado: 'estable', tipo: 'producto' })).toEqual([]);
  });

  it('combines state, type, branch and text at the same time', () => {
    expect(filtrar({ estado: 'agotado', tipo: 'producto', sucursalId: 1 })).toEqual([]);
    expect(filtrar({ estado: 'agotado', tipo: 'producto', sucursalId: 2 })).toEqual([
      'Agua mineral 500 ml',
    ]);
    expect(filtrar({ estado: 'alertas', sucursalId: 1, texto: 'LECHE' })).toEqual(['Leche entera']);
  });

  it('searches without accents or case and ignores surrounding spaces', () => {
    expect(filtrar({ texto: '  azucar ' })).toEqual(['Azúcar']);
    expect(filtrar({ texto: 'CAFÉ' })).toEqual(['Café en grano']);
  });

  it('keeps the original order of the list', () => {
    expect(filtrar({ estado: 'alertas' })).toEqual([
      'Azúcar',
      'Leche entera',
      'Agua mineral 500 ml',
      'Galletas de avena',
    ]);
  });
});

describe('contarEstados', () => {
  it('counts each state, the alerts and the mismatches', () => {
    expect(contarEstados(todas)).toEqual({
      agotado: 2,
      critico: 2,
      estable: 1,
      alertas: 4,
      descuadre: 1,
      total: 5,
    });
  });

  it('counts stock equal to the minimum as stable, and zero or negative stock as out of stock even with minimum zero', () => {
    const limites = [
      existencia('Justo en el mínimo', { cantidad: 1.125, stockMinimo: 1.125 }),
      existencia('Sin stock ni mínimo', { cantidad: 0, stockMinimo: 0 }),
      existencia('Negativo sin mínimo', { cantidad: -0.5, stockMinimo: 0 }),
    ];

    expect(contarEstados(limites)).toEqual({
      agotado: 2,
      critico: 0,
      estable: 1,
      alertas: 2,
      descuadre: 1,
      total: 3,
    });
  });

  it('counts zero for an empty list', () => {
    expect(contarEstados([])).toEqual({
      agotado: 0,
      critico: 0,
      estable: 0,
      alertas: 0,
      descuadre: 0,
      total: 0,
    });
  });
});

describe('faltanteParaMinimo', () => {
  it.each([
    [0.6, 1, 0.4],
    [0, 3, 3],
    [-2, 12, 14],
    [5, 5, 0],
    [8, 5, 0],
    [0, 0, 0],
    [0.1, 0.3, 0.2],
    [1.124, 1.125, 0.001],
    [-3, 0, 3],
  ])('stock %s con mínimo %s le faltan %s', (cantidad, stockMinimo, esperado) => {
    expect(faltanteParaMinimo(existencia('X', { cantidad, stockMinimo }))).toBe(esperado);
  });
});

describe('normalizarTexto', () => {
  it('removes accents, case and surrounding spaces', () => {
    expect(normalizarTexto('  Ñuñoa CAFÉ ')).toBe('nunoa cafe');
  });
});
