import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, catchError, map, switchMap, throwError } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { IngredientesApiService } from '../../../core/api/ingredientes-api.service';
import { UnidadesMedidaApiService } from '../../../core/api/unidades-medida-api.service';
import { ArticuloCatalogo, DatosMateriaPrima, UnidadCatalogo } from '../models/catalogo.model';
import { TipoArticulo } from '../../inventario/models/inventario.model';

/** Fila de la vista v_articulos (migración 20261021_modelo_articulos.sql). */
export interface ArticuloApi {
  tipo: TipoArticulo;
  articulo_id: number;
  nombre: string;
  unidad_id: number | null;
  unidad: string;
  codigo_barras: string | null;
  activo: boolean;
}

const ARTICULO_FIELDS = 'tipo,articulo_id,nombre,unidad_id,unidad,codigo_barras,activo';

/**
 * Ingredientes (materias primas) del Maestro de Productos. Antes era la pestaña Catálogo de
 * Inventario (H3.3 T01–T03). Lee las materias primas de la vista v_articulos y escribe con
 * IngredientesApiService.
 * Después de cada cambio vuelve a leer la fila desde la vista, así la pantalla muestra
 * exactamente lo que quedó guardado (incluida la abreviatura de la unidad).
 */
@Injectable({ providedIn: 'root' })
export class CatalogoService {
  private readonly http = inject(HttpClient);
  private readonly ingredientesApi = inject(IngredientesApiService);
  private readonly unidadesApi = inject(UnidadesMedidaApiService);
  private readonly url = `${environment.apiUrl}/v_articulos`;

  listarMateriasPrimas(): Observable<ArticuloCatalogo[]> {
    return this.http
      .get<ArticuloApi[]>(this.url, {
        params: { select: ARTICULO_FIELDS, tipo: 'eq.materia_prima', order: 'nombre.asc' },
      })
      .pipe(map((filas) => filas.map(aArticulo)));
  }

  listarUnidades(): Observable<UnidadCatalogo[]> {
    return this.unidadesApi.listar();
  }

  crearMateriaPrima(datos: DatosMateriaPrima): Observable<ArticuloCatalogo> {
    return this.ingredientesApi
      .crear({
        nombre: datos.nombre,
        unidad_id: datos.unidadId,
        categoria_id: null,
        codigo_barras: datos.codigoBarras,
      })
      .pipe(
        switchMap((creado) => this.obtener('materia_prima', creado.id)),
        catchError((error) => throwError(() => errorGuardado(error, 'crear'))),
      );
  }

  /** Solo cambia nombre y código de barras: la unidad queda fija desde la creación (H3.3). */
  editarMateriaPrima(id: number, datos: DatosMateriaPrima): Observable<ArticuloCatalogo> {
    return this.ingredientesApi
      .actualizar(id, { nombre: datos.nombre, codigo_barras: datos.codigoBarras })
      .pipe(
        switchMap(() => this.obtener('materia_prima', id)),
        catchError((error) => throwError(() => errorGuardado(error, 'editar'))),
      );
  }

  /** Activa o desactiva sin borrar: la materia prima conserva su historial de stock. */
  cambiarEstado(articulo: ArticuloCatalogo, activo: boolean): Observable<ArticuloCatalogo> {
    return this.ingredientesApi.actualizarEstado(articulo.id, activo).pipe(
      switchMap(() => this.obtener('materia_prima', articulo.id)),
      catchError((error) => throwError(() => errorEstado(error, articulo.nombre))),
    );
  }

  private obtener(tipo: TipoArticulo, id: number): Observable<ArticuloCatalogo> {
    return this.http
      .get<ArticuloApi[]>(this.url, {
        params: { select: ARTICULO_FIELDS, tipo: `eq.${tipo}`, articulo_id: `eq.${id}` },
      })
      .pipe(
        map(([fila]) => {
          if (!fila) throw new Error('El artículo ya no está disponible. Actualiza el listado.');
          return aArticulo(fila);
        }),
      );
  }
}

export function aArticulo(fila: ArticuloApi): ArticuloCatalogo {
  return {
    tipo: fila.tipo,
    id: fila.articulo_id,
    nombre: fila.nombre,
    unidad: fila.unidad,
    unidadId: fila.unidad_id,
    codigoBarras: fila.codigo_barras,
    activo: fila.activo,
  };
}

/** Mensaje de PostgREST/PostgreSQL (por ejemplo el del trigger de unidad fija), si viene. */
function mensajeServidor(error: HttpErrorResponse): string | null {
  const cuerpo = error.error as { message?: unknown } | null;
  return typeof cuerpo?.message === 'string' && cuerpo.message.trim() ? cuerpo.message : null;
}

function errorGuardado(error: unknown, accion: 'crear' | 'editar'): Error {
  if (!(error instanceof HttpErrorResponse)) {
    return error instanceof Error ? error : new Error('No pudimos guardar el ingrediente.');
  }
  switch (error.status) {
    case 0:
      return new Error('No hay conexión con el servidor. Revisa tu internet e inténtalo de nuevo.');
    case 409:
      return new Error(
        JSON.stringify(error.error ?? '').includes('codigo_barras')
          ? 'Ya existe otro artículo con ese código de barras.'
          : 'Ya existe un ingrediente con ese nombre.',
      );
    case 401:
    case 403:
      return new Error(`Tu usuario no tiene permiso para ${accion} ingredientes.`);
    case 400:
      return new Error(mensajeServidor(error) ?? 'Revisa los datos del ingrediente.');
    default:
      return new Error('No pudimos guardar el ingrediente. Inténtalo de nuevo.');
  }
}

function errorEstado(error: unknown, nombre: string): Error {
  if (error instanceof HttpErrorResponse) {
    if (error.status === 0) return new Error('No hay conexión con el servidor.');
    if (error.status === 401 || error.status === 403) {
      return new Error(`Tu usuario no tiene permiso para cambiar el estado de ${nombre}.`);
    }
  }
  if (error instanceof Error && !(error instanceof HttpErrorResponse)) return error;
  return new Error(`No pudimos cambiar el estado de ${nombre}. Inténtalo de nuevo.`);
}
