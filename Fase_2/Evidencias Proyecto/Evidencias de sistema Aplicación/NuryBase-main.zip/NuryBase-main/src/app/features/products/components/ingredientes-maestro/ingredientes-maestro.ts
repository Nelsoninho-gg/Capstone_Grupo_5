import { Component, HostListener, OnInit, computed, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { finalize, forkJoin } from 'rxjs';
import { MovimientosArticulo } from '../../../inventario/components/movimientos-articulo/movimientos-articulo';
import { ArticuloMovimientos } from '../../../inventario/models/movimientos.model';
import {
  ArticuloCatalogo,
  UnidadCatalogo,
  claveArticulo,
  claveCodigo,
  codigoRepetido,
  filtrarCatalogo,
  limpiarNombre,
  nombreRepetido,
} from '../../models/catalogo.model';
import { CatalogoService } from '../../services/catalogo.service';

type EstadoCarga = 'cargando' | 'listo' | 'error';

/**
 * Pestaña Ingredientes del Maestro de Productos: materias primas con nombre, unidad y estado,
 * búsqueda y formulario para crearlas y editarlas (antes Catálogo de Inventario, H3.3).
 * La unidad queda fija desde la creación. Admin y bodeguero.
 */
@Component({
  selector: 'app-ingredientes-maestro',
  imports: [ReactiveFormsModule, MovimientosArticulo],
  templateUrl: './ingredientes-maestro.html',
  styleUrls: ['../../../inventario/styles/inventario-base.css', './ingredientes-maestro.css'],
})
export class IngredientesMaestro implements OnInit {
  private readonly catalogoService = inject(CatalogoService);
  private readonly formBuilder = inject(FormBuilder);

  protected readonly estado = signal<EstadoCarga>('cargando');
  protected readonly articulos = signal<ArticuloCatalogo[]>([]);
  protected readonly unidades = signal<UnidadCatalogo[]>([]);
  protected readonly busqueda = signal('');
  protected readonly mensajeExito = signal<string | null>(null);
  protected readonly errorEstado = signal<string | null>(null);
  /** Historial de movimientos abierto (H3.2 T01), de todas las sucursales. */
  protected readonly movimientosDe = signal<ArticuloMovimientos | null>(null);
  protected readonly cambiandoEstado = signal<ReadonlySet<string>>(new Set());

  protected readonly filtrados = computed(() =>
    filtrarCatalogo(this.articulos(), { texto: this.busqueda(), tipo: 'materia_prima' }),
  );
  protected readonly hayFiltros = computed(() => this.busqueda().trim() !== '');
  // Formulario de materia prima ------------------------------------------------------
  protected readonly modalAbierto = signal(false);
  protected readonly enEdicion = signal<ArticuloCatalogo | null>(null);
  protected readonly guardando = signal(false);
  protected readonly errorFormulario = signal<string | null>(null);
  protected readonly formulario = this.formBuilder.nonNullable.group({
    nombre: ['', [Validators.required, Validators.maxLength(120)]],
    unidadId: this.formBuilder.control<number | null>(null, Validators.required),
    codigoBarras: ['', Validators.maxLength(64)],
  });
  /**
   * Criterio de H3.3: la unidad queda asociada permanentemente a la materia prima (base de
   * recetas y descuentos de stock), así que al editar nunca se cambia.
   */
  protected readonly unidadBloqueada = computed(() => this.enEdicion() !== null);

  ngOnInit(): void {
    this.cargar();
  }

  protected cargar(): void {
    this.estado.set('cargando');
    forkJoin({
      articulos: this.catalogoService.listarMateriasPrimas(),
      unidades: this.catalogoService.listarUnidades(),
    }).subscribe({
      next: ({ articulos, unidades }) => {
        this.articulos.set(articulos);
        this.unidades.set(unidades);
        this.estado.set('listo');
      },
      error: () => this.estado.set('error'),
    });
  }

  protected clave(articulo: ArticuloCatalogo): string {
    return claveArticulo(articulo);
  }

  protected actualizarBusqueda(evento: Event): void {
    this.busqueda.set((evento.target as HTMLInputElement).value);
  }

  protected limpiarFiltros(): void {
    this.busqueda.set('');
  }

  protected abrirNueva(): void {
    this.enEdicion.set(null);
    this.formulario.reset({ nombre: '', unidadId: null, codigoBarras: '' });
    this.formulario.controls.unidadId.enable();
    this.abrirModal();
  }

  protected abrirEdicion(articulo: ArticuloCatalogo): void {
    this.enEdicion.set(articulo);
    this.formulario.reset({
      nombre: articulo.nombre,
      unidadId: articulo.unidadId,
      codigoBarras: articulo.codigoBarras ?? '',
    });
    this.formulario.controls.unidadId.disable();
    this.abrirModal();
  }

  @HostListener('document:keydown.escape')
  protected cerrarModal(): void {
    if (this.guardando()) return;
    this.modalAbierto.set(false);
  }

  protected guardar(): void {
    if (this.guardando()) return;
    this.errorFormulario.set(null);
    this.formulario.markAllAsTouched();
    const valores = this.formulario.getRawValue();
    const nombre = limpiarNombre(valores.nombre);
    if (!nombre) this.formulario.controls.nombre.setErrors({ required: true });
    if (this.formulario.invalid || valores.unidadId === null) return;

    const edicion = this.enEdicion();
    const codigoBarras = claveCodigo(valores.codigoBarras);
    let repetido = false;
    if (nombreRepetido(this.articulos(), nombre, edicion?.id ?? null)) {
      this.formulario.controls.nombre.setErrors({ repetido: true });
      repetido = true;
    }
    if (codigoRepetido(this.articulos(), codigoBarras, edicion?.id ?? null)) {
      this.formulario.controls.codigoBarras.setErrors({ repetido: true });
      repetido = true;
    }
    if (repetido) return;
    const datos = {
      nombre,
      unidadId: valores.unidadId,
      // Sin espacios y en mayúsculas, como lo compara la base (H3.3 T05).
      codigoBarras: codigoBarras === null ? null : valores.codigoBarras.replace(/\s/g, ''),
    };
    this.guardando.set(true);
    const peticion = edicion
      ? this.catalogoService.editarMateriaPrima(edicion.id, datos)
      : this.catalogoService.crearMateriaPrima(datos);
    peticion.pipe(finalize(() => this.guardando.set(false))).subscribe({
      next: (guardado) => {
        this.articulos.update((lista) =>
          edicion
            ? lista.map((a) => (claveArticulo(a) === claveArticulo(guardado) ? guardado : a))
            : [...lista, guardado],
        );
        this.mensajeExito.set(
          `${edicion ? 'Se actualizó' : 'Se creó'} el ingrediente ${guardado.nombre}.`,
        );
        this.modalAbierto.set(false);
      },
      error: (error: unknown) =>
        this.errorFormulario.set(
          error instanceof Error ? error.message : 'No pudimos guardar el ingrediente.',
        ),
    });
  }

  protected alternarEstado(articulo: ArticuloCatalogo): void {
    const clave = claveArticulo(articulo);
    if (this.cambiandoEstado().has(clave)) return;
    this.errorEstado.set(null);
    this.mensajeExito.set(null);
    this.marcarCambiando(clave, true);
    this.catalogoService
      .cambiarEstado(articulo, !articulo.activo)
      .pipe(finalize(() => this.marcarCambiando(clave, false)))
      .subscribe({
        next: (cambiado) => {
          this.articulos.update((lista) =>
            lista.map((a) => (claveArticulo(a) === clave ? cambiado : a)),
          );
          this.mensajeExito.set(
            `${cambiado.nombre} quedó ${cambiado.activo ? 'activo' : 'inactivo'}.` +
              (cambiado.activo ? '' : ' No se borra: conserva su historial de stock.'),
          );
        },
        error: (error: unknown) =>
          this.errorEstado.set(
            error instanceof Error
              ? error.message
              : `No pudimos cambiar el estado de ${articulo.nombre}.`,
          ),
      });
  }

  protected abrirMovimientos(articulo: ArticuloCatalogo): void {
    this.movimientosDe.set({
      tipo: articulo.tipo,
      id: articulo.id,
      nombre: articulo.nombre,
      unidad: articulo.unidad,
      sucursalId: null,
      sucursal: null,
    });
  }

  protected estaCambiando(articulo: ArticuloCatalogo): boolean {
    return this.cambiandoEstado().has(claveArticulo(articulo));
  }

  private abrirModal(): void {
    this.errorFormulario.set(null);
    this.errorEstado.set(null);
    this.mensajeExito.set(null);
    this.modalAbierto.set(true);
  }

  private marcarCambiando(clave: string, activo: boolean): void {
    this.cambiandoEstado.update((claves) => {
      const nuevas = new Set(claves);
      if (activo) nuevas.add(clave);
      else nuevas.delete(clave);
      return nuevas;
    });
  }
}
