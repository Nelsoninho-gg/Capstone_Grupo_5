import { HttpErrorResponse } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { of, throwError } from 'rxjs';
import { UsuariosApiService } from '../../../../core/api/usuarios-api.service';
import { VentaApi, VentasApiService } from '../../../../core/api/ventas-api.service';
import { AuthService } from '../../../auth/services/auth.service';
import { PosService } from '../../../pos/services/pos.service';
import { AnulacionVenta } from './anulacion-venta';
import { UserRole } from '../../../auth/models/auth.model';

const SALE: VentaApi = {
  id: 7,
  sucursal_id: 1,
  cajero_id: 3,
  fecha_venta: '2026-10-01T17:28:24',
  medio_pago: 'efectivo',
  total: 9600,
  anulada: false,
  anulada_en: null,
  anulada_por: null,
  creado_en: '2026-10-01T17:28:24',
  detalle_venta: [
    { cantidad: 1, precio_unitario: 3000, subtotal: 3000, productos: { nombre: 'CHAPARRITA' } },
    { cantidad: 2, precio_unitario: 3300, subtotal: 6600, productos: { nombre: 'EMPANADA PINO' } },
  ],
};

describe('AnulacionVenta', () => {
  const listar = vi.fn();
  const anular = vi.fn();
  const sincronizarAnulacion = vi.fn();
  const listarUsuarios = vi.fn();
  let component: AnulacionVenta;

  function render(sucursalId: number | null = 1, rol: UserRole = 'admin', id = 4): HTMLElement {
    TestBed.configureTestingModule({
      providers: [
        { provide: VentasApiService, useValue: { listar, anular } },
        { provide: UsuariosApiService, useValue: { listar: listarUsuarios } },
        { provide: PosService, useValue: { sincronizarAnulacion } },
        {
          provide: AuthService,
          useValue: {
            currentUser: () => ({
              id,
              rol,
              nombre: 'Cajero',
              sucursalId,
              sucursalNombre: 'Nury Providencia',
            }),
          },
        },
      ],
    });
    const fixture = TestBed.createComponent(AnulacionVenta);
    component = fixture.componentInstance;
    fixture.detectChanges();
    return fixture.nativeElement as HTMLElement;
  }

  beforeEach(() => {
    listar.mockReset().mockReturnValue(of([SALE]));
    anular.mockReset().mockReturnValue(of(undefined));
    sincronizarAnulacion.mockReset();
    listarUsuarios.mockReset().mockReturnValue(of([{ id: 3, nombre: 'Cajero' }]));
  });

  it("loads the admin's branch history without needing an open shift", () => {
    const el = render();

    expect(listar).toHaveBeenCalledTimes(1);
    const filtro = listar.mock.calls[0][0];
    expect(filtro.sucursalIds).toEqual([1]);
    expect(filtro.incluirDetalle).toBe(true);
    expect(filtro.hasta.getTime()).toBeGreaterThan(filtro.desde.getTime());
    expect(el.textContent).toContain('TK-7');
    expect(el.textContent).toContain('Cajero');
    expect(el.textContent).toContain('1 × CHAPARRITA, 2 × EMPANADA PINO');
    expect(el.textContent).not.toContain('No hay un turno activo');
  });

  it('does not query anything when the user has no branch', () => {
    const el = render(null);

    expect(listar).not.toHaveBeenCalled();
    expect(el.textContent).toContain('no tiene una sucursal asignada');
  });

  it('shows only the cashier sales and totals without requesting other user profiles', () => {
    listar.mockReturnValue(
      of([SALE, { ...SALE, id: 8, cajero_id: 5 }, { ...SALE, id: 9, cajero_id: null }]),
    );
    const el = render(1, 'cajero', 3);
    expect(listar.mock.calls[0][0].cajeroId).toBe(3);
    expect(listarUsuarios).not.toHaveBeenCalled();
    expect(el.querySelector('[aria-label="Filtrar por cajero"]')).toBeNull();
    expect(el.textContent).toContain('TK-7');
    expect(el.textContent).not.toContain('TK-8');
    expect(el.textContent).not.toContain('TK-9');
    expect(component['totalVigente']()).toBe(9600);

    component['abrirDetalle'](component['ventas']()[0]);
    component['motivo'].set('Error al cobrar');
    component['confirmarAnulacion']();
    expect(anular).toHaveBeenCalledWith(7, 'Error al cobrar');
    expect(sincronizarAnulacion).toHaveBeenCalledWith(7, 'Error al cobrar');
  });

  it.each([5, null])(
    'blocks a cashier from annulling a sale owned by %s even with a forced selection',
    (cajeroId) => {
      render(1, 'cajero', 3);
      const ajena = { ...component['ventas']()[0], id: 8, cajeroId };
      component['abrirDetalle'](ajena);
      expect(component['ventaSeleccionada']()).toBeNull();
      component['ventaSeleccionada'].set(ajena);
      component['motivo'].set('Error al cobrar');
      component['confirmarAnulacion']();
      expect(anular).not.toHaveBeenCalled();
    },
  );

  it('does not attempt to annul an already annulled sale', () => {
    render();
    component['ventaSeleccionada'].set({ ...component['ventas']()[0], anulada: true });
    component['motivo'].set('Error al cobrar');
    component['confirmarAnulacion']();
    expect(anular).not.toHaveBeenCalled();
  });

  it('shows a retryable error when the history cannot be loaded', () => {
    listar.mockReturnValue(throwError(() => new Error('sin red')));
    const el = render();

    expect(el.textContent).toContain('No se pudieron cargar las ventas');
  });

  it('requires a reason of at least five characters before annulling', () => {
    const el = render();
    (el.querySelector('.danger-button') as HTMLButtonElement).click();
    TestBed.tick();

    const confirm = el.querySelector('.danger-button.solid') as HTMLButtonElement;
    expect(confirm.disabled).toBe(true);

    const textarea = el.querySelector('textarea') as HTMLTextAreaElement;
    textarea.value = 'xx';
    textarea.dispatchEvent(new Event('input'));
    TestBed.tick();
    expect(confirm.disabled).toBe(true);
    confirm.click();
    expect(anular).not.toHaveBeenCalled();
  });

  it('annuls with the reason, marks the row and syncs the local shift', () => {
    const el = render();
    (el.querySelector('.danger-button') as HTMLButtonElement).click();
    TestBed.tick();

    const textarea = el.querySelector('textarea') as HTMLTextAreaElement;
    textarea.value = 'Error al cobrar';
    textarea.dispatchEvent(new Event('input'));
    TestBed.tick();
    (el.querySelector('.danger-button.solid') as HTMLButtonElement).click();
    TestBed.tick();

    expect(anular).toHaveBeenCalledWith(7, 'Error al cobrar');
    expect(sincronizarAnulacion).toHaveBeenCalledWith(7, 'Error al cobrar');
    expect(el.querySelector('.badge-anulada')).not.toBeNull();
    expect(el.querySelector('.danger-button')).toBeNull();
    expect(el.textContent).toContain('Venta TK-7 anulada correctamente.');
  });

  it('filters the list and the totals by cashier, and combines with the text search', () => {
    const otra: VentaApi = {
      ...SALE,
      id: 12,
      cajero_id: 5,
      total: 6300,
      detalle_venta: [
        { cantidad: 1, precio_unitario: 6300, subtotal: 6300, productos: { nombre: 'JUGO' } },
      ],
    };
    const sinCajero: VentaApi = { ...SALE, id: 13, cajero_id: null, total: 1000 };
    listar.mockReturnValue(of([otra, SALE, sinCajero]));
    const el = render();
    const select = el.querySelector('select') as HTMLSelectElement;
    const folios = () =>
      [...el.querySelectorAll('tbody tr')].map((fila) => fila.children[0].textContent?.trim());
    const tarjetas = () =>
      [...el.querySelectorAll('.summary-card strong')].map((e) => e.textContent?.trim());

    expect([...select.options].map((o) => o.textContent?.trim())).toEqual([
      'Todos los cajeros',
      'Cajero',
      'Cajero #5',
      'Sin cajero',
    ]);
    expect(folios()).toEqual(['TK-12', 'TK-7', 'TK-13']);

    select.value = '3';
    select.dispatchEvent(new Event('change'));
    TestBed.tick();
    expect(folios()).toEqual(['TK-7']);
    expect(tarjetas()[0]).toBe('1');

    select.value = 'sin';
    select.dispatchEvent(new Event('change'));
    TestBed.tick();
    expect(folios()).toEqual(['TK-13']);

    select.value = '';
    select.dispatchEvent(new Event('change'));
    const search = el.querySelector('input[type=search]') as HTMLInputElement;
    search.value = 'jugo';
    search.dispatchEvent(new Event('input'));
    TestBed.tick();
    expect(folios()).toEqual(['TK-12']);
  });

  it('identifies employee sales, filters them by type and keeps their discount when annulling (H2.12)', () => {
    const empleado: VentaApi = {
      ...SALE,
      id: 20,
      total: 6720,
      tipo_venta: 'empleado',
      venta_especial: true,
      empleado_id: 3,
      descuento_porcentaje: 30,
      descuento_monto: 2880,
      codigo_venta: 'EMP-20',
    };
    const normal: VentaApi = { ...SALE, tipo_venta: 'normal', venta_especial: false, codigo_venta: 'TK-7' };
    listar.mockReturnValue(of([empleado, normal]));
    const el = render();
    const tipo = el.querySelector('select[aria-label="Filtrar por tipo de venta"]') as HTMLSelectElement;
    const folios = () =>
      [...el.querySelectorAll('tbody tr')].map((fila) =>
        fila.children[0].textContent?.replace(/\s+/g, ' ').trim(),
      );

    expect(folios()).toEqual(['EMP-20 Empleado', 'TK-7']);

    tipo.value = 'empleado';
    tipo.dispatchEvent(new Event('change'));
    TestBed.tick();
    expect(folios()).toEqual(['EMP-20 Empleado']);
    expect(el.querySelector('.summary-card strong')?.textContent?.trim()).toBe('1');

    tipo.value = 'normal';
    tipo.dispatchEvent(new Event('change'));
    TestBed.tick();
    expect(folios()).toEqual(['TK-7']);

    tipo.value = 'empleado';
    tipo.dispatchEvent(new Event('change'));
    TestBed.tick();
    (el.querySelector('.danger-button') as HTMLButtonElement).click();
    TestBed.tick();
    const modal = (el.querySelector('.modal') as HTMLElement).textContent?.replace(/\s+/g, '');
    expect(modal).toContain('¿AnularlaventaEMP-20?');
    expect(modal).toContain('VentaaempleadoCajero');
    expect(modal).toContain('Subtotal$9.600');
    expect(modal).toContain('Descuentoempleado(30%)−$2.880');
    expect(modal).toContain('Total$6.720');

    const textarea = el.querySelector('textarea') as HTMLTextAreaElement;
    textarea.value = 'Error al cobrar';
    textarea.dispatchEvent(new Event('input'));
    TestBed.tick();
    (el.querySelector('.danger-button.solid') as HTMLButtonElement).click();
    TestBed.tick();

    // Anular solo cambia el estado: la venta sigue siendo a empleado con su descuento.
    expect(anular).toHaveBeenCalledWith(20, 'Error al cobrar');
    expect(folios()).toEqual(['EMP-20 Empleado']);
    expect(el.querySelector('.badge-anulada')).not.toBeNull();
  });

  it('filters by status with buttons and combines with the cashier filter', () => {
    const anulada: VentaApi = {
      ...SALE,
      id: 8,
      anulada: true,
      anulada_motivo: 'prueba',
      anulada_en: '2026-10-01T18:13:07',
      anulada_por: 1,
    };
    const deOtro: VentaApi = { ...SALE, id: 12, cajero_id: 5, anulada: true };
    listar.mockReturnValue(of([deOtro, SALE, anulada]));
    const el = render();
    const folios = () =>
      [...el.querySelectorAll('tbody tr')].map((fila) => fila.children[0].textContent?.trim());
    const boton = (texto: string) =>
      [...el.querySelectorAll('.estado-filtro button')].find(
        (b) => b.textContent?.trim() === texto,
      ) as HTMLButtonElement;

    expect(folios()).toEqual(['TK-12', 'TK-7', 'TK-8']);
    expect(boton('Todas').getAttribute('aria-pressed')).toBe('true');

    boton('Anuladas').click();
    TestBed.tick();
    expect(folios()).toEqual(['TK-12', 'TK-8']);
    expect(boton('Anuladas').getAttribute('aria-pressed')).toBe('true');

    boton('Vigentes').click();
    TestBed.tick();
    expect(folios()).toEqual(['TK-7']);

    const select = el.querySelector('select') as HTMLSelectElement;
    boton('Anuladas').click();
    select.value = '5';
    select.dispatchEvent(new Event('change'));
    TestBed.tick();
    expect(folios()).toEqual(['TK-12']);

    boton('Vigentes').click();
    TestBed.tick();
    expect(el.textContent).toContain('No hay ventas que coincidan con los filtros.');
  });

  it('shows the server reason when it rejects the annulment', () => {
    anular.mockReturnValue(
      throwError(
        () =>
          new HttpErrorResponse({
            status: 400,
            error: { message: 'column ventas.anulada_motivo does not exist' },
          }),
      ),
    );
    const el = render();
    (el.querySelector('.danger-button') as HTMLButtonElement).click();
    TestBed.tick();
    const textarea = el.querySelector('textarea') as HTMLTextAreaElement;
    textarea.value = 'prueba';
    textarea.dispatchEvent(new Event('input'));
    TestBed.tick();
    (el.querySelector('.danger-button.solid') as HTMLButtonElement).click();
    TestBed.tick();

    expect(el.textContent).toContain(
      'El servidor rechazó la anulación (error 400): column ventas.anulada_motivo does not exist',
    );
    expect(el.querySelector('.badge-anulada')).toBeNull();
  });

  it('keeps the sale and shows the reason for the failure when annulling fails', () => {
    anular.mockReturnValue(throwError(() => new Error('La venta no existe o ya estaba anulada.')));
    const el = render();
    (el.querySelector('.danger-button') as HTMLButtonElement).click();
    TestBed.tick();

    const textarea = el.querySelector('textarea') as HTMLTextAreaElement;
    textarea.value = 'Error al cobrar';
    textarea.dispatchEvent(new Event('input'));
    TestBed.tick();
    (el.querySelector('.danger-button.solid') as HTMLButtonElement).click();
    TestBed.tick();

    expect(el.textContent).toContain('La venta no existe o ya estaba anulada.');
    expect(sincronizarAnulacion).not.toHaveBeenCalled();
    expect(el.querySelector('.badge-anulada')).toBeNull();
  });
});
