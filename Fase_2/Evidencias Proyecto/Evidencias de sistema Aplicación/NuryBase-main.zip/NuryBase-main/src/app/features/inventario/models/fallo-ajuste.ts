import { HttpErrorResponse } from '@angular/common/http';

export type TipoFalloAjuste =
  | 'conexion'
  | 'sesion'
  | 'permisos'
  | 'stock-insuficiente'
  | 'articulo-inexistente'
  | 'datos-invalidos'
  | 'no-disponible'
  | 'servidor';

/**
 * Qué puede hacer el usuario después del fallo:
 * - reintentar: el mismo ajuste, con la misma clave de idempotencia (H3.6 T06).
 * - corregir: cambiar los datos del formulario, porque la base los rechazó.
 * - ninguna: no depende del formulario (sesión, permisos o servidor sin la función).
 */
export type AccionFalloAjuste = 'reintentar' | 'corregir' | 'ninguna';

export interface FalloAjuste {
  tipo: TipoFalloAjuste;
  mensaje: string;
  accion: AccionFalloAjuste;
  /** El stock en pantalla ya no es confiable y conviene consultarlo de nuevo. */
  actualizarStock: boolean;
}

/** Cuerpo de error de PostgREST: `code` es el SQLSTATE de PostgreSQL o un código PGRST. */
interface ErrorPostgrest {
  code?: string;
  message?: string;
}

const SIN_CAMBIOS = 'El stock no se modificó.';
const REINTENTO_SEGURO = 'Puedes reintentar: el ajuste no se aplicará dos veces.';

/**
 * Traduce el error de registrar un ajuste a un mensaje para el usuario.
 * Sigue los códigos de `fn_ajustar_stock` (database/migrations/0008_ajuste_stock_idempotente.sql):
 * 22023 datos inválidos, 23503 artículo o sucursal inexistente y 23514 stock insuficiente.
 * Para esos rechazos muestra el texto de la base, que ya explica el caso en español.
 */
export function interpretarFalloAjuste(error: unknown): FalloAjuste {
  if (!(error instanceof HttpErrorResponse)) return falloServidor();

  const { code = '', message = '' } = (error.error ?? {}) as ErrorPostgrest;

  if (error.status === 0) {
    return {
      tipo: 'conexion',
      mensaje:
        'No pudimos comunicarnos con el servidor y no sabemos si el ajuste alcanzó a ' +
        'aplicarse. Revisa la conexión y reintenta sin cambiar los datos: si ya se había ' +
        'aplicado, no se aplicará dos veces.',
      accion: 'reintentar',
      actualizarStock: false,
    };
  }
  // PostgREST responde 42501 (sin privilegio) con 401 si no hay sesión y 403 si la hay.
  if (error.status === 401) {
    return {
      tipo: 'sesion',
      mensaje: `Tu sesión expiró y el ajuste no se registró. ${SIN_CAMBIOS} Vuelve a iniciar sesión para registrarlo.`,
      accion: 'ninguna',
      actualizarStock: false,
    };
  }
  if (error.status === 403 || code === '42501') {
    return {
      tipo: 'permisos',
      mensaje: `Tu usuario no tiene permiso para registrar ajustes de stock. ${SIN_CAMBIOS}`,
      accion: 'ninguna',
      actualizarStock: false,
    };
  }
  if (code === 'PGRST202') {
    return {
      tipo: 'no-disponible',
      mensaje: `El registro de ajustes aún no está habilitado en el servidor. ${SIN_CAMBIOS} Avisa al administrador.`,
      accion: 'ninguna',
      actualizarStock: false,
    };
  }
  if (code === '23514') {
    return {
      tipo: 'stock-insuficiente',
      mensaje: `${oracion(message, 'El ajuste dejaría el stock en negativo.')} ${SIN_CAMBIOS} Revisa la cantidad con el stock actualizado.`,
      accion: 'corregir',
      actualizarStock: true,
    };
  }
  if (code === '23503') {
    return {
      tipo: 'articulo-inexistente',
      mensaje: `${oracion(message, 'El artículo o la sucursal ya no está disponible.')} ${SIN_CAMBIOS}`,
      accion: 'corregir',
      actualizarStock: true,
    };
  }
  if (code === '22023') {
    return {
      tipo: 'datos-invalidos',
      mensaje: `${oracion(message, 'Revisa los datos del ajuste.')} ${SIN_CAMBIOS}`,
      accion: 'corregir',
      // Un producto que ahora tiene receta ya no debería aparecer como de reventa.
      actualizarStock: message.toLocaleLowerCase('es').includes('receta'),
    };
  }
  return falloServidor();
}

/** El texto de la base como oración (con punto final), o el de respaldo si no vino. */
function oracion(texto: string, respaldo: string): string {
  const limpio = texto.trim();
  if (!limpio) return respaldo;
  return /[.!?]$/.test(limpio) ? limpio : `${limpio}.`;
}

function falloServidor(): FalloAjuste {
  return {
    tipo: 'servidor',
    mensaje: `No pudimos registrar el ajuste. ${REINTENTO_SEGURO}`,
    accion: 'reintentar',
    actualizarStock: false,
  };
}
