import {
  ArticuloCatalogo,
  claveCodigo,
  claveNombre,
  codigoRepetido,
  contarPorTipo,
  filtrarCatalogo,
  limpiarNombre,
  nombreRepetido,
} from './catalogo.model';

function articulo(cambios: Partial<ArticuloCatalogo>): ArticuloCatalogo {
  return {
    tipo: 'materia_prima',
    id: 1,
    nombre: 'Harina',
    unidad: 'kg',
    unidadId: 1,
    codigoBarras: null,
    activo: true,
    ...cambios,
  };
}

const ARTICULOS = [
  articulo({ id: 1, nombre: 'Harina' }),
  articulo({ id: 2, nombre: 'Azúcar', activo: false }),
  articulo({
    tipo: 'producto',
    id: 1,
    nombre: 'CHAPARRITA',
    unidad: 'un',
    codigoBarras: '7801234',
  }),
];

describe('filtrarCatalogo', () => {
  it('busca sin tildes ni mayúsculas, también por código de barras, y ordena por nombre', () => {
    const nombres = (texto: string) =>
      filtrarCatalogo(ARTICULOS, { texto, tipo: 'todos' }).map((a) => a.nombre);

    expect(nombres('')).toEqual(['Azúcar', 'CHAPARRITA', 'Harina']);
    expect(nombres('azucar')).toEqual(['Azúcar']);
    expect(nombres('chap')).toEqual(['CHAPARRITA']);
    expect(nombres('7801')).toEqual(['CHAPARRITA']);
  });

  it('filtra por tipo y combina con la búsqueda', () => {
    expect(filtrarCatalogo(ARTICULOS, { texto: '', tipo: 'producto' })).toHaveLength(1);
    expect(filtrarCatalogo(ARTICULOS, { texto: 'har', tipo: 'producto' })).toEqual([]);
    expect(filtrarCatalogo(ARTICULOS, { texto: 'har', tipo: 'materia_prima' })).toHaveLength(1);
  });
});

describe('contarPorTipo y nombreRepetido', () => {
  it('cuenta los artículos de cada tipo', () => {
    expect(contarPorTipo(ARTICULOS)).toEqual({ todos: 3, materia_prima: 2, producto: 1 });
  });

  it('detecta un nombre repetido entre materias primas, sin contar la que se edita', () => {
    expect(nombreRepetido(ARTICULOS, ' harina ', null)).toBe(true);
    expect(nombreRepetido(ARTICULOS, 'AZÚCAR', null)).toBe(true);
    expect(nombreRepetido(ARTICULOS, 'Harina', 1)).toBe(false);
    // Un producto con el mismo nombre no cuenta: son tablas distintas.
    expect(nombreRepetido(ARTICULOS, 'Chaparrita', null)).toBe(false);
  });
});

describe('duplicados ignorando mayúsculas y espacios (H3.3 T05)', () => {
  it('limpia el nombre como la base: sin espacios en los extremos ni repetidos', () => {
    expect(limpiarNombre('  Harina   000 ')).toBe('Harina 000');
  });

  it('compara nombres sin mayúsculas ni espacios, pero con tildes', () => {
    expect(claveNombre('  HARINA   000')).toBe(claveNombre('harina 000'));
    expect(claveNombre('Piña')).not.toBe(claveNombre('Pina'));
    expect(nombreRepetido(ARTICULOS, '  HARINA ', null)).toBe(true);
  });

  it('compara códigos de barras sin mayúsculas ni espacios', () => {
    expect(claveCodigo(' abc 123 ')).toBe('ABC123');
    expect(claveCodigo('   ')).toBeNull();
    const conCodigo = ARTICULOS.map((a, i) => ({
      ...a,
      codigoBarras: i === 0 ? 'ab12' : a.codigoBarras,
    }));
    expect(codigoRepetido(conCodigo, 'AB 12', null)).toBe(true);
    expect(codigoRepetido(conCodigo, 'AB 12', conCodigo[0].id)).toBe(false);
    expect(codigoRepetido(conCodigo, null, null)).toBe(false);
  });
});
