import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Subject, of, throwError } from 'rxjs';
import { ArticuloCatalogo } from '../../models/catalogo.model';
import { CatalogoService } from '../../services/catalogo.service';
import { MovimientosService } from '../../../inventario/services/movimientos.service';
import { IngredientesMaestro } from './ingredientes-maestro';

describe('IngredientesMaestro (pestaña Ingredientes del Maestro, H3.3)', () => {
  let fixture: ComponentFixture<IngredientesMaestro>;

  const harina: ArticuloCatalogo = {
    tipo: 'materia_prima',
    id: 3,
    nombre: 'Harina',
    unidad: 'kg',
    unidadId: 1,
    codigoBarras: null,
    activo: true,
  };
  const palta: ArticuloCatalogo = { ...harina, id: 5, nombre: 'Palta' };
  const unidades = [
    { id: 1, nombre: 'Kilogramo', abreviatura: 'kg' },
    { id: 2, nombre: 'Gramo', abreviatura: 'g' },
  ];

  const servicio = {
    listarMateriasPrimas: vi.fn(),
    listarUnidades: vi.fn(),
    crearMateriaPrima: vi.fn(),
    editarMateriaPrima: vi.fn(),
    cambiarEstado: vi.fn(),
  };

  async function render(): Promise<void> {
    await TestBed.configureTestingModule({
      imports: [IngredientesMaestro],
      providers: [
        { provide: CatalogoService, useValue: servicio },
        { provide: MovimientosService, useValue: { listar: () => of([]) } },
      ],
    }).compileComponents();
    fixture = TestBed.createComponent(IngredientesMaestro);
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
  }
  function el(): HTMLElement {
    return fixture.nativeElement as HTMLElement;
  }
  function filas(): string[][] {
    return Array.from(el().querySelectorAll('tbody tr:not(.empty-row)')).map((tr) =>
      Array.from(tr.querySelectorAll('td')).map((td) =>
        (td.textContent ?? '').replace(/\s+/g, ' ').trim(),
      ),
    );
  }
  function boton(texto: string): HTMLButtonElement {
    return Array.from(el().querySelectorAll<HTMLButtonElement>('button')).find(
      (b) => b.textContent?.trim() === texto,
    )!;
  }
  function escribir(selector: string, valor: string, evento = 'input'): void {
    const control = el().querySelector<HTMLInputElement | HTMLSelectElement>(selector)!;
    control.value = valor;
    control.dispatchEvent(new Event(evento));
    fixture.detectChanges();
  }

  beforeEach(() => {
    for (const fn of Object.values(servicio)) fn.mockReset();
    servicio.listarMateriasPrimas.mockReturnValue(of([palta, harina]));
    servicio.listarUnidades.mockReturnValue(of(unidades));
  });

  it('lists name, unit and state, sorted by name', async () => {
    await render();

    expect(filas().map((f) => f.slice(0, 3))).toEqual([
      ['Harina', 'kg', 'Activo'],
      ['Palta', 'kg', 'Activo'],
    ]);
    expect(el().querySelector('.record-count')?.textContent?.trim()).toBe('2 de 2 ingredientes');
    expect(el().querySelector('select[aria-label="Tipo de artículo"]')).toBeNull();
  });

  it('searches by name and clears the search', async () => {
    await render();

    escribir('input[type="search"]', 'har');
    expect(filas().map((f) => f[0])).toEqual(['Harina']);

    escribir('input[type="search"]', 'xyz');
    expect(el().querySelector('.empty-row')?.textContent).toContain(
      'No hay ingredientes que coincidan.',
    );
    boton('Limpiar filtros').click();
    fixture.detectChanges();
    expect(filas()).toHaveLength(2);
  });

  it('offers edit, activate/deactivate and movements on every ingredient', async () => {
    await render();
    const acciones = Array.from(el().querySelectorAll('.row-actions')).map((td) =>
      td.textContent!.replace(/\s+/g, ' ').trim(),
    );

    expect(acciones).toEqual(['Editar Desactivar Movimientos', 'Editar Desactivar Movimientos']);
  });

  it('creates a raw material and validates name and unit', async () => {
    servicio.crearMateriaPrima.mockReturnValue(
      of({ ...palta, id: 9, nombre: 'Leche', unidadId: 2, unidad: 'g' }),
    );
    await render();
    boton('+ Nuevo ingrediente').click();
    fixture.detectChanges();

    boton('Crear ingrediente').click();
    fixture.detectChanges();
    expect(el().querySelector('[role="dialog"]')?.textContent).toContain('Ingresa el nombre.');
    expect(el().querySelector('[role="dialog"]')?.textContent).toContain('Elige la unidad');

    escribir('input[formcontrolname="nombre"]', 'palta');
    const selectUnidad = el().querySelector<HTMLSelectElement>(
      'select[formcontrolname="unidadId"]',
    )!;
    selectUnidad.selectedIndex = 2; // Gramo (la opción 0 es "Selecciona una unidad")
    selectUnidad.dispatchEvent(new Event('change'));
    fixture.detectChanges();
    boton('Crear ingrediente').click();
    fixture.detectChanges();
    expect(el().querySelector('[role="dialog"]')?.textContent).toContain(
      'Ya existe un ingrediente con ese nombre.',
    );
    expect(servicio.crearMateriaPrima).not.toHaveBeenCalled();

    escribir('input[formcontrolname="nombre"]', '  Leche  ');
    escribir('input[formcontrolname="codigoBarras"]', '');
    boton('Crear ingrediente').click();
    fixture.detectChanges();

    expect(servicio.crearMateriaPrima).toHaveBeenCalledWith({
      nombre: 'Leche',
      unidadId: 2,
      codigoBarras: null,
    });
    expect(el().querySelector('[role="dialog"]')).toBeNull();
    expect(filas().map((f) => f[0])).toContain('Leche');
    expect(el().querySelector('.success-feedback')?.textContent).toContain(
      'Se creó el ingrediente Leche.',
    );
  });

  it('rejects a repeated name or barcode ignoring case and spaces, and saves it clean (H3.3 T05)', async () => {
    servicio.listarMateriasPrimas.mockReturnValue(
      of([{ ...harina, codigoBarras: '7801234' }, palta]),
    );
    servicio.crearMateriaPrima.mockReturnValue(of({ ...palta, id: 9, nombre: 'Harina 000' }));
    await render();
    boton('+ Nuevo ingrediente').click();
    fixture.detectChanges();
    const selectUnidad = el().querySelector<HTMLSelectElement>(
      'select[formcontrolname="unidadId"]',
    )!;
    selectUnidad.selectedIndex = 1;
    selectUnidad.dispatchEvent(new Event('change'));

    escribir('input[formcontrolname="nombre"]', '  HARINA ');
    escribir('input[formcontrolname="codigoBarras"]', '780 1234');
    boton('Crear ingrediente').click();
    fixture.detectChanges();
    const dialogo = el().querySelector('[role="dialog"]')?.textContent ?? '';
    expect(dialogo).toContain('Ya existe un ingrediente con ese nombre.');
    expect(dialogo).toContain('Ya existe un ingrediente con ese código de barras.');
    expect(servicio.crearMateriaPrima).not.toHaveBeenCalled();

    escribir('input[formcontrolname="nombre"]', '  Harina    000 ');
    escribir('input[formcontrolname="codigoBarras"]', ' 999 1 ');
    boton('Crear ingrediente').click();
    fixture.detectChanges();
    expect(servicio.crearMateriaPrima).toHaveBeenCalledWith({
      nombre: 'Harina 000',
      unidadId: 1,
      codigoBarras: '9991',
    });
  });

  it('keeps the unit fixed once the raw material exists, even if it is not in use yet', async () => {
    await render();
    const editar = (nombre: string) => {
      const fila = Array.from(el().querySelectorAll('tbody tr')).find((tr) =>
        tr.textContent?.includes(nombre),
      )!;
      fila.querySelector<HTMLButtonElement>('.row-actions button')!.click();
      fixture.detectChanges();
    };
    const unidad = () =>
      el().querySelector<HTMLSelectElement>('select[formcontrolname="unidadId"]')!;

    editar('Palta'); // sin recetas ni stock
    expect(unidad().disabled).toBe(true);
    expect(el().querySelector('[role="dialog"]')?.textContent).toContain(
      'La unidad queda fija desde que se crea el ingrediente',
    );

    boton('Cancelar').click();
    fixture.detectChanges();
    boton('+ Nuevo ingrediente').click();
    fixture.detectChanges();
    expect(unidad().disabled).toBe(false);
  });

  it('deactivates without deleting and shows the result', async () => {
    servicio.cambiarEstado.mockReturnValue(of({ ...palta, activo: false }));
    await render();

    el().querySelector<HTMLButtonElement>('[aria-label="Desactivar Palta"]')!.click();
    fixture.detectChanges();

    expect(servicio.cambiarEstado).toHaveBeenCalledWith(palta, false);
    expect(filas().find((f) => f[0] === 'Palta')?.[2]).toBe('Inactivo');
    expect(el().querySelector('.success-feedback')?.textContent).toContain(
      'Palta quedó inactivo. No se borra',
    );
  });

  it('opens the movement history of an article for all branches (H3.2 T01)', async () => {
    await render();

    el().querySelector<HTMLButtonElement>('[aria-label="Movimientos de Palta"]')!.click();
    fixture.detectChanges();

    expect(el().querySelector('app-movimientos-articulo')).not.toBeNull();
    expect(el().querySelector('#movements-title')?.textContent).toContain('Palta');
  });

  it('keeps the row as it was and explains when changing the state fails', async () => {
    servicio.cambiarEstado.mockReturnValue(
      throwError(() => new Error('Tu usuario no tiene permiso para cambiar el estado de Palta.')),
    );
    await render();

    el().querySelector<HTMLButtonElement>('[aria-label="Desactivar Palta"]')!.click();
    fixture.detectChanges();

    expect(filas().find((f) => f[0] === 'Palta')?.[2]).toBe('Activo');
    expect(el().querySelector('.state-error')?.textContent).toContain('no tiene permiso');
    expect(el().querySelector<HTMLButtonElement>('[aria-label="Desactivar Palta"]')!.disabled).toBe(
      false,
    );
  });

  it('shows the loading state and an error with retry', async () => {
    const pendiente = new Subject<ArticuloCatalogo[]>();
    servicio.listarMateriasPrimas.mockReturnValue(pendiente);
    await render();
    expect(el().querySelectorAll('.skeleton-row')).toHaveLength(4);

    pendiente.error(new Error('500'));
    fixture.detectChanges();
    expect(el().querySelector('.error-row')?.textContent).toContain(
      'No pudimos cargar los ingredientes.',
    );

    servicio.listarMateriasPrimas.mockReturnValue(of([harina]));
    boton('Reintentar').click();
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(filas()).toHaveLength(1);
  });

  it('closes the form with Escape', async () => {
    await render();
    boton('+ Nuevo ingrediente').click();
    fixture.detectChanges();

    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape' }));
    fixture.detectChanges();
    expect(el().querySelector('[role="dialog"]')).toBeNull();
  });

  it('keeps a save error inside the form', async () => {
    servicio.editarMateriaPrima.mockReturnValue(throwError(() => new Error('Sin conexión')));
    await render();
    const fila = Array.from(el().querySelectorAll('tbody tr')).find((tr) =>
      tr.textContent?.includes('Palta'),
    )!;
    fila.querySelector<HTMLButtonElement>('.row-actions button')!.click();
    fixture.detectChanges();

    boton('Guardar cambios').click();
    fixture.detectChanges();
    expect(el().querySelector('.error-feedback')?.textContent).toContain('Sin conexión');
    expect(el().querySelector('[role="dialog"]')).not.toBeNull();
  });
});
