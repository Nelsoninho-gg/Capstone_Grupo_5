import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { of } from 'rxjs';
import { UsuariosApiService } from '../../../../core/api/usuarios-api.service';
import { SucursalesApiService } from '../../../../core/api/sucursales-api.service';
import { GestionNegocio } from './gestion-negocio';

/** Lo que las pruebas usan de la parte protegida del componente. */
interface FormularioUsuario {
  formulario: { patchValue(valor: object): void };
  errorFormulario(): string | null;
  crearUsuario(): void;
}

describe('GestionNegocio', () => {
  let component: GestionNegocio;
  let fixture: ComponentFixture<GestionNegocio>;
  const usuariosApi = {
    listar: vi.fn(() => of([])),
    crear: vi.fn((usuario: object) => of({ id: 9, ...usuario })),
  };

  beforeEach(async () => {
    usuariosApi.crear.mockClear();
    await TestBed.configureTestingModule({
      imports: [GestionNegocio],
      providers: [
        provideRouter([]),
        { provide: UsuariosApiService, useValue: usuariosApi },
        { provide: SucursalesApiService, useValue: { listar: () => of([]) } },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(GestionNegocio);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('branch required by role (H3.4 T08)', () => {
    function crearCon(rol: string, sucursal_id: number | null): FormularioUsuario {
      const formulario = component as unknown as FormularioUsuario;
      formulario.formulario.patchValue({
        nombre: 'Usuario de prueba',
        identificador_acceso: 'usuario.prueba',
        contrasena: 'clave-prueba',
        rol,
        sucursal_id,
      });
      formulario.crearUsuario();
      return formulario;
    }

    it.each(['cajero', 'bodeguero'])('does not create a %s without a branch', (rol) => {
      const formulario = crearCon(rol, null);

      expect(formulario.errorFormulario()).toBe(`Selecciona una sucursal para el usuario ${rol}.`);
      expect(usuariosApi.crear).not.toHaveBeenCalled();
    });

    it('creates a storekeeper with a branch', () => {
      crearCon('bodeguero', 2);

      expect(usuariosApi.crear).toHaveBeenCalledWith(
        expect.objectContaining({ rol: 'bodeguero', sucursal_id: 2 }),
      );
    });

    it('still lets an administrator have no branch', () => {
      crearCon('admin', null);

      expect(usuariosApi.crear).toHaveBeenCalledWith(
        expect.objectContaining({ rol: 'admin', sucursal_id: null }),
      );
    });
  });
});
