import { HttpErrorResponse } from '@angular/common/http';
import { interpretarFalloIngreso } from './fallo-ingreso';

function respuesta(status: number, code?: string, message?: string): HttpErrorResponse {
  return new HttpErrorResponse({
    status,
    error: code ? { code, message, details: null, hint: null } : null,
  });
}

describe('interpretarFalloIngreso', () => {
  it.each([
    ['sin conexión', respuesta(0), 'conexion', true],
    ['sesión vencida', respuesta(401, 'PGRST303', 'JWT expired'), 'sesion', false],
    ['sin permiso (HTTP)', respuesta(403), 'permisos', false],
    ['sucursal ajena', respuesta(403, '42501', 'Solo puedes ingresar facturas en tu propia sucursal'), 'permisos', false],
    ['ya ingresada', respuesta(409, '23505', 'Esta factura ya fue ingresada (folio 1 del emisor 2).'), 'ya-ingresada', false],
    ['datos inválidos', respuesta(400, '22023', 'Faltan asociar 1 línea(s).'), 'datos', false],
    ['función no publicada', respuesta(404, 'PGRST202', 'Could not find the function'), 'no-disponible', false],
    ['error del servidor', respuesta(500), 'servidor', true],
  ] as const)('%s', (_caso, error, tipo, reintentable) => {
    expect(interpretarFalloIngreso(error)).toEqual(expect.objectContaining({ tipo, reintentable }));
  });

  it('uses the server message for a branch the user cannot use', () => {
    const fallo = interpretarFalloIngreso(
      respuesta(403, '42501', 'Solo puedes ingresar facturas en tu propia sucursal'),
    );

    expect(fallo.mensaje).toBe(
      'Solo puedes ingresar facturas en tu propia sucursal No se guardó nada y el stock no cambió.',
    );
  });

  it('reports a permission error even when PostgREST answers 401', () => {
    expect(interpretarFalloIngreso(respuesta(401, '42501', 'no autorizado')).tipo).toBe('permisos');
  });

  it('says that the stock was not added twice for a duplicate invoice', () => {
    const fallo = interpretarFalloIngreso(
      respuesta(409, '23505', 'Esta factura ya fue ingresada (folio 56631070 del emisor 82623500-4).'),
    );

    expect(fallo.mensaje).toBe(
      'Esta factura ya fue ingresada (folio 56631070 del emisor 82623500-4). No se volvió a sumar stock.',
    );
  });

  it('shows the server explanation for invalid data', () => {
    const fallo = interpretarFalloIngreso(
      respuesta(400, '22023', 'Línea 2: el producto elegido tiene receta; su stock sale de sus ingredientes.'),
    );

    expect(fallo.mensaje).toBe(
      'Línea 2: el producto elegido tiene receta; su stock sale de sus ingredientes. ' +
        'No se guardó nada y el stock no cambió.',
    );
  });

  it('treats unexpected errors as a retryable server failure', () => {
    expect(interpretarFalloIngreso(new Error('timeout'))).toEqual({
      tipo: 'servidor',
      mensaje:
        'No pudimos ingresar la factura. No se guardó nada y el stock no cambió. ' +
        'Puedes reintentar: no se ingresará dos veces.',
      reintentable: true,
    });
  });
});
