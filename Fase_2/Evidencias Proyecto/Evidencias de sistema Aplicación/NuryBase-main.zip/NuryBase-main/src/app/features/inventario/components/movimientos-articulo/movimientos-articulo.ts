import {
  Component,
  HostListener,
  OnInit,
  computed,
  inject,
  input,
  output,
  signal,
} from '@angular/core';
import {
  ArticuloMovimientos,
  FILTROS_MOVIMIENTO,
  FiltroMovimiento,
  MovimientoArticulo,
  etiquetaMovimiento,
  filtrarMovimientos,
  origenMovimiento,
} from '../../models/movimientos.model';
import { LIMITE_MOVIMIENTOS, MovimientosService } from '../../services/movimientos.service';

type EstadoCarga = 'cargando' | 'listo' | 'error';

const formatoCantidad = new Intl.NumberFormat('es-CL', { maximumFractionDigits: 3 });
const formatoFecha = new Intl.DateTimeFormat('es-CL', {
  day: '2-digit',
  month: '2-digit',
  year: 'numeric',
});
const formatoHora = new Intl.DateTimeFormat('es-CL', {
  hour: '2-digit',
  minute: '2-digit',
  hourCycle: 'h23',
});

/**
 * Historial de movimientos de un artículo (H3.2 T01): cada venta, anulación, compra, ajuste
 * o merma con su origen, cantidad, unidad, stock resultante, fecha y sucursal.
 */
@Component({
  selector: 'app-movimientos-articulo',
  templateUrl: './movimientos-articulo.html',
  styleUrls: ['../../styles/inventario-base.css', './movimientos-articulo.css'],
})
export class MovimientosArticulo implements OnInit {
  private readonly movimientosService = inject(MovimientosService);

  readonly articulo = input.required<ArticuloMovimientos>();
  readonly cerrar = output<void>();

  protected readonly filtros = FILTROS_MOVIMIENTO;
  protected readonly limite = LIMITE_MOVIMIENTOS;
  protected readonly estado = signal<EstadoCarga>('cargando');
  protected readonly movimientos = signal<MovimientoArticulo[]>([]);
  protected readonly filtro = signal<FiltroMovimiento>('todos');

  protected readonly visibles = computed(() =>
    filtrarMovimientos(this.movimientos(), this.filtro()),
  );
  /** Con todas las sucursales se muestra la columna Sucursal. */
  protected readonly todasLasSucursales = computed(() => this.articulo().sucursalId === null);
  protected readonly alcanzoLimite = computed(() => this.movimientos().length >= this.limite);

  ngOnInit(): void {
    this.cargar();
  }

  protected cargar(): void {
    const articulo = this.articulo();
    this.estado.set('cargando');
    this.movimientosService.listar(articulo.tipo, articulo.id, articulo.sucursalId).subscribe({
      next: (movimientos) => {
        this.movimientos.set(movimientos);
        this.estado.set('listo');
      },
      error: () => this.estado.set('error'),
    });
  }

  @HostListener('document:keydown.escape')
  protected cerrarModal(): void {
    this.cerrar.emit();
  }

  protected etiqueta(movimiento: MovimientoArticulo): string {
    return etiquetaMovimiento(movimiento.tipo);
  }

  protected origen(movimiento: MovimientoArticulo): string {
    return origenMovimiento(movimiento);
  }

  protected cantidad(movimiento: MovimientoArticulo): string {
    const signo = movimiento.cantidad > 0 ? '+' : '';
    return `${signo}${formatoCantidad.format(movimiento.cantidad)} ${movimiento.unidad}`;
  }

  protected numero(valor: number): string {
    return formatoCantidad.format(valor);
  }

  protected fecha(valor: Date): string {
    return formatoFecha.format(valor);
  }

  protected hora(valor: Date): string {
    return formatoHora.format(valor);
  }
}
