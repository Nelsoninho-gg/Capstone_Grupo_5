import { signal } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { Observable, of, Subject, throwError } from 'rxjs';
import type { Mock } from 'vitest';
import { HttpErrorResponse } from '@angular/common/http';
import {
  ConsultaFacturaIngresada,
  FacturasApiService,
  ResultadoIngresoFactura,
} from '../../../../core/api/facturas-api.service';
import { SucursalesApiService } from '../../../../core/api/sucursales-api.service';
import { User } from '../../../auth/models/auth.model';
import { AuthService } from '../../../auth/services/auth.service';
import { IngredientesApiService } from '../../../../core/api/ingredientes-api.service';
import { ProductosApiService } from '../../../../core/api/productos-api.service';
import { RecetasApiService } from '../../../../core/api/recetas-api.service';
import { UnidadesMedidaApiService } from '../../../../core/api/unidades-medida-api.service';
import { CargaFactura } from './carga-factura';

const XML_VALIDO = `<?xml version="1.0" encoding="ISO-8859-1"?>
<SetDTE><DTE version="1.0"><Documento ID="F1T33">
  <Encabezado>
    <IdDoc><TipoDTE>33</TipoDTE><Folio>56631070</Folio><FchEmis>2026-10-15</FchEmis></IdDoc>
    <Emisor><RUTEmisor>82623500-4</RUTEmisor><RznSoc>Ideal S.A</RznSoc></Emisor>
    <Totales><MntNeto>1000</MntNeto><TasaIVA>19</TasaIVA><IVA>190</IVA><MntTotal>1190</MntTotal></Totales>
  </Encabezado>
  <Detalle>
    <NroLinDet>1</NroLinDet><NmbItem>Pan</NmbItem><QtyItem>2</QtyItem>
    <PrcItem>500</PrcItem><MontoItem>1000</MontoItem>
  </Detalle>
</Documento></DTE></SetDTE>`;

function archivo(contenido: string, nombre = 'factura.xml'): File {
  return new File([contenido], nombre, { type: 'text/xml' });
}

function usuarioDePrueba(rol: User['rol'], sucursalId: number | null, sucursalNombre = ''): User {
  return {
    id: 1,
    nombre: 'Usuario de prueba',
    identificadorAcceso: 'usuario@nurys.cl',
    rol,
    sucursalId,
    sucursalNombre,
    activo: true,
  };
}

describe('CargaFactura', () => {
  let fixture: ComponentFixture<CargaFactura>;
  let ingredientes: () => Observable<unknown[]>;
  let sucursales: () => Observable<unknown[]>;
  let ingresar: Mock<(...args: unknown[]) => unknown>;
  let consultar: Mock<(...args: unknown[]) => unknown>;
  const usuarioActual = signal<User | null>(null);

  beforeEach(async () => {
    ingredientes = () => of([{ id: 1, nombre: 'Harina', activo: true, unidad_id: 1 }]);
    sucursales = () =>
      of([
        { id: 2, nombre: 'Viña del Mar', activo: true },
        { id: 1, nombre: 'Providencia', activo: true },
      ]);
    ingresar = vi.fn();
    // Por defecto la factura no está ingresada: el aviso solo aparece cuando una prueba lo pide.
    consultar = vi.fn(() => of({ identificacion_completa: true, ingresada: false }));
    // Por defecto un administrador sin sucursal propia, que elige dónde ingresar.
    usuarioActual.set(usuarioDePrueba('admin', null));
    await TestBed.configureTestingModule({
      imports: [CargaFactura],
      providers: [
        provideRouter([]),
        { provide: AuthService, useValue: { currentUser: usuarioActual } },
        {
          provide: FacturasApiService,
          useValue: {
            ingresar: (...args: unknown[]) => ingresar(...args),
            consultarIngresada: (...args: unknown[]) => consultar(...args),
          },
        },
        { provide: SucursalesApiService, useValue: { listarActivas: () => sucursales() } },
        { provide: IngredientesApiService, useValue: { listar: () => ingredientes() } },
        {
          provide: ProductosApiService,
          useValue: {
            listar: () =>
              of([
                { id: 10, nombre: 'Pan de molde', activo: true },
                { id: 11, nombre: 'Sándwich de queso', activo: true },
              ]),
          },
        },
        { provide: RecetasApiService, useValue: { listarIdsProductosConReceta: () => of([11]) } },
        {
          provide: UnidadesMedidaApiService,
          useValue: { listar: () => of([{ id: 1, nombre: 'Kilogramo', abreviatura: 'kg' }]) },
        },
      ],
    }).compileComponents();
    fixture = TestBed.createComponent(CargaFactura);
    fixture.detectChanges();
  });

  function elegir(file: File): Promise<void> {
    const input = fixture.nativeElement.querySelector('input[type="file"]') as HTMLInputElement;
    // jsdom no tiene DataTransfer: basta con una lista que responda a item(0).
    const lista = { length: 1, item: (indice: number) => (indice === 0 ? file : null) };
    Object.defineProperty(input, 'files', { value: lista, configurable: true });
    input.dispatchEvent(new Event('change'));
    return fixture.whenStable().then(() => fixture.detectChanges());
  }

  function texto(): string {
    return (fixture.nativeElement as HTMLElement).textContent ?? '';
  }

  it('starts with an empty state', () => {
    expect(texto()).toContain('Aún no hay ninguna factura cargada.');
  });

  it('shows the preview of a valid invoice without saving anything', async () => {
    await elegir(archivo(XML_VALIDO));

    expect(texto()).toContain('Ideal S.A');
    expect(texto()).toContain('56631070');
    expect(texto()).toContain('Líneas (1)');
    expect(texto()).toContain('Los montos de las líneas son netos (sin IVA).');
    expect(texto()).toContain('Revisa estos avisos antes de continuar.');
    expect(texto()).toContain('La factura no indica si las líneas incluyen IVA; se asumen netas.');
  });

  it('reads a file dropped on the upload zone', async () => {
    const zona = fixture.nativeElement.querySelector('.dropzone') as HTMLElement;
    const file = archivo(XML_VALIDO, 'arrastrada.xml');
    // jsdom no tiene DragEvent: un Event con dataTransfer basta para el componente.
    const soltar = Object.assign(new Event('drop', { cancelable: true }), {
      dataTransfer: { files: { length: 1, item: (indice: number) => (indice === 0 ? file : null) } },
    });

    zona.dispatchEvent(soltar);
    await fixture.whenStable();
    fixture.detectChanges();

    expect(soltar.defaultPrevented).toBe(true);
    expect(texto()).toContain('Archivo arrastrada.xml');
    expect(texto()).toContain('56631070');
  });

  it('lists the reasons why an invalid file cannot be entered', async () => {
    await elegir(archivo(XML_VALIDO.replace('<TipoDTE>33', '<TipoDTE>34')));

    expect(texto()).toContain('El archivo factura.xml no se puede ingresar.');
    expect(texto()).toContain('El documento es tipo 34. Solo se aceptan facturas electrónicas (tipo 33).');
    expect(texto()).not.toContain('Líneas (');
  });

  it('rejects a file that is too large before reading it', async () => {
    const grande = new File([new Uint8Array(6 * 1024 * 1024)], 'enorme.xml', { type: 'text/xml' });

    await elegir(grande);

    expect(texto()).toContain('No se pudo leer enorme.xml.');
    expect(texto()).toContain('El archivo pesa más de 5 MB.');
  });

  function campo(): HTMLInputElement {
    return fixture.nativeElement.querySelector('td.asociacion input[role="combobox"]') as HTMLInputElement;
  }

  function abrirLista(): void {
    campo().dispatchEvent(new Event('focus'));
    fixture.detectChanges();
  }

  function escribirBusqueda(texto: string): void {
    campo().value = texto;
    campo().dispatchEvent(new Event('input'));
    fixture.detectChanges();
  }

  function tecla(key: string): void {
    campo().dispatchEvent(new KeyboardEvent('keydown', { key, cancelable: true }));
    fixture.detectChanges();
  }

  function opciones(): string[] {
    const nombres = fixture.nativeElement.querySelectorAll('td.asociacion li[role="option"] .opcion-nombre');
    return Array.from(nombres).map((nombre) => (nombre as HTMLElement).textContent?.trim() ?? '');
  }

  function asociar(valor: string): void {
    abrirLista();
    const opcion = fixture.nativeElement.querySelector(`td.asociacion li[data-valor="${valor}"]`) as HTMLElement;
    opcion.click();
    fixture.detectChanges();
  }

  it('suggests an article from the line description and lets the user change it', async () => {
    await elegir(archivo(XML_VALIDO.replace('<NmbItem>Pan</NmbItem>', '<NmbItem>HARINA SIN POLVOS 25 KG</NmbItem>')));

    expect(campo().value).toBe('Harina');
    expect(texto()).toContain('Sugerido por la descripción. Revisa que sea el correcto.');
    expect(texto()).toContain('Pendiente: falta la equivalencia');

    asociar('producto:10');
    expect(campo().value).toBe('Pan de molde');
    expect(texto()).not.toContain('Sugerido por la descripción');
  });

  it('leaves the line pending when no article matches the description', async () => {
    await elegir(archivo(XML_VALIDO));

    expect(campo().value).toBe('');
    expect(texto()).not.toContain('Sugerido por la descripción');
    expect(fixture.nativeElement.querySelector('.etiqueta-pendiente')?.textContent?.trim()).toBe('Pendiente');
  });

  it('shows a single field per line and keeps the list closed until it is used', async () => {
    await elegir(archivo(XML_VALIDO));

    expect(fixture.nativeElement.querySelectorAll('td.asociacion input')).toHaveLength(1);
    expect(fixture.nativeElement.querySelector('td.asociacion select')).toBeNull();
    expect(fixture.nativeElement.querySelector('td.asociacion [role="listbox"]')).toBeNull();
  });

  it('offers raw materials and products without a recipe for each line', async () => {
    await elegir(archivo(XML_VALIDO));
    abrirLista();

    expect(opciones()).toEqual(['No corresponde a inventario', 'Harina', 'Pan de molde']);
    expect(texto()).toContain('Falta completar 1 línea.');
  });

  it('filters the articles of a line by name', async () => {
    await elegir(archivo(XML_VALIDO));
    abrirLista();

    escribirBusqueda('molde');
    expect(opciones()).toEqual(['No corresponde a inventario', 'Pan de molde']);

    escribirBusqueda('zzz');
    expect(texto()).toContain('Sin coincidencias. Prueba con otra palabra.');
  });

  it('shows the chosen article in the same field and keeps it while searching', async () => {
    await elegir(archivo(XML_VALIDO));
    asociar('producto:10');
    expect(campo().value).toBe('Pan de molde');

    abrirLista();
    escribirBusqueda('zzz');

    expect(opciones()).toEqual(['No corresponde a inventario', 'Pan de molde']);
    expect(texto()).toContain('Sin coincidencias. Prueba con otra palabra.');

    campo().dispatchEvent(new Event('blur'));
    fixture.detectChanges();
    expect(campo().value).toBe('Pan de molde');
  });

  it('chooses with the keyboard and closes with Escape', async () => {
    await elegir(archivo(XML_VALIDO));
    abrirLista();

    tecla('ArrowDown');
    tecla('ArrowDown');
    tecla('Enter');

    expect(campo().value).toBe('Pan de molde');
    expect(fixture.nativeElement.querySelector('td.asociacion [role="listbox"]')).toBeNull();

    tecla('ArrowDown');
    expect(fixture.nativeElement.querySelector('td.asociacion [role="listbox"]')).not.toBeNull();
    tecla('Escape');
    expect(fixture.nativeElement.querySelector('td.asociacion [role="listbox"]')).toBeNull();
  });

  function escribirEquivalencia(valor: string): void {
    const campo = fixture.nativeElement.querySelector('.equivalencia-control input') as HTMLInputElement;
    campo.value = valor;
    campo.dispatchEvent(new Event('input'));
    fixture.detectChanges();
  }

  it('keeps an associated line pending until its equivalence is confirmed', async () => {
    await elegir(archivo(XML_VALIDO));

    asociar('producto:10');

    expect(texto()).toContain('Falta completar 1 línea.');
    expect(texto()).toContain('Pendiente: falta la equivalencia');
    expect(texto()).toContain('Indica cuánto trae cada presentación de la factura, en un.');

    escribirEquivalencia('12');

    const ingreso = fixture.nativeElement.querySelector('.ingreso') as HTMLElement;
    expect(ingreso.textContent?.replace(/\s+/g, ' ').trim()).toBe('Se sumarán 24 un (2 × 12)');
    expect(texto()).toContain('Todas las líneas están completas.');
    expect(fixture.nativeElement.querySelector('.etiqueta-pendiente')).toBeNull();
  });

  it('uses the unit of the raw material and accepts a decimal comma', async () => {
    await elegir(archivo(XML_VALIDO));

    asociar('ingrediente:1');
    escribirEquivalencia('0,5');

    expect(fixture.nativeElement.querySelector('.equivalencia-unidad')?.textContent?.trim()).toBe('kg');
    expect(texto()).toContain('Se sumarán 1 kg');
  });

  it('rejects an invalid equivalence and keeps the line pending', async () => {
    await elegir(archivo(XML_VALIDO));

    asociar('producto:10');
    escribirEquivalencia('0');

    expect(texto()).toContain('Escribe un número mayor que cero, con hasta 3 decimales.');
    expect(texto()).toContain('Falta completar 1 línea.');
  });

  it('asks for the equivalence again when the article changes', async () => {
    await elegir(archivo(XML_VALIDO));
    asociar('producto:10');
    escribirEquivalencia('12');

    asociar('ingrediente:1');

    const campo = fixture.nativeElement.querySelector('.equivalencia-control input') as HTMLInputElement;
    expect(campo.value).toBe('');
    expect(texto()).toContain('Falta completar 1 línea.');
  });

  it('does not ask for an equivalence on a non-inventory line', async () => {
    await elegir(archivo(XML_VALIDO));

    asociar('no-inventario');

    expect(fixture.nativeElement.querySelector('.equivalencia')).toBeNull();
  });

  it('keeps the chosen article when the line is redrawn', async () => {
    await elegir(archivo(XML_VALIDO));
    asociar('producto:10');
    const anterior = campo();

    // Recargar el catálogo pasa por «cargando» y vuelve a crear el campo de cada línea.
    const respuesta = new Subject<unknown[]>();
    ingredientes = () => respuesta;
    (fixture.componentInstance as unknown as { cargarCatalogo(): void }).cargarCatalogo();
    fixture.detectChanges();
    expect(campo()).toBeNull();

    respuesta.next([{ id: 1, nombre: 'Harina', activo: true, unidad_id: 1 }]);
    respuesta.complete();
    fixture.detectChanges();

    expect(campo()).not.toBe(anterior);
    expect(campo().value).toBe('Pan de molde');
  });

  it('lets the user mark a line as not inventory', async () => {
    await elegir(archivo(XML_VALIDO));

    asociar('no-inventario');

    expect(campo().value).toBe('No corresponde a inventario');
    expect(texto()).toContain('Todas las líneas están completas.');
  });

  it('offers a retry when the catalog cannot be loaded', async () => {
    ingredientes = () => throwError(() => new Error('sin conexión'));

    await elegir(archivo(XML_VALIDO));

    expect(texto()).toContain('No pudimos cargar el catálogo.');
    expect(campo()).toBeNull();

    ingredientes = () => of([]);
    const reintentar = Array.from(fixture.nativeElement.querySelectorAll('button')).find(
      (boton) => (boton as HTMLButtonElement).textContent?.trim() === 'Reintentar',
    ) as HTMLButtonElement;
    reintentar.click();
    fixture.detectChanges();

    expect(campo()).not.toBeNull();
  });

  /** Cambia de usuario y vuelve a pedir las sucursales, como al abrir la pantalla con otra sesión. */
  function entrarComo(usuario: User | null): void {
    usuarioActual.set(usuario);
    (fixture.componentInstance as unknown as { cargarDestino(): void }).cargarDestino();
    fixture.detectChanges();
  }

  it('asks an admin to choose the branch that will receive the stock', () => {
    const select = fixture.nativeElement.querySelector('.destino select') as HTMLSelectElement;

    expect(Array.from(select.options).map((opcion) => opcion.textContent?.trim())).toEqual([
      'Elige una sucursal…',
      'Providencia',
      'Viña del Mar',
    ]);
    expect(texto()).toContain('Elige la sucursal antes de confirmar la factura.');
  });

  it('shows the chosen branch in the document data', async () => {
    const select = fixture.nativeElement.querySelector('.destino select') as HTMLSelectElement;
    select.value = '2';
    select.dispatchEvent(new Event('change'));
    fixture.detectChanges();

    expect(texto()).toContain('Como administrador puedes ingresar facturas en cualquier sucursal.');

    await elegir(archivo(XML_VALIDO));

    const destino = fixture.nativeElement.querySelector('.document-destino dd') as HTMLElement;
    expect(destino.textContent?.replace(/\s+/g, ' ').trim()).toBe('Viña del Mar');
  });

  it('shows "Sin elegir" in the document data while the admin has not chosen a branch', async () => {
    await elegir(archivo(XML_VALIDO));

    const destino = fixture.nativeElement.querySelector('.document-destino dd') as HTMLElement;
    expect(destino.textContent?.replace(/\s+/g, ' ').trim()).toBe('Sin elegir');
  });

  it('preselects the admin own branch', () => {
    entrarComo(usuarioDePrueba('admin', 1, 'Providencia'));

    const select = fixture.nativeElement.querySelector('.destino select') as HTMLSelectElement;
    expect(select.value).toBe('1');
    expect(texto()).not.toContain('Elige la sucursal antes de confirmar la factura.');
  });

  it('fixes the branch of a warehouse user, without a choice', async () => {
    entrarComo(usuarioDePrueba('bodeguero', 1, 'Providencia'));

    expect(fixture.nativeElement.querySelector('.destino select')).toBeNull();
    expect(fixture.nativeElement.querySelector('.destino-nombre')?.textContent?.trim()).toBe('Providencia');
    expect(texto()).toContain('Tu usuario solo puede ingresar facturas en esta sucursal.');

    await elegir(archivo(XML_VALIDO));

    const destino = fixture.nativeElement.querySelector('.document-destino dd') as HTMLElement;
    expect(destino.textContent?.replace(/\s+/g, ' ').trim()).toBe('Providencia');
  });

  it('does not list branches for a warehouse user', () => {
    const listar = vi.fn(() => of([]));
    sucursales = listar;

    entrarComo(usuarioDePrueba('bodeguero', 1, 'Providencia'));

    expect(listar).not.toHaveBeenCalled();
  });

  it('blocks a warehouse user without an assigned branch', () => {
    entrarComo(usuarioDePrueba('bodeguero', null));

    expect(texto()).toContain('No puedes ingresar facturas.');
    expect(texto()).toContain('no tiene una sucursal asignada');
    expect(fixture.nativeElement.querySelector('.dropzone')).toBeNull();
  });

  it('blocks a cashier', () => {
    entrarComo(usuarioDePrueba('cajero', 1, 'Providencia'));

    expect(texto()).toContain('Tu rol no permite ingresar facturas.');
    expect(fixture.nativeElement.querySelector('.dropzone')).toBeNull();
  });

  it('offers a retry when the branches cannot be loaded', () => {
    sucursales = () => throwError(() => new Error('sin conexión'));
    entrarComo(usuarioDePrueba('admin', null));

    expect(texto()).toContain('No pudimos cargar las sucursales.');
    expect(fixture.nativeElement.querySelector('.dropzone')).toBeNull();

    sucursales = () => of([{ id: 1, nombre: 'Providencia', activo: true }]);
    const reintentar = Array.from(fixture.nativeElement.querySelectorAll('button')).find(
      (boton) => (boton as HTMLButtonElement).textContent?.trim() === 'Reintentar',
    ) as HTMLButtonElement;
    reintentar.click();
    fixture.detectChanges();

    expect(fixture.nativeElement.querySelector('.dropzone')).not.toBeNull();
  });

  it('keeps the chosen branch when the invoice is replaced', async () => {
    const select = fixture.nativeElement.querySelector('.destino select') as HTMLSelectElement;
    select.value = '1';
    select.dispatchEvent(new Event('change'));
    await elegir(archivo(XML_VALIDO));

    await elegir(archivo(XML_VALIDO, 'otra.xml'));

    const destino = fixture.nativeElement.querySelector('.document-destino dd') as HTMLElement;
    expect(destino.textContent?.replace(/\s+/g, ' ').trim()).toBe('Providencia');
  });

  // Confirmación (H3.1 T08) -------------------------------------------------------------

  function elegirSucursalDestino(valor: string): void {
    const select = fixture.nativeElement.querySelector('.destino select') as HTMLSelectElement;
    select.value = valor;
    select.dispatchEvent(new Event('change'));
    fixture.detectChanges();
  }

  function botonConfirmar(): HTMLButtonElement {
    return fixture.nativeElement.querySelector('.confirmar-barra button') as HTMLButtonElement;
  }

  /** Factura lista para confirmar: sucursal elegida y la única línea completa. */
  async function prepararFacturaCompleta(): Promise<void> {
    elegirSucursalDestino('2');
    await elegir(archivo(XML_VALIDO));
    asociar('producto:10');
    escribirEquivalencia('12');
  }

  const RESULTADO: ResultadoIngresoFactura = {
    factura_compra_id: 7,
    factura_xml_id: 3,
    lineas_inventario: 1,
    lineas_no_inventario: 0,
  };

  it('explains why the invoice cannot be confirmed yet', async () => {
    await elegir(archivo(XML_VALIDO));

    expect(botonConfirmar().disabled).toBe(true);
    expect(texto()).toContain('Elige la sucursal que recibirá el stock.');

    elegirSucursalDestino('2');

    expect(botonConfirmar().disabled).toBe(true);
    expect(texto()).toContain('Completa la línea pendiente.');
  });

  it('sends the original file, the branch and each line when confirming', async () => {
    ingresar.mockReturnValue(of(RESULTADO));
    await prepararFacturaCompleta();

    expect(texto()).toContain('Todo listo. El stock se sumará en Viña del Mar.');
    botonConfirmar().click();
    fixture.detectChanges();

    expect(ingresar).toHaveBeenCalledOnce();
    const [sucursal, bytes, nombre, lineas] = ingresar.mock.calls[0];
    expect(sucursal).toBe(2);
    expect(new TextDecoder('latin1').decode(bytes as Uint8Array)).toBe(XML_VALIDO);
    expect(nombre).toBe('factura.xml');
    expect(lineas).toEqual([{ numero_linea: 1, producto_id: 10, unidades_por_presentacion: 12 }]);
  });

  it('closes the modal from its close button, which gets the focus on opening', () => {
    const cerrar = vi.fn();
    fixture.componentInstance.cerrarModal.subscribe(cerrar);
    const boton = fixture.nativeElement.querySelector('.modal-close') as HTMLButtonElement;

    expect(document.activeElement).toBe(boton);
    boton.click();

    expect(cerrar).toHaveBeenCalledOnce();
  });

  it('tells the list to reload after an entry and closes from the result', async () => {
    const ingresada = vi.fn();
    const cerrar = vi.fn();
    fixture.componentInstance.ingresada.subscribe(ingresada);
    fixture.componentInstance.cerrarModal.subscribe(cerrar);
    ingresar.mockReturnValue(of(RESULTADO));
    await prepararFacturaCompleta();

    botonConfirmar().click();
    fixture.detectChanges();
    expect(ingresada).toHaveBeenCalledOnce();

    const ver = Array.from(fixture.nativeElement.querySelectorAll('button')).find(
      (boton) => (boton as HTMLButtonElement).textContent?.trim() === 'Ver facturas ingresadas',
    ) as HTMLButtonElement;
    ver.click();
    expect(cerrar).toHaveBeenCalledOnce();
  });

  it('shows the result and lets the user load another invoice', async () => {
    ingresar.mockReturnValue(of(RESULTADO));
    await prepararFacturaCompleta();

    botonConfirmar().click();
    fixture.detectChanges();

    expect(texto()).toContain('Factura 56631070 ingresada en Viña del Mar.');
    expect(texto()).toContain('1 línea sumó stock.');
    expect(fixture.nativeElement.querySelector('.lines-table')).toBeNull();

    const otra = Array.from(fixture.nativeElement.querySelectorAll('button')).find(
      (boton) => (boton as HTMLButtonElement).textContent?.trim() === 'Cargar otra factura',
    ) as HTMLButtonElement;
    otra.click();
    fixture.detectChanges();

    expect(texto()).toContain('Aún no hay ninguna factura cargada.');
  });

  it('sends a non-inventory line without article or equivalence', async () => {
    ingresar.mockReturnValue(of({ ...RESULTADO, lineas_inventario: 0, lineas_no_inventario: 1 }));
    elegirSucursalDestino('1');
    await elegir(archivo(XML_VALIDO));
    asociar('no-inventario');

    botonConfirmar().click();
    fixture.detectChanges();

    expect(ingresar.mock.calls[0][3]).toEqual([{ numero_linea: 1, no_corresponde_inventario: true }]);
    expect(texto()).toContain('0 líneas sumaron stock.');
    expect(texto()).toContain('1 línea no corresponde a inventario.');
  });

  it('disables the button while confirming and ignores a second click', async () => {
    const respuesta = new Subject<ResultadoIngresoFactura>();
    ingresar.mockReturnValue(respuesta);
    await prepararFacturaCompleta();

    botonConfirmar().click();
    fixture.detectChanges();
    botonConfirmar().click();
    fixture.detectChanges();

    expect(ingresar).toHaveBeenCalledOnce();
    expect(botonConfirmar().disabled).toBe(true);
    expect(botonConfirmar().textContent?.trim()).toBe('Confirmando…');
    expect(texto()).toContain('Ingresando la factura… No cierres esta pantalla.');
    expect((fixture.nativeElement.querySelector('.modal-close') as HTMLButtonElement).disabled).toBe(true);

    respuesta.next(RESULTADO);
    respuesta.complete();
    fixture.detectChanges();

    expect(texto()).toContain('Factura 56631070 ingresada en Viña del Mar.');
  });

  it('blocks the confirmation of an invoice that was already entered', async () => {
    ingresar.mockReturnValue(
      throwError(
        () =>
          new HttpErrorResponse({
            status: 409,
            error: { code: '23505', message: 'Esta factura ya fue ingresada (folio 56631070 del emisor 82623500-4).' },
          }),
      ),
    );
    await prepararFacturaCompleta();

    botonConfirmar().click();
    fixture.detectChanges();

    expect(texto()).toContain('Esta factura ya fue ingresada (folio 56631070 del emisor 82623500-4). No se volvió a sumar stock.');
    expect(botonConfirmar().disabled).toBe(true);
  });

  // Factura ya ingresada (H3.7 T03, T05 y T06) -----------------------------------------------

  const INGRESO_PREVIO: ConsultaFacturaIngresada = {
    identificacion_completa: true,
    ingresada: true,
    puede_ver_detalle: true,
    sucursal: 'Providencia',
    ingresada_en: '2026-10-20T15:32:00',
    ingresada_por: 'Ana Pérez',
    ingresada_por_ti: false,
    lineas_inventario: 2,
    lineas_no_inventario: 1,
  };

  it('asks the server about the identity of the invoice when it is loaded', async () => {
    await elegir(archivo(XML_VALIDO));

    expect(consultar).toHaveBeenCalledExactlyOnceWith('82623500-4', 33, 56631070);
    expect(texto()).not.toContain('ya fue ingresada');
  });

  it('warns and blocks an invoice that was already entered, before confirming', async () => {
    consultar.mockReturnValue(of(INGRESO_PREVIO));
    await prepararFacturaCompleta();

    expect(texto()).toContain('Esta factura ya fue ingresada.');
    expect(texto()).toContain('La ingresó Ana Pérez el 20-10-2026 15:32 en Providencia.');
    expect(texto()).toContain('2 líneas sumaron stock y 1 no corresponde a inventario.');
    expect(texto()).toContain('No se puede volver a ingresar y el stock no se sumará otra vez.');
    expect(botonConfirmar().disabled).toBe(true);

    botonConfirmar().click();
    expect(ingresar).not.toHaveBeenCalled();
  });

  it('tells the user when they entered the invoice themselves', async () => {
    consultar.mockReturnValue(of({ ...INGRESO_PREVIO, ingresada_por_ti: true }));
    await elegir(archivo(XML_VALIDO));

    expect(texto()).toContain('La ingresaste tú el 20-10-2026 15:32 en Providencia.');
    expect(texto()).toContain('Si no viste la confirmación, el ingreso sí se completó.');
  });

  it('does not reveal where an invoice entered in another branch was entered', async () => {
    consultar.mockReturnValue(of({ identificacion_completa: true, ingresada: true, puede_ver_detalle: false }));
    await elegir(archivo(XML_VALIDO));

    expect(texto()).toContain('Esta factura ya fue ingresada.');
    expect(texto()).toContain('Se ingresó en otra sucursal y tu usuario no puede ver el detalle.');
    expect(texto()).not.toContain('Providencia.');
  });

  it('blocks an invoice whose identity is incomplete', async () => {
    consultar.mockReturnValue(of({ identificacion_completa: false, ingresada: false }));
    await prepararFacturaCompleta();

    expect(texto()).toContain('La factura no tiene identificación completa.');
    expect(botonConfirmar().disabled).toBe(true);
  });

  it('waits for the check before allowing the confirmation', async () => {
    const respuesta = new Subject<ConsultaFacturaIngresada>();
    consultar.mockReturnValue(respuesta);
    await prepararFacturaCompleta();

    expect(texto()).toContain('Comprobando si la factura ya fue ingresada…');
    expect(botonConfirmar().disabled).toBe(true);

    respuesta.next({ identificacion_completa: true, ingresada: false });
    respuesta.complete();
    fixture.detectChanges();

    expect(botonConfirmar().disabled).toBe(false);
  });

  it('lets the user continue when the check fails, because the server checks again', async () => {
    consultar.mockReturnValue(throwError(() => new HttpErrorResponse({ status: 0 })));
    ingresar.mockReturnValue(of(RESULTADO));
    await prepararFacturaCompleta();

    expect(texto()).toContain('No pudimos comprobar si la factura ya fue ingresada.');
    expect(botonConfirmar().disabled).toBe(false);

    botonConfirmar().click();
    fixture.detectChanges();

    expect(texto()).toContain('Factura 56631070 ingresada en Viña del Mar.');
  });

  it('shows the existing entry when a retry finds the invoice already entered', async () => {
    ingresar.mockReturnValue(throwError(() => new HttpErrorResponse({ status: 0 })));
    await prepararFacturaCompleta();
    botonConfirmar().click();
    fixture.detectChanges();
    expect(texto()).toContain('no sabemos si la factura alcanzó a ingresarse');

    // La primera vez sí se había guardado: el reintento la encuentra y la consulta la describe.
    ingresar.mockReturnValue(
      throwError(
        () =>
          new HttpErrorResponse({
            status: 409,
            error: { code: '23505', message: 'Esta factura ya fue ingresada (folio 56631070 del emisor 82623500-4).' },
          }),
      ),
    );
    consultar.mockReturnValue(of({ ...INGRESO_PREVIO, ingresada_por_ti: true }));
    botonConfirmar().click();
    fixture.detectChanges();

    expect(texto()).toContain('La ingresaste tú el 20-10-2026 15:32 en Providencia.');
    expect(texto()).toContain('No se volvió a sumar stock.');
    expect(botonConfirmar().disabled).toBe(true);
  });

  it('ignores a late answer about a file that was already replaced', async () => {
    const tardia = new Subject<ConsultaFacturaIngresada>();
    consultar.mockReturnValueOnce(tardia);
    await elegir(archivo(XML_VALIDO));

    await elegir(archivo(XML_VALIDO, 'otra.xml'));
    tardia.next(INGRESO_PREVIO);
    fixture.detectChanges();

    expect(texto()).not.toContain('Esta factura ya fue ingresada.');
  });

  it('treats the «already entered» result of the server as a blocked confirmation', async () => {
    ingresar.mockReturnValue(of({ ya_ingresada: true, intento_id: 5 }));
    await prepararFacturaCompleta();

    botonConfirmar().click();
    fixture.detectChanges();

    expect(texto()).toContain('Esta factura ya fue ingresada. No se volvió a sumar stock.');
    expect(texto()).not.toContain('Factura 56631070 ingresada en Viña del Mar.');
    expect(botonConfirmar().disabled).toBe(true);
    // Una consulta al cargar el archivo y otra tras el rechazo, para mostrar el ingreso existente.
    expect(consultar).toHaveBeenCalledTimes(2);
  });

  it('offers a retry after losing the connection', async () => {
    ingresar.mockReturnValue(throwError(() => new HttpErrorResponse({ status: 0 })));
    await prepararFacturaCompleta();

    botonConfirmar().click();
    fixture.detectChanges();

    expect(texto()).toContain('no sabemos si la factura alcanzó a ingresarse');
    expect(botonConfirmar().textContent?.trim()).toBe('Reintentar');
    expect(botonConfirmar().disabled).toBe(false);

    ingresar.mockReturnValue(of(RESULTADO));
    botonConfirmar().click();
    fixture.detectChanges();

    expect(ingresar).toHaveBeenCalledTimes(2);
    expect(texto()).toContain('Factura 56631070 ingresada en Viña del Mar.');
  });

  it('shows the server explanation when the server rejects the data', async () => {
    ingresar.mockReturnValue(
      throwError(
        () =>
          new HttpErrorResponse({
            status: 400,
            error: { code: '22023', message: 'Línea 1: el producto elegido tiene receta; su stock sale de sus ingredientes.' },
          }),
      ),
    );
    await prepararFacturaCompleta();

    botonConfirmar().click();
    fixture.detectChanges();

    expect(texto()).toContain('Línea 1: el producto elegido tiene receta; su stock sale de sus ingredientes.');
    expect(fixture.nativeElement.querySelector('.lines-table')).not.toBeNull();
  });

  it('returns to the empty state when the invoice is cancelled, without saving anything', async () => {
    await prepararFacturaCompleta();
    const cancelar = Array.from(fixture.nativeElement.querySelectorAll('button')).find(
      (boton) => (boton as HTMLButtonElement).textContent?.trim() === 'Cancelar',
    ) as HTMLButtonElement;

    cancelar.click();
    fixture.detectChanges();

    expect(texto()).toContain('Aún no hay ninguna factura cargada.');
    // Cancelar una factura lista para confirmar no envía nada: el stock no puede cambiar.
    expect(ingresar).not.toHaveBeenCalled();
  });
});
