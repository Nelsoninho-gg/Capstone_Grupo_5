/**
 * Asociación de las líneas de una factura XML con el catálogo (H3.1 T05) y
 * equivalencia entre la presentación de compra y la unidad del catálogo (H3.1 T06).
 *
 * Cada línea termina asociada a una materia prima (ingrediente), a un producto
 * de reventa (sin receta) o marcada como «No corresponde a inventario». Las
 * asociadas a un artículo necesitan además una equivalencia confirmada por el
 * usuario. Mientras falte algo, la línea queda pendiente y la factura no se
 * puede confirmar (H3.1 T08).
 */

export type TipoArticulo = 'ingrediente' | 'producto';

export interface ArticuloCatalogo {
  tipo: TipoArticulo;
  id: number;
  nombre: string;
  /** Unidad en que se lleva el stock: la del ingrediente (kg, L…) o «un» para productos. */
  unidad: string;
}

/** Los productos de reventa se cuentan por unidad (`stock_producto_sucursal`). */
export const UNIDAD_PRODUCTO = 'un';

export type AsociacionLinea =
  | { tipo: 'pendiente' }
  | { tipo: 'no-inventario' }
  | { tipo: TipoArticulo; id: number };

export const PENDIENTE: AsociacionLinea = { tipo: 'pendiente' };

interface IngredienteCatalogo {
  id: number;
  nombre: string;
  activo: boolean;
  unidad_id: number;
}

interface UnidadCatalogo {
  id: number;
  abreviatura: string;
}

interface ProductoCatalogo {
  id: number;
  nombre: string;
  activo: boolean;
}

/**
 * Artículos a los que se puede asociar una línea: materias primas activas y
 * productos activos sin receta. Un producto con receta no se compra: su stock
 * sale de sus ingredientes (misma regla que `fn_aplicar_compra`).
 */
export function armarCatalogo(
  ingredientes: IngredienteCatalogo[],
  productos: ProductoCatalogo[],
  idsProductosConReceta: number[],
  unidades: UnidadCatalogo[],
): { ingredientes: ArticuloCatalogo[]; productos: ArticuloCatalogo[] } {
  const conReceta = new Set(idsProductosConReceta);
  const abreviaturas = new Map(unidades.map((unidad) => [unidad.id, unidad.abreviatura]));
  const porNombre = (a: ArticuloCatalogo, b: ArticuloCatalogo) => a.nombre.localeCompare(b.nombre, 'es');

  return {
    ingredientes: ingredientes
      .filter((ingrediente) => ingrediente.activo)
      .map(
        ({ id, nombre, unidad_id }): ArticuloCatalogo => ({
          tipo: 'ingrediente',
          id,
          nombre,
          // unidad_id es obligatoria en ingredientes; el respaldo solo cubre una unidad borrada.
          unidad: abreviaturas.get(unidad_id) ?? 'unidad sin nombre',
        }),
      )
      .sort(porNombre),
    productos: productos
      .filter((producto) => producto.activo && !conReceta.has(producto.id))
      .map(({ id, nombre }): ArticuloCatalogo => ({ tipo: 'producto', id, nombre, unidad: UNIDAD_PRODUCTO }))
      .sort(porNombre),
  };
}

/**
 * Equivalencia escrita por el usuario: cuántas unidades del catálogo trae una
 * presentación. Acepta coma o punto decimal y hasta 3 decimales (como
 * `unidades_por_presentacion NUMERIC(12,3)`). Devuelve null si no es válida.
 */
export function leerEquivalencia(texto: string): number | null {
  const limpio = texto.trim().replace(',', '.');
  if (!/^\d{1,9}(\.\d{1,3})?$/.test(limpio)) return null;
  const valor = Number(limpio);
  return valor > 0 ? valor : null;
}

/** Cantidad que se sumará al stock: la del XML por la equivalencia, como `cantidad_ingreso`. */
export function cantidadIngreso(cantidad: number, equivalencia: number): number {
  return Math.round(cantidad * equivalencia * 1000) / 1000;
}

/** Solo las líneas asociadas a un artículo suman stock y necesitan equivalencia. */
export function necesitaEquivalencia(asociacion: AsociacionLinea): boolean {
  return asociacion.tipo === 'ingrediente' || asociacion.tipo === 'producto';
}

/** Minúsculas y sin tildes, para buscar «pinguino» y encontrar «Pingüino». */
export function normalizar(texto: string): string {
  return texto
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLocaleLowerCase('es')
    .trim();
}

/**
 * Artículos cuyo nombre contiene todas las palabras buscadas, sin importar
 * mayúsculas ni tildes. El artículo ya elegido se conserva aunque no coincida,
 * para que el selector no pierda la opción seleccionada.
 */
export function filtrarArticulos(
  articulos: ArticuloCatalogo[],
  busqueda: string,
  elegido: AsociacionLinea = PENDIENTE,
): ArticuloCatalogo[] {
  const palabras = normalizar(busqueda).split(/\s+/).filter(Boolean);
  if (palabras.length === 0) return articulos;
  return articulos.filter((articulo) => {
    if ('id' in elegido && elegido.tipo === articulo.tipo && elegido.id === articulo.id) return true;
    const nombre = normalizar(articulo.nombre);
    return palabras.every((palabra) => nombre.includes(palabra));
  });
}

/** Valor de un `<select>`: '' pendiente, 'no-inventario', 'ingrediente:12' o 'producto:5'. */
export function valorAsociacion(asociacion: AsociacionLinea): string {
  if (asociacion.tipo === 'pendiente') return '';
  if (asociacion.tipo === 'no-inventario') return 'no-inventario';
  return `${asociacion.tipo}:${asociacion.id}`;
}

export function leerValorAsociacion(valor: string): AsociacionLinea {
  if (valor === 'no-inventario') return { tipo: 'no-inventario' };
  const partes = /^(ingrediente|producto):(\d+)$/.exec(valor);
  if (!partes) return PENDIENTE;
  return { tipo: partes[1] as TipoArticulo, id: Number(partes[2]) };
}

/**
 * Líneas que aún requieren acción: sin artículo ni marca de no inventariable, o
 * asociadas a un artículo pero sin una equivalencia válida.
 */
export function contarPendientes(
  numerosLinea: number[],
  asociaciones: ReadonlyMap<number, AsociacionLinea>,
  equivalencias: ReadonlyMap<number, string> = new Map(),
): number {
  return numerosLinea.filter((numero) => {
    const asociacion = asociaciones.get(numero) ?? PENDIENTE;
    if (asociacion.tipo === 'pendiente') return true;
    return necesitaEquivalencia(asociacion) && leerEquivalencia(equivalencias.get(numero) ?? '') === null;
  }).length;
}
