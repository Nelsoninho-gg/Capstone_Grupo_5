import { HttpErrorResponse, provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { Provider } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { ActivatedRoute, Router, convertToParamMap } from '@angular/router';
import { Subject, of, throwError } from 'rxjs';
import { User } from '../../../auth/models/auth.model';
import { AuthService } from '../../../auth/services/auth.service';
import { AjusteInventario } from '../../components/ajuste-inventario/ajuste-inventario';
import { MinimoSinFilaError } from '../../models/fallo-minimo';
import { ExistenciaStock, calcularEstadoStock } from '../../models/inventario.model';
import { InventarioService } from '../../services/inventario.service';
import { MovimientosService } from '../../services/movimientos.service';
import { INTERVALO_REVISION_MS, Inventario, vistaDesdeUrl } from './inventario';

describe('calcularEstadoStock', () => {
  it.each([
    [-2, 5, 'agotado'],
    [-3, 0, 'agotado'],
    [0, 5, 'agotado'],
    [0, 0, 'agotado'],
    [3, 5, 'critico'],
    [1.124, 1.125, 'critico'],
    [5, 5, 'estable'],
    [1.125, 1.125, 'estable'],
    [8, 5, 'estable'],
    [0.5, 0, 'estable'],
  ] as const)('stock %s con mínimo %s es %s', (cantidad, minimo, esperado) => {
    expect(calcularEstadoStock(cantidad, minimo)).toBe(esperado);
  });
});

describe('Inventario', () => {
  let fixture: ComponentFixture<Inventario>;
  const cafe: ExistenciaStock = {
    id: 'materia_prima-cafe-1',
    articuloId: 11,
    articulo: 'Café en grano',
    tipo: 'materia_prima',
    cantidad: 4.25,
    stockMinimo: 2,
    unidad: 'kg',
    sucursalId: 1,
    sucursal: 'Nury Providencia',
  };
  const azucar: ExistenciaStock = {
    id: 'materia_prima-azucar-1',
    articuloId: 12,
    articulo: 'Azúcar',
    tipo: 'materia_prima',
    cantidad: 0.6,
    stockMinimo: 1,
    unidad: 'kg',
    sucursalId: 1,
    sucursal: 'Nury Providencia',
  };
  const agua: ExistenciaStock = {
    id: 'producto-agua-2',
    articuloId: 21,
    articulo: 'Agua mineral 500 ml',
    tipo: 'producto',
    cantidad: -2,
    stockMinimo: 12,
    unidad: 'un',
    sucursalId: 2,
    sucursal: 'Nury Ñuñoa',
  };
  const service = {
    listarExistencias: vi.fn(),
    actualizarMinimo: vi.fn(),
    listarMermas: vi.fn(),
    versionInventario: vi.fn(() => of({ stock: 'inicial', movimientos: 1 })),
  };

  let usuarioActual: Partial<User> = {};
  const movimientos = vi.fn(() => of([]));

  async function render(extra: Provider[] = []): Promise<void> {
    await TestBed.configureTestingModule({
      imports: [Inventario],
      providers: [
        // El modal de ajuste real usa los servicios HTTP de la API.
        provideHttpClient(),
        provideHttpClientTesting(),
        { provide: InventarioService, useValue: service },
        {
          provide: AuthService,
          useValue: { currentUser: () => usuarioActual },
        },
        ...extra,
      ],
    }).compileComponents();
    fixture = TestBed.createComponent(Inventario);
    fixture.detectChanges();
    await fixture.whenStable();
  }

  function element(): HTMLElement {
    return fixture.nativeElement as HTMLElement;
  }
  function filas(): HTMLTableRowElement[] {
    return Array.from(
      element().querySelectorAll('tbody tr:not(.empty-row, .skeleton-row, .sr-only)'),
    );
  }
  function articulos(): (string | undefined)[] {
    return filas().map((fila) => fila.cells[0].textContent?.trim());
  }
  function cambiar(selector: string, value: string, evento = 'change'): void {
    const control = element().querySelector(selector) as HTMLInputElement | HTMLSelectElement;
    control.value = value;
    control.dispatchEvent(new Event(evento));
    fixture.detectChanges();
  }
  function click(selector: string): void {
    (element().querySelector(selector) as HTMLButtonElement).click();
    fixture.detectChanges();
  }
  function tarjeta(etiqueta: string): HTMLButtonElement {
    return Array.from(element().querySelectorAll<HTMLButtonElement>('.summary-card')).find((card) =>
      card.textContent?.includes(etiqueta),
    )!;
  }
  function abrirEdicion(articulo: string): void {
    const fila = filas().find((f) => f.cells[0].textContent?.trim() === articulo)!;
    fila.querySelector<HTMLButtonElement>('.edit-button')!.click();
    fixture.detectChanges();
  }
  function modal(): HTMLElement | null {
    return element().querySelector('[role="dialog"]');
  }

  beforeEach(() => {
    usuarioActual = { nombre: 'Rocío Fuentes', rol: 'bodeguero', sucursalId: 1 };
    service.listarExistencias.mockReset();
    service.actualizarMinimo.mockReset();
    service.listarMermas.mockReset();
    service.listarMermas.mockReturnValue(of([]));
    service.actualizarMinimo.mockImplementation(
      (existencia: ExistenciaStock, stockMinimo: number) => of({ ...existencia, stockMinimo }),
    );
  });

  it('shows the loading state while stock is being fetched', async () => {
    service.listarExistencias.mockReturnValue(new Subject<ExistenciaStock[]>());
    await render();

    expect(element().querySelectorAll('.skeleton-row')).toHaveLength(5);
    expect(element().textContent).toContain('Cargando existencias...');
    expect(element().querySelector('.stock-panel')?.getAttribute('aria-busy')).toBe('true');
    expect((element().querySelector('input[type="search"]') as HTMLInputElement).disabled).toBe(
      true,
    );
    expect(tarjeta('Agotados').disabled).toBe(true);
    // El ajuste real carga sus propios datos: se puede abrir aunque la tabla siga cargando.
    expect(element().querySelector<HTMLButtonElement>('.discount-action')!.disabled).toBe(false);
  });

  it('lists each item with its type, quantity, minimum, unit, branch and state', async () => {
    service.listarExistencias.mockReturnValue(of([cafe, agua]));
    await render();

    const [primera, segunda] = filas().map((fila) =>
      Array.from(fila.querySelectorAll('td'))
        .slice(0, 7)
        .map((celda) => celda.textContent?.replace(/\s+/g, ' ').trim()),
    );
    expect(primera).toEqual([
      'Café en grano',
      'Materia prima',
      '4,25',
      '2',
      'kg',
      'Nury Providencia',
      'Estable',
    ]);
    expect(segunda).toEqual([
      'Agua mineral 500 ml',
      'Producto',
      '-2',
      '12',
      'un',
      'Nury Ñuñoa',
      'Agotado Descuadre Faltan 14 un para el mínimo',
    ]);
    expect(element().querySelector('.record-count')?.textContent).toContain('2 registros');
    expect(element().querySelector('.connection')?.textContent).toContain('En línea');
  });

  it('marks out-of-stock and critical rows and counts each state', async () => {
    service.listarExistencias.mockReturnValue(of([cafe, azucar, agua]));
    await render();

    expect(filas().map((fila) => fila.className)).toEqual([
      'state-estable',
      'state-critico',
      'state-agotado',
    ]);
    expect(tarjeta('Agotados').textContent).toContain('1');
    expect(tarjeta('Críticos').textContent).toContain('1');
    expect(tarjeta('Estables').textContent).toContain('1');
  });

  it('shows a visible alert for out-of-stock and critical items of the queried branch', async () => {
    service.listarExistencias.mockReturnValue(of([cafe, azucar, agua]));
    await render();

    expect(element().querySelector('.stock-alert')?.textContent).toContain(
      '1 artículo agotado y 1 en estado crítico.',
    );

    cambiar('select[aria-label="Filtrar por sucursal"]', '1');
    expect(element().querySelector('.stock-alert')?.textContent).toContain(
      '1 en estado crítico en Nury Providencia.',
    );

    click('.stock-alert .secondary-button');
    expect(articulos()).toEqual(['Azúcar']);
    expect(element().querySelector('.stock-alert .secondary-button')).toBeNull();
  });

  it('flags negative stock as a mismatch, separate from zero stock', async () => {
    const sinStock = { ...azucar, id: 'sin-stock', articulo: 'Galletas de avena', cantidad: 0 };
    service.listarExistencias.mockReturnValue(of([cafe, sinStock, agua]));
    await render();

    const descuadres = filas().map((fila) => !!fila.querySelector('.mismatch-badge'));
    expect(articulos()).toEqual(['Café en grano', 'Galletas de avena', 'Agua mineral 500 ml']);
    expect(descuadres).toEqual([false, false, true]);
    expect(filas()[2].querySelector('.mismatch-badge')?.getAttribute('title')).toBe(
      'Se vendió más de lo registrado: revisa compras o conteos pendientes.',
    );
    expect(element().querySelector('.mismatch-note')?.textContent).toContain(
      'Hay 1 artículo con stock negativo (descuadre)',
    );

    cambiar('select[aria-label="Filtrar por sucursal"]', '1');
    expect(element().querySelector('.stock-alert')?.textContent).toContain('1 artículo agotado');
    expect(element().querySelector('.mismatch-note')).toBeNull();
  });

  it('filters only the items with a mismatch, from the select or the alert', async () => {
    const sinStock = { ...azucar, id: 'sin-stock', articulo: 'Galletas de avena', cantidad: 0 };
    service.listarExistencias.mockReturnValue(of([cafe, sinStock, agua]));
    await render();

    click('.mismatch-note .link-button');
    expect(articulos()).toEqual(['Agua mineral 500 ml']);
    expect(element().querySelector('.record-count')?.textContent?.trim()).toBe('1 registro');
    expect(
      element().querySelector<HTMLSelectElement>(
        'select[aria-label="Filtrar por estado de stock"]',
      )!.value,
    ).toBe('descuadre');
    expect(element().querySelector('.mismatch-note .link-button')).toBeNull();

    cambiar('select[aria-label="Filtrar por estado de stock"]', 'agotado');
    expect(articulos()).toEqual(['Galletas de avena', 'Agua mineral 500 ml']);

    cambiar('select[aria-label="Filtrar por estado de stock"]', 'descuadre');
    cambiar('select[aria-label="Filtrar por sucursal"]', '1');
    expect(filas()).toHaveLength(0);
    expect(element().querySelector('.empty-row')?.textContent).toContain(
      'No encontramos artículos que coincidan con los filtros.',
    );
  });

  it('hides the alert when every item is stable', async () => {
    service.listarExistencias.mockReturnValue(of([cafe]));
    await render();

    expect(element().querySelector('.stock-alert')).toBeNull();
  });

  it('combines the state filter with type and text filters', async () => {
    service.listarExistencias.mockReturnValue(of([cafe, azucar, agua]));
    await render();

    cambiar('select[aria-label="Filtrar por estado de stock"]', 'alertas');
    expect(articulos()).toEqual(['Azúcar', 'Agua mineral 500 ml']);

    cambiar('select[aria-label="Filtrar por tipo de artículo"]', 'materia_prima');
    expect(articulos()).toEqual(['Azúcar']);

    cambiar('select[aria-label="Filtrar por estado de stock"]', 'estable');
    cambiar('input[type="search"]', 'cafe', 'input');
    expect(articulos()).toEqual(['Café en grano']);
  });

  describe('combinable filters and visual alerts', () => {
    const leche: ExistenciaStock = {
      ...azucar,
      id: 'materia_prima-leche-1',
      articulo: 'Leche entera',
      cantidad: 0,
      stockMinimo: 3,
      unidad: 'l',
    };
    const galletas: ExistenciaStock = {
      ...cafe,
      id: 'producto-galletas-1',
      articulo: 'Galletas de avena',
      tipo: 'producto',
      cantidad: 3,
      stockMinimo: 10,
      unidad: 'un',
    };

    function opciones(etiqueta: string): string[] {
      const select = element().querySelector(`select[aria-label="${etiqueta}"]`)!;
      return Array.from(select.querySelectorAll('option')).map((opcion) =>
        opcion.textContent!.replace(/\s+/g, ' ').trim(),
      );
    }
    function chips(): string[] {
      return Array.from(element().querySelectorAll('.filter-chip')).map((chip) =>
        chip.textContent!.replace(/\s+/g, ' ').trim(),
      );
    }

    beforeEach(async () => {
      service.listarExistencias.mockReturnValue(of([cafe, azucar, leche, galletas, agua]));
      await render();
    });

    it('shows how many items each option leaves, given the other filters', () => {
      expect(opciones('Filtrar por estado de stock')).toEqual([
        'Todos los estados (5)',
        'Con alerta (4)',
        'Agotados (2)',
        'Con descuadre (1)',
        'Críticos (2)',
        'Estables (1)',
      ]);
      expect(opciones('Filtrar por tipo de artículo')).toEqual([
        'Todos los tipos (5)',
        'Productos (2)',
        'Materias primas (3)',
      ]);

      cambiar('select[aria-label="Filtrar por tipo de artículo"]', 'producto');
      expect(opciones('Filtrar por estado de stock')).toEqual([
        'Todos los estados (2)',
        'Con alerta (2)',
        'Agotados (1)',
        'Con descuadre (1)',
        'Críticos (1)',
        'Estables (0)',
      ]);

      cambiar('select[aria-label="Filtrar por estado de stock"]', 'critico');
      expect(opciones('Filtrar por tipo de artículo')).toEqual([
        'Todos los tipos (2)',
        'Productos (1)',
        'Materias primas (1)',
      ]);
      expect(articulos()).toEqual(['Galletas de avena']);
    });

    it('counts the summary cards with the type and text filters applied', () => {
      cambiar('select[aria-label="Filtrar por tipo de artículo"]', 'materia_prima');
      expect(tarjeta('Agotados').textContent).toContain('1');
      expect(tarjeta('Críticos').textContent).toContain('1');
      expect(tarjeta('Estables').textContent).toContain('1');

      tarjeta('Críticos').click();
      fixture.detectChanges();
      expect(articulos()).toEqual(['Azúcar']);
    });

    it('keeps the alert for the whole branch while other filters hide those items', () => {
      cambiar('select[aria-label="Filtrar por tipo de artículo"]', 'materia_prima');
      cambiar('input[type="search"]', 'cafe', 'input');

      expect(articulos()).toEqual(['Café en grano']);
      expect(element().querySelector('.stock-alert')?.textContent).toContain(
        '2 artículos agotados y 2 en estado crítico.',
      );
    });

    it('shows exactly the announced items when opening the alerts', () => {
      cambiar('select[aria-label="Filtrar por tipo de artículo"]', 'materia_prima');
      cambiar('input[type="search"]', 'cafe', 'input');
      cambiar('select[aria-label="Filtrar por estado de stock"]', 'alertas');
      // La lista filtrada esconde alertas que el aviso cuenta: el acceso sigue disponible.
      expect(articulos()).toEqual([]);

      click('.stock-alert .secondary-button');

      expect(element().querySelector('.stock-alert .secondary-button')).toBeNull();
      expect(articulos()).toEqual([
        'Azúcar',
        'Leche entera',
        'Galletas de avena',
        'Agua mineral 500 ml',
      ]);
      expect(
        element().querySelector<HTMLSelectElement>(
          'select[aria-label="Filtrar por tipo de artículo"]',
        )!.value,
      ).toBe('todos');
      expect(element().querySelector<HTMLInputElement>('input[type="search"]')!.value).toBe('');
    });

    it('keeps the queried branch when opening the alerts', () => {
      cambiar('select[aria-label="Filtrar por sucursal"]', '1');
      click('.stock-alert .secondary-button');

      expect(articulos()).toEqual(['Azúcar', 'Leche entera', 'Galletas de avena']);
    });

    it('lists the applied filters and removes them one by one', () => {
      expect(element().querySelector('.active-filters')).toBeNull();

      cambiar('input[type="search"]', 'a', 'input');
      cambiar('select[aria-label="Filtrar por estado de stock"]', 'alertas');
      cambiar('select[aria-label="Filtrar por tipo de artículo"]', 'materia_prima');
      cambiar('select[aria-label="Filtrar por sucursal"]', '1');

      expect(chips()).toEqual(['“a”×', 'Con alerta×', 'Materias primas×', 'Nury Providencia×']);
      expect(element().querySelector('.active-filters-summary')?.textContent).toContain(
        'Mostrando 2 de 5 registros',
      );
      expect(articulos()).toEqual(['Azúcar', 'Leche entera']);

      click('.filter-chip[aria-label="Quitar filtro Materias primas"]');
      expect(chips()).toEqual(['“a”×', 'Con alerta×', 'Nury Providencia×']);
      expect(articulos()).toEqual(['Azúcar', 'Leche entera', 'Galletas de avena']);
      expect(
        element().querySelector<HTMLSelectElement>(
          'select[aria-label="Filtrar por tipo de artículo"]',
        )!.value,
      ).toBe('todos');

      click('.clear-filters');
      expect(element().querySelector('.active-filters')).toBeNull();
      expect(filas()).toHaveLength(5);
    });

    it('colors the alert by its most severe state', async () => {
      expect(element().querySelector('.stock-alert')?.classList).toContain('state-agotado');

      service.listarExistencias.mockReturnValue(of([cafe, azucar]));
      TestBed.resetTestingModule();
      await render();
      expect(element().querySelector('.stock-alert')?.classList).toContain('state-critico');
    });

    it('shows how much is missing to reach the minimum only on alert rows', () => {
      const faltantes = filas().map(
        (fila) => fila.querySelector('.shortfall')?.textContent?.trim() ?? null,
      );

      expect(faltantes).toEqual([
        null,
        'Faltan 0,4 kg para el mínimo',
        'Faltan 3 l para el mínimo',
        'Faltan 7 un para el mínimo',
        'Faltan 14 un para el mínimo',
      ]);
    });

    it('does not show a shortfall when the minimum is zero, even with negative stock', async () => {
      const empanada: ExistenciaStock = { ...agua, id: 'producto-pino-1', stockMinimo: 0 };
      service.listarExistencias.mockReturnValue(of([empanada]));
      TestBed.resetTestingModule();
      await render();

      expect(filas()[0].querySelector('.mismatch-badge')).not.toBeNull();
      expect(filas()[0].querySelector('.shortfall')).toBeNull();
    });

    it('removes the alert of an item that returns to stable', () => {
      cambiar('select[aria-label="Filtrar por estado de stock"]', 'critico');
      abrirEdicion('Azúcar');
      cambiar('.minimum-modal input', '0,5', 'input');
      click('.minimum-modal button[type="submit"]');

      expect(articulos()).toEqual(['Galletas de avena']);
      expect(opciones('Filtrar por estado de stock')).toContain('Críticos (1)');
      expect(element().querySelector('.stock-alert')?.textContent).toContain(
        '2 artículos agotados y 1 en estado crítico.',
      );
    });

    it('keeps an item without stock out of stock when its minimum is set to zero', () => {
      abrirEdicion('Leche entera');
      cambiar('.minimum-modal input', '0', 'input');
      expect(modal()?.querySelector('.state-preview')?.textContent).toContain('Agotado');
      click('.minimum-modal button[type="submit"]');

      const leche = filas().find((fila) => fila.cells[0].textContent?.trim() === 'Leche entera')!;
      expect(leche.className).toBe('state-agotado');
      expect(leche.querySelector('.shortfall')).toBeNull();
      expect(element().querySelector('.stock-alert')?.textContent).toContain(
        '2 artículos agotados y 2 en estado crítico.',
      );
    });
  });

  it('toggles the state filter from the summary cards', async () => {
    service.listarExistencias.mockReturnValue(of([cafe, azucar, agua]));
    await render();

    tarjeta('Agotados').click();
    fixture.detectChanges();
    expect(articulos()).toEqual(['Agua mineral 500 ml']);
    expect(tarjeta('Agotados').getAttribute('aria-pressed')).toBe('true');

    tarjeta('Agotados').click();
    fixture.detectChanges();
    expect(filas()).toHaveLength(3);
  });

  it('shows an empty state when there is no stock', async () => {
    service.listarExistencias.mockReturnValue(of([]));
    await render();

    expect(filas()).toHaveLength(0);
    expect(element().textContent).toContain('Aún no hay existencias registradas.');
  });

  it('explains the empty list to a storekeeper without an assigned branch', async () => {
    usuarioActual = { nombre: 'Rocío Fuentes', rol: 'bodeguero', sucursalId: null };
    service.listarExistencias.mockReturnValue(of([]));
    await render();

    expect(element().textContent).toContain('Tu usuario no tiene una sucursal asignada.');
    expect(element().textContent).not.toContain('Aún no hay existencias registradas.');
  });

  it.each([
    [{ rol: 'bodeguero', sucursalId: 3, sucursalNombre: 'Nury Vitacura' }, 'de Nury Vitacura.'],
    [
      { rol: 'admin', sucursalId: 1, sucursalNombre: 'Nury Providencia' },
      'en todas las sucursales.',
    ],
    [{ rol: 'bodeguero', sucursalId: null, sucursalNombre: '' }, 'de tu sucursal.'],
  ] as const)('names the branches being consulted in the header (%o)', async (usuario, texto) => {
    usuarioActual = { nombre: 'Rocío Fuentes', ...usuario };
    service.listarExistencias.mockReturnValue(of([]));
    await render();

    expect(element().querySelector('.page-header p')?.textContent).toBe(
      `Existencias de productos y materias primas ${texto}`,
    );
  });

  it('no longer labels the stock as sample data', async () => {
    service.listarExistencias.mockReturnValue(of([cafe]));
    await render();

    expect(element().querySelector('.stock-panel .sample-badge')).toBeNull();
  });

  it('shows an error with a retry that reloads the stock', async () => {
    service.listarExistencias.mockReturnValue(throwError(() => new Error('offline')));
    await render();

    expect(element().querySelector('.error-row [role="alert"]')?.textContent).toContain(
      'No pudimos cargar las existencias',
    );

    service.listarExistencias.mockReturnValue(of([cafe]));
    click('.error-row button');

    expect(service.listarExistencias).toHaveBeenCalledTimes(2);
    expect(filas()).toHaveLength(1);
  });

  describe('connection loss and recovery', () => {
    function conexion(evento: 'online' | 'offline'): void {
      window.dispatchEvent(new Event(evento));
      fixture.detectChanges();
    }
    function texto(selector: string): string {
      return (element().querySelector(selector)?.textContent ?? '').replace(/\s+/g, ' ').trim();
    }

    it('keeps the last data visible and warns when the connection is lost', async () => {
      service.listarExistencias.mockReturnValue(of([cafe]));
      await render();
      expect(texto('.connection')).toMatch(/^En línea Actualizado a las \d{2}:\d{2}$/);

      conexion('offline');

      expect(texto('.connection')).toMatch(/^Sin conexión Último dato a las \d{2}:\d{2}$/);
      expect(element().querySelector('.connection')?.classList).toContain('offline');
      expect(texto('.offline-banner')).toContain('Se perdió la conexión con el servidor.');
      expect(element().querySelector('.table-container')?.classList).toContain('stale');
      expect(filas()).toHaveLength(1);
      expect(service.listarExistencias).toHaveBeenCalledTimes(1);
    });

    it('consults the stock again on reconnect without hiding the last data', async () => {
      service.listarExistencias.mockReturnValue(of([cafe]));
      await render();
      conexion('offline');

      const respuesta = new Subject<ExistenciaStock[]>();
      service.listarExistencias.mockReturnValue(respuesta);
      conexion('online');

      expect(service.listarExistencias).toHaveBeenCalledTimes(2);
      expect(texto('.connection strong')).toBe('Actualizando...');
      expect(element().querySelector('.connection')?.classList).toContain('syncing');
      expect(element().querySelector('.offline-banner')).toBeNull();
      expect(element().querySelector('.skeleton-row')).toBeNull();
      expect(filas()[0].cells[2].textContent?.trim()).toBe('4,25');
      const tabla = element().querySelector('.table-container')!;
      expect(tabla.classList).toContain('stale');
      expect(tabla.getAttribute('aria-busy')).toBe('true');

      respuesta.next([{ ...cafe, cantidad: 3 }]);
      respuesta.complete();
      fixture.detectChanges();

      expect(texto('.connection')).toMatch(/^En línea Actualizado a las/);
      expect(tabla.classList).not.toContain('stale');
      expect(tabla.getAttribute('aria-busy')).toBe('false');
      expect(filas()[0].cells[2].textContent?.trim()).toBe('3');
    });

    it('warns and offers a retry when the update after reconnecting fails', async () => {
      service.listarExistencias.mockReturnValue(of([cafe]));
      await render();
      conexion('offline');

      service.listarExistencias.mockReturnValue(throwError(() => new Error('502')));
      conexion('online');

      expect(texto('.connection strong')).toBe('Datos sin actualizar');
      expect(texto('.offline-banner.pending')).toContain(
        'Volvió la conexión, pero no pudimos actualizar las existencias.',
      );
      expect(element().querySelector('.table-container')?.classList).toContain('stale');
      expect(filas()).toHaveLength(1);

      service.listarExistencias.mockReturnValue(of([cafe, azucar]));
      click('.offline-banner.pending button');

      expect(element().querySelector('.offline-banner')).toBeNull();
      expect(texto('.connection strong')).toBe('En línea');
      expect(filas()).toHaveLength(2);
    });

    it('loads the stock again on reconnect when the first load failed', async () => {
      service.listarExistencias.mockReturnValue(throwError(() => new Error('offline')));
      await render();
      conexion('offline');

      service.listarExistencias.mockReturnValue(of([cafe]));
      conexion('online');

      expect(element().querySelector('.error-row')).toBeNull();
      expect(filas()).toHaveLength(1);
    });

    it('ignores a late answer from a previous reconnection', async () => {
      service.listarExistencias.mockReturnValue(of([cafe]));
      await render();

      const primera = new Subject<ExistenciaStock[]>();
      const segunda = new Subject<ExistenciaStock[]>();
      service.listarExistencias.mockReturnValueOnce(primera).mockReturnValueOnce(segunda);
      conexion('offline');
      conexion('online');
      conexion('offline');
      conexion('online');

      segunda.next([{ ...cafe, cantidad: 2 }]);
      primera.next([{ ...cafe, cantidad: 9 }]);
      fixture.detectChanges();

      expect(filas()[0].cells[2].textContent?.trim()).toBe('2');
    });

    it('consults the waste report again on reconnect', async () => {
      service.listarExistencias.mockReturnValue(of([cafe]));
      await render();
      element().querySelector<HTMLButtonElement>('#tab-mermas')!.click();
      fixture.detectChanges();
      await fixture.whenStable();
      const consultas = service.listarMermas.mock.calls.length;

      conexion('offline');
      conexion('online');
      await fixture.whenStable();

      expect(service.listarMermas.mock.calls.length).toBe(consultas + 1);
    });
  });

  it('filters by text without accents, by type and by branch', async () => {
    service.listarExistencias.mockReturnValue(of([cafe, agua]));
    await render();

    cambiar('input[type="search"]', 'cafe', 'input');
    expect(filas()).toHaveLength(1);

    cambiar('input[type="search"]', '', 'input');
    cambiar('select[aria-label="Filtrar por tipo de artículo"]', 'producto');
    expect(articulos()).toEqual(['Agua mineral 500 ml']);

    cambiar('select[aria-label="Filtrar por tipo de artículo"]', 'todos');
    cambiar('select[aria-label="Filtrar por sucursal"]', '1');
    expect(articulos()).toEqual(['Café en grano']);
  });

  it('offers to clear the filters when nothing matches', async () => {
    service.listarExistencias.mockReturnValue(of([cafe, agua]));
    await render();

    cambiar('select[aria-label="Filtrar por estado de stock"]', 'critico');
    expect(element().textContent).toContain(
      'No encontramos artículos que coincidan con los filtros.',
    );

    click('.empty-row button');
    expect(filas()).toHaveLength(2);
  });

  it('hides the branch filter when there is only one branch', async () => {
    service.listarExistencias.mockReturnValue(of([cafe]));
    await render();

    expect(element().querySelector('select[aria-label="Filtrar por sucursal"]')).toBeNull();
  });

  describe('same item in several branches', () => {
    const cafeNunoa: ExistenciaStock = {
      ...cafe,
      id: 'materia_prima-cafe-2',
      cantidad: 1.8,
      sucursalId: 2,
      sucursal: 'Nury Ñuñoa',
    };
    function sucursalesDeFilas(): (string | undefined)[] {
      return filas().map((fila) => fila.cells[5].textContent?.trim());
    }

    beforeEach(async () => {
      usuarioActual = { nombre: 'Rocío Fuentes', rol: 'admin', sucursalId: 1 };
      service.listarExistencias.mockReturnValue(of([cafe, cafeNunoa]));
      await render();
    });

    it('shows the state, alert and counts of each branch separately', () => {
      expect(sucursalesDeFilas()).toEqual(['Nury Providencia', 'Nury Ñuñoa']);
      expect(filas().map((fila) => fila.className)).toEqual(['state-estable', 'state-critico']);
      expect(element().querySelector('.stock-alert')?.textContent).toContain(
        '1 en estado crítico.',
      );

      cambiar('select[aria-label="Filtrar por sucursal"]', '1');
      expect(sucursalesDeFilas()).toEqual(['Nury Providencia']);
      expect(tarjeta('Críticos').textContent).toContain('0');
      expect(tarjeta('Estables').textContent).toContain('1');
      expect(element().querySelector('.stock-alert')).toBeNull();

      cambiar('select[aria-label="Filtrar por sucursal"]', '2');
      expect(sucursalesDeFilas()).toEqual(['Nury Ñuñoa']);
      expect(tarjeta('Críticos').textContent).toContain('1');
      expect(tarjeta('Estables').textContent).toContain('0');
      expect(element().querySelector('.stock-alert')?.textContent).toContain(
        '1 en estado crítico en Nury Ñuñoa.',
      );
    });

    it('changes the minimum only in the branch of the edited row', () => {
      click('.edit-button[aria-label="Editar mínimo de Café en grano en Nury Ñuñoa"]');
      expect(modal()?.textContent).toContain('Nury Ñuñoa');
      cambiar('[role="dialog"] input', '1,8', 'input');
      click('[role="dialog"] button[type="submit"]');

      expect(service.actualizarMinimo).toHaveBeenCalledWith(cafeNunoa, 1.8);
      expect(filas().map((fila) => fila.querySelector('.minimum')?.textContent?.trim())).toEqual([
        '2',
        '1,8',
      ]);
      // Stock igual al mínimo queda estable: la alerta de Ñuñoa desaparece.
      expect(filas().map((fila) => fila.className)).toEqual(['state-estable', 'state-estable']);
      expect(element().querySelector('.stock-alert')).toBeNull();
    });
  });

  describe('minimum edition', () => {
    beforeEach(async () => {
      service.listarExistencias.mockReturnValue(of([cafe, azucar]));
      await render();
    });

    it('opens with the current stock, state and minimum of the item', () => {
      abrirEdicion('Azúcar');

      expect(modal()?.textContent).toContain('Nury Providencia');
      expect(modal()?.textContent).toContain('0,6 kg');
      expect(modal()?.querySelector('.current-stock .state-badge')?.textContent).toContain(
        'Crítico',
      );
      expect(modal()?.querySelector<HTMLInputElement>('input')?.value).toBe('1');
    });

    it.each([
      ['', 'Ingresa el stock mínimo.'],
      ['   ', 'Ingresa el stock mínimo.'],
      ['-1', 'El mínimo no puede ser negativo.'],
      ['-0,5', 'El mínimo no puede ser negativo.'],
      ['abc', 'Ingresa un número válido, por ejemplo 2 o 1,5.'],
      ['1e3', 'Ingresa un número válido, por ejemplo 2 o 1,5.'],
      ['1,2345', 'Usa como máximo 3 decimales.'],
      ['1000000000', 'El mínimo es demasiado grande.'],
    ])('rejects %j with "%s"', (valor, mensaje) => {
      abrirEdicion('Azúcar');
      cambiar('[role="dialog"] input', valor, 'input');
      click('[role="dialog"] button[type="submit"]');

      expect(modal()?.querySelector('.field-error')?.textContent).toContain(mensaje);
      expect(modal()?.querySelector('input')?.getAttribute('aria-invalid')).toBe('true');
      expect(service.actualizarMinimo).not.toHaveBeenCalled();
    });

    it('previews the resulting state before saving', () => {
      abrirEdicion('Azúcar');
      cambiar('[role="dialog"] input', '0,5', 'input');

      expect(modal()?.querySelector('.state-preview')?.textContent).toContain('Estable');
    });

    it('saves a decimal minimum with comma, recalculates the state and confirms', () => {
      abrirEdicion('Azúcar');
      cambiar('[role="dialog"] input', '0,5', 'input');
      click('[role="dialog"] button[type="submit"]');

      expect(service.actualizarMinimo).toHaveBeenCalledWith(azucar, 0.5);
      expect(modal()).toBeNull();
      expect(element().querySelector('.success-feedback')?.textContent).toContain(
        'Mínimo de Azúcar en Nury Providencia actualizado a 0,5 kg.',
      );
      expect(filas()[1].className).toBe('state-estable');
      expect(element().querySelector('.stock-alert')).toBeNull();
    });

    it('accepts zero as a valid minimum', () => {
      abrirEdicion('Café en grano');
      cambiar('[role="dialog"] input', '0', 'input');
      click('[role="dialog"] button[type="submit"]');

      expect(service.actualizarMinimo).toHaveBeenCalledWith(cafe, 0);
    });

    it.each([
      ['1.5', 1.5],
      [' 2 ', 2],
      ['1,125', 1.125],
      ['999999999,999', 999_999_999.999],
    ])('accepts %j and saves %s', (valor, minimo) => {
      abrirEdicion('Azúcar');
      cambiar('[role="dialog"] input', valor, 'input');
      click('[role="dialog"] button[type="submit"]');

      expect(service.actualizarMinimo).toHaveBeenCalledWith(azucar, minimo);
      expect(modal()).toBeNull();
    });

    it('keeps the modal open with an error when saving fails', () => {
      service.actualizarMinimo.mockReturnValue(throwError(() => new Error('offline')));
      abrirEdicion('Azúcar');
      cambiar('[role="dialog"] input', '2', 'input');
      click('[role="dialog"] button[type="submit"]');

      expect(modal()?.querySelector('.error-feedback')?.textContent).toContain(
        'No pudimos guardar el mínimo',
      );
      expect(filas()[1].querySelector('.minimum')?.textContent?.trim()).toBe('1');
    });

    it('explains a permission error from the server', () => {
      service.actualizarMinimo.mockReturnValue(
        throwError(() => new HttpErrorResponse({ status: 403, error: { code: '42501' } })),
      );
      abrirEdicion('Azúcar');
      cambiar('[role="dialog"] input', '2', 'input');
      click('[role="dialog"] button[type="submit"]');

      expect(modal()?.querySelector('.error-feedback')?.textContent).toContain(
        'Tu usuario no tiene permiso para cambiar mínimos de stock. El mínimo no se modificó.',
      );
      expect(service.listarExistencias).toHaveBeenCalledTimes(1);
    });

    it('refreshes the stock when the row no longer exists', () => {
      service.actualizarMinimo.mockReturnValue(throwError(() => new MinimoSinFilaError()));
      abrirEdicion('Azúcar');
      cambiar('[role="dialog"] input', '2', 'input');
      click('[role="dialog"] button[type="submit"]');

      expect(modal()?.querySelector('.error-feedback')?.textContent).toContain(
        'ya no tiene stock registrado en esa sucursal',
      );
      expect(service.listarExistencias).toHaveBeenCalledTimes(2);
    });

    it('closes without saving on cancel or Escape', () => {
      abrirEdicion('Azúcar');
      click('[role="dialog"] .secondary-button');
      expect(modal()).toBeNull();

      abrirEdicion('Azúcar');
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape' }));
      fixture.detectChanges();
      expect(modal()).toBeNull();
      expect(service.actualizarMinimo).not.toHaveBeenCalled();
    });
  });

  describe('stock adjustment and waste', () => {
    function botonAjustar(articulo: string, sucursal = 'Nury Providencia'): HTMLButtonElement {
      const fila = filas().find(
        (f) => f.cells[0].textContent?.trim() === articulo && f.textContent?.includes(sucursal),
      )!;
      return fila.querySelector<HTMLButtonElement>('.discount-button')!;
    }
    function ajusteReal(): AjusteInventario | null {
      return fixture.debugElement.query(By.directive(AjusteInventario))?.componentInstance ?? null;
    }
    function pestana(nombre: string): HTMLButtonElement {
      return Array.from(element().querySelectorAll<HTMLButtonElement>('[role="tab"]')).find((tab) =>
        tab.textContent?.includes(nombre),
      )!;
    }

    beforeEach(async () => {
      service.listarExistencias.mockReturnValue(of([cafe, azucar, agua]));
      await render();
    });

    it('offers to adjust every item, also the ones without stock', () => {
      expect(botonAjustar('Café en grano').disabled).toBe(false);
      expect(botonAjustar('Agua mineral 500 ml', 'Nury Ñuñoa').disabled).toBe(false);
      expect(botonAjustar('Agua mineral 500 ml', 'Nury Ñuñoa').getAttribute('aria-label')).toBe(
        'Ajustar stock de Agua mineral 500 ml en Nury Ñuñoa',
      );
      expect(element().querySelector('[role="tab"]#tab-ajuste')).toBeNull();
    });

    it('opens the real adjustment as a modal with the item and branch of the row', () => {
      expect(ajusteReal()).toBeNull();
      botonAjustar('Café en grano').click();
      fixture.detectChanges();

      expect(ajusteReal()).not.toBeNull();
      expect(ajusteReal()!.preseleccion()).toEqual({
        tipo: 'ingrediente',
        sucursalId: 1,
        nombre: 'Café en grano',
      });
      expect(element().querySelector('app-ajuste-inventario [role="dialog"]')).not.toBeNull();
    });

    it('opens the general adjustment on the branch selected in the panel', () => {
      cambiar('select[aria-label="Filtrar por sucursal"]', '2');
      click('.discount-action');

      expect(ajusteReal()!.preseleccion()).toEqual({
        tipo: 'producto',
        sucursalId: 2,
        nombre: null,
      });
    });

    it('closes the modal, shows the result and refreshes the stock after an adjustment', () => {
      const llamadas = service.listarExistencias.mock.calls.length;
      click('.discount-action');
      ajusteReal()!.ajustado.emit('Ajuste aplicado a CHAPARRITA: +20 unid.');
      fixture.detectChanges();

      expect(ajusteReal()).toBeNull();
      expect(element().querySelector('.success-feedback')?.textContent).toContain(
        'Ajuste aplicado a CHAPARRITA: +20 unid.',
      );
      expect(service.listarExistencias).toHaveBeenCalledTimes(llamadas + 1);
    });

    it('closes the modal without changes when it is cancelled', () => {
      click('.discount-action');
      ajusteReal()!.cerrar.emit();
      fixture.detectChanges();

      expect(ajusteReal()).toBeNull();
      expect(element().querySelector('.success-feedback')).toBeNull();
      expect(filas()[0].cells[2].textContent?.trim()).toBe('4,25');
    });

    it('switches to the waste report in the branch selected in the panel', async () => {
      cambiar('select[aria-label="Filtrar por sucursal"]', '1');
      pestana('Mermas y ajustes').click();
      fixture.detectChanges();
      await fixture.whenStable();

      expect(pestana('Mermas y ajustes').getAttribute('aria-selected')).toBe('true');
      expect(pestana('Existencias').getAttribute('aria-selected')).toBe('false');
      expect(element().querySelector('.stock-panel')).toBeNull();
      expect(element().querySelector('app-reporte-mermas')).not.toBeNull();
      expect(service.listarMermas).toHaveBeenCalledWith(expect.objectContaining({ sucursalId: 1 }));

      pestana('Existencias').click();
      fixture.detectChanges();
      expect(element().querySelector('.stock-panel')).not.toBeNull();
    });
  });

  describe('H3.4 T09: actualización, tiempo de respuesta y separación entre sucursales', () => {
    const cafeNunoa: ExistenciaStock = {
      ...cafe,
      id: 'materia_prima-cafe-2',
      cantidad: 1.5,
      stockMinimo: 3,
      sucursalId: 2,
      sucursal: 'Nury Ñuñoa',
    };
    function fila(articulo: string, sucursal: string): HTMLTableRowElement {
      return filas().find(
        (f) => f.cells[0].textContent?.trim() === articulo && f.textContent?.includes(sucursal),
      )!;
    }
    function textoConexion(): string {
      return (element().querySelector('.connection')?.textContent ?? '').replace(/\s+/g, ' ');
    }

    afterEach(() => vi.useRealTimers());

    it('shows the time of the last update and renews it when the stock is consulted again', async () => {
      vi.useFakeTimers({ toFake: ['Date'] });
      vi.setSystemTime(new Date(2026, 9, 16, 10, 15));
      service.listarExistencias.mockReturnValue(of([cafe]));
      await render();
      expect(textoConexion()).toContain('Actualizado a las 10:15');

      vi.setSystemTime(new Date(2026, 9, 16, 10, 42));
      service.listarExistencias.mockReturnValue(of([{ ...cafe, cantidad: 3 }]));
      click('.discount-action');
      fixture.debugElement
        .query(By.directive(AjusteInventario))
        .componentInstance.ajustado.emit('Ajuste aplicado');
      fixture.detectChanges();

      expect(textoConexion()).toContain('Actualizado a las 10:42');
      expect(fila('Café en grano', 'Nury Providencia').cells[2].textContent?.trim()).toBe('3');
    });

    it('keeps the loading state while the answer is pending and shows the data as soon as it arrives', async () => {
      const respuesta = new Subject<ExistenciaStock[]>();
      service.listarExistencias.mockReturnValue(respuesta);
      await render();
      expect(element().querySelectorAll('.skeleton-row').length).toBeGreaterThan(0);
      expect(filas()).toHaveLength(0);

      respuesta.next([cafe, agua]);
      fixture.detectChanges();

      expect(element().querySelectorAll('.skeleton-row')).toHaveLength(0);
      expect(filas()).toHaveLength(2);
      expect(element().querySelector('.stock-panel')?.getAttribute('aria-busy')).toBe('false');
      expect(service.listarExistencias).toHaveBeenCalledTimes(1);
    });

    it('lists the same item once per branch, each with its own quantity, minimum and state', async () => {
      service.listarExistencias.mockReturnValue(of([cafe, cafeNunoa]));
      await render();

      const providencia = fila('Café en grano', 'Nury Providencia');
      const nunoa = fila('Café en grano', 'Nury Ñuñoa');
      expect(providencia.cells[2].textContent?.trim()).toBe('4,25');
      expect(nunoa.cells[2].textContent?.trim()).toBe('1,5');
      expect(providencia.className).toBe('state-estable');
      expect(nunoa.className).toBe('state-critico');
    });

    it('shows and counts only the items of the selected branch', async () => {
      service.listarExistencias.mockReturnValue(of([cafe, cafeNunoa, azucar, agua]));
      await render();

      cambiar('select[aria-label="Filtrar por sucursal"]', '2');
      expect(filas().every((f) => f.textContent?.includes('Nury Ñuñoa'))).toBe(true);
      expect(articulos()).toEqual(['Café en grano', 'Agua mineral 500 ml']);
      expect(tarjeta('Críticos').textContent).toContain('1');
      expect(tarjeta('Agotados').textContent).toContain('1');

      cambiar('select[aria-label="Filtrar por sucursal"]', '1');
      expect(filas().every((f) => f.textContent?.includes('Nury Providencia'))).toBe(true);
      expect(articulos()).toEqual(['Café en grano', 'Azúcar']);
    });

    it('changes the minimum only in the branch of the edited row', async () => {
      service.listarExistencias.mockReturnValue(of([cafe, cafeNunoa]));
      await render();

      fila('Café en grano', 'Nury Ñuñoa').querySelector<HTMLButtonElement>('.edit-button')!.click();
      fixture.detectChanges();
      cambiar('[role="dialog"] input', '1', 'input');
      click('[role="dialog"] button[type="submit"]');

      expect(service.actualizarMinimo).toHaveBeenCalledWith(cafeNunoa, 1);
      expect(fila('Café en grano', 'Nury Ñuñoa').className).toBe('state-estable');
      expect(
        fila('Café en grano', 'Nury Providencia').querySelector('.minimum')?.textContent?.trim(),
      ).toBe('2');
    });

    it('opens the stock adjustment on the branch of the row, not on another one', async () => {
      service.listarExistencias.mockReturnValue(of([cafe, cafeNunoa]));
      await render();

      fila('Café en grano', 'Nury Ñuñoa')
        .querySelector<HTMLButtonElement>('.discount-button')!
        .click();
      fixture.detectChanges();

      expect(
        fixture.debugElement.query(By.directive(AjusteInventario)).componentInstance.preseleccion(),
      ).toEqual({ tipo: 'ingrediente', sucursalId: 2, nombre: 'Café en grano' });
    });
  });

  it('opens the movement history of a row in its branch (H3.2 T01)', async () => {
    service.listarExistencias.mockReturnValue(of([cafe]));
    await render([{ provide: MovimientosService, useValue: { listar: movimientos } }]);

    click(`[aria-label="Movimientos de ${cafe.articulo} en ${cafe.sucursal}"]`);

    expect(movimientos).toHaveBeenCalledWith(cafe.tipo, cafe.articuloId, cafe.sucursalId);
    expect(element().querySelector('#movements-title')?.textContent).toContain(cafe.articulo);
    click('.movements-panel .close-button');
    expect(element().querySelector('app-movimientos-articulo')).toBeNull();
  });

  it('has only Existencias and Mermas: ingredients moved to the Product Master', async () => {
    service.listarExistencias.mockReturnValue(of([]));
    await render();

    const pestanas = Array.from(element().querySelectorAll('[role="tab"]')).map((tab) =>
      tab.textContent?.trim(),
    );
    expect(pestanas).toEqual(['Existencias', 'Mermas y ajustes']);
    expect(element().querySelector('#tab-catalogo')).toBeNull();
  });

  describe('tab in the URL (H3.3 T04)', () => {
    const router = { navigate: vi.fn().mockResolvedValue(true) };
    function conVista(vista: string | null): Provider[] {
      const ruta = { snapshot: { queryParamMap: convertToParamMap(vista ? { vista } : {}) } };
      return [
        { provide: ActivatedRoute, useValue: ruta },
        { provide: Router, useValue: router },
      ];
    }

    beforeEach(() => router.navigate.mockClear());

    it('accepts only known tabs', () => {
      expect(vistaDesdeUrl('mermas')).toBe('mermas');
      expect(vistaDesdeUrl('catalogo')).toBe('existencias');
      expect(vistaDesdeUrl('ingredientes')).toBe('existencias');
      expect(vistaDesdeUrl(null)).toBe('existencias');
    });

    it('opens Mermas directly with ?vista=mermas', async () => {
      service.listarExistencias.mockReturnValue(of([]));
      service.listarMermas.mockReturnValue(of([]));
      await render(conVista('mermas'));

      expect(element().querySelector('#tab-mermas')?.getAttribute('aria-selected')).toBe('true');
    });

    it('keeps the chosen tab in the URL without adding history', async () => {
      service.listarExistencias.mockReturnValue(of([]));
      await render(conVista(null));

      click('#tab-mermas');
      expect(router.navigate).toHaveBeenLastCalledWith(
        [],
        expect.objectContaining({ queryParams: { vista: 'mermas' }, replaceUrl: true }),
      );
      click('#tab-existencias');
      expect(router.navigate).toHaveBeenLastCalledWith(
        [],
        expect.objectContaining({ queryParams: { vista: null } }),
      );
    });
  });

  describe('automatic refresh without reloading (H3.2 T06)', () => {
    let version: { stock: string; movimientos: number };

    beforeEach(() => {
      vi.useFakeTimers();
      version = { stock: 'v1', movimientos: 10 };
      service.versionInventario.mockImplementation(() => of(version));
      service.listarExistencias.mockReturnValue(of([cafe]));
    });
    afterEach(() => {
      vi.useRealTimers();
      service.versionInventario.mockImplementation(() => of({ stock: 'inicial', movimientos: 1 }));
    });

    async function avanzar(ms: number): Promise<void> {
      await vi.advanceTimersByTimeAsync(ms);
      fixture.detectChanges();
    }

    it('checks every 2 s and reloads the stock only when it changed', async () => {
      await render();
      await avanzar(0);
      const cargasIniciales = service.listarExistencias.mock.calls.length;

      await avanzar(INTERVALO_REVISION_MS * 3);
      expect(service.versionInventario.mock.calls.length).toBeGreaterThanOrEqual(4);
      expect(service.listarExistencias.mock.calls.length).toBe(cargasIniciales);

      // Una venta en el POS cambia el stock: aparece en el siguiente ciclo, sin recargar.
      version = { stock: 'v2', movimientos: 11 };
      service.listarExistencias.mockReturnValue(of([{ ...cafe, cantidad: 1.25 }]));
      await avanzar(INTERVALO_REVISION_MS);
      expect(service.listarExistencias.mock.calls.length).toBe(cargasIniciales + 1);
      expect(element().textContent).toContain('1,25');
    });

    it('also reloads when only a minimum changed (it affects the alerts)', async () => {
      await render();
      await avanzar(0);
      const cargas = service.listarExistencias.mock.calls.length;

      version = { stock: 'v2', movimientos: 10 };
      await avanzar(INTERVALO_REVISION_MS);
      expect(service.listarExistencias.mock.calls.length).toBe(cargas + 1);
    });

    it('stops while the tab is hidden and checks right away when it is visible again', async () => {
      await render();
      await avanzar(0);
      const visibilidad = vi.spyOn(document, 'visibilityState', 'get').mockReturnValue('hidden');
      document.dispatchEvent(new Event('visibilitychange'));
      const consultas = service.versionInventario.mock.calls.length;

      await avanzar(INTERVALO_REVISION_MS * 5);
      expect(service.versionInventario.mock.calls.length).toBe(consultas);

      visibilidad.mockReturnValue('visible');
      document.dispatchEvent(new Event('visibilitychange'));
      await avanzar(0);
      expect(service.versionInventario.mock.calls.length).toBe(consultas + 1);
      visibilidad.mockRestore();
    });

    it('keeps the data when a check fails and goes on checking', async () => {
      await render();
      await avanzar(0);
      const cargas = service.listarExistencias.mock.calls.length;
      service.versionInventario.mockImplementationOnce(() =>
        throwError(() => new Error('sin red')),
      );

      await avanzar(INTERVALO_REVISION_MS);
      expect(service.listarExistencias.mock.calls.length).toBe(cargas);
      expect(element().textContent).toContain('Café en grano');

      version = { stock: 'v3', movimientos: 12 };
      await avanzar(INTERVALO_REVISION_MS);
      expect(service.listarExistencias.mock.calls.length).toBe(cargas + 1);
    });
  });
});
