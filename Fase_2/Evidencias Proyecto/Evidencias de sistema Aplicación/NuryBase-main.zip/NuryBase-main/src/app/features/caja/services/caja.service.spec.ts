import { TestBed } from '@angular/core/testing';
import { NEVER, of } from 'rxjs';
import { ProductosApiService } from '../../../core/api/productos-api.service';
import { VentasApiService } from '../../../core/api/ventas-api.service';
import { TurnosApiService, TurnoApi } from '../../../core/api/turnos-api.service';
import { PosProduct } from '../../pos/models/pos.model';
import { PosService } from '../../pos/services/pos.service';
import { CajaService } from './caja.service';
import { CierreCaja } from '../models/caja.model';

const FAKE_TURNO: TurnoApi = {
  id: 1,
  usuario_id: 1,
  sucursal_id: 1,
  hora_inicio: new Date().toISOString(),
  hora_fin: null,
  creado_en: new Date().toISOString(),
  monto_inicial: 0,
};

/** La mayoría de las pruebas aquí mockean TurnosApiService con `of(...)`,
 * así que la Observable de cerrarTurno() emite de forma síncrona. */
function closeShift(caja: CajaService, ...args: Parameters<CajaService['cerrarTurno']>): CierreCaja {
  let result: CierreCaja | undefined;
  caja.cerrarTurno(...args).subscribe((cierre) => (result = cierre));
  if (!result) {
    throw new Error('cerrarTurno no emitió un resultado de forma síncrona en esta prueba.');
  }
  return result;
}

const TEST_PRODUCTS: PosProduct[] = [
  {
    id: 1,
    nombre: 'Café Espresso Doble',
    categoriaId: 'BEBESTIBLES - CAFÉ',
    categoriaNombre: 'Cafetería',
    codigoInterno: 'NUR-101',
    codigoBarras: '7801234501018',
    precioVenta: 2600,
    icono: '☕',
    descripcion: 'Producto exclusivo para pruebas.',
    activo: true,
  },
  {
    id: 2,
    nombre: 'Cappuccino Italiano',
    categoriaId: 'BEBESTIBLES - CAFÉ',
    categoriaNombre: 'Cafetería',
    codigoInterno: 'NUR-102',
    codigoBarras: '7801234501025',
    precioVenta: 3200,
    icono: '☕',
    descripcion: 'Producto exclusivo para pruebas.',
    activo: true,
  },
];

describe('CajaService', () => {
  function chargeSale(
    pos: PosService,
    productIndex: number,
    cantidad: number,
    medioPago: 'efectivo' | 'credito' | 'debito' | 'sodexo' | 'edenred'
  ) {
    for (let i = 0; i < cantidad; i++) {
      pos.addToCart(pos.catalog()[productIndex]);
    }
    return pos
      .completeSale(
        medioPago,
        pos.total(),
        { id: 1, nombre: 'Camila Rojas' },
        { id: 1, nombre: 'Sucursal Providencia' },
      )
      .subscribe();
  }

  beforeEach(() => {
    // Angular corre Vitest con `isolate: false`: todos los specs comparten el
    // mismo sessionStorage. Si otro spec dejó una sesión (`nury_session`) y un
    // turno con ventas (`nury_turno`) del mismo usuario, PosService los
    // restauraba aquí y el cierre veía ventas ajenas a la prueba.
    sessionStorage.clear();
    TestBed.configureTestingModule({
      providers: [
        { provide: ProductosApiService, useValue: { listar: () => NEVER } },
        { provide: VentasApiService, useValue: { registrar: () => of(999) } },
        { provide: TurnosApiService, useValue: { abrir: () => of(FAKE_TURNO), cerrar: () => of(FAKE_TURNO) } },
      ],
    });
    const pos = TestBed.inject(PosService);
    pos.catalog.set(TEST_PRODUCTS);
    pos.clearCart();
    // La mayoría de las pruebas de cierre asumen un turno ya abierto; la
    // prueba de "iniciarTurno" lo deja explícitamente cerrado antes.
    pos.turnoActivo.set(FAKE_TURNO);
  });

  afterEach(() => {
    sessionStorage.clear();
  });

  it('counts employee sales with their discount and identifies them separately (H2.12)', () => {
    const pos = TestBed.inject(PosService);
    const caja = TestBed.inject(CajaService);
    chargeSale(pos, 0, 1, 'efectivo'); // normal: $2.600

    pos.empleados.set([{ id: 5, nombre: 'Ana Pérez' }]);
    pos.empleadosStatus.set('ready');
    pos.setVentaEmpleado(true);
    pos.seleccionarEmpleado(5);
    chargeSale(pos, 1, 1, 'efectivo'); // empleado: $3.200 − $960 = $2.240

    expect(caja.grandTotal()).toBe(2600 + 2240);
    expect(caja.summaryByMethod().find((m) => m.key === 'efectivo')?.total).toBe(4840);
    expect(caja.resumenVentasEmpleado()).toEqual({ cantidad: 1, total: 2240, descuento: 960 });
  });

  it('closes the shift with a snapshot of the totals and resets the sales history', () => {
    const pos = TestBed.inject(PosService);
    const caja = TestBed.inject(CajaService);

    chargeSale(pos, 0, 1, 'efectivo'); // $2.600
    chargeSale(pos, 1, 1, 'credito'); // $3.200

    const cierre = closeShift(caja, 'Camila Rojas', 'Nury Providencia', 2600, null, { credito: 1 }, {});

    expect(cierre.totalGeneral).toBe(5800);
    expect(cierre.ventasTotales).toBe(2);
    expect(cierre.desglose.find((d) => d.key === 'efectivo')?.total).toBe(2600);
    expect(cierre.desglose.find((d) => d.key === 'credito')?.total).toBe(3200);
    expect(pos.salesHistory()).toHaveLength(0);
    expect(caja.grandTotal()).toBe(0);
    expect(caja.historialCierres()).toContain(cierre);
    expect(pos.isRegisterOpen()).toBe(false);
  });

  it('does not mix sales from a previous shift into the next closing', () => {
    const pos = TestBed.inject(PosService);
    const caja = TestBed.inject(CajaService);

    chargeSale(pos, 0, 1, 'efectivo');
    closeShift(caja, 'Camila Rojas', 'Nury Providencia', 2600, null, {}, {});

    // Reabre el turno para la segunda venta, como haría el cajero en la app real.
    pos.turnoActivo.set(FAKE_TURNO);
    chargeSale(pos, 1, 1, 'credito'); // única venta del nuevo turno
    const segundoCierre = closeShift(caja, 'Camila Rojas', 'Nury Providencia', 0, null, { credito: 1 }, {});

    expect(segundoCierre.ventasTotales).toBe(1);
    expect(segundoCierre.desglose.find((d) => d.key === 'efectivo')?.total).toBe(0);
    expect(segundoCierre.desglose.find((d) => d.key === 'credito')?.total).toBe(3200);
  });

  it('iniciarTurno opens the register so the cashier can operate in the POS', () => {
    const pos = TestBed.inject(PosService);
    const caja = TestBed.inject(CajaService);

    pos.turnoActivo.set(null);
    expect(caja.isRegisterOpen()).toBe(false);

    caja.iniciarTurno(1, 1, 0).subscribe();

    expect(caja.isRegisterOpen()).toBe(true);
    expect(pos.isRegisterOpen()).toBe(true);
  });

  it('groups the individual sales of the shift by payment method (ventasPorMetodo)', () => {
    const pos = TestBed.inject(PosService);
    const caja = TestBed.inject(CajaService);

    chargeSale(pos, 0, 1, 'efectivo'); // Café Espresso Doble $2.600
    chargeSale(pos, 1, 2, 'credito'); // 2x Cappuccino Italiano $6.400

    const grupos = caja.ventasPorMetodo();
    const efectivo = grupos.find((g) => g.key === 'efectivo')!;
    const credito = grupos.find((g) => g.key === 'credito')!;
    const sodexo = grupos.find((g) => g.key === 'sodexo')!;

    expect(efectivo.ventas).toHaveLength(1);
    expect(efectivo.ventas[0].total).toBe(2600);
    expect(efectivo.ventas[0].items[0].producto.nombre).toBe('Café Espresso Doble');

    expect(credito.ventas).toHaveLength(1);
    expect(credito.ventas[0].total).toBe(6400);
    expect(credito.ventas[0].items[0].cantidad).toBe(2);

    expect(sodexo.ventas).toHaveLength(0);
  });

  it('records no difference when the counted cash matches the system total', () => {
    const pos = TestBed.inject(PosService);
    const caja = TestBed.inject(CajaService);

    chargeSale(pos, 0, 1, 'efectivo'); // $2.600

    const cierre = closeShift(caja, 'Camila Rojas', 'Nury Providencia', 2600, null, {}, {});

    expect(cierre.efectivoEsperado).toBe(2600);
    expect(cierre.efectivoContado).toBe(2600);
    expect(cierre.diferenciaEfectivo).toBe(0);
    expect(cierre.justificacionDiferencia).toBeNull();
  });

  it('rejects closing with a cash mismatch and no justification', () => {
    const pos = TestBed.inject(PosService);
    const caja = TestBed.inject(CajaService);

    chargeSale(pos, 0, 1, 'efectivo'); // $2.600

    expect(() => caja.cerrarTurno('Camila Rojas', 'Nury Providencia', 2000, null, {}, {})).toThrow();
    expect(() => caja.cerrarTurno('Camila Rojas', 'Nury Providencia', 2000, '   ', {}, {})).toThrow();
    expect(pos.salesHistory()).toHaveLength(1); // no se cerró el turno
  });

  it('records a shortage or surplus with its justification', () => {
    const pos = TestBed.inject(PosService);
    const caja = TestBed.inject(CajaService);

    chargeSale(pos, 0, 1, 'efectivo'); // $2.600

    const cierre = closeShift(
      caja,
      'Camila Rojas',
      'Nury Providencia',
      2000,
      'Se entregó de más en el vuelto de una venta.',
      {},
      {}
    );

    expect(cierre.diferenciaEfectivo).toBe(-600);
    expect(cierre.justificacionDiferencia).toBe('Se entregó de más en el vuelto de una venta.');
  });

  it('records no difference for boletas when the counted amount matches the sales', () => {
    const pos = TestBed.inject(PosService);
    const caja = TestBed.inject(CajaService);

    chargeSale(pos, 0, 1, 'efectivo'); // $2.600
    chargeSale(pos, 1, 1, 'credito'); // $3.200

    const cierre = closeShift(caja, 'Camila Rojas', 'Nury Providencia', 2600, null, { credito: 1 }, {});
    const credito = cierre.cuadraturaBoletas.find((b) => b.key === 'credito')!;

    expect(credito.boletasEsperadas).toBe(1);
    expect(credito.boletasContadas).toBe(1);
    expect(credito.diferenciaBoletas).toBe(0);
    expect(credito.justificacionDiferencia).toBeNull();
  });

  it('rejects closing with a boleta mismatch and no justification', () => {
    const pos = TestBed.inject(PosService);
    const caja = TestBed.inject(CajaService);

    chargeSale(pos, 0, 1, 'efectivo'); // $2.600
    chargeSale(pos, 1, 1, 'credito'); // $3.200

    expect(() =>
      caja.cerrarTurno('Camila Rojas', 'Nury Providencia', 2600, null, { credito: 0 }, {})
    ).toThrow();
    expect(pos.salesHistory()).toHaveLength(2); // no se cerró el turno
  });

  it('records a boleta shortage or surplus with its justification', () => {
    const pos = TestBed.inject(PosService);
    const caja = TestBed.inject(CajaService);

    chargeSale(pos, 0, 1, 'efectivo'); // $2.600
    chargeSale(pos, 1, 1, 'credito'); // $3.200

    const cierre = closeShift(
      caja,
      'Camila Rojas',
      'Nury Providencia',
      2600,
      null,
      { credito: 0 },
      { credito: 'El cliente se llevó su boleta y no quedó copia en caja.' }
    );
    const credito = cierre.cuadraturaBoletas.find((b) => b.key === 'credito')!;

    expect(credito.diferenciaBoletas).toBe(-1);
    expect(credito.justificacionDiferencia).toBe(
      'El cliente se llevó su boleta y no quedó copia en caja.'
    );
  });
});
