import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, computed, inject, OnInit, signal } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../../auth/services/auth.service';
import { AppIconComponent } from '../../../../shared/components/app-icon/app-icon.component';
import { PAYMENT_METHOD_META, CierreCaja, MetodoElectronico, VentasPorMetodo } from '../../models/caja.model';
import { CompletedSale, PaymentMethod } from '../../../pos/models/pos.model';
import { CajaService } from '../../services/caja.service';

/** Mensaje legible a partir de un error de PostgREST (RAISE EXCEPTION en el RPC). */
function mensajeError(error: unknown, fallback: string): string {
  if (error instanceof HttpErrorResponse) {
    const mensaje = (error.error as { message?: string } | null)?.message;
    if (mensaje) return mensaje;
  }
  if (error instanceof Error && error.message) return error.message;
  return fallback;
}

// Los 4 medios de pago electrónicos se cuadran por cantidad de boletas, no por dinero
const METODOS_ELECTRONICOS: MetodoElectronico[] = ['credito', 'debito', 'sodexo', 'edenred'];

interface CuadraturaBoletasPreview {
  key: MetodoElectronico;
  label: string;
  icon: string;
  esperadas: number;
  contadas: number | null;
  diferencia: number | null;
  requiereJustificacion: boolean;
  justificacion: string;
}

@Component({
  selector: 'app-cierre-caja',
  standalone: true,
  imports: [CommonModule, AppIconComponent],
  templateUrl: './cierre-caja.component.html',
  styleUrl: './cierre-caja.component.css',
})
export class CierreCajaComponent implements OnInit {
  private readonly cajaService = inject(CajaService);
  private readonly authService = inject(AuthService);
  private readonly router = inject(Router, { optional: true });

  readonly selectedMethod = signal<PaymentMethod | null>(null);
  readonly showConfirm = signal(false);
  readonly turnoCerrado = signal<CierreCaja | null>(null);

  // Apertura de turno: monto inicial obligatorio (puede ser 0) + estado de la llamada al backend.
  readonly montoInicialInput = signal<number | null>(null);
  readonly abriendoTurno = signal(false);
  readonly errorAbrirTurno = signal<string | null>(null);

  // Cierre de turno: estado de la llamada al backend (fn_cerrar_turno).
  readonly cerrandoTurno = signal(false);
  readonly errorCerrarTurno = signal<string | null>(null);

  readonly efectivoContado = signal<number | null>(null);
  readonly justificacion = signal('');

  // Conteo de boletas de los medios electrónicos: no es dinero, es cantidad de comprobantes
  readonly boletasContadas = signal<Partial<Record<MetodoElectronico, number | null>>>({});
  readonly justificacionesBoletas = signal<Partial<Record<MetodoElectronico, string>>>({});

  readonly summaryByMethod = this.cajaService.summaryByMethod;
  readonly grandTotal = this.cajaService.grandTotal;
  readonly hayVentasEnElTurno = this.cajaService.hayVentasEnElTurno;
  readonly isRegisterOpen = this.cajaService.isRegisterOpen;
  readonly turnoActivo = this.cajaService.turnoActivo;
  readonly sincronizandoTurno = this.cajaService.sincronizandoTurno;
  readonly errorSincronizarTurno = this.cajaService.errorSincronizarTurno;
  readonly ventasPorMetodo = this.cajaService.ventasPorMetodo;
  readonly resumenVentasEmpleado = this.cajaService.resumenVentasEmpleado;

  // Historial: filtro por tipo de venta (H2.12)
  readonly tipoVentaFiltro = signal<'todas' | 'normal' | 'empleado'>('todas');

  ngOnInit(): void {
    this.recuperarTurno();
  }

  recuperarTurno(): void {
    this.cajaService.sincronizarTurno().subscribe({ error: () => {} });
  }

  continuarVendiendo(): void {
    if (this.isRegisterOpen()) this.router?.navigate(['/pos']);
  }

  fechaInicioTurno(): Date {
    const fecha = this.turnoActivo()?.hora_inicio ?? '';
    return new Date(/[zZ]|[+-]\d{2}:?\d{2}$/.test(fecha) ? fecha : `${fecha}Z`);
  }

  // Historial de ventas: filtro de texto libre por folio, productos o medio de pago
  readonly historialQuery = signal('');

  readonly ventasPorMetodoFiltradas = computed<VentasPorMetodo[]>(() => {
    const query = this.historialQuery().trim().toLowerCase();
    const tipo = this.tipoVentaFiltro();
    const grupos =
      tipo === 'todas'
        ? this.ventasPorMetodo()
        : this.ventasPorMetodo().map((grupo) => ({
            ...grupo,
            ventas: grupo.ventas.filter((venta) => (venta.tipoVenta ?? 'normal') === tipo),
          }));
    if (!query) return grupos;

    return grupos.map((grupo) => {
      if (grupo.label.toLowerCase().includes(query)) {
        return grupo;
      }
      return {
        ...grupo,
        ventas: grupo.ventas.filter(
          (venta) =>
            venta.ticketFolio.toLowerCase().includes(query) ||
            this.resumenItems(venta).toLowerCase().includes(query)
        ),
      };
    });
  });

  readonly hayResultadosHistorial = computed(() =>
    this.ventasPorMetodoFiltradas().some((grupo) => grupo.ventas.length > 0)
  );

  readonly selectedMethodLabel = computed(() => {
    const method = this.selectedMethod();
    return method ? PAYMENT_METHOD_META[method].label : '';
  });

  readonly selectedMethodProducts = computed(() => {
    const method = this.selectedMethod();
    return method ? this.cajaService.productosPorMedioPago(method) : [];
  });

  readonly efectivoEsperado = computed(
    () => this.summaryByMethod().find((m) => m.key === 'efectivo')?.total ?? 0
  );

  // Diferencia entre lo contado físicamente y lo que dice el sistema.
  // Positivo = sobrante, negativo = faltante, null = todavía no ingresa el conteo.
  readonly diferenciaEfectivo = computed(() => {
    const contado = this.efectivoContado();
    return contado === null ? null : contado - this.efectivoEsperado();
  });

  readonly requiereJustificacion = computed(() => {
    const diferencia = this.diferenciaEfectivo();
    return diferencia !== null && diferencia !== 0;
  });

  // Cuadratura de boletas por medio electrónico: esperadas (según el sistema) vs.
  // contadas (lo que el cajero cuenta físicamente), con su propia justificación si difieren.
  readonly cuadraturaBoletas = computed<CuadraturaBoletasPreview[]>(() => {
    const desglose = this.summaryByMethod();
    const contadas = this.boletasContadas();
    const justificaciones = this.justificacionesBoletas();

    // Solo pide cuadrar boletas de un medio si hubo ventas con ese medio este turno;
    // si nadie pagó con Edenred, por ejemplo, no tiene sentido pedir que se cuente.
    return METODOS_ELECTRONICOS.filter(
      (key) => (desglose.find((m) => m.key === key)?.ventas ?? 0) > 0
    ).map((key) => {
      const meta = PAYMENT_METHOD_META[key];
      const esperadas = desglose.find((m) => m.key === key)?.ventas ?? 0;
      const contada = contadas[key] ?? null;
      const diferencia = contada === null ? null : contada - esperadas;
      return {
        key,
        label: meta.label,
        icon: meta.icon,
        esperadas,
        contadas: contada,
        diferencia,
        requiereJustificacion: diferencia !== null && diferencia !== 0,
        justificacion: justificaciones[key] ?? '',
      };
    });
  });

  readonly puedeConfirmarCierre = computed(() => {
    if (this.efectivoContado() === null) return false;
    if (this.requiereJustificacion() && this.justificacion().trim().length === 0) return false;

    for (const boleta of this.cuadraturaBoletas()) {
      if (boleta.contadas === null) return false;
      if (boleta.requiereJustificacion && boleta.justificacion.trim().length === 0) return false;
    }
    return true;
  });

  setEfectivoContado(valor: string): void {
    const parsed = valor.trim() === '' ? null : Number(valor);
    this.efectivoContado.set(parsed === null || Number.isNaN(parsed) ? null : parsed);
  }

  setJustificacion(valor: string): void {
    this.justificacion.set(valor);
  }

  setTipoVentaFiltro(valor: string): void {
    this.tipoVentaFiltro.set(valor === 'normal' || valor === 'empleado' ? valor : 'todas');
  }

  setHistorialQuery(valor: string): void {
    this.historialQuery.set(valor);
  }

  setMontoInicial(valor: string): void {
    const parsed = valor.trim() === '' ? null : Number(valor);
    this.montoInicialInput.set(parsed === null || Number.isNaN(parsed) ? null : parsed);
  }

  setBoletaContada(key: MetodoElectronico, valor: string): void {
    const parsed = valor.trim() === '' ? null : Number(valor);
    this.boletasContadas.set({
      ...this.boletasContadas(),
      [key]: parsed === null || Number.isNaN(parsed) ? null : parsed,
    });
  }

  setJustificacionBoleta(key: MetodoElectronico, valor: string): void {
    this.justificacionesBoletas.set({ ...this.justificacionesBoletas(), [key]: valor });
  }

  selectMethod(method: PaymentMethod): void {
    this.selectedMethod.set(this.selectedMethod() === method ? null : method);
  }

  // El turno se puede cerrar haya o no ventas; igual se debe contar el
  // efectivo físico de la caja (para cuadrar contra el monto inicial).
  openConfirm(): void {
    this.efectivoContado.set(null);
    this.justificacion.set('');
    this.boletasContadas.set({});
    this.justificacionesBoletas.set({});
    this.showConfirm.set(true);
  }

  cancelConfirm(): void {
    this.showConfirm.set(false);
  }

  confirmCierre(): void {
    if (!this.puedeConfirmarCierre() || this.cerrandoTurno()) return;

    const cajero = this.authService.currentUser();
    const boletasContadas = this.boletasContadas() as Partial<Record<MetodoElectronico, number>>;

    this.cerrandoTurno.set(true);
    this.errorCerrarTurno.set(null);

    this.cajaService
      .cerrarTurno(
        cajero?.nombre ?? 'Cajero',
        cajero?.sucursalNombre ?? 'Sucursal',
        this.efectivoContado()!,
        this.requiereJustificacion() ? this.justificacion() : null,
        boletasContadas,
        this.justificacionesBoletas()
      )
      .subscribe({
        next: (cierre) => {
          this.cerrandoTurno.set(false);
          this.turnoCerrado.set(cierre);
          this.showConfirm.set(false);
          this.selectedMethod.set(null);
        },
        error: (error) => {
          this.cerrandoTurno.set(false);
          this.errorCerrarTurno.set(
            mensajeError(error, 'No se pudo cerrar el turno. Intenta nuevamente.')
          );
        },
      });
  }

  // Abre turno contra el backend (fn_abrir_turno) y, si tiene éxito, lleva
  // al cajero al POS para empezar a vender.
  iniciarTurno(): void {
    if (this.abriendoTurno() || this.sincronizandoTurno() || this.errorSincronizarTurno()) return;

    const cajero = this.authService.currentUser();
    const monto = this.montoInicialInput();

    if (!cajero) {
      this.errorAbrirTurno.set('No hay una sesión activa.');
      return;
    }
    if (cajero.sucursalId === null) {
      this.errorAbrirTurno.set('Tu usuario no tiene una sucursal asignada.');
      return;
    }
    if (monto === null || monto < 0) {
      this.errorAbrirTurno.set('Ingresa el monto inicial de caja (puede ser 0).');
      return;
    }

    this.abriendoTurno.set(true);
    this.errorAbrirTurno.set(null);

    this.cajaService.iniciarTurno(cajero.id, cajero.sucursalId, monto).subscribe({
      next: () => {
        this.abriendoTurno.set(false);
        this.montoInicialInput.set(null);
        this.router?.navigate(['/pos']);
      },
      error: (error) => {
        if (error instanceof HttpErrorResponse &&
            (error.error?.code === '23505' || error.error?.message?.includes('Ya existe un turno activo'))) {
          this.cajaService.sincronizarTurno().subscribe({
            next: (turno) => {
              this.abriendoTurno.set(false);
              this.errorAbrirTurno.set(turno ? null : 'El turno cambió mientras intentabas abrirlo. Reintenta.');
            },
            error: () => this.abriendoTurno.set(false),
          });
          return;
        }
        this.abriendoTurno.set(false);
        this.errorAbrirTurno.set(
          mensajeError(error, 'No se pudo abrir el turno. Intenta nuevamente.')
        );
      },
    });
  }

  volverAOperar(): void {
    this.turnoCerrado.set(null);
  }

  formatClpAbs(amount: number): string {
    return this.formatClp(Math.abs(amount));
  }

  absNumber(value: number): number {
    return Math.abs(value);
  }

  formatClp(amount: number): string {
    return new Intl.NumberFormat('es-CL', {
      style: 'currency',
      currency: 'CLP',
      maximumFractionDigits: 0,
    }).format(amount);
  }

  formatFecha(fecha: Date): string {
    return new Intl.DateTimeFormat('es-CL', {
      dateStyle: 'medium',
      timeStyle: 'short',
    }).format(fecha);
  }

  formatHora(fecha: Date): string {
    return new Intl.DateTimeFormat('es-CL', { timeStyle: 'short' }).format(fecha);
  }

  // Resumen legible de los ítems de una venta, ej. "2x Café Espresso, 1x Cappuccino"
  resumenItems(sale: CompletedSale): string {
    return sale.items.map((item) => `${item.cantidad}x ${item.producto.nombre}`).join(', ');
  }

  medioPagoLabel(sale: CompletedSale): string {
    return PAYMENT_METHOD_META[sale.medioPago].label;
  }
}
