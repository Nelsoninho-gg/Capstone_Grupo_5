import { Component } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { NEVER, of, Subject, throwError } from 'rxjs';
import { CierreCajaComponent } from './cierre-caja.component';
import { PosService } from '../../../pos/services/pos.service';
import { ProductosApiService } from '../../../../core/api/productos-api.service';
import { VentasApiService } from '../../../../core/api/ventas-api.service';
import { TurnosApiService, TurnoApi, TurnoRecuperadoApi } from '../../../../core/api/turnos-api.service';
import { AuthService } from '../../../auth/services/auth.service';
import { PosProduct } from '../../../pos/models/pos.model';

const FAKE_TURNO: TurnoApi = {
  id: 1,
  usuario_id: 1,
  sucursal_id: 1,
  hora_inicio: new Date().toISOString(),
  hora_fin: null,
  creado_en: new Date().toISOString(),
  monto_inicial: 0,
};

const FAKE_CAJERO = {
  id: 1,
  nombre: 'Camila Rojas',
  identificadorAcceso: 'camila@test.cl',
  rol: 'cajero' as const,
  sucursalId: 1,
  sucursalNombre: 'Sucursal Providencia',
  activo: true,
};

@Component({ standalone: true, template: '' })
class DummyComponent {}

const TEST_PRODUCTS: PosProduct[] = [
  {
    id: 1,
    nombre: 'Café Espresso Doble',
    categoriaId: 'BEBESTIBLES - CAFÉ',
    categoriaNombre: 'Cafetería',
    codigoInterno: 'NUR-101',
    codigoBarras: '7801234501018',
    precioVenta: 2600,
    icono: '☕',
    descripcion: 'Producto exclusivo para pruebas.',
    activo: true,
  },
  {
    id: 2,
    nombre: 'Cappuccino Italiano',
    categoriaId: 'BEBESTIBLES - CAFÉ',
    categoriaNombre: 'Cafetería',
    codigoInterno: 'NUR-102',
    codigoBarras: '7801234501025',
    precioVenta: 3200,
    icono: '☕',
    descripcion: 'Producto exclusivo para pruebas.',
    activo: true,
  },
  {
    id: 3,
    nombre: 'Café Latte Vainilla',
    categoriaId: 'BEBESTIBLES - CAFÉ',
    categoriaNombre: 'Cafetería',
    codigoInterno: 'NUR-103',
    codigoBarras: '7801234501032',
    precioVenta: 3500,
    icono: '☕',
    descripcion: 'Producto exclusivo para pruebas.',
    activo: true,
  },
];

describe('CierreCajaComponent', () => {
  function chargeSale(
    pos: PosService,
    productIndex: number,
    cantidad: number,
    medioPago: 'efectivo' | 'credito' | 'debito' | 'sodexo' | 'edenred'
  ) {
    for (let i = 0; i < cantidad; i++) {
      pos.addToCart(pos.catalog()[productIndex]);
    }
    return pos
      .completeSale(
        medioPago,
        pos.total(),
        { id: 1, nombre: 'Camila Rojas' },
        { id: 1, nombre: 'Sucursal Providencia' },
      )
      .subscribe();
  }

  beforeEach(() => {
    // PosService persiste el turno/ventas en sessionStorage (para sobrevivir
    // a un refresh de página); sin esto, el turno de un test quedaba "pegado"
    // al siguiente porque todos usan el mismo FAKE_CAJERO.id.
    sessionStorage.clear();
    TestBed.configureTestingModule({
      providers: [
        provideRouter([
          { path: 'pos', component: DummyComponent },
          { path: 'caja', component: DummyComponent },
        ]),
        { provide: ProductosApiService, useValue: { listar: () => NEVER } },
        { provide: VentasApiService, useValue: { registrar: () => of(999) } },
        { provide: TurnosApiService, useValue: { abrir: () => of(FAKE_TURNO), cerrar: () => of(FAKE_TURNO), recuperar: vi.fn(() => of({ turno: FAKE_TURNO, ventas: [] })) } },
        { provide: AuthService, useValue: { currentUser: () => FAKE_CAJERO } },
      ],
    });
    const pos = TestBed.inject(PosService);
    pos.catalog.set(TEST_PRODUCTS);
    pos.clearCart();
    // La mayoría de las pruebas de cierre asumen un turno ya abierto (igual
    // que antes de conectar Caja a fn_abrir_turno/fn_cerrar_turno); las que
    // prueban el flujo de apertura en sí lo dejan explícito más abajo.
    pos.turnoActivo.set(FAKE_TURNO);
  });

  afterEach(() => sessionStorage.clear());

  it('shows the amount collected per payment method (AC1)', () => {
    const pos = TestBed.inject(PosService);
    chargeSale(pos, 0, 1, 'efectivo'); // Café Espresso Doble $2.600
    chargeSale(pos, 1, 1, 'credito'); // Cappuccino Italiano $3.200
    chargeSale(pos, 2, 1, 'sodexo'); // Café Latte Vainilla $3.500

    const component = TestBed.createComponent(CierreCajaComponent).componentInstance;
    const summary = component.summaryByMethod();

    expect(summary.find((m) => m.key === 'efectivo')?.total).toBe(2600);
    expect(summary.find((m) => m.key === 'credito')?.total).toBe(3200);
    expect(summary.find((m) => m.key === 'sodexo')?.total).toBe(3500);
    expect(component.grandTotal()).toBe(2600 + 3200 + 3500);
  });

  it('lists the products sold with the selected payment method (AC2)', () => {
    const pos = TestBed.inject(PosService);
    chargeSale(pos, 0, 1, 'efectivo'); // 1ra venta: 1 unidad
    chargeSale(pos, 0, 2, 'efectivo'); // 2da venta: 2 unidades del mismo producto
    chargeSale(pos, 1, 1, 'credito'); // producto distinto, otro método

    const component = TestBed.createComponent(CierreCajaComponent).componentInstance;
    component.selectMethod('efectivo');

    const productos = component.selectedMethodProducts();
    expect(productos).toHaveLength(1);
    expect(productos[0].producto.nombre).toBe('Café Espresso Doble');
    expect(productos[0].cantidad).toBe(3);

    component.selectMethod('efectivo');
    expect(component.selectedMethod()).toBeNull();
    expect(component.selectedMethodProducts()).toHaveLength(0);
  });

  it('recovers employee sales with their code and discount, marks them and filters by type (H2.12)', () => {
    const producto = {
      id: 1, nombre: 'Café Espresso Doble', categoria: 'BEBESTIBLES - CAFÉ', precio_compra: 0,
      precio_venta: 2600, codigo_barras: null, activo: true, creado_en: '2026-10-13T12:00:00',
    };
    const detalle = { cantidad: 1, precio_unitario: 2600, subtotal: 2600, productos: producto };
    const base = {
      sucursal_id: 1, cajero_id: FAKE_TURNO.usuario_id, fecha_venta: '2026-10-13T12:00:00',
      anulada: false, anulada_en: null, anulada_por: null, creado_en: '2026-10-13T12:00:00',
      detalle_venta: [detalle],
    };
    const recuperado = {
      turno: FAKE_TURNO,
      ventas: [
        { ...base, id: 1, medio_pago: 'efectivo', total: 2600, tipo_venta: 'normal', codigo_venta: 'TK-1',
          descuento_monto: 0 },
        { ...base, id: 2, medio_pago: 'debito', total: 1820, tipo_venta: 'empleado', codigo_venta: 'EMP-2',
          empleado_id: 5, descuento_porcentaje: 30, descuento_monto: 780 },
      ],
    } as unknown as TurnoRecuperadoApi;
    vi.mocked(TestBed.inject(TurnosApiService).recuperar).mockReturnValue(of(recuperado));

    const fixture = TestBed.createComponent(CierreCajaComponent);
    const component = fixture.componentInstance;
    fixture.detectChanges();
    const el: HTMLElement = fixture.nativeElement;
    const folios = () =>
      component
        .ventasPorMetodoFiltradas()
        .flatMap((grupo) => grupo.ventas.map((venta) => venta.ticketFolio));

    const empleado = TestBed.inject(PosService).salesHistory().find((venta) => venta.id === 2);
    expect(empleado).toEqual(
      expect.objectContaining({ tipoVenta: 'empleado', subtotal: 2600, descuento: 780, total: 1820 }),
    );
    expect(el.querySelectorAll('.badge-empleado')).toHaveLength(1);
    expect(el.querySelector('.resumen-empleado')?.textContent).toContain('1 venta a empleado');
    expect(component.grandTotal()).toBe(2600 + 1820);
    expect(folios()).toEqual(['TK-1', 'EMP-2']);

    component.setTipoVentaFiltro('empleado');
    expect(folios()).toEqual(['EMP-2']);

    component.setTipoVentaFiltro('normal');
    expect(folios()).toEqual(['TK-1']);

    component.setTipoVentaFiltro('todas');
    expect(folios()).toHaveLength(2);
  });

  it('opens the confirm dialog even when the shift has no sales', () => {
    const component = TestBed.createComponent(CierreCajaComponent).componentInstance;
    component.openConfirm();
    expect(component.showConfirm()).toBe(true);
  });

  it('closes the shift after confirming a matching cash count', () => {
    const pos = TestBed.inject(PosService);
    chargeSale(pos, 0, 1, 'efectivo'); // $2.600
    chargeSale(pos, 1, 1, 'credito'); // $3.200

    const component = TestBed.createComponent(CierreCajaComponent).componentInstance;
    component.openConfirm();
    expect(component.showConfirm()).toBe(true);

    component.setEfectivoContado('2600');
    expect(component.puedeConfirmarCierre()).toBe(false); // falta cuadrar las boletas de crédito

    component.setBoletaContada('credito', '1');
    expect(component.puedeConfirmarCierre()).toBe(true);
    component.confirmCierre();

    expect(component.showConfirm()).toBe(false);
    expect(component.turnoCerrado()?.totalGeneral).toBe(2600 + 3200);
    expect(component.turnoCerrado()?.diferenciaEfectivo).toBe(0);
    expect(component.turnoCerrado()?.cuadraturaBoletas.find((b) => b.key === 'credito')?.diferenciaBoletas).toBe(0);
    expect(pos.salesHistory()).toHaveLength(0);
    expect(component.grandTotal()).toBe(0);
    expect(pos.isRegisterOpen()).toBe(false);
  });

  it('cancels the confirm dialog without closing the shift', () => {
    const pos = TestBed.inject(PosService);
    chargeSale(pos, 0, 1, 'efectivo');

    const component = TestBed.createComponent(CierreCajaComponent).componentInstance;
    component.openConfirm();
    component.cancelConfirm();

    expect(component.showConfirm()).toBe(false);
    expect(component.turnoCerrado()).toBeNull();
    expect(pos.salesHistory()).toHaveLength(1);
  });

  it('shows the register as closed until "Iniciar Turno" is triggered, and opens it with the monto inicial entered', () => {
    const pos = TestBed.inject(PosService);
    pos.turnoActivo.set(null);

    const component = TestBed.createComponent(CierreCajaComponent).componentInstance;
    expect(component.isRegisterOpen()).toBe(false);

    component.setMontoInicial('0');
    component.iniciarTurno();

    expect(component.isRegisterOpen()).toBe(true);
    expect(pos.isRegisterOpen()).toBe(true);
    expect(component.errorAbrirTurno()).toBeNull();
  });

  it('blocks opening the shift without entering a monto inicial', () => {
    const pos = TestBed.inject(PosService);
    pos.turnoActivo.set(null);

    const component = TestBed.createComponent(CierreCajaComponent).componentInstance;
    component.iniciarTurno();

    expect(component.isRegisterOpen()).toBe(false);
    expect(component.errorAbrirTurno()).toContain('monto inicial');
  });

  it('recovers an existing shift when opening races with another tab instead of leaving the cashier blocked', () => {
    const pos = TestBed.inject(PosService);
    pos.turnoActivo.set(null);
    const turnosApi = TestBed.inject(TurnosApiService);
    const mensaje = 'Ya existe un turno activo para este cajero en esta sucursal';
    vi.spyOn(turnosApi, 'abrir').mockReturnValue(
      throwError(() => new HttpErrorResponse({ error: { message: mensaje }, status: 409 }))
    );

    const component = TestBed.createComponent(CierreCajaComponent).componentInstance;
    component.setMontoInicial('0');
    component.iniciarTurno();

    expect(component.isRegisterOpen()).toBe(true);
    expect(component.errorAbrirTurno()).toBeNull();
    expect(turnosApi.recuperar).toHaveBeenCalledOnce();
    expect(component.turnoActivo()?.id).toBe(FAKE_TURNO.id);
  });

  it('checks the server on entry and hides opening and closing actions until the shift is verified', () => {
    const response = new Subject<TurnoRecuperadoApi>();
    vi.mocked(TestBed.inject(TurnosApiService).recuperar).mockReturnValue(response);
    const fixture = TestBed.createComponent(CierreCajaComponent);
    fixture.detectChanges();
    const el = fixture.nativeElement as HTMLElement;
    expect(el.textContent).toContain('Comprobando tu turno');
    expect(el.textContent).not.toContain('Iniciar Turno');
    expect(el.textContent).not.toContain('Cerrar turno');
    response.next({ turno: FAKE_TURNO, ventas: [] });
    response.complete();
    fixture.detectChanges();
    expect(el.textContent).toContain('Continuar vendiendo');
    expect(el.textContent).toContain('Cerrar turno');
  });

  it('offers a retry when recovery fails without treating an unverified shift as closed', () => {
    vi.mocked(TestBed.inject(TurnosApiService).recuperar).mockReturnValue(throwError(() => new Error('sin red')));
    const fixture = TestBed.createComponent(CierreCajaComponent);
    fixture.detectChanges();
    const el = fixture.nativeElement as HTMLElement;
    expect(el.textContent).toContain('No pudimos comprobar tu turno');
    expect(el.textContent).toContain('Reintentar');
    expect(el.textContent).not.toContain('Iniciar Turno');
    expect(el.textContent).not.toContain('Cerrar turno');
  });

  it('returns to the start-shift screen after closing, without auto-reopening the register (AC: monto inicial obligatorio)', () => {
    const pos = TestBed.inject(PosService);
    chargeSale(pos, 0, 1, 'efectivo'); // $2.600

    const component = TestBed.createComponent(CierreCajaComponent).componentInstance;
    component.openConfirm();
    component.setEfectivoContado('2600');
    component.confirmCierre();

    expect(pos.isRegisterOpen()).toBe(false);

    component.volverAOperar();

    // Ya no reabre automáticamente: el cajero debe ingresar el monto
    // inicial del nuevo turno antes de poder operar de nuevo.
    expect(component.turnoCerrado()).toBeNull();
    expect(pos.isRegisterOpen()).toBe(false);
  });

  it('lists the individual sales grouped by payment method, not just aggregates (AC2)', () => {
    const pos = TestBed.inject(PosService);
    chargeSale(pos, 0, 1, 'efectivo'); // Café Espresso Doble
    chargeSale(pos, 1, 1, 'efectivo'); // Cappuccino Italiano

    const component = TestBed.createComponent(CierreCajaComponent).componentInstance;
    const grupos = component.ventasPorMetodo();
    const efectivo = grupos.find((g) => g.key === 'efectivo')!;

    expect(efectivo.ventas).toHaveLength(2);
    expect(component.resumenItems(efectivo.ventas[0])).toContain('Cappuccino Italiano');
    expect(component.resumenItems(efectivo.ventas[1])).toContain('Café Espresso Doble');
  });

  it('blocks closing when there is a cash mismatch and no justification yet (AC)', () => {
    const pos = TestBed.inject(PosService);
    chargeSale(pos, 0, 1, 'efectivo'); // $2.600

    const component = TestBed.createComponent(CierreCajaComponent).componentInstance;
    component.openConfirm();
    component.setEfectivoContado('2000');

    expect(component.diferenciaEfectivo()).toBe(-600);
    expect(component.requiereJustificacion()).toBe(true);
    expect(component.puedeConfirmarCierre()).toBe(false);

    component.confirmCierre();
    expect(component.turnoCerrado()).toBeNull(); // no cerró, faltaba justificar

    component.setJustificacion('Faltó registrar una venta en el sistema.');
    expect(component.puedeConfirmarCierre()).toBe(true);

    component.confirmCierre();
    expect(component.turnoCerrado()?.diferenciaEfectivo).toBe(-600);
    expect(component.turnoCerrado()?.justificacionDiferencia).toBe(
      'Faltó registrar una venta en el sistema.'
    );
  });

  it('does not require a justification when the cash count matches exactly', () => {
    const pos = TestBed.inject(PosService);
    chargeSale(pos, 0, 1, 'efectivo'); // $2.600

    const component = TestBed.createComponent(CierreCajaComponent).componentInstance;
    component.openConfirm();
    component.setEfectivoContado('2600');

    expect(component.requiereJustificacion()).toBe(false);
    expect(component.puedeConfirmarCierre()).toBe(true);
  });

  it('blocks closing when there is a boleta mismatch for an electronic method (AC)', () => {
    const pos = TestBed.inject(PosService);
    chargeSale(pos, 0, 1, 'efectivo'); // $2.600
    chargeSale(pos, 1, 1, 'sodexo'); // $3.200

    const component = TestBed.createComponent(CierreCajaComponent).componentInstance;
    component.openConfirm();
    component.setEfectivoContado('2600');
    component.setBoletaContada('sodexo', '0');

    const sodexo = component.cuadraturaBoletas().find((b) => b.key === 'sodexo')!;
    expect(sodexo.diferencia).toBe(-1);
    expect(component.puedeConfirmarCierre()).toBe(false);

    component.confirmCierre();
    expect(component.turnoCerrado()).toBeNull(); // no cerró, faltaba justificar la boleta

    component.setJustificacionBoleta('sodexo', 'El cliente se retiró con la boleta impresa.');
    expect(component.puedeConfirmarCierre()).toBe(true);

    component.confirmCierre();
    const cierreSodexo = component.turnoCerrado()?.cuadraturaBoletas.find((b) => b.key === 'sodexo');
    expect(cierreSodexo?.diferenciaBoletas).toBe(-1);
    expect(cierreSodexo?.justificacionDiferencia).toBe('El cliente se retiró con la boleta impresa.');
  });

  it('does not ask to reconcile an electronic method with no sales this shift', () => {
    const pos = TestBed.inject(PosService);
    chargeSale(pos, 0, 1, 'efectivo'); // $2.600

    const component = TestBed.createComponent(CierreCajaComponent).componentInstance;
    component.openConfirm();

    expect(component.cuadraturaBoletas()).toHaveLength(0);
    component.setEfectivoContado('2600');
    expect(component.puedeConfirmarCierre()).toBe(true);
  });
  it('shows folio, fecha and medio de pago for each sale in the shift history (AC: historial de ventas)', () => {
    const pos = TestBed.inject(PosService);
    chargeSale(pos, 0, 1, 'efectivo');

    const component = TestBed.createComponent(CierreCajaComponent).componentInstance;
    const venta = component.ventasPorMetodo().find((g) => g.key === 'efectivo')!.ventas[0];

    expect(venta.ticketFolio).toBe('TK-999');
    expect(component.medioPagoLabel(venta)).toBe('Efectivo');
    expect(component.formatFecha(venta.fecha)).toContain(':');
  });

  it('filters the shift history by product name', () => {
    const pos = TestBed.inject(PosService);
    chargeSale(pos, 0, 1, 'efectivo'); // Café Espresso Doble
    chargeSale(pos, 1, 1, 'credito'); // Cappuccino Italiano

    const component = TestBed.createComponent(CierreCajaComponent).componentInstance;
    component.setHistorialQuery('espresso');

    const filtrado = component.ventasPorMetodoFiltradas();
    expect(filtrado.find((g) => g.key === 'efectivo')?.ventas).toHaveLength(1);
    expect(filtrado.find((g) => g.key === 'credito')?.ventas).toHaveLength(0);
  });

  it('filters the shift history by medio de pago label', () => {
    const pos = TestBed.inject(PosService);
    chargeSale(pos, 0, 1, 'efectivo');
    chargeSale(pos, 1, 1, 'credito');

    const component = TestBed.createComponent(CierreCajaComponent).componentInstance;
    component.setHistorialQuery('crédito');

    const filtrado = component.ventasPorMetodoFiltradas();
    expect(filtrado.find((g) => g.key === 'credito')?.ventas).toHaveLength(1);
    expect(filtrado.find((g) => g.key === 'efectivo')?.ventas).toHaveLength(0);
  });

  it('reports no results when the search matches nothing', () => {
    const pos = TestBed.inject(PosService);
    chargeSale(pos, 0, 1, 'efectivo');

    const component = TestBed.createComponent(CierreCajaComponent).componentInstance;
    expect(component.hayResultadosHistorial()).toBe(true);

    component.setHistorialQuery('producto inexistente');
    expect(component.hayResultadosHistorial()).toBe(false);
  });
});
