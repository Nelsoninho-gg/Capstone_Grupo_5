import { permisoIngreso, SucursalIngreso } from './permiso-ingreso';

const SUCURSALES: SucursalIngreso[] = [
  { id: 3, nombre: 'Viña del Mar' },
  { id: 1, nombre: 'Providencia' },
  { id: 2, nombre: 'Concepción' },
];

function usuario(rol: 'admin' | 'bodeguero' | 'cajero', sucursalId: number | null, sucursalNombre = '') {
  return { rol, sucursalId, sucursalNombre };
}

describe('permisoIngreso', () => {
  it('lets an admin choose any active branch, sorted by name', () => {
    const permiso = permisoIngreso(usuario('admin', null), SUCURSALES);

    expect(permiso).toEqual({
      puede: true,
      fija: false,
      opciones: [
        { id: 2, nombre: 'Concepción' },
        { id: 1, nombre: 'Providencia' },
        { id: 3, nombre: 'Viña del Mar' },
      ],
      porDefecto: null,
    });
  });

  it('preselects the admin own branch when it is active', () => {
    const permiso = permisoIngreso(usuario('admin', 3), SUCURSALES);

    expect(permiso.puede && permiso.porDefecto).toBe(3);
  });

  it('does not preselect the admin own branch when it is inactive', () => {
    const permiso = permisoIngreso(usuario('admin', 9), SUCURSALES);

    expect(permiso.puede && permiso.porDefecto).toBeNull();
  });

  it('preselects the only branch when there is just one', () => {
    const permiso = permisoIngreso(usuario('admin', null), [{ id: 5, nombre: 'Única' }]);

    expect(permiso.puede && permiso.porDefecto).toBe(5);
  });

  it('blocks an admin when there are no active branches', () => {
    const permiso = permisoIngreso(usuario('admin', null), []);

    expect(permiso).toEqual({
      puede: false,
      motivo: 'No hay sucursales activas donde ingresar la factura. Activa o crea una sucursal primero.',
    });
  });

  it('limits a warehouse user to their own branch, without a choice', () => {
    const permiso = permisoIngreso(usuario('bodeguero', 1, 'Providencia'), SUCURSALES);

    expect(permiso).toEqual({
      puede: true,
      fija: true,
      opciones: [{ id: 1, nombre: 'Providencia' }],
      porDefecto: 1,
    });
  });

  it('does not offer other branches to a warehouse user even if more are active', () => {
    const permiso = permisoIngreso(usuario('bodeguero', 2, 'Concepción'), SUCURSALES);

    expect(permiso.puede && permiso.opciones.map((s) => s.id)).toEqual([2]);
  });

  it('blocks a warehouse user without an assigned branch', () => {
    const permiso = permisoIngreso(usuario('bodeguero', null), SUCURSALES);

    expect(permiso.puede).toBe(false);
    expect(!permiso.puede && permiso.motivo).toContain('no tiene una sucursal asignada');
  });

  it('blocks a cashier', () => {
    expect(permisoIngreso(usuario('cajero', 1, 'Providencia'), SUCURSALES)).toEqual({
      puede: false,
      motivo: 'Tu rol no permite ingresar facturas.',
    });
  });

  it('blocks a session without a user', () => {
    expect(permisoIngreso(null, SUCURSALES)).toEqual({
      puede: false,
      motivo: 'Inicia sesión para ingresar facturas.',
    });
  });
});
