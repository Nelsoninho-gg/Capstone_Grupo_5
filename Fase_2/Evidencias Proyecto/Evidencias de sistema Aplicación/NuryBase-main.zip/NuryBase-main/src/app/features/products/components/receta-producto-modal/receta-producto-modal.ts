import { NgTemplateOutlet } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
  Component,
  HostListener,
  OnInit,
  computed,
  inject,
  input,
  output,
  signal,
} from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { catchError, finalize, forkJoin, of } from 'rxjs';
import { ProductoApi } from '../../../../core/api/productos-api.service';
import { IngredienteApi, IngredientesApiService } from '../../../../core/api/ingredientes-api.service';
import {
  CambioRecetaApi,
  RecetaApi,
  RecetasApiService,
  VersionRecetaApi,
} from '../../../../core/api/recetas-api.service';
import { UnidadMedidaApi, UnidadesMedidaApiService } from '../../../../core/api/unidades-medida-api.service';

const formatoFechaVersion = new Intl.DateTimeFormat('es-CL', {
  day: '2-digit',
  month: '2-digit',
  year: 'numeric',
  hour: '2-digit',
  minute: '2-digit',
  hourCycle: 'h23',
});
const formatoCantidadVersion = new Intl.NumberFormat('es-CL', { maximumFractionDigits: 3 });

@Component({
  selector: 'app-receta-producto-modal',
  imports: [ReactiveFormsModule, NgTemplateOutlet],
  templateUrl: './receta-producto-modal.html',
  styleUrl: './receta-producto-modal.css',
})
export class RecetaProductoModal implements OnInit {
  readonly producto = input.required<ProductoApi>();
  readonly cerrar = output<void>();

  private readonly recetasApi = inject(RecetasApiService);
  private readonly ingredientesApi = inject(IngredientesApiService);
  private readonly unidadesMedidaApi = inject(UnidadesMedidaApiService);
  private readonly formBuilder = inject(FormBuilder);

  protected readonly cargando = signal(true);
  protected readonly error = signal<string | null>(null);
  protected readonly insumos = signal<RecetaApi[]>([]);
  protected readonly ingredientes = signal<IngredienteApi[]>([]);
  protected readonly unidadesMedida = signal<UnidadMedidaApi[]>([]);
  /** Historial de versiones (H2.5 T02); vacío si la base todavía no lo ofrece. */
  protected readonly versiones = signal<VersionRecetaApi[]>([]);
  protected readonly versionActual = computed(() => this.versiones()[0] ?? null);
  protected readonly versionesAnteriores = computed(() => this.versiones().slice(1));

  protected readonly agregando = signal(false);
  protected readonly errorAgregar = signal<string | null>(null);
  protected readonly guardandoIds = signal<ReadonlySet<number>>(new Set());
  protected readonly eliminandoIds = signal<ReadonlySet<number>>(new Set());
  protected readonly errorPorFila = signal<ReadonlyMap<number, string>>(new Map());
  /**
   * Insumo que se pidió quitar cuando era el último (H5.3 T05): sin insumos el producto deja de
   * tener receta y se vende descontando su propio stock, así que se pide confirmar.
   */
  protected readonly confirmarQuitarUltimo = signal<number | null>(null);
  protected readonly cantidadesEditadas = signal<ReadonlyMap<number, string>>(new Map());

  protected readonly formularioAgregar = this.formBuilder.nonNullable.group({
    ingrediente_id: this.formBuilder.control<number | null>(null, Validators.required),
    cantidad_necesaria: ['', Validators.required],
  });

  private readonly ingredientesPorId = computed(() => {
    const mapa = new Map<number, IngredienteApi>();
    for (const ingrediente of this.ingredientes()) {
      mapa.set(ingrediente.id, ingrediente);
    }
    return mapa;
  });

  private readonly unidadesPorId = computed(() => {
    const mapa = new Map<number, UnidadMedidaApi>();
    for (const unidad of this.unidadesMedida()) {
      mapa.set(unidad.id, unidad);
    }
    return mapa;
  });

  /** Insumos de la receta con los datos del ingrediente y la unidad ya resueltos para mostrar. */
  protected readonly filasInsumos = computed(() =>
    this.insumos().map((receta) => {
      const ingrediente = this.ingredientesPorId().get(receta.ingrediente_id);
      const unidad = this.unidadesPorId().get(receta.unidad_id);
      return {
        receta,
        nombreIngrediente: ingrediente?.nombre ?? 'Insumo desconocido',
        inactivo: ingrediente !== undefined && !ingrediente.activo,
        unidadTexto: unidad ? `${unidad.nombre} (${unidad.abreviatura})` : 'Unidad desconocida',
      };
    }),
  );

  /**
   * Solo se pueden agregar insumos activos (H3.3 T07; la base también lo exige) que todavía no
   * estén en la receta (UNIQUE producto+ingrediente).
   */
  protected readonly ingredientesDisponibles = computed(() => {
    const yaAgregados = new Set(this.insumos().map((receta) => receta.ingrediente_id));
    return this.ingredientes().filter(
      (ingrediente) => ingrediente.activo && !yaAgregados.has(ingrediente.id),
    );
  });
  protected readonly hayIngredientesActivos = computed(() =>
    this.ingredientes().some((ingrediente) => ingrediente.activo),
  );

  protected unidadDe(ingrediente: IngredienteApi): string {
    const unidad = this.unidadesPorId().get(ingrediente.unidad_id);
    return unidad ? `${unidad.nombre} (${unidad.abreviatura})` : 'unidad desconocida';
  }

  // El valor de un FormControl no es una señal: sin este puente, el
  // computed de abajo nunca se volvería a recalcular al elegir un insumo.
  private readonly ingredienteIdSeleccionado = toSignal(
    this.formularioAgregar.controls.ingrediente_id.valueChanges,
    { initialValue: this.formularioAgregar.controls.ingrediente_id.value },
  );

  protected readonly unidadIngredienteSeleccionado = computed(() => {
    const id = this.ingredienteIdSeleccionado();
    if (id === null) return null;
    const ingrediente = this.ingredientesPorId().get(id);
    if (!ingrediente) return null;
    return this.unidadesPorId().get(ingrediente.unidad_id) ?? null;
  });

  ngOnInit(): void {
    this.cargarDatos();
  }

  protected cargarDatos(): void {
    this.cargando.set(true);
    this.error.set(null);
    forkJoin({
      insumos: this.recetasApi.listarPorProducto(this.producto().id),
      // Todos, también los inactivos: una receta anterior puede tener un insumo que después se
      // desactivó y debe verse con su nombre. Para agregar solo se ofrecen los activos (H3.3 T07).
      ingredientes: this.ingredientesApi.listar(false),
      unidadesMedida: this.unidadesMedidaApi.listar(),
    }).subscribe({
      next: ({ insumos, ingredientes, unidadesMedida }) => {
        this.insumos.set(insumos);
        this.ingredientes.set(ingredientes);
        this.unidadesMedida.set(unidadesMedida);
        this.cantidadesEditadas.set(
          new Map(insumos.map((receta) => [receta.id, String(receta.cantidad_necesaria)])),
        );
        this.cargando.set(false);
        this.cargarVersiones();
      },
      error: () => {
        this.error.set(
          'No pudimos cargar la receta de este producto. Revisa la conexión e inténtalo nuevamente.',
        );
        this.cargando.set(false);
      },
    });
  }

  @HostListener('document:keydown.escape')
  protected cerrarModal(): void {
    this.cerrar.emit();
  }

  protected agregarInsumo(): void {
    if (this.agregando()) return;
    this.errorAgregar.set(null);
    this.formularioAgregar.markAllAsTouched();

    const valores = this.formularioAgregar.getRawValue();
    const ingredienteId = valores.ingrediente_id;
    const cantidad = this.parsearCantidad(valores.cantidad_necesaria);

    if (ingredienteId === null) {
      this.errorAgregar.set('Selecciona un insumo.');
      return;
    }
    const ingrediente = this.ingredientesPorId().get(ingredienteId);
    if (!ingrediente) {
      this.errorAgregar.set('El insumo seleccionado ya no está disponible.');
      return;
    }
    if (cantidad === null) {
      this.errorAgregar.set('Ingresa una cantidad mayor a 0, con hasta 3 decimales.');
      return;
    }

    this.agregando.set(true);
    this.recetasApi
      .agregar({
        producto_id: this.producto().id,
        ingrediente_id: ingredienteId,
        cantidad_necesaria: cantidad,
        unidad_id: ingrediente.unidad_id,
      })
      .pipe(finalize(() => this.agregando.set(false)))
      .subscribe({
        next: (creada) => {
          this.insumos.update((lista) => [...lista, creada]);
          this.cantidadesEditadas.update((mapa) => {
            const actualizado = new Map(mapa);
            actualizado.set(creada.id, String(creada.cantidad_necesaria));
            return actualizado;
          });
          this.formularioAgregar.reset({ ingrediente_id: null, cantidad_necesaria: '' });
          this.cargarVersiones();
        },
        error: (error) => this.errorAgregar.set(this.mensajeError(error, 'agregar')),
      });
  }

  protected valorCantidad(id: number): string {
    return this.cantidadesEditadas().get(id) ?? '';
  }

  protected actualizarValorCantidad(id: number, valor: string): void {
    this.cantidadesEditadas.update((mapa) => {
      const actualizado = new Map(mapa);
      actualizado.set(id, valor);
      return actualizado;
    });
  }

  protected cambioPendiente(receta: RecetaApi): boolean {
    const valor = this.parsearCantidad(this.valorCantidad(receta.id));
    return valor !== null && valor !== Number(receta.cantidad_necesaria);
  }

  protected guardandoFila(id: number): boolean {
    return this.guardandoIds().has(id);
  }

  protected eliminandoFila(id: number): boolean {
    return this.eliminandoIds().has(id);
  }

  protected errorDeFila(id: number): string | null {
    return this.errorPorFila().get(id) ?? null;
  }

  protected guardarCantidad(receta: RecetaApi): void {
    if (this.guardandoFila(receta.id)) return;
    const cantidad = this.parsearCantidad(this.valorCantidad(receta.id));
    if (cantidad === null) {
      this.setErrorFila(receta.id, 'Ingresa una cantidad mayor a 0, con hasta 3 decimales.');
      return;
    }
    this.setErrorFila(receta.id, null);
    this.marcarGuardando(receta.id, true);
    this.recetasApi
      .actualizar(receta.id, { cantidad_necesaria: cantidad })
      .pipe(finalize(() => this.marcarGuardando(receta.id, false)))
      .subscribe({
        next: (actualizada) => {
          this.insumos.update((lista) =>
            lista.map((actual) => (actual.id === actualizada.id ? actualizada : actual)),
          );
          this.cargarVersiones();
        },
        error: (error) => this.setErrorFila(receta.id, this.mensajeError(error, 'actualizar')),
      });
  }

  protected quitarInsumo(receta: RecetaApi): void {
    if (this.eliminandoFila(receta.id)) return;
    if (this.insumos().length === 1 && this.confirmarQuitarUltimo() !== receta.id) {
      this.confirmarQuitarUltimo.set(receta.id);
      return;
    }
    this.confirmarQuitarUltimo.set(null);
    this.setErrorFila(receta.id, null);
    this.marcarEliminando(receta.id, true);
    this.recetasApi
      .eliminar(receta.id)
      .pipe(finalize(() => this.marcarEliminando(receta.id, false)))
      .subscribe({
        next: () => {
          this.insumos.update((lista) => lista.filter((actual) => actual.id !== receta.id));
          this.cargarVersiones();
        },
        error: (error) => this.setErrorFila(receta.id, this.mensajeError(error, 'quitar')),
      });
  }

  /** "Pan 50 → 100 g", "+ Palta 50 g" o "− Queso 30 g". */
  protected textoCambio(cambio: CambioRecetaApi): string {
    const unidad = cambio.unidad ? ` ${cambio.unidad}` : '';
    const cantidad = (valor: number | null) => formatoCantidadVersion.format(Number(valor));
    if (cambio.tipo === 'agregado') return `+ ${cambio.ingrediente} ${cantidad(cambio.despues)}${unidad}`;
    if (cambio.tipo === 'quitado') return `− ${cambio.ingrediente} ${cantidad(cambio.antes)}${unidad}`;
    return `${cambio.ingrediente} ${cantidad(cambio.antes)} → ${cantidad(cambio.despues)}${unidad}`;
  }

  protected fechaVersion(version: VersionRecetaApi): string {
    return formatoFechaVersion.format(new Date(version.vigente_desde)).replace(',', '');
  }

  /**
   * Cada cambio en la receta crea una versión en la base: se vuelve a pedir el historial.
   * Si falla (por ejemplo, sin la migración de H2.5 T02) la línea de versión no se muestra.
   */
  private cargarVersiones(): void {
    this.recetasApi
      .listarVersiones(this.producto().id)
      .pipe(catchError(() => of<VersionRecetaApi[]>([])))
      .subscribe((versiones) => this.versiones.set(versiones));
  }

  /**
   * Cantidad positiva en la unidad base del ingrediente, con hasta 3 decimales: la columna es
   * NUMERIC(12,3) y con más decimales la base redondearía sin avisar (H5.3 T05).
   */
  private parsearCantidad(valor: string): number | null {
    const normalizado = valor.trim().replace(',', '.');
    if (!/^\d+(\.\d{1,3})?$/.test(normalizado)) return null;
    const numero = Number(normalizado);
    if (!Number.isFinite(numero) || numero <= 0) return null;
    return numero;
  }

  private marcarGuardando(id: number, activo: boolean): void {
    this.guardandoIds.update((ids) => {
      const actualizado = new Set(ids);
      activo ? actualizado.add(id) : actualizado.delete(id);
      return actualizado;
    });
  }

  private marcarEliminando(id: number, activo: boolean): void {
    this.eliminandoIds.update((ids) => {
      const actualizado = new Set(ids);
      activo ? actualizado.add(id) : actualizado.delete(id);
      return actualizado;
    });
  }

  private setErrorFila(id: number, mensaje: string | null): void {
    this.errorPorFila.update((mapa) => {
      const actualizado = new Map(mapa);
      if (mensaje) {
        actualizado.set(id, mensaje);
      } else {
        actualizado.delete(id);
      }
      return actualizado;
    });
  }

  private mensajeError(error: unknown, accion: 'agregar' | 'actualizar' | 'quitar'): string {
    if (error instanceof HttpErrorResponse) {
      if (error.status === 409 && accion === 'agregar') {
        return 'Ese insumo ya está en la receta de este producto.';
      }
      if (error.status === 400) {
        // Mensaje de la base: unidad distinta a la del ingrediente, ingrediente inactivo,
        // cantidad no positiva (H2.5 T01, H3.3 T07, H5.3 T05).
        const cuerpo = error.error as { message?: unknown } | null;
        return typeof cuerpo?.message === 'string' && cuerpo.message.trim()
          ? cuerpo.message
          : 'Revisa el insumo y la cantidad: debe ser mayor a 0.';
      }
      if (error.status === 401 || error.status === 403) {
        return 'Tu sesión no tiene permisos para modificar la receta.';
      }
      if (error.status === 404) {
        return 'Ese insumo ya no está en la receta. Actualiza la pantalla e inténtalo nuevamente.';
      }
    }
    return 'No pudimos guardar los cambios. Revisa la conexión e inténtalo nuevamente.';
  }
}
