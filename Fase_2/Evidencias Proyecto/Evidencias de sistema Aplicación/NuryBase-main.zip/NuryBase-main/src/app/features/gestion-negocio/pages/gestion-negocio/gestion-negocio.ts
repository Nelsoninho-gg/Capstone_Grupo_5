import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { finalize } from 'rxjs';
import {
  UsuarioActualizacion,
  UsuarioApi,
  UsuarioCreacion,
  UsuariosApiService,
} from '../../../../core/api/usuarios-api.service';
import { SucursalApi, SucursalesApiService } from '../../../../core/api/sucursales-api.service';
import { BusinessTabs } from '../../components/business-tabs/business-tabs';

type RolNuevoUsuario = 'admin' | 'cajero' | 'bodeguero';

/**
 * El cajero vende y el bodeguero administra el stock de un local fijo, así que ambos
 * necesitan una sucursal (H3.4 T08). El administrador puede quedar sin sucursal.
 */
function requiereSucursal(rol: RolNuevoUsuario): boolean {
  return rol === 'cajero' || rol === 'bodeguero';
}

@Component({
  imports: [ReactiveFormsModule, BusinessTabs],
  selector: 'app-gestion-negocio',
  styleUrl: './gestion-negocio.css',
  templateUrl: './gestion-negocio.html',
})
export class GestionNegocio implements OnInit {
  private readonly usuariosApi = inject(UsuariosApiService);
  private readonly sucursalesApi = inject(SucursalesApiService);
  private readonly formBuilder = inject(FormBuilder);

  protected readonly requiereSucursal = requiereSucursal;
  protected readonly usuarios = signal<UsuarioApi[]>([]);
  private readonly todasSucursales = signal<SucursalApi[]>([]);
  protected readonly sucursales = computed(() =>
    this.todasSucursales().filter((sucursal) => sucursal.activo)
      .sort((a, b) => a.nombre.localeCompare(b.nombre, 'es')),
  );
  protected readonly cargando = signal(true);
  protected readonly error = signal<string | null>(null);
  protected readonly formularioAbierto = signal(false);
  protected readonly guardando = signal(false);
  protected readonly usuarioEnEdicion = signal<UsuarioApi | null>(null);
  protected readonly usuarioPorEliminar = signal<UsuarioApi | null>(null);
  protected readonly eliminando = signal(false);
  protected readonly errorEliminacion = signal<string | null>(null);
  protected readonly idsActualizandoEstado = signal<ReadonlySet<number>>(new Set<number>());
  protected readonly errorFormulario = signal<string | null>(null);
  protected readonly errorAccion = signal<string | null>(null);
  protected readonly mensajeExito = signal<string | null>(null);
  protected readonly formulario = this.formBuilder.nonNullable.group({
    nombre: ['', [Validators.required, Validators.maxLength(120)]],
    identificador_acceso: ['', [Validators.required, Validators.maxLength(120)]],
    contrasena: ['', [Validators.required, Validators.minLength(4)]],
    rol: ['cajero' as RolNuevoUsuario, Validators.required],
    sucursal_id: [null as number | null],
    debe_cambiar_password: [true],
    activo: [true],
  });

  ngOnInit(): void {
    this.cargarUsuarios();
    this.sucursalesApi.listar().subscribe({
      next: (sucursales) => this.todasSucursales.set(sucursales),
      error: (error) => console.error('No se pudieron cargar las sucursales', error),
    });
  }

  protected cargarUsuarios(): void {
    this.cargando.set(true);
    this.error.set(null);
    this.usuariosApi.listar().subscribe({
      next: (usuarios) => {
        this.usuarios.set(usuarios);
        this.cargando.set(false);
      },
      error: (error) => {
        console.error('No se pudieron cargar los usuarios', error);
        this.error.set('No pudimos cargar los usuarios. Revisa la conexión con la base de datos.');
        this.cargando.set(false);
      },
    });
  }

  protected abrirFormulario(): void {
    this.usuarioEnEdicion.set(null);
    this.formulario.controls.contrasena.setValidators([Validators.required, Validators.minLength(4)]);
    this.formulario.controls.contrasena.updateValueAndValidity();
    this.errorFormulario.set(null);
    this.mensajeExito.set(null);
    this.errorEliminacion.set(null);
    this.errorAccion.set(null);
    this.formularioAbierto.set(true);
  }

  protected editarUsuario(usuario: UsuarioApi): void {
    this.usuarioEnEdicion.set(usuario);
    this.formulario.controls.contrasena.clearValidators();
    this.formulario.controls.contrasena.updateValueAndValidity();
    this.formulario.reset({
      nombre: usuario.nombre,
      identificador_acceso: usuario.identificador_acceso,
      contrasena: '',
      rol: usuario.rol === 'administrador' ? 'admin' : usuario.rol as RolNuevoUsuario,
      sucursal_id: usuario.sucursal_id,
      debe_cambiar_password: usuario.debe_cambiar_password,
      activo: usuario.activo,
    });
    this.errorFormulario.set(null);
    this.errorAccion.set(null);
    this.mensajeExito.set(null);
    this.formularioAbierto.set(true);
  }

  protected confirmarEliminacion(usuario: UsuarioApi): void {
    this.errorEliminacion.set(null);
    this.errorAccion.set(null);
    this.mensajeExito.set(null);
    this.usuarioPorEliminar.set(usuario);
  }

  protected estadoActualizando(usuarioId: number): boolean {
    return this.idsActualizandoEstado().has(usuarioId);
  }

  protected alternarEstadoUsuario(usuario: UsuarioApi): void {
    if (this.estadoActualizando(usuario.id)) return;

    this.mensajeExito.set(null);
    this.errorAccion.set(null);
    this.idsActualizandoEstado.update((ids) => new Set(ids).add(usuario.id));

    this.usuariosApi
      .actualizar(usuario.id, { activo: !usuario.activo })
      .pipe(
        finalize(() => {
          this.idsActualizandoEstado.update((ids) => {
            const actualizados = new Set(ids);
            actualizados.delete(usuario.id);
            return actualizados;
          });
        }),
      )
      .subscribe({
        next: (actualizado) => {
          this.usuarios.update((usuarios) =>
            usuarios.map((actual) => (actual.id === actualizado.id ? actualizado : actual)),
          );
          this.mensajeExito.set(
            `${actualizado.nombre} ahora está ${actualizado.activo ? 'activo' : 'deshabilitado'}.`,
          );
        },
        error: (error) => {
          console.error('No se pudo cambiar el estado del usuario', error);
          this.errorAccion.set('No pudimos cambiar el estado del usuario. Inténtalo nuevamente.');
        },
      });
  }

  protected cancelarEliminacion(): void {
    if (this.eliminando()) return;
    this.usuarioPorEliminar.set(null);
    this.errorEliminacion.set(null);
  }

  protected eliminarUsuario(): void {
    const usuario = this.usuarioPorEliminar();
    if (!usuario || this.eliminando()) return;

    this.errorEliminacion.set(null);
    this.errorAccion.set(null);
    this.eliminando.set(true);
    this.usuariosApi
      .eliminar(usuario.id)
      .pipe(finalize(() => this.eliminando.set(false)))
      .subscribe({
        next: () => {
          this.usuarios.update((usuarios) => usuarios.filter((actual) => actual.id !== usuario.id));
          this.usuarioPorEliminar.set(null);
          this.mensajeExito.set(`Se eliminó el usuario ${usuario.nombre}.`);
        },
        error: (error) => {
          console.error('No se pudo eliminar el usuario', error);
          this.errorEliminacion.set(this.mensajeErrorEliminacion(error));
        },
      });
  }

  protected cerrarFormulario(): void {
    if (this.guardando()) return;
    this.formularioAbierto.set(false);
    this.usuarioEnEdicion.set(null);
    this.formulario.controls.contrasena.setValidators([Validators.required, Validators.minLength(4)]);
    this.formulario.controls.contrasena.updateValueAndValidity();
    this.errorFormulario.set(null);
    this.formulario.reset({
      nombre: '',
      identificador_acceso: '',
      contrasena: '',
      rol: 'cajero',
      sucursal_id: null,
      debe_cambiar_password: true,
      activo: true,
    });
  }

  protected guardarUsuario(): void {
    const usuario = this.usuarioEnEdicion();
    if (usuario) {
      this.actualizarUsuario(usuario);
      return;
    }

    this.crearUsuario();
  }

  private actualizarUsuario(usuario: UsuarioApi): void {
    this.formulario.markAllAsTouched();
    this.errorFormulario.set(null);

    const value = this.formulario.getRawValue();
    if (this.formulario.invalid) return;
    if (!value.nombre.trim() || !value.identificador_acceso.trim()) {
      this.errorFormulario.set('Completa el nombre y el usuario de acceso.');
      return;
    }
    if (requiereSucursal(value.rol) && value.sucursal_id === null) {
      this.errorFormulario.set(`Selecciona una sucursal para el usuario ${value.rol}.`);
      return;
    }

    const cambios: UsuarioActualizacion = {
      nombre: value.nombre.trim(),
      identificador_acceso: value.identificador_acceso.trim(),
      rol: value.rol,
      sucursal_id: value.sucursal_id,
      debe_cambiar_password: value.debe_cambiar_password,
      activo: value.activo,
    };

    this.guardando.set(true);
    this.usuariosApi
      .actualizar(usuario.id, cambios)
      .pipe(finalize(() => this.guardando.set(false)))
      .subscribe({
        next: (actualizado) => {
          this.usuarios.update((usuarios) =>
            usuarios.map((actual) => (actual.id === actualizado.id ? actualizado : actual)),
          );
          this.mensajeExito.set(`Se actualizaron los datos de ${actualizado.nombre}.`);
          this.cerrarFormulario();
        },
        error: (error) => {
          console.error('No se pudo actualizar el usuario', error);
          this.errorFormulario.set(this.mensajeErrorActualizacion(error));
        },
      });
  }

  protected crearUsuario(): void {
    this.formulario.markAllAsTouched();
    this.errorFormulario.set(null);

    const value = this.formulario.getRawValue();
    if (this.formulario.invalid) return;
    if (!value.nombre.trim() || !value.identificador_acceso.trim()) {
      this.errorFormulario.set('Completa el nombre y el usuario de acceso.');
      return;
    }
    if (requiereSucursal(value.rol) && value.sucursal_id === null) {
      this.errorFormulario.set(`Selecciona una sucursal para el usuario ${value.rol}.`);
      return;
    }

    const nuevoUsuario: UsuarioCreacion = {
      nombre: value.nombre.trim(),
      identificador_acceso: value.identificador_acceso.trim(),
      contrasena: value.contrasena,
      rol: value.rol,
      sucursal_id: value.sucursal_id,
      debe_cambiar_password: value.debe_cambiar_password,
      activo: value.activo,
    };

    this.guardando.set(true);
    this.usuariosApi
      .crear(nuevoUsuario)
      .pipe(finalize(() => this.guardando.set(false)))
      .subscribe({
        next: (usuario) => {
          this.usuarios.update((usuarios) => [...usuarios, usuario].sort((a, b) => a.id - b.id));
          this.mensajeExito.set('Usuario creado correctamente.');
          this.cerrarFormulario();
        },
        error: (error) => {
          console.error('No se pudo crear el usuario', error);
          this.errorFormulario.set(this.mensajeErrorCreacion(error));
        },
      });
  }

  private mensajeErrorCreacion(error: unknown): string {
    if (error instanceof HttpErrorResponse && error.status === 404) {
      return 'El endpoint de creación aún no está instalado en la API. Aplica la migración de usuarios y recarga el esquema de PostgREST.';
    }

    if (error instanceof HttpErrorResponse && error.status === 409) {
      return 'Ese usuario de acceso ya está registrado. Elige otro identificador.';
    }

    return 'No pudimos crear el usuario. Revisa los datos e inténtalo nuevamente.';
  }

  private mensajeErrorActualizacion(error: unknown): string {
    if (error instanceof HttpErrorResponse && error.status === 409) {
      return 'Ese usuario de acceso ya está registrado. Elige otro identificador.';
    }

    if (error instanceof HttpErrorResponse && error.status === 404) {
      return 'No encontramos el usuario para actualizar. Recarga el listado e inténtalo nuevamente.';
    }

    return 'No pudimos guardar los cambios. Revisa los datos e inténtalo nuevamente.';
  }

  private mensajeErrorEliminacion(error: unknown): string {
    if (error instanceof HttpErrorResponse && error.status === 409) {
      return 'No se puede eliminar: este usuario tiene ventas u otros registros asociados. La fila se conserva.';
    }

    return 'No se pudo eliminar el usuario. Revisa la conexión e inténtalo nuevamente.';
  }

  protected nombreSucursal(sucursalId: number | null): string {
    if (sucursalId === null) return 'Sin sucursal asignada';
    return this.todasSucursales().find((sucursal) => sucursal.id === sucursalId)?.nombre
      ?? 'Sucursal no disponible';
  }

  protected nombreRol(rol: UsuarioApi['rol']): string {
    switch (rol) {
      case 'admin':
      case 'administrador':
        return 'Administrador';
      case 'bodeguero':
        return 'Bodeguero';
      case 'cajero':
        return 'Cajero';
    }
  }
}
