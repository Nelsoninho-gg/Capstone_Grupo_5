import { decodificarXml, leerFacturaXml, normalizarRut } from './lector-dte';

// Copia del XML de ejemplo (DTE_DOWN104920152026-10-15.xml, folio 56631070) con
// los mismos montos y líneas. El receptor y el transporte se reemplazaron por
// datos ficticios, y se omiten la firma y el timbre, que el lector no usa.
const LINEAS: [codigo: string, nombre: string, cantidad: number, precio: number][] = [
  ['2779', '2779Pan Blanco Sandwich 1p 700g Bolsa HO', 16, 2029],
  ['5380', '5380 Pinguino 2p 80g MLA', 20, 647],
  ['973598', '973598 Pinguinos CookiesCream 2p 80g FLOW MLA', 3, 647],
  ['503999', '503999 Pinguino Triple Choco 2p 80g BOLSA MLA', 20, 647],
  ['23355', '23355 Rayita Vaini 2p 60g MLA', 20, 485],
  ['24956', '24956 Gansito Termoformado 1p 50g MLA', 20, 518],
  ['25746', '25746 Laguito 2p 70g LDS', 20, 452],
  ['501601', '501601 Alfi SP 3p 60g BOLSA MLA', 20, 452],
  ['502664', '502664 Galleta Chocochip 1p 75g Dpy NUR', 16, 646],
  ['973631', '973631 Brownie Choco Almendra 1p 50g FLOW NUR', 12, 582],
  ['973628', '973628 Brownie Dulce de Leche 1p 44g FLOW NUR', 18, 517],
  ['502660', '502660Brownie Chip 1p 62g Bolsa NUR', 12, 517],
  ['502661', '502661Brownie Sin Azucar 1p 50g Bolsa NU', 12, 517],
  ['502659', '502659Brownie 1p 62g Bolsa NUR', 12, 517],
  ['502668', '502668Queque Marmol 1p 70g Bolsa NUR', 12, 452],
  ['40279', '40279 Mil Hojas 6p 280g ADP', 3, 1942],
  ['503716', '503716Magdalena Tres Leches 2p 100g FLOW', 10, 646],
];

const DETALLE = LINEAS.map(
  ([codigo, nombre, cantidad, precio], i) => `
        <Detalle>
          <NroLinDet>${i + 1}</NroLinDet>
          <CdgItem><TpoCodigo /><VlrCodigo>${codigo}</VlrCodigo></CdgItem>
          <NmbItem>${nombre}</NmbItem>
          <DscItem />
          <QtyItem>${cantidad}</QtyItem>
          <PrcItem>${precio}</PrcItem>
          <MontoItem>${cantidad * precio}</MontoItem>
        </Detalle>`,
).join('');

const EJEMPLO = `<?xml version="1.0" encoding="ISO-8859-1"?>
<SetDTE>
  <DTE version="1.0">
    <Documento ID="F56631070T33">
      <Encabezado>
        <IdDoc>
          <TipoDTE>33</TipoDTE>
          <Folio>56631070</Folio>
          <FchEmis>2026-10-15</FchEmis>
          <FmaPago>1</FmaPago>
          <FchVenc>2026-10-15</FchVenc>
        </IdDoc>
        <Emisor>
          <RUTEmisor>82623500-4</RUTEmisor>
          <RznSoc>Ideal S.A</RznSoc>
          <DirOrigen>Avenida Tupungato, placilla de peñuelas. - 3130</DirOrigen>
          <CmnaOrigen>VIÑA DEL MAR</CmnaOrigen>
        </Emisor>
        <Receptor>
          <RUTRecep>11111111-1</RUTRecep>
          <RznSocRecep>RECEPTOR DE PRUEBA</RznSocRecep>
        </Receptor>
        <Totales>
          <MntNeto>161373</MntNeto>
          <MntBase>161373</MntBase>
          <TasaIVA>19</TasaIVA>
          <IVA>30663</IVA>
          <MntTotal>192036</MntTotal>
        </Totales>
      </Encabezado>${DETALLE}
      <Referencia>
        <NroLinRef>1</NroLinRef>
        <TpoDocRef>801</TpoDocRef>
        <FolioRef>188117</FolioRef>
        <FchRef>2026-10-15</FchRef>
        <RazonRef>ORDEN DE COMPRA</RazonRef>
      </Referencia>
    </Documento>
  </DTE>
</SetDTE>`;

/** Bytes en ISO-8859-1, como llega el archivo real (TextEncoder solo produce UTF-8). */
function latin1(texto: string): Uint8Array {
  return Uint8Array.from(texto, (caracter) => caracter.charCodeAt(0));
}

function leer(xml: string) {
  return leerFacturaXml(latin1(xml));
}

function errores(xml: string): string[] {
  const resultado = leer(xml);
  if (resultado.valida) throw new Error('Se esperaba una factura inválida');
  return resultado.errores;
}

describe('leerFacturaXml', () => {
  it('reads the header, totals and reference of the sample invoice', () => {
    const resultado = leer(EJEMPLO);
    if (!resultado.valida) throw new Error(resultado.errores.join(' '));

    expect(resultado.factura).toEqual(
      expect.objectContaining({
        tipo_documento: 33,
        folio: 56631070,
        rut_emisor: '82623500-4',
        rut_emisor_normalizado: '82623500-4',
        razon_social_emisor: 'Ideal S.A',
        rut_receptor: '11111111-1',
        fecha_emision: '2026-10-15',
        fecha_vencimiento: '2026-10-15',
        forma_pago: 1,
        orden_compra_referencia: '188117',
        monto_neto: 161373,
        monto_exento: 0,
        monto_iva: 30663,
        tasa_iva: 19,
        monto_total: 192036,
        detalle_incluye_iva: false,
      }),
    );
  });

  it('reads the 17 lines with their supplier code and amounts', () => {
    const resultado = leer(EJEMPLO);
    if (!resultado.valida) throw new Error(resultado.errores.join(' '));

    expect(resultado.factura.lineas).toHaveLength(17);
    expect(resultado.factura.lineas[0]).toEqual({
      numero_linea: 1,
      codigo_tipo: null,
      codigo_proveedor: '2779',
      descripcion: '2779Pan Blanco Sandwich 1p 700g Bolsa HO',
      cantidad: 16,
      precio_unitario: 2029,
      monto: 32464,
    });
    expect(resultado.factura.lineas.reduce((suma, linea) => suma + linea.monto, 0)).toBe(161373);
  });

  it('accepts the $2 VAT difference and the net-amount assumption as warnings only', () => {
    const resultado = leer(EJEMPLO);

    expect(resultado.valida).toBe(true);
    expect(resultado.avisos).toEqual([
      'El IVA informado ($30.663) difiere en $2 del 19 % del neto ($30.661).',
      'La factura no indica si las líneas incluyen IVA; se asumen netas.',
    ]);
  });

  it('reads documents that use the SII namespace', () => {
    const resultado = leer(EJEMPLO.replace('<SetDTE>', '<SetDTE xmlns="http://www.sii.cl/SiiDte">'));

    expect(resultado.valida).toBe(true);
  });

  it('marks the lines as VAT-included when IndMntBruto is 1', () => {
    const resultado = leer(EJEMPLO.replace('<FmaPago>', '<IndMntBruto>1</IndMntBruto><FmaPago>'));
    if (!resultado.valida) throw new Error(resultado.errores.join(' '));

    expect(resultado.factura.detalle_incluye_iva).toBe(true);
    expect(resultado.avisos).not.toContain('La factura no indica si las líneas incluyen IVA; se asumen netas.');
  });

  it('rejects a file that is not XML', () => {
    expect(errores('esto no es un xml')).toEqual(['El archivo no es un XML válido o está dañado.']);
  });

  it('rejects a damaged XML', () => {
    expect(errores(EJEMPLO.slice(0, 600))).toEqual(['El archivo no es un XML válido o está dañado.']);
  });

  it('rejects an XML without a tax document', () => {
    expect(errores('<?xml version="1.0"?><Otro />')).toEqual([
      'El archivo no contiene un documento tributario electrónico (DTE).',
    ]);
  });

  it('rejects a file with more than one document', () => {
    const dos = EJEMPLO.replace('</DTE>', '</DTE><DTE><Documento /></DTE>');

    expect(errores(dos)).toEqual(['El archivo contiene 2 documentos. Carga una factura a la vez.']);
  });

  it('rejects documents that are not type 33', () => {
    expect(errores(EJEMPLO.replace('<TipoDTE>33', '<TipoDTE>34'))).toEqual([
      'El documento es tipo 34. Solo se aceptan facturas electrónicas (tipo 33).',
    ]);
  });

  it('explains every missing header field at once', () => {
    const incompleto = EJEMPLO.replace('<TipoDTE>33</TipoDTE>', '')
      .replace('<Folio>56631070</Folio>', '')
      .replace('<FchEmis>2026-10-15</FchEmis>', '')
      .replace('<RUTEmisor>82623500-4</RUTEmisor>', '');

    expect(errores(incompleto)).toEqual([
      'No indica el tipo de documento (TipoDTE).',
      'El folio falta o no es un número válido.',
      'La fecha de emisión falta o no es válida.',
      'No indica el RUT del emisor.',
    ]);
  });

  it('rejects an issuer RUT with a wrong check digit', () => {
    expect(errores(EJEMPLO.replace('82623500-4', '82623500-5'))).toEqual([
      'El RUT del emisor (82623500-5) no es válido.',
    ]);
  });

  it('rejects an impossible issue date', () => {
    expect(errores(EJEMPLO.replace('<FchEmis>2026-10-15', '<FchEmis>2026-02-30'))).toEqual([
      'La fecha de emisión falta o no es válida.',
    ]);
  });

  it('rejects totals that do not add up', () => {
    expect(errores(EJEMPLO.replace('<MntTotal>192036', '<MntTotal>192000'))).toEqual([
      'Los totales no cuadran: neto, exento, IVA e impuestos suman $192.036, ' +
        'pero el total informado es $192.000.',
    ]);
  });

  it('rejects missing totals', () => {
    expect(errores(EJEMPLO.replace('<IVA>30663</IVA>', ''))).toEqual([
      'Falta el IVA o no es un número entero.',
    ]);
  });

  it('rejects lines without a positive quantity, price or amount', () => {
    const lineaMala = EJEMPLO.replace('<QtyItem>16</QtyItem>', '<QtyItem>0</QtyItem>')
      .replace('<PrcItem>647</PrcItem>', '')
      .replace('<MontoItem>1941</MontoItem>', '');

    expect(errores(lineaMala)).toEqual([
      'Línea 1: la cantidad falta o no es mayor que cero.',
      'Línea 2: falta el precio unitario.',
      'Línea 3: falta el monto de la línea.',
    ]);
  });

  it('rejects an invoice without lines', () => {
    expect(errores(EJEMPLO.replace(DETALLE, ''))).toEqual(['La factura no trae líneas de detalle.']);
  });

  it('warns when quantity × price does not match the line amount', () => {
    const resultado = leer(EJEMPLO.replace('<MontoItem>32464', '<MontoItem>32000'));

    expect(resultado.avisos).toContain(
      'Línea 1: cantidad × precio da $32.464, pero el monto informado es $32.000.',
    );
    expect(resultado.avisos).toContain(
      'La suma de las líneas ($160.909) no coincide con el neto ($161.373). ' +
        'Puede deberse a descuentos o recargos globales.',
    );
  });
});

describe('decodificarXml', () => {
  it('decodes ISO-8859-1 as declared, keeping ñ and accents', () => {
    const bytes = latin1('<?xml version="1.0" encoding="ISO-8859-1"?><a>Viña, Peñuelas, Valparaíso</a>');

    expect(decodificarXml(bytes)).toContain('Viña, Peñuelas, Valparaíso');
  });

  it('decodes UTF-8 when no encoding is declared', () => {
    const bytes = new TextEncoder().encode('<?xml version="1.0"?><a>Viña</a>');

    expect(decodificarXml(bytes)).toContain('Viña');
  });

  it('skips the UTF-8 byte order mark', () => {
    const bytes = new TextEncoder().encode('﻿<a>Viña</a>');

    expect(decodificarXml(bytes)).toBe('<a>Viña</a>');
  });

  it('reports an unknown encoding', () => {
    const bytes = latin1('<?xml version="1.0" encoding="NO-EXISTE"?><a />');

    expect(() => decodificarXml(bytes)).toThrow('El archivo declara una codificación desconocida (NO-EXISTE).');
  });
});

describe('normalizarRut', () => {
  it.each([
    ['82623500-4', '82623500-4'],
    ['82.623.500-4', '82623500-4'],
    ['826235004', '82623500-4'],
    [' 82623500-4 ', '82623500-4'],
    ['11111111-1', '11111111-1'],
    ['12.345.678-5', '12345678-5'],
    ['6-k', '6-K'],
    ['0082623500-4', '82623500-4'],
  ])('normalizes %s', (rut, esperado) => {
    expect(normalizarRut(rut)).toBe(esperado);
  });

  it.each(['82623500-5', '82623500', 'ABC', '', '123456789-0'])('rejects %s', (rut) => {
    expect(normalizarRut(rut)).toBeNull();
  });
});
