import {
  Component,
  ElementRef,
  HostListener,
  OnDestroy,
  OnInit,
  ViewChild,
  computed,
  inject,
  linkedSignal,
  signal,
} from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { finalize } from 'rxjs';
import { BarcodeScanner } from '../../../../core/services/barcode-scanner';
import {
  ProductoApi,
  ProductoCreacion,
  ProductosApiService,
} from '../../../../core/api/productos-api.service';
import { RecetaProductoModal } from '../../components/receta-producto-modal/receta-producto-modal';
import { IngredientesMaestro } from '../../components/ingredientes-maestro/ingredientes-maestro';
import { claveCodigo, claveNombre, limpiarNombre } from '../../models/catalogo.model';
import { AuthService } from '../../../auth/services/auth.service';

type VistaMaestro = 'productos' | 'ingredientes';

@Component({
  imports: [ReactiveFormsModule, RecetaProductoModal, IngredientesMaestro],
  selector: 'app-product-master',
  styleUrl: './product-master.css',
  templateUrl: './product-master.html',
})
export class ProductMaster implements OnInit, OnDestroy {
  private readonly productosApi = inject(ProductosApiService);
  private readonly formBuilder = inject(FormBuilder);
  private readonly barcodeScanner = inject(BarcodeScanner);
  private readonly authService = inject(AuthService);
  protected readonly esAdmin = computed(() => this.authService.currentUser()?.rol === 'admin');
  protected readonly puedeEditar = computed(() =>
    ['admin', 'cajero'].includes(this.authService.currentUser()?.rol ?? ''),
  );
  /**
   * Pestaña Ingredientes (materias primas, antes en Inventario → Catálogo): admin y bodeguero.
   * El bodeguero ve los productos sin editarlos; el cajero solo ve Productos.
   */
  protected readonly puedeVerIngredientes = computed(() =>
    ['admin', 'bodeguero'].includes(this.authService.currentUser()?.rol ?? ''),
  );
  private readonly ruta = inject(ActivatedRoute, { optional: true });
  private readonly router = inject(Router);
  /** La pestaña viaja en la URL (?vista=ingredientes) para enlaces y recargas. */
  protected readonly vista = signal<VistaMaestro>(
    this.ruta?.snapshot.queryParamMap.get('vista') === 'ingredientes' && this.puedeVerIngredientes()
      ? 'ingredientes'
      : 'productos',
  );

  @ViewChild('productBarcodeVideo') private productBarcodeVideo?: ElementRef<HTMLVideoElement>;

  protected readonly products = signal<ProductoApi[]>([]);
  protected readonly searchQuery = signal('');
  protected readonly zeroPriceFilterActive = signal(false);
  protected readonly categoriaFilter = signal('');
  protected readonly estadoFilter = signal<'todos' | 'activos' | 'inactivos'>('todos');
  protected readonly loading = signal(true);
  protected readonly error = signal<string | null>(null);
  protected readonly selectedProduct = signal<ProductoApi | null>(null);
  protected readonly creatingProduct = signal(false);
  protected readonly saving = signal(false);
  protected readonly saveError = signal<string | null>(null);
  protected readonly successMessage = signal<string | null>(null);
  protected readonly actionError = signal<string | null>(null);
  protected readonly updatingStatusIds = signal<ReadonlySet<number>>(new Set<number>());
  protected readonly productToDelete = signal<ProductoApi | null>(null);
  protected readonly deleting = signal(false);
  protected readonly deleteError = signal<string | null>(null);
  protected readonly barcodeScannerOpen = signal(false);
  protected readonly barcodeScannerError = signal<string | null>(null);
  protected readonly productoRecetaAbierta = signal<ProductoApi | null>(null);
  protected readonly productForm = this.formBuilder.nonNullable.group({
    nombre: ['', [Validators.required, Validators.maxLength(120)]],
    categoria: ['', Validators.maxLength(60)],
    precio_compra: [null as number | null, Validators.min(0)],
    precio_venta: [null as number | null, [Validators.required, Validators.min(0.01)]],
    codigo_barras: ['', Validators.maxLength(64)],
    activo: [true],
  });
  protected readonly activeProducts = computed(
    () => this.products().filter((product) => product.activo).length,
  );
  protected readonly inactiveProducts = computed(
    () => this.products().filter((product) => !product.activo).length,
  );
  protected readonly productModalOpen = computed(
    () => this.creatingProduct() || this.selectedProduct() !== null,
  );
  protected readonly availableCategories = computed(() => {
    const categorias = this.products()
      .map((product) => product.categoria)
      .filter((categoria): categoria is string => !!categoria && categoria.trim().length > 0);

    return [...new Set(categorias)].sort((a, b) => a.localeCompare(b, 'es-CL'));
  });

  protected readonly filteredProducts = computed(() => {
    const query = this.normalizeSearchValue(this.searchQuery());
    const categoria = this.categoriaFilter();
    const estado = this.estadoFilter();

    return this.products().filter((product) => {
      const hasZeroPrice =
        Number(product.precio_venta) === 0 ||
        (product.precio_compra !== null && Number(product.precio_compra) === 0);
      if (this.zeroPriceFilterActive() && !hasZeroPrice) {
        return false;
      }

      if (categoria && product.categoria !== categoria) {
        return false;
      }

      if (estado === 'activos' && !product.activo) {
        return false;
      }

      if (estado === 'inactivos' && product.activo) {
        return false;
      }

      if (!query) {
        return true;
      }

      const searchableValues = [
        product.nombre,
        product.codigo_barras ?? '',
      ];

      return searchableValues.some((value) => this.normalizeSearchValue(value).includes(query));
    });
  });

  protected readonly zeroPriceProductsCount = computed(
    () =>
      this.products().filter(
        (product) =>
          Number(product.precio_venta) === 0 ||
          (product.precio_compra !== null && Number(product.precio_compra) === 0),
      ).length,
  );

  protected readonly pageSize = 10;
  protected readonly currentPage = linkedSignal({
    source: this.filteredProducts,
    computation: () => 1,
  });
  protected readonly totalPages = computed(() =>
    Math.max(1, Math.ceil(this.filteredProducts().length / this.pageSize)),
  );
  protected readonly paginatedProducts = computed(() => {
    const start = (this.currentPage() - 1) * this.pageSize;
    return this.filteredProducts().slice(start, start + this.pageSize);
  });
  protected readonly firstVisibleProduct = computed(() =>
    this.filteredProducts().length > 0 ? (this.currentPage() - 1) * this.pageSize + 1 : 0,
  );
  protected readonly lastVisibleProduct = computed(() =>
    Math.min(this.currentPage() * this.pageSize, this.filteredProducts().length),
  );

  protected changePage(offset: number): void {
    this.currentPage.update((page) => Math.max(1, Math.min(page + offset, this.totalPages())));
  }

  protected cambiarVista(vista: VistaMaestro): void {
    this.vista.set(vista);
    if (!this.ruta) return;
    void this.router.navigate([], {
      relativeTo: this.ruta,
      queryParams: { vista: vista === 'productos' ? null : vista },
      queryParamsHandling: 'merge',
      replaceUrl: true,
    });
  }

  ngOnInit(): void {
    this.productosApi.listar(false).subscribe({
      next: (products) => {
        this.products.set(products);
        this.loading.set(false);
      },
      error: (error) => {
        console.error('No se pudieron cargar los productos', error);
        this.error.set('No pudimos cargar los productos. Revisa la conexión con la base de datos.');
        this.loading.set(false);
      },
    });
  }

  ngOnDestroy(): void {
    this.barcodeScanner.stop();
  }

  protected productBarcode(product: ProductoApi): string {
    return product.codigo_barras?.trim() || 'Sin código';
  }

  protected formatClp(price: number | string): string {
    return new Intl.NumberFormat('es-CL', {
      style: 'currency',
      currency: 'CLP',
      maximumFractionDigits: 0,
    }).format(Number(price));
  }

  protected utilidadClp(product: ProductoApi): number | null {
    if (product.precio_compra === null) {
      return null;
    }

    return Number(product.precio_venta) - Number(product.precio_compra);
  }

  protected utilidadPorcentaje(product: ProductoApi): number | null {
    const utilidad = this.utilidadClp(product);
    const precioVenta = Number(product.precio_venta);

    if (utilidad === null || precioVenta <= 0) {
      return null;
    }

    return (utilidad / precioVenta) * 100;
  }

  protected formatPercent(value: number): string {
    return new Intl.NumberFormat('es-CL', {
      style: 'percent',
      maximumFractionDigits: 1,
    }).format(value / 100);
  }

  protected formatDate(date: string): string {
    return new Intl.DateTimeFormat('es-CL', {
      dateStyle: 'medium',
      timeStyle: 'short',
    }).format(new Date(date));
  }

  protected updateSearch(event: Event): void {
    this.searchQuery.set((event.target as HTMLInputElement).value);
  }

  protected updateCategoriaFilter(event: Event): void {
    this.categoriaFilter.set((event.target as HTMLSelectElement).value);
  }

  protected updateEstadoFilter(event: Event): void {
    const value = (event.target as HTMLSelectElement).value;
    this.estadoFilter.set(value === 'activos' || value === 'inactivos' ? value : 'todos');
  }

  protected openEditModal(product: ProductoApi): void {
    if (!this.puedeEditar()) return;
    this.successMessage.set(null);
    this.saveError.set(null);
    this.productForm.reset({
      nombre: product.nombre,
      categoria: product.categoria ?? '',
      precio_compra: product.precio_compra === null ? null : Number(product.precio_compra),
      precio_venta: Number(product.precio_venta),
      codigo_barras: product.codigo_barras ?? '',
      activo: product.activo,
    });
    this.creatingProduct.set(false);
    this.selectedProduct.set(product);
  }

  protected isUpdatingStatus(productId: number): boolean {
    return this.updatingStatusIds().has(productId);
  }

  protected toggleProductStatus(product: ProductoApi): void {
    if (!this.esAdmin() || this.isUpdatingStatus(product.id)) {
      return;
    }

    const nextStatus = !product.activo;
    this.successMessage.set(null);
    this.actionError.set(null);
    this.updatingStatusIds.update((ids) => new Set(ids).add(product.id));

    this.productosApi
      .actualizarEstado(product.id, nextStatus)
      .pipe(
        finalize(() => {
          this.updatingStatusIds.update((ids) => {
            const updatedIds = new Set(ids);
            updatedIds.delete(product.id);
            return updatedIds;
          });
        }),
      )
      .subscribe({
        next: (updatedProduct) => {
          this.products.update((products) =>
            products.map((current) =>
              current.id === updatedProduct.id ? updatedProduct : current,
            ),
          );
          this.successMessage.set(
            `“${updatedProduct.nombre}” ahora está ${updatedProduct.activo ? 'visible' : 'oculto'} en el catálogo.`,
          );
        },
        error: (error) => {
          console.error('No se pudo cambiar la visibilidad del producto', error);
          this.actionError.set(
            'No pudimos cambiar la visibilidad del producto. Inténtalo nuevamente.',
          );
        },
      });
  }

  protected openDeleteModal(product: ProductoApi): void {
    if (!this.esAdmin()) return;
    this.successMessage.set(null);
    this.actionError.set(null);
    this.deleteError.set(null);
    this.productToDelete.set(product);
  }

  protected closeDeleteModal(): void {
    if (this.deleting()) {
      return;
    }

    this.productToDelete.set(null);
    this.deleteError.set(null);
  }

  protected deleteProduct(): void {
    const product = this.productToDelete();

    if (!this.esAdmin() || !product || this.deleting()) {
      return;
    }

    this.deleting.set(true);
    this.deleteError.set(null);

    this.productosApi
      .eliminar(product.id)
      .pipe(finalize(() => this.deleting.set(false)))
      .subscribe({
        next: (deletedProduct) => {
          this.products.update((products) =>
            products.filter((current) => current.id !== deletedProduct.id),
          );
          this.productToDelete.set(null);
          this.successMessage.set(`“${deletedProduct.nombre}” fue eliminado correctamente.`);
        },
        error: (error) => {
          console.error('No se pudo eliminar el producto', error);
          this.deleteError.set(this.deleteErrorMessage(error?.status));
        },
      });
  }

  protected openCreateModal(): void {
    if (!this.puedeEditar()) return;
    this.successMessage.set(null);
    this.saveError.set(null);
    this.productForm.reset({
      nombre: '',
      categoria: '',
      precio_compra: null,
      precio_venta: null,
      codigo_barras: '',
      activo: true,
    });
    this.selectedProduct.set(null);
    this.creatingProduct.set(true);
  }

  protected closeProductModal(): void {
    if (this.saving()) {
      return;
    }

    this.creatingProduct.set(false);
    this.selectedProduct.set(null);
    this.saveError.set(null);
    this.closeBarcodeScanner();
  }

  protected openBarcodeScanner(): void {
    this.barcodeScannerError.set(null);
    this.barcodeScannerOpen.set(true);

    // The video element is rendered by the @if block on the next change-detection pass.
    setTimeout(() => void this.startBarcodeScanner(), 0);
  }

  protected closeBarcodeScanner(): void {
    this.barcodeScanner.stop();
    this.barcodeScannerOpen.set(false);
  }

  private async startBarcodeScanner(): Promise<void> {
    const videoElement = this.productBarcodeVideo?.nativeElement;
    if (!videoElement || !this.barcodeScannerOpen()) return;

    try {
      await this.barcodeScanner.start(
        videoElement,
        (code) => {
          this.productForm.controls.codigo_barras.setValue(code);
          this.productForm.controls.codigo_barras.markAsDirty();
          this.closeBarcodeScanner();
        },
        (error) => {
          console.error('No se pudo iniciar la cámara para escanear el producto', error);
          this.barcodeScannerError.set(this.getBarcodeScannerErrorMessage(error));
        },
      );
    } catch {
      // The user-facing message is set by the error callback above.
    }
  }

  private getBarcodeScannerErrorMessage(error: unknown): string {
    if (error instanceof DOMException && error.name === 'NotAllowedError') {
      return 'Debes permitir el acceso a la cámara para escanear.';
    }
    if (error instanceof DOMException && error.name === 'NotFoundError') {
      return 'No se encontró una cámara disponible en este dispositivo.';
    }
    return 'No fue posible iniciar la cámara. Verifica los permisos y que estés usando HTTPS.';
  }

  protected saveProduct(): void {
    const product = this.selectedProduct();
    const isCreating = this.creatingProduct();

    if (!this.puedeEditar() || (!isCreating && !product) || this.saving()) {
      return;
    }

    if (this.productForm.invalid) {
      this.productForm.markAllAsTouched();
      return;
    }

    const values = this.productForm.getRawValue();
    const productData: ProductoCreacion = {
      // Sin espacios en los extremos ni repetidos, como lo guarda la base (H3.3 T05).
      nombre: limpiarNombre(values.nombre),
      categoria: values.categoria.trim() || null,
      precio_compra: values.precio_compra === null ? null : Number(values.precio_compra),
      precio_venta: Number(values.precio_venta),
      codigo_barras: values.codigo_barras.replace(/\s/g, '') || null,
      ...(this.esAdmin() ? { activo: values.activo } : {}),
    };

    if (!productData.nombre) {
      this.productForm.controls.nombre.setErrors({ required: true });
      return;
    }

    // H3.3 T05: nombre y código de barras únicos sin importar mayúsculas ni espacios.
    // La base también lo exige (índices ux_productos_*_normalizado); acá se avisa antes.
    const otros = this.products().filter((current) => current.id !== product?.id);
    const nombreClave = claveNombre(productData.nombre);
    const codigoClave = claveCodigo(productData.codigo_barras);
    let repetido = false;
    if (otros.some((current) => claveNombre(current.nombre) === nombreClave)) {
      this.productForm.controls.nombre.setErrors({ repetido: true });
      repetido = true;
    }
    if (codigoClave && otros.some((current) => claveCodigo(current.codigo_barras) === codigoClave)) {
      this.productForm.controls.codigo_barras.setErrors({ repetido: true });
      repetido = true;
    }
    if (repetido) {
      this.productForm.markAllAsTouched();
      return;
    }

    this.saving.set(true);
    this.saveError.set(null);

    const request = isCreating
      ? this.productosApi.crear(productData)
      : this.productosApi.actualizar(product!.id, productData);

    request.pipe(finalize(() => this.saving.set(false))).subscribe({
      next: (savedProduct) => {
        this.products.update((products) =>
          isCreating
            ? [...products, savedProduct]
            : products.map((current) => (current.id === savedProduct.id ? savedProduct : current)),
        );
        this.creatingProduct.set(false);
        this.selectedProduct.set(null);
        this.successMessage.set(
          `“${savedProduct.nombre}” fue ${isCreating ? 'creado' : 'actualizado'} correctamente.`,
        );
      },
      error: (error) => {
        console.error(`No se pudo ${isCreating ? 'crear' : 'actualizar'} el producto`, error);
        this.saveError.set(this.saveErrorMessage(error?.status, isCreating));
      },
    });
  }

  @HostListener('document:keydown.escape')
  protected closeOnEscape(): void {
    if (this.barcodeScannerOpen()) {
      this.closeBarcodeScanner();
    } else if (this.productToDelete()) {
      this.closeDeleteModal();
    } else if (this.productModalOpen()) {
      this.closeProductModal();
    }
  }

  private deleteErrorMessage(status: number | undefined): string {
    if (status === 409) {
      return 'Este producto tiene ventas, promociones u otros registros asociados. Puedes ocultarlo del catálogo en lugar de eliminarlo.';
    }

    if (status === 401 || status === 403) {
      return 'Tu sesión no tiene permisos para eliminar productos.';
    }

    return 'No pudimos eliminar el producto. Revisa la conexión e inténtalo nuevamente.';
  }

  private saveErrorMessage(status: number | undefined, isCreating: boolean): string {
    if (status === 409) {
      return 'Ya existe un producto con ese nombre o código de barras.';
    }

    if (status === 401 || status === 403) {
      return `Tu sesión no tiene permisos para ${isCreating ? 'crear' : 'editar'} productos.`;
    }

    return 'No pudimos guardar los cambios. Revisa la conexión e inténtalo nuevamente.';
  }

  /**
   * Un producto con código de barras se asume de reventa simple: lleva su propio
   * stock (stock_producto_sucursal) y no se arma con ingredientes, así que no se
   * le asigna receta desde el Maestro.
   */
  protected puedeTenerReceta(product: ProductoApi): boolean {
    return !product.codigo_barras?.trim();
  }

  protected abrirReceta(product: ProductoApi): void {
    if (!this.esAdmin()) return;
    this.productoRecetaAbierta.set(product);
  }

  protected cerrarReceta(): void {
    this.productoRecetaAbierta.set(null);
  }

  private normalizeSearchValue(value: string): string {
    return value
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .trim()
      .toLocaleLowerCase('es-CL');
  }
}
