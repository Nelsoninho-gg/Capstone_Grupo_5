import { TestBed } from '@angular/core/testing';
import { firstValueFrom, of } from 'rxjs';
import { RecetasApiService } from '../../../core/api/recetas-api.service';
import {
  AjusteManualApi,
  StockApiService,
  StockIngredienteApi,
  StockProductoApi,
} from '../../../core/api/stock-api.service';
import { User } from '../../auth/models/auth.model';
import { AuthService } from '../../auth/services/auth.service';
import { MinimoSinFilaError } from '../models/fallo-minimo';
import { ExistenciaStock } from '../models/inventario.model';
import { InventarioService, sucursalesAutorizadas } from './inventario.service';

const providencia = { nombre: 'Nury Providencia (Equipo de desarrollo)' };
const enac = { nombre: "Nury's ENAC" };

function usuario(rol: User['rol'], sucursalId: number | null): User {
  return {
    id: 1,
    nombre: 'Rocío Fuentes',
    identificadorAcceso: 'rocio',
    rol,
    sucursalId,
    sucursalNombre: '',
    activo: true,
  };
}

function configurar(usuarioActual: User | null) {
  const stockApi = {
    listarStockIngredientes: vi.fn(),
    listarStockProductos: vi.fn(),
    actualizarMinimo: vi.fn(),
    listarAjustesManuales: vi.fn(),
  };
  const recetasApi = { listarIdsProductosConReceta: vi.fn(() => of<number[]>([])) };
  TestBed.configureTestingModule({
    providers: [
      { provide: AuthService, useValue: { currentUser: () => usuarioActual } },
      { provide: StockApiService, useValue: stockApi },
      { provide: RecetasApiService, useValue: recetasApi },
    ],
  });
  return { service: TestBed.inject(InventarioService), stockApi, recetasApi };
}

describe('sucursalesAutorizadas', () => {
  it.each([
    ['admin con sucursal', usuario('admin', 1), null],
    ['admin sin sucursal', usuario('admin', null), null],
    ['bodeguero con sucursal', usuario('bodeguero', 3), 3],
    ['bodeguero sin sucursal', usuario('bodeguero', null), 'ninguna'],
    ['sin sesión', null, 'ninguna'],
  ] as const)('%s', (_caso, actual, esperado) => {
    expect(sucursalesAutorizadas(actual)).toBe(esperado);
  });
});

describe('InventarioService (existencias reales)', () => {
  const queso: StockIngredienteApi = {
    ingrediente_id: 3,
    sucursal_id: 1,
    stock_actual: '2.500',
    stock_minimo: '1.000',
    ingredientes: { nombre: 'Queso', unidades_medida: { abreviatura: 'g' } },
    sucursales: providencia,
  };
  const chaparrita: StockProductoApi = {
    producto_id: 1,
    sucursal_id: 1,
    stock_actual: 6,
    stock_minimo: 0,
    productos: { nombre: 'CHAPARRITA' },
    sucursales: providencia,
  };
  const pino: StockProductoApi = {
    ...chaparrita,
    producto_id: 2,
    stock_actual: -3,
    productos: { nombre: 'EMPANADA PINO' },
  };
  const pinoEnac: StockProductoApi = { ...pino, sucursal_id: 2, sucursales: enac };

  it('maps ingredients and resale products to the rows of the panel', async () => {
    const { service, stockApi } = configurar(usuario('admin', 1));
    stockApi.listarStockIngredientes.mockReturnValue(of([queso]));
    stockApi.listarStockProductos.mockReturnValue(of([pino]));

    const existencias = await firstValueFrom(service.listarExistencias());

    expect(existencias).toEqual([
      {
        id: 'producto-2-1',
        articuloId: 2,
        articulo: 'EMPANADA PINO',
        tipo: 'producto',
        cantidad: -3,
        stockMinimo: 0,
        unidad: 'un',
        sucursalId: 1,
        sucursal: 'Nury Providencia (Equipo de desarrollo)',
      },
      {
        id: 'materia_prima-3-1',
        articuloId: 3,
        articulo: 'Queso',
        tipo: 'materia_prima',
        cantidad: 2.5,
        stockMinimo: 1,
        unidad: 'g',
        sucursalId: 1,
        sucursal: 'Nury Providencia (Equipo de desarrollo)',
      },
    ]);
  });

  it('adds no waiting of its own to the stock query (H3.4 T09: answer in < 1 s)', () => {
    // El tiempo total depende de la API; el servicio solo debe entregar apenas ella responde.
    const { service, stockApi } = configurar(usuario('admin', 1));
    stockApi.listarStockIngredientes.mockReturnValue(of([queso]));
    stockApi.listarStockProductos.mockReturnValue(of([chaparrita]));
    let filas: ExistenciaStock[] | null = null;

    service.listarExistencias().subscribe((existencias) => (filas = existencias));

    expect(filas).toHaveLength(2);
  });

  it('sorts by branch and then by item name', async () => {
    const { service, stockApi } = configurar(usuario('admin', null));
    stockApi.listarStockIngredientes.mockReturnValue(of([queso]));
    stockApi.listarStockProductos.mockReturnValue(of([pinoEnac, pino, chaparrita]));

    const existencias = await firstValueFrom(service.listarExistencias());

    expect(existencias.map((e) => `${e.sucursalId} ${e.articulo}`)).toEqual([
      '1 CHAPARRITA',
      '1 EMPANADA PINO',
      '1 Queso',
      '2 EMPANADA PINO',
    ]);
  });

  it('gives the same item a different row in each branch', async () => {
    const { service, stockApi } = configurar(usuario('admin', null));
    stockApi.listarStockIngredientes.mockReturnValue(of([]));
    stockApi.listarStockProductos.mockReturnValue(of([pino, pinoEnac]));

    const ids = (await firstValueFrom(service.listarExistencias())).map((e) => e.id);

    expect(new Set(ids).size).toBe(2);
  });

  it('leaves out the stock rows of products that have a recipe', async () => {
    const { service, stockApi, recetasApi } = configurar(usuario('admin', 1));
    stockApi.listarStockIngredientes.mockReturnValue(of([]));
    stockApi.listarStockProductos.mockReturnValue(of([chaparrita, pino]));
    recetasApi.listarIdsProductosConReceta.mockReturnValue(of([2]));

    const existencias = await firstValueFrom(service.listarExistencias());

    expect(existencias.map((e) => e.articulo)).toEqual(['CHAPARRITA']);
  });

  it('keeps an empty unit when the ingredient has none', async () => {
    const { service, stockApi } = configurar(usuario('admin', 1));
    stockApi.listarStockIngredientes.mockReturnValue(
      of([{ ...queso, ingredientes: { nombre: 'Queso', unidades_medida: null } }]),
    );
    stockApi.listarStockProductos.mockReturnValue(of([]));

    const [existencia] = await firstValueFrom(service.listarExistencias());

    expect(existencia.unidad).toBe('');
  });

  it('lets the administrator query every branch', async () => {
    const { service, stockApi } = configurar(usuario('admin', 1));
    stockApi.listarStockIngredientes.mockReturnValue(of([]));
    stockApi.listarStockProductos.mockReturnValue(of([]));

    await firstValueFrom(service.listarExistencias());

    expect(stockApi.listarStockIngredientes).toHaveBeenCalledWith(null);
    expect(stockApi.listarStockProductos).toHaveBeenCalledWith(null);
  });

  it('limits a storekeeper to the assigned branch', async () => {
    const { service, stockApi } = configurar(usuario('bodeguero', 3));
    stockApi.listarStockIngredientes.mockReturnValue(of([]));
    stockApi.listarStockProductos.mockReturnValue(of([]));

    await firstValueFrom(service.listarExistencias());

    expect(stockApi.listarStockIngredientes).toHaveBeenCalledWith(3);
    expect(stockApi.listarStockProductos).toHaveBeenCalledWith(3);
  });

  it('does not query anything for a storekeeper without a branch', async () => {
    const { service, stockApi } = configurar(usuario('bodeguero', null));

    expect(await firstValueFrom(service.listarExistencias())).toEqual([]);
    expect(stockApi.listarStockIngredientes).not.toHaveBeenCalled();
    expect(stockApi.listarStockProductos).not.toHaveBeenCalled();
  });
});

describe('InventarioService (mínimos reales)', () => {
  const existencia: ExistenciaStock = {
    id: 'producto-1-1',
    articuloId: 1,
    articulo: 'CHAPARRITA',
    tipo: 'producto',
    cantidad: 6,
    stockMinimo: 0,
    unidad: 'un',
    sucursalId: 1,
    sucursal: 'Nury Providencia (Equipo de desarrollo)',
  };

  it('saves the minimum of a resale product in its branch and returns the stored value', async () => {
    const { service, stockApi } = configurar(usuario('admin', 1));
    stockApi.actualizarMinimo.mockReturnValue(of(10));

    const actualizada = await firstValueFrom(service.actualizarMinimo(existencia, 10));

    expect(stockApi.actualizarMinimo).toHaveBeenCalledWith('producto', 1, 1, 10);
    expect(actualizada).toEqual({ ...existencia, stockMinimo: 10 });
  });

  it('saves the minimum of a raw material in the ingredient stock', async () => {
    const { service, stockApi } = configurar(usuario('bodeguero', 1));
    stockApi.actualizarMinimo.mockReturnValue(of(0.5));
    const queso = { ...existencia, articuloId: 3, tipo: 'materia_prima' as const };

    await firstValueFrom(service.actualizarMinimo(queso, 0.5));

    expect(stockApi.actualizarMinimo).toHaveBeenCalledWith('ingrediente', 3, 1, 0.5);
  });

  it('fails with MinimoSinFilaError when the stock row no longer exists', async () => {
    const { service, stockApi } = configurar(usuario('admin', 1));
    stockApi.actualizarMinimo.mockReturnValue(of(null));

    await expect(firstValueFrom(service.actualizarMinimo(existencia, 3))).rejects.toBeInstanceOf(
      MinimoSinFilaError,
    );
  });
});

describe('InventarioService (ajustes y mermas reales)', () => {
  const leche: AjusteManualApi = {
    id: 7,
    ingrediente_id: 3,
    producto_id: null,
    sucursal_id: 1,
    tipo_movimiento: 'merma',
    cantidad: '-0.250',
    nota: 'Leche cortada',
    // PostgREST entrega el TIMESTAMP sin zona y con microsegundos; la base lo guarda en UTC.
    creado_en: '2026-10-20T09:15:00.123456',
    ingredientes: { nombre: 'Leche entera', unidades_medida: { abreviatura: 'L' } },
    productos: null,
    sucursales: providencia,
    usuarios: { nombre: 'Rocío Fuentes' },
  };
  const galletas: AjusteManualApi = {
    id: 6,
    ingrediente_id: null,
    producto_id: 3,
    sucursal_id: 2,
    tipo_movimiento: 'ajuste',
    cantidad: 2,
    nota: null,
    creado_en: '2026-10-19T17:40:00',
    ingredientes: null,
    productos: { nombre: 'GALLETAS' },
    sucursales: enac,
    usuarios: null,
  };
  const filtro = { sucursalId: 2, desde: '2026-10-14', hasta: '2026-10-20', soloMermas: false };

  /** Medianoche local del día indicado, en UTC sin zona: lo que se compara con creado_en. */
  function medianocheEnUtc(anio: number, mes: number, dia: number): string {
    return new Date(anio, mes - 1, dia).toISOString().slice(0, 19);
  }

  it('maps waste and adjustments with their sign, class and UTC time', async () => {
    const { service, stockApi } = configurar(usuario('admin', 1));
    stockApi.listarAjustesManuales.mockReturnValue(of([leche, galletas]));

    expect(await firstValueFrom(service.listarMermas(filtro))).toEqual([
      {
        id: 7,
        existenciaId: 'materia_prima-3-1',
        articulo: 'Leche entera',
        tipo: 'materia_prima',
        clase: 'merma',
        cantidad: -0.25,
        unidad: 'L',
        motivo: 'Leche cortada',
        usuario: 'Rocío Fuentes',
        sucursalId: 1,
        sucursal: 'Nury Providencia (Equipo de desarrollo)',
        fecha: new Date(Date.UTC(2026, 9, 20, 9, 15, 0, 123)),
      },
      {
        id: 6,
        existenciaId: 'producto-3-2',
        articulo: 'GALLETAS',
        tipo: 'producto',
        clase: 'ajuste',
        cantidad: 2,
        unidad: 'un',
        motivo: '',
        usuario: null,
        sucursalId: 2,
        sucursal: "Nury's ENAC",
        fecha: new Date(Date.UTC(2026, 9, 19, 17, 40)),
      },
    ]);
  });

  it('respects the time zone when the date already carries one', async () => {
    const { service, stockApi } = configurar(usuario('admin', 1));
    stockApi.listarAjustesManuales.mockReturnValue(
      of([{ ...galletas, creado_en: '2026-10-19T17:40:00-03:00' }]),
    );

    const [ajuste] = await firstValueFrom(service.listarMermas(filtro));
    expect(ajuste.fecha).toEqual(new Date(Date.UTC(2026, 9, 19, 20, 40)));
  });

  it('lets the administrator query the branch of the filter or every branch', async () => {
    const { service, stockApi } = configurar(usuario('admin', 1));
    stockApi.listarAjustesManuales.mockReturnValue(of([]));

    await firstValueFrom(service.listarMermas(filtro));
    await firstValueFrom(service.listarMermas({ ...filtro, sucursalId: null, soloMermas: true }));

    const desde = medianocheEnUtc(2026, 10, 14);
    const hasta = medianocheEnUtc(2026, 10, 21);
    expect(stockApi.listarAjustesManuales.mock.calls).toEqual([
      [2, desde, hasta, false],
      [null, desde, hasta, true],
    ]);
  });

  it('sends the local midnight after the end of the period as the exclusive limit', async () => {
    const { service, stockApi } = configurar(usuario('admin', 1));
    stockApi.listarAjustesManuales.mockReturnValue(of([]));

    await firstValueFrom(
      service.listarMermas({
        ...filtro,
        sucursalId: null,
        desde: '2026-12-01',
        hasta: '2026-12-31',
      }),
    );

    expect(stockApi.listarAjustesManuales).toHaveBeenCalledWith(
      null,
      medianocheEnUtc(2026, 12, 1),
      medianocheEnUtc(2027, 1, 1),
      false,
    );
  });

  it('limits a storekeeper to the assigned branch even if the filter asks for another', async () => {
    const { service, stockApi } = configurar(usuario('bodeguero', 3));
    stockApi.listarAjustesManuales.mockReturnValue(of([]));

    await firstValueFrom(service.listarMermas(filtro));
    await firstValueFrom(service.listarMermas({ ...filtro, sucursalId: null }));

    expect(stockApi.listarAjustesManuales.mock.calls.map(([sucursal]) => sucursal)).toEqual([3, 3]);
  });

  it('does not query waste for a storekeeper without a branch', async () => {
    const { service, stockApi } = configurar(usuario('bodeguero', null));

    expect(await firstValueFrom(service.listarMermas(filtro))).toEqual([]);
    expect(stockApi.listarAjustesManuales).not.toHaveBeenCalled();
  });
});
