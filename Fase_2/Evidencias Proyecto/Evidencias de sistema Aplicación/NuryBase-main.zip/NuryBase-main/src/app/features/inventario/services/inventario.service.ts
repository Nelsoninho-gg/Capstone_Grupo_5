import { Injectable, inject } from '@angular/core';
import { Observable, forkJoin, map, of } from 'rxjs';
import { RecetasApiService } from '../../../core/api/recetas-api.service';
import {
  AjusteManualApi,
  StockApiService,
  StockIngredienteApi,
  StockProductoApi,
  VersionInventarioApi,
} from '../../../core/api/stock-api.service';
import { User } from '../../auth/models/auth.model';
import { AuthService } from '../../auth/services/auth.service';
import {
  AjusteStock,
  ExistenciaStock,
  FiltroMermas,
  TipoArticulo,
  claveExistencia,
} from '../models/inventario.model';
import { MinimoSinFilaError } from '../models/fallo-minimo';

/** Los productos no tienen unidad de medida en la base: se cuentan por unidad. */
const UNIDAD_PRODUCTO = 'un';

/**
 * Existencias reales (H3.4 T03) y mínimos (H3.5 T05) desde stock_sucursal y
 * stock_producto_sucursal, y reporte de mermas (H3.6 T07) desde movimientos_stock.
 * El ajuste del panel ya es real (AjusteInventario).
 */
@Injectable({ providedIn: 'root' })
export class InventarioService {
  private readonly authService = inject(AuthService);
  private readonly stockApi = inject(StockApiService);
  private readonly recetasApi = inject(RecetasApiService);

  /**
   * Existencias registradas de las sucursales autorizadas, ordenadas por sucursal y
   * artículo. Un artículo aparece en una sucursal cuando ya tiene fila de stock (por una
   * compra, un ajuste o una venta); no se completan con ceros los que nunca tuvieron.
   */
  listarExistencias(): Observable<ExistenciaStock[]> {
    const alcance = sucursalesAutorizadas(this.authService.currentUser());
    if (alcance === 'ninguna') return of([]);

    return forkJoin({
      ingredientes: this.stockApi.listarStockIngredientes(alcance),
      productos: this.stockApi.listarStockProductos(alcance),
      conReceta: this.recetasApi.listarIdsProductosConReceta(),
    }).pipe(
      map(({ ingredientes, productos, conReceta }) => {
        // Un producto con receta descuenta sus ingredientes: una fila propia sería un resto viejo.
        const idsConReceta = new Set(conReceta);
        return [
          ...ingredientes.map(existenciaDeIngrediente),
          ...productos
            .filter((fila) => !idsConReceta.has(fila.producto_id))
            .map(existenciaDeProducto),
        ].sort(
          (a, b) =>
            a.sucursal.localeCompare(b.sucursal, 'es') ||
            a.articulo.localeCompare(b.articulo, 'es'),
        );
      }),
    );
  }

  /**
   * Guarda el mínimo de la existencia en su fila de stock (H3.5 T05) y la devuelve con el
   * valor que quedó en la base. Falla con MinimoSinFilaError si la fila ya no existe.
   */
  actualizarMinimo(existencia: ExistenciaStock, stockMinimo: number): Observable<ExistenciaStock> {
    const tipo = existencia.tipo === 'producto' ? 'producto' : 'ingrediente';
    return this.stockApi
      .actualizarMinimo(tipo, existencia.articuloId, existencia.sucursalId, stockMinimo)
      .pipe(
        map((guardado) => {
          if (guardado === null) throw new MinimoSinFilaError();
          return { ...existencia, stockMinimo: guardado };
        }),
      );
  }

  /** Versión liviana del inventario para detectar cambios sin traer las existencias (H3.2 T06). */
  versionInventario(): Observable<VersionInventarioApi> {
    return this.stockApi.versionInventario();
  }

  /**
   * Ajustes manuales y mermas del periodo (H3.6 T07), del más reciente al más antiguo.
   * Quien no es administrador queda limitado a su sucursal aunque el filtro pida otra.
   */
  listarMermas(filtro: FiltroMermas): Observable<AjusteStock[]> {
    const alcance = sucursalesAutorizadas(this.authService.currentUser());
    if (alcance === 'ninguna') return of([]);

    return this.stockApi
      .listarAjustesManuales(
        alcance ?? filtro.sucursalId,
        inicioDelDiaEnUtc(filtro.desde, 0),
        inicioDelDiaEnUtc(filtro.hasta, 1),
        filtro.soloMermas,
      )
      .pipe(map((filas) => filas.map(ajusteManual)));
  }
}

/**
 * Sucursales que puede consultar el usuario: el administrador ve todas (null) y el
 * resto solo la suya. Sin sucursal asignada no ve ninguna hasta que H3.4 T08 defina
 * ese caso. La base todavía no restringe la lectura por sucursal.
 */
export function sucursalesAutorizadas(usuario: User | null): number | null | 'ninguna' {
  if (usuario?.rol === 'admin') return null;
  return usuario?.sucursalId ?? 'ninguna';
}

function existenciaDeIngrediente(fila: StockIngredienteApi): ExistenciaStock {
  return {
    id: claveExistencia('materia_prima', fila.ingrediente_id, fila.sucursal_id),
    articuloId: fila.ingrediente_id,
    articulo: fila.ingredientes.nombre,
    tipo: 'materia_prima',
    cantidad: Number(fila.stock_actual),
    stockMinimo: Number(fila.stock_minimo),
    unidad: fila.ingredientes.unidades_medida?.abreviatura ?? '',
    sucursalId: fila.sucursal_id,
    sucursal: fila.sucursales.nombre,
  };
}

function existenciaDeProducto(fila: StockProductoApi): ExistenciaStock {
  return {
    id: claveExistencia('producto', fila.producto_id, fila.sucursal_id),
    articuloId: fila.producto_id,
    articulo: fila.productos.nombre,
    tipo: 'producto',
    cantidad: Number(fila.stock_actual),
    stockMinimo: Number(fila.stock_minimo),
    unidad: UNIDAD_PRODUCTO,
    sucursalId: fila.sucursal_id,
    sucursal: fila.sucursales.nombre,
  };
}

function ajusteManual(fila: AjusteManualApi): AjusteStock {
  const tipo: TipoArticulo = fila.producto_id !== null ? 'producto' : 'materia_prima';
  // La base exige exactamente uno de los dos ids.
  const articuloId = (fila.producto_id ?? fila.ingrediente_id)!;
  return {
    id: fila.id,
    existenciaId: claveExistencia(tipo, articuloId, fila.sucursal_id),
    articulo: fila.productos?.nombre ?? fila.ingredientes?.nombre ?? '',
    tipo,
    clase: fila.tipo_movimiento === 'merma' ? 'merma' : 'ajuste',
    cantidad: Number(fila.cantidad),
    unidad:
      tipo === 'producto'
        ? UNIDAD_PRODUCTO
        : (fila.ingredientes?.unidades_medida?.abreviatura ?? ''),
    motivo: fila.nota ?? '',
    usuario: fila.usuarios?.nombre ?? null,
    sucursalId: fila.sucursal_id,
    sucursal: fila.sucursales.nombre,
    fecha: fechaDeLaBase(fila.creado_en),
  };
}

/**
 * Inicio del día local AAAA-MM-DD (más `dias`) en UTC sin zona, el formato de creado_en.
 * shortcut: supone que la base guarda la hora en UTC (comprobado el 20-10-2026 con un ajuste
 * real); si creado_en pasa a timestamptz, enviar el instante con zona.
 */
function inicioDelDiaEnUtc(fecha: string, dias: number): string {
  const [anio, mes, dia] = fecha.split('-').map(Number);
  return new Date(anio, mes - 1, dia + dias).toISOString().slice(0, 19);
}

/** creado_en llega sin zona y está en UTC; si algún día trae zona, se respeta. */
function fechaDeLaBase(texto: string): Date {
  return new Date(/(Z|[+-]\d{2}(:?\d{2})?)$/.test(texto) ? texto : `${texto}Z`);
}
