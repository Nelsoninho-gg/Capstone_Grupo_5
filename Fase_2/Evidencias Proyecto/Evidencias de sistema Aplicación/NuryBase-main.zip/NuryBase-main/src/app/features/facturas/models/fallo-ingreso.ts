import { HttpErrorResponse } from '@angular/common/http';

export type TipoFalloIngreso =
  | 'conexion'
  | 'sesion'
  | 'permisos'
  | 'ya-ingresada'
  | 'datos'
  | 'no-disponible'
  | 'servidor';

export interface FalloIngreso {
  tipo: TipoFalloIngreso;
  mensaje: string;
  /** Se puede volver a intentar sin cambiar nada: el servidor nunca ingresa la misma factura dos veces. */
  reintentable: boolean;
}

interface ErrorPostgrest {
  code?: string;
  message?: string;
}

const SIN_CAMBIOS = 'No se guardó nada y el stock no cambió.';

/**
 * Traduce el error de `fn_ingresar_factura_xml` a un mensaje para el usuario.
 * Códigos de la función: 42501 sin permiso o sucursal ajena, 23505 factura ya ingresada,
 * 22023 datos del XML o de las líneas (el mensaje del servidor ya está en español).
 */
export function interpretarFalloIngreso(error: unknown): FalloIngreso {
  if (!(error instanceof HttpErrorResponse)) return falloServidor();

  const { code = '', message = '' } = (error.error ?? {}) as ErrorPostgrest;

  if (error.status === 0) {
    return {
      tipo: 'conexion',
      mensaje:
        'No pudimos comunicarnos con el servidor y no sabemos si la factura alcanzó a ingresarse. ' +
        'Revisa la conexión y reintenta: si ya estaba ingresada, te lo diremos y el stock no se sumará dos veces.',
      reintentable: true,
    };
  }
  if (error.status === 401 && code !== '42501') {
    return {
      tipo: 'sesion',
      mensaje: `Tu sesión expiró. ${SIN_CAMBIOS} Vuelve a iniciar sesión e intenta de nuevo.`,
      reintentable: false,
    };
  }
  if (error.status === 403 || code === '42501') {
    return {
      tipo: 'permisos',
      mensaje: `${message || 'Tu usuario no puede ingresar facturas en esa sucursal.'} ${SIN_CAMBIOS}`,
      reintentable: false,
    };
  }
  if (code === '23505') return falloYaIngresada(message || undefined);
  if (code === '22023') {
    return {
      tipo: 'datos',
      mensaje: `${message || 'Revisa los datos de la factura.'} ${SIN_CAMBIOS}`,
      reintentable: false,
    };
  }
  if (code === 'PGRST202') {
    return {
      tipo: 'no-disponible',
      mensaje: `El ingreso de facturas aún no está habilitado en el servidor. ${SIN_CAMBIOS} Avisa al administrador.`,
      reintentable: false,
    };
  }
  return falloServidor();
}

/** La factura ya estaba ingresada: lo informa el servidor como resultado (H3.7 T07) o como error 23505. */
export function falloYaIngresada(mensaje = 'Esta factura ya fue ingresada.'): FalloIngreso {
  return { tipo: 'ya-ingresada', mensaje: `${mensaje} No se volvió a sumar stock.`, reintentable: false };
}

function falloServidor(): FalloIngreso {
  return {
    tipo: 'servidor',
    mensaje: `No pudimos ingresar la factura. ${SIN_CAMBIOS} Puedes reintentar: no se ingresará dos veces.`,
    reintentable: true,
  };
}
