import { HttpErrorResponse } from '@angular/common/http';
import { MinimoSinFilaError, interpretarFalloMinimo } from './fallo-minimo';

function errorHttp(status: number, code?: string): HttpErrorResponse {
  return new HttpErrorResponse({ status, error: code ? { code, message: '' } : null });
}

describe('interpretarFalloMinimo', () => {
  it.each([
    ['sin conexión', errorHttp(0), 'No pudimos comunicarnos con el servidor.'],
    ['sesión vencida', errorHttp(401), 'Tu sesión expiró.'],
    [
      'sin permiso (403)',
      errorHttp(403, '42501'),
      'Tu usuario no tiene permiso para cambiar mínimos',
    ],
    [
      'sin permiso aunque la respuesta no traiga código',
      errorHttp(403),
      'Tu usuario no tiene permiso para cambiar mínimos',
    ],
    ['sin sesión aunque PostgREST informe 42501', errorHttp(401, '42501'), 'Tu sesión expiró.'],
    ['restricción de mínimo ≥ 0', errorHttp(400, '23514'), 'El mínimo no puede ser negativo.'],
    ['número fuera de rango', errorHttp(400, '22003'), 'El mínimo es demasiado grande.'],
    ['mínimo con formato inválido', errorHttp(400, '22P02'), 'No pudimos guardar el mínimo.'],
    ['error del servidor', errorHttp(500), 'No pudimos guardar el mínimo.'],
    ['error desconocido', new Error('x'), 'No pudimos guardar el mínimo.'],
  ])('%s', (_caso, error, mensaje) => {
    const fallo = interpretarFalloMinimo(error);

    expect(fallo.mensaje).toContain(mensaje);
    expect(fallo.mensaje).toContain('El mínimo no se modificó.');
    expect(fallo.actualizarStock).toBe(false);
  });

  it('pide actualizar el panel cuando la fila de stock ya no existe', () => {
    const fallo = interpretarFalloMinimo(new MinimoSinFilaError());

    expect(fallo.mensaje).toContain('ya no tiene stock registrado en esa sucursal');
    expect(fallo.actualizarStock).toBe(true);
  });
});
