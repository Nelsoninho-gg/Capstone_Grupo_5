import { HttpErrorResponse } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { Subject, of, throwError } from 'rxjs';
import { SucursalApi, SucursalesApiService } from '../../../../core/api/sucursales-api.service';
import { Sucursales } from './sucursales';

describe('Sucursales', () => {
  let fixture: ComponentFixture<Sucursales>;
  let component: Sucursales;
  const branch: SucursalApi = {
    id: 1,
    nombre: 'Nury Providencia',
    direccion: 'Providencia 123',
    telefono: '+56 9 1234 5678',
    activo: true,
    creado_en: '2026-09-30T12:00:00',
  };
  const inactive: SucursalApi = {
    ...branch,
    id: 2,
    nombre: 'Nury Ñuñoa',
    direccion: null,
    telefono: null,
    activo: false,
  };
  const api = {
    listar: vi.fn(),
    crear: vi.fn(),
    actualizar: vi.fn(),
    actualizarEstado: vi.fn(),
  };

  beforeEach(async () => {
    Object.values(api).forEach((mock) => mock.mockReset());
    api.listar.mockReturnValue(of([branch, inactive]));
    api.crear.mockImplementation((data) => of({ ...data, id: 3, creado_en: branch.creado_en }));
    api.actualizar.mockImplementation((id, data) => of({ ...branch, ...data, id }));
    api.actualizarEstado.mockImplementation((id, activo) => of({ ...branch, id, activo }));
    await TestBed.configureTestingModule({
      imports: [Sucursales],
      providers: [provideRouter([]), { provide: SucursalesApiService, useValue: api }],
    }).compileComponents();
    fixture = TestBed.createComponent(Sucursales);
    component = fixture.componentInstance;
    fixture.detectChanges();
    await fixture.whenStable();
  });

  function click(selector: string): void {
    (fixture.nativeElement.querySelector(selector) as HTMLButtonElement).click();
    fixture.detectChanges();
  }
  function submit(): void {
    fixture.nativeElement.querySelector('form').dispatchEvent(new Event('submit'));
    fixture.detectChanges();
  }

  it('lists active and inactive branches with their contact details', () => {
    expect(api.listar).toHaveBeenCalledOnce();
    const rows = fixture.nativeElement.querySelectorAll('.branches-table tbody tr');
    expect(rows).toHaveLength(2);
    expect(rows[0].textContent).toContain('Providencia 123');
    expect(rows[1].textContent).toContain('Sin dirección');
    expect(rows[1].textContent).toContain('Sin teléfono');
    expect(rows[1].textContent).toContain('Inactivo');
  });

  it('creates a branch, normalizes optional fields and closes the saved form', () => {
    click('.panel-actions .primary-button');
    component['formulario'].setValue({
      nombre: '  Nury Las Condes  ',
      direccion: '  Nueva dirección  ',
      telefono: ' ',
      activo: false,
    });
    submit();
    expect(api.crear).toHaveBeenCalledExactlyOnceWith({
      nombre: 'Nury Las Condes',
      direccion: 'Nueva dirección',
      telefono: null,
      activo: false,
    });
    expect(fixture.nativeElement.querySelector('[role="dialog"]')).toBeNull();
    expect(fixture.nativeElement.querySelectorAll('.branch-name')).toHaveLength(3);
    expect(fixture.nativeElement.querySelector('.success-feedback').textContent).toContain(
      'creada',
    );
  });

  it('opens the selected branch and refreshes only its row after editing', () => {
    click('[aria-label="Editar Nury Providencia"]');
    expect(component['formulario'].getRawValue()).toEqual({
      nombre: branch.nombre,
      direccion: branch.direccion,
      telefono: branch.telefono,
      activo: true,
    });
    component['formulario'].patchValue({
      nombre: 'Nury Providencia renovada',
      direccion: '',
      telefono: '',
    });
    submit();
    expect(api.actualizar).toHaveBeenCalledExactlyOnceWith(1, {
      nombre: 'Nury Providencia renovada',
      direccion: null,
      telefono: null,
      activo: true,
    });
    expect(api.crear).not.toHaveBeenCalled();
    expect(component['sucursales']()[1]).toEqual(inactive);
    expect(fixture.nativeElement.querySelector('[role="dialog"]')).toBeNull();
    expect(fixture.nativeElement.querySelector('.branch-name').textContent).toContain('renovada');
  });

  it('rejects blank names and fields exceeding the database limits', () => {
    click('.panel-actions .primary-button');
    component['formulario'].patchValue({ nombre: '   ' });
    submit();
    expect(api.crear).not.toHaveBeenCalled();
    expect(fixture.nativeElement.querySelector('.form-field small')).not.toBeNull();
    component['formulario'].patchValue({ nombre: 'Válida', direccion: 'x'.repeat(201) });
    submit();
    expect(api.crear).not.toHaveBeenCalled();
    component['formulario'].patchValue({ direccion: '', telefono: 'x'.repeat(31) });
    submit();
    expect(api.crear).not.toHaveBeenCalled();
  });

  it('keeps the form and entered data when the API rejects a duplicate name', () => {
    api.crear.mockReturnValue(throwError(() => new HttpErrorResponse({ status: 409 })));
    click('.panel-actions .primary-button');
    component['formulario'].patchValue({
      nombre: branch.nombre,
      direccion: 'Dirección conservada',
    });
    submit();
    expect(fixture.nativeElement.querySelector('[role="dialog"]')).not.toBeNull();
    expect(fixture.nativeElement.querySelector('[role="alert"]').textContent).toContain(
      'Ya existe',
    );
    expect(component['formulario'].controls.direccion.value).toBe('Dirección conservada');
    expect(component['guardando']()).toBe(false);
    expect(component['sucursales']()).toHaveLength(2);
  });

  it('blocks duplicate saves and dismissal while a save is pending', () => {
    const pending = new Subject<SucursalApi>();
    api.crear.mockReturnValue(pending);
    click('.panel-actions .primary-button');
    component['formulario'].patchValue({ nombre: 'Nueva sucursal' });
    submit();
    submit();
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape' }));
    fixture.detectChanges();
    expect(api.crear).toHaveBeenCalledOnce();
    expect(fixture.nativeElement.querySelector('[role="dialog"]')).not.toBeNull();
    expect(fixture.nativeElement.querySelector('fieldset').disabled).toBe(true);
    pending.next({ ...branch, id: 3, nombre: 'Nueva sucursal' });
    pending.complete();
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('[role="dialog"]')).toBeNull();
  });

  it('updates the active state once and refreshes the action and row', () => {
    const pending = new Subject<SucursalApi>();
    api.actualizarEstado.mockReturnValue(pending);
    click('[aria-label="Deshabilitar Nury Providencia"]');
    component['alternarEstadoSucursal'](branch);
    expect(api.actualizarEstado).toHaveBeenCalledExactlyOnceWith(1, false);
    expect(
      fixture.nativeElement.querySelector('[aria-label="Editar Nury Providencia"]').disabled,
    ).toBe(true);
    pending.next({ ...branch, activo: false });
    pending.complete();
    fixture.detectChanges();
    expect(
      fixture.nativeElement.querySelector('[aria-label="Habilitar Nury Providencia"]'),
    ).not.toBeNull();
    expect(component['estadoActualizando'](1)).toBe(false);
    expect(component['sucursales']()[0].activo).toBe(false);
  });

  it('keeps the current state and re-enables actions when the API denies the update', () => {
    api.actualizarEstado.mockReturnValue(throwError(() => new HttpErrorResponse({ status: 403 })));
    click('[aria-label="Deshabilitar Nury Providencia"]');
    expect(component['sucursales']()[0].activo).toBe(true);
    expect(fixture.nativeElement.querySelector('[role="alert"]').textContent).toContain(
      'no tiene permisos',
    );
    expect(component['estadoActualizando'](1)).toBe(false);
  });

  it('shows a loading state, a retryable error and then the recovered list', () => {
    const pending = new Subject<SucursalApi[]>();
    api.listar.mockReturnValue(pending);
    component['cargarSucursales']();
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('.empty-row').textContent).toContain('Cargando');
    expect(fixture.nativeElement.querySelector('.panel-actions .primary-button').disabled).toBe(
      true,
    );
    pending.error(new Error('offline'));
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('[role="alert"]')).not.toBeNull();
    api.listar.mockReturnValue(of([branch]));
    click('.retry-button');
    expect(fixture.nativeElement.querySelectorAll('.branch-name')).toHaveLength(1);
    expect(fixture.nativeElement.querySelector('[role="alert"]')).toBeNull();
    expect(fixture.nativeElement.querySelector('.panel-actions .primary-button').disabled).toBe(
      false,
    );
  });
});
