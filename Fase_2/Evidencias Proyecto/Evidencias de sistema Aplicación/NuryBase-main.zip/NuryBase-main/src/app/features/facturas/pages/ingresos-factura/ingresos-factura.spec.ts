import { Component, output } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { provideRouter } from '@angular/router';
import { Observable, of, throwError } from 'rxjs';
import type { Mock } from 'vitest';
import { FacturasApiService, IngresoFactura } from '../../../../core/api/facturas-api.service';
import { CargaFactura } from '../carga-factura/carga-factura';
import { IngresosFactura } from './ingresos-factura';

/** La carga tiene sus propias pruebas; aquí solo importa cómo se abre y se cierra. */
@Component({ selector: 'app-carga-factura', template: '' })
class CargaFacturaFalsa {
  readonly cerrarModal = output<void>();
  readonly ingresada = output<void>();
}

const INGRESO: IngresoFactura = {
  factura_xml_id: 3,
  factura_compra_id: 7,
  folio: 90000002,
  rut_emisor: '76123456-0',
  razon_social_emisor: 'PROVEEDOR DE PRUEBA SPA',
  proveedor: null,
  fecha_emision: '2026-10-15',
  monto_neto: 85000,
  monto_iva: 16150,
  monto_total: 101150,
  detalle_incluye_iva: false,
  xml_nombre: 'factura_prueba_33.xml',
  sucursal_id: 1,
  sucursal: 'Nury Providencia',
  ingresada_por: 'Nelson Alfaro',
  ingresada_en: '2026-10-20T15:32:00',
  lineas: [
    {
      numero_linea: 1,
      codigo_proveedor: '1001',
      descripcion: 'Harina Sin Polvos 25kg',
      cantidad: 2,
      precio_unitario: 18000,
      monto: 36000,
      tipo: 'ingrediente',
      articulo: 'Harina',
      unidad: 'kg',
      unidades_por_presentacion: 25,
      cantidad_ingreso: 50,
    },
    {
      numero_linea: 2,
      codigo_proveedor: null,
      descripcion: 'Flete',
      cantidad: 1,
      precio_unitario: 5000,
      monto: 5000,
      tipo: 'no-inventario',
      articulo: null,
      unidad: null,
      unidades_por_presentacion: null,
      cantidad_ingreso: null,
    },
  ],
  intentos_duplicados: [],
};

describe('IngresosFactura', () => {
  let fixture: ComponentFixture<IngresosFactura>;
  let listar: Mock<() => Observable<IngresoFactura[]>>;
  let descargar: Mock<(id: number) => Observable<unknown>>;

  beforeEach(async () => {
    listar = vi.fn(() => of([INGRESO]));
    descargar = vi.fn(() => of({ xml_nombre: 'factura_prueba_33.xml', xml_base64: btoa('<SetDTE>ñ</SetDTE>') }));
    await TestBed.configureTestingModule({
      imports: [IngresosFactura],
      providers: [
        provideRouter([]),
        {
          provide: FacturasApiService,
          useValue: { listarIngresos: () => listar(), descargarXml: (id: number) => descargar(id) },
        },
      ],
    })
      .overrideComponent(IngresosFactura, {
        remove: { imports: [CargaFactura] },
        add: { imports: [CargaFacturaFalsa] },
      })
      .compileComponents();
  });

  function crear(): void {
    fixture = TestBed.createComponent(IngresosFactura);
    fixture.detectChanges();
  }

  function texto(): string {
    return ((fixture.nativeElement as HTMLElement).textContent ?? '').replace(/\s+/g, ' ');
  }

  function boton(nombre: string): HTMLButtonElement {
    return Array.from(fixture.nativeElement.querySelectorAll('button')).find(
      (b) => (b as HTMLButtonElement).textContent?.trim() === nombre,
    ) as HTMLButtonElement;
  }

  function dato(nombre: string): string {
    const fila = Array.from(fixture.nativeElement.querySelectorAll('.document-grid div')).find(
      (div) => (div as HTMLElement).querySelector('dt')?.textContent?.trim() === nombre,
    ) as HTMLElement;
    return fila.querySelector('dd')?.textContent?.trim() ?? '';
  }

  it('lists each entered invoice with who entered it, when and where', () => {
    crear();

    expect(texto()).toContain('1 factura ingresada');
    const resumen = ((fixture.nativeElement as HTMLElement).querySelector('.ingreso-resumen')?.textContent ?? '')
      .replace(/\s+/g, ' ');
    expect(resumen).toContain('PROVEEDOR DE PRUEBA SPA');
    expect(resumen).toContain('Folio 90000002 · RUT 76123456-0 · Emitida el 15-10-2026');
    expect(resumen).toContain('Nury Providencia');
    expect(resumen).toContain('Ingresada el 20-10-2026 15:32 por Nelson Alfaro');
    expect(resumen).toContain('1 línea al stock · 1 excluida');
    expect(resumen).toContain('$101.150');
  });

  it('shows net, VAT and the file name only in the detail', () => {
    crear();
    expect(texto()).not.toContain('factura_prueba_33.xml');

    boton('Ver detalle').click();
    fixture.detectChanges();

    expect(dato('Neto')).toBe('$85.000');
    expect(dato('IVA')).toBe('$16.150');
    expect(dato('Total')).toBe('$101.150');
    expect(dato('Archivo')).toBe('factura_prueba_33.xml');
  });

  it('opens the invoice upload in a modal and reloads the list after an entry', () => {
    crear();
    const dialogo = () => (fixture.nativeElement as HTMLElement).querySelector('[role="dialog"]');
    expect(dialogo()).toBeNull();

    boton('Cargar factura').click();
    fixture.detectChanges();
    expect(dialogo()?.querySelector('app-carga-factura')).toBeTruthy();

    const carga = fixture.debugElement.query(By.directive(CargaFacturaFalsa)).componentInstance as CargaFacturaFalsa;
    carga.ingresada.emit();
    expect(listar).toHaveBeenCalledTimes(2);

    carga.cerrarModal.emit();
    fixture.detectChanges();
    expect(dialogo()).toBeNull();
  });

  it('prefers the registered supplier name over the one in the XML', () => {
    listar.mockReturnValue(of([{ ...INGRESO, proveedor: 'Ideal S.A' }]));
    crear();

    expect(fixture.nativeElement.querySelector('.ingreso-principal h2').textContent.trim()).toBe('Ideal S.A');
  });

  it('shows the original lines, the associated article, the equivalence and what was added', () => {
    crear();
    expect(fixture.nativeElement.querySelector('.lines-table')).toBeNull();

    boton('Ver detalle').click();
    fixture.detectChanges();

    const filas = fixture.nativeElement.querySelectorAll('.lines-table tbody tr');
    expect(filas).toHaveLength(2);
    const harina = (filas[0] as HTMLElement).textContent?.replace(/\s+/g, ' ') ?? '';
    expect(harina).toContain('Harina Sin Polvos 25kg');
    expect(harina).toContain('Harina Materia prima');
    expect(harina).toContain('25 kg por presentación');
    expect(harina).toContain('+50 kg');
    const flete = (filas[1] as HTMLElement).textContent?.replace(/\s+/g, ' ') ?? '';
    expect(flete).toContain('No corresponde a inventario');
    expect(flete).not.toContain('por presentación');
    expect(texto()).toContain('Los montos de las líneas son netos (sin IVA).');

    boton('Ocultar detalle').click();
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('.lines-table')).toBeNull();
  });

  it('shows the repeated attempts to enter the same invoice', () => {
    listar.mockReturnValue(
      of([
        {
          ...INGRESO,
          intentos_duplicados: [
            {
              creado_en: '2026-10-20T16:05:00',
              usuario: 'Ana Pérez',
              sucursal_solicitada: 'Nury Vitacura',
              xml_nombre: 'copia.xml',
            },
          ],
        },
      ]),
    );
    crear();

    expect(texto()).toContain('1 intento repetido');
    boton('Ver detalle').click();
    fixture.detectChanges();

    expect(texto()).toContain('Intentos de volver a ingresarla');
    expect(texto()).toContain('20-10-2026 16:05 · Ana Pérez desde Nury Vitacura · archivo copia.xml');
  });

  it('downloads the original XML file byte by byte', () => {
    const crearUrl = vi.fn((_blob: Blob) => 'blob:xml');
    const liberarUrl = vi.fn();
    Object.assign(URL, { createObjectURL: crearUrl, revokeObjectURL: liberarUrl });
    const clic = vi.spyOn(HTMLAnchorElement.prototype, 'click').mockImplementation(() => undefined);
    crear();

    boton('Descargar XML').click();
    fixture.detectChanges();

    expect(descargar).toHaveBeenCalledExactlyOnceWith(3);
    // '<SetDTE>ñ</SetDTE>' en latin1: 18 bytes, uno por carácter (la ñ no se convierte a UTF-8).
    expect(crearUrl.mock.calls[0][0].size).toBe(18);
    const enlace = clic.mock.contexts[0] as HTMLAnchorElement;
    expect(enlace.download).toBe('factura_prueba_33.xml');
    expect(liberarUrl).toHaveBeenCalledWith('blob:xml');
    clic.mockRestore();
  });

  it('tells the user when the XML could not be downloaded', () => {
    descargar.mockReturnValue(throwError(() => new Error('sin conexión')));
    crear();

    boton('Descargar XML').click();
    fixture.detectChanges();

    expect(texto()).toContain('No pudimos descargar el XML. Vuelve a intentarlo.');
    expect(boton('Descargar XML').disabled).toBe(false);
  });

  it('explains when there are no entered invoices yet', () => {
    listar.mockReturnValue(of([]));
    crear();

    expect(texto()).toContain('Aún no hay facturas ingresadas que puedas ver.');
  });

  it('offers a retry when the list cannot be loaded', () => {
    listar.mockReturnValue(throwError(() => new Error('sin conexión')));
    crear();

    expect(texto()).toContain('No pudimos cargar los ingresos.');

    listar.mockReturnValue(of([INGRESO]));
    boton('Reintentar').click();
    fixture.detectChanges();

    expect(texto()).toContain('1 factura ingresada');
  });
});
