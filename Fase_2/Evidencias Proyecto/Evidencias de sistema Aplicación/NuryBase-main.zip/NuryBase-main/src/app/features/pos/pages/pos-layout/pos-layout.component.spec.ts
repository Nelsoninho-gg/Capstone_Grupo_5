import { Component } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { NEVER, of } from 'rxjs';
import { ProductosApiService } from '../../../../core/api/productos-api.service';
import { AppLoaderService } from '../../../../core/services/app-loader.service';
import { BarcodeScanner } from '../../../../core/services/barcode-scanner';
import { PosProduct } from '../../models/pos.model';
import { PosService } from '../../services/pos.service';
import { PosLayoutComponent } from './pos-layout.component';
import { TurnosApiService } from '../../../../core/api/turnos-api.service';
import { AuthService } from '../../../auth/services/auth.service';

@Component({ standalone: true, template: '' })
class DummyComponent {}

const TEST_PRODUCTS: PosProduct[] = [
  {
    id: 1,
    nombre: 'Café Espresso Doble',
    categoriaId: 'BEBESTIBLES - CAFÉ',
    categoriaNombre: 'BEBESTIBLES - CAFÉ',
    codigoInterno: 'NUR-101',
    codigoBarras: '7801234501018',
    precioVenta: 2600,
    icono: '☕',
    descripcion: 'Producto exclusivo para pruebas.',
    activo: true,
  },
  ...[201, 202, 203].map((code, index) => ({
    id: index + 2,
    nombre: ['Sándwich Ave Palta', 'Sándwich Mechada Luco', 'Sándwich Jamón Queso'][index],
    categoriaId: 'ALIMENTOS - SANDWICH',
    categoriaNombre: 'ALIMENTOS - SANDWICH',
    codigoInterno: `NUR-${code}`,
    codigoBarras: `780123450${code}`,
    precioVenta: 4000 + index * 500,
    icono: '🥪',
    descripcion: 'Producto exclusivo para pruebas.',
    activo: true,
  })),
];

const PAGINATION_PRODUCTS: PosProduct[] = Array.from({ length: 23 }, (_, index) => ({
  ...TEST_PRODUCTS[index < 20 ? 0 : 1],
  id: index + 1,
  nombre: `Producto ${index + 1}`,
  codigoInterno: `PAGE-${index + 1}`,
}));

describe('PosLayoutComponent', () => {
  it('renders twelve products per page and navigates through the remaining products', () => {
    const fixture = TestBed.createComponent(PosLayoutComponent);
    fixture.componentInstance.posService.catalog.set(PAGINATION_PRODUCTS);
    fixture.detectChanges();

    const buttons = fixture.nativeElement.querySelectorAll('.catalog-pagination button');
    const previous = buttons[0] as HTMLButtonElement;
    const next = buttons[1] as HTMLButtonElement;
    const visibleNames = () =>
      Array.from(fixture.nativeElement.querySelectorAll('.product-title') as NodeListOf<HTMLElement>)
        .map((element) => element.textContent?.trim());

    expect(visibleNames()).toEqual(PAGINATION_PRODUCTS.slice(0, 12).map((p) => p.nombre));
    expect(previous.disabled).toBe(true);
    expect(next.disabled).toBe(false);

    next.click();
    fixture.detectChanges();
    expect(visibleNames()).toEqual(PAGINATION_PRODUCTS.slice(12).map((p) => p.nombre));
    expect(previous.disabled).toBe(false);

    next.click();
    fixture.detectChanges();
    expect(visibleNames()).toEqual(PAGINATION_PRODUCTS.slice(12).map((p) => p.nombre));
    expect(next.disabled).toBe(true);
    expect(fixture.nativeElement.querySelector('.catalog-pagination span').textContent)
      .toContain('Página 2 de 2');

    previous.click();
    fixture.detectChanges();
    expect(visibleNames()).toEqual(PAGINATION_PRODUCTS.slice(0, 12).map((p) => p.nombre));
  });

  it('returns to the first page when filtering and hides pagination for a single or empty page', () => {
    const fixture = TestBed.createComponent(PosLayoutComponent);
    const component = fixture.componentInstance;
    component.posService.catalog.set(PAGINATION_PRODUCTS);
    fixture.detectChanges();
    component.changeCatalogPage(2);

    component.searchQuery.set('PAGE-23');
    fixture.detectChanges();
    expect(component.catalogPage()).toBe(1);
    expect(fixture.nativeElement.querySelectorAll('.product-card')).toHaveLength(1);
    expect(fixture.nativeElement.querySelector('.product-title').textContent)
      .toContain('Producto 23');
    expect(fixture.nativeElement.querySelector('.catalog-pagination')).toBeNull();

    component.searchQuery.set('');
    component.changeCatalogPage(2);
    component.selectCategory('ALIMENTOS - SANDWICH');
    fixture.detectChanges();
    expect(component.catalogPage()).toBe(1);
    expect(fixture.nativeElement.querySelectorAll('.product-card')).toHaveLength(3);
    expect(fixture.nativeElement.querySelector('.catalog-pagination')).toBeNull();

    component.searchQuery.set('sin coincidencias');
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelectorAll('.product-card')).toHaveLength(0);
    expect(fixture.nativeElement.querySelector('.empty-catalog-state')).not.toBeNull();
    expect(fixture.nativeElement.querySelector('.catalog-pagination')).toBeNull();
  });

  it('finds accented names with unaccented uppercase text', () => {
    const component = TestBed.createComponent(PosLayoutComponent).componentInstance;
    component.searchQuery.set('  CAFE  ');
    expect(component.filteredCatalog().some((p) => p.nombre === 'Café Espresso Doble')).toBe(true);
    component.searchQuery.set('sandwich');
    expect(component.filteredCatalog()).toHaveLength(3);
  });

  it('searches barcode and combines search with category selection', () => {
    const component = TestBed.createComponent(PosLayoutComponent).componentInstance;
    const product = component.catalog()[0];
    component.searchQuery.set(product.codigoBarras);
    expect(component.filteredCatalog()).toEqual([product]);
    component.selectCategory('ALIMENTOS - SANDWICH');
    expect(component.filteredCatalog()).toEqual([]);
    component.selectCategory('');
    expect(component.filteredCatalog()).toEqual([product]);
  });

  it('excludes inactive products from cards and category counts', () => {
    const component = TestBed.createComponent(PosLayoutComponent).componentInstance;
    const product = component.catalog()[0];
    const initialCount = component.getCategoryCount('');
    const categoryCount = component.getCategoryCount(product.categoriaId);
    component.posService.catalog.update((products) =>
      products.map((p) => (p.id === product.id ? { ...p, activo: false } : p)),
    );
    expect(component.getCategoryCount('')).toBe(initialCount - 1);
    expect(component.getCategoryCount(product.categoriaId)).toBe(categoryCount - 1);
    component.searchQuery.set(product.codigoInterno);
    expect(component.filteredCatalog()).toEqual([]);
  });

  it('adds exactly one item through the accessible product button', () => {
    const fixture = TestBed.createComponent(PosLayoutComponent);
    fixture.detectChanges();
    const button = fixture.nativeElement.querySelector(
      'button[aria-label="Agregar Café Espresso Doble"]',
    );
    button.click();
    expect(fixture.componentInstance.cart()).toHaveLength(1);
    expect(fixture.componentInstance.cart()[0].cantidad).toBe(1);
    expect(fixture.componentInstance.cart()[0].producto.nombre).toBe('Café Espresso Doble');
    expect(fixture.componentInstance.total()).toBe(2600);
  });
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PosLayoutComponent],
      providers: [
        { provide: ProductosApiService, useValue: { listar: () => NEVER } },
        { provide: AuthService, useValue: { currentUser: () => ({ id: 1, sucursalId: 1 }) } },
        { provide: TurnosApiService, useValue: { recuperar: () => of({ turno: TestBed.inject(PosService).turnoActivo(), ventas: [] }) } },
        provideRouter([
          { path: 'login', component: DummyComponent },
          { path: 'pos', component: DummyComponent },
        ]),
      ],
    }).compileComponents();

    const posService = TestBed.inject(PosService);
    posService.catalog.set(TEST_PRODUCTS.map((product) => ({ ...product })));
    posService.clearCart();
    // Estas pruebas verifican el comportamiento del POS asumiendo un turno ya
    // iniciado; el flujo real de apertura ahora vive en CajaService/"Caja"
    // (fn_abrir_turno). Acá se simula directamente el estado ya abierto.
    posService.turnoActivo.set({
      id: 1,
      usuario_id: 1,
      sucursal_id: 1,
      hora_inicio: new Date().toISOString(),
      hora_fin: null,
      creado_en: new Date().toISOString(),
      monto_inicial: 0,
    });
  });

  it('should create the pos layout component', () => {
    const fixture = TestBed.createComponent(PosLayoutComponent);
    const component = fixture.componentInstance;
    expect(component).toBeTruthy();
  });

  it('should filter catalog by search query (H2.2)', () => {
    const fixture = TestBed.createComponent(PosLayoutComponent);
    const component = fixture.componentInstance;

    component.searchQuery.set('espresso');
    const filtered = component.filteredCatalog();
    expect(filtered.length).toBeGreaterThan(0);
    expect(
      filtered.every(
        (p) =>
          p.nombre.toLowerCase().includes('espresso') ||
          p.codigoInterno.toLowerCase().includes('espresso') ||
          p.descripcion.toLowerCase().includes('espresso'),
      ),
    ).toBe(true);
  });

  it('should add product on barcode scan (H2.1 & H2.3)', () => {
    const fixture = TestBed.createComponent(PosLayoutComponent);
    const component = fixture.componentInstance;

    component.quickBarcodeInput.set('NUR-201');
    component.onBarcodeScan();

    expect(component.barcodeFeedback()).toContain('NUR-201');
    expect(component.cart().length).toBeGreaterThan(0);
  });

  async function openCamera() {
    const scanner = TestBed.inject(BarcodeScanner);
    const start = vi.spyOn(scanner, 'start').mockResolvedValue();
    const stop = vi.spyOn(scanner, 'stop');
    const fixture = TestBed.createComponent(PosLayoutComponent);
    const component = fixture.componentInstance;
    fixture.detectChanges();
    component.openBarcodeScanner();
    fixture.detectChanges();
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(start).toHaveBeenCalledOnce();
    return { fixture, component, stop, detect: start.mock.calls[0][1] };
  }

  it('adds consecutive camera scans and shows the product and quantity inside the open modal', async () => {
    const { fixture, component, stop, detect } = await openCamera();
    detect('NUR-101');
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('.scanner-feedback').textContent)
      .toContain('Café Espresso Doble agregado al carrito');
    expect(fixture.nativeElement.querySelector('.scanner-feedback').textContent)
      .toContain('Cantidad en carrito: 1');
    detect('NUR-201');
    detect('NUR-101');
    fixture.detectChanges();
    expect(component.totalItemsCount()).toBe(3);
    expect(fixture.nativeElement.querySelector('.scanner-feedback').textContent)
      .toContain('Cantidad en carrito: 2');
    expect(component.isScannerOpen()).toBe(true);
    expect(stop).not.toHaveBeenCalled();

    fixture.nativeElement.querySelector('.scanner-modal-backdrop').click();
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape' }));
    fixture.detectChanges();
    expect(component.isScannerOpen()).toBe(true);
    fixture.nativeElement.querySelector('.scanner-cancel').click();
    fixture.detectChanges();
    expect(stop).toHaveBeenCalledOnce();
    expect(fixture.nativeElement.querySelector('.scanner-modal')).toBeNull();
    detect('NUR-201');
    expect(component.totalItemsCount()).toBe(3);
  });

  it('keeps the camera open on unknown codes and allows the next product to be scanned', async () => {
    const { fixture, component, detect } = await openCamera();
    detect('DESCONOCIDO');
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('.scanner-feedback-error').textContent)
      .toContain('no encontrado');
    expect(component.totalItemsCount()).toBe(0);
    detect('NUR-201');
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('.scanner-feedback').textContent)
      .toContain('Sándwich Ave Palta agregado');
    expect(fixture.nativeElement.querySelector('.scanner-feedback-error')).toBeNull();
    expect(component.isScannerOpen()).toBe(true);
    expect(component.totalItemsCount()).toBe(1);

    component.posService.turnoActivo.set(null);
    detect('NUR-101');
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('.scanner-feedback-error').textContent)
      .toContain('caja está cerrada');
    expect(component.totalItemsCount()).toBe(1);
  });

  it('preserves the latest modal confirmation until another scan and clears it on reopening', async () => {
    const { fixture, component, detect } = await openCamera();
    vi.useFakeTimers();
    try {
      detect('NUR-101');
      vi.advanceTimersByTime(3000);
      fixture.detectChanges();
      expect(component.barcodeFeedback()).toBeNull();
      expect(fixture.nativeElement.querySelector('.scanner-feedback').textContent)
        .toContain('Café Espresso Doble agregado');
      component.closeBarcodeScanner();
      component.openBarcodeScanner();
      fixture.detectChanges();
      expect(fixture.nativeElement.querySelector('.scanner-feedback').textContent)
        .toContain('Esperando un código');
    } finally {
      vi.useRealTimers();
    }
  });

  it('blocks product entry while the register is closed', () => {
    const component = TestBed.createComponent(PosLayoutComponent).componentInstance;
    const product = component.catalog()[0];
    component.posService.turnoActivo.set(null);

    component.addProduct(product);
    component.quickBarcodeInput.set(product.codigoInterno);
    component.onBarcodeScan();

    expect(component.cart()).toHaveLength(0);
    expect(component.barcodeFeedback()).toContain('caja está cerrada');
  });

  it('filters and counts products by unified category group', () => {
    const component = TestBed.createComponent(PosLayoutComponent).componentInstance;
    component.posService.catalog.update((products) => [
      ...products,
      {
        ...products[1],
        id: 99,
        nombre: 'Empanada de Pino',
        categoriaId: 'ALIMENTOS - EMPANADAS',
        categoriaNombre: 'ALIMENTOS - EMPANADAS',
      },
    ]);

    expect(component.categories().some((c) => c.id === 'ALIMENTOS')).toBe(true);
    expect(component.getCategoryCount('ALIMENTOS')).toBe(4);
    component.selectCategory('ALIMENTOS');
    expect(component.filteredCatalog()).toHaveLength(4);

    // La subcategoría original sigue siendo buscable.
    component.searchQuery.set('empanadas');
    expect(component.filteredCatalog().map((p) => p.nombre)).toEqual(['Empanada de Pino']);
  });

  it('opens the cart as a modal from the mobile button and closes it', () => {
    const fixture = TestBed.createComponent(PosLayoutComponent);
    fixture.detectChanges();
    const host: HTMLElement = fixture.nativeElement;

    host.querySelector<HTMLButtonElement>('.mobile-cart-fab')!.click();
    fixture.detectChanges();
    const cart = host.querySelector('#pos-cart')!;
    expect(cart.classList).toContain('sheet-open');
    expect(cart.getAttribute('role')).toBe('dialog');
    expect(host.querySelector('.mobile-cart-fab')).toBeNull();

    host.querySelector<HTMLElement>('.cart-sheet-backdrop')!.click();
    fixture.detectChanges();
    expect(cart.classList).not.toContain('sheet-open');
    expect(cart.getAttribute('role')).toBeNull();
  });

  it('closes the cart modal when continuing to payment', () => {
    const component = TestBed.createComponent(PosLayoutComponent).componentInstance;
    component.addProduct(component.catalog()[0]);
    component.openCartSheet();

    component.openPayment();

    expect(component.isCartSheetOpen()).toBe(false);
    expect(component.isPaymentModalOpen()).toBe(true);
  });

  it('draws each product card with the icon of its category', () => {
    const fixture = TestBed.createComponent(PosLayoutComponent);
    fixture.componentInstance.posService.catalog.update((products) =>
      products.map((p) => ({ ...p, icono: p.id === 1 ? 'coffee' : 'sandwich' })),
    );
    fixture.detectChanges();

    const icons = [...fixture.nativeElement.querySelectorAll('.product-icon')].map((svg: Element) =>
      svg.getAttribute('data-icon'),
    );
    expect(icons).toEqual(['coffee', 'sandwich', 'sandwich', 'sandwich']);
  });

  it('does not cover an already loaded catalog with the coffee loader', () => {
    const fixture = TestBed.createComponent(PosLayoutComponent);
    fixture.detectChanges();

    expect(fixture.componentInstance.catalogLoaderStatus()).toBe('ready');
    expect(fixture.nativeElement.querySelector('.coffee-loader')).toBeNull();
  });

  it('shows the coffee loader over the catalog and retries when the catalog fails', () => {
    const posService = TestBed.inject(PosService);
    posService.catalog.set([]);
    const fixture = TestBed.createComponent(PosLayoutComponent);
    fixture.detectChanges();
    const reload = vi.spyOn(posService, 'cargarCatalogoDesdeApi');

    posService.catalogStatus.set('error');
    fixture.detectChanges();

    const catalog: HTMLElement = fixture.nativeElement.querySelector('.catalog-column');
    expect(catalog.querySelector('.coffee-loader')?.textContent).toContain('No pudimos cargar el catálogo');
    // Mientras no hay catálogo no aparece el aviso de "sin productos"
    expect(catalog.querySelector('.empty-catalog-state')).toBeNull();

    catalog.querySelector<HTMLButtonElement>('.loader-retry')!.click();
    expect(reload).toHaveBeenCalledTimes(1);
  });

  it('joins the fullscreen coffee loader right after login instead of showing its own', () => {
    const appLoader = TestBed.inject(AppLoaderService);
    TestBed.inject(PosService).catalog.set([]);
    appLoader.start();

    const fixture = TestBed.createComponent(PosLayoutComponent);
    fixture.detectChanges();

    expect(fixture.componentInstance.usesAppLoader).toBe(true);
    expect(fixture.nativeElement.querySelector('app-coffee-loader')).toBeNull();
    expect(appLoader.status()).toBe('loading');
  });

  it('shows subtotal, 30% employee discount and total to pay, and requires the employee (H2.12)', () => {
    const fixture = TestBed.createComponent(PosLayoutComponent);
    const component = fixture.componentInstance;
    // Lista ya cargada: la prueba no llama a la API de usuarios.
    component.posService.empleados.set([{ id: 5, nombre: 'Ana Pérez' }]);
    component.posService.empleadosStatus.set('ready');
    component.addProduct(component.catalog()[0]);
    fixture.detectChanges();

    const element: HTMLElement = fixture.nativeElement;
    const charge = () => element.querySelector('.btn-charge') as HTMLButtonElement;
    const checkbox = element.querySelector('.employee-toggle input') as HTMLInputElement;

    expect(element.querySelector('.discount-line')).toBeNull();
    expect(element.querySelector('.employee-select')).toBeNull();
    expect(charge().disabled).toBe(false);

    checkbox.click();
    fixture.detectChanges();

    const lines = Array.from(element.querySelectorAll('.summary-line')).map((line) =>
      line.textContent?.replace(/\s+/g, ' ').trim(),
    );
    expect(lines[0]).toContain('Subtotal:');
    expect(lines[0]).toContain('2.600');
    expect(lines[1]).toContain('Descuento empleado (30%):');
    expect(lines[1]).toContain('780');
    expect(element.querySelector('.total-title')?.textContent).toContain('Total a pagar');
    expect(element.querySelector('.grand-total')?.textContent).toContain('1.820');
    expect(element.querySelector('.employee-hint')).not.toBeNull();
    expect(charge().disabled).toBe(true);

    const select = element.querySelector('.employee-select select') as HTMLSelectElement;
    select.value = select.options[1].value;
    select.dispatchEvent(new Event('change'));
    fixture.detectChanges();

    expect(component.empleadoSeleccionado()?.nombre).toBe('Ana Pérez');
    expect(element.querySelector('.employee-hint')).toBeNull();
    expect(charge().disabled).toBe(false);

    component.posService.updateQuantity(component.catalog()[0].id, 1);
    fixture.detectChanges();
    expect(element.querySelector('.grand-total')?.textContent).toContain('3.640');
  });

  it('keeps session controls out of the POS header', () => {
    const fixture = TestBed.createComponent(PosLayoutComponent);
    fixture.detectChanges();

    expect(fixture.nativeElement.querySelector('.btn-register')).toBeNull();
    expect(fixture.nativeElement.querySelector('.btn-logout')).toBeNull();
  });
});
