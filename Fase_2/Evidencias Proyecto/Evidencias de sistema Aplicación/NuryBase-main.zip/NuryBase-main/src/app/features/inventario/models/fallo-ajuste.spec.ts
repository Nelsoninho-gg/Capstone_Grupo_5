import { HttpErrorResponse } from '@angular/common/http';
import { interpretarFalloAjuste } from './fallo-ajuste';

function respuesta(status: number, code?: string, message?: string): HttpErrorResponse {
  return new HttpErrorResponse({
    status,
    error: code ? { code, message, details: null, hint: null } : null,
  });
}

describe('interpretarFalloAjuste', () => {
  it.each([
    ['sin conexión', respuesta(0), 'conexion', 'reintentar', false],
    ['sesión vencida', respuesta(401, 'PGRST303', 'JWT expired'), 'sesion', 'ninguna', false],
    ['sin permiso (HTTP)', respuesta(403), 'permisos', 'ninguna', false],
    [
      'sin permiso (PostgreSQL)',
      respuesta(401, '42501', 'permission denied for function fn_ajustar_stock'),
      'sesion',
      'ninguna',
      false,
    ],
    [
      'stock insuficiente',
      respuesta(400, '23514', 'El ajuste dejaría el stock en negativo (actual: 1, ajuste: -2)'),
      'stock-insuficiente',
      'corregir',
      true,
    ],
    [
      'artículo inexistente',
      respuesta(409, '23503', 'El ingrediente indicado no existe'),
      'articulo-inexistente',
      'corregir',
      true,
    ],
    [
      'función no publicada',
      respuesta(404, 'PGRST202', 'Could not find the function public.fn_ajustar_stock'),
      'no-disponible',
      'ninguna',
      false,
    ],
    ['error del servidor', respuesta(500), 'servidor', 'reintentar', false],
    ['tiempo agotado', respuesta(504), 'servidor', 'reintentar', false],
  ] as const)('%s', (_caso, error, tipo, accion, actualizarStock) => {
    expect(interpretarFalloAjuste(error)).toEqual(
      expect.objectContaining({ tipo, accion, actualizarStock }),
    );
  });

  it('reports permission errors from PostgreSQL even with a 403 status', () => {
    const fallo = interpretarFalloAjuste(respuesta(403, '42501', 'permission denied'));

    expect(fallo.tipo).toBe('permisos');
    expect(fallo.mensaje).toBe(
      'Tu usuario no tiene permiso para registrar ajustes de stock. El stock no se modificó.',
    );
  });

  it.each([
    [
      'El motivo del ajuste es obligatorio',
      'El motivo del ajuste es obligatorio. El stock no se modificó.',
    ],
    [
      'La cantidad del ajuste es obligatoria y no puede ser 0',
      'La cantidad del ajuste es obligatoria y no puede ser 0. El stock no se modificó.',
    ],
    [
      'Este producto tiene receta: su stock se ajusta a través de sus ingredientes',
      'Este producto tiene receta: su stock se ajusta a través de sus ingredientes. ' +
        'El stock no se modificó.',
    ],
    ['', 'Revisa los datos del ajuste. El stock no se modificó.'],
  ])('shows the database explanation of the invalid data "%s"', (message, esperado) => {
    const fallo = interpretarFalloAjuste(respuesta(400, '22023', message));

    expect(fallo).toEqual(
      expect.objectContaining({ tipo: 'datos-invalidos', accion: 'corregir', mensaje: esperado }),
    );
  });

  it('only asks to refresh the stock for a recipe product among invalid data', () => {
    expect(interpretarFalloAjuste(respuesta(400, '22023', 'tiene receta')).actualizarStock).toBe(
      true,
    );
    expect(interpretarFalloAjuste(respuesta(400, '22023', 'motivo')).actualizarStock).toBe(false);
  });

  it('treats unexpected errors as a retryable server failure', () => {
    expect(interpretarFalloAjuste(new Error('timeout'))).toEqual({
      tipo: 'servidor',
      mensaje:
        'No pudimos registrar el ajuste. Puedes reintentar: el ajuste no se aplicará dos veces.',
      accion: 'reintentar',
      actualizarStock: false,
    });
  });

  it('keeps the database text when the stock would become negative', () => {
    const fallo = interpretarFalloAjuste(
      respuesta(400, '23514', 'El ajuste dejaría el stock en negativo (actual: 1.000, ajuste: -2)'),
    );

    expect(fallo.mensaje).toBe(
      'El ajuste dejaría el stock en negativo (actual: 1.000, ajuste: -2). El stock no se ' +
        'modificó. Revisa la cantidad con el stock actualizado.',
    );
  });

  it('explains a lost connection without promising that nothing happened', () => {
    expect(interpretarFalloAjuste(respuesta(0)).mensaje).toBe(
      'No pudimos comunicarnos con el servidor y no sabemos si el ajuste alcanzó a aplicarse. ' +
        'Revisa la conexión y reintenta sin cambiar los datos: si ya se había aplicado, no se ' +
        'aplicará dos veces.',
    );
  });
});
