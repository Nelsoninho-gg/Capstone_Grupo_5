import { TipoArticulo, normalizarTexto } from '../../inventario/models/inventario.model';

/**
 * Artículo del catálogo (H3.3): una fila de la vista v_articulos (migración
 * 20261021_modelo_articulos.sql). La pestaña Ingredientes del Maestro de Productos usa solo
 * las materias primas.
 */
export interface ArticuloCatalogo {
  tipo: TipoArticulo;
  /** ingredientes.id o productos.id según el tipo. */
  id: number;
  nombre: string;
  /** Abreviatura de la unidad; los productos siempre se cuentan en "un". */
  unidad: string;
  /** Unidad de la materia prima; null en productos. */
  unidadId: number | null;
  codigoBarras: string | null;
  activo: boolean;
}

export interface UnidadCatalogo {
  id: number;
  nombre: string;
  abreviatura: string;
}

export type FiltroTipoCatalogo = 'todos' | TipoArticulo;

export interface CriteriosCatalogo {
  texto: string;
  tipo: FiltroTipoCatalogo;
}

export interface DatosMateriaPrima {
  nombre: string;
  unidadId: number;
  codigoBarras: string | null;
}

export function claveArticulo(articulo: Pick<ArticuloCatalogo, 'tipo' | 'id'>): string {
  return `${articulo.tipo}-${articulo.id}`;
}

/** Búsqueda sin tildes por nombre o código de barras, filtro por tipo y orden por nombre. */
export function filtrarCatalogo(
  articulos: ArticuloCatalogo[],
  criterios: CriteriosCatalogo,
): ArticuloCatalogo[] {
  const texto = normalizarTexto(criterios.texto);
  return articulos
    .filter((articulo) => criterios.tipo === 'todos' || articulo.tipo === criterios.tipo)
    .filter(
      (articulo) =>
        !texto ||
        normalizarTexto(articulo.nombre).includes(texto) ||
        (articulo.codigoBarras ?? '').includes(texto),
    )
    .sort((a, b) => a.nombre.localeCompare(b.nombre, 'es'));
}

export function contarPorTipo(articulos: ArticuloCatalogo[]): Record<FiltroTipoCatalogo, number> {
  const conteo = { todos: articulos.length, materia_prima: 0, producto: 0 };
  for (const articulo of articulos) conteo[articulo.tipo]++;
  return conteo;
}

/**
 * Nombre como se guarda (H3.3 T05): sin espacios en los extremos ni repetidos. Es lo mismo que
 * hace el trigger fn_limpiar_nombre_y_codigo en la base.
 */
export function limpiarNombre(nombre: string): string {
  return nombre.trim().replace(/\s+/g, ' ');
}

/**
 * Clave para comparar nombres duplicados, igual que fn_nombre_normalizado en la base:
 * sin distinguir mayúsculas ni espacios. Las tildes sí cuentan ("Piña" y "Pina" son distintos).
 */
export function claveNombre(nombre: string): string {
  return limpiarNombre(nombre).toLocaleLowerCase('es');
}

/** Clave para comparar códigos de barras, igual que fn_codigo_normalizado: mayúsculas, sin espacios. */
export function claveCodigo(codigo: string | null | undefined): string | null {
  const clave = (codigo ?? '').replace(/\s/g, '').toUpperCase();
  return clave || null;
}

/** Nombre repetido entre las materias primas (sin mayúsculas ni espacios), salvo la que se edita. */
export function nombreRepetido(
  articulos: ArticuloCatalogo[],
  nombre: string,
  excepto: number | null,
): boolean {
  const buscado = claveNombre(nombre);
  return articulos.some(
    (articulo) =>
      articulo.tipo === 'materia_prima' &&
      articulo.id !== excepto &&
      claveNombre(articulo.nombre) === buscado,
  );
}

/** Código de barras repetido entre las materias primas (sin mayúsculas ni espacios). */
export function codigoRepetido(
  articulos: ArticuloCatalogo[],
  codigo: string | null,
  excepto: number | null,
): boolean {
  const buscado = claveCodigo(codigo);
  return (
    buscado !== null &&
    articulos.some(
      (articulo) =>
        articulo.tipo === 'materia_prima' &&
        articulo.id !== excepto &&
        claveCodigo(articulo.codigoBarras) === buscado,
    )
  );
}
