import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, computed, inject, input, signal } from '@angular/core';
import { rxResource } from '@angular/core/rxjs-interop';
import {
  AjusteStock,
  ClaseAjuste,
  FiltroMermas,
  TipoArticulo,
  agruparMermas,
} from '../../models/inventario.model';
import { InventarioService } from '../../services/inventario.service';

type Periodo = 'hoy' | '7-dias' | '30-dias' | 'mes' | 'personalizado';

const TODAS_LAS_SUCURSALES = 'todas';

const formatoCantidad = new Intl.NumberFormat('es-CL', { maximumFractionDigits: 3 });
const formatoFecha = new Intl.DateTimeFormat('es-CL', {
  day: '2-digit',
  month: '2-digit',
  year: 'numeric',
});
const formatoHora = new Intl.DateTimeFormat('es-CL', {
  hour: '2-digit',
  minute: '2-digit',
  hourCycle: 'h23',
});

/**
 * Consulta de ajustes manuales y mermas por sucursal y periodo (H3.6 T01), con totales
 * por artículo y unidad. Lee movimientos_stock desde H3.6 T07; "Solo mermas" muestra los
 * movimientos de tipo merma, que la base registra aparte de los ajustes.
 */
@Component({
  selector: 'app-reporte-mermas',
  templateUrl: './reporte-mermas.html',
  styleUrls: ['../../styles/inventario-base.css', './reporte-mermas.css'],
})
export class ReporteMermas implements OnInit {
  private readonly inventarioService = inject(InventarioService);

  readonly sucursales = input.required<{ id: number; nombre: string }[]>();
  /** Sucursal elegida en el panel de existencias, para abrir el reporte en el mismo contexto. */
  readonly sucursalInicial = input(TODAS_LAS_SUCURSALES);
  /** Cambia con cada ajuste confirmado para volver a consultar sin recargar la página. */
  readonly version = input(0);

  protected readonly periodos: { valor: Periodo; etiqueta: string }[] = [
    { valor: 'hoy', etiqueta: 'Hoy' },
    { valor: '7-dias', etiqueta: 'Últimos 7 días' },
    { valor: '30-dias', etiqueta: 'Últimos 30 días' },
    { valor: 'mes', etiqueta: 'Este mes' },
    { valor: 'personalizado', etiqueta: 'Personalizado' },
  ];

  protected readonly filtroSucursal = signal(TODAS_LAS_SUCURSALES);
  protected readonly soloMermas = signal(false);
  protected readonly periodo = signal<Periodo>('7-dias');
  protected readonly desdePersonalizado = signal(fechaLocal(sumarDias(new Date(), -6)));
  protected readonly hastaPersonalizado = signal(fechaLocal(new Date()));
  protected readonly hoy = fechaLocal(new Date());

  /** Rango consultado, o el motivo por el que no se puede consultar. */
  protected readonly rango = computed((): { desde: string; hasta: string } | { error: string } => {
    const hoy = new Date();
    switch (this.periodo()) {
      case 'hoy':
        return { desde: fechaLocal(hoy), hasta: fechaLocal(hoy) };
      case '7-dias':
        return { desde: fechaLocal(sumarDias(hoy, -6)), hasta: fechaLocal(hoy) };
      case '30-dias':
        return { desde: fechaLocal(sumarDias(hoy, -29)), hasta: fechaLocal(hoy) };
      case 'mes':
        return {
          desde: fechaLocal(new Date(hoy.getFullYear(), hoy.getMonth(), 1)),
          hasta: fechaLocal(hoy),
        };
      case 'personalizado': {
        const desde = this.desdePersonalizado();
        const hasta = this.hastaPersonalizado();
        if (!desde || !hasta) return { error: 'Indica la fecha inicial y la final.' };
        if (desde > hasta) return { error: 'La fecha inicial no puede ser posterior a la final.' };
        return { desde, hasta };
      }
    }
  });

  protected readonly errorRango = computed(() => {
    const rango = this.rango();
    return 'error' in rango ? rango.error : null;
  });

  protected readonly mermas = rxResource({
    params: () => {
      const rango = this.rango();
      if ('error' in rango) return undefined;
      const sucursal = this.filtroSucursal();
      return {
        sucursalId: sucursal === TODAS_LAS_SUCURSALES ? null : Number(sucursal),
        ...rango,
        soloMermas: this.soloMermas(),
        version: this.version(),
      };
    },
    stream: ({ params }) => {
      const filtro: FiltroMermas = {
        sucursalId: params.sucursalId,
        desde: params.desde,
        hasta: params.hasta,
        soloMermas: params.soloMermas,
      };
      return this.inventarioService.listarMermas(filtro);
    },
  });

  protected readonly ajustes = computed<AjusteStock[]>(() =>
    this.mermas.hasValue() ? this.mermas.value() : [],
  );
  protected readonly totales = computed(() => agruparMermas(this.ajustes()));
  protected readonly cargando = computed(() => this.mermas.isLoading());
  protected readonly conError = computed(() => this.mermas.status() === 'error');
  /** PostgREST responde 403 cuando el rol de la sesión no puede leer movimientos_stock. */
  protected readonly sinPermiso = computed(() => {
    const error = this.mermas.error();
    return error instanceof HttpErrorResponse && error.status === 403;
  });

  protected readonly textoPeriodo = computed(() => {
    const rango = this.rango();
    if ('error' in rango) return '';
    const desde = formatoFecha.format(desdeFechaLocal(rango.desde));
    const hasta = formatoFecha.format(desdeFechaLocal(rango.hasta));
    return desde === hasta ? `el ${desde}` : `del ${desde} al ${hasta}`;
  });

  ngOnInit(): void {
    const inicial = this.sucursalInicial();
    const existe = this.sucursales().some((sucursal) => String(sucursal.id) === inicial);
    this.filtroSucursal.set(existe ? inicial : TODAS_LAS_SUCURSALES);
  }

  protected reintentar(): void {
    this.mermas.reload();
  }

  protected actualizarSucursal(event: Event): void {
    this.filtroSucursal.set((event.target as HTMLSelectElement).value);
  }

  protected actualizarClase(event: Event): void {
    this.soloMermas.set((event.target as HTMLSelectElement).value === 'mermas');
  }

  protected actualizarPeriodo(event: Event): void {
    this.periodo.set((event.target as HTMLSelectElement).value as Periodo);
  }

  protected actualizarDesde(event: Event): void {
    this.desdePersonalizado.set((event.target as HTMLInputElement).value);
  }

  protected actualizarHasta(event: Event): void {
    this.hastaPersonalizado.set((event.target as HTMLInputElement).value);
  }

  protected etiquetaTipo(tipo: TipoArticulo): string {
    return tipo === 'producto' ? 'Producto' : 'Materia prima';
  }

  protected etiquetaClase(clase: ClaseAjuste): string {
    return clase === 'merma' ? 'Merma' : 'Ajuste';
  }

  /** "1 ajuste", "3 mermas"… según la vista elegida. */
  protected contar(cantidad: number): string {
    const [singular, plural] = this.soloMermas() ? ['merma', 'mermas'] : ['ajuste', 'ajustes'];
    return `${cantidad} ${cantidad === 1 ? singular : plural}`;
  }

  protected formatearCantidad(cantidad: number): string {
    return formatoCantidad.format(cantidad);
  }

  /** +1 o −0,25: el signo dice si entró o salió. */
  protected formatearConSigno(cantidad: number): string {
    return `${cantidad < 0 ? '−' : '+'}${formatoCantidad.format(Math.abs(cantidad))}`;
  }

  protected formatearFecha(fecha: Date): string {
    return formatoFecha.format(fecha);
  }

  protected formatearHora(fecha: Date): string {
    return formatoHora.format(fecha);
  }
}

/** Fecha local en formato AAAA-MM-DD, el mismo de los campos de tipo date. */
function fechaLocal(fecha: Date): string {
  const mes = String(fecha.getMonth() + 1).padStart(2, '0');
  const dia = String(fecha.getDate()).padStart(2, '0');
  return `${fecha.getFullYear()}-${mes}-${dia}`;
}

function desdeFechaLocal(texto: string): Date {
  const [anio, mes, dia] = texto.split('-').map(Number);
  return new Date(anio, mes - 1, dia);
}

function sumarDias(fecha: Date, dias: number): Date {
  const resultado = new Date(fecha);
  resultado.setDate(resultado.getDate() + dias);
  return resultado;
}
