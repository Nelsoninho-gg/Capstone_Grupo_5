/**
 * Lector de facturas electrónicas (DTE tipo 33) en XML (H3.1 T03).
 *
 * Lee el archivo en el navegador para previsualizarlo antes de tocar stock. No
 * reemplaza la validación en servidor: la confirmación (H3.1 T08) vuelve a
 * comprobar los datos en PostgreSQL.
 *
 * Los nombres de campo siguen las columnas de `facturas_xml_pendientes` y
 * `facturas_xml_pendientes_lineas` (database/migrations/20261016_facturas_xml_pendientes.sql).
 */

export interface LineaFacturaXml {
  numero_linea: number;
  codigo_tipo: string | null;
  codigo_proveedor: string | null;
  descripcion: string;
  cantidad: number;
  precio_unitario: number;
  monto: number;
}

export interface FacturaXml {
  tipo_documento: 33;
  folio: number;
  rut_emisor: string;
  rut_emisor_normalizado: string;
  razon_social_emisor: string | null;
  /** Solo informativo: el receptor no se valida (decisión 16/10/2026). */
  rut_receptor: string | null;
  fecha_emision: string;
  fecha_vencimiento: string | null;
  forma_pago: number | null;
  /** Folio de la referencia tipo 801 (orden de compra), si viene. */
  orden_compra_referencia: string | null;
  monto_neto: number;
  monto_exento: number;
  monto_iva: number;
  tasa_iva: number | null;
  monto_total: number;
  /** `IndMntBruto = 1`. Si no viene, las líneas se asumen netas (supuesto registrado). */
  detalle_incluye_iva: boolean;
  lineas: LineaFacturaXml[];
}

export type ResultadoLecturaXml =
  | { valida: true; factura: FacturaXml; avisos: string[] }
  | { valida: false; errores: string[]; avisos: string[] };

const TIPO_FACTURA_ELECTRONICA = 33;
const TIPO_REFERENCIA_ORDEN_COMPRA = '801';
/** Diferencia aceptada por redondeo entre cantidad × precio y el monto de una línea. */
const TOLERANCIA_REDONDEO = 1;

/**
 * Convierte los bytes del archivo a texto según la codificación declarada en
 * `<?xml ... encoding="..."?>`. Los DTE del SII suelen venir en ISO-8859-1;
 * leídos como UTF-8 se rompen la ñ y los acentos.
 */
export function decodificarXml(bytes: Uint8Array): string {
  if (bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf) {
    return new TextDecoder('utf-8').decode(bytes.subarray(3));
  }
  const prologo = new TextDecoder('latin1').decode(bytes.subarray(0, 200));
  const codificacion = /^<\?xml[^>]*encoding\s*=\s*["']([^"']+)["']/i.exec(prologo)?.[1] ?? 'utf-8';
  try {
    return new TextDecoder(codificacion).decode(bytes);
  } catch {
    throw new Error(`El archivo declara una codificación desconocida (${codificacion}).`);
  }
}

/**
 * Deja el RUT como `12345678-K`: sin puntos ni espacios, con guion y el dígito
 * verificador en mayúscula. Devuelve null si el formato o el dígito no son válidos.
 */
export function normalizarRut(rut: string): string | null {
  const limpio = rut.replace(/[.\s]/g, '').toUpperCase();
  const partes = /^0*(\d{1,8})-?([\dK])$/.exec(limpio);
  if (!partes) return null;
  const [, cuerpo, dv] = partes;
  return digitoVerificador(cuerpo) === dv ? `${cuerpo}-${dv}` : null;
}

function digitoVerificador(cuerpo: string): string {
  let suma = 0;
  let factor = 2;
  for (let i = cuerpo.length - 1; i >= 0; i--) {
    suma += Number(cuerpo[i]) * factor;
    factor = factor === 7 ? 2 : factor + 1;
  }
  const resto = 11 - (suma % 11);
  return resto === 11 ? '0' : resto === 10 ? 'K' : String(resto);
}

/** Lee y valida una factura electrónica tipo 33 a partir de los bytes del archivo. */
export function leerFacturaXml(bytes: Uint8Array): ResultadoLecturaXml {
  let texto: string;
  try {
    texto = decodificarXml(bytes);
  } catch (error) {
    return invalida([(error as Error).message]);
  }

  const xml = new DOMParser().parseFromString(texto, 'application/xml');
  if (xml.getElementsByTagName('parsererror').length > 0) {
    return invalida(['El archivo no es un XML válido o está dañado.']);
  }

  const documentos = Array.from(xml.getElementsByTagNameNS('*', 'Documento'));
  if (documentos.length === 0) {
    return invalida(['El archivo no contiene un documento tributario electrónico (DTE).']);
  }
  if (documentos.length > 1) {
    return invalida([`El archivo contiene ${documentos.length} documentos. Carga una factura a la vez.`]);
  }

  return leerDocumento(documentos[0]);
}

function leerDocumento(documento: Element): ResultadoLecturaXml {
  const errores: string[] = [];
  const avisos: string[] = [];

  const encabezado = hijo(documento, 'Encabezado');
  const idDoc = hijo(encabezado, 'IdDoc');
  const emisor = hijo(encabezado, 'Emisor');
  const receptor = hijo(encabezado, 'Receptor');
  const totales = hijo(encabezado, 'Totales');

  const tipo = texto(idDoc, 'TipoDTE');
  if (tipo === null) {
    errores.push('No indica el tipo de documento (TipoDTE).');
  } else if (Number(tipo) !== TIPO_FACTURA_ELECTRONICA) {
    // Sin tipo 33 el resto de las reglas no aplica: se informa solo este motivo.
    return invalida([`El documento es tipo ${tipo}. Solo se aceptan facturas electrónicas (tipo 33).`]);
  }

  const folio = entero(texto(idDoc, 'Folio'));
  if (folio === null || folio <= 0) errores.push('El folio falta o no es un número válido.');

  const fechaEmision = texto(idDoc, 'FchEmis');
  if (!esFecha(fechaEmision)) errores.push('La fecha de emisión falta o no es válida.');

  const fechaVencimiento = texto(idDoc, 'FchVenc');
  if (fechaVencimiento !== null && !esFecha(fechaVencimiento)) {
    errores.push('La fecha de vencimiento no es válida.');
  }

  const rutEmisor = texto(emisor, 'RUTEmisor');
  const rutEmisorNormalizado = rutEmisor === null ? null : normalizarRut(rutEmisor);
  if (rutEmisor === null) {
    errores.push('No indica el RUT del emisor.');
  } else if (rutEmisorNormalizado === null) {
    errores.push(`El RUT del emisor (${rutEmisor}) no es válido.`);
  }

  const montoNeto = entero(texto(totales, 'MntNeto'));
  const montoExento = entero(texto(totales, 'MntExe')) ?? 0;
  const montoIva = entero(texto(totales, 'IVA'));
  const montoTotal = entero(texto(totales, 'MntTotal'));
  const tasaIva = decimal(texto(totales, 'TasaIVA'));
  if (montoNeto === null) errores.push('Falta el monto neto (MntNeto) o no es un número entero.');
  if (montoIva === null) errores.push('Falta el IVA o no es un número entero.');
  if (montoTotal === null) errores.push('Falta el monto total (MntTotal) o no es un número entero.');

  if (montoNeto !== null && montoIva !== null && montoTotal !== null) {
    const otrosImpuestos = hijos(totales, 'ImptoReten').reduce(
      (suma, impuesto) => suma + (entero(texto(impuesto, 'MontoImp')) ?? 0),
      0,
    );
    const esperado = montoNeto + montoExento + montoIva + otrosImpuestos;
    if (esperado !== montoTotal) {
      errores.push(
        `Los totales no cuadran: neto, exento, IVA e impuestos suman ${pesos(esperado)}, ` +
          `pero el total informado es ${pesos(montoTotal)}.`,
      );
    }
    if (tasaIva !== null) {
      const ivaCalculado = Math.round((montoNeto * tasaIva) / 100);
      if (ivaCalculado !== montoIva) {
        // Se acepta la diferencia (decisión 16/10/2026); solo se informa.
        avisos.push(
          `El IVA informado (${pesos(montoIva)}) difiere en ${pesos(Math.abs(montoIva - ivaCalculado))} ` +
            `del ${tasaIva} % del neto (${pesos(ivaCalculado)}).`,
        );
      }
    }
  }

  const detalleIncluyeIva = texto(idDoc, 'IndMntBruto') === '1';
  if (texto(idDoc, 'IndMntBruto') === null) {
    avisos.push('La factura no indica si las líneas incluyen IVA; se asumen netas.');
  }

  const lineas = leerLineas(documento, errores, avisos);

  if (montoNeto !== null && lineas.length > 0 && !detalleIncluyeIva) {
    const sumaAfectas = hijos(documento, 'Detalle')
      .filter((detalle) => texto(detalle, 'IndExe') === null)
      .reduce((suma, detalle) => suma + (entero(texto(detalle, 'MontoItem')) ?? 0), 0);
    if (sumaAfectas !== montoNeto) {
      avisos.push(
        `La suma de las líneas (${pesos(sumaAfectas)}) no coincide con el neto (${pesos(montoNeto)}). ` +
          'Puede deberse a descuentos o recargos globales.',
      );
    }
  }

  if (errores.length > 0) return { valida: false, errores, avisos };

  return {
    valida: true,
    avisos,
    factura: {
      tipo_documento: TIPO_FACTURA_ELECTRONICA,
      folio: folio!,
      rut_emisor: rutEmisor!,
      rut_emisor_normalizado: rutEmisorNormalizado!,
      razon_social_emisor: texto(emisor, 'RznSoc'),
      rut_receptor: texto(receptor, 'RUTRecep'),
      fecha_emision: fechaEmision!,
      fecha_vencimiento: fechaVencimiento,
      forma_pago: entero(texto(idDoc, 'FmaPago')),
      orden_compra_referencia: ordenDeCompra(documento),
      monto_neto: montoNeto!,
      monto_exento: montoExento,
      monto_iva: montoIva!,
      tasa_iva: tasaIva,
      monto_total: montoTotal!,
      detalle_incluye_iva: detalleIncluyeIva,
      lineas,
    },
  };
}

function leerLineas(documento: Element, errores: string[], avisos: string[]): LineaFacturaXml[] {
  const detalles = hijos(documento, 'Detalle');
  if (detalles.length === 0) {
    errores.push('La factura no trae líneas de detalle.');
    return [];
  }

  return detalles.map((detalle, indice) => {
    const numero = entero(texto(detalle, 'NroLinDet')) ?? indice + 1;
    const descripcion = texto(detalle, 'NmbItem');
    const cantidad = decimal(texto(detalle, 'QtyItem'));
    const precio = decimal(texto(detalle, 'PrcItem'));
    const monto = entero(texto(detalle, 'MontoItem'));
    const codigo = hijo(detalle, 'CdgItem');

    if (descripcion === null) errores.push(`Línea ${numero}: falta la descripción del artículo.`);
    if (cantidad === null || cantidad <= 0) {
      errores.push(`Línea ${numero}: la cantidad falta o no es mayor que cero.`);
    }
    if (precio === null) errores.push(`Línea ${numero}: falta el precio unitario.`);
    if (monto === null) errores.push(`Línea ${numero}: falta el monto de la línea.`);

    if (cantidad !== null && precio !== null && monto !== null) {
      const descuento = entero(texto(detalle, 'DescuentoMonto')) ?? 0;
      const recargo = entero(texto(detalle, 'RecargoMonto')) ?? 0;
      const calculado = cantidad * precio - descuento + recargo;
      if (Math.abs(calculado - monto) > TOLERANCIA_REDONDEO) {
        avisos.push(
          `Línea ${numero}: cantidad × precio da ${pesos(Math.round(calculado))}, ` +
            `pero el monto informado es ${pesos(monto)}.`,
        );
      }
    }

    return {
      numero_linea: numero,
      codigo_tipo: texto(codigo, 'TpoCodigo'),
      codigo_proveedor: texto(codigo, 'VlrCodigo'),
      descripcion: descripcion ?? '',
      cantidad: cantidad ?? 0,
      precio_unitario: precio ?? 0,
      monto: monto ?? 0,
    };
  });
}

function ordenDeCompra(documento: Element): string | null {
  const referencia = hijos(documento, 'Referencia').find(
    (ref) => texto(ref, 'TpoDocRef') === TIPO_REFERENCIA_ORDEN_COMPRA,
  );
  return texto(referencia ?? null, 'FolioRef');
}

// Lectura de nodos sin depender del namespace: los DTE pueden venir con o sin
// xmlns="http://www.sii.cl/SiiDte".

function hijos(padre: Element | null, nombre: string): Element[] {
  if (!padre) return [];
  return Array.from(padre.children).filter((el) => el.localName === nombre);
}

function hijo(padre: Element | null, nombre: string): Element | null {
  return hijos(padre, nombre)[0] ?? null;
}

/** Texto del hijo sin espacios en los extremos; null si no existe o está vacío. */
function texto(padre: Element | null, nombre: string): string | null {
  const valor = hijo(padre, nombre)?.textContent?.trim();
  return valor ? valor : null;
}

function entero(valor: string | null): number | null {
  return valor !== null && /^-?\d+$/.test(valor) ? Number(valor) : null;
}

function decimal(valor: string | null): number | null {
  return valor !== null && /^-?\d+(\.\d+)?$/.test(valor) ? Number(valor) : null;
}

function esFecha(valor: string | null): valor is string {
  if (valor === null || !/^\d{4}-\d{2}-\d{2}$/.test(valor)) return false;
  const fecha = new Date(`${valor}T00:00:00Z`);
  return !Number.isNaN(fecha.getTime()) && fecha.toISOString().startsWith(valor);
}

function pesos(monto: number): string {
  return `$${monto.toLocaleString('es-CL')}`;
}

function invalida(errores: string[]): ResultadoLecturaXml {
  return { valida: false, errores, avisos: [] };
}
