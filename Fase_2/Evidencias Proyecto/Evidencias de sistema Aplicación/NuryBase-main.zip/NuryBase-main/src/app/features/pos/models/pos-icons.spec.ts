import { POS_ICON_PATHS, posIconPath, resolvePosIcon } from './pos-icons';

describe('resolvePosIcon', () => {
  it('assigns a specific icon to each real category of the catalog', () => {
    const expected: Record<string, string> = {
      'ALIMENTOS - EMPANADAS': 'empanada',
      'ALIMENTOS - SANDWICH': 'sandwich',
      'ALIMENTOS - COMPLETO': 'hotdog',
      'ALIMENTOS - CHAPARRITA': 'chaparrita',
      'ALIMENTOS - PIZZA': 'pizza',
      'ALIMENTOS - PAPAS': 'fries',
      'ALIMENTOS - PASTEL': 'cake',
      'ALIMENTOS - GHOAN': 'riceBowl',
      'ALIMENTOS - HAND ROLL': 'handroll',
      'ALIMENTOS - ENSALADA': 'bowl',
      'ALIMENTOS - VEGANOS': 'bowl',
      'ALIMENTOS - ALMUERZO': 'lunch',
      'ALIMENTOS - FAJITA': 'wrap',
      'ALIMENTOS - FRUTA': 'fruit',
      'ALIMENTOS - YOGURTH': 'yogurt',
      'BEBESTIBLES - CAFÉ': 'coffee',
      'BEBESTIBLES - CHOCOLATE': 'mug',
      'BEBESTIBLES - TE': 'tea',
      'BEBESTIBLES - BOTELLA': 'bottle',
      'BEBESTIBLES - ISOTONICAS': 'energy',
      'BEBESTIBLES - LATA': 'can',
      'BEBESTIBLES - JUGO': 'juice',
      'BEBESTIBLES - LECHE': 'milk',
      'GOLOSINAS - PAPAS': 'chips',
      'GOLOSINAS - CHOCOLATE': 'chocolateBar',
      'GOLOSINAS - BARRA': 'bar',
      'GOLOSINAS - TURRON': 'bar',
      'GOLOSINAS - CHICLE': 'gum',
      'GOLOSINAS - GALLETAS': 'cookie',
      'GOLOSINAS - DULCES': 'candy',
      'HELADOS - HELADOS': 'iceCream',
      'OTROS - ENCENDEDOR': 'lighter',
      'OTROS - LAPIZ': 'pencil',
      'OTROS - GOMA': 'eraser',
      'OTROS - PAÑUELOS': 'tissues',
    };

    for (const [categoria, icon] of Object.entries(expected)) {
      expect(`${categoria} → ${resolvePosIcon(categoria)}`).toBe(`${categoria} → ${icon}`);
    }
  });

  it('falls back to the product name, then to the family, then to a generic bag', () => {
    expect(resolvePosIcon('Sin categoría', 'Empanada de pino')).toBe('empanada');
    expect(resolvePosIcon('GOLOSINAS - VARIOS', 'MANTECOL 41G')).toBe('candy');
    expect(resolvePosIcon('ALIMENTOS - AGREGADOS', 'AGREGADO PALTA')).toBe('lunch');
    expect(resolvePosIcon('OTROS - PAPELILLO', 'PAPELILLO OCB PREMIUM')).toBe('bag');
  });

  it('never uses the drink-with-straw icon for food or sweets', () => {
    expect(resolvePosIcon('ALIMENTOS - EMPANADAS')).not.toBe('juice');
    expect(resolvePosIcon('GOLOSINAS - VARIOS')).not.toBe('juice');
    expect(resolvePosIcon('HELADOS - HELADOS')).not.toBe('juice');
  });

  it('returns the generic bag path for unknown icon keys', () => {
    expect(posIconPath('empanada')).toBe(POS_ICON_PATHS.empanada);
    expect(posIconPath('🛍️')).toBe(POS_ICON_PATHS.bag);
  });
});
