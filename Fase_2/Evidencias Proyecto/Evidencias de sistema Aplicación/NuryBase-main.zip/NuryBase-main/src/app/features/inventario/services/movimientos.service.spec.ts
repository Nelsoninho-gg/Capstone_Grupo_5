import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { firstValueFrom } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { MovimientoApi, MovimientosService } from './movimientos.service';

const URL = `${environment.apiUrl}/v_movimientos_articulos`;

describe('MovimientosService', () => {
  let service: MovimientosService;
  let http: HttpTestingController;

  const fila: MovimientoApi = {
    movimiento_id: 90,
    tipo_movimiento: 'venta',
    venta_id: 67,
    referencia_tipo: 'venta',
    referencia_id: 67,
    cantidad: '-1.000',
    unidad: 'un',
    stock_resultante: '4.000',
    sucursal_id: 1,
    sucursal: 'Nury Providencia',
    fecha: '2026-10-22T16:53:52.604912+00:00',
    nota: null,
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()],
    });
    service = TestBed.inject(MovimientosService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  it('lists the newest movements of an article in one branch', async () => {
    const resultado = firstValueFrom(service.listar('producto', 21, 1));
    const peticion = http.expectOne((r) => r.url === URL);
    const params = peticion.request.params;
    expect(params.get('tipo_articulo')).toBe('eq.producto');
    expect(params.get('articulo_id')).toBe('eq.21');
    expect(params.get('sucursal_id')).toBe('eq.1');
    expect(params.get('order')).toBe('fecha.desc,movimiento_id.desc');
    expect(params.get('limit')).toBe('100');
    peticion.flush([fila]);

    const [movimiento] = await resultado;
    expect(movimiento).toEqual({
      id: 90,
      tipo: 'venta',
      ventaId: 67,
      referenciaTipo: 'venta',
      referenciaId: 67,
      cantidad: -1,
      unidad: 'un',
      stockResultante: 4,
      sucursalId: 1,
      sucursal: 'Nury Providencia',
      fecha: new Date('2026-10-22T16:53:52.604912+00:00'),
      nota: null,
    });
  });

  it('does not filter by branch when opened from the Catalog', async () => {
    const resultado = firstValueFrom(service.listar('materia_prima', 4, null));
    const peticion = http.expectOne((r) => r.url === URL);
    expect(peticion.request.params.has('sucursal_id')).toBe(false);
    peticion.flush([]);
    expect(await resultado).toEqual([]);
  });
});
