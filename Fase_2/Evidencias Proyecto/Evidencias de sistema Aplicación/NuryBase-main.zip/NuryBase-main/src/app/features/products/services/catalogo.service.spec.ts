import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { firstValueFrom } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { ArticuloCatalogo } from '../models/catalogo.model';
import { ArticuloApi, CatalogoService } from './catalogo.service';

const API = environment.apiUrl;
const VISTA_URL = `${API}/v_articulos`;

describe('CatalogoService', () => {
  let service: CatalogoService;
  let http: HttpTestingController;

  const filaHarina: ArticuloApi = {
    tipo: 'materia_prima',
    articulo_id: 3,
    nombre: 'Harina',
    unidad_id: 1,
    unidad: 'kg',
    codigo_barras: null,
    activo: true,
  };
  const harina: ArticuloCatalogo = {
    tipo: 'materia_prima',
    id: 3,
    nombre: 'Harina',
    unidad: 'kg',
    unidadId: 1,
    codigoBarras: null,
    activo: true,
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()],
    });
    service = TestBed.inject(CatalogoService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  /** Responde la relectura de un artículo desde la vista después de un cambio. */
  function responderRelectura(tipo: string, id: number, fila: ArticuloApi): void {
    const relectura = http.expectOne(
      (r) =>
        r.method === 'GET' &&
        r.url === VISTA_URL &&
        r.params.get('tipo') === `eq.${tipo}` &&
        r.params.get('articulo_id') === `eq.${id}`,
    );
    relectura.flush([fila]);
  }

  it('lists only the raw materials of v_articulos ordered by name', async () => {
    const resultado = firstValueFrom(service.listarMateriasPrimas());
    const peticion = http.expectOne((r) => r.method === 'GET' && r.url === VISTA_URL);
    expect(peticion.request.params.get('tipo')).toBe('eq.materia_prima');
    expect(peticion.request.params.get('order')).toBe('nombre.asc');
    expect(peticion.request.params.get('select')).toBe(
      'tipo,articulo_id,nombre,unidad_id,unidad,codigo_barras,activo',
    );
    peticion.flush([filaHarina]);

    expect(await resultado).toEqual([harina]);
  });

  it('lists the units from unidades_medida', async () => {
    const resultado = firstValueFrom(service.listarUnidades());
    http
      .expectOne((r) => r.url === `${API}/unidades_medida`)
      .flush([{ id: 7, nombre: 'Lámina', abreviatura: 'lám' }]);
    expect(await resultado).toEqual([{ id: 7, nombre: 'Lámina', abreviatura: 'lám' }]);
  });

  it('creates a raw material in ingredientes and returns the row from the view', async () => {
    const resultado = firstValueFrom(
      service.crearMateriaPrima({ nombre: 'Harina', unidadId: 1, codigoBarras: null }),
    );
    const alta = http.expectOne((r) => r.method === 'POST' && r.url === `${API}/ingredientes`);
    expect(alta.request.body).toEqual({
      nombre: 'Harina',
      unidad_id: 1,
      categoria_id: null,
      codigo_barras: null,
    });
    alta.flush([{ id: 3, nombre: 'Harina', unidad_id: 1, activo: true }]);
    responderRelectura('materia_prima', 3, filaHarina);

    expect(await resultado).toEqual(harina);
  });

  it('edits only the name and barcode, never the unit', async () => {
    const resultado = firstValueFrom(
      service.editarMateriaPrima(3, { nombre: 'Harina 000', unidadId: 2, codigoBarras: '123' }),
    );
    const cambio = http.expectOne((r) => r.method === 'PATCH' && r.url === `${API}/ingredientes`);
    expect(cambio.request.params.get('id')).toBe('eq.3');
    expect(cambio.request.body).toEqual({ nombre: 'Harina 000', codigo_barras: '123' });
    cambio.flush([{ id: 3 }]);
    responderRelectura('materia_prima', 3, {
      ...filaHarina,
      nombre: 'Harina 000',
      codigo_barras: '123',
    });

    expect(await resultado).toEqual({ ...harina, nombre: 'Harina 000', codigoBarras: '123' });
  });

  it('deactivates a raw material in ingredientes without deleting it', async () => {
    const materia = firstValueFrom(service.cambiarEstado(harina, false));
    const patchMateria = http.expectOne(
      (r) => r.method === 'PATCH' && r.url === `${API}/ingredientes`,
    );
    expect(patchMateria.request.params.get('id')).toBe('eq.3');
    expect(patchMateria.request.body).toEqual({ activo: false });
    patchMateria.flush([{ id: 3, activo: false }]);
    responderRelectura('materia_prima', 3, { ...filaHarina, activo: false });
    expect((await materia).activo).toBe(false);
  });

  it('translates a duplicated name (409) into a clear message', async () => {
    const resultado = firstValueFrom(
      service.crearMateriaPrima({ nombre: 'Harina', unidadId: 1, codigoBarras: null }),
    );
    http
      .expectOne((r) => r.method === 'POST')
      .flush({ code: '23505' }, { status: 409, statusText: 'Conflict' });

    await expect(resultado).rejects.toThrow('Ya existe un ingrediente con ese nombre.');
  });

  it('tells apart a duplicated barcode (409 on codigo_barras)', async () => {
    const resultado = firstValueFrom(
      service.crearMateriaPrima({ nombre: 'Harina', unidadId: 1, codigoBarras: '123' }),
    );
    http
      .expectOne((r) => r.method === 'POST')
      .flush(
        {
          code: '23505',
          message:
            'duplicate key value violates unique constraint "ingredientes_codigo_barras_key"',
          details: 'Key (codigo_barras)=(123) already exists.',
        },
        { status: 409, statusText: 'Conflict' },
      );

    await expect(resultado).rejects.toThrow('Ya existe otro artículo con ese código de barras.');
  });

  it('shows the database message for a 400, such as the fixed unit trigger', async () => {
    const mensaje =
      'La unidad de "Harina" no se puede cambiar: queda fija desde que se crea la materia prima';
    const resultado = firstValueFrom(
      service.editarMateriaPrima(3, { nombre: 'Harina', unidadId: 1, codigoBarras: null }),
    );
    http
      .expectOne((r) => r.method === 'PATCH')
      .flush({ code: '22023', message: mensaje }, { status: 400, statusText: 'Bad Request' });

    await expect(resultado).rejects.toThrow(mensaje);
  });

  it('explains missing permissions when changing the state', async () => {
    const resultado = firstValueFrom(service.cambiarEstado(harina, false));
    http
      .expectOne((r) => r.method === 'PATCH')
      .flush({ code: '42501' }, { status: 403, statusText: 'Forbidden' });

    await expect(resultado).rejects.toThrow(
      'Tu usuario no tiene permiso para cambiar el estado de Harina.',
    );
  });
});
