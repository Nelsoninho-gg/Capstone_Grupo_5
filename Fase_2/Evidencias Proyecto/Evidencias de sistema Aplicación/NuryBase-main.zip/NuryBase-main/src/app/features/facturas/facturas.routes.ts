import { Routes } from '@angular/router';

export const FACTURAS_ROUTES: Routes = [
  {
    path: 'ingresos',
    loadComponent: () =>
      import('./pages/ingresos-factura/ingresos-factura').then((m) => m.IngresosFactura),
  },
  // La carga ahora es un modal dentro de «Facturas ingresadas».
  { path: 'cargar', redirectTo: 'ingresos' },
  { path: '', pathMatch: 'full', redirectTo: 'ingresos' },
];
