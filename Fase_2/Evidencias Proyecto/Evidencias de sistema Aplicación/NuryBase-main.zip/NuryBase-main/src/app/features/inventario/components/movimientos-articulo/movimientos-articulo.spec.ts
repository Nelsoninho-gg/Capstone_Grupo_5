import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Subject, of, throwError } from 'rxjs';
import { ArticuloMovimientos, MovimientoArticulo } from '../../models/movimientos.model';
import { MovimientosService } from '../../services/movimientos.service';
import { MovimientosArticulo } from './movimientos-articulo';

describe('MovimientosArticulo', () => {
  let fixture: ComponentFixture<MovimientosArticulo>;
  const servicio = { listar: vi.fn() };

  const venta: MovimientoArticulo = {
    id: 1,
    tipo: 'venta',
    ventaId: 67,
    referenciaTipo: 'venta',
    referenciaId: 67,
    cantidad: -2,
    unidad: 'un',
    stockResultante: 3,
    sucursalId: 1,
    sucursal: 'Providencia',
    fecha: new Date('2026-10-22T16:53:52Z'),
    nota: null,
  };
  const compra: MovimientoArticulo = {
    ...venta,
    id: 2,
    tipo: 'compra',
    ventaId: null,
    referenciaTipo: 'factura_compra',
    referenciaId: 12,
    cantidad: 24,
    stockResultante: 5,
  };
  const coca: ArticuloMovimientos = {
    tipo: 'producto',
    id: 21,
    nombre: 'Coca-Cola',
    unidad: 'un',
    sucursalId: 1,
    sucursal: 'Providencia',
  };

  async function render(articulo = coca): Promise<void> {
    await TestBed.configureTestingModule({
      imports: [MovimientosArticulo],
      providers: [{ provide: MovimientosService, useValue: servicio }],
    }).compileComponents();
    fixture = TestBed.createComponent(MovimientosArticulo);
    fixture.componentRef.setInput('articulo', articulo);
    fixture.detectChanges();
  }

  const el = () => fixture.nativeElement as HTMLElement;
  const filas = () =>
    Array.from(el().querySelectorAll('tbody tr')).map((fila) =>
      Array.from(fila.querySelectorAll('td')).map((td) =>
        td.textContent?.replace(/\s+/g, ' ').trim(),
      ),
    );

  beforeEach(() => servicio.listar.mockReset());

  it('shows each movement with its origin, signed quantity, unit and resulting stock', async () => {
    servicio.listar.mockReturnValue(of([venta, compra]));
    await render();

    expect(servicio.listar).toHaveBeenCalledWith('producto', 21, 1);
    expect(el().querySelector('h2')?.textContent).toContain('Coca-Cola');
    expect(filas().map((f) => f.slice(1))).toEqual([
      ['Venta', 'Venta #67', '-2 un', '3 un'],
      ['Compra', 'Factura #12', '+24 un', '5 un'],
    ]);
    // Con una sola sucursal no se repite la columna.
    expect(el().querySelector('th')?.parentElement?.textContent).not.toContain('Sucursal');
  });

  it('adds the branch column when opened for all branches', async () => {
    servicio.listar.mockReturnValue(of([venta]));
    await render({ ...coca, sucursalId: null, sucursal: null });

    expect(servicio.listar).toHaveBeenCalledWith('producto', 21, null);
    expect(el().querySelector('.modal-header p')?.textContent).toContain('Todas las sucursales');
    expect(filas()[0]).toContain('Providencia');
  });

  it('filters by movement type', async () => {
    servicio.listar.mockReturnValue(of([venta, compra]));
    await render();

    const chip = Array.from(el().querySelectorAll<HTMLButtonElement>('.filter-chip')).find(
      (b) => b.textContent?.trim() === 'Compras',
    )!;
    chip.click();
    fixture.detectChanges();

    expect(chip.getAttribute('aria-pressed')).toBe('true');
    expect(filas().map((f) => f[1])).toEqual(['Compra']);
  });

  it('shows loading, empty and error with retry', async () => {
    const pendiente = new Subject<MovimientoArticulo[]>();
    servicio.listar.mockReturnValue(pendiente);
    await render();
    expect(el().querySelector('[role="status"]')?.textContent).toContain('Cargando');

    pendiente.error(new Error('500'));
    fixture.detectChanges();
    expect(el().textContent).toContain('No pudimos cargar los movimientos.');

    servicio.listar.mockReturnValue(of([]));
    el().querySelector<HTMLButtonElement>('.error-state button')!.click();
    fixture.detectChanges();
    expect(el().textContent).toContain('Este artículo todavía no tiene movimientos.');
  });

  it('closes with the close button and with Escape', async () => {
    servicio.listar.mockReturnValue(throwError(() => new Error('x')));
    await render();
    const cerrado = vi.fn();
    fixture.componentInstance.cerrar.subscribe(cerrado);

    el().querySelector<HTMLButtonElement>('.close-button')!.click();
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape' }));

    expect(cerrado).toHaveBeenCalledTimes(2);
  });
});
