import { HttpErrorResponse } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { of, throwError } from 'rxjs';
import { IngredientesApiService } from '../../../../core/api/ingredientes-api.service';
import { ProductosApiService } from '../../../../core/api/productos-api.service';
import { RecetasApiService } from '../../../../core/api/recetas-api.service';
import { StockApiService } from '../../../../core/api/stock-api.service';
import { SucursalesApiService } from '../../../../core/api/sucursales-api.service';
import { UnidadesMedidaApiService } from '../../../../core/api/unidades-medida-api.service';
import { User } from '../../../auth/models/auth.model';
import { AuthService } from '../../../auth/services/auth.service';
import { AjusteInventario, nuevaClave } from './ajuste-inventario';

describe('AjusteInventario', () => {
  let fixture: ComponentFixture<AjusteInventario>;
  let usuarioActual: Partial<User> = {};

  const producto = (id: number, nombre: string, codigo_barras: string | null = null) => ({
    id,
    nombre,
    categoria: null,
    precio_compra: null,
    precio_venta: 1000,
    codigo_barras,
    activo: true,
    creado_en: '2026-10-01T00:00:00',
  });

  const stockApi = {
    obtenerStockProducto: vi.fn(() => of(16)),
    obtenerStockIngrediente: vi.fn(() => of(2)),
    ajustar: vi.fn(() =>
      of({ id: 9, producto_id: 1, ingrediente_id: null, sucursal_id: 1, stock_resultante: 36 }),
    ),
  };

  beforeEach(async () => {
    stockApi.obtenerStockProducto.mockClear();
    stockApi.ajustar.mockClear();
    usuarioActual = { rol: 'admin', sucursalId: 1 };
    await TestBed.configureTestingModule({
      imports: [AjusteInventario],
      providers: [
        {
          provide: SucursalesApiService,
          useValue: {
            listarActivas: () =>
              of([
                { id: 1, nombre: 'Nury Providencia' },
                { id: 2, nombre: 'Nury Ñuñoa' },
              ]),
          },
        },
        { provide: AuthService, useValue: { currentUser: () => usuarioActual } },
        {
          provide: ProductosApiService,
          useValue: {
            listar: () =>
              of([
                producto(1, 'CHAPARRITA', '7801234567890'),
                producto(2, 'Café helado'),
                producto(3, 'Sándwich con receta'),
                ...Array.from({ length: 12 }, (_, i) => producto(10 + i, `Bebida ${i + 1}`)),
              ]),
          },
        },
        { provide: RecetasApiService, useValue: { listarIdsProductosConReceta: () => of([3]) } },
        {
          provide: IngredientesApiService,
          useValue: {
            listar: () => of([{ id: 3, nombre: 'Queso', unidad_id: 1, codigo_barras: null }]),
          },
        },
        {
          provide: UnidadesMedidaApiService,
          useValue: { listar: () => of([{ id: 1, nombre: 'Gramo', abreviatura: 'g' }]) },
        },
        { provide: StockApiService, useValue: stockApi },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(AjusteInventario);
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
  });

  function element(): HTMLElement {
    return fixture.nativeElement as HTMLElement;
  }
  function buscador(): HTMLInputElement {
    return element().querySelector<HTMLInputElement>('#buscar-item')!;
  }
  function escribir(texto: string): void {
    const input = buscador();
    input.dispatchEvent(new Event('focus'));
    input.value = texto;
    input.dispatchEvent(new Event('input'));
    fixture.detectChanges();
  }
  function opciones(): string[] {
    return Array.from(element().querySelectorAll('.resultados li[role="option"] span')).map(
      (span) => span.textContent?.trim() ?? '',
    );
  }
  function tecla(key: string): void {
    buscador().dispatchEvent(new KeyboardEvent('keydown', { key, cancelable: true }));
    fixture.detectChanges();
  }

  it('finds products by name ignoring accents and case, without products that have a recipe', () => {
    escribir('cafe');
    expect(opciones()).toEqual(['Café helado']);

    escribir('sandwich');
    expect(opciones()).toEqual([]);
    expect(element().querySelector('.sin-resultados')).not.toBeNull();
  });

  it('limits the list and tells how many matches there are', () => {
    escribir('bebida');
    expect(opciones().length).toBe(8);
    expect(element().querySelector('.mas-resultados')?.textContent).toContain('de 12');
  });

  it('selects with the keyboard and loads the stock of the chosen item', () => {
    const componente = fixture.componentInstance as unknown as {
      formulario: {
        controls: { sucursal_id: { setValue(v: number): void }; item_id: { value: number | null } };
      };
    };
    componente.formulario.controls.sucursal_id.setValue(1);

    escribir('chap');
    tecla('Enter');

    expect(componente.formulario.controls.item_id.value).toBe(1);
    expect(buscador().value).toBe('CHAPARRITA');
    expect(element().querySelector('.resultados')).toBeNull();
    expect(stockApi.obtenerStockProducto).toHaveBeenCalledWith(1, 1);
  });

  it('selects directly by an exact barcode (scanner)', () => {
    const componente = fixture.componentInstance as unknown as {
      formulario: { controls: { item_id: { value: number | null } } };
    };
    escribir('7801234567890');
    tecla('Enter');
    expect(componente.formulario.controls.item_id.value).toBe(1);
  });

  it('clears the selection when the text changes after choosing', () => {
    const componente = fixture.componentInstance as unknown as {
      formulario: { controls: { item_id: { value: number | null } } };
    };
    escribir('chap');
    tecla('Enter');
    escribir('chapa');
    expect(componente.formulario.controls.item_id.value).toBeNull();
  });

  it('opens with the item and branch of the row when the name matches exactly', async () => {
    const conFila = TestBed.createComponent(AjusteInventario);
    conFila.componentRef.setInput('preseleccion', {
      tipo: 'producto',
      sucursalId: 1,
      nombre: 'chaparrita',
    });
    conFila.detectChanges();
    await conFila.whenStable();
    conFila.detectChanges();

    const componente = conFila.componentInstance as unknown as {
      formulario: {
        controls: { sucursal_id: { value: number | null }; item_id: { value: number | null } };
      };
    };
    expect(componente.formulario.controls.sucursal_id.value).toBe(1);
    expect(componente.formulario.controls.item_id.value).toBe(1);
    expect(
      (conFila.nativeElement as HTMLElement).querySelector<HTMLInputElement>('#buscar-item')!.value,
    ).toBe('CHAPARRITA');
    expect(stockApi.obtenerStockProducto).toHaveBeenCalledWith(1, 1);
  });

  it('leaves the name written when it does not exist in the database', async () => {
    const conFila = TestBed.createComponent(AjusteInventario);
    conFila.componentRef.setInput('preseleccion', {
      tipo: 'producto',
      sucursalId: 1,
      nombre: 'Agua mineral 500 ml',
    });
    conFila.detectChanges();
    await conFila.whenStable();
    conFila.detectChanges();

    const componente = conFila.componentInstance as unknown as {
      formulario: { controls: { item_id: { value: number | null } } };
    };
    expect(componente.formulario.controls.item_id.value).toBeNull();
    expect(
      (conFila.nativeElement as HTMLElement).querySelector<HTMLInputElement>('#buscar-item')!.value,
    ).toBe('Agua mineral 500 ml');
  });

  it('closes with Escape, the close button or the backdrop', () => {
    const cerrar = vi.fn();
    fixture.componentInstance.cerrar.subscribe(cerrar);

    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape' }));
    element().querySelector<HTMLButtonElement>('.close-button')!.click();
    element().querySelector<HTMLElement>('.modal-backdrop')!.click();

    expect(cerrar).toHaveBeenCalledTimes(3);
  });

  it('only closes the suggestion list with Escape while it is open', () => {
    const cerrar = vi.fn();
    fixture.componentInstance.cerrar.subscribe(cerrar);
    escribir('chap');

    buscador().dispatchEvent(
      new KeyboardEvent('keydown', { key: 'Escape', bubbles: true, cancelable: true }),
    );
    fixture.detectChanges();

    expect(element().querySelector('.resultados')).toBeNull();
    expect(cerrar).not.toHaveBeenCalled();
  });

  /** Completa el formulario con CHAPARRITA en Providencia y la cantidad indicada. */
  function completar(cantidad: number): void {
    const componente = fixture.componentInstance as unknown as {
      formulario: {
        controls: {
          sucursal_id: { setValue(v: number): void };
          cantidad: { setValue(v: number): void };
          motivo: { setValue(v: string): void };
        };
      };
    };
    componente.formulario.controls.sucursal_id.setValue(1);
    escribir('chap');
    tecla('Enter');
    componente.formulario.controls.cantidad.setValue(cantidad);
    componente.formulario.controls.motivo.setValue('Carga inicial');
  }
  function enviar(): void {
    element().querySelector<HTMLFormElement>('form')!.dispatchEvent(new Event('submit'));
    fixture.detectChanges();
  }
  function claves(): string[] {
    return stockApi.ajustar.mock.calls.map(
      (llamada) => (llamada as unknown as [{ clave: string }])[0].clave,
    );
  }
  function botonEnviar(): string {
    return element().querySelector('button[type="submit"]')?.textContent?.trim() ?? '';
  }
  function aviso(): string {
    return element().querySelector('.error-feedback')?.textContent?.trim() ?? '';
  }
  function falla(status: number, code?: string, message?: string): void {
    stockApi.ajustar.mockReturnValueOnce(
      throwError(() => new HttpErrorResponse({ status, error: code ? { code, message } : null })),
    );
  }

  it('applies the adjustment and reports the result to the panel', () => {
    const ajustado = vi.fn();
    fixture.componentInstance.ajustado.subscribe(ajustado);
    completar(20);

    enviar();

    expect(stockApi.ajustar).toHaveBeenCalledWith({
      sucursal_id: 1,
      cantidad: 20,
      motivo: 'Carga inicial',
      producto_id: 1,
      clave: expect.stringMatching(/^[0-9a-f-]{36}$/),
    });
    expect(ajustado).toHaveBeenCalledWith(
      'Ajuste aplicado a CHAPARRITA en Nury Providencia (+20 unid.). Stock actual: 36 unid.',
    );
  });

  it('explains that the user has no permission when the database rejects the adjustment', () => {
    const ajustado = vi.fn();
    fixture.componentInstance.ajustado.subscribe(ajustado);
    completar(-2);
    falla(403);

    enviar();

    expect(aviso()).toBe(
      'Tu usuario no tiene permiso para registrar ajustes de stock. El stock no se modificó.',
    );
    expect(ajustado).not.toHaveBeenCalled();
  });

  describe('retries without applying twice (H3.6 T06)', () => {
    it('keeps the data after a lost connection and retries with the same key', () => {
      const ajustado = vi.fn();
      fixture.componentInstance.ajustado.subscribe(ajustado);
      completar(20);
      falla(0);

      enviar();

      expect(aviso()).toContain('no sabemos si el ajuste alcanzó a aplicarse');
      expect(botonEnviar()).toBe('Reintentar ajuste');
      expect(ajustado).not.toHaveBeenCalled();

      enviar();

      expect(claves()).toHaveLength(2);
      expect(claves()[1]).toBe(claves()[0]);
      expect(ajustado).toHaveBeenCalled();
    });

    it('uses a new key when the data changes before sending again', () => {
      completar(20);
      falla(0);
      enviar();

      completar(15);
      enviar();

      expect(claves()[1]).not.toBe(claves()[0]);
    });

    it('shows the database reason and refreshes the stock when it would become negative', () => {
      completar(-40);
      stockApi.obtenerStockProducto.mockClear();
      falla(400, '23514', 'El ajuste dejaría el stock en negativo (actual: 16.000, ajuste: -40)');

      enviar();

      expect(aviso()).toBe(
        'El ajuste dejaría el stock en negativo (actual: 16.000, ajuste: -40). El stock no se ' +
          'modificó. Revisa la cantidad con el stock actualizado.',
      );
      expect(botonEnviar()).toBe('Aplicar ajuste');
      expect(stockApi.obtenerStockProducto).toHaveBeenCalledWith(1, 1);
    });

    it('asks to sign in again when the session expired', () => {
      completar(20);
      falla(401, 'PGRST303', 'JWT expired');

      enviar();

      expect(aviso()).toContain('Tu sesión expiró');
    });

    it('creates a valid UUID even without randomUUID (http outside localhost)', () => {
      const original = crypto.randomUUID;
      Object.defineProperty(crypto, 'randomUUID', { value: undefined, configurable: true });
      try {
        expect(nuevaClave()).toMatch(
          /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/,
        );
      } finally {
        Object.defineProperty(crypto, 'randomUUID', { value: original, configurable: true });
      }
    });
  });

  describe('authorized branches (H3.4 T08)', () => {
    let sucursalElegida: () => number | null;

    async function abrirComo(usuario: Partial<User>): Promise<HTMLElement> {
      usuarioActual = usuario;
      const otro = TestBed.createComponent(AjusteInventario);
      otro.detectChanges();
      await otro.whenStable();
      otro.detectChanges();
      const componente = otro.componentInstance as unknown as {
        formulario: { controls: { sucursal_id: { value: number | null } } };
      };
      sucursalElegida = () => componente.formulario.controls.sucursal_id.value;
      return otro.nativeElement as HTMLElement;
    }
    function opcionesSucursal(raiz: HTMLElement): string[] {
      return Array.from(raiz.querySelectorAll('select[formcontrolname="sucursal_id"] option')).map(
        (opcion) => opcion.textContent?.trim() ?? '',
      );
    }

    it('lets the administrator choose any active branch', async () => {
      const raiz = await abrirComo({ rol: 'admin', sucursalId: 1 });

      expect(opcionesSucursal(raiz)).toEqual([
        'Selecciona una sucursal',
        'Nury Providencia',
        'Nury Ñuñoa',
      ]);
      expect(sucursalElegida()).toBeNull();
    });

    it('limits a storekeeper to the assigned branch and selects it', async () => {
      const raiz = await abrirComo({ rol: 'bodeguero', sucursalId: 2 });

      expect(opcionesSucursal(raiz)).toEqual(['Selecciona una sucursal', 'Nury Ñuñoa']);
      expect(sucursalElegida()).toBe(2);
      expect(raiz.querySelector('.sin-sucursal')).toBeNull();
    });

    it('offers no branch to a storekeeper without one and explains why', async () => {
      const raiz = await abrirComo({ rol: 'bodeguero', sucursalId: null });

      expect(opcionesSucursal(raiz)).toEqual(['Selecciona una sucursal']);
      expect(sucursalElegida()).toBeNull();
      expect(raiz.querySelector('.sin-sucursal')?.textContent).toContain(
        'Tu usuario no tiene una sucursal asignada.',
      );
    });
  });

  it('only accepts whole quantities for resale products', () => {
    stockApi.ajustar.mockClear();
    const componente = fixture.componentInstance as unknown as {
      formulario: {
        controls: {
          sucursal_id: { setValue(v: number): void };
          cantidad: { setValue(v: number): void };
          motivo: { setValue(v: string): void };
        };
      };
    };
    componente.formulario.controls.sucursal_id.setValue(1);
    escribir('chap');
    tecla('Enter');

    const cantidad = element().querySelector<HTMLInputElement>(
      'input[formcontrolname="cantidad"]',
    )!;
    expect(cantidad.step).toBe('1');
    const punto = new KeyboardEvent('keydown', { key: '.', cancelable: true });
    cantidad.dispatchEvent(punto);
    expect(punto.defaultPrevented).toBe(true);

    componente.formulario.controls.cantidad.setValue(1.5);
    componente.formulario.controls.motivo.setValue('Carga inicial');
    element().querySelector<HTMLFormElement>('form')!.dispatchEvent(new Event('submit'));
    fixture.detectChanges();

    expect(stockApi.ajustar).not.toHaveBeenCalled();
    expect(element().textContent).toContain(
      'Los productos de reventa solo admiten cantidades enteras.',
    );
  });
});
