import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, map } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { TipoArticulo } from '../models/inventario.model';
import { MovimientoArticulo, TipoMovimiento } from '../models/movimientos.model';

/** Fila de la vista v_movimientos_articulos. */
export interface MovimientoApi {
  movimiento_id: number;
  tipo_movimiento: TipoMovimiento;
  venta_id: number | null;
  referencia_tipo: string | null;
  referencia_id: number | null;
  cantidad: number | string;
  unidad: string;
  stock_resultante: number | string;
  sucursal_id: number;
  sucursal: string;
  fecha: string;
  nota: string | null;
}

const MOVIMIENTO_FIELDS =
  'movimiento_id,tipo_movimiento,venta_id,referencia_tipo,referencia_id,cantidad,unidad,' +
  'stock_resultante,sucursal_id,sucursal,fecha,nota';

/** Tope de filas por consulta: el historial muestra lo más reciente primero. */
export const LIMITE_MOVIMIENTOS = 100;

/** Historial de movimientos de un artículo (H3.2 T01) desde v_movimientos_articulos. */
@Injectable({ providedIn: 'root' })
export class MovimientosService {
  private readonly http = inject(HttpClient);
  private readonly url = `${environment.apiUrl}/v_movimientos_articulos`;

  listar(
    tipo: TipoArticulo,
    articuloId: number,
    sucursalId: number | null,
  ): Observable<MovimientoArticulo[]> {
    const params: Record<string, string> = {
      select: MOVIMIENTO_FIELDS,
      tipo_articulo: `eq.${tipo}`,
      articulo_id: `eq.${articuloId}`,
      order: 'fecha.desc,movimiento_id.desc',
      limit: String(LIMITE_MOVIMIENTOS),
    };
    if (sucursalId !== null) params['sucursal_id'] = `eq.${sucursalId}`;
    return this.http
      .get<MovimientoApi[]>(this.url, { params })
      .pipe(map((filas) => filas.map(aMovimiento)));
  }
}

export function aMovimiento(fila: MovimientoApi): MovimientoArticulo {
  return {
    id: fila.movimiento_id,
    tipo: fila.tipo_movimiento,
    ventaId: fila.venta_id,
    referenciaTipo: fila.referencia_tipo,
    referenciaId: fila.referencia_id,
    cantidad: Number(fila.cantidad),
    unidad: fila.unidad,
    stockResultante: Number(fila.stock_resultante),
    sucursalId: fila.sucursal_id,
    sucursal: fila.sucursal,
    fecha: new Date(fila.fecha),
    nota: fila.nota,
  };
}
