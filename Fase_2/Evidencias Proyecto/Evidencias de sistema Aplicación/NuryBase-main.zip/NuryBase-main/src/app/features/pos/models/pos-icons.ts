/**
 * Íconos de línea de las tarjetas del POS (viewBox 32×32, trazo sin relleno).
 * Cada producto recibe el ícono según su categoría de la base de datos.
 */
export const POS_ICON_PATHS = {
  empanada:
    'M4 23A2.6 2.6 0 0 1 4.91 18.41A2.6 2.6 0 0 1 7.51 14.51A2.6 2.6 0 0 1 11.41 11.91A2.6 2.6 0 0 1 16 11A2.6 2.6 0 0 1 20.59 11.91A2.6 2.6 0 0 1 24.49 14.51A2.6 2.6 0 0 1 27.09 18.41A2.6 2.6 0 0 1 28 23ZM8 23a8 8 0 0 1 16 0M3 27h26',
  // Masa alargada con la salchicha asomando por ambos extremos.
  chaparrita:
    'M7 17C8.5 9 23.5 9 25 17c-1.5 7-16.5 7-18 0zM7.6 15.2H5a1.8 1.8 0 0 0 0 3.6h2.6M24.4 15.2H27a1.8 1.8 0 0 1 0 3.6h-2.6M11.5 13.5l2 4.5M15.5 12.5l2 5M19.5 13l2 4.5M4 27h24',
  sandwich: 'm4 21 12-14 12 14H4zm0 4h24M9 21l7-8 7 8M6 28h20',
  hotdog:
    'M4 14.5h24a2.5 2.5 0 0 1 0 5H4a2.5 2.5 0 0 1 0-5zM5 18v3a4 4 0 0 0 4 4h14a4 4 0 0 0 4-4v-3M8 17l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1',
  pizza:
    'M5 8c7-3 15-3 22 0L16 29zM6.7 11.2c6-2.4 12.6-2.4 18.6 0M11.5 16a1.5 1.5 0 1 0 3 0a1.5 1.5 0 1 0-3 0M17.5 14.5a1.5 1.5 0 1 0 3 0a1.5 1.5 0 1 0-3 0M14.8 21.5a1.3 1.3 0 1 0 2.6 0a1.3 1.3 0 1 0-2.6 0',
  fries: 'M7 14h18l-2.5 15h-13zM10 14 8.5 6M13 14l-.5-10M16.5 14l.5-9.5M20 14l1.5-8.5M23 14l1.5-6',
  chips:
    'M8 6l2-2 2 2 2-2 2 2 2-2 2 2 2-2 2 2v20l-2 2-2-2-2 2-2-2-2 2-2-2-2 2-2-2zM12 16c2-3 6-3 8 0-2 3-6 3-8 0z',
  cake: 'M5 15h22v11H5zM5 15l17-7 5 7M5 20.5h22M21 5.5a1.5 1.5 0 1 0 3 0a1.5 1.5 0 1 0-3 0',
  lunch:
    'M9 16a7 7 0 1 0 14 0a7 7 0 1 0-14 0M12 16a4 4 0 1 0 8 0a4 4 0 1 0-8 0M4 5v6a1.5 1.5 0 0 0 3 0V5M5.5 5v6M5.5 12.5V27M27 27V5c-2 2-3 5-3 9h3',
  riceBowl:
    'M4 16h24a12 10 0 0 1-24 0zM12 28h8M8 16c1-2.5 3-2.5 4 0 1-2.5 3-2.5 4 0 1-2.5 3-2.5 4 0 1-2.5 3-2.5 4 0M18 12 27 3M21 13l8-6',
  bowl: 'M4 16h24a12 10 0 0 1-24 0zM12 28h8M9 16c0-4 3-7 7-7 0 4-3 7-7 7M16 16c1-3.5 4-5.5 8-5-1 3-4 5-8 5M10.5 15.5 15 10',
  wrap: 'M5.8 22.2 19.8 8.2a4.24 4.24 0 0 1 6 6L11.8 28.2a4.24 4.24 0 0 1-6-6zM19.8 8.2a4.24 4.24 0 0 0 6 6M9 20.5c2 .3 3.2 1.5 3.5 3.5M13 16.5c2 .3 3.2 1.5 3.5 3.5',
  // Handroll chileno: rollo cilíndrico de nori; el extremo muestra arroz y relleno.
  handroll:
    'M10 9.5h13a4 7.5 0 0 1 0 15H10M5 17a5 7.5 0 1 0 10 0a5 7.5 0 1 0-10 0M6.9 17a3.1 5.4 0 1 0 6.2 0a3.1 5.4 0 1 0-6.2 0M9 14.2h2v5.6H9zM4 28h24',
  fruit:
    'M16 11c-3-2-9-1.5-9 5.5 0 7 4 12.5 7 11.5 1-.4 3-.4 4 0 3 1 7-4.5 7-11.5 0-7-6-7.5-9-5.5zM16 11c0-3 1-5 3-6.5M17 8c1.5-2.5 5-3 6.5-2-1 2.5-4.5 3-6.5 2z',
  yogurt: 'M7 6h18v3H7zM8.5 9h15l-2 19h-11zM9.1 15h13.8M9.8 21h12.4',
  coffee: 'M7 12h16v8a7 7 0 0 1-7 7h-2a7 7 0 0 1-7-7zM23 14h2a4 4 0 0 1 0 8h-3M5 29h21M11 8V4m5 4V2m5 6V4',
  mug: 'M7 11h15v13a4 4 0 0 1-4 4h-7a4 4 0 0 1-4-4zM22 14h2.5a3.5 3.5 0 0 1 0 7H22M11 4c-1.2 1.2 1.2 2.3 0 3.5M14.5 4c-1.2 1.2 1.2 2.3 0 3.5M18 4c-1.2 1.2 1.2 2.3 0 3.5',
  tea: 'M6 14h16v5a7 7 0 0 1-7 7h-2a7 7 0 0 1-7-7zM22 16h1.5a3 3 0 0 1 0 6H21M4 29h22M11 14l5-7.5M15 3.5h4.5V8H15z',
  bottle:
    'M13 3h6v4c0 2 4 3 4 7v13a2 2 0 0 1-2 2H11a2 2 0 0 1-2-2V14c0-4 4-5 4-7zM13 5.5h6M9 17h14M9 23h14',
  energy: 'M12 8h8v2.5l2 3V27a2 2 0 0 1-2 2h-8a2 2 0 0 1-2-2V13.5l2-3zM13.5 3.5h5V8h-5zM17 15l-3 5h4l-3 5',
  can: 'M9 7.5c0-1.7 3.1-2.7 7-2.7s7 1 7 2.7v17c0 1.7-3.1 2.7-7 2.7s-7-1-7-2.7zM9 7.5c0 1.7 3.1 2.7 7 2.7s7-1 7-2.7M9 12h14M9 21h14',
  juice: 'M8 10h16l-2 19H10L8 10zm9 0 3-7h5M9 17h14M7 10h18',
  milk: 'M9 12h14v16H9zM9 12l3-5h8l3 5M12 7V4.5h8V7M16 16.5c-1.5 2-2.5 3.2-2.5 4.5a2.5 2.5 0 0 0 5 0c0-1.3-1-2.5-2.5-4.5z',
  chocolateBar: 'M9 4h14v24H9zM9 12h14M9 20h14M16 4v24',
  bar: 'M8 11h16v10H8zM8 11 4.5 12.5v7L8 21M24 11l3.5 1.5v7L24 21M12 16h8',
  candy: 'M11 16a5 5 0 1 0 10 0a5 5 0 1 0-10 0M11 16l-6-4v8zM21 16l6-4v8zM14 12.5l4 7',
  gum: 'M5 9h22v14H5zM9.5 13h3a3 3 0 0 1 0 6h-3a3 3 0 0 1 0-6zM19.5 13h3a3 3 0 0 1 0 6h-3a3 3 0 0 1 0-6z',
  cookie:
    'M5 16a11 11 0 1 0 22 0a11 11 0 1 0-22 0M11 11.5a1 1 0 1 0 2 0a1 1 0 1 0-2 0M18 10a1 1 0 1 0 2 0a1 1 0 1 0-2 0M14 17a1 1 0 1 0 2 0a1 1 0 1 0-2 0M20 18.5a1 1 0 1 0 2 0a1 1 0 1 0-2 0M11 22a1 1 0 1 0 2 0a1 1 0 1 0-2 0',
  iceCream:
    'M9 14a7 7 0 0 1 14 0c-1 1.5-2.5 1.5-3.5 0-1 1.5-2.5 1.5-3.5 0-1 1.5-2.5 1.5-3.5 0-1 1.5-2.5 1.5-3.5 0zM10.5 15.5 16 29l5.5-13.5M11.9 19l6.5 3.8M20.1 19l-6.5 3.8',
  lighter:
    'M10 12h12v15a2 2 0 0 1-2 2h-8a2 2 0 0 1-2-2zM11.5 12V8.5h7V12M19.5 9.5a1.5 1.5 0 1 0 3 0a1.5 1.5 0 1 0-3 0M15 3c-1.8 1.6-1.8 4 0 4s1.8-2.4 0-4z',
  pencil: 'M6 26l1.5-5.5L21 7a2.83 2.83 0 0 1 4 4L11.5 24.5zM19 9l4 4M7.5 20.5l4 4',
  eraser: 'M4 19 14 9h14L18 19zM4 19v5h14v-5M18 24l10-10V9M11 19l10-10M11 19v5',
  tissues: 'M5 14h22v13H5zM11 14c.5-3 2-5.5 5-7 1 1.5 3 2.5 5 2.5-1 1.5-1.5 3-1.5 4.5M5 19h22',
  bag: 'M7 11h18l-1.5 17h-15zM12 11V8a4 4 0 0 1 8 0v3',
} as const;

export type PosIconKey = keyof typeof POS_ICON_PATHS;

// El orden importa: las reglas más específicas van primero
// (p. ej. "GOLOSINAS - PAPAS" son papas de bolsa, "ALIMENTOS - PAPAS" son fritas).
const ICON_RULES: ReadonlyArray<readonly [RegExp, PosIconKey]> = [
  [/CHAPARRITA/, 'chaparrita'],
  [/EMPANADA/, 'empanada'],
  [/SANDWICH|SANDUCHE|HAMBURGUESA/, 'sandwich'],
  [/COMPLETO|HOT ?DOG/, 'hotdog'],
  [/PIZZA/, 'pizza'],
  [/GOLOSINA.*PAPAS|SNACK/, 'chips'],
  [/PAPAS/, 'fries'],
  [/PASTEL|TORTA|KUCHEN|QUEQUE/, 'cake'],
  [/GHOAN|GOHAN|SUSHI/, 'riceBowl'],
  [/HAND ?ROLL/, 'handroll'],
  [/ENSALADA|VEGAN|VEGETARIAN|BOWL/, 'bowl'],
  [/ALMUERZO|COLACION|MENU/, 'lunch'],
  [/FAJITA|WRAP|BURRITO/, 'wrap'],
  [/FRUTA/, 'fruit'],
  [/YOG(H)?URT/, 'yogurt'],
  [/BEBESTIBLE.*CHOCOLATE|CHOCOLATE CALIENTE/, 'mug'],
  [/CAFE|CAPUCHINO|LATTE/, 'coffee'],
  [/\bTE\b|INFUSION|HIERBA/, 'tea'],
  [/ISOTONIC|ENERG/, 'energy'],
  [/JUGO|NECTAR/, 'juice'],
  [/LATA/, 'can'],
  [/BOTELLA|AGUA/, 'bottle'],
  [/LECHE/, 'milk'],
  [/CHICLE/, 'gum'],
  [/GALLETA/, 'cookie'],
  [/CHOCOLATE/, 'chocolateBar'],
  [/BARRA|TURRON/, 'bar'],
  [/DULCE|CARAMELO|GOMITA/, 'candy'],
  [/HELADO/, 'iceCream'],
  [/ENCENDEDOR/, 'lighter'],
  [/LAPIZ|PLUMON|LAPICERA/, 'pencil'],
  [/\bGOMA\b/, 'eraser'],
  [/PANUELO/, 'tissues'],
];

// Si ni la categoría ni el nombre calzan con una regla, se usa el ícono de la familia.
const FAMILY_ICONS: ReadonlyArray<readonly [RegExp, PosIconKey]> = [
  [/^ALIMENTO/, 'lunch'],
  [/^BEBESTIBLE/, 'juice'],
  [/^GOLOSINA/, 'candy'],
  [/^HELADO/, 'iceCream'],
];

function normalize(text: string): string {
  return text
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toUpperCase()
    .trim();
}

function matchRule(text: string, rules: ReadonlyArray<readonly [RegExp, PosIconKey]>): PosIconKey | null {
  return rules.find(([pattern]) => pattern.test(text))?.[1] ?? null;
}

/** Elige el ícono por categoría; si no alcanza, por nombre del producto y luego por familia. */
export function resolvePosIcon(categoria: string, nombre = ''): PosIconKey {
  const category = normalize(categoria);
  return (
    matchRule(category, ICON_RULES) ??
    matchRule(normalize(nombre), ICON_RULES) ??
    matchRule(category, FAMILY_ICONS) ??
    'bag'
  );
}

export function posIconPath(icon: string): string {
  return icon in POS_ICON_PATHS ? POS_ICON_PATHS[icon as PosIconKey] : POS_ICON_PATHS.bag;
}
