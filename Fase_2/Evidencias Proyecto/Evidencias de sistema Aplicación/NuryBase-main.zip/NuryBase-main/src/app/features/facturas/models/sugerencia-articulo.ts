/**
 * Sugerencia de artículo del catálogo para cada línea de una factura XML, a partir de
 * la descripción del proveedor. Solo propone: el usuario la ve marcada como sugerida
 * y puede cambiarla. Si no hay una coincidencia clara, la línea queda pendiente.
 *
 * Cada palabra pesa según lo rara que es en el catálogo: «takis» o «laguito» identifican
 * un artículo; «galleta», «sandwich» o «bot» aparecen en decenas y casi no cuentan.
 */

import { ArticuloCatalogo, normalizar } from './asociacion-lineas';

/** Palabras que no distinguen artículos. Las unidades sueltas quedan fuera al unirse al número. */
const VACIAS = new Set(['de', 'del', 'la', 'las', 'el', 'los', 'y', 'en', 'al', 'x', 'un', 'uni', 'unid']);
/** Mínimo de letras para aceptar abreviaturas: «choc» → «chocolate», «aven» → «avena». */
const MINIMO_PREFIJO = 4;
/** Parte del nombre del artículo (ponderada) que debe aparecer en la descripción. */
const COBERTURA_CLARA = 0.75;
/** Con una palabra única en el catálogo basta la mitad del nombre: «Laguito» → «ALFAJOR LAGUITO». */
const COBERTURA_CON_PALABRA_UNICA = 0.5;
const LARGO_PALABRA_UNICA = 5;
/** Ventaja mínima sobre el segundo candidato para no sugerir al azar entre parecidos. */
const VENTAJA_MINIMA = 0.15;

interface Palabras {
  /** Palabras con letras, sin las vacías. */
  texto: string[];
  /** Tamaños como «56g» o «600ml», para desempatar presentaciones del mismo artículo. */
  tamanos: string[];
}

interface ArticuloIndexado {
  articulo: ArticuloCatalogo;
  palabras: Palabras;
}

export interface IndiceCatalogo {
  articulos: ArticuloIndexado[];
  /** En cuántos artículos aparece cada palabra. */
  frecuencia: Map<string, number>;
}

/** Se arma una vez por catálogo y sirve para todas las líneas de la factura. */
export function indexarCatalogo(articulos: ArticuloCatalogo[]): IndiceCatalogo {
  const indexados = articulos.map((articulo) => ({ articulo, palabras: separar(articulo.nombre) }));
  const frecuencia = new Map<string, number>();
  for (const { palabras } of indexados) {
    for (const palabra of new Set(palabras.texto)) frecuencia.set(palabra, (frecuencia.get(palabra) ?? 0) + 1);
  }
  return { articulos: indexados, frecuencia };
}

/** Artículo que mejor corresponde a la descripción, o null si no hay uno claro. */
export function sugerirArticulo(descripcion: string, indice: IndiceCatalogo): ArticuloCatalogo | null {
  const linea = separar(descripcion);
  // La primera palabra conocida dice qué es («Brownie sin azúcar» es un brownie, no azúcar).
  const vocabulario = [...indice.frecuencia.keys()];
  const principal = linea.texto.find((palabra) => vocabulario.some((otra) => coinciden(otra, palabra)));
  if (!principal) return null;
  const total = indice.articulos.length;
  const peso = (palabra: string) => Math.log(1 + total / (indice.frecuencia.get(palabra) ?? 1));

  const candidatos = indice.articulos
    .map(({ articulo, palabras }) => {
      const propias = [...new Set(palabras.texto)];
      if (!propias.some((palabra) => coinciden(palabra, principal))) return null;
      const encontradas = propias.filter((palabra) => linea.texto.some((otra) => coinciden(palabra, otra)));
      const cobertura =
        encontradas.reduce((suma, palabra) => suma + peso(palabra), 0) /
        propias.reduce((suma, palabra) => suma + peso(palabra), 0);
      const unica = encontradas.some(
        (palabra) => indice.frecuencia.get(palabra) === 1 && palabra.length >= LARGO_PALABRA_UNICA,
      );
      const tamanos = palabras.tamanos.filter((tamano) => linea.tamanos.includes(tamano)).length;
      return { articulo, cobertura, unica, tamanos };
    })
    .filter((candidato) => candidato !== null && candidato.cobertura > 0)
    .sort((a, b) => b!.cobertura - a!.cobertura || b!.tamanos - a!.tamanos);

  const [mejor, segundo] = candidatos;
  if (!mejor) return null;
  const suficiente =
    mejor.cobertura >= COBERTURA_CLARA || (mejor.cobertura >= COBERTURA_CON_PALABRA_UNICA && mejor.unica);
  if (!suficiente) return null;
  if (segundo) {
    const empate = mejor.cobertura - segundo.cobertura < VENTAJA_MINIMA;
    // Solo el tamaño puede romper un empate: «600ml» frente a «850ml» del mismo artículo.
    if (empate && !(mejor.cobertura === segundo.cobertura && mejor.tamanos > segundo.tamanos)) return null;
  }
  return mejor.articulo;
}

function coinciden(articulo: string, linea: string): boolean {
  if (articulo === linea) return true;
  if (Math.min(articulo.length, linea.length) < MINIMO_PREFIJO) return false;
  return articulo.startsWith(linea) || linea.startsWith(articulo);
}

const UNIDADES = 'g|gr|grs|grm|kg|ml|cc|l|lt|lts';

function separar(texto: string): Palabras {
  const unido = normalizar(texto)
    // «600 ml» y «600ml» son lo mismo; «41,5 g» también vale como tamaño.
    .replace(/(\d)[.,](\d)/g, '$1_$2')
    .replace(new RegExp(`(\\d)\\s+(${UNIDADES})\\b`, 'g'), '$1$2')
    // Códigos pegados al nombre: «502660Brownie» → «502660 brownie», «nougat35g» → «nougat 35g».
    .replace(/(\d)([a-z]+)/g, (todo, digito, letras) =>
      new RegExp(`^(${UNIDADES})$`).test(letras) ? todo : `${digito} ${letras}`,
    )
    .replace(/([a-z])(\d)/g, '$1 $2');
  const palabras = unido.split(/[^a-z0-9_]+/).filter(Boolean);
  return {
    texto: palabras.filter((palabra) => palabra.length >= 2 && !/\d/.test(palabra) && !VACIAS.has(palabra)),
    tamanos: palabras.map(tamano).filter((valor): valor is string => valor !== null),
  };
}

/** «56gr» → «56g», «1lt» → «1l», «200cc» → «200ml»; null si no es un tamaño. */
function tamano(palabra: string): string | null {
  const partes = new RegExp(`^(\\d+(?:_\\d+)?)(${UNIDADES})$`).exec(palabra);
  if (!partes) return null;
  const unidad = { gr: 'g', grs: 'g', grm: 'g', cc: 'ml', lt: 'l', lts: 'l' }[partes[2]] ?? partes[2];
  return partes[1] + unidad;
}
