import {
  Component,
  HostListener,
  OnInit,
  computed,
  inject,
  input,
  output,
  signal,
} from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { finalize, forkJoin } from 'rxjs';
import {
  IngredienteApi,
  IngredientesApiService,
} from '../../../../core/api/ingredientes-api.service';
import { ProductoApi, ProductosApiService } from '../../../../core/api/productos-api.service';
import { RecetasApiService } from '../../../../core/api/recetas-api.service';
import { AjusteStock, StockApiService } from '../../../../core/api/stock-api.service';
import { SucursalApi, SucursalesApiService } from '../../../../core/api/sucursales-api.service';
import {
  UnidadMedidaApi,
  UnidadesMedidaApiService,
} from '../../../../core/api/unidades-medida-api.service';
import { AuthService } from '../../../auth/services/auth.service';
import { FalloAjuste, interpretarFalloAjuste } from '../../models/fallo-ajuste';
import { sucursalesAutorizadas } from '../../services/inventario.service';

export type TipoItem = 'ingrediente' | 'producto';

/** Datos con los que se abre el modal (p. ej. desde una fila del panel de Inventario). */
export interface PreseleccionAjuste {
  tipo: TipoItem;
  sucursalId: number | null;
  /** Nombre del ítem: si coincide exacto con uno de la base, queda elegido. */
  nombre: string | null;
}

/** Opción del buscador de ítems: producto de reventa o ingrediente. */
interface ItemBuscable {
  id: number;
  nombre: string;
  codigo: string | null;
}

/** Cantidad máxima de coincidencias que se muestran bajo el buscador. */
const MAX_RESULTADOS = 8;

/** Igual que en el POS: sin tildes ni mayúsculas, para buscar "cafe" y encontrar "Café". */
function normalizar(valor: string): string {
  return valor
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim()
    .toLowerCase();
}

/**
 * Ajuste real de stock (entradas y salidas) contra la base, vía fn_ajustar_stock.
 * Se abre como modal desde el botón "Ajustar stock" del panel de Inventario
 * (o desde el botón de cada fila, con el ítem y la sucursal prellenados).
 * Si el envío falla, explica el motivo y conserva los datos: reintentar repite la misma
 * operación y la base no la aplica dos veces (H3.6 T06).
 */
@Component({
  selector: 'app-ajuste-inventario',
  imports: [ReactiveFormsModule],
  templateUrl: './ajuste-inventario.html',
  styleUrl: './ajuste-inventario.css',
})
export class AjusteInventario implements OnInit {
  private readonly sucursalesApi = inject(SucursalesApiService);
  private readonly ingredientesApi = inject(IngredientesApiService);
  private readonly productosApi = inject(ProductosApiService);
  private readonly recetasApi = inject(RecetasApiService);
  private readonly unidadesApi = inject(UnidadesMedidaApiService);
  private readonly stockApi = inject(StockApiService);
  private readonly authService = inject(AuthService);
  private readonly formBuilder = inject(FormBuilder);

  readonly preseleccion = input<PreseleccionAjuste | null>(null);
  readonly cerrar = output<void>();
  /** Se emite con el mensaje de resultado cuando el ajuste se aplicó en la base. */
  readonly ajustado = output<string>();

  protected readonly sucursales = signal<SucursalApi[]>([]);
  protected readonly ingredientes = signal<IngredienteApi[]>([]);
  protected readonly productosReventa = signal<ProductoApi[]>([]);
  protected readonly unidades = signal<UnidadMedidaApi[]>([]);

  protected readonly cargando = signal(true);
  protected readonly error = signal<string | null>(null);

  protected readonly tipo = signal<TipoItem>('producto');
  protected readonly stockActual = signal<number | null>(null);
  protected readonly cargandoStock = signal(false);
  protected readonly guardando = signal(false);
  protected readonly fallo = signal<FalloAjuste | null>(null);
  /**
   * Clave del último ajuste enviado y sus datos. Si el envío falla y se reintenta con los
   * mismos datos, se repite la clave y la base no lo aplica dos veces (H3.6 T06).
   */
  private ajustePendiente: { clave: string; datos: string } | null = null;

  protected readonly formulario = this.formBuilder.nonNullable.group({
    sucursal_id: this.formBuilder.control<number | null>(null, Validators.required),
    item_id: this.formBuilder.control<number | null>(null, Validators.required),
    cantidad: this.formBuilder.control<number | null>(null, Validators.required),
    motivo: ['', [Validators.required, Validators.maxLength(200)]],
  });

  private readonly itemIdSeleccionado = toSignal(this.formulario.controls.item_id.valueChanges, {
    initialValue: null,
  });
  private readonly cantidadIngresada = toSignal(this.formulario.controls.cantidad.valueChanges, {
    initialValue: null,
  });

  /** Texto del buscador de producto/ingrediente. */
  protected readonly busqueda = signal('');
  protected readonly listaAbierta = signal(false);
  /** Opción resaltada con las flechas del teclado. */
  protected readonly indiceActivo = signal(0);

  private readonly itemsDisponibles = computed<ItemBuscable[]>(() => {
    const items =
      this.tipo() === 'producto'
        ? this.productosReventa().map((p) => ({
            id: p.id,
            nombre: p.nombre,
            codigo: p.codigo_barras,
          }))
        : this.ingredientes().map((i) => ({ id: i.id, nombre: i.nombre, codigo: i.codigo_barras }));
    return items.sort((a, b) => a.nombre.localeCompare(b.nombre, 'es'));
  });

  /** Coincidencias por nombre (sin tildes) o por código de barras. */
  protected readonly resultados = computed(() => {
    const consulta = normalizar(this.busqueda());
    const items = this.itemsDisponibles();
    const filtrados = consulta
      ? items.filter(
          (item) =>
            normalizar(item.nombre).includes(consulta) ||
            (item.codigo ?? '').toLowerCase().includes(consulta),
        )
      : items;
    return filtrados.slice(0, MAX_RESULTADOS);
  });

  /** Total de coincidencias, para avisar cuando hay más de las que se muestran. */
  protected readonly totalCoincidencias = computed(() => {
    const consulta = normalizar(this.busqueda());
    if (!consulta) return this.itemsDisponibles().length;
    return this.itemsDisponibles().filter(
      (item) =>
        normalizar(item.nombre).includes(consulta) ||
        (item.codigo ?? '').toLowerCase().includes(consulta),
    ).length;
  });

  protected readonly unidadItem = computed(() => {
    if (this.tipo() === 'producto') return 'unid.';
    const ingrediente = this.ingredientes().find((i) => i.id === Number(this.itemIdSeleccionado()));
    const unidad = this.unidades().find((u) => u.id === ingrediente?.unidad_id);
    return unidad?.abreviatura ?? '';
  });

  /** Stock que quedaría si se aplicara el ajuste ingresado (solo para mostrar). */
  protected readonly stockResultante = computed(() => {
    const actual = this.stockActual();
    const delta = Number(this.cantidadIngresada());
    if (actual === null || !this.cantidadIngresada() || Number.isNaN(delta)) return null;
    return actual + delta;
  });

  ngOnInit(): void {
    this.cargarDatos();
  }

  protected cargarDatos(): void {
    this.cargando.set(true);
    this.error.set(null);
    forkJoin({
      sucursales: this.sucursalesApi.listarActivas(),
      ingredientes: this.ingredientesApi.listar(true),
      productos: this.productosApi.listar(true),
      conReceta: this.recetasApi.listarIdsProductosConReceta(),
      unidades: this.unidadesApi.listar(),
    }).subscribe({
      next: ({ sucursales, ingredientes, productos, conReceta, unidades }) => {
        const idsConReceta = new Set(conReceta);
        this.sucursales.set(this.filtrarAutorizadas(sucursales));
        if (this.sucursales().length === 1) {
          this.formulario.controls.sucursal_id.setValue(this.sucursales()[0].id);
        }
        this.ingredientes.set(ingredientes);
        this.productosReventa.set(productos.filter((p) => !idsConReceta.has(p.id)));
        this.unidades.set(unidades);
        this.cargando.set(false);
        this.aplicarPreseleccion();
      },
      error: () => {
        this.error.set('No pudimos cargar los datos. Revisa la conexión e inténtalo nuevamente.');
        this.cargando.set(false);
      },
    });
  }

  /** Mismas sucursales que el panel (H3.4 T08): el admin, todas; el resto, solo la suya. */
  private filtrarAutorizadas(sucursales: SucursalApi[]): SucursalApi[] {
    const alcance = sucursalesAutorizadas(this.authService.currentUser());
    if (alcance === null) return sucursales;
    return sucursales.filter((sucursal) => sucursal.id === alcance);
  }

  private aplicarPreseleccion(): void {
    const pre = this.preseleccion();
    if (!pre) return;
    this.tipo.set(pre.tipo);
    if (pre.sucursalId !== null && this.sucursales().some((s) => s.id === pre.sucursalId)) {
      this.formulario.controls.sucursal_id.setValue(pre.sucursalId);
    }
    if (pre.nombre) {
      const nombre = normalizar(pre.nombre);
      const exacto = this.itemsDisponibles().find((item) => normalizar(item.nombre) === nombre);
      if (exacto) {
        this.seleccionarItem(exacto);
      } else {
        // Sin coincidencia exacta: queda escrito para que se elija entre las sugerencias.
        this.busqueda.set(pre.nombre);
      }
    }
  }

  @HostListener('document:keydown.escape')
  protected cancelar(): void {
    if (this.guardando()) return;
    this.cerrar.emit();
  }

  protected cambiarTipo(tipo: TipoItem): void {
    if (this.tipo() === tipo) return;
    this.tipo.set(tipo);
    this.formulario.controls.item_id.reset(null);
    this.busqueda.set('');
    this.listaAbierta.set(false);
    this.stockActual.set(null);
    this.fallo.set(null);
  }

  protected alEscribirBusqueda(valor: string): void {
    this.busqueda.set(valor);
    this.indiceActivo.set(0);
    this.listaAbierta.set(true);
    // Si se cambia el texto después de elegir, la selección anterior deja de valer.
    if (this.formulario.controls.item_id.value !== null) {
      this.formulario.controls.item_id.setValue(null);
      this.stockActual.set(null);
    }
  }

  protected abrirLista(): void {
    this.indiceActivo.set(0);
    this.listaAbierta.set(true);
  }

  protected cerrarLista(): void {
    this.listaAbierta.set(false);
    this.formulario.controls.item_id.markAsTouched();
  }

  protected seleccionarItem(item: ItemBuscable): void {
    this.formulario.controls.item_id.setValue(item.id);
    this.busqueda.set(item.nombre);
    this.listaAbierta.set(false);
    this.alCambiarSeleccion();
  }

  protected alTeclearBusqueda(evento: KeyboardEvent): void {
    const resultados = this.resultados();
    switch (evento.key) {
      case 'ArrowDown':
        evento.preventDefault();
        this.listaAbierta.set(true);
        this.indiceActivo.update((i) => Math.min(i + 1, Math.max(resultados.length - 1, 0)));
        break;
      case 'ArrowUp':
        evento.preventDefault();
        this.indiceActivo.update((i) => Math.max(i - 1, 0));
        break;
      case 'Enter': {
        // Enter nunca envía el formulario desde el buscador.
        evento.preventDefault();
        // Un código de barras exacto (pistola lectora) elige el ítem directamente.
        const texto = this.busqueda().trim();
        const porCodigo = this.itemsDisponibles().find(
          (item) => item.codigo && item.codigo === texto,
        );
        const elegido = porCodigo ?? resultados[this.indiceActivo()];
        if (elegido) this.seleccionarItem(elegido);
        break;
      }
      case 'Escape':
        // Con la lista abierta, Escape solo la cierra (no cierra el modal).
        if (this.listaAbierta()) {
          evento.stopPropagation();
          this.listaAbierta.set(false);
        }
        break;
    }
  }

  protected alCambiarSeleccion(): void {
    this.fallo.set(null);
    this.refrescarStock();
  }

  private refrescarStock(): void {
    const { sucursal_id, item_id } = this.formulario.getRawValue();
    if (sucursal_id === null || item_id === null) {
      this.stockActual.set(null);
      return;
    }

    this.cargandoStock.set(true);
    const consulta =
      this.tipo() === 'producto'
        ? this.stockApi.obtenerStockProducto(Number(item_id), Number(sucursal_id))
        : this.stockApi.obtenerStockIngrediente(Number(item_id), Number(sucursal_id));
    consulta.pipe(finalize(() => this.cargandoStock.set(false))).subscribe({
      next: (stock) => this.stockActual.set(stock),
      error: () => this.stockActual.set(null),
    });
  }

  /** Los productos de reventa se cuentan en unidades: impide escribir decimales. */
  protected bloquearDecimales(evento: KeyboardEvent): void {
    if (this.tipo() === 'producto' && ['.', ',', 'e', 'E'].includes(evento.key)) {
      evento.preventDefault();
    }
  }

  protected aplicarAjuste(): void {
    if (this.guardando()) return;
    this.fallo.set(null);
    this.formulario.markAllAsTouched();
    if (this.formulario.invalid) return;

    const valores = this.formulario.getRawValue();
    const cantidad = Number(valores.cantidad);
    const motivo = valores.motivo.trim();
    if (!motivo) {
      this.formulario.controls.motivo.setErrors({ required: true });
      return;
    }
    if (!Number.isFinite(cantidad) || cantidad === 0) {
      this.formulario.controls.cantidad.setErrors({ cero: true });
      return;
    }
    if (this.tipo() === 'producto' && !Number.isInteger(cantidad)) {
      this.formulario.controls.cantidad.setErrors({ entero: true });
      return;
    }

    const itemId = Number(valores.item_id);
    const ajuste: Omit<AjusteStock, 'clave'> = {
      sucursal_id: Number(valores.sucursal_id),
      cantidad,
      motivo,
      ...(this.tipo() === 'producto' ? { producto_id: itemId } : { ingrediente_id: itemId }),
    };
    const datos = JSON.stringify(ajuste);
    const pendiente =
      this.ajustePendiente?.datos === datos ? this.ajustePendiente : { clave: nuevaClave(), datos };
    this.ajustePendiente = pendiente;

    this.guardando.set(true);
    this.stockApi
      .ajustar({ ...ajuste, clave: pendiente.clave })
      .pipe(finalize(() => this.guardando.set(false)))
      .subscribe({
        next: (movimiento) => {
          this.ajustePendiente = null;
          const nuevo = Number(movimiento.stock_resultante);
          const sucursal = this.sucursales().find((s) => s.id === Number(valores.sucursal_id));
          const signo = cantidad > 0 ? '+' : '';
          this.ajustado.emit(
            `Ajuste aplicado a ${this.busqueda()}${sucursal ? ' en ' + sucursal.nombre : ''} ` +
              `(${signo}${cantidad} ${this.unidadItem()}). ` +
              `Stock actual: ${nuevo} ${this.unidadItem()}`,
          );
        },
        error: (error: unknown) => {
          const fallo = interpretarFalloAjuste(error);
          this.fallo.set(fallo);
          if (fallo.actualizarStock) this.refrescarStock();
        },
      });
  }
}

/** UUID v4 de la operación. randomUUID solo existe en https o localhost; getRandomValues, siempre. */
export function nuevaClave(): string {
  if (typeof crypto.randomUUID === 'function') return crypto.randomUUID();
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  bytes[6] = (bytes[6] & 0x0f) | 0x40; // versión 4
  bytes[8] = (bytes[8] & 0x3f) | 0x80; // variante RFC 4122
  const hex = Array.from(bytes, (byte) => byte.toString(16).padStart(2, '0')).join('');
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}
