import { HttpErrorResponse } from '@angular/common/http';
import { Component, HostListener, OnInit, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { finalize } from 'rxjs';
import {
  SucursalApi,
  SucursalCreacion,
  SucursalesApiService,
} from '../../../../core/api/sucursales-api.service';
import { BusinessTabs } from '../../components/business-tabs/business-tabs';

@Component({
  selector: 'app-sucursales',
  imports: [BusinessTabs, ReactiveFormsModule],
  templateUrl: './sucursales.html',
  styleUrls: ['../gestion-negocio/gestion-negocio.css', './sucursales.css'],
})
export class Sucursales implements OnInit {
  private readonly sucursalesApi = inject(SucursalesApiService);
  private readonly formBuilder = inject(FormBuilder);
  protected readonly sucursales = signal<SucursalApi[]>([]);
  protected readonly cargando = signal(true);
  protected readonly error = signal<string | null>(null);
  protected readonly formularioAbierto = signal(false);
  protected readonly sucursalEnEdicion = signal<SucursalApi | null>(null);
  protected readonly guardando = signal(false);
  protected readonly errorFormulario = signal<string | null>(null);
  protected readonly mensajeExito = signal<string | null>(null);
  protected readonly errorAccion = signal<string | null>(null);
  protected readonly idsActualizandoEstado = signal<ReadonlySet<number>>(new Set());
  protected readonly formulario = this.formBuilder.nonNullable.group({
    nombre: ['', [Validators.required, Validators.maxLength(120)]],
    direccion: ['', Validators.maxLength(200)],
    telefono: ['', Validators.maxLength(30)],
    activo: [true],
  });

  ngOnInit(): void {
    this.cargarSucursales();
  }

  protected cargarSucursales(): void {
    this.cargando.set(true);
    this.error.set(null);
    this.sucursalesApi.listar().subscribe({
      next: (sucursales) => {
        this.sucursales.set(sucursales);
        this.cargando.set(false);
      },
      error: () => {
        this.error.set(
          'No pudimos cargar las sucursales. Revisa la conexión e inténtalo nuevamente.',
        );
        this.cargando.set(false);
      },
    });
  }

  protected abrirFormulario(): void {
    this.sucursalEnEdicion.set(null);
    this.formulario.reset({ nombre: '', direccion: '', telefono: '', activo: true });
    this.prepararFormulario();
  }

  protected editarSucursal(sucursal: SucursalApi): void {
    this.sucursalEnEdicion.set(sucursal);
    this.formulario.reset({
      nombre: sucursal.nombre,
      direccion: sucursal.direccion ?? '',
      telefono: sucursal.telefono ?? '',
      activo: sucursal.activo,
    });
    this.prepararFormulario();
  }

  private prepararFormulario(): void {
    this.errorFormulario.set(null);
    this.errorAccion.set(null);
    this.mensajeExito.set(null);
    this.formularioAbierto.set(true);
  }

  @HostListener('document:keydown.escape')
  protected cerrarFormulario(): void {
    if (this.guardando()) return;
    this.formularioAbierto.set(false);
    this.sucursalEnEdicion.set(null);
    this.errorFormulario.set(null);
  }

  protected guardarSucursal(): void {
    if (this.guardando()) return;
    this.errorFormulario.set(null);
    this.formulario.markAllAsTouched();
    const values = this.formulario.getRawValue();
    if (!values.nombre.trim()) this.formulario.controls.nombre.setErrors({ required: true });
    if (this.formulario.invalid) return;

    const datos: SucursalCreacion = {
      nombre: values.nombre.trim(),
      direccion: values.direccion.trim() || null,
      telefono: values.telefono.trim() || null,
      activo: values.activo,
    };
    const sucursal = this.sucursalEnEdicion();
    const request = sucursal
      ? this.sucursalesApi.actualizar(sucursal.id, datos)
      : this.sucursalesApi.crear(datos);
    this.guardando.set(true);
    request.pipe(finalize(() => this.guardando.set(false))).subscribe({
      next: (guardada) => {
        this.sucursales.update((sucursales) =>
          sucursal
            ? sucursales.map((actual) => (actual.id === guardada.id ? guardada : actual))
            : [...sucursales, guardada].sort((a, b) => a.id - b.id),
        );
        this.mensajeExito.set(
          sucursal ? 'Sucursal actualizada correctamente.' : 'Sucursal creada correctamente.',
        );
        this.guardando.set(false);
        this.cerrarFormulario();
      },
      error: (error) => this.errorFormulario.set(this.mensajeError(error, !!sucursal)),
    });
  }

  protected estadoActualizando(id: number): boolean {
    return this.idsActualizandoEstado().has(id);
  }

  protected alternarEstadoSucursal(sucursal: SucursalApi): void {
    if (this.estadoActualizando(sucursal.id)) return;
    this.mensajeExito.set(null);
    this.errorAccion.set(null);
    this.idsActualizandoEstado.update((ids) => new Set(ids).add(sucursal.id));
    this.sucursalesApi
      .actualizarEstado(sucursal.id, !sucursal.activo)
      .pipe(
        finalize(() => {
          this.idsActualizandoEstado.update((ids) => {
            const updated = new Set(ids);
            updated.delete(sucursal.id);
            return updated;
          });
        }),
      )
      .subscribe({
        next: (actualizada) => {
          this.sucursales.update((sucursales) =>
            sucursales.map((actual) => (actual.id === actualizada.id ? actualizada : actual)),
          );
          this.mensajeExito.set(
            `${actualizada.nombre} ahora está ${actualizada.activo ? 'activa' : 'deshabilitada'}.`,
          );
        },
        error: (error) => this.errorAccion.set(this.mensajeError(error, true)),
      });
  }

  private mensajeError(error: unknown, editing: boolean): string {
    if (error instanceof HttpErrorResponse) {
      if (error.status === 409) return 'Ya existe una sucursal con ese nombre. Elige otro nombre.';
      if (error.status === 401 || error.status === 403)
        return 'Tu sesión no tiene permisos para modificar sucursales.';
      if (error.status === 404 && editing)
        return 'La sucursal ya no está disponible. Actualiza el listado e inténtalo nuevamente.';
    }
    return 'No pudimos guardar la sucursal. Revisa los datos y la conexión e inténtalo nuevamente.';
  }
}
