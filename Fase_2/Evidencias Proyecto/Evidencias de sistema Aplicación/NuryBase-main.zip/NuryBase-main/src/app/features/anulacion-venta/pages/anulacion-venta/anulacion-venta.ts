import { HttpErrorResponse } from '@angular/common/http';
import { Component, computed, inject, OnInit, signal } from '@angular/core';
import { catchError, finalize, forkJoin, of, timeout } from 'rxjs';
import { VentasApiService } from '../../../../core/api/ventas-api.service';
import { UsuariosApiService } from '../../../../core/api/usuarios-api.service';
import { AuthService } from '../../../auth/services/auth.service';
import { PAYMENT_METHOD_META } from '../../../caja/models/caja.model';
import { PosService } from '../../../pos/services/pos.service';

const MOTIVO_MIN_LENGTH = 5;
const REQUEST_TIMEOUT_MS = 15000;

export type EstadoVenta = 'todas' | 'vigentes' | 'anuladas';
export type TipoVentaFiltro = 'todas' | 'normal' | 'empleado';

export interface VentaFila {
  id: number;
  folio: string;
  fecha: Date;
  medioPago: string;
  total: number;
  cajeroId: number | null;
  cajeroNombre: string;
  anulada: boolean;
  anuladaMotivo: string | null;
  /** Venta a empleado (H2.12): `ventas.venta_especial`. */
  ventaEspecial: boolean;
  empleadoNombre: string | null;
  descuentoPorcentaje: number;
  descuentoMonto: number;
  items: { nombre: string; cantidad: number; precioUnitario: number; subtotal: number }[];
}

@Component({
  selector: 'app-anulacion-venta',
  styleUrl: './anulacion-venta.css',
  templateUrl: './anulacion-venta.html',
})
export class AnulacionVenta implements OnInit {
  private readonly ventasApi = inject(VentasApiService);
  private readonly usuariosApi = inject(UsuariosApiService);
  private readonly authService = inject(AuthService);
  private readonly posService = inject(PosService);
  protected readonly esAdmin = computed(() => this.authService.currentUser()?.rol === 'admin');

  protected readonly sucursalId = computed(
    () => this.authService.currentUser()?.sucursalId ?? null,
  );
  protected readonly sucursalNombre = computed(
    () => this.authService.currentUser()?.sucursalNombre ?? '',
  );

  protected readonly fechaDesde = signal(fechaLocalInput(new Date()));
  protected readonly fechaHasta = signal(fechaLocalInput(new Date()));
  protected readonly cargando = signal(false);
  protected readonly cargaError = signal<string | null>(null);
  protected readonly ventas = signal<VentaFila[]>([]);

  protected readonly searchQuery = signal('');
  protected readonly ventaSeleccionada = signal<VentaFila | null>(null);
  protected readonly motivo = signal('');
  protected readonly motivoValido = computed(
    () => this.motivo().trim().length >= MOTIVO_MIN_LENGTH,
  );
  protected readonly motivoMinLength = MOTIVO_MIN_LENGTH;
  protected readonly anulando = signal(false);
  protected readonly anularError = signal<string | null>(null);
  protected readonly successMessage = signal<string | null>(null);

  /** `''` = todos los cajeros; `'sin'` = ventas sin cajero; si no, el id del cajero. */
  protected readonly cajeroFiltro = signal('');
  protected readonly cajeros = computed(() => {
    const porId = new Map<number, string>();
    let haySinCajero = false;
    for (const venta of this.ventas()) {
      if (venta.cajeroId == null) haySinCajero = true;
      else porId.set(venta.cajeroId, venta.cajeroNombre);
    }
    const lista = [...porId].map(([id, nombre]) => ({ valor: String(id), nombre }));
    lista.sort((a, b) => a.nombre.localeCompare(b.nombre, 'es'));
    if (haySinCajero) lista.push({ valor: 'sin', nombre: 'Sin cajero' });
    return lista;
  });

  protected readonly tipoVentaFiltro = signal<TipoVentaFiltro>('todas');

  /** Ventas del cajero y tipo de venta elegidos; los totales de arriba usan esta lista. */
  private readonly ventasDelCajero = computed(() => {
    if (!this.esAdmin()) {
      return this.ventas().filter((venta) => venta.cajeroId === this.authService.currentUser()?.id);
    }
    const filtro = this.cajeroFiltro();
    const tipo = this.tipoVentaFiltro();
    return this.ventas().filter(
      (venta) =>
        (!filtro ||
          (filtro === 'sin' ? venta.cajeroId == null : String(venta.cajeroId) === filtro)) &&
        (tipo === 'todas' || venta.ventaEspecial === (tipo === 'empleado')),
    );
  });

  protected readonly estadoFiltro = signal<EstadoVenta>('todas');
  protected readonly estados: { valor: EstadoVenta; etiqueta: string }[] = [
    { valor: 'todas', etiqueta: 'Todas' },
    { valor: 'vigentes', etiqueta: 'Vigentes' },
    { valor: 'anuladas', etiqueta: 'Anuladas' },
  ];

  protected readonly vigentes = computed(() =>
    this.ventasDelCajero().filter((venta) => !venta.anulada),
  );
  protected readonly anuladas = computed(() =>
    this.ventasDelCajero().filter((venta) => venta.anulada),
  );
  protected readonly totalVigente = computed(() =>
    this.vigentes().reduce((sum, venta) => sum + venta.total, 0),
  );
  /** Ventas del cajero elegido según el estado (todas, vigentes o anuladas). */
  private readonly ventasPorEstado = computed(() => {
    switch (this.estadoFiltro()) {
      case 'vigentes':
        return this.vigentes();
      case 'anuladas':
        return this.anuladas();
      default:
        return this.ventasDelCajero();
    }
  });

  protected readonly ventasFiltradas = computed(() => {
    const query = this.searchQuery().trim().toLowerCase();
    if (!query) return this.ventasPorEstado();

    return this.ventasPorEstado().filter(
      (venta) =>
        venta.folio.toLowerCase().includes(query) ||
        this.medioPagoLabel(venta.medioPago).toLowerCase().includes(query) ||
        venta.cajeroNombre.toLowerCase().includes(query) ||
        venta.items.some((item) => item.nombre.toLowerCase().includes(query)),
    );
  });

  ngOnInit(): void {
    this.cargar();
  }

  /** Trae el historial permitido de la sucursal, sin depender del turno abierto. */
  protected cargar(): void {
    const usuario = this.authService.currentUser();
    if (!usuario || !['admin', 'cajero'].includes(usuario.rol)) return;
    const sucursalId = this.sucursalId();
    if (sucursalId == null) {
      this.cargaError.set(
        'Tu usuario no tiene una sucursal asignada, así que no hay ventas que mostrar.',
      );
      return;
    }

    const desde = inicioDelDia(this.fechaDesde());
    const hasta = inicioDelDia(this.fechaHasta());
    if (!desde || !hasta || desde > hasta) {
      this.cargaError.set(
        'Revisa el rango de fechas: la fecha inicial no puede ser posterior a la final.',
      );
      return;
    }
    hasta.setDate(hasta.getDate() + 1);

    this.cargando.set(true);
    this.cargaError.set(null);
    this.cajeroFiltro.set('');
    this.tipoVentaFiltro.set('todas');

    forkJoin({
      ventas: this.ventasApi.listar({
        sucursalIds: [sucursalId],
        desde,
        hasta,
        incluirDetalle: true,
        ...(this.esAdmin() ? {} : { cajeroId: usuario.id }),
      }),
      // Los nombres son un complemento: si falla, se muestra el número de cajero.
      usuarios: this.esAdmin()
        ? this.usuariosApi.listar().pipe(catchError(() => of([])))
        : of([{ id: usuario.id, nombre: usuario.nombre }]),
    })
      .pipe(
        timeout(REQUEST_TIMEOUT_MS),
        finalize(() => this.cargando.set(false)),
      )
      .subscribe({
        next: ({ ventas, usuarios }) => {
          const nombres = new Map(usuarios.map((usuario) => [usuario.id, usuario.nombre]));
          this.ventas.set(
            ventas
              .filter((venta) => this.esAdmin() || venta.cajero_id === usuario.id)
              .map((venta) => ({
                id: venta.id,
                folio: venta.codigo_venta ?? `TK-${venta.id}`,
                fecha: fechaDeServidor(venta.fecha_venta),
                medioPago: venta.medio_pago ?? '',
                total: venta.total,
                cajeroId: venta.cajero_id,
                cajeroNombre:
                  venta.cajero_id == null
                    ? 'Sin cajero'
                    : (nombres.get(venta.cajero_id) ?? `Cajero #${venta.cajero_id}`),
                anulada: venta.anulada,
                anuladaMotivo: venta.anulada_motivo ?? null,
                ventaEspecial: venta.venta_especial ?? venta.tipo_venta === 'empleado',
                empleadoNombre:
                  venta.empleado_id == null
                    ? null
                    : (nombres.get(venta.empleado_id) ?? `Empleado #${venta.empleado_id}`),
                descuentoPorcentaje: Number(venta.descuento_porcentaje ?? 0),
                descuentoMonto: Number(venta.descuento_monto ?? 0),
                items: (venta.detalle_venta ?? []).map((detalle) => ({
                  nombre: detalle.productos?.nombre ?? 'Producto',
                  cantidad: detalle.cantidad,
                  precioUnitario: detalle.precio_unitario,
                  subtotal: detalle.subtotal,
                })),
              })),
          );
        },
        error: () => {
          this.ventas.set([]);
          this.cargaError.set(
            'No se pudieron cargar las ventas. Revisa tu conexión e intenta nuevamente.',
          );
        },
      });
  }

  protected abrirDetalle(venta: VentaFila): void {
    if (!this.puedeAnular(venta)) return;
    this.anularError.set(null);
    this.motivo.set('');
    this.ventaSeleccionada.set(venta);
  }

  protected cerrarDetalle(): void {
    if (this.anulando()) return;
    this.ventaSeleccionada.set(null);
  }

  protected confirmarAnulacion(): void {
    const venta = this.ventaSeleccionada();
    const usuarioId = this.authService.currentUser()?.id;
    const motivo = this.motivo().trim();
    if (!venta || !usuarioId || !this.puedeAnular(venta) || !this.motivoValido() || this.anulando())
      return;

    this.anulando.set(true);
    this.anularError.set(null);

    this.ventasApi
      .anular(venta.id, motivo)
      .pipe(
        timeout(REQUEST_TIMEOUT_MS),
        finalize(() => this.anulando.set(false)),
      )
      .subscribe({
        next: () => {
          this.posService.sincronizarAnulacion(venta.id, motivo);
          this.ventas.set(
            this.ventas().map((fila) =>
              fila.id === venta.id ? { ...fila, anulada: true, anuladaMotivo: motivo } : fila,
            ),
          );
          this.ventaSeleccionada.set(null);
          this.successMessage.set(`Venta ${venta.folio} anulada correctamente.`);
        },
        error: (err: unknown) => {
          this.anularError.set(this.mensajeDeErrorAnulacion(err));
        },
      });
  }

  protected puedeAnular(venta: VentaFila): boolean {
    const usuario = this.authService.currentUser();
    return (
      !venta.anulada &&
      !!usuario &&
      (usuario.rol === 'admin' || (usuario.rol === 'cajero' && venta.cajeroId === usuario.id))
    );
  }

  private mensajeDeErrorAnulacion(err: unknown): string {
    if (err instanceof HttpErrorResponse && err.status > 0) {
      const detalle = typeof err.error?.message === 'string' ? err.error.message : null;
      return detalle
        ? `El servidor rechazó la anulación (error ${err.status}): ${detalle}`
        : `El servidor rechazó la anulación (error ${err.status}).`;
    }
    if (err instanceof Error && err.name !== 'TimeoutError' && !(err instanceof HttpErrorResponse)) {
      return err.message;
    }
    return 'No se pudo anular la venta. Revisa tu conexión e intenta nuevamente.';
  }

  protected setTipoVentaFiltro(valor: string): void {
    this.tipoVentaFiltro.set(valor === 'normal' || valor === 'empleado' ? valor : 'todas');
  }

  /** Suma de los productos antes del descuento de empleado. */
  protected subtotalVenta(venta: VentaFila): number {
    return venta.total + venta.descuentoMonto;
  }

  protected medioPagoLabel(medioPago: string): string {
    return PAYMENT_METHOD_META[medioPago as keyof typeof PAYMENT_METHOD_META]?.label ?? medioPago;
  }

  protected resumenProductos(venta: VentaFila): string {
    return venta.items.map((item) => `${item.cantidad} × ${item.nombre}`).join(', ');
  }

  protected formatCLP(value: number): string {
    return `$${Math.round(value).toLocaleString('es-CL')}`;
  }

  protected formatFecha(fecha: Date): string {
    return fecha.toLocaleString('es-CL', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }
}

/** `YYYY-MM-DD` con la fecha local, el formato de `<input type="date">`. */
function fechaLocalInput(fecha: Date): string {
  const mes = String(fecha.getMonth() + 1).padStart(2, '0');
  const dia = String(fecha.getDate()).padStart(2, '0');
  return `${fecha.getFullYear()}-${mes}-${dia}`;
}

/** Medianoche local del día indicado, o null si el valor no es una fecha válida. */
function inicioDelDia(valor: string): Date | null {
  const [anio, mes, dia] = valor.split('-').map(Number);
  if (!anio || !mes || !dia) return null;
  return new Date(anio, mes - 1, dia);
}

/** `ventas.fecha_venta` llega sin zona horaria y el servidor guarda UTC. */
function fechaDeServidor(valor: string): Date {
  return new Date(/[zZ]|[+-]\d{2}:?\d{2}$/.test(valor) ? valor : `${valor}Z`);
}
