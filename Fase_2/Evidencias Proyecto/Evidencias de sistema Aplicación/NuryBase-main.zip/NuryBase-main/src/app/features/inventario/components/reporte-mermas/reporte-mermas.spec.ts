import { HttpErrorResponse } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Subject, of, throwError } from 'rxjs';
import { AjusteStock, ClaseAjuste, agruparMermas } from '../../models/inventario.model';
import { InventarioService } from '../../services/inventario.service';
import { ReporteMermas } from './reporte-mermas';

/** `cantidad` con signo: negativa sale, positiva entra. */
function ajuste(
  id: number,
  articulo: string,
  cantidad: number,
  unidad: string,
  sucursal = 'Nury Providencia',
  fecha = new Date(2026, 9, 8, 9, 15),
  clase: ClaseAjuste = 'ajuste',
): AjusteStock {
  return {
    id,
    existenciaId: `${articulo}-${sucursal}`,
    articulo,
    tipo: unidad === 'un' ? 'producto' : 'materia_prima',
    clase,
    cantidad,
    unidad,
    motivo: 'Merma',
    usuario: 'Rocío Fuentes',
    sucursalId: sucursal === 'Nury Providencia' ? 1 : 2,
    sucursal,
    fecha,
  };
}

describe('agruparMermas', () => {
  it('suma por artículo y unidad, aunque vengan de distintas sucursales', () => {
    const totales = agruparMermas([
      ajuste(1, 'Leche entera', -1, 'L'),
      ajuste(2, 'Café en grano', -0.1, 'kg'),
      ajuste(3, 'Leche entera', -2, 'L', 'Nury Ñuñoa'),
      ajuste(4, 'Café en grano', -0.2, 'kg'),
    ]);

    expect(totales).toEqual([
      {
        articulo: 'Café en grano',
        tipo: 'materia_prima',
        unidad: 'kg',
        salida: 0.3,
        entrada: 0,
        ajustes: 2,
      },
      {
        articulo: 'Leche entera',
        tipo: 'materia_prima',
        unidad: 'L',
        salida: 3,
        entrada: 0,
        ajustes: 2,
      },
    ]);
  });

  it('no mezcla un mismo artículo registrado en unidades distintas', () => {
    const totales = agruparMermas([
      ajuste(1, 'Azúcar', -1, 'kg'),
      ajuste(2, 'Azúcar', -500, 'g'),
      ajuste(3, 'Azúcar', -0.5, 'kg'),
    ]);

    expect(totales.map((t) => [t.articulo, t.unidad, t.salida, t.ajustes])).toEqual([
      ['Azúcar', 'g', 500, 1],
      ['Azúcar', 'kg', 1.5, 2],
    ]);
  });

  it('separa lo que salió de lo que entró, sin compensarlos', () => {
    const totales = agruparMermas([
      ajuste(1, 'Leche entera', -1, 'L'),
      ajuste(2, 'Leche entera', 5, 'L'),
      ajuste(3, 'Leche entera', -0.5, 'L'),
    ]);

    expect(totales.map((t) => [t.salida, t.entrada, t.ajustes])).toEqual([[1.5, 5, 3]]);
  });

  it('devuelve una lista vacía sin ajustes', () => {
    expect(agruparMermas([])).toEqual([]);
  });
});

describe('ReporteMermas', () => {
  let fixture: ComponentFixture<ReporteMermas>;
  const service = { listarMermas: vi.fn() };
  const sucursales = [
    { id: 1, nombre: 'Nury Providencia' },
    { id: 2, nombre: 'Nury Ñuñoa' },
  ];

  async function render(sucursalInicial = 'todas', esperarCarga = true): Promise<void> {
    await TestBed.configureTestingModule({
      imports: [ReporteMermas],
      providers: [{ provide: InventarioService, useValue: service }],
    }).compileComponents();
    fixture = TestBed.createComponent(ReporteMermas);
    fixture.componentRef.setInput('sucursales', sucursales);
    fixture.componentRef.setInput('sucursalInicial', sucursalInicial);
    if (esperarCarga) {
      await estable();
    } else {
      fixture.detectChanges();
    }
  }

  async function estable(): Promise<void> {
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
  }

  function element(): HTMLElement {
    return fixture.nativeElement as HTMLElement;
  }
  async function cambiar(selector: string, valor: string): Promise<void> {
    const control = element().querySelector(selector) as HTMLSelectElement | HTMLInputElement;
    control.value = valor;
    control.dispatchEvent(new Event('change'));
    await estable();
  }
  function texto(selector: string): string {
    return (element().querySelector(selector)?.textContent ?? '').replace(/\s+/g, ' ').trim();
  }
  function ultimaConsulta(): unknown {
    return service.listarMermas.mock.lastCall?.[0];
  }

  beforeEach(() => {
    // Solo se fija la fecha; los temporizadores siguen siendo reales para que el recurso cargue.
    vi.useFakeTimers({ toFake: ['Date'] });
    vi.setSystemTime(new Date(2026, 9, 8, 12, 0));
    service.listarMermas.mockReset();
    service.listarMermas.mockReturnValue(of([]));
  });

  afterEach(() => vi.useRealTimers());

  it('consults the last 7 days of every branch by default', async () => {
    service.listarMermas.mockReturnValue(
      of([
        ajuste(2, 'Café en grano', -0.25, 'kg', 'Nury Providencia', new Date(2026, 9, 7, 17, 21)),
        ajuste(1, 'Leche entera', -2, 'L', 'Nury Ñuñoa', new Date(2026, 9, 4, 10, 5)),
        ajuste(3, 'Café en grano', -0.5, 'kg', 'Nury Providencia', new Date(2026, 9, 3, 16, 9)),
      ]),
    );
    await render();

    expect(ultimaConsulta()).toEqual({
      sucursalId: null,
      desde: '2026-10-02',
      hasta: '2026-10-08',
      soloMermas: false,
    });
    expect(texto('.record-count')).toBe('3 ajustes');
    expect(texto('.totals h3')).toBe('Totales por artículo del 02-10-2026 al 08-10-2026');
    const totales = Array.from(element().querySelectorAll('.total-card')).map((card) =>
      card.textContent!.replace(/\s+/g, ' ').trim(),
    );
    expect(totales).toEqual([
      'Café en grano −0,75 kg Materia prima · 2 ajustes',
      'Leche entera −2 L Materia prima · 1 ajuste',
    ]);

    const primeraFila = Array.from(
      element().querySelectorAll('tbody tr')[0].querySelectorAll('td'),
    ).map((celda) => celda.textContent!.replace(/\s+/g, ' ').trim());
    expect(primeraFila).toEqual([
      '07-10-2026 17:21',
      'Café en grano',
      'Ajuste',
      '−0,25 kg',
      'Merma',
      'Rocío Fuentes',
      'Nury Providencia',
    ]);
  });

  it('opens on the branch chosen in the stock panel and filters by branch', async () => {
    await render('2');

    expect(ultimaConsulta()).toEqual(expect.objectContaining({ sucursalId: 2 }));
    const select = element().querySelector<HTMLSelectElement>(
      'select[aria-label="Sucursal del reporte"]',
    )!;
    expect(select.selectedOptions[0].textContent).toContain('Nury Ñuñoa');

    await cambiar('select[aria-label="Sucursal del reporte"]', '1');
    expect(ultimaConsulta()).toEqual(expect.objectContaining({ sucursalId: 1 }));
    await cambiar('select[aria-label="Sucursal del reporte"]', 'todas');
    expect(ultimaConsulta()).toEqual(expect.objectContaining({ sucursalId: null }));
  });

  it.each([
    ['hoy', '2026-10-08', '2026-10-08'],
    ['30-dias', '2026-09-09', '2026-10-08'],
    ['mes', '2026-10-01', '2026-10-08'],
  ])('consults the period "%s"', async (periodo, desde, hasta) => {
    await render();
    await cambiar('select[aria-label="Periodo del reporte"]', periodo);

    expect(ultimaConsulta()).toEqual({ sucursalId: null, desde, hasta, soloMermas: false });
  });

  it('validates the custom range before consulting', async () => {
    await render();
    await cambiar('select[aria-label="Periodo del reporte"]', 'personalizado');
    const consultas = service.listarMermas.mock.calls.length;

    // El rango personalizado parte en los últimos 7 días: desde el 02-10-2026.
    await cambiar('input[aria-label="Fecha final"]', '2026-10-01');
    expect(texto('.range-error')).toBe('La fecha inicial no puede ser posterior a la final.');
    expect(service.listarMermas.mock.calls.length).toBe(consultas);

    await cambiar('input[aria-label="Fecha final"]', '');
    expect(texto('.range-error')).toBe('Indica la fecha inicial y la final.');

    await cambiar('input[aria-label="Fecha inicial"]', '2026-09-15');
    await cambiar('input[aria-label="Fecha final"]', '2026-09-20');
    expect(element().querySelector('.range-error')).toBeNull();
    expect(ultimaConsulta()).toEqual({
      sucursalId: null,
      desde: '2026-09-15',
      hasta: '2026-09-20',
      soloMermas: false,
    });
  });

  it('shows an empty state for the period', async () => {
    await render();
    await cambiar('select[aria-label="Periodo del reporte"]', 'hoy');

    expect(texto('.report-message')).toContain('No hay ajustes registrados el 08-10-2026.');
    expect(element().querySelector('.waste-table')).toBeNull();
  });

  it('shows only waste when chosen, with its own counts and empty state', async () => {
    await render();
    await cambiar('select[aria-label="Tipo de movimiento del reporte"]', 'mermas');

    expect(ultimaConsulta()).toEqual(expect.objectContaining({ soloMermas: true }));
    expect(texto('.report-message')).toContain('No hay mermas registradas del 02-10-2026');

    service.listarMermas.mockReturnValue(
      of([ajuste(1, 'Leche entera', -1, 'L', 'Nury Providencia', undefined, 'merma')]),
    );
    await cambiar('select[aria-label="Periodo del reporte"]', 'hoy');
    expect(texto('.record-count')).toBe('1 merma');
    expect(texto('td[data-label="Tipo"]')).toBe('Merma');

    await cambiar('select[aria-label="Tipo de movimiento del reporte"]', 'todos');
    expect(ultimaConsulta()).toEqual(expect.objectContaining({ soloMermas: false }));
  });

  it('shows stock that came in with a plus sign, apart from what went out', async () => {
    service.listarMermas.mockReturnValue(
      of([ajuste(2, 'Leche entera', 5, 'L'), ajuste(1, 'Leche entera', -1, 'L')]),
    );
    await render();

    const cantidades = element().querySelectorAll('td[data-label="Cantidad"]');
    expect(cantidades[0].textContent!.trim()).toBe('+5 L');
    expect(cantidades[0].classList.contains('entrada')).toBe(true);
    expect(cantidades[1].textContent!.trim()).toBe('−1 L');
    expect(cantidades[1].classList.contains('entrada')).toBe(false);
    expect(texto('.total-card')).toBe('Leche entera −1 L +5 L Materia prima · 2 ajustes');
  });

  it('shows the loading state and an error with retry', async () => {
    const pendiente = new Subject<AjusteStock[]>();
    service.listarMermas.mockReturnValue(pendiente);
    await render('todas', false);
    expect(texto('[role="status"]')).toBe('Cargando mermas...');
    expect(element().querySelector('.report-panel')?.getAttribute('aria-busy')).toBe('true');

    pendiente.error(new Error('500'));
    await estable();
    expect(texto('.report-message.error')).toContain('No pudimos cargar las mermas.');

    service.listarMermas.mockReturnValue(of([ajuste(1, 'Leche entera', -1, 'L')]));
    element().querySelector<HTMLButtonElement>('.report-message.error button')!.click();
    await estable();
    expect(texto('.record-count')).toBe('1 ajuste');
  });

  it('explains a permission error without offering a retry', async () => {
    service.listarMermas.mockReturnValue(
      throwError(() => new HttpErrorResponse({ status: 403, statusText: 'Forbidden' })),
    );
    await render();

    expect(texto('.report-message.error')).toBe(
      'Tu rol no tiene permiso para ver el reporte de mermas. Pide acceso al administrador.',
    );
    expect(element().querySelector('.report-message.error')?.getAttribute('role')).toBe('alert');
    expect(element().querySelector('.report-message.error button')).toBeNull();
  });

  it('shows a dash when the adjustment has no recorded user', async () => {
    service.listarMermas.mockReturnValue(
      of([{ ...ajuste(1, 'Leche entera', -1, 'L'), usuario: null }]),
    );
    await render();

    expect(texto('td[data-label="Registrado por"]')).toBe('—');
  });

  it('consults again when a new adjustment is confirmed', async () => {
    await render();
    const consultas = service.listarMermas.mock.calls.length;

    fixture.componentRef.setInput('version', 1);
    await estable();
    expect(service.listarMermas.mock.calls.length).toBe(consultas + 1);
  });

  it('hides the branch filter when there is only one branch', async () => {
    await TestBed.configureTestingModule({
      imports: [ReporteMermas],
      providers: [{ provide: InventarioService, useValue: service }],
    }).compileComponents();
    fixture = TestBed.createComponent(ReporteMermas);
    fixture.componentRef.setInput('sucursales', [sucursales[0]]);
    await estable();

    expect(element().querySelector('select[aria-label="Sucursal del reporte"]')).toBeNull();
    expect(service.listarMermas).toHaveBeenCalledWith(
      expect.objectContaining({ sucursalId: null }),
    );
  });
});
