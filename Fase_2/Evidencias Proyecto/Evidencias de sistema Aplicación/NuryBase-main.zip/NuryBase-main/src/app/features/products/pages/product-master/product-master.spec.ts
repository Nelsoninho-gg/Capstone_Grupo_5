import { ComponentFixture, TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import {
  ProductoActualizacion,
  ProductoApi,
  ProductoCreacion,
  ProductosApiService,
} from '../../../../core/api/productos-api.service';
import { ProductMaster } from './product-master';
import { signal } from '@angular/core';
import { UserRole } from '../../../auth/models/auth.model';
import { AuthService } from '../../../auth/services/auth.service';
import { CatalogoService } from '../../services/catalogo.service';

describe('ProductMaster', () => {
  let component: ProductMaster;
  let fixture: ComponentFixture<ProductMaster>;
  let updatedProduct: ProductoActualizacion | null;
  let createdProduct: ProductoCreacion | null;
  let updatedStatus: { id: number; activo: boolean } | null;
  let deletedProductId: number | null;
  const rol = signal<UserRole>('admin');

  const product: ProductoApi = {
    id: 7,
    nombre: 'Café americano',
    categoria: 'Cafetería',
    precio_compra: 1200,
    precio_venta: 2200,
    codigo_barras: '7800000000007',
    activo: true,
    creado_en: '2026-09-01T12:00:00Z',
  };
  const secondProduct: ProductoApi = {
    id: 12,
    nombre: 'Té verde',
    categoria: 'Pastelería',
    precio_compra: null,
    precio_venta: 1800,
    codigo_barras: '7800000000012',
    activo: true,
    creado_en: '2026-09-02T12:00:00Z',
  };
  const paginationProducts: ProductoApi[] = Array.from({ length: 23 }, (_, index) => ({
    ...(index < 20 ? product : secondProduct),
    id: index + 1,
    nombre: `Producto ${index + 1}`,
    codigo_barras: `CODE-${index + 1}`,
    activo: index < 20,
    precio_venta: index < 20 ? 2200 : 0,
  }));

  beforeEach(async () => {
    rol.set('admin');
    updatedProduct = null;
    createdProduct = null;
    updatedStatus = null;
    deletedProductId = null;
    await TestBed.configureTestingModule({
      imports: [ProductMaster],
      providers: [
        { provide: AuthService, useValue: { currentUser: () => ({ rol: rol() }) } },
        {
          provide: CatalogoService,
          useValue: { listarMateriasPrimas: () => of([]), listarUnidades: () => of([]) },
        },
        {
          provide: ProductosApiService,
          useValue: {
            listar: () => of([product, secondProduct]),
            crear: (newProduct: ProductoCreacion) => {
              createdProduct = newProduct;
              return of({
                ...newProduct,
                id: 8,
                creado_en: '2026-09-20T12:00:00Z',
              });
            },
            actualizar: (_id: number, changes: ProductoActualizacion) => {
              updatedProduct = changes;
              return of({ ...product, ...changes });
            },
            actualizarEstado: (id: number, activo: boolean) => {
              updatedStatus = { id, activo };
              const currentProduct = id === product.id ? product : secondProduct;
              return of({ ...currentProduct, activo });
            },
            eliminar: (id: number) => {
              deletedProductId = id;
              return of(id === product.id ? product : secondProduct);
            },
          },
        },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(ProductMaster);
    component = fixture.componentInstance;
    await fixture.whenStable();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('allows a cashier to create and edit without sending the product status', () => {
    rol.set('cajero');
    fixture.detectChanges();
    const host = fixture.nativeElement as HTMLElement;
    expect(host.querySelector('.delete-button')).toBeNull();
    expect(host.querySelector('.visibility-button')).toBeNull();

    (host.querySelector('.edit-button') as HTMLButtonElement).click();
    fixture.detectChanges();
    expect(host.querySelector('[formControlName="activo"]')).toBeNull();
    component['productForm'].patchValue({ nombre: 'Café editado', activo: false });
    component['saveProduct']();
    expect(updatedProduct).toMatchObject({ nombre: 'Café editado' });
    expect(updatedProduct).not.toHaveProperty('activo');

    component['openCreateModal']();
    component['productForm'].patchValue({
      nombre: 'Nuevo café',
      precio_venta: 2500,
      activo: false,
    });
    component['saveProduct']();
    expect(createdProduct).toMatchObject({ nombre: 'Nuevo café', precio_venta: 2500 });
    expect(createdProduct).not.toHaveProperty('activo');
  });

  it('blocks cashier status changes and deletion even if methods are invoked directly', () => {
    rol.set('cajero');
    component['toggleProductStatus'](product);
    component['openDeleteModal'](product);
    expect(component['productToDelete']()).toBeNull();
    component['productToDelete'].set(product);
    component['deleteProduct']();
    expect(updatedStatus).toBeNull();
    expect(deletedProductId).toBeNull();
  });

  it('shows ten rows per page with working navigation and the visible product range', () => {
    component['products'].set(paginationProducts);
    fixture.detectChanges();
    const previous = fixture.nativeElement.querySelector(
      '[aria-label="Página anterior"]',
    ) as HTMLButtonElement;
    const next = fixture.nativeElement.querySelector(
      '[aria-label="Página siguiente"]',
    ) as HTMLButtonElement;
    const visibleNames = () =>
      Array.from(
        fixture.nativeElement.querySelectorAll('.product-name') as NodeListOf<HTMLElement>,
      ).map((element) => element.textContent?.trim());

    expect(visibleNames()).toEqual(paginationProducts.slice(0, 10).map((p) => p.nombre));
    expect(fixture.nativeElement.querySelector('.table-footer').textContent).toContain(
      'Mostrando 1–10 de 23 productos',
    );
    expect(previous.disabled).toBe(true);

    next.click();
    fixture.detectChanges();
    expect(visibleNames()).toEqual(paginationProducts.slice(10, 20).map((p) => p.nombre));
    expect(previous.disabled).toBe(false);
    expect(fixture.nativeElement.querySelector('.table-footer').textContent).toContain(
      'Mostrando 11–20 de 23 productos',
    );

    next.click();
    fixture.detectChanges();
    expect(visibleNames()).toEqual(paginationProducts.slice(20).map((p) => p.nombre));
    expect(next.disabled).toBe(true);
    expect(fixture.nativeElement.querySelector('.table-footer').textContent).toContain(
      'Mostrando 21–23 de 23 productos',
    );
    expect(fixture.nativeElement.querySelector('.pagination span').textContent).toContain(
      'Página 3 de 3',
    );

    previous.click();
    fixture.detectChanges();
    expect(visibleNames()).toEqual(paginationProducts.slice(10, 20).map((p) => p.nombre));
  });

  it.each([
    ['search', '[aria-label="Buscar productos"]', 'input', 'CODE-23', 1],
    ['category', '[aria-label="Filtrar por categoría"]', 'change', 'Pastelería', 3],
    ['status', '[aria-label="Filtrar por estado"]', 'change', 'inactivos', 3],
    ['zero price', '.zero-price-filter', 'click', '', 3],
  ] as const)(
    'returns to the first page when filtering by %s',
    (_name, selector, event, value, count) => {
      component['products'].set(paginationProducts);
      fixture.detectChanges();
      const next = fixture.nativeElement.querySelector(
        '[aria-label="Página siguiente"]',
      ) as HTMLButtonElement;
      next.click();
      fixture.detectChanges();
      next.click();
      fixture.detectChanges();

      const control = fixture.nativeElement.querySelector(selector) as HTMLInputElement;
      control.value = value;
      control.dispatchEvent(new Event(event));
      fixture.detectChanges();

      expect(component['currentPage']()).toBe(1);
      expect(fixture.nativeElement.querySelectorAll('.product-name')).toHaveLength(count);
      expect(fixture.nativeElement.querySelector('.pagination')).toBeNull();
      expect(fixture.nativeElement.querySelector('.table-footer').textContent).toContain(
        `Mostrando 1–${count} de ${count} productos`,
      );
    },
  );

  it('shows a zero range and no pagination when the search has no matches', () => {
    component['searchQuery'].set('sin coincidencias');
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelectorAll('.product-name')).toHaveLength(0);
    expect(fixture.nativeElement.querySelector('.empty-row').textContent).toContain(
      'No encontramos productos',
    );
    expect(fixture.nativeElement.querySelector('.pagination')).toBeNull();
    expect(fixture.nativeElement.querySelector('.table-footer').textContent).toContain(
      'Mostrando 0–0 de 0 productos',
    );
  });

  it('keeps a valid page after deleting the only product on the last page', () => {
    component['products'].set(paginationProducts.slice(0, 21));
    vi.spyOn(TestBed.inject(ProductosApiService), 'eliminar').mockReturnValue(
      of(paginationProducts[20]),
    );
    fixture.detectChanges();
    const next = fixture.nativeElement.querySelector(
      '[aria-label="Página siguiente"]',
    ) as HTMLButtonElement;
    next.click();
    fixture.detectChanges();
    next.click();
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelectorAll('.product-name')).toHaveLength(1);

    (fixture.nativeElement.querySelector('.delete-button') as HTMLButtonElement).click();
    fixture.detectChanges();
    (fixture.nativeElement.querySelector('.confirm-delete-button') as HTMLButtonElement).click();
    fixture.detectChanges();

    expect(fixture.nativeElement.querySelectorAll('.product-name')).toHaveLength(10);
    expect(fixture.nativeElement.querySelector('.pagination span').textContent).toContain(
      'Página 1 de 2',
    );
    expect(component['products']()).toHaveLength(20);
  });

  it('shows the database purchase price before the sale price', () => {
    const headers = [...fixture.nativeElement.querySelectorAll('.product-table thead th')].map(
      (header: HTMLTableCellElement) => header.textContent?.trim(),
    );
    const firstRow = fixture.nativeElement.querySelector('.product-table tbody tr');

    expect(headers.indexOf('Precio de compra')).toBe(headers.indexOf('Precio de venta') - 1);
    expect(firstRow.querySelector('[data-label="Precio de compra"]').textContent.trim()).toBe(
      '$1.200',
    );
    expect(firstRow.querySelector('[data-label="Precio de venta"]').textContent.trim()).toBe(
      '$2.200',
    );
  });

  it('opens the edit modal with all the product data', () => {
    const editButton = fixture.nativeElement.querySelector('.edit-button') as HTMLButtonElement;
    editButton.click();
    fixture.detectChanges();

    const modal = fixture.nativeElement.querySelector('.edit-modal');
    const nameInput = fixture.nativeElement.querySelector(
      'input[formControlName="nombre"]',
    ) as HTMLInputElement;
    const barcodeInput = fixture.nativeElement.querySelector(
      'input[formControlName="codigo_barras"]',
    ) as HTMLInputElement;
    const purchasePriceInput = fixture.nativeElement.querySelector(
      'input[formControlName="precio_compra"]',
    ) as HTMLInputElement;

    expect(modal).toBeTruthy();
    expect(nameInput.value).toBe('Café americano');
    expect(barcodeInput.value).toBe('7800000000007');
    expect(purchasePriceInput.value).toBe('1200');
  });

  it('filters products by name without requiring matching accents', () => {
    const searchInput = fixture.nativeElement.querySelector(
      'input[aria-label="Buscar productos"]',
    ) as HTMLInputElement;
    searchInput.value = 'te verde';
    searchInput.dispatchEvent(new Event('input'));
    fixture.detectChanges();

    const rows = fixture.nativeElement.querySelectorAll('.product-table tbody tr');
    expect(rows).toHaveLength(1);
    expect(rows[0].textContent).toContain('Té verde');
    expect(rows[0].textContent).not.toContain('Café americano');
  });

  it('filters products by their displayed barcode', () => {
    const searchInput = fixture.nativeElement.querySelector(
      'input[aria-label="Buscar productos"]',
    ) as HTMLInputElement;
    searchInput.value = '7800000000012';
    searchInput.dispatchEvent(new Event('input'));
    fixture.detectChanges();

    const rows = fixture.nativeElement.querySelectorAll('.product-table tbody tr');
    expect(rows).toHaveLength(1);
    expect(rows[0].textContent).toContain('Té verde');
    expect(rows[0].textContent).toContain('7800000000012');
  });

  it('opens an empty form when clicking Nuevo producto', () => {
    (fixture.nativeElement.querySelector('.primary-button') as HTMLButtonElement).click();
    fixture.detectChanges();

    const modal = fixture.nativeElement.querySelector('.product-modal');
    const title = fixture.nativeElement.querySelector('#product-form-title');
    const nameInput = fixture.nativeElement.querySelector(
      'input[formControlName="nombre"]',
    ) as HTMLInputElement;

    expect(modal).toBeTruthy();
    expect(title.textContent).toContain('Crear producto');
    expect(nameInput.value).toBe('');
    expect(fixture.nativeElement.querySelector('.readonly-grid')).toBeNull();
  });

  it('creates a product and adds it to the table after saving', () => {
    (fixture.nativeElement.querySelector('.primary-button') as HTMLButtonElement).click();
    fixture.detectChanges();

    const nameInput = fixture.nativeElement.querySelector(
      'input[formControlName="nombre"]',
    ) as HTMLInputElement;
    const priceInput = fixture.nativeElement.querySelector(
      'input[formControlName="precio_venta"]',
    ) as HTMLInputElement;
    nameInput.value = 'Té chai';
    nameInput.dispatchEvent(new Event('input'));
    priceInput.value = '2800';
    priceInput.dispatchEvent(new Event('input'));

    (fixture.nativeElement.querySelector('.product-modal form') as HTMLFormElement).dispatchEvent(
      new Event('submit'),
    );
    fixture.detectChanges();

    expect(createdProduct?.nombre).toBe('Té chai');
    expect(createdProduct?.precio_compra).toBeNull();
    expect(createdProduct?.precio_venta).toBe(2800);
    expect(fixture.nativeElement.querySelector('.product-modal')).toBeNull();
    expect(fixture.nativeElement.textContent).toContain('Té chai');
    expect(fixture.nativeElement.querySelector('.success-toast').textContent).toContain('creado');
  });

  it('updates the product and refreshes the row after saving', () => {
    (fixture.nativeElement.querySelector('.edit-button') as HTMLButtonElement).click();
    fixture.detectChanges();

    const nameInput = fixture.nativeElement.querySelector(
      'input[formControlName="nombre"]',
    ) as HTMLInputElement;
    nameInput.value = 'Café americano grande';
    nameInput.dispatchEvent(new Event('input'));
    const purchasePriceInput = fixture.nativeElement.querySelector(
      'input[formControlName="precio_compra"]',
    ) as HTMLInputElement;
    purchasePriceInput.value = '1400';
    purchasePriceInput.dispatchEvent(new Event('input'));

    (fixture.nativeElement.querySelector('.edit-modal form') as HTMLFormElement).dispatchEvent(
      new Event('submit'),
    );
    fixture.detectChanges();

    expect(updatedProduct?.nombre).toBe('Café americano grande');
    expect(updatedProduct?.precio_compra).toBe(1400);
    expect(fixture.nativeElement.querySelector('.edit-modal')).toBeNull();
    expect(
      fixture.nativeElement.querySelector('[data-label="Precio de compra"]').textContent.trim(),
    ).toBe('$1.400');
    expect(fixture.nativeElement.querySelector('.product-name').textContent).toContain(
      'Café americano grande',
    );
    expect(fixture.nativeElement.querySelector('.success-toast')).toBeTruthy();
  });

  it('hides and shows a product in the catalog using the eye button', () => {
    let visibilityButton = fixture.nativeElement.querySelector(
      '.visibility-button',
    ) as HTMLButtonElement;

    expect(visibilityButton.getAttribute('aria-label')).toContain('Ocultar Café americano');
    visibilityButton.click();
    fixture.detectChanges();

    expect(updatedStatus).toEqual({ id: product.id, activo: false });
    expect(component['products']()[0].activo).toBe(false);
    expect(fixture.nativeElement.querySelector('.status').textContent).toContain('Inactivo');
    expect(fixture.nativeElement.querySelector('.success-toast').textContent).toContain('oculto');
    visibilityButton = fixture.nativeElement.querySelector(
      '.visibility-button',
    ) as HTMLButtonElement;
    expect(visibilityButton.getAttribute('aria-label')).toContain('Mostrar Café americano');

    visibilityButton.click();
    fixture.detectChanges();

    expect(updatedStatus).toEqual({ id: product.id, activo: true });
    expect(component['products']()[0].activo).toBe(true);
    expect(fixture.nativeElement.querySelector('.status').textContent).toContain('Activo');
    expect(fixture.nativeElement.querySelector('.success-toast').textContent).toContain('visible');
  });

  it('asks for confirmation and removes the product using the trash button', () => {
    const deleteButton = fixture.nativeElement.querySelector('.delete-button') as HTMLButtonElement;
    deleteButton.click();
    fixture.detectChanges();

    expect(fixture.nativeElement.querySelector('.delete-modal')).toBeTruthy();
    expect(
      fixture.nativeElement.querySelector('#delete-product-description').textContent,
    ).toContain('Café americano');
    expect(deletedProductId).toBeNull();

    (fixture.nativeElement.querySelector('.confirm-delete-button') as HTMLButtonElement).click();
    fixture.detectChanges();

    expect(deletedProductId).toBe(product.id);
    expect(component['products']().map((current) => current.id)).not.toContain(product.id);
    expect(fixture.nativeElement.querySelector('.delete-modal')).toBeNull();
    expect(fixture.nativeElement.querySelector('.success-toast').textContent).toContain(
      'eliminado',
    );
  });

  it('does not save a repeated name or barcode ignoring case and spaces (H3.3 T05)', () => {
    (fixture.nativeElement.querySelector('.edit-button') as HTMLButtonElement).click();
    fixture.detectChanges();
    const escribir = (control: string, valor: string) => {
      const input = fixture.nativeElement.querySelector(
        `input[formControlName="${control}"]`,
      ) as HTMLInputElement;
      input.value = valor;
      input.dispatchEvent(new Event('input'));
    };
    const enviar = () => {
      (fixture.nativeElement.querySelector('.edit-modal form') as HTMLFormElement).dispatchEvent(
        new Event('submit'),
      );
      fixture.detectChanges();
    };

    // Editando "Café americano": "  TÉ   VERDE " y " 7800000000012 " son del otro producto.
    escribir('nombre', '  TÉ   VERDE ');
    escribir('codigo_barras', ' 78000 00000012 ');
    enviar();
    const modal = fixture.nativeElement.querySelector('.edit-modal').textContent as string;
    expect(updatedProduct).toBeNull();
    expect(modal).toContain('Ya existe un producto con ese nombre.');
    expect(modal).toContain('Ya existe un producto con ese código de barras.');

    // Su propio nombre con otros espacios sí se puede guardar, y se guarda limpio.
    escribir('nombre', ' café   AMERICANO ');
    escribir('codigo_barras', '7800 000000007');
    enviar();
    expect(updatedProduct).toEqual(
      expect.objectContaining({ nombre: 'café AMERICANO', codigo_barras: '7800000000007' }),
    );
  });

  it('does not save an invalid price', () => {
    (fixture.nativeElement.querySelector('.edit-button') as HTMLButtonElement).click();
    fixture.detectChanges();

    const priceInput = fixture.nativeElement.querySelector(
      'input[formControlName="precio_venta"]',
    ) as HTMLInputElement;
    priceInput.value = '0';
    priceInput.dispatchEvent(new Event('input'));

    (fixture.nativeElement.querySelector('.edit-modal form') as HTMLFormElement).dispatchEvent(
      new Event('submit'),
    );
    fixture.detectChanges();

    expect(updatedProduct).toBeNull();
    expect(fixture.nativeElement.querySelector('.edit-modal')).toBeTruthy();
    expect(fixture.nativeElement.querySelector('.form-field small').textContent).toContain(
      'precio',
    );
  });

  it('shows the utility amount and percentage for a product with a registered purchase price', () => {
    expect(component['utilidadClp'](product)).toBe(1000);
    expect(component['utilidadPorcentaje'](product)).toBeCloseTo((1000 / 2200) * 100);

    const rows = fixture.nativeElement.querySelectorAll('.product-table tbody tr');
    const firstRowUtility = rows[0].querySelector('.product-utility');
    expect(firstRowUtility.textContent).toContain('1.000');
    expect(firstRowUtility.querySelector('.negative')).toBeNull();
  });

  it('shows a placeholder when a product has no registered purchase price', () => {
    expect(component['utilidadClp'](secondProduct)).toBeNull();
    expect(component['utilidadPorcentaje'](secondProduct)).toBeNull();

    const rows = fixture.nativeElement.querySelectorAll('.product-table tbody tr');
    const secondRowUtility = rows[1].querySelector('.product-utility');
    expect(secondRowUtility.textContent).toContain('—');
  });

  it('does not offer a recipe for products that have a barcode (simple resale items)', () => {
    expect(component['puedeTenerReceta'](product)).toBe(false);
    expect(component['puedeTenerReceta']({ ...product, codigo_barras: '   ' })).toBe(true);
    expect(component['puedeTenerReceta']({ ...product, codigo_barras: null })).toBe(true);
    expect(component['puedeTenerReceta']({ ...product, codigo_barras: '' })).toBe(true);

    const recipeButtons = fixture.nativeElement.querySelectorAll('button[aria-label^="Receta de"]');
    expect(recipeButtons.length).toBe(0);
  });

  it('filters products by category', () => {
    const categorySelect = fixture.nativeElement.querySelector(
      'select[aria-label="Filtrar por categoría"]',
    ) as HTMLSelectElement;

    categorySelect.value = 'Pastelería';
    categorySelect.dispatchEvent(new Event('change'));
    fixture.detectChanges();

    const rows = fixture.nativeElement.querySelectorAll('.product-table tbody tr');
    expect(rows).toHaveLength(1);
    expect(rows[0].textContent).toContain('Té verde');
    expect(rows[0].textContent).not.toContain('Café americano');
  });

  it('filters products by status', () => {
    const visibilityButton = fixture.nativeElement.querySelector(
      '.visibility-button',
    ) as HTMLButtonElement;
    visibilityButton.click();
    fixture.detectChanges();

    const statusSelect = fixture.nativeElement.querySelector(
      'select[aria-label="Filtrar por estado"]',
    ) as HTMLSelectElement;
    statusSelect.value = 'inactivos';
    statusSelect.dispatchEvent(new Event('change'));
    fixture.detectChanges();

    const rows = fixture.nativeElement.querySelectorAll('.product-table tbody tr');
    expect(rows).toHaveLength(1);
    expect(rows[0].textContent).toContain('Café americano');
    expect(rows[0].textContent).not.toContain('Té verde');
  });

  describe('Productos / Ingredientes tabs', () => {
    const host = () => fixture.nativeElement as HTMLElement;
    const pestanas = () =>
      Array.from(host().querySelectorAll('[role="tab"]')).map((tab) => tab.textContent?.trim());

    it('shows both tabs to the admin and opens Ingredientes', () => {
      expect(pestanas()).toEqual(['Productos', 'Ingredientes']);
      expect(host().querySelector('#tab-productos')?.getAttribute('aria-selected')).toBe('true');

      (host().querySelector('#tab-ingredientes') as HTMLButtonElement).click();
      fixture.detectChanges();

      expect(host().querySelector('app-ingredientes-maestro')).not.toBeNull();
      expect(host().querySelector('.product-table')).toBeNull();
      // "Nuevo producto" solo tiene sentido en la pestaña Productos.
      expect(host().textContent).not.toContain('Nuevo producto');
    });

    it('lets the storekeeper see products without editing them, and manage ingredients', () => {
      rol.set('bodeguero');
      fixture.detectChanges();

      expect(pestanas()).toEqual(['Productos', 'Ingredientes']);
      expect(host().querySelectorAll('.product-table tbody tr').length).toBeGreaterThan(0);
      expect(host().querySelector('.edit-button')).toBeNull();
      expect(host().querySelector('.visibility-button')).toBeNull();
      expect(host().querySelector('.delete-button')).toBeNull();
      expect(host().textContent).not.toContain('Nuevo producto');
    });

    it('keeps the cashier on products only, without tabs', () => {
      rol.set('cajero');
      fixture.detectChanges();

      expect(pestanas()).toEqual([]);
      expect(host().querySelector('app-ingredientes-maestro')).toBeNull();
    });
  });
});
