import { inject, Injectable, computed, effect, signal, untracked } from '@angular/core';
import {
  Observable,
  catchError,
  defer,
  finalize,
  map,
  of,
  shareReplay,
  switchMap,
  tap,
  throwError,
  timeout,
} from 'rxjs';
import {
  CartItem,
  CompletedSale,
  PaymentMethod,
  PosCategory,
  PosProduct,
} from '../models/pos.model';
import { resolvePosIcon } from '../models/pos-icons';
import { LoadStatus } from '../../../shared/components/coffee-loader/coffee-loader';
import { ProductosApiService, ProductoApi } from '../../../core/api/productos-api.service';
import { RegistrarVentaPayload, VentasApiService } from '../../../core/api/ventas-api.service';
import { nuevaClaveUnica } from '../../../shared/utils/clave-unica';
import { TurnosApiService, TurnoApi, VentaTurnoApi } from '../../../core/api/turnos-api.service';
import { EmpleadoApi, UsuariosApiService } from '../../../core/api/usuarios-api.service';
import { AuthService } from '../../auth/services/auth.service';

const TURNO_STORAGE_KEY = 'nury_turno';

/** Descuento fijo de la venta a empleado (H2.12). Por ahora no es editable. */
export const DESCUENTO_EMPLEADO_PORCENTAJE = 30;

// Turno guardado junto a la sesión (sessionStorage) para que una recarga o
// volver a entrar a la URL no lo pierda mientras la caja siga sin cerrarse.
// La caché conserva detalles locales; Caja y POS comprueban el estado real
// con fn_recuperar_turno al entrar, también cuando la caché ya no existe.
interface StoredTurno {
  usuarioId: number;
  turno: TurnoApi | null;
  ventas: CompletedSale[];
  anuladas: VentaAnulada[];
}

@Injectable({
  providedIn: 'root',
})
export class PosService {

  private readonly productosApi = inject(ProductosApiService);
  private readonly ventasApi = inject(VentasApiService);
  private readonly turnosApi = inject(TurnosApiService);
  private readonly usuariosApi = inject(UsuariosApiService);
  private readonly authService = inject(AuthService);
  private revisionTurno = 0;
  private recuperacionEnCurso?: Observable<TurnoApi | null>;
  private identidadTurno: string;

  constructor() {
    this.restoreTurno();
    this.identidadTurno = this.identidadActual();
    effect(() => {
      const actual = this.identidadActual();
      untracked(() => this.alinearSesion(actual));
    });
  }

  private alinearSesion(identidad: string): void {
    if (identidad === this.identidadTurno) return;
    this.identidadTurno = identidad;
    this.revisionTurno++;
    this.recuperacionEnCurso = undefined;
    this.turnoActivo.set(null);
    this.resetSalesHistory();
    this.clearCart();
    this.sincronizandoTurno.set(false);
    this.errorSincronizarTurno.set(null);
  }

  private identidadActual(): string {
    const usuario = this.authService.currentUser();
    return `${usuario?.id ?? ''}:${usuario?.sucursalId ?? ''}`;
  }

  /** Última venta enviada sin confirmar, con su clave única (H2.5 T05). */
  private ventaPendiente: { firma: string; clave: string } | null = null;

  // Arranca en "loading": el catálogo aún no se ha pedido a la API.
  readonly catalogStatus = signal<LoadStatus>('loading');

  cargarCatalogoDesdeApi(): void {
    this.catalogStatus.set('loading');
    this.productosApi
      .listar()
      // Con la conexión caída o colgada, se corta a los 15s para ofrecer reintentar.
      .pipe(timeout(15000))
      .subscribe({
        next: (productos) => {
          this.catalog.set(productos.map((producto) => this.adaptarProducto(producto)));
          this.catalogStatus.set('ready');
        },
        error: (error) => {
          console.error('No se pudo cargar el catálogo desde PostgREST', error);
          this.catalogStatus.set('error');
        },
      });
  }

  private adaptarProducto(producto: ProductoApi): PosProduct {
    const categoriaNombre = producto.categoria?.trim() || 'Sin categoría';

    return {
      id: producto.id,
      nombre: producto.nombre,
      categoriaId: categoriaNombre,
      categoriaNombre,
      codigoInterno: `NUR-${String(producto.id).padStart(3, '0')}`,
      codigoBarras: producto.codigo_barras ?? '',
      precioVenta: Number(producto.precio_venta),
      icono: resolvePosIcon(categoriaNombre, producto.nombre),
      descripcion: '',
      activo: producto.activo,
    };
  }


  // Se carga exclusivamente desde ProductosApiService.
  readonly catalog = signal<PosProduct[]>([]);

  /**
   * Relaciona cada categoría de la base con la pestaña del POS donde se muestra.
   * Las categorías que comparten palabra inicial se unifican bajo esa palabra
   * ("ALIMENTOS - EMPANADAS" y "ALIMENTOS - SANDWICH" → "ALIMENTOS";
   * "EMPANADA POLLO" y "EMPANADAS" → "EMPANADA") para que el filtro no crezca
   * con cada subcategoría. Las que no comparten palabra conservan su nombre,
   * sin segmentos repetidos ("HELADOS - HELADOS" → "HELADOS").
   */
  readonly categoryGroups = computed<Map<string, string>>(() => {
    const names = [...new Set(this.catalog().map((product) => product.categoriaNombre))]
      .sort((a, b) => a.localeCompare(b, 'es', { sensitivity: 'base' }));

    const byLeadingWord = new Map<string, string[]>();
    for (const name of names) {
      const key = this.leadingWordKey(name);
      byLeadingWord.set(key, [...(byLeadingWord.get(key) ?? []), name]);
    }

    const groups = new Map<string, string>();
    for (const members of byLeadingWord.values()) {
      const groupName =
        members.length > 1 ? this.leadingWord(members[0]) : this.withoutRepeatedSegments(members[0]);
      members.forEach((name) => groups.set(name, groupName));
    }
    return groups;
  });

  readonly categories = computed<PosCategory[]>(() => {
    const groupNames = [...new Set(this.categoryGroups().values())]
      .sort((a, b) => a.localeCompare(b, 'es', { sensitivity: 'base' }));
    return [
      { id: '', nombre: 'Todos', icono: '✨' },
      ...groupNames.map((nombre) => ({ id: nombre, nombre, icono: '🛍️' })),
    ];
  });

  /** Id de la pestaña del POS a la que pertenece el producto. */
  categoryGroupOf(product: PosProduct): string {
    return this.categoryGroups().get(product.categoriaNombre) ?? product.categoriaNombre;
  }

  private leadingWord(name: string): string {
    return name.trim().split(/[\s\-–—/,.]+/)[0] || name.trim();
  }

  // "HELADOS - HELADOS" → "HELADOS"; "ALIMENTOS - PIZZA" queda igual.
  private withoutRepeatedSegments(name: string): string {
    const segments = name.split(' - ').map((segment) => segment.trim()).filter(Boolean);
    const unique = segments.filter(
      (segment, index) =>
        segments.findIndex((other) => this.comparable(other) === this.comparable(segment)) === index,
    );
    return unique.join(' - ') || name.trim();
  }

  private comparable(text: string): string {
    return text
      .normalize('NFD')
      .replace(/[̀-ͯ]/g, '')
      .toUpperCase();
  }

  // Ignora mayúsculas, tildes y el plural simple para que "Empanada" y "EMPANADAS" coincidan.
  private leadingWordKey(name: string): string {
    const word = this.comparable(this.leadingWord(name));
    // "EMPANADAS"→"EMPANADA", "PASTELES"→"PASTEL" (y "PASTEL" queda igual).
    return word.length > 3 ? word.replace(/S$/, '').replace(/E$/, '') : word;
  }

  // Carrito de compras reactivo
  readonly cart = signal<CartItem[]>([]);

  // Suma de los productos, antes de cualquier descuento.
  readonly subtotal = computed(() =>
    this.cart().reduce((sum, item) => sum + item.subtotal, 0)
  );

  // Venta a empleado (H2.12): 30% sobre el total, redondeado a pesos.
  // El servidor (fn_registrar_venta) vuelve a calcularlo con la misma regla.
  readonly ventaEmpleado = signal(false);
  readonly empleadoSeleccionado = signal<EmpleadoApi | null>(null);
  readonly empleados = signal<EmpleadoApi[]>([]);
  readonly empleadosStatus = signal<'idle' | LoadStatus>('idle');

  readonly descuento = computed(() =>
    this.ventaEmpleado()
      ? Math.round((this.subtotal() * DESCUENTO_EMPLEADO_PORCENTAJE) / 100)
      : 0
  );

  // Total a pagar.
  readonly total = computed(() => this.subtotal() - this.descuento());

  // Venta a empleado marcada pero sin elegir quién compra: no se puede cobrar.
  readonly faltaEmpleado = computed(() => this.ventaEmpleado() && !this.empleadoSeleccionado());

  readonly totalItemsCount = computed(() =>
    this.cart().reduce((sum, item) => sum + item.cantidad, 0)
  );

  // Historial de ventas del turno activo
  readonly salesHistory = signal<CompletedSale[]>([]);

  // Estado de apertura de caja (compartido entre POS y Cierre de Caja).
  // Arranca cerrada: el turno debe iniciarse explícitamente desde "Caja"
  // (botón "Iniciar Turno"), nunca automáticamente al iniciar sesión.
  // El turno real vive en PostgreSQL (tabla `turnos`, vía fn_abrir_turno /
  // fn_cerrar_turno) — este signal es la copia local del turno activo, no
  // una fuente de verdad independiente. Se restaura desde sessionStorage
  // (ver restoreTurno) para que un refresh de página no lo pierda de vista.
  readonly turnoActivo = signal<TurnoApi | null>(null);
  readonly sincronizandoTurno = signal(false);
  readonly errorSincronizarTurno = signal<string | null>(null);
  readonly isRegisterOpen = computed(() => this.turnoActivo() !== null &&
    !this.sincronizandoTurno() && this.errorSincronizarTurno() === null);
  readonly requiereCierreTurno = computed(() => this.turnoActivo() !== null ||
    this.sincronizandoTurno() || this.errorSincronizarTurno() !== null);

  /** La base confirma el turno y reconstruye su historial aunque se haya perdido la caché. */
  sincronizarTurno(): Observable<TurnoApi | null> {
    this.alinearSesion(this.identidadActual());
    if (this.recuperacionEnCurso) return this.recuperacionEnCurso;
    const usuario = this.authService.currentUser();
    if (!usuario || usuario.sucursalId == null) {
      this.turnoActivo.set(null);
      this.resetSalesHistory();
      this.sincronizandoTurno.set(false);
      this.errorSincronizarTurno.set(null);
      return of(null);
    }

    const identidad = this.identidadActual();
    const revision = ++this.revisionTurno;
    const sigueVigente = () => revision === this.revisionTurno && identidad === this.identidadActual();
    this.sincronizandoTurno.set(true);
    this.errorSincronizarTurno.set(null);
    const request = this.turnosApi.recuperar().pipe(
      timeout(15000),
      map(({ turno, ventas }) => {
        if (!sigueVigente()) return null;
        if (turno && (turno.usuario_id !== usuario.id || turno.sucursal_id !== usuario.sucursalId || turno.hora_fin !== null)) {
          throw new Error('El turno recibido no corresponde a tu sesión activa.');
        }
        const cache = new Map([
          ...this.salesHistory(), ...this.anuladasTurno().map((anulada) => anulada.venta),
        ].map((venta) => [venta.id, venta]));
        const vigentes = turno ? ventas.filter((venta) => !venta.anulada)
          .map((venta) => this.adaptarVentaRecuperada(venta, cache.get(venta.id))) : [];
        const anuladas = turno ? ventas.filter((venta) => venta.anulada).map((venta) => ({
          venta: this.adaptarVentaRecuperada(venta, cache.get(venta.id)),
          anuladaEn: fechaServidor(venta.anulada_en ?? venta.fecha_venta),
          motivo: venta.anulada_motivo ?? '',
        })) : [];
        if (this.turnoActivo()?.id !== turno?.id) this.clearCart();
        this.turnoActivo.set(turno);
        this.salesHistory.set(vigentes);
        this.anuladasTurno.set(anuladas);
        this.persistTurno();
        return turno;
      }),
      catchError((error: unknown) => {
        if (sigueVigente()) this.errorSincronizarTurno.set(
          'No pudimos comprobar tu turno ni recuperar sus ventas. Revisa la conexión y reintenta.',
        );
        return throwError(() => error);
      }),
      finalize(() => {
        if (revision === this.revisionTurno) {
          this.sincronizandoTurno.set(false);
          this.recuperacionEnCurso = undefined;
        }
      }),
      shareReplay({ bufferSize: 1, refCount: false }),
    );
    this.recuperacionEnCurso = request;
    return request;
  }

  private adaptarVentaRecuperada(venta: VentaTurnoApi, cache?: CompletedSale): CompletedSale {
    const usuario = this.authService.currentUser();
    if (!['efectivo', 'credito', 'debito', 'sodexo', 'edenred'].includes(venta.medio_pago ?? '')) {
      throw new Error('El turno contiene un medio de pago que no se puede cuadrar en esta pantalla.');
    }
    return {
      ...cache,
      id: venta.id,
      // Venta a empleado (H2.12): conserva su código, tipo y descuento. El nombre
      // del empleado solo está en la copia local (cache), si existe.
      ticketFolio: venta.codigo_venta ?? `TK-${venta.id}`,
      tipoVenta: venta.tipo_venta ?? 'normal',
      descuento: Number(venta.descuento_monto ?? 0),
      subtotal: Number(venta.total) + Number(venta.descuento_monto ?? 0),
      fecha: fechaServidor(venta.fecha_venta),
      cajeroNombre: usuario?.nombre ?? '',
      sucursalNombre: usuario?.sucursalNombre ?? '',
      medioPago: venta.medio_pago as PaymentMethod,
      total: Number(venta.total),
      montoRecibido: cache?.montoRecibido ?? Number(venta.total),
      vuelto: cache?.vuelto ?? 0,
      items: venta.detalle_venta.map((detalle) => {
        if (!detalle.productos) throw new Error('No se pudo recuperar el detalle completo de una venta.');
        return {
          producto: this.adaptarProducto({ ...detalle.productos, precio_venta: detalle.precio_unitario }),
          cantidad: Number(detalle.cantidad), subtotal: Number(detalle.subtotal),
        };
      }),
    };
  }

  /**
   * Abre turno contra el backend. Rechaza (HTTP 4xx con mensaje de
   * fn_abrir_turno en el body) si el cajero ya tiene un turno activo en esa
   * sucursal — ese caso lo maneja el componente que llama a este método.
   */
  abrirTurno(usuarioId: number, sucursalId: number, montoInicial: number): Observable<TurnoApi> {
    this.alinearSesion(this.identidadActual());
    return this.turnosApi.abrir(usuarioId, sucursalId, montoInicial).pipe(
      timeout(15000),
      tap((turno) => {
        this.revisionTurno++;
        this.errorSincronizarTurno.set(null);
        this.sincronizandoTurno.set(false);
        this.recuperacionEnCurso = undefined;
        this.resetSalesHistory();
        this.turnoActivo.set(turno);
        this.persistTurno();
      }),
    );
  }

  /** Cierra el turno activo contra el backend. No hace nada si ya no hay turno activo. */
  cerrarTurnoActivo(): Observable<TurnoApi> {
    const turno = this.turnoActivo();
    if (!turno) {
      return throwError(() => new Error('No hay un turno activo para cerrar.'));
    }

    return this.turnosApi.cerrar(turno.id).pipe(
      timeout(15000),
      tap(() => {
        this.revisionTurno++;
        this.recuperacionEnCurso = undefined;
        this.sincronizandoTurno.set(false);
        this.errorSincronizarTurno.set(null);
        this.turnoActivo.set(null);
        this.persistTurno();
      }),
    );
  }

  addToCart(product: PosProduct): void {
    const current = this.cart();
    const existingIndex = current.findIndex((i) => i.producto.id === product.id);

    if (existingIndex > -1) {
      const updated = [...current];
      const existing = updated[existingIndex];
      const newQty = existing.cantidad + 1;
      updated[existingIndex] = {
        ...existing,
        cantidad: newQty,
        subtotal: newQty * product.precioVenta,
      };
      this.cart.set(updated);
    } else {
      this.cart.set([
        ...current,
        {
          producto: product,
          cantidad: 1,
          subtotal: product.precioVenta,
        },
      ]);
    }
  }

  addByCode(code: string): boolean {
    const normalized = code.trim().toLowerCase();
    const found = this.catalog().find(
      (p) =>
        p.codigoInterno.toLowerCase() === normalized ||
        p.codigoBarras === normalized
    );

    if (found) {
      this.addToCart(found);
      return true;
    }
    return false;
  }

  updateQuantity(productId: number, delta: number): void {
    const current = this.cart();
    const updated = current
      .map((item) => {
        if (item.producto.id === productId) {
          const newQty = item.cantidad + delta;
          if (newQty <= 0) return null;
          return {
            ...item,
            cantidad: newQty,
            subtotal: newQty * item.producto.precioVenta,
          };
        }
        return item;
      })
      .filter((i): i is CartItem => i !== null);

    this.cart.set(updated);
  }

  removeFromCart(productId: number): void {
    this.cart.set(this.cart().filter((i) => i.producto.id !== productId));
  }

  clearCart(): void {
    this.cart.set([]);
    // Cada venta parte como normal: el cajero marca de nuevo si es a empleado.
    this.setVentaEmpleado(false);
  }

  setVentaEmpleado(activa: boolean): void {
    this.ventaEmpleado.set(activa);
    if (!activa) {
      this.empleadoSeleccionado.set(null);
      return;
    }
    if (this.empleadosStatus() !== 'ready' && this.empleadosStatus() !== 'loading') {
      this.cargarEmpleados();
    }
  }

  seleccionarEmpleado(empleadoId: number | null): void {
    this.empleadoSeleccionado.set(this.empleados().find((e) => e.id === empleadoId) ?? null);
  }

  cargarEmpleados(): void {
    this.empleadosStatus.set('loading');
    this.usuariosApi
      .listarEmpleados()
      .pipe(timeout(15000))
      .subscribe({
        next: (empleados) => {
          this.empleados.set(empleados);
          this.empleadosStatus.set('ready');
        },
        error: (error) => {
          console.error('No se pudo cargar la lista de empleados', error);
          this.empleadosStatus.set('error');
        },
      });
  }

  /**
   * Registra la venta contra PostgREST (fn_registrar_venta) y, solo si la
   * base confirma que quedó guardada, arma el ticket y actualiza el
   * historial local. Si falla, el carrito NO se vacía, para que el cajero
   * pueda reintentar sin perder lo que ya había cobrado.
   */
  completeSale(
    medioPago: PaymentMethod,
    montoRecibido: number,
    cajero: { id: number; nombre: string },
    sucursal: { id: number; nombre: string },
    extraDetails?: {
      codigoAutorizacion?: string;
      titularJunaeb?: string;
      saldoRestanteJunaeb?: number;
    }
  ): Observable<CompletedSale> {
    const items = this.cart();
    const subtotalVenta = this.subtotal();
    const descuentoVenta = this.descuento();
    const totalVenta = this.total();
    const vuelto = Math.max(0, montoRecibido - totalVenta);
    const empleado = this.ventaEmpleado() ? this.empleadoSeleccionado() : null;

    if (this.faltaEmpleado()) {
      return throwError(() => new Error('Selecciona el empleado que compra.'));
    }

    const venta: Omit<RegistrarVentaPayload, 'p_clave'> = {
      p_sucursal_id: sucursal.id,
      p_cajero_id: cajero.id,
      p_medio_pago: medioPago,
      p_items: items.map((item) => ({
        producto: item.producto.nombre,
        cantidad: item.cantidad,
        precio_unitario: item.producto.precioVenta,
      })),
      ...(empleado ? { p_tipo_venta: 'empleado' as const, p_empleado_id: empleado.id } : {}),
    };

    return this.ventasApi
      .registrar({ ...venta, p_clave: this.claveParaVenta(venta) })
      .pipe(
        // Si PostgREST no responde en 15s (backend caído, colgado o sin red),
        // cortamos la espera acá para no dejar al cajero atrapado en "Guardando venta...".
        timeout(15000),
        map((ventaId): CompletedSale => ({
          id: ventaId,
          // Mismo código que guarda la base (ventas.codigo_venta).
          ticketFolio: `${empleado ? 'EMP' : 'TK'}-${ventaId}`,
          fecha: new Date(),
          cajeroNombre: cajero.nombre,
          sucursalNombre: sucursal.nombre,
          medioPago,
          total: totalVenta,
          tipoVenta: empleado ? 'empleado' : 'normal',
          subtotal: subtotalVenta,
          descuento: descuentoVenta,
          empleadoNombre: empleado?.nombre,
          montoRecibido,
          vuelto,
          items,
          codigoAutorizacion: extraDetails?.codigoAutorizacion,
          titularJunaeb: extraDetails?.titularJunaeb,
          saldoRestanteJunaeb: extraDetails?.saldoRestanteJunaeb,
        })),
        // H2.5 T04: la venta ya quedó registrada; se consulta qué quedó sin stock suficiente
        // solo para avisar. Si esta consulta falla o tarda, la venta sigue igual, sin aviso.
        switchMap((sale) =>
          defer(() => this.ventasApi.stockInsuficiente(sale.id)).pipe(
            timeout(5000),
            map(
              (filas): CompletedSale => ({
                ...sale,
                stockInsuficiente: filas.map((fila) => ({
                  nombre: fila.nombre,
                  unidad: fila.unidad,
                  requerido: Number(fila.requerido),
                  disponible: Number(fila.disponible),
                  faltante: Number(fila.faltante),
                })),
              }),
            ),
            catchError(() => of(sale)),
          ),
        ),
        tap((sale) => {
          // Venta confirmada: el próximo cobro es otra venta y lleva otra clave.
          this.ventaPendiente = null;
          this.salesHistory.set([sale, ...this.salesHistory()]);
          this.persistTurno();
          this.clearCart();
        }),
      );
  }

  /**
   * Clave única de la venta (H2.5 T05). Si el cobro anterior falló o no respondió y se
   * reintenta la MISMA venta (mismo carrito, medio de pago y cajero), se reutiliza la clave:
   * si la base ya la había guardado, devuelve esa venta sin descontar el inventario otra vez.
   * Cualquier cambio en la venta genera una clave nueva.
   */
  private claveParaVenta(venta: Omit<RegistrarVentaPayload, 'p_clave'>): string {
    const firma = JSON.stringify(venta);
    if (this.ventaPendiente?.firma !== firma) {
      this.ventaPendiente = { firma, clave: nuevaClaveUnica() };
    }
    return this.ventaPendiente.clave;
  }

  // Vacía el historial de ventas del turno tras un cierre de caja confirmado.
  resetSalesHistory(): void {
    this.salesHistory.set([]);
    this.anuladasTurno.set([]);
    this.persistTurno();
  }

  // Ventas del turno activo que fueron anuladas. Se sacan de salesHistory
  // para que el cuadre de caja deje de contarlas.
  readonly anuladasTurno = signal<VentaAnulada[]>([]);

  /** Solo se pueden anular ventas del turno activo (las que están en salesHistory). */
  anularVenta(ventaId: number, motivo: string): Observable<void> {
    const venta = this.salesHistory().find((sale) => sale.id === ventaId);
    if (!this.isRegisterOpen() || !venta) {
      return throwError(() => new Error('Solo se pueden anular ventas del turno activo.'));
    }

    return this.ventasApi.anular(ventaId, motivo).pipe(
      timeout(15000),
      tap(() => this.sincronizarAnulacion(ventaId, motivo)),
    );
  }

  /**
   * Refleja en el turno de esta pestaña una venta ya anulada en la base. Si la venta
   * no pertenece a este turno (por ejemplo, la anuló un admin desde el historial de
   * la sucursal), no hace nada.
   */
  sincronizarAnulacion(ventaId: number, motivo: string): void {
    const venta = this.salesHistory().find((sale) => sale.id === ventaId);
    if (!venta) {
      return;
    }
    this.salesHistory.set(this.salesHistory().filter((sale) => sale.id !== ventaId));
    this.anuladasTurno.set([{ venta, anuladaEn: new Date(), motivo }, ...this.anuladasTurno()]);
    this.persistTurno();
  }

  private persistTurno(): void {
    const usuarioId = this.authService.currentUser()?.id;
    if (usuarioId == null) {
      return;
    }

    try {
      if (!this.turnoActivo() && this.salesHistory().length === 0) {
        sessionStorage.removeItem(TURNO_STORAGE_KEY);
        return;
      }

      const stored: StoredTurno = {
        usuarioId,
        turno: this.turnoActivo(),
        ventas: this.salesHistory(),
        anuladas: this.anuladasTurno(),
      };
      sessionStorage.setItem(TURNO_STORAGE_KEY, JSON.stringify(stored));
    } catch {
      // Sin sessionStorage el turno sigue vivo en memoria; solo no sobrevive a un refresh.
    }
  }

  /** Recupera el turno de este cajero si la página se recargó sin cerrar caja. */
  private restoreTurno(): void {
    const usuarioId = this.authService.currentUser()?.id;
    if (usuarioId == null) {
      return;
    }

    try {
      const raw = sessionStorage.getItem(TURNO_STORAGE_KEY);
      if (!raw) {
        return;
      }

      const stored = JSON.parse(raw) as StoredTurno;
      // Un turno de otro usuario en esta pestaña no se hereda.
      if (stored.usuarioId !== usuarioId || stored.turno?.hora_fin != null ||
          (stored.turno && stored.turno.sucursal_id !== this.authService.currentUser()?.sucursalId)) {
        return;
      }

      // JSON guarda las fechas como texto; se reconstruyen para ordenar y mostrar.
      const reviveSale = (sale: CompletedSale): CompletedSale => ({
        ...sale,
        fecha: new Date(sale.fecha),
      });
      this.salesHistory.set((stored.ventas ?? []).map(reviveSale));
      this.anuladasTurno.set(
        (stored.anuladas ?? []).map((anulada) => ({
          ...anulada,
          venta: reviveSale(anulada.venta),
          anuladaEn: new Date(anulada.anuladaEn),
        })),
      );
      this.turnoActivo.set(stored.turno ?? null);
    } catch {
      sessionStorage.removeItem(TURNO_STORAGE_KEY);
    }
  }
}

export interface VentaAnulada {
  venta: CompletedSale;
  anuladaEn: Date;
  motivo: string;
}

function fechaServidor(valor: string): Date {
  return new Date(/[zZ]|[+-]\d{2}:?\d{2}$/.test(valor) ? valor : `${valor}Z`);
}
