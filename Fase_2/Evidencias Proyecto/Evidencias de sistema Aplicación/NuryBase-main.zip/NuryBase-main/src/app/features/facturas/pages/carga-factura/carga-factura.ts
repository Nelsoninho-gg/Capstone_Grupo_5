import {
  AfterViewInit,
  Component,
  computed,
  ElementRef,
  inject,
  OnInit,
  output,
  signal,
  ViewChild,
} from '@angular/core';
import { forkJoin } from 'rxjs';
import {
  ConsultaFacturaIngresada,
  FacturasApiService,
  LineaIngresoFactura,
  ResultadoIngresoFactura,
} from '../../../../core/api/facturas-api.service';
import { IngredientesApiService } from '../../../../core/api/ingredientes-api.service';
import { ProductosApiService } from '../../../../core/api/productos-api.service';
import { RecetasApiService } from '../../../../core/api/recetas-api.service';
import { SucursalesApiService } from '../../../../core/api/sucursales-api.service';
import { UnidadesMedidaApiService } from '../../../../core/api/unidades-medida-api.service';
import { AuthService } from '../../../auth/services/auth.service';
import {
  ArticuloCatalogo,
  armarCatalogo,
  AsociacionLinea,
  cantidadIngreso,
  contarPendientes,
  filtrarArticulos,
  leerEquivalencia,
  leerValorAsociacion,
  necesitaEquivalencia,
  PENDIENTE,
  valorAsociacion,
} from '../../models/asociacion-lineas';
import { FalloIngreso, falloYaIngresada, interpretarFalloIngreso } from '../../models/fallo-ingreso';
import { FacturaXml, leerFacturaXml, ResultadoLecturaXml } from '../../models/lector-dte';
import { permisoIngreso, PermisoIngreso, SucursalIngreso } from '../../models/permiso-ingreso';
import { indexarCatalogo, sugerirArticulo } from '../../models/sugerencia-articulo';

/** Tamaño máximo razonable para una factura: evita leer archivos que no son XML de factura. */
const TAMANO_MAXIMO_BYTES = 5 * 1024 * 1024;

const TEXTO_NO_INVENTARIO = 'No corresponde a inventario';

/** Opción de la lista de una línea; `valor` es el de `valorAsociacion`. */
interface OpcionAsociacion {
  valor: string;
  nombre: string;
  detalle: string;
}

type EstadoCarga =
  | { tipo: 'vacio' }
  | { tipo: 'leyendo'; nombre: string }
  /** `bytes` es el archivo tal cual llegó: el servidor lo vuelve a leer al confirmar. */
  | { tipo: 'listo'; nombre: string; resultado: ResultadoLecturaXml; bytes: Uint8Array }
  | { tipo: 'error'; nombre: string; mensaje: string };

/** Resultado de comprobar en el servidor si la factura ya fue ingresada (H3.7 T03/T06). */
type EstadoPrevio =
  | { tipo: 'inactivo' }
  | { tipo: 'consultando' }
  | { tipo: 'libre' }
  | { tipo: 'incompleta' }
  /** No se pudo preguntar: no bloquea, porque el servidor vuelve a comprobarlo al confirmar. */
  | { tipo: 'no-verificada' }
  | { tipo: 'ingresada'; consulta: ConsultaFacturaIngresada };

type EstadoConfirmacion =
  | { tipo: 'inactivo' }
  | { tipo: 'confirmando' }
  | { tipo: 'ingresada'; resultado: ResultadoIngresoFactura; sucursal: string; folio: number }
  | { tipo: 'error'; fallo: FalloIngreso };

type EstadoCatalogo =
  | { tipo: 'inactivo' }
  | { tipo: 'cargando' }
  | { tipo: 'listo'; ingredientes: ArticuloCatalogo[]; productos: ArticuloCatalogo[] }
  | { tipo: 'error' };

type EstadoDestino =
  | { tipo: 'cargando' }
  | { tipo: 'error' }
  | { tipo: 'sin-permiso'; motivo: string }
  | { tipo: 'listo'; fija: boolean; opciones: SucursalIngreso[] };

/**
 * Carga y previsualización de una factura XML (H3.1 T04) y asociación de sus
 * líneas con el catálogo (H3.1 T05), con la equivalencia de cada presentación
 * (H3.1 T06) y la sucursal que recibirá el stock (H3.1 T07). Nada se guarda hasta
 * confirmar (H3.1 T08): entonces `fn_ingresar_factura_xml` vuelve a leer el XML,
 * valida todo y guarda factura, líneas y stock en una sola transacción.
 */
@Component({
  selector: 'app-carga-factura',
  styleUrl: './carga-factura.css',
  templateUrl: './carga-factura.html',
})
export class CargaFactura implements OnInit, AfterViewInit {
  /** Se abre en un modal desde «Facturas ingresadas». */
  readonly cerrarModal = output<void>();
  /** Factura ingresada: la lista debe recargarse. */
  readonly ingresada = output<void>();

  @ViewChild('botonCerrar') private readonly botonCerrar?: ElementRef<HTMLButtonElement>;

  private readonly ingredientesApi = inject(IngredientesApiService);
  private readonly productosApi = inject(ProductosApiService);
  private readonly recetasApi = inject(RecetasApiService);
  private readonly sucursalesApi = inject(SucursalesApiService);
  private readonly unidadesApi = inject(UnidadesMedidaApiService);
  private readonly authService = inject(AuthService);
  private readonly facturasApi = inject(FacturasApiService);

  protected readonly confirmacion = signal<EstadoConfirmacion>({ tipo: 'inactivo' });
  protected readonly previa = signal<EstadoPrevio>({ tipo: 'inactivo' });

  /** Por qué todavía no se puede confirmar; null si está todo listo. */
  protected readonly faltaParaConfirmar = computed(() => {
    const estado = this.estado();
    if (estado.tipo !== 'listo' || !estado.resultado.valida) return 'Carga una factura válida.';
    const previa = this.previa();
    if (previa.tipo === 'consultando') return 'Comprobando si la factura ya fue ingresada…';
    if (previa.tipo === 'ingresada') return 'Esta factura ya fue ingresada.';
    if (previa.tipo === 'incompleta') return 'La factura no tiene identificación completa.';
    if (this.destino().tipo !== 'listo') return 'Tu usuario no puede ingresar facturas.';
    if (this.catalogo().tipo !== 'listo') return 'Espera a que cargue el catálogo.';
    if (this.sucursalElegida() === null) return 'Elige la sucursal que recibirá el stock.';
    const pendientes = this.pendientes();
    if (pendientes === 1) return 'Completa la línea pendiente.';
    if (pendientes > 1) return `Completa las ${pendientes} líneas pendientes.`;
    return null;
  });

  /** Qué sucursales puede usar el usuario; el admin las trae del servidor. */
  protected readonly destino = signal<EstadoDestino>({ tipo: 'cargando' });
  /** Sucursal que recibirá el stock. null = el admin todavía no la eligió. */
  protected readonly sucursalElegida = signal<number | null>(null);
  protected readonly sucursalNombre = computed(() => {
    const destino = this.destino();
    if (destino.tipo !== 'listo') return null;
    return destino.opciones.find((sucursal) => sucursal.id === this.sucursalElegida())?.nombre ?? null;
  });

  protected readonly estado = signal<EstadoCarga>({ tipo: 'vacio' });
  protected readonly catalogo = signal<EstadoCatalogo>({ tipo: 'inactivo' });
  protected readonly asociaciones = signal<ReadonlyMap<number, AsociacionLinea>>(new Map());
  /** Texto del buscador de cada línea, por número de línea. */
  protected readonly busquedas = signal<ReadonlyMap<number, string>>(new Map());
  /** Línea cuya lista de artículos está desplegada (una a la vez) y la opción resaltada. */
  protected readonly listaAbierta = signal<number | null>(null);
  protected readonly indiceActivo = signal(0);
  /** Equivalencia escrita en cada línea: unidades del catálogo por presentación. */
  protected readonly equivalencias = signal<ReadonlyMap<number, string>>(new Map());
  /** Líneas cuyo artículo propuso el sistema por la descripción y el usuario aún no cambió. */
  protected readonly sugeridas = signal<ReadonlySet<number>>(new Set());
  protected readonly tamanoMaximoMb = TAMANO_MAXIMO_BYTES / (1024 * 1024);

  protected readonly pendientes = computed(() => {
    const estado = this.estado();
    if (estado.tipo !== 'listo' || !estado.resultado.valida) return 0;
    const numeros = estado.resultado.factura.lineas.map((linea) => linea.numero_linea);
    return contarPendientes(numeros, this.asociaciones(), this.equivalencias());
  });

  /** Se arrastra un archivo sobre la zona de carga. */
  protected readonly arrastrando = signal(false);

  ngOnInit(): void {
    this.cargarDestino();
  }

  /** El foco entra al modal al abrirlo. */
  ngAfterViewInit(): void {
    this.botonCerrar?.nativeElement.focus();
  }

  /**
   * El admin necesita la lista de sucursales activas. Los demás roles usan la que
   * tienen asignada (y ni siquiera pueden listar sucursales en el servidor).
   */
  protected cargarDestino(): void {
    const usuario = this.authService.currentUser();

    if (usuario?.rol !== 'admin') {
      this.aplicarPermiso(permisoIngreso(usuario, []));
      return;
    }

    this.destino.set({ tipo: 'cargando' });
    this.sucursalesApi.listarActivas().subscribe({
      next: (sucursales) =>
        this.aplicarPermiso(
          permisoIngreso(
            usuario,
            sucursales.map(({ id, nombre }) => ({ id, nombre })),
          ),
        ),
      error: () => this.destino.set({ tipo: 'error' }),
    });
  }

  private aplicarPermiso(permiso: PermisoIngreso): void {
    if (!permiso.puede) {
      this.destino.set({ tipo: 'sin-permiso', motivo: permiso.motivo });
      this.sucursalElegida.set(null);
      return;
    }
    this.destino.set({ tipo: 'listo', fija: permiso.fija, opciones: permiso.opciones });
    // Conserva lo elegido si sigue disponible; si no, usa la sugerida.
    const vigente = permiso.opciones.some((sucursal) => sucursal.id === this.sucursalElegida());
    if (!vigente) this.sucursalElegida.set(permiso.porDefecto);
  }

  protected elegirSucursal(evento: Event): void {
    const valor = (evento.target as HTMLSelectElement).value;
    this.sucursalElegida.set(valor === '' ? null : Number(valor));
  }

  protected async alSeleccionar(evento: Event): Promise<void> {
    const input = evento.target as HTMLInputElement;
    const archivo = input.files?.item(0);
    // Permite elegir de nuevo el mismo archivo después de cancelar o reemplazar.
    input.value = '';
    if (archivo) await this.leerArchivo(archivo);
  }

  protected alArrastrar(evento: DragEvent, encima: boolean): void {
    evento.preventDefault();
    this.arrastrando.set(encima);
  }

  protected async alSoltar(evento: DragEvent): Promise<void> {
    evento.preventDefault();
    this.arrastrando.set(false);
    const archivo = evento.dataTransfer?.files.item(0);
    if (archivo) await this.leerArchivo(archivo);
  }

  private async leerArchivo(archivo: File): Promise<void> {
    this.confirmacion.set({ tipo: 'inactivo' });
    this.previa.set({ tipo: 'inactivo' });
    this.asociaciones.set(new Map());
    this.busquedas.set(new Map());
    this.listaAbierta.set(null);
    this.equivalencias.set(new Map());
    this.sugeridas.set(new Set());

    if (archivo.size > TAMANO_MAXIMO_BYTES) {
      this.estado.set({
        tipo: 'error',
        nombre: archivo.name,
        mensaje: `El archivo pesa más de ${this.tamanoMaximoMb} MB. Una factura XML es mucho más liviana: revisa que sea el archivo correcto.`,
      });
      return;
    }

    this.estado.set({ tipo: 'leyendo', nombre: archivo.name });
    try {
      const bytes = new Uint8Array(await archivo.arrayBuffer());
      const resultado = leerFacturaXml(bytes);
      const listo: EstadoCarga = { tipo: 'listo', nombre: archivo.name, resultado, bytes };
      this.estado.set(listo);
      if (resultado.valida) {
        if (this.catalogo().tipo === 'listo') this.sugerirArticulos();
        else this.cargarCatalogo();
        this.comprobarIngreso(resultado.factura, listo);
      }
    } catch {
      this.estado.set({
        tipo: 'error',
        nombre: archivo.name,
        mensaje: 'No pudimos leer el archivo. Revisa que no esté en uso y vuelve a intentarlo.',
      });
    }
  }

  /**
   * Pregunta al servidor si la factura ya fue ingresada, para avisar y bloquear antes de
   * confirmar. Si la respuesta llega cuando ya se cargó otro archivo, se descarta.
   */
  private comprobarIngreso(factura: FacturaXml, estado: EstadoCarga): void {
    this.previa.set({ tipo: 'consultando' });
    this.facturasApi.consultarIngresada(factura.rut_emisor, factura.tipo_documento, factura.folio).subscribe({
      next: (consulta) => {
        if (this.estado() !== estado) return;
        if (!consulta.identificacion_completa) this.previa.set({ tipo: 'incompleta' });
        else this.previa.set(consulta.ingresada ? { tipo: 'ingresada', consulta } : { tipo: 'libre' });
      },
      error: () => {
        if (this.estado() === estado) this.previa.set({ tipo: 'no-verificada' });
      },
    });
  }

  /** Fecha y hora como se muestran en Chile: 20-10-2026 15:32. */
  protected fechaHora(valor: string | undefined): string {
    if (!valor) return '';
    const fecha = new Date(valor);
    if (Number.isNaN(fecha.getTime())) return '';
    const dos = (n: number) => String(n).padStart(2, '0');
    return `${dos(fecha.getDate())}-${dos(fecha.getMonth() + 1)}-${fecha.getFullYear()} ${dos(fecha.getHours())}:${dos(fecha.getMinutes())}`;
  }

  /** «2 líneas sumaron stock y 1 no corresponde a inventario.» */
  protected resumenLineas(consulta: ConsultaFacturaIngresada): string {
    const inventario = consulta.lineas_inventario ?? 0;
    const otras = consulta.lineas_no_inventario ?? 0;
    const suman = inventario === 1 ? '1 línea sumó stock' : `${inventario} líneas sumaron stock`;
    const no = otras === 1 ? '1 no corresponde a inventario' : `${otras} no corresponden a inventario`;
    return otras > 0 ? `${suman} y ${no}.` : `${suman}.`;
  }

  protected cargarCatalogo(): void {
    this.catalogo.set({ tipo: 'cargando' });
    forkJoin([
      this.ingredientesApi.listar(),
      this.productosApi.listar(),
      this.recetasApi.listarIdsProductosConReceta(),
      this.unidadesApi.listar(),
    ]).subscribe({
      next: ([ingredientes, productos, idsConReceta, unidades]) => {
        this.catalogo.set({
          tipo: 'listo',
          ...armarCatalogo(ingredientes, productos, idsConReceta, unidades),
        });
        this.sugerirArticulos();
      },
      error: () => this.catalogo.set({ tipo: 'error' }),
    });
  }

  /**
   * Propone un artículo para cada línea aún pendiente según su descripción. No toca
   * lo que el usuario ya eligió; la equivalencia la sigue confirmando él.
   */
  private sugerirArticulos(): void {
    const estado = this.estado();
    const catalogo = this.catalogo();
    if (estado.tipo !== 'listo' || !estado.resultado.valida || catalogo.tipo !== 'listo') return;

    const indice = indexarCatalogo([...catalogo.ingredientes, ...catalogo.productos]);
    const asociaciones = new Map(this.asociaciones());
    const sugeridas = new Set(this.sugeridas());
    for (const linea of estado.resultado.factura.lineas) {
      if (this.asociacion(linea.numero_linea).tipo !== 'pendiente') continue;
      const articulo = sugerirArticulo(linea.descripcion, indice);
      if (!articulo) continue;
      asociaciones.set(linea.numero_linea, { tipo: articulo.tipo, id: articulo.id });
      sugeridas.add(linea.numero_linea);
    }
    this.asociaciones.set(asociaciones);
    this.sugeridas.set(sugeridas);
  }

  protected asociacion(numeroLinea: number): AsociacionLinea {
    return this.asociaciones().get(numeroLinea) ?? PENDIENTE;
  }

  protected valor(numeroLinea: number): string {
    return valorAsociacion(this.asociacion(numeroLinea));
  }

  protected asociar(numeroLinea: number, valor: string): void {
    this.asociaciones.update((actuales) =>
      new Map(actuales).set(numeroLinea, leerValorAsociacion(valor)),
    );
    // Lo que elige el usuario deja de ser una sugerencia.
    this.sugeridas.update((actuales) => {
      const nuevas = new Set(actuales);
      nuevas.delete(numeroLinea);
      return nuevas;
    });
    // La equivalencia depende del artículo: al cambiarlo hay que confirmarla de nuevo.
    this.equivalencias.update((actuales) => {
      const nuevas = new Map(actuales);
      nuevas.delete(numeroLinea);
      return nuevas;
    });
  }

  /** Texto del campo cuando está cerrado: el artículo elegido o la marca de no inventario. */
  protected etiqueta(numeroLinea: number, ...listas: ArticuloCatalogo[][]): string {
    if (this.asociacion(numeroLinea).tipo === 'no-inventario') return TEXTO_NO_INVENTARIO;
    return this.articulo(numeroLinea, ...listas)?.nombre ?? '';
  }

  /** Opciones de la lista de una línea: la marca de no inventario y los artículos que coinciden. */
  protected opcionesDe(
    numeroLinea: number,
    ingredientes: ArticuloCatalogo[],
    productos: ArticuloCatalogo[],
  ): OpcionAsociacion[] {
    const deArticulo = (articulo: ArticuloCatalogo): OpcionAsociacion => ({
      valor: valorAsociacion(articulo),
      nombre: articulo.nombre,
      detalle: articulo.tipo === 'ingrediente' ? `Materia prima · ${articulo.unidad}` : 'Producto',
    });
    return [
      { valor: 'no-inventario', nombre: TEXTO_NO_INVENTARIO, detalle: '' },
      ...this.filtrar(numeroLinea, ingredientes).map(deArticulo),
      ...this.filtrar(numeroLinea, productos).map(deArticulo),
    ];
  }

  protected abrir(numeroLinea: number): void {
    if (this.listaAbierta() === numeroLinea) return;
    this.busquedas.update((actuales) => new Map(actuales).set(numeroLinea, ''));
    this.indiceActivo.set(0);
    this.listaAbierta.set(numeroLinea);
  }

  protected cerrar(numeroLinea: number): void {
    if (this.listaAbierta() === numeroLinea) this.listaAbierta.set(null);
  }

  protected elegir(numeroLinea: number, valor: string): void {
    this.asociar(numeroLinea, valor);
    this.cerrar(numeroLinea);
  }

  /** Flechas para recorrer la lista, Enter para elegir y Escape para cerrarla. */
  protected teclear(numeroLinea: number, evento: KeyboardEvent, opciones: OpcionAsociacion[]): void {
    const abierta = this.listaAbierta() === numeroLinea;
    if (evento.key === 'ArrowDown' || evento.key === 'ArrowUp') {
      evento.preventDefault();
      if (!abierta) return this.abrir(numeroLinea);
      const paso = evento.key === 'ArrowDown' ? 1 : -1;
      this.indiceActivo.update((i) => Math.min(Math.max(i + paso, 0), opciones.length - 1));
    } else if (evento.key === 'Enter' && abierta) {
      evento.preventDefault();
      const opcion = opciones[this.indiceActivo()];
      if (opcion) this.elegir(numeroLinea, opcion.valor);
    } else if (evento.key === 'Escape') {
      this.cerrar(numeroLinea);
    }
  }

  /** La línea aún requiere acción: falta el artículo, o la equivalencia de un artículo. */
  protected lineaPendiente(numeroLinea: number, cantidad: number): boolean {
    const asociacion = this.asociacion(numeroLinea);
    if (asociacion.tipo === 'pendiente') return true;
    return necesitaEquivalencia(asociacion) && this.ingreso(numeroLinea, cantidad) === null;
  }

  /** Artículo del catálogo asociado a la línea, o null si está pendiente o no es inventariable. */
  protected articulo(numeroLinea: number, ...listas: ArticuloCatalogo[][]): ArticuloCatalogo | null {
    const asociacion = this.asociacion(numeroLinea);
    if (!necesitaEquivalencia(asociacion) || !('id' in asociacion)) return null;
    return (
      listas.flat().find((item) => item.tipo === asociacion.tipo && item.id === asociacion.id) ?? null
    );
  }

  protected equivalencia(numeroLinea: number): string {
    return this.equivalencias().get(numeroLinea) ?? '';
  }

  protected cambiarEquivalencia(numeroLinea: number, evento: Event): void {
    const texto = (evento.target as HTMLInputElement).value;
    this.equivalencias.update((actuales) => new Map(actuales).set(numeroLinea, texto));
  }

  /** Cantidad que se sumará al stock, o null mientras la equivalencia no sea válida. */
  protected ingreso(numeroLinea: number, cantidad: number): number | null {
    const equivalencia = leerEquivalencia(this.equivalencia(numeroLinea));
    return equivalencia === null ? null : cantidadIngreso(cantidad, equivalencia);
  }

  protected numero(valor: number): string {
    return valor.toLocaleString('es-CL', { maximumFractionDigits: 3 });
  }

  protected busqueda(numeroLinea: number): string {
    return this.busquedas().get(numeroLinea) ?? '';
  }

  protected buscar(numeroLinea: number, evento: Event): void {
    const texto = (evento.target as HTMLInputElement).value;
    this.busquedas.update((actuales) => new Map(actuales).set(numeroLinea, texto));
    this.indiceActivo.set(0);
    this.listaAbierta.set(numeroLinea);
  }

  /** Artículos de una lista que coinciden con el buscador de la línea. */
  protected filtrar(numeroLinea: number, articulos: ArticuloCatalogo[]): ArticuloCatalogo[] {
    return filtrarArticulos(articulos, this.busqueda(numeroLinea), this.asociacion(numeroLinea));
  }

  /** La búsqueda no coincide con ningún artículo (sin contar el que ya está elegido). */
  protected sinCoincidencias(numeroLinea: number, ...listas: ArticuloCatalogo[][]): boolean {
    const busqueda = this.busqueda(numeroLinea);
    return busqueda.trim() !== '' && filtrarArticulos(listas.flat(), busqueda).length === 0;
  }

  protected cancelar(): void {
    this.estado.set({ tipo: 'vacio' });
    this.asociaciones.set(new Map());
    this.sugeridas.set(new Set());
    this.busquedas.set(new Map());
    this.listaAbierta.set(null);
    this.equivalencias.set(new Map());
    this.confirmacion.set({ tipo: 'inactivo' });
    this.previa.set({ tipo: 'inactivo' });
  }

  /**
   * Envía el XML original y lo elegido para cada línea. El servidor decide: si algo
   * no cuadra, rechaza todo y no queda nada guardado.
   */
  protected confirmar(): void {
    const estado = this.estado();
    const sucursal = this.sucursalElegida();
    const nombreSucursal = this.sucursalNombre();
    if (
      this.faltaParaConfirmar() !== null ||
      this.confirmacion().tipo === 'confirmando' ||
      estado.tipo !== 'listo' ||
      !estado.resultado.valida ||
      sucursal === null
    ) {
      return;
    }

    const factura = estado.resultado.factura;
    // faltaParaConfirmar ya descartó líneas pendientes o sin equivalencia.
    const lineas = factura.lineas.map(({ numero_linea }): LineaIngresoFactura => {
      const asociacion = this.asociacion(numero_linea);
      const equivalencia = leerEquivalencia(this.equivalencia(numero_linea)) ?? undefined;
      if (asociacion.tipo === 'ingrediente') {
        return { numero_linea, ingrediente_id: asociacion.id, unidades_por_presentacion: equivalencia };
      }
      if (asociacion.tipo === 'producto') {
        return { numero_linea, producto_id: asociacion.id, unidades_por_presentacion: equivalencia };
      }
      return { numero_linea, no_corresponde_inventario: true };
    });

    this.confirmacion.set({ tipo: 'confirmando' });
    this.facturasApi.ingresar(sucursal, estado.bytes, estado.nombre, lineas).subscribe({
      next: (resultado) => {
        if ('ya_ingresada' in resultado) {
          this.confirmacion.set({ tipo: 'error', fallo: falloYaIngresada() });
          this.comprobarIngreso(factura, estado);
          return;
        }
        this.confirmacion.set({
          tipo: 'ingresada',
          resultado,
          sucursal: nombreSucursal ?? '',
          folio: factura.folio,
        });
        this.ingresada.emit();
      },
      error: (error: unknown) => {
        const fallo = interpretarFalloIngreso(error);
        this.confirmacion.set({ tipo: 'error', fallo });
        // Si se perdió la respuesta de un ingreso que sí se completó, aquí se ve cuál fue.
        if (fallo.tipo === 'ya-ingresada') this.comprobarIngreso(factura, estado);
      },
    });
  }

  /** 2026-10-15 → 15-10-2026, como se muestran las fechas en Chile. */
  protected fecha(valor: string | null): string {
    if (!valor) return '—';
    const [anio, mes, dia] = valor.split('-');
    return `${dia}-${mes}-${anio}`;
  }

  protected pesos(monto: number): string {
    return `$${monto.toLocaleString('es-CL')}`;
  }
}
