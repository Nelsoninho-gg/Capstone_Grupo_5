import { ComponentFixture, TestBed } from '@angular/core/testing';
import { of, throwError } from 'rxjs';
import { IngredientesApiService } from '../../../../core/api/ingredientes-api.service';
import { ProductoApi } from '../../../../core/api/productos-api.service';
import { RecetasApiService, VersionRecetaApi } from '../../../../core/api/recetas-api.service';
import { UnidadesMedidaApiService } from '../../../../core/api/unidades-medida-api.service';
import { RecetaProductoModal } from './receta-producto-modal';

describe('RecetaProductoModal: versión de la receta (H2.5 T02)', () => {
  let fixture: ComponentFixture<RecetaProductoModal>;
  const producto = { id: 10, nombre: 'Sándwich' } as ProductoApi;
  const receta = { id: 1, producto_id: 10, ingrediente_id: 3, cantidad_necesaria: 2, unidad_id: 1 };
  const version = (
    numero: number,
    insumos = 2,
    creada_por: string | null = 'Rocío Fuentes',
    cambios: VersionRecetaApi['cambios'] = numero === 1 ? null : [],
  ): VersionRecetaApi => ({
    numero,
    vigente_desde: `2026-10-${10 + numero}T18:4${numero}:00`,
    creada_por,
    insumos,
    cambios,
  });

  const recetasApi = {
    listarPorProducto: vi.fn(),
    listarVersiones: vi.fn(),
    agregar: vi.fn(),
    actualizar: vi.fn(),
    eliminar: vi.fn(),
  };
  let ingredientes: { id: number; nombre: string; unidad_id: number; activo: boolean }[];
  const listarIngredientes = vi.fn(() => of(ingredientes));

  async function render(): Promise<void> {
    await TestBed.configureTestingModule({
      imports: [RecetaProductoModal],
      providers: [
        { provide: RecetasApiService, useValue: recetasApi },
        {
          provide: IngredientesApiService,
          useValue: { listar: listarIngredientes },
        },
        {
          provide: UnidadesMedidaApiService,
          useValue: { listar: () => of([{ id: 1, nombre: 'Unidad', abreviatura: 'un' }]) },
        },
      ],
    }).compileComponents();
    fixture = TestBed.createComponent(RecetaProductoModal);
    fixture.componentRef.setInput('producto', producto);
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
  }
  function cambios(selector: string): string[] {
    return Array.from(
      (fixture.nativeElement as HTMLElement).querySelectorAll(`${selector} > span`),
    ).map((span) => span.textContent!.trim());
  }
  function texto(selector: string): string {
    const el = (fixture.nativeElement as HTMLElement).querySelector(selector);
    return (el?.textContent ?? '').replace(/\s+/g, ' ').trim();
  }

  beforeEach(() => {
    for (const fn of Object.values(recetasApi)) fn.mockReset();
    recetasApi.listarPorProducto.mockReturnValue(of([receta]));
    ingredientes = [{ id: 3, nombre: 'Pan', unidad_id: 1, activo: true }];
    listarIngredientes.mockClear();
  });

  describe('inactive ingredients (H3.3 T07)', () => {
    beforeEach(() => {
      recetasApi.listarVersiones.mockReturnValue(of([version(1)]));
      ingredientes = [
        { id: 3, nombre: 'Pan', unidad_id: 1, activo: false },
        { id: 4, nombre: 'Queso', unidad_id: 1, activo: true },
        { id: 5, nombre: 'Jamón', unidad_id: 1, activo: false },
      ];
    });

    it('shows an ingredient that was deactivated later with its name and an Inactivo badge', async () => {
      await render();

      expect(listarIngredientes).toHaveBeenCalledWith(false);
      expect(texto('.insumo-name')).toBe('Pan Inactivo');
      expect(texto('.insumo-name')).not.toContain('desconocido');
    });

    it('offers only active ingredients to add', async () => {
      await render();

      const opciones = Array.from(
        (fixture.nativeElement as HTMLElement).querySelectorAll(
          'select[formcontrolname="ingrediente_id"] option',
        ),
      ).map((opcion) => opcion.textContent!.trim());
      expect(opciones).toEqual(['Selecciona un insumo', 'Queso']);
    });
  });

  describe('recipe validations (H5.3 T05)', () => {
    const host = () => fixture.nativeElement as HTMLElement;
    beforeEach(() => recetasApi.listarVersiones.mockReturnValue(of([version(1)])));

    it('asks to confirm before removing the last supply', async () => {
      recetasApi.eliminar.mockReturnValue(of(receta));
      await render();

      host().querySelector<HTMLButtonElement>('[aria-label="Quitar Pan"]')!.click();
      fixture.detectChanges();
      expect(recetasApi.eliminar).not.toHaveBeenCalled();
      expect(texto('.last-supply-warning')).toContain('quedará sin receta');

      Array.from(host().querySelectorAll<HTMLButtonElement>('.last-supply-warning button'))
        .find((b) => b.textContent?.trim() === 'Cancelar')!
        .click();
      fixture.detectChanges();
      expect(host().querySelector('.last-supply-warning')).toBeNull();

      host().querySelector<HTMLButtonElement>('[aria-label="Quitar Pan"]')!.click();
      fixture.detectChanges();
      Array.from(host().querySelectorAll<HTMLButtonElement>('.last-supply-warning button'))
        .find((b) => b.textContent?.trim() === 'Quitar igual')!
        .click();
      fixture.detectChanges();
      expect(recetasApi.eliminar).toHaveBeenCalledWith(receta.id);
    });

    it('removes a supply without asking when others remain', async () => {
      ingredientes = [...ingredientes, { id: 4, nombre: 'Queso', unidad_id: 1, activo: true }];
      recetasApi.listarPorProducto.mockReturnValue(
        of([receta, { ...receta, id: 2, ingrediente_id: 4 }]),
      );
      recetasApi.eliminar.mockReturnValue(of(receta));
      await render();

      host().querySelector<HTMLButtonElement>('[aria-label="Quitar Pan"]')!.click();
      fixture.detectChanges();
      expect(recetasApi.eliminar).toHaveBeenCalledWith(receta.id);
    });

    it('accepts only positive quantities with up to 3 decimals', async () => {
      await render();
      const input = host().querySelector<HTMLInputElement>('.cantidad-input')!;
      for (const valor of ['0', '-1', '1.2345', 'abc']) {
        input.value = valor;
        input.dispatchEvent(new Event('input'));
        fixture.detectChanges();
        expect(host().querySelector('.action-group .secondary-button')).toBeNull();
      }
      input.value = '0,125';
      input.dispatchEvent(new Event('input'));
      fixture.detectChanges();
      expect(host().querySelector('.action-group .secondary-button')).not.toBeNull();
    });

    it('shows the database message when it rejects a supply', async () => {
      const { HttpErrorResponse } = await import('@angular/common/http');
      recetasApi.actualizar.mockReturnValue(
        throwError(
          () =>
            new HttpErrorResponse({
              status: 400,
              error: { message: '"Pan" está inactivo: no se puede agregar a una receta' },
            }),
        ),
      );
      await render();
      const input = host().querySelector<HTMLInputElement>('.cantidad-input')!;
      input.value = '3';
      input.dispatchEvent(new Event('input'));
      fixture.detectChanges();
      host().querySelector<HTMLButtonElement>('.action-group .secondary-button')!.click();
      fixture.detectChanges();

      expect(texto('.row-error')).toContain('está inactivo');
    });
  });

  it('shows the current version in one line, with the history folded', async () => {
    recetasApi.listarVersiones.mockReturnValue(
      of([
        version(3, 2, 'Rocío Fuentes', [
          { tipo: 'modificado', ingrediente: 'Queso', unidad: 'g', antes: 50, despues: 100 },
          { tipo: 'quitado', ingrediente: 'Palta', unidad: 'g', antes: 30, despues: null },
        ]),
        version(2, 3, 'Matías Lagos', [
          { tipo: 'agregado', ingrediente: 'Palta', unidad: 'g', antes: null, despues: 30 },
        ]),
        version(1, 2, null),
      ]),
    );
    await render();

    expect(recetasApi.listarVersiones).toHaveBeenCalledWith(10);
    expect(texto('.version-receta p')).toBe('Versión 3 desde el 13-10-2026 18:43 · Rocío Fuentes');
    expect(cambios('.version-receta > .version-cambios')).toEqual([
      'Queso 50 → 100 g',
      '− Palta 30 g',
    ]);
    expect(
      (fixture.nativeElement as HTMLElement).querySelector(
        '.version-receta > .version-cambios .cambio-quitado',
      )?.textContent,
    ).toBe('− Palta 30 g');
    const historial = (fixture.nativeElement as HTMLElement).querySelector('details')!;
    expect(historial.open).toBe(false);
    expect(texto('details summary')).toBe('Ver versiones anteriores (2)');
    expect(
      Array.from(historial.querySelectorAll('li')).map((li) =>
        li.textContent!.replace(/\s+/g, ' ').trim(),
      ),
    ).toEqual([
      'Versión 2 · 12-10-2026 18:42 · Matías Lagos + Palta 30 g',
      'Versión 1 · 11-10-2026 18:41 Receta inicial',
    ]);
  });

  it('shows no history when there is a single version', async () => {
    recetasApi.listarVersiones.mockReturnValue(of([version(1, 1, null)]));
    await render();

    expect(texto('.version-receta p')).toBe('Versión 1 desde el 11-10-2026 18:41');
    expect(texto('.version-cambios')).toBe('Receta inicial');
    expect((fixture.nativeElement as HTMLElement).querySelector('details')).toBeNull();
  });

  it('asks for the versions again after each change to the recipe', async () => {
    recetasApi.listarVersiones.mockReturnValue(of([version(1)]));
    recetasApi.actualizar.mockReturnValue(of({ ...receta, cantidad_necesaria: 3 }));
    await render();

    recetasApi.listarVersiones.mockReturnValue(of([version(2), version(1)]));
    const input = (fixture.nativeElement as HTMLElement).querySelector<HTMLInputElement>(
      '.cantidad-input',
    )!;
    input.value = '3';
    input.dispatchEvent(new Event('input'));
    fixture.detectChanges();
    (fixture.nativeElement as HTMLElement)
      .querySelector<HTMLButtonElement>('.action-group .secondary-button')!
      .click();
    fixture.detectChanges();

    expect(recetasApi.listarVersiones).toHaveBeenCalledTimes(2);
    expect(texto('.version-badge')).toBe('Versión 2');
  });

  it('hides the version line when the database does not offer it yet', async () => {
    recetasApi.listarVersiones.mockReturnValue(throwError(() => new Error('404')));
    await render();

    expect((fixture.nativeElement as HTMLElement).querySelector('.version-receta')).toBeNull();
    expect(texto('.insumo-name')).toBe('Pan');
  });

  it('says when a version left the product without supplies', async () => {
    recetasApi.listarPorProducto.mockReturnValue(of([]));
    recetasApi.listarVersiones.mockReturnValue(
      of([
        version(2, 0, 'Rocío Fuentes', [
          { tipo: 'quitado', ingrediente: 'Pan', unidad: 'un', antes: 2.5, despues: null },
        ]),
        version(1, 1, null),
      ]),
    );
    await render();

    expect(cambios('.version-receta > .version-cambios')).toEqual([
      '− Pan 2,5 un',
      '(sin insumos: producto simple)',
    ]);
  });

  it('shows nothing for a simple product without versions', async () => {
    recetasApi.listarPorProducto.mockReturnValue(of([]));
    recetasApi.listarVersiones.mockReturnValue(of([]));
    await render();

    expect((fixture.nativeElement as HTMLElement).querySelector('.version-receta')).toBeNull();
  });
});
