import { Component, ElementRef, inject, OnInit, signal, ViewChild } from '@angular/core';
import { FacturasApiService, IngresoFactura, XmlFactura } from '../../../../core/api/facturas-api.service';
import { CargaFactura } from '../carga-factura/carga-factura';

type EstadoListado =
  | { tipo: 'cargando' }
  | { tipo: 'error' }
  | { tipo: 'listo'; ingresos: IngresoFactura[] };

/** Descarga del XML en curso o fallida, por factura. */
type EstadoDescarga = { id: number; tipo: 'descargando' | 'error' } | null;

/**
 * Consulta de ingresos de facturas XML realizados (H3.1 T09): cada factura con su detalle
 * original, lo que se hizo con cada línea, quién y cuándo la ingresó, los intentos de
 * volver a ingresarla (H3.7 T07) y la descarga del XML original. El servidor decide qué
 * facturas ve cada usuario (`fn_listar_ingresos_factura`).
 */
@Component({
  selector: 'app-ingresos-factura',
  imports: [CargaFactura],
  // Reutiliza encabezado, paneles, tablas y avisos de la pantalla de carga.
  styleUrls: ['../carga-factura/carga-factura.css', './ingresos-factura.css'],
  templateUrl: './ingresos-factura.html',
})
export class IngresosFactura implements OnInit {
  private readonly facturasApi = inject(FacturasApiService);

  protected readonly estado = signal<EstadoListado>({ tipo: 'cargando' });
  /** Factura con el detalle desplegado. */
  protected readonly abierta = signal<number | null>(null);
  protected readonly descarga = signal<EstadoDescarga>(null);
  /** Modal de carga de una factura XML. */
  protected readonly cargaAbierta = signal(false);

  @ViewChild('botonCarga') private readonly botonCarga?: ElementRef<HTMLButtonElement>;

  ngOnInit(): void {
    this.cargar();
  }

  protected cerrarCarga(): void {
    this.cargaAbierta.set(false);
    // Devuelve el foco al botón que abrió el modal.
    setTimeout(() => this.botonCarga?.nativeElement.focus());
  }

  protected cargar(): void {
    this.estado.set({ tipo: 'cargando' });
    this.facturasApi.listarIngresos().subscribe({
      next: (ingresos) => this.estado.set({ tipo: 'listo', ingresos }),
      error: () => this.estado.set({ tipo: 'error' }),
    });
  }

  protected alternar(id: number): void {
    this.abierta.update((actual) => (actual === id ? null : id));
  }

  protected descargar(ingreso: IngresoFactura): void {
    if (this.descarga()?.tipo === 'descargando') return;
    const id = ingreso.factura_xml_id;
    this.descarga.set({ id, tipo: 'descargando' });
    this.facturasApi.descargarXml(id).subscribe({
      next: (xml) => {
        guardarArchivo(xml);
        this.descarga.set(null);
      },
      error: () => this.descarga.set({ id, tipo: 'error' }),
    });
  }

  /** «3 líneas al stock» o «1 línea al stock · 1 excluida». */
  protected resumenLineas(ingreso: IngresoFactura): string {
    const stock = ingreso.lineas.filter((linea) => linea.tipo !== 'no-inventario').length;
    const excluidas = ingreso.lineas.length - stock;
    const resumen = stock === 1 ? '1 línea al stock' : `${stock} líneas al stock`;
    if (excluidas === 0) return resumen;
    return `${resumen} · ${excluidas === 1 ? '1 excluida' : excluidas + ' excluidas'}`;
  }

  protected numero(valor: number | null): string {
    return valor === null ? '—' : valor.toLocaleString('es-CL', { maximumFractionDigits: 3 });
  }

  protected pesos(monto: number): string {
    return `$${monto.toLocaleString('es-CL')}`;
  }

  /** 2026-10-15 → 15-10-2026, como se muestran las fechas en Chile. */
  protected fecha(valor: string): string {
    const [anio, mes, dia] = valor.split('-');
    return `${dia}-${mes}-${anio}`;
  }

  /** Fecha y hora: 20-10-2026 15:32. */
  protected fechaHora(valor: string): string {
    const fecha = new Date(valor);
    if (Number.isNaN(fecha.getTime())) return '—';
    const dos = (n: number) => String(n).padStart(2, '0');
    return `${dos(fecha.getDate())}-${dos(fecha.getMonth() + 1)}-${fecha.getFullYear()} ${dos(fecha.getHours())}:${dos(fecha.getMinutes())}`;
  }
}

/** Entrega al navegador el archivo tal cual llegó (los bytes, no el texto: puede ser ISO-8859-1). */
function guardarArchivo({ xml_nombre, xml_base64 }: XmlFactura): void {
  const binario = atob(xml_base64);
  const bytes = Uint8Array.from(binario, (caracter) => caracter.charCodeAt(0));
  const url = URL.createObjectURL(new Blob([bytes], { type: 'application/xml' }));
  const enlace = document.createElement('a');
  enlace.href = url;
  enlace.download = xml_nombre;
  enlace.click();
  URL.revokeObjectURL(url);
}
