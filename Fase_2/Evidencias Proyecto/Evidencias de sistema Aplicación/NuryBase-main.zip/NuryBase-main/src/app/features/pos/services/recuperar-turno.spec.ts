import { signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { firstValueFrom, NEVER, of, Subject, throwError } from 'rxjs';
import { ProductosApiService } from '../../../core/api/productos-api.service';
import { VentasApiService } from '../../../core/api/ventas-api.service';
import { TurnoApi, TurnoRecuperadoApi, TurnosApiService, VentaTurnoApi } from '../../../core/api/turnos-api.service';
import { User } from '../../auth/models/auth.model';
import { AuthService } from '../../auth/services/auth.service';
import { PosService } from './pos.service';

const USER: User = {
  id: 7, nombre: 'Camila', identificadorAcceso: 'camila@test.cl', rol: 'cajero',
  sucursalId: 1, sucursalNombre: 'Providencia', activo: true,
};
const TURNO: TurnoApi = {
  id: 42, usuario_id: USER.id, sucursal_id: 1, monto_inicial: 5000,
  hora_inicio: '2026-10-12T12:00:00', hora_fin: null, creado_en: '2026-10-12T12:00:00',
};
const VENTA: VentaTurnoApi = {
  id: 999, cajero_id: USER.id, sucursal_id: 1, fecha_venta: '2026-10-12T12:30:00',
  medio_pago: 'efectivo', total: 2000, anulada: false, anulada_en: null, anulada_por: null,
  creado_en: '2026-10-12T12:30:00', detalle_venta: [{
    cantidad: 2, precio_unitario: 1000, subtotal: 2000,
    productos: { id: 1, nombre: 'Café', categoria: 'Cafetería', precio_compra: null,
      precio_venta: 1500, codigo_barras: null, activo: true, creado_en: '2026-10-01T12:00:00' },
  }],
};

describe('PosService — recuperación desde PostgreSQL', () => {
  const currentUser = signal<User | null>(USER);
  const recuperar = vi.fn();
  let pos: PosService;

  beforeEach(() => {
    sessionStorage.clear();
    currentUser.set(USER);
    recuperar.mockReset().mockReturnValue(of({ turno: TURNO, ventas: [VENTA] }));
    TestBed.configureTestingModule({ providers: [
      { provide: ProductosApiService, useValue: { listar: () => NEVER } },
      { provide: VentasApiService, useValue: {} },
      { provide: AuthService, useValue: { currentUser } },
      { provide: TurnosApiService, useValue: {
        recuperar, cerrar: () => of({ ...TURNO, hora_fin: '2026-10-12T13:00:00' }),
      } },
    ] });
    pos = TestBed.inject(PosService);
  });
  afterEach(() => sessionStorage.clear());

  it('restores the shift, original opening amount, sales and historical prices without a browser cache', async () => {
    await firstValueFrom(pos.sincronizarTurno());
    expect(pos.isRegisterOpen()).toBe(true);
    expect(pos.turnoActivo()?.monto_inicial).toBe(5000);
    expect(pos.salesHistory()).toHaveLength(1);
    expect(pos.salesHistory()[0].total).toBe(2000);
    expect(pos.salesHistory()[0].items[0].producto.precioVenta).toBe(1000);
    expect(pos.salesHistory()[0].fecha.toISOString()).toBe('2026-10-12T12:30:00.000Z');
    expect(sessionStorage.getItem('nury_turno')).not.toBeNull();
  });

  it('excludes annulled sales from the recovered totals and restores their reasons', async () => {
    recuperar.mockReturnValue(of({ turno: TURNO, ventas: [VENTA, {
      ...VENTA, id: 1000, anulada: true, anulada_en: '2026-10-12T12:35:00', anulada_motivo: 'Error al cobrar',
    }] }));
    await firstValueFrom(pos.sincronizarTurno());
    expect(pos.salesHistory().map((v) => v.id)).toEqual([999]);
    expect(pos.anuladasTurno()[0].venta.id).toBe(1000);
    expect(pos.anuladasTurno()[0].motivo).toBe('Error al cobrar');
  });

  it('discards a locally open shift that the server confirms is closed', async () => {
    await firstValueFrom(pos.sincronizarTurno());
    recuperar.mockReturnValue(of({ turno: null, ventas: [] }));
    await firstValueFrom(pos.sincronizarTurno());
    expect(pos.turnoActivo()).toBeNull();
    expect(pos.salesHistory()).toEqual([]);
    expect(pos.anuladasTurno()).toEqual([]);
    expect(sessionStorage.getItem('nury_turno')).toBeNull();
  });

  it('shares simultaneous recovery requests and prevents operations while waiting', () => {
    const response = new Subject<TurnoRecuperadoApi>();
    recuperar.mockReturnValue(response);
    pos.turnoActivo.set(TURNO);
    pos.sincronizarTurno().subscribe();
    pos.sincronizarTurno().subscribe();
    expect(recuperar).toHaveBeenCalledOnce();
    expect(pos.sincronizandoTurno()).toBe(true);
    expect(pos.isRegisterOpen()).toBe(false);
    response.next({ turno: TURNO, ventas: [VENTA] });
    response.complete();
    expect(pos.salesHistory()).toHaveLength(1);
    expect(pos.isRegisterOpen()).toBe(true);
  });

  it('does not reopen a shift with a late recovery response after a confirmed closure', () => {
    const response = new Subject<TurnoRecuperadoApi>();
    recuperar.mockReturnValue(response);
    pos.turnoActivo.set(TURNO);
    pos.sincronizarTurno().subscribe();
    pos.cerrarTurnoActivo().subscribe();
    response.next({ turno: TURNO, ventas: [VENTA] });
    response.complete();
    expect(pos.isRegisterOpen()).toBe(false);
    expect(pos.turnoActivo()).toBeNull();
  });

  it('does not transfer shift data or apply a late response to another logged-in user', () => {
    const response = new Subject<TurnoRecuperadoApi>();
    recuperar.mockReturnValue(response);
    pos.sincronizarTurno().subscribe();
    currentUser.set({ ...USER, id: 8 });
    TestBed.tick();
    response.next({ turno: TURNO, ventas: [VENTA] });
    response.complete();
    expect(pos.turnoActivo()).toBeNull();
    expect(pos.salesHistory()).toEqual([]);
  });

  it('retains recoverable cache data on network errors and can retry without opening another shift', async () => {
    await firstValueFrom(pos.sincronizarTurno());
    recuperar.mockReturnValue(throwError(() => new Error('sin red')));
    await expect(firstValueFrom(pos.sincronizarTurno())).rejects.toThrow('sin red');
    expect(pos.errorSincronizarTurno()).not.toBeNull();
    expect(pos.isRegisterOpen()).toBe(false);
    expect(pos.salesHistory()).toHaveLength(1);
    recuperar.mockReturnValue(of({ turno: TURNO, ventas: [VENTA] }));
    await firstValueFrom(pos.sincronizarTurno());
    expect(pos.errorSincronizarTurno()).toBeNull();
    expect(pos.isRegisterOpen()).toBe(true);
  });

  it('rejects a recovered shift belonging to another cashier', async () => {
    recuperar.mockReturnValue(of({ turno: { ...TURNO, usuario_id: 8 }, ventas: [] }));
    await expect(firstValueFrom(pos.sincronizarTurno())).rejects.toThrow('no corresponde');
    expect(pos.isRegisterOpen()).toBe(false);
  });
});
