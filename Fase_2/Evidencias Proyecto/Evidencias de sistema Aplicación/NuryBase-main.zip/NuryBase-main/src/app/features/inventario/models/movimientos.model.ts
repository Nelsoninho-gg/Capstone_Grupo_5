import { TipoArticulo } from './inventario.model';

/**
 * Movimiento del kardex de un artículo (H3.2 T01), leído de la vista v_movimientos_articulos
 * (migración 20261026_movimientos_articulos.sql).
 */
export type TipoMovimiento = 'venta' | 'anulacion_venta' | 'compra' | 'ajuste' | 'merma';

export interface MovimientoArticulo {
  id: number;
  tipo: TipoMovimiento;
  /** Venta que lo originó (venta o anulación); null en compras y ajustes. */
  ventaId: number | null;
  referenciaTipo: string | null;
  referenciaId: number | null;
  /** Con signo: positivo entra, negativo sale. */
  cantidad: number;
  unidad: string;
  stockResultante: number;
  sucursalId: number;
  sucursal: string;
  fecha: Date;
  nota: string | null;
}

/** Artículo cuyo historial se abre, desde Existencias (con sucursal) o desde el Catálogo. */
export interface ArticuloMovimientos {
  tipo: TipoArticulo;
  id: number;
  nombre: string;
  unidad: string;
  /** Sucursal de la fila de Existencias; null para ver todas. */
  sucursalId: number | null;
  sucursal: string | null;
}

export type FiltroMovimiento = 'todos' | 'venta' | 'compra' | 'ajustes' | 'anulacion_venta';

export const FILTROS_MOVIMIENTO: { valor: FiltroMovimiento; etiqueta: string }[] = [
  { valor: 'todos', etiqueta: 'Todos' },
  { valor: 'venta', etiqueta: 'Ventas' },
  { valor: 'anulacion_venta', etiqueta: 'Anulaciones' },
  { valor: 'compra', etiqueta: 'Compras' },
  { valor: 'ajustes', etiqueta: 'Ajustes y mermas' },
];

const ETIQUETAS: Record<TipoMovimiento, string> = {
  venta: 'Venta',
  anulacion_venta: 'Anulación',
  compra: 'Compra',
  ajuste: 'Ajuste',
  merma: 'Merma',
};

export function etiquetaMovimiento(tipo: TipoMovimiento): string {
  return ETIQUETAS[tipo] ?? tipo;
}

export function filtrarMovimientos(
  movimientos: MovimientoArticulo[],
  filtro: FiltroMovimiento,
): MovimientoArticulo[] {
  if (filtro === 'todos') return movimientos;
  if (filtro === 'ajustes') {
    return movimientos.filter((m) => m.tipo === 'ajuste' || m.tipo === 'merma');
  }
  return movimientos.filter((m) => m.tipo === filtro);
}

/** De dónde salió el movimiento, en palabras: "Venta #67", "Factura #12", "Ajuste manual". */
export function origenMovimiento(movimiento: MovimientoArticulo): string {
  const id = movimiento.referenciaId;
  switch (movimiento.referenciaTipo) {
    case 'venta':
      return movimiento.tipo === 'anulacion_venta'
        ? `Anulación de la venta #${id}`
        : `Venta #${id}`;
    case 'factura_compra':
      return id === null ? 'Factura de compra' : `Factura #${id}`;
    case 'ajuste_manual':
      return movimiento.tipo === 'merma' ? 'Merma registrada' : 'Ajuste manual';
    default:
      return etiquetaMovimiento(movimiento.tipo);
  }
}
