export interface PosCategory {
  id: string;
  nombre: string;
  icono: string;
}

export interface PosProduct {
  id: number;
  nombre: string;
  categoriaId: string;
  categoriaNombre: string;
  codigoInterno: string;
  codigoBarras: string;
  precioVenta: number;
  icono: string;
  descripcion: string;
  activo: boolean;
}

export interface CartItem {
  producto: PosProduct;
  cantidad: number;
  subtotal: number;
}

import { TipoVenta } from '../../../core/models/comun.model';

export type PaymentMethod = 'efectivo' | 'credito' | 'debito' | 'sodexo' | 'edenred';

/** Ítem que no alcanzó a cubrirse con el stock de la sucursal en una venta (H2.5 T04). */
export interface StockInsuficiente {
  nombre: string;
  unidad: string;
  requerido: number;
  disponible: number;
  faltante: number;
}

export interface CompletedSale {
  /** id real de la venta en la base de datos (ventas.id) */
  id: number;
  ticketFolio: string;
  fecha: Date;
  cajeroNombre: string;
  sucursalNombre: string;
  medioPago: PaymentMethod;
  /** Total cobrado (con el descuento ya aplicado en una venta a empleado). */
  total: number;
  /** Venta a empleado (H2.12). Ausente en ventas anteriores: se tratan como normales. */
  tipoVenta?: TipoVenta;
  /** Suma de los productos antes del descuento. */
  subtotal?: number;
  descuento?: number;
  empleadoNombre?: string;
  montoRecibido: number;
  vuelto: number;
  items: CartItem[];
  codigoAutorizacion?: string;
  titularJunaeb?: string;
  saldoRestanteJunaeb?: number;
  /** Lo que quedó sin stock suficiente tras la venta; vacío o ausente si alcanzó todo. */
  stockInsuficiente?: StockInsuficiente[];
}
