/**
 * Quién puede ingresar facturas y en qué sucursal (H3.1 T07).
 *
 * Es la misma regla que aplica PostgreSQL (`fn_validar_sucursal_ingreso`,
 * database/migrations/20261017_permisos_ingreso_facturas.sql). Aquí solo sirve
 * para mostrar las opciones correctas: el servidor es quien la hace cumplir.
 *
 *   - admin: cualquier sucursal activa.
 *   - bodeguero: únicamente la suya; sin sucursal asignada no puede ingresar.
 *   - cajero y otros roles: no ingresan facturas.
 */

import type { User } from '../../auth/models/auth.model';

export interface SucursalIngreso {
  id: number;
  nombre: string;
}

export type PermisoIngreso =
  | {
      puede: true;
      /** El usuario no elige: solo puede usar su sucursal. */
      fija: boolean;
      opciones: SucursalIngreso[];
      /** Sucursal preseleccionada, o null si el usuario debe elegir. */
      porDefecto: number | null;
    }
  | { puede: false; motivo: string };

export function permisoIngreso(
  usuario: Pick<User, 'rol' | 'sucursalId' | 'sucursalNombre'> | null,
  sucursalesActivas: SucursalIngreso[],
): PermisoIngreso {
  if (!usuario) {
    return { puede: false, motivo: 'Inicia sesión para ingresar facturas.' };
  }

  if (usuario.rol === 'admin') {
    const opciones = [...sucursalesActivas].sort((a, b) => a.nombre.localeCompare(b.nombre, 'es'));
    if (opciones.length === 0) {
      return {
        puede: false,
        motivo: 'No hay sucursales activas donde ingresar la factura. Activa o crea una sucursal primero.',
      };
    }
    const propia = opciones.find((sucursal) => sucursal.id === usuario.sucursalId);
    return {
      puede: true,
      fija: false,
      opciones,
      porDefecto: propia?.id ?? (opciones.length === 1 ? opciones[0].id : null),
    };
  }

  if (usuario.rol === 'bodeguero') {
    if (usuario.sucursalId === null) {
      return {
        puede: false,
        motivo:
          'Tu usuario no tiene una sucursal asignada, por eso no puede ingresar facturas. ' +
          'Pide a un administrador que te la asigne.',
      };
    }
    return {
      puede: true,
      fija: true,
      opciones: [{ id: usuario.sucursalId, nombre: usuario.sucursalNombre || 'Mi sucursal' }],
      porDefecto: usuario.sucursalId,
    };
  }

  return { puede: false, motivo: 'Tu rol no permite ingresar facturas.' };
}
