import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { NEVER, of } from 'rxjs';
import { PaymentModalComponent } from './payment-modal.component';
import { PosService } from '../../services/pos.service';
import { ProductosApiService } from '../../../../core/api/productos-api.service';
import { VentasApiService } from '../../../../core/api/ventas-api.service';
import { PosProduct } from '../../models/pos.model';
import { AuthService } from '../../../auth/services/auth.service';
import { User } from '../../../auth/models/auth.model';

const TEST_PRODUCT: PosProduct = {
  id: 1,
  nombre: 'Café Espresso Doble',
  categoriaId: 'BEBESTIBLES - CAFÉ',
  categoriaNombre: 'Cafetería',
  codigoInterno: 'NUR-101',
  codigoBarras: '7801234501018',
  precioVenta: 2600,
  icono: '☕',
  descripcion: 'Producto exclusivo para pruebas.',
  activo: true,
};

const TEST_USER: User = {
  id: 1,
  nombre: 'Camila Rojas',
  identificadorAcceso: 'c.rojas@nurys.cl',
  rol: 'cajero',
  sucursalId: 1,
  sucursalNombre: 'Nury Providencia',
  activo: true,
};

describe('PaymentModalComponent', () => {
  beforeEach(async () => {
    // PosService guarda el turno en sessionStorage; cada prueba parte sin turno previo.
    sessionStorage.clear();
    await TestBed.configureTestingModule({
      imports: [PaymentModalComponent],
      providers: [
        provideRouter([]),
        { provide: ProductosApiService, useValue: { listar: () => NEVER } },
        { provide: VentasApiService, useValue: { registrar: () => of(999) } },
        { provide: AuthService, useValue: { currentUser: () => TEST_USER } },
      ],
    }).compileComponents();
    const pos = TestBed.inject(PosService);
    pos.catalog.set([TEST_PRODUCT]);
    pos.clearCart();
  });

  // Las ventas cobradas aquí (id 999, usuario 1) no deben quedar en el sessionStorage compartido.
  afterEach(() => sessionStorage.clear());

  it('prints only after a sale, keeping its receipt and sale history intact', () => {
    const print = vi.spyOn(window, 'print').mockImplementation(() => {});
    try {
      const fixture = TestBed.createComponent(PaymentModalComponent);
      const component = fixture.componentInstance;
      component.printTicket();
      expect(print).not.toHaveBeenCalled();
      const pos = TestBed.inject(PosService);
      pos.addToCart(pos.catalog()[0]);
      component.totalToPay = pos.total();
      fixture.detectChanges();
      component.setExactAmount();
      component.onConfirmPayment();
      fixture.detectChanges();
      const receipt = fixture.nativeElement.querySelector('.receipt-paper');
      expect(receipt.textContent).toContain('Café Espresso Doble');
      expect(receipt.textContent).toContain('Subtotal neto');
      expect(receipt.textContent).toContain('IVA (19% incluido)');
      expect(receipt.textContent).toContain('TK-');
      fixture.nativeElement.querySelector('.btn-print').click();
      expect(print).toHaveBeenCalledTimes(1);
      expect(pos.salesHistory()).toHaveLength(1);
      expect(component.completedTicket()).not.toBeNull();
    } finally {
      print.mockRestore();
    }
  });

  it('shows the employee, subtotal and 30% discount on an employee sale receipt (H2.12)', () => {
    const fixture = TestBed.createComponent(PaymentModalComponent);
    const component = fixture.componentInstance;
    const pos = TestBed.inject(PosService);
    pos.empleados.set([{ id: 5, nombre: 'Ana Pérez' }]);
    pos.empleadosStatus.set('ready');
    pos.addToCart(pos.catalog()[0]);
    pos.setVentaEmpleado(true);
    pos.seleccionarEmpleado(5);
    component.totalToPay = pos.total();
    fixture.detectChanges();

    component.setExactAmount();
    component.onConfirmPayment();
    fixture.detectChanges();

    const receipt = (fixture.nativeElement.querySelector('.receipt-paper').textContent as string)
      .replace(/\s+/g, '');
    expect(receipt).toContain('EMP-999');
    expect(receipt).toContain('Ventaaempleado:AnaPérez');
    expect(receipt).toContain('Subtotal$2.600');
    expect(receipt).toContain('Descuentoempleado(30%)−$780');
    expect(receipt).toContain('TOTALPAGADO$1.820');
  });

  it('keeps the normal receipt without employee or discount lines', () => {
    const fixture = TestBed.createComponent(PaymentModalComponent);
    const component = fixture.componentInstance;
    const pos = TestBed.inject(PosService);
    pos.addToCart(pos.catalog()[0]);
    component.totalToPay = pos.total();
    fixture.detectChanges();

    component.setExactAmount();
    component.onConfirmPayment();
    fixture.detectChanges();

    const receipt = fixture.nativeElement.querySelector('.receipt-paper').textContent as string;
    expect(receipt).toContain('TK-999');
    expect(receipt).not.toContain('Venta a empleado');
    expect(receipt).not.toContain('Descuento empleado');
  });

  it('requires explicit cash selection (exact amount or cash received) before confirming payment', () => {
    const component = TestBed.createComponent(PaymentModalComponent).componentInstance;
    component.totalToPay = 5000;
    component.setMethod('efectivo');

    // Inicialmente no es válido hasta que el cajero indique el monto
    expect(component.isPaymentValid()).toBe(false);
    expect(component.paymentError()).toContain('paga justo');

    // Al seleccionar Paga Justo
    component.setExactAmount();
    expect(component.isPaymentValid()).toBe(true);
    expect(component.changeDue()).toBe(0);

    // Al cambiar de medio y volver a efectivo se requiere nueva confirmación
    component.setMethod('credito');
    component.setMethod('efectivo');
    expect(component.isPaymentValid()).toBe(false);

    // Al seleccionar un billete suficiente
    component.setCashAmount(10000);
    expect(component.isPaymentValid()).toBe(true);
    expect(component.changeDue()).toBe(5000);
  });
  it.each([NaN, Infinity, -1, 5000.5, Number.MAX_SAFE_INTEGER + 1])(
    'rejects invalid cash: %s',
    async (amount) => {
      const fixture = TestBed.createComponent(PaymentModalComponent);
      fixture.componentInstance.totalToPay = 5000;
      fixture.detectChanges();
      fixture.componentInstance.setCashAmount(amount);
      expect(fixture.componentInstance.isPaymentValid()).toBe(false);
    },
  );

  it('revalidates the total and resets Junaeb approval when it changes', () => {
    const component = TestBed.createComponent(PaymentModalComponent).componentInstance;
    component.totalToPay = 5000;
    component.setMethod('sodexo');
    component.markJunaebAsScanned();
    expect(component.isPaymentValid()).toBe(true);
    component.totalToPay = 6000;
    expect(component.isPaymentValid()).toBe(false);
    component.setMethod('credito');
    component.totalToPay = 0;
    expect(component.isPaymentValid()).toBe(false);
  });

  it('requires a fresh Junaeb confirmation after switching methods', () => {
    const component = TestBed.createComponent(PaymentModalComponent).componentInstance;
    component.totalToPay = 5000;
    component.setMethod('sodexo');
    component.markJunaebAsScanned();
    component.setMethod('credito');
    component.setMethod('sodexo');
    expect(component.isPaymentValid()).toBe(false);
  });

  it('records the selected method once, even if confirmation is repeated', () => {
    const pos = TestBed.inject(PosService);
    pos.addToCart(pos.catalog()[0]);
    const component = TestBed.createComponent(PaymentModalComponent).componentInstance;
    component.totalToPay = pos.total();
    component.setMethod('credito');
    component.markCardPaymentAsReady();
    component.onConfirmPayment();
    const sale = component.completedTicket();
    component.onConfirmPayment();
    expect(pos.salesHistory()).toHaveLength(1);
    expect(component.completedTicket()).toBe(sale);
    expect(sale?.medioPago).toBe('credito');
    expect(sale?.montoRecibido).toBe(sale?.total);
  });

  it('does not charge an empty or changed cart', () => {
    const pos = TestBed.inject(PosService);
    const component = TestBed.createComponent(PaymentModalComponent).componentInstance;
    component.totalToPay = 5000;
    component.setMethod('credito');
    component.markCardPaymentAsReady();
    component.onConfirmPayment();
    pos.addToCart(pos.catalog()[0]);
    component.onConfirmPayment();
    expect(pos.salesHistory()).toHaveLength(0);
    expect(component.completedTicket()).toBeNull();
  });

  it('should create the payment modal', () => {
    const fixture = TestBed.createComponent(PaymentModalComponent);
    const component = fixture.componentInstance;
    component.totalToPay = 5000;
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

  it('should calculate cash change correctly (H2.4)', () => {
    const fixture = TestBed.createComponent(PaymentModalComponent);
    const component = fixture.componentInstance;
    component.totalToPay = 4800;
    fixture.detectChanges();

    component.setMethod('efectivo');
    component.setCashAmount(10000);

    expect(component.changeDue()).toBe(5200);
    expect(component.isPaymentValid()).toBe(true);
  });

  it('should detect insufficient cash payment', () => {
    const fixture = TestBed.createComponent(PaymentModalComponent);
    const component = fixture.componentInstance;
    component.totalToPay = 5000;
    fixture.detectChanges();

    component.setMethod('efectivo');
    component.setCashAmount(3000);

    expect(component.changeDue()).toBe(-2000);
    expect(component.isPaymentValid()).toBe(false);
  });

  it('should auto-set exact amount for card payment', () => {
    const fixture = TestBed.createComponent(PaymentModalComponent);
    const component = fixture.componentInstance;
    component.totalToPay = 6500;
    fixture.detectChanges();

    component.setMethod('credito');
    expect(component.amountReceived()).toBe(6500);
    expect(component.isPaymentValid()).toBe(false);
    component.markCardPaymentAsReady();
    expect(component.isPaymentValid()).toBe(true);
  });

  it('requires a fresh card confirmation after switching payment methods', () => {
    const component = TestBed.createComponent(PaymentModalComponent).componentInstance;
    component.totalToPay = 5000;
    component.setMethod('credito');
    component.markCardPaymentAsReady();
    expect(component.isPaymentValid()).toBe(true);

    component.setMethod('efectivo');
    component.setMethod('credito');

    expect(component.cardPaymentReady()).toBe(false);
    expect(component.isPaymentValid()).toBe(false);
  });

  it('should require marking Junaeb as scanned before confirming', () => {
    const fixture = TestBed.createComponent(PaymentModalComponent);
    const component = fixture.componentInstance;
    component.totalToPay = 4500;
    fixture.detectChanges();

    component.setMethod('sodexo');
    // Inicialmente no es válido hasta que se marque como escaneado desde el móvil
    expect(component.isPaymentValid()).toBe(false);

    // Al presionar "Listo / Escaneado"
    component.markJunaebAsScanned();

    expect(component.junaebScanned()).toBe(true);
    expect(component.isPaymentValid()).toBe(true);
  });
});

describe('PaymentModalComponent — aviso de stock insuficiente (H2.5 T04)', () => {
  beforeEach(async () => {
    sessionStorage.clear();
    await TestBed.configureTestingModule({
      imports: [PaymentModalComponent],
      providers: [
        provideRouter([]),
        { provide: ProductosApiService, useValue: { listar: () => NEVER } },
        {
          provide: VentasApiService,
          useValue: {
            registrar: () => of(999),
            stockInsuficiente: () =>
              of([
                {
                  tipo: 'ingrediente',
                  item_id: 3,
                  nombre: 'Queso',
                  sucursal_id: 1,
                  unidad: 'g',
                  requerido: 120,
                  disponible: 100,
                  faltante: 20.5,
                  stock_actual: -20.5,
                },
              ]),
          },
        },
        { provide: AuthService, useValue: { currentUser: () => TEST_USER } },
      ],
    }).compileComponents();
    const pos = TestBed.inject(PosService);
    pos.catalog.set([TEST_PRODUCT]);
    pos.clearCart();
  });

  afterEach(() => sessionStorage.clear());

  function cobrar() {
    const fixture = TestBed.createComponent(PaymentModalComponent);
    const component = fixture.componentInstance;
    const pos = TestBed.inject(PosService);
    pos.addToCart(pos.catalog()[0]);
    component.totalToPay = pos.total();
    fixture.detectChanges();
    component.setExactAmount();
    component.onConfirmPayment();
    fixture.detectChanges();
    return fixture;
  }

  it('warns, outside the receipt, which ingredients were left without enough stock', () => {
    const fixture = cobrar();
    const aviso = fixture.nativeElement.querySelector('.stock-warning') as HTMLElement;

    expect(aviso).not.toBeNull();
    expect(aviso.getAttribute('role')).toBe('status');
    expect(aviso.textContent).toContain('Queso: faltan 20,5 g');
    expect(aviso.textContent).toContain('se usaron 120, había 100');
    expect(fixture.nativeElement.querySelector('.receipt-paper .stock-warning')).toBeNull();
    expect(fixture.nativeElement.querySelector('.ticket-badge-ok').textContent).toContain(
      'Venta registrada',
    );
  });

  it('shows no warning when every ingredient had enough stock', () => {
    const ventas = TestBed.inject(VentasApiService) as unknown as {
      stockInsuficiente: () => unknown;
    };
    ventas.stockInsuficiente = () => of([]);
    const fixture = cobrar();

    expect(fixture.nativeElement.querySelector('.stock-warning')).toBeNull();
  });
});
