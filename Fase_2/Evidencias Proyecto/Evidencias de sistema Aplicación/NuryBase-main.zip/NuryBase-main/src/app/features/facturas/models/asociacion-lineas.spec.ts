import {
  armarCatalogo,
  ArticuloCatalogo,
  AsociacionLinea,
  cantidadIngreso,
  contarPendientes,
  filtrarArticulos,
  leerEquivalencia,
  leerValorAsociacion,
  necesitaEquivalencia,
  valorAsociacion,
} from './asociacion-lineas';

describe('armarCatalogo', () => {
  it('keeps active raw materials and active products without a recipe, sorted by name', () => {
    const catalogo = armarCatalogo(
      [
        { id: 1, nombre: 'Queso gauda', activo: true, unidad_id: 1 },
        { id: 2, nombre: 'Azúcar', activo: true, unidad_id: 2 },
        { id: 3, nombre: 'Harina vieja', activo: false, unidad_id: 1 },
      ],
      [
        { id: 10, nombre: 'Pingüino', activo: true },
        { id: 11, nombre: 'Café con leche', activo: true },
        { id: 12, nombre: 'Alfajor', activo: true },
        { id: 13, nombre: 'Brownie retirado', activo: false },
      ],
      [11],
      [
        { id: 1, abreviatura: 'kg' },
        { id: 2, abreviatura: 'g' },
      ],
    );

    expect(catalogo.ingredientes).toEqual([
      { tipo: 'ingrediente', id: 2, nombre: 'Azúcar', unidad: 'g' },
      { tipo: 'ingrediente', id: 1, nombre: 'Queso gauda', unidad: 'kg' },
    ]);
    expect(catalogo.productos).toEqual([
      { tipo: 'producto', id: 12, nombre: 'Alfajor', unidad: 'un' },
      { tipo: 'producto', id: 10, nombre: 'Pingüino', unidad: 'un' },
    ]);
  });
});

describe('filtrarArticulos', () => {
  const articulos: ArticuloCatalogo[] = [
    { tipo: 'producto', id: 1, nombre: 'Pingüino Triple Choco', unidad: 'un' },
    { tipo: 'producto', id: 2, nombre: 'Brownie Chip', unidad: 'un' },
    { tipo: 'producto', id: 3, nombre: 'Brownie Dulce de Leche', unidad: 'un' },
    { tipo: 'ingrediente', id: 1, nombre: 'Chocolate en polvo', unidad: 'kg' },
  ];

  it('returns every article when the search is empty', () => {
    expect(filtrarArticulos(articulos, '   ')).toEqual(articulos);
  });

  it('ignores case and accents', () => {
    expect(filtrarArticulos(articulos, 'PINGUINO').map((a) => a.id)).toEqual([1]);
  });

  it('requires every word, in any order', () => {
    expect(filtrarArticulos(articulos, 'leche brownie').map((a) => a.nombre)).toEqual([
      'Brownie Dulce de Leche',
    ]);
  });

  it('matches raw materials and products alike', () => {
    expect(filtrarArticulos(articulos, 'choco').map((a) => a.nombre)).toEqual([
      'Pingüino Triple Choco',
      'Chocolate en polvo',
    ]);
  });

  it('keeps the chosen article even if it does not match', () => {
    const resultado = filtrarArticulos(articulos, 'leche', { tipo: 'producto', id: 2 });

    expect(resultado.map((a) => a.nombre)).toEqual(['Brownie Chip', 'Brownie Dulce de Leche']);
  });

  it('does not confuse a raw material and a product with the same id', () => {
    // Se conserva la materia prima 1 elegida, pero no el producto 1 (Pingüino).
    const resultado = filtrarArticulos(articulos, 'leche', { tipo: 'ingrediente', id: 1 });

    expect(resultado.map((a) => a.nombre)).toEqual(['Brownie Dulce de Leche', 'Chocolate en polvo']);
  });
});

describe('valorAsociacion / leerValorAsociacion', () => {
  it.each<[AsociacionLinea, string]>([
    [{ tipo: 'pendiente' }, ''],
    [{ tipo: 'no-inventario' }, 'no-inventario'],
    [{ tipo: 'ingrediente', id: 12 }, 'ingrediente:12'],
    [{ tipo: 'producto', id: 5 }, 'producto:5'],
  ])('round-trips %o', (asociacion, valor) => {
    expect(valorAsociacion(asociacion)).toBe(valor);
    expect(leerValorAsociacion(valor)).toEqual(asociacion);
  });

  it('treats an unknown value as pending', () => {
    expect(leerValorAsociacion('otro:3')).toEqual({ tipo: 'pendiente' });
  });
});

describe('contarPendientes', () => {
  const asociaciones = new Map<number, AsociacionLinea>([
    [1, { tipo: 'producto', id: 10 }],
    [2, { tipo: 'no-inventario' }],
    [3, { tipo: 'pendiente' }],
    [5, { tipo: 'ingrediente', id: 4 }],
  ]);

  it('counts lines without an article, and associated lines without an equivalence', () => {
    // 1 y 5 sin equivalencia, 3 y 4 sin artículo; 2 no necesita nada.
    expect(contarPendientes([1, 2, 3, 4, 5], asociaciones)).toBe(4);
  });

  it('stops counting an associated line once it has a valid equivalence', () => {
    const equivalencias = new Map([
      [1, '12'],
      [5, '0'],
    ]);

    expect(contarPendientes([1, 2, 3, 4, 5], asociaciones, equivalencias)).toBe(3);
  });
});

describe('leerEquivalencia', () => {
  it.each([
    ['12', 12],
    [' 6 ', 6],
    ['0,5', 0.5],
    ['1.25', 1.25],
    ['0.001', 0.001],
  ])('reads "%s" as %s', (texto, valor) => {
    expect(leerEquivalencia(texto)).toBe(valor);
  });

  it.each(['', '0', '0,000', '-1', 'doce', '1.2345', '12 un', '1e3'])('rejects "%s"', (texto) => {
    expect(leerEquivalencia(texto)).toBeNull();
  });
});

describe('cantidadIngreso', () => {
  it('multiplies the XML quantity by the equivalence', () => {
    expect(cantidadIngreso(7, 12)).toBe(84);
  });

  it('keeps three decimals, like cantidad_ingreso in the database', () => {
    expect(cantidadIngreso(3, 0.333)).toBe(0.999);
    expect(cantidadIngreso(0.1, 0.2)).toBe(0.02);
  });
});

describe('necesitaEquivalencia', () => {
  it.each<[AsociacionLinea, boolean]>([
    [{ tipo: 'ingrediente', id: 1 }, true],
    [{ tipo: 'producto', id: 1 }, true],
    [{ tipo: 'no-inventario' }, false],
    [{ tipo: 'pendiente' }, false],
  ])('%o → %s', (asociacion, esperado) => {
    expect(necesitaEquivalencia(asociacion)).toBe(esperado);
  });
});
