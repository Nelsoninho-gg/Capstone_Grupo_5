import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';

@Component({
  selector: 'app-business-tabs',
  imports: [RouterLink, RouterLinkActive],
  templateUrl: './business-tabs.html',
  styleUrl: './business-tabs.css',
})
export class BusinessTabs {}
