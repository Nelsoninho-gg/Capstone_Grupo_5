import { HttpErrorResponse } from '@angular/common/http';

/** La fila de stock ya no existe: el PATCH respondió sin filas modificadas. */
export class MinimoSinFilaError extends Error {
  constructor() {
    super('La fila de stock no existe');
    this.name = 'MinimoSinFilaError';
  }
}

export interface FalloMinimo {
  mensaje: string;
  /** El listado ya no refleja la base y conviene consultarlo de nuevo. */
  actualizarStock: boolean;
}

const SIN_CAMBIOS = 'El mínimo no se modificó.';

/**
 * Traduce el error de guardar un mínimo a un mensaje para el usuario. Cambiar el mínimo
 * fija un valor (no suma ni resta), así que reintentar nunca lo aplica dos veces.
 */
export function interpretarFalloMinimo(error: unknown): FalloMinimo {
  if (error instanceof MinimoSinFilaError) {
    return {
      mensaje:
        `Este artículo ya no tiene stock registrado en esa sucursal. ${SIN_CAMBIOS} ` +
        'Actualizamos el inventario.',
      actualizarStock: true,
    };
  }
  if (!(error instanceof HttpErrorResponse)) return falloServidor();

  const code = (error.error as { code?: string } | null)?.code ?? '';
  if (error.status === 0) {
    return {
      mensaje: `No pudimos comunicarnos con el servidor. ${SIN_CAMBIOS} Revisa la conexión e inténtalo nuevamente.`,
      actualizarStock: false,
    };
  }
  if (error.status === 401) {
    return {
      mensaje: `Tu sesión expiró. ${SIN_CAMBIOS} Vuelve a iniciar sesión para guardarlo.`,
      actualizarStock: false,
    };
  }
  // PostgREST responde 42501 (sin privilegio) con 401 si no hay sesión y 403 si la hay.
  if (error.status === 403) {
    return {
      mensaje: `Tu usuario no tiene permiso para cambiar mínimos de stock. ${SIN_CAMBIOS}`,
      actualizarStock: false,
    };
  }
  // 23514: restricción CHECK (mínimo ≥ 0, H3.5 T02); 22003: no cabe en NUMERIC(12,3).
  if (code === '23514') {
    return { mensaje: `El mínimo no puede ser negativo. ${SIN_CAMBIOS}`, actualizarStock: false };
  }
  if (code === '22003') {
    return { mensaje: `El mínimo es demasiado grande. ${SIN_CAMBIOS}`, actualizarStock: false };
  }
  return falloServidor();
}

function falloServidor(): FalloMinimo {
  return {
    mensaje: `No pudimos guardar el mínimo. ${SIN_CAMBIOS} Inténtalo nuevamente.`,
    actualizarStock: false,
  };
}
