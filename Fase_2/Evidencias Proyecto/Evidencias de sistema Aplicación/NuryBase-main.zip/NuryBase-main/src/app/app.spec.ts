import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { App } from './app';

describe('App', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [App],
      providers: [provideRouter([])],
    }).compileComponents();
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(App);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it('does not show the fullscreen coffee loader until a session starts', () => {
    const fixture = TestBed.createComponent(App);
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('.coffee-loader')).toBeNull();

    fixture.componentInstance.appLoader.start();
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('.coffee-loader.fullscreen')).not.toBeNull();
  });

  it('should have title NuryBase', () => {
    const fixture = TestBed.createComponent(App);
    const app = fixture.componentInstance;
    expect(app.title()).toBe('NuryBase');
  });
});
