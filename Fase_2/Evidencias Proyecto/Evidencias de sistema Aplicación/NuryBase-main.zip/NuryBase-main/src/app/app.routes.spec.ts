import { Component, EnvironmentInjector, runInInjectionContext } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { Router, provideRouter } from '@angular/router';
import { RouterTestingHarness } from '@angular/router/testing';
import { NEVER, of } from 'rxjs';
import { routes } from './app.routes';
import { ProductosApiService } from './core/api/productos-api.service';
import { VentasApiService } from './core/api/ventas-api.service';
import { TurnosApiService, TurnoApi } from './core/api/turnos-api.service';
import { PosService } from './features/pos/services/pos.service';

const FAKE_TURNO: TurnoApi = {
  id: 1,
  usuario_id: 1,
  sucursal_id: 1,
  hora_inicio: new Date().toISOString(),
  hora_fin: null,
  creado_en: new Date().toISOString(),
  monto_inicial: 0,
};

describe('Ruta raíz', () => {
  beforeEach(() => {
    sessionStorage.clear();
    TestBed.configureTestingModule({
      providers: [
        { provide: ProductosApiService, useValue: { listar: () => NEVER } },
        { provide: VentasApiService, useValue: { registrar: () => of(999) } },
        { provide: TurnosApiService, useValue: { abrir: () => of(FAKE_TURNO), cerrar: () => of(FAKE_TURNO) } },
      ],
    });
  });

  function resolveRoot(): unknown {
    const redirect = routes[0].redirectTo as () => string;
    return runInInjectionContext(TestBed.inject(EnvironmentInjector), () => redirect());
  }

  it('sends the cashier to Caja when no shift is open', () => {
    expect(resolveRoot()).toBe('caja');
  });

  it('resumes the POS when the shift is still open', () => {
    TestBed.inject(PosService).abrirTurno(1, 1, 0).subscribe();

    expect(resolveRoot()).toBe('pos');
  });
});

@Component({ template: '' })
class PaginaVacia {}

describe('Ruta antigua de Ingredientes (H3.3 T04)', () => {
  it('redirects to the Ingredients tab of the Product Master', async () => {
    const antigua = routes
      .flatMap((ruta) => [ruta, ...(ruta.children ?? [])])
      .find((ruta) => ruta.path === 'inventario/ingredientes');
    expect(antigua?.redirectTo).toBeDefined();

    TestBed.configureTestingModule({
      providers: [provideRouter([antigua!, { path: 'product-master', component: PaginaVacia }])],
    });
    const harness = await RouterTestingHarness.create();
    await harness.navigateByUrl('/inventario/ingredientes');

    expect(TestBed.inject(Router).url).toBe('/product-master?vista=ingredientes');
  });
});
