import { signal } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { User } from '../../features/auth/models/auth.model';
import { AuthService } from '../../features/auth/services/auth.service';
import { PosService } from '../../features/pos/services/pos.service';
import { Sidebar } from './sidebar';

describe('Sidebar', () => {
  let component: Sidebar;
  let fixture: ComponentFixture<Sidebar>;
  const currentUser = signal<User | null>(null);
  const isRegisterOpen = signal(false);
  const sincronizandoTurno = signal(false);
  const logout = vi.fn();

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Sidebar],
      providers: [
        provideRouter([]),
        { provide: AuthService, useValue: { currentUser, logout } },
        { provide: PosService, useValue: { isRegisterOpen, requiereCierreTurno: () => isRegisterOpen() || sincronizandoTurno() } },
      ],
    }).compileComponents();

    currentUser.set(null);
    isRegisterOpen.set(false);
    sincronizandoTurno.set(false);
    logout.mockClear();
    fixture = TestBed.createComponent(Sidebar);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('shows cashier operations and the product master outside Administration', () => {
    currentUser.set(createUser('cajero'));
    fixture.detectChanges();

    expect(visibleMenuRoutes()).toEqual(['/pos', '/caja', '/anulacion-venta', '/product-master']);
    expect((fixture.nativeElement as HTMLElement).querySelector('.nav-group-toggle')).toBeNull();
  });

  it('should show inventory and the product master (ingredients) but hide POS from a warehouse user', () => {
    currentUser.set(createUser('bodeguero'));
    fixture.detectChanges();

    expect(visibleMenuRoutes()).toEqual([
      '/product-master',
      '/inventario',
      '/facturas/cargar',
      '/facturas/ingresos',
    ]);
    expect((fixture.nativeElement as HTMLElement).querySelector('.nav-group-toggle')).toBeNull();
  });

  it('should show every available function to an administrator', () => {
    currentUser.set(createUser('admin'));
    fixture.detectChanges();

    expect(visibleMenuRoutes()).toEqual([
      '/pos',
      '/caja',
      '/anulacion-venta',
      '/product-master',
      '/inventario',
      '/facturas',
    ]);
    expect((fixture.nativeElement as HTMLElement).querySelector('.nav-group-toggle')).toBeTruthy();
  });

  it('should expand Administration and show the Gestión Negocio link only to an administrator', () => {
    currentUser.set(createUser('admin'));
    fixture.detectChanges();

    const host = fixture.nativeElement as HTMLElement;
    const toggle = host.querySelector('.nav-group-toggle') as HTMLButtonElement;
    expect(toggle.getAttribute('aria-expanded')).toBe('false');
    expect(host.querySelector('.sidebar-submenu')).toBeNull();

    toggle.click();
    fixture.detectChanges();
    expect(toggle.getAttribute('aria-expanded')).toBe('true');
    expect(host.querySelector('.sidebar-submenu a')?.getAttribute('href')).toBe('/gestion-negocio');
    expect(host.querySelector('.sidebar-submenu a[href="/anulacion-venta"]')).toBeNull();
    expect(host.querySelectorAll('a[href="/anulacion-venta"]')).toHaveLength(1);

    toggle.click();
    fixture.detectChanges();
    expect(host.querySelector('.sidebar-submenu')).toBeNull();
  });

  it('should not render role-specific links without a database-authenticated user', () => {
    fixture.detectChanges();

    expect(visibleMenuRoutes()).toEqual([]);
  });

  it('should show the logout button independently of the user role', () => {
    currentUser.set(createUser('bodeguero'));
    fixture.detectChanges();

    const logoutButton = (fixture.nativeElement as HTMLElement).querySelector(
      '.logout-btn',
    ) as HTMLButtonElement | null;
    expect(logoutButton).toBeTruthy();
    expect(logoutButton?.textContent).toContain('Cerrar sesión');

    logoutButton?.click();
    expect(logout).toHaveBeenCalledOnce();
  });

  it('should prevent a cashier from logging out while the register is open', () => {
    currentUser.set(createUser('cajero'));
    isRegisterOpen.set(true);
    fixture.detectChanges();

    const logoutButton = (fixture.nativeElement as HTMLElement).querySelector(
      '.logout-btn',
    ) as HTMLButtonElement | null;
    logoutButton?.click();
    fixture.detectChanges();

    expect(logout).not.toHaveBeenCalled();
    expect(
      (fixture.nativeElement as HTMLElement).querySelector('.sidebar-logout-overlay'),
    ).toBeTruthy();
  });

  it('should open and close the mobile menu', () => {
    fixture.detectChanges();
    const menuButton = (fixture.nativeElement as HTMLElement).querySelector(
      '.mobile-menu-toggle',
    ) as HTMLButtonElement;
    const sidebar = (fixture.nativeElement as HTMLElement).querySelector('.sidebar') as HTMLElement;

    menuButton.click();
    fixture.detectChanges();
    expect(sidebar.classList.contains('mobile-open')).toBe(true);

    const closeButton = (fixture.nativeElement as HTMLElement).querySelector(
      '.mobile-close-btn',
    ) as HTMLButtonElement;
    closeButton.click();
    fixture.detectChanges();
    expect(sidebar.classList.contains('mobile-open')).toBe(false);
  });

  it('waits for shift verification before allowing a cashier to log out', () => {
    currentUser.set(createUser('cajero'));
    sincronizandoTurno.set(true);
    fixture.detectChanges();
    (fixture.nativeElement.querySelector('.logout-btn') as HTMLButtonElement).click();
    fixture.detectChanges();
    expect(logout).not.toHaveBeenCalled();
    expect(fixture.nativeElement.querySelector('.sidebar-logout-overlay')).toBeTruthy();
  });

  function visibleMenuRoutes(): string[] {
    const host = fixture.nativeElement as HTMLElement;
    const links = host.querySelectorAll<HTMLAnchorElement>('.sidebar-nav a');
    return Array.from(links).map((element) => element.getAttribute('href') ?? '');
  }

  function createUser(rol: User['rol']): User {
    return {
      id: 1,
      nombre: 'Usuario de prueba',
      identificadorAcceso: 'usuario@nurys.cl',
      rol,
      sucursalId: 1,
      sucursalNombre: 'Nury Providencia',
      activo: true,
    };
  }
});
