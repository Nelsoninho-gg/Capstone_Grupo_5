import { DOCUMENT, DestroyRef, Injectable, inject, signal } from '@angular/core';
import { Observable, Subject } from 'rxjs';

/**
 * Estado de la conexión del navegador, para avisar cuando los datos en pantalla
 * pueden estar desactualizados y volver a consultarlos al recuperarla (H3.4 T07).
 *
 * Hoy se basa en los eventos `online`/`offline` del navegador; el canal de
 * tiempo real (H3.4 T06) podrá sumar aquí su propio estado de conexión.
 */
@Injectable({
  providedIn: 'root',
})
export class ConexionService {
  private readonly ventana = inject(DOCUMENT).defaultView;
  private readonly navegadorEnLinea = signal(this.ventana?.navigator.onLine ?? true);
  private readonly reconexiones = new Subject<void>();

  readonly enLinea = this.navegadorEnLinea.asReadonly();

  /**
   * Emite cada vez que vuelve la conexión. Es un evento y no solo el cambio del
   * signal, para no perder un corte breve que ocurra entre dos renderizados.
   */
  readonly alReconectar: Observable<void> = this.reconexiones.asObservable();

  constructor() {
    const ventana = this.ventana;
    if (!ventana) return;

    const alConectar = () => {
      this.navegadorEnLinea.set(true);
      this.reconexiones.next();
    };
    const alDesconectar = () => this.navegadorEnLinea.set(false);

    ventana.addEventListener('online', alConectar);
    ventana.addEventListener('offline', alDesconectar);
    inject(DestroyRef).onDestroy(() => {
      ventana.removeEventListener('online', alConectar);
      ventana.removeEventListener('offline', alDesconectar);
      this.reconexiones.complete();
    });
  }
}
