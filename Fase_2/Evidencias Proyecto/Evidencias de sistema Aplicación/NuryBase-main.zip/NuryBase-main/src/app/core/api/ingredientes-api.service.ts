import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

export interface IngredienteApi {
  id: number;
  nombre: string;
  categoria_id: number | null;
  unidad_id: number;
  costo_unitario_promedio: number | string;
  codigo_barras: string | null;
  activo: boolean;
  creado_en: string;
  actualizado_en: string;
}

export type IngredienteCreacion = Pick<IngredienteApi, 'nombre' | 'unidad_id' | 'categoria_id' | 'codigo_barras'>;

// La unidad de medida queda fija al crear el ingrediente y nunca se puede modificar
// (protege los cálculos de recetas y el historial de movimientos de stock).
export type IngredienteActualizacion = Pick<
  IngredienteApi,
  'nombre' | 'categoria_id' | 'codigo_barras' | 'activo'
>;

const INGREDIENTE_FIELDS =
  'id,nombre,categoria_id,unidad_id,costo_unitario_promedio,codigo_barras,activo,creado_en,actualizado_en';

@Injectable({
  providedIn: 'root',
})
export class IngredientesApiService {
  private readonly http = inject(HttpClient);
  private readonly url = `${environment.apiUrl}/ingredientes`;

  listar(soloActivos = true): Observable<IngredienteApi[]> {
    const params: Record<string, string> = {
      select: INGREDIENTE_FIELDS,
      order: 'nombre.asc',
    };

    if (soloActivos) {
      params['activo'] = 'eq.true';
    }

    return this.http.get<IngredienteApi[]>(this.url, {
      params,
    });
  }

  crear(ingrediente: IngredienteCreacion): Observable<IngredienteApi> {
    return this.http
      .post<IngredienteApi[]>(this.url, ingrediente, {
        headers: { Prefer: 'return=representation' },
        params: { select: INGREDIENTE_FIELDS },
      })
      .pipe(
        map(([ingredienteCreado]) => {
          if (!ingredienteCreado) {
            throw new Error('El ingrediente no pudo ser creado.');
          }

          return ingredienteCreado;
        }),
      );
  }

  /** Solo se envían los campos dados (PATCH): lo que no viene queda como está. */
  actualizar(id: number, cambios: Partial<IngredienteActualizacion>): Observable<IngredienteApi> {
    return this.http
      .patch<IngredienteApi[]>(this.url, cambios, {
        headers: { Prefer: 'return=representation' },
        params: {
          id: `eq.${id}`,
          select: INGREDIENTE_FIELDS,
        },
      })
      .pipe(
        map(([ingrediente]) => {
          if (!ingrediente) {
            throw new Error('El ingrediente no existe o no pudo ser actualizado.');
          }

          return ingrediente;
        }),
      );
  }

  actualizarEstado(id: number, activo: boolean): Observable<IngredienteApi> {
    return this.http
      .patch<IngredienteApi[]>(
        this.url,
        { activo },
        {
          headers: { Prefer: 'return=representation' },
          params: {
            id: `eq.${id}`,
            select: INGREDIENTE_FIELDS,
          },
        },
      )
      .pipe(
        map(([ingrediente]) => {
          if (!ingrediente) {
            throw new Error('El ingrediente no existe o no pudo cambiar de estado.');
          }

          return ingrediente;
        }),
      );
  }
}
