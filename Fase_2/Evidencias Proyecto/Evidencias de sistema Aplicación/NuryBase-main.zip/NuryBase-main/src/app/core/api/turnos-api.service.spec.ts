import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { firstValueFrom } from 'rxjs';
import { environment } from '../../../environments/environment';
import { TurnosApiService } from './turnos-api.service';

describe('TurnosApiService — recuperación', () => {
  it('recovers the authenticated shift without sending a user ID or opening another shift', async () => {
    TestBed.configureTestingModule({ providers: [provideHttpClient(), provideHttpClientTesting()] });
    const http = TestBed.inject(HttpTestingController);
    const result = firstValueFrom(TestBed.inject(TurnosApiService).recuperar());
    const request = http.expectOne(`${environment.apiUrl}/rpc/fn_recuperar_turno`);
    expect(request.request.method).toBe('POST');
    expect(request.request.body).toEqual({});
    request.flush({ turno: null, ventas: [] });
    await expect(result).resolves.toEqual({ turno: null, ventas: [] });
    http.verify();
  });
});
