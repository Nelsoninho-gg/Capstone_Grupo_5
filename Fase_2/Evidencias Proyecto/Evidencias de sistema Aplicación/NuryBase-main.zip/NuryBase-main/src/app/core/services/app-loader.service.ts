import { Injectable, Signal, computed, effect, signal, untracked } from '@angular/core';
import { LoadStatus } from '../../shared/components/coffee-loader/coffee-loader';

/** Margen para que la vista recién creada alcance a sumarse antes de dar la carga por terminada. */
export const NAVIGATION_SETTLE_MS = 50;

interface LoaderTask {
  status: Signal<LoadStatus>;
  retry?: () => void;
}

/**
 * Carga de pantalla completa que acompaña la entrada a la app tras iniciar sesión.
 *
 * Dura mientras se navega a la vista de destino y mientras las vistas que se
 * sumen (`join`) cargan sus datos; así el usuario ve una sola taza y un solo
 * soplido aunque la vista tenga su propia carga (p. ej. el catálogo del POS).
 */
@Injectable({
  providedIn: 'root',
})
export class AppLoaderService {
  private readonly active = signal(false);
  private readonly navigating = signal(false);
  private readonly navigationRetry = signal<(() => void) | null>(null);
  private readonly tasks = signal<LoaderTask[]>([]);

  readonly status = computed<LoadStatus>(() => {
    if (!this.active()) return 'ready';
    const statuses = this.tasks().map((task) => task.status());
    if (this.navigationRetry() || statuses.includes('error')) return 'error';
    return this.navigating() || statuses.includes('loading') ? 'loading' : 'ready';
  });

  constructor() {
    // Cuando todo terminó, la carga se cierra: una vista que recargue después
    // sus datos ya no vuelve a mostrar la taza a pantalla completa.
    effect(() => {
      if (this.active() && this.status() === 'ready') {
        untracked(() => {
          this.active.set(false);
          this.tasks.set([]);
        });
      }
    });
  }

  /** Inicia la carga justo antes de navegar a la vista de destino. */
  start(): void {
    this.tasks.set([]);
    this.navigationRetry.set(null);
    this.navigating.set(true);
    this.active.set(true);
  }

  navigationDone(): void {
    setTimeout(() => this.navigating.set(false), NAVIGATION_SETTLE_MS);
  }

  /** La navegación falló (p. ej. sin conexión para descargar la vista). */
  navigationFailed(retry: () => void): void {
    this.navigating.set(false);
    this.navigationRetry.set(retry);
  }

  /**
   * Una vista suma su propia carga a la de pantalla completa, si está en curso.
   * Devuelve `false` si no hay carga activa: la vista debe mostrar su propio loader.
   */
  join(status: Signal<LoadStatus>, retry?: () => void): boolean {
    if (!this.active()) return false;
    this.tasks.update((tasks) => [...tasks, { status, retry }]);
    return true;
  }

  retry(): void {
    const retryNavigation = this.navigationRetry();
    if (retryNavigation) {
      this.navigationRetry.set(null);
      retryNavigation();
      return;
    }
    this.tasks()
      .filter((task) => task.status() === 'error')
      .forEach((task) => task.retry?.());
  }
}
