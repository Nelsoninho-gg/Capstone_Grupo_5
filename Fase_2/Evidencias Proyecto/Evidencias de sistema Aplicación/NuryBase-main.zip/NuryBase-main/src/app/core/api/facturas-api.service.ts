import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

/** Qué hacer con una línea del XML al ingresar la factura. */
export interface LineaIngresoFactura {
  numero_linea: number;
  ingrediente_id?: number;
  producto_id?: number;
  no_corresponde_inventario?: boolean;
  /** Unidades del catálogo por presentación; solo en líneas con artículo. */
  unidades_por_presentacion?: number;
}

/** La factura ya estaba ingresada: el servidor registró el intento (H3.7 T07) y no guardó nada más. */
export interface IngresoYaExistente {
  ya_ingresada: true;
  intento_id: number;
}

export interface ResultadoIngresoFactura {
  factura_compra_id: number;
  factura_xml_id: number;
  lineas_inventario: number;
  lineas_no_inventario: number;
}

/**
 * Respuesta de `fn_consultar_factura_ingresada` (H3.7 T03). El detalle solo llega si
 * `puede_ver_detalle`: un bodeguero de otra sucursal únicamente sabe que ya existe.
 */
export interface ConsultaFacturaIngresada {
  identificacion_completa: boolean;
  ingresada: boolean;
  puede_ver_detalle?: boolean;
  sucursal?: string;
  ingresada_en?: string;
  ingresada_por?: string;
  ingresada_por_ti?: boolean;
  lineas_inventario?: number;
  lineas_no_inventario?: number;
}

/** Línea de una factura ya ingresada, con lo que se hizo con ella (H3.1 T09). */
export interface LineaIngresoRealizado {
  numero_linea: number;
  codigo_proveedor: string | null;
  descripcion: string;
  cantidad: number;
  precio_unitario: number;
  monto: number;
  tipo: 'ingrediente' | 'producto' | 'no-inventario';
  articulo: string | null;
  unidad: string | null;
  unidades_por_presentacion: number | null;
  cantidad_ingreso: number | null;
}

export interface IntentoDuplicado {
  creado_en: string;
  usuario: string | null;
  sucursal_solicitada: string | null;
  xml_nombre: string | null;
}

/** Factura ingresada, como la devuelve `fn_listar_ingresos_factura`. */
export interface IngresoFactura {
  factura_xml_id: number;
  factura_compra_id: number;
  folio: number;
  rut_emisor: string;
  razon_social_emisor: string | null;
  proveedor: string | null;
  fecha_emision: string;
  monto_neto: number;
  monto_iva: number;
  monto_total: number;
  detalle_incluye_iva: boolean;
  xml_nombre: string | null;
  sucursal_id: number;
  sucursal: string | null;
  ingresada_por: string | null;
  ingresada_en: string;
  lineas: LineaIngresoRealizado[];
  intentos_duplicados: IntentoDuplicado[];
}

export interface XmlFactura {
  xml_nombre: string;
  xml_base64: string;
}

/**
 * Ingreso de facturas XML (H3.1 T08). Todo ocurre en `fn_ingresar_factura_xml`
 * (database/migrations/20261017_ingresar_factura_xml.sql): el servidor vuelve a leer
 * el XML, valida permiso, sucursal y duplicados, y guarda factura, líneas y stock en
 * una sola transacción.
 */
@Injectable({ providedIn: 'root' })
export class FacturasApiService {
  private readonly http = inject(HttpClient);
  private readonly url = `${environment.apiUrl}/rpc/fn_ingresar_factura_xml`;

  /** ¿Ya hay un ingreso confirmado con esta identidad? (database/migrations/20261020_consultar_factura_ingresada.sql) */
  consultarIngresada(rut: string, tipo: number, folio: number): Observable<ConsultaFacturaIngresada> {
    return this.http.post<ConsultaFacturaIngresada>(`${environment.apiUrl}/rpc/fn_consultar_factura_ingresada`, {
      p_rut_emisor: rut,
      p_tipo_documento: tipo,
      p_folio: folio,
    });
  }

  /** Facturas ingresadas que el usuario puede ver (database/migrations/20261020_consulta_ingresos_factura.sql). */
  listarIngresos(): Observable<IngresoFactura[]> {
    return this.http.post<IngresoFactura[]>(`${environment.apiUrl}/rpc/fn_listar_ingresos_factura`, {});
  }

  /** XML original de una factura ingresada, en base64. */
  descargarXml(facturaXmlId: number): Observable<XmlFactura> {
    return this.http.post<XmlFactura>(`${environment.apiUrl}/rpc/fn_xml_factura`, {
      p_factura_xml_id: facturaXmlId,
    });
  }

  ingresar(
    sucursalId: number,
    xml: Uint8Array,
    nombreArchivo: string,
    lineas: LineaIngresoFactura[],
  ): Observable<ResultadoIngresoFactura | IngresoYaExistente> {
    return this.http.post<ResultadoIngresoFactura | IngresoYaExistente>(this.url, {
      p_sucursal_id: sucursalId,
      p_xml_base64: aBase64(xml),
      p_xml_nombre: nombreArchivo,
      p_lineas: lineas,
    });
  }
}

/** Bytes del archivo en base64, en tramos para no exceder el límite de argumentos. */
export function aBase64(bytes: Uint8Array): string {
  let binario = '';
  const tramo = 0x8000;
  for (let inicio = 0; inicio < bytes.length; inicio += tramo) {
    binario += String.fromCharCode(...bytes.subarray(inicio, inicio + tramo));
  }
  return btoa(binario);
}
