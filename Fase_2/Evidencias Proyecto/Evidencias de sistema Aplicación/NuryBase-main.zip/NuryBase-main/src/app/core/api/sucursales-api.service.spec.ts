import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { firstValueFrom } from 'rxjs';
import { environment } from '../../../environments/environment';
import { SucursalApi, SucursalCreacion, SucursalesApiService } from './sucursales-api.service';

const BRANCH_URL = `${environment.apiUrl}/sucursales`;
const BRANCH_FIELDS = 'id,nombre,direccion,telefono,activo,creado_en';

describe('SucursalesApiService', () => {
  let service: SucursalesApiService;
  let http: HttpTestingController;
  const branch: SucursalApi = {
    id: 4,
    nombre: 'Nury Providencia',
    direccion: 'Av. Providencia 123',
    telefono: '+56 9 1234 5678',
    activo: true,
    creado_en: '2026-09-30T12:00:00',
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()],
    });
    service = TestBed.inject(SucursalesApiService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  it('lists active and inactive branches with all management fields', async () => {
    const result = firstValueFrom(service.listar());
    const request = http.expectOne((req) => req.method === 'GET' && req.url === BRANCH_URL);
    expect(request.request.params.get('select')).toBe(BRANCH_FIELDS);
    expect(request.request.params.get('order')).toBe('id.asc');
    expect(request.request.params.has('activo')).toBe(false);
    const branches = [branch, { ...branch, id: 5, activo: false }];
    request.flush(branches);
    await expect(result).resolves.toEqual(branches);
  });

  it('keeps the active-only alphabetical list used by the user form', async () => {
    const result = firstValueFrom(service.listarActivas());
    const request = http.expectOne((req) => req.method === 'GET' && req.url === BRANCH_URL);
    expect(request.request.params.get('activo')).toBe('eq.true');
    expect(request.request.params.get('order')).toBe('nombre.asc');
    request.flush([branch]);
    await expect(result).resolves.toEqual([branch]);
  });

  it('creates a branch through the RPC and returns the stored row', async () => {
    const input: SucursalCreacion = {
      nombre: branch.nombre,
      direccion: null,
      telefono: null,
      activo: false,
    };
    const result = firstValueFrom(service.crear(input));
    const request = http.expectOne(`${environment.apiUrl}/rpc/crear_sucursal`);
    expect(request.request.method).toBe('POST');
    expect(request.request.body).toEqual({
      p_nombre: input.nombre,
      p_direccion: null,
      p_telefono: null,
      p_activo: false,
    });
    const created = { ...branch, ...input };
    request.flush([created]);
    await expect(result).resolves.toEqual(created);
  });

  it('updates only the selected branch and requests its resulting row', async () => {
    const changes = { direccion: 'Nueva dirección', telefono: null };
    const result = firstValueFrom(service.actualizar(branch.id, changes));
    const request = http.expectOne((req) => req.method === 'PATCH' && req.url === BRANCH_URL);
    expect(request.request.params.get('id')).toBe('eq.4');
    expect(request.request.params.get('select')).toBe(BRANCH_FIELDS);
    expect(request.request.headers.get('Prefer')).toBe('return=representation');
    expect(request.request.body).toEqual(changes);
    const updated = { ...branch, ...changes };
    request.flush([updated]);
    await expect(result).resolves.toEqual(updated);
  });

  it('changes the active state without changing other branch fields', async () => {
    const result = firstValueFrom(service.actualizarEstado(branch.id, false));
    const request = http.expectOne((req) => req.method === 'PATCH' && req.url === BRANCH_URL);
    expect(request.request.params.get('id')).toBe('eq.4');
    expect(request.request.body).toEqual({ activo: false });
    request.flush([{ ...branch, activo: false }]);
    await expect(result).resolves.toMatchObject({ activo: false });
  });

  it('rejects an update when the API returns no matching branch', async () => {
    const result = firstValueFrom(service.actualizar(9999, { nombre: 'No existe' }));
    const rejected = expect(result).rejects.toThrow('La sucursal no existe o no pudo ser actualizada.');
    http.expectOne((req) => req.method === 'PATCH' && req.url === BRANCH_URL).flush([]);
    await rejected;
  });

  it('rejects creation when the API returns no created row', async () => {
    const result = firstValueFrom(service.crear(branch));
    const rejected = expect(result).rejects.toThrow('La sucursal no existe o no pudo ser creada.');
    http.expectOne(`${environment.apiUrl}/rpc/crear_sucursal`).flush([]);
    await rejected;
  });

  it('propagates duplicate-name errors for the form to handle', async () => {
    const result = firstValueFrom(service.crear(branch));
    const rejected = expect(result).rejects.toMatchObject({ status: 409 });
    http.expectOne(`${environment.apiUrl}/rpc/crear_sucursal`).flush(
      { code: '23505', message: 'duplicate key value violates unique constraint' },
      { status: 409, statusText: 'Conflict' },
    );
    await rejected;
  });
});
