import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

export interface RecetaApi {
  id: number;
  producto_id: number;
  ingrediente_id: number;
  cantidad_necesaria: number | string;
  unidad_id: number;
}

export type RecetaCreacion = Pick<
  RecetaApi,
  'producto_id' | 'ingrediente_id' | 'cantidad_necesaria' | 'unidad_id'
>;

// Solo la cantidad se puede ajustar. producto_id/ingrediente_id no cambian
// (si se necesita otro insumo, se quita esta fila y se agrega una nueva) y
// unidad_id no se envía: siempre debe ser la misma unidad del ingrediente,
// que ya quedó fija al crear la receta (ver fn_aplicar_venta, no hay
// conversión de unidades).
export type RecetaActualizacion = Pick<RecetaApi, 'cantidad_necesaria'>;

const RECETA_FIELDS = 'id,producto_id,ingrediente_id,cantidad_necesaria,unidad_id';

/** Un insumo agregado, quitado o con otra cantidad respecto de la versión anterior. */
export interface CambioRecetaApi {
  tipo: 'agregado' | 'quitado' | 'modificado';
  ingrediente: string;
  unidad: string | null;
  antes: number | null;
  despues: number | null;
}

/** Una versión de la receta (H2.5 T02): se crea sola cada vez que se edita la receta. */
export interface VersionRecetaApi {
  numero: number;
  vigente_desde: string;
  /** Nombre de quien la editó; null en la carga inicial. */
  creada_por: string | null;
  /** Cantidad de insumos de esa versión; 0 si se quitaron todos (producto simple). */
  insumos: number;
  /** Qué cambió respecto de la versión anterior; null en la primera. */
  cambios: CambioRecetaApi[] | null;
}

@Injectable({
  providedIn: 'root',
})
export class RecetasApiService {
  private readonly http = inject(HttpClient);
  private readonly url = `${environment.apiUrl}/recetas`;

  /** Lista los insumos de la receta de un producto (vacío si es un producto simple). */
  listarPorProducto(productoId: number): Observable<RecetaApi[]> {
    return this.http.get<RecetaApi[]>(this.url, {
      params: {
        select: RECETA_FIELDS,
        producto_id: `eq.${productoId}`,
        order: 'id.asc',
      },
    });
  }

  /** IDs de productos que tienen receta (los demás son de reventa y llevan stock propio). */
  listarIdsProductosConReceta(): Observable<number[]> {
    return this.http
      .get<Pick<RecetaApi, 'producto_id'>[]>(this.url, {
        params: { select: 'producto_id' },
      })
      .pipe(map((filas) => [...new Set(filas.map((fila) => fila.producto_id))]));
  }

  agregar(receta: RecetaCreacion): Observable<RecetaApi> {
    return this.http
      .post<RecetaApi[]>(this.url, receta, {
        headers: { Prefer: 'return=representation' },
        params: { select: RECETA_FIELDS },
      })
      .pipe(
        map(([recetaCreada]) => {
          if (!recetaCreada) {
            throw new Error('El insumo no pudo ser agregado a la receta.');
          }

          return recetaCreada;
        }),
      );
  }

  actualizar(id: number, cambios: RecetaActualizacion): Observable<RecetaApi> {
    return this.http
      .patch<RecetaApi[]>(this.url, cambios, {
        headers: { Prefer: 'return=representation' },
        params: {
          id: `eq.${id}`,
          select: RECETA_FIELDS,
        },
      })
      .pipe(
        map(([receta]) => {
          if (!receta) {
            throw new Error('El insumo de la receta no existe o no pudo ser actualizado.');
          }

          return receta;
        }),
      );
  }

  /** Versiones de la receta del producto, de la más nueva a la más antigua. */
  listarVersiones(productoId: number): Observable<VersionRecetaApi[]> {
    return this.http.post<VersionRecetaApi[]>(`${environment.apiUrl}/rpc/fn_versiones_receta`, {
      p_producto_id: productoId,
    });
  }

  /** Quita un insumo de la receta. No hay borrado lógico: esta tabla no tiene columna `activo`. */
  eliminar(id: number): Observable<RecetaApi> {
    return this.http
      .delete<RecetaApi[]>(this.url, {
        headers: { Prefer: 'return=representation' },
        params: {
          id: `eq.${id}`,
          select: RECETA_FIELDS,
        },
      })
      .pipe(
        map(([receta]) => {
          if (!receta) {
            throw new Error('El insumo de la receta no existe o no pudo ser eliminado.');
          }

          return receta;
        }),
      );
  }
}
