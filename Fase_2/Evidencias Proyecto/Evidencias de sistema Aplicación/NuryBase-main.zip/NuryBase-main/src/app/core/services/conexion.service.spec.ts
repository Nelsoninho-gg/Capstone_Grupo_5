import { TestBed } from '@angular/core/testing';
import { ConexionService } from './conexion.service';

describe('ConexionService', () => {
  afterEach(() => vi.restoreAllMocks());

  it('starts with the browser connection state', () => {
    vi.spyOn(navigator, 'onLine', 'get').mockReturnValue(false);

    expect(TestBed.inject(ConexionService).enLinea()).toBe(false);
  });

  it('follows the offline and online events and notifies each reconnection', () => {
    const service = TestBed.inject(ConexionService);
    const reconexiones = vi.fn();
    service.alReconectar.subscribe(reconexiones);
    expect(service.enLinea()).toBe(true);

    window.dispatchEvent(new Event('offline'));
    expect(service.enLinea()).toBe(false);
    expect(reconexiones).not.toHaveBeenCalled();

    window.dispatchEvent(new Event('online'));
    expect(service.enLinea()).toBe(true);
    expect(reconexiones).toHaveBeenCalledTimes(1);

    // Un corte breve también cuenta, aunque el estado final sea el mismo.
    window.dispatchEvent(new Event('offline'));
    window.dispatchEvent(new Event('online'));
    expect(reconexiones).toHaveBeenCalledTimes(2);
  });

  it('stops listening when the app is destroyed', () => {
    const service = TestBed.inject(ConexionService);
    const reconexiones = vi.fn();
    service.alReconectar.subscribe({ next: reconexiones, complete: reconexiones });

    TestBed.resetTestingModule();
    reconexiones.mockClear();
    window.dispatchEvent(new Event('online'));

    expect(reconexiones).not.toHaveBeenCalled();
  });
});
