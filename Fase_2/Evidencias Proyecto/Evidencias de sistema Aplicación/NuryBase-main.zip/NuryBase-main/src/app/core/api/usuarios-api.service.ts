import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

/** Campos de usuario que se pueden consultar sin exponer credenciales. */
export interface UsuarioApi {
  id: number;
  nombre: string;
  identificador_acceso: string;
  rol: 'admin' | 'administrador' | 'cajero' | 'bodeguero';
  sucursal_id: number | null;
  debe_cambiar_password: boolean;
  activo: boolean;
  creado_en: string;
  actualizado_en: string;
}

export type UsuarioCreacion = Pick<
  UsuarioApi,
  | 'nombre'
  | 'identificador_acceso'
  | 'rol'
  | 'sucursal_id'
  | 'debe_cambiar_password'
  | 'activo'
> & {
  /** El RPC genera y guarda el hash en PostgreSQL. */
  contrasena: string;
};

export type UsuarioActualizacion = Partial<
  Pick<
    UsuarioApi,
    | 'nombre'
    | 'identificador_acceso'
    | 'rol'
    | 'sucursal_id'
    | 'debe_cambiar_password'
    | 'activo'
  >
> & {
  /** Si se cambia la contraseña, enviar solo su hash seguro. */
  password_hash?: string;
};

/** Empleado que puede comprar con descuento en el POS (H2.12): solo id y nombre. */
export interface EmpleadoApi {
  id: number;
  nombre: string;
}

const USER_FIELDS =
  'id,nombre,identificador_acceso,rol,sucursal_id,debe_cambiar_password,activo,creado_en,actualizado_en';

/** Acceso CRUD a `public.usuarios` mediante los endpoints REST de PostgREST. */
@Injectable({ providedIn: 'root' })
export class UsuariosApiService {
  private readonly http = inject(HttpClient);
  private readonly url = `${environment.apiUrl}/usuarios`;
  private readonly crearUrl = `${environment.apiUrl}/rpc/crear_usuario`;
  private readonly empleadosUrl = `${environment.apiUrl}/rpc/fn_listar_empleados`;

  listar(): Observable<UsuarioApi[]> {
    return this.http.get<UsuarioApi[]>(this.url, {
      params: {
        select: USER_FIELDS,
        order: 'id.asc',
      },
    });
  }

  /**
   * Usuarios activos para elegir al empleado en una venta a empleado. Usa el RPC
   * `fn_listar_empleados` porque el cajero no tiene acceso a la tabla `usuarios`.
   */
  listarEmpleados(): Observable<EmpleadoApi[]> {
    return this.http.get<EmpleadoApi[]>(this.empleadosUrl);
  }

  crear(usuario: UsuarioCreacion): Observable<UsuarioApi> {
    return this.http
      .post<UsuarioApi[]>(this.crearUrl, {
        p_nombre: usuario.nombre,
        p_identificador_acceso: usuario.identificador_acceso,
        p_contrasena: usuario.contrasena,
        p_rol: usuario.rol,
        p_sucursal_id: usuario.sucursal_id,
        p_debe_cambiar_password: usuario.debe_cambiar_password,
        p_activo: usuario.activo,
      })
      .pipe(map(([creado]) => this.exigirUsuario(creado, 'creado')));
  }

  actualizar(id: number, cambios: UsuarioActualizacion): Observable<UsuarioApi> {
    return this.http
      .patch<UsuarioApi[]>(this.url, cambios, {
        headers: { Prefer: 'return=representation' },
        params: {
          id: `eq.${id}`,
          select: USER_FIELDS,
        },
      })
      .pipe(map(([actualizado]) => this.exigirUsuario(actualizado, 'actualizado')));
  }

  eliminar(id: number): Observable<UsuarioApi> {
    return this.http
      .delete<UsuarioApi[]>(this.url, {
        headers: { Prefer: 'return=representation' },
        params: {
          id: `eq.${id}`,
          select: USER_FIELDS,
        },
      })
      .pipe(map(([eliminado]) => this.exigirUsuario(eliminado, 'eliminado')));
  }

  private exigirUsuario(usuario: UsuarioApi | undefined, accion: string): UsuarioApi {
    if (!usuario) {
      throw new Error(`El usuario no existe o no pudo ser ${accion}.`);
    }

    return usuario;
  }
}
