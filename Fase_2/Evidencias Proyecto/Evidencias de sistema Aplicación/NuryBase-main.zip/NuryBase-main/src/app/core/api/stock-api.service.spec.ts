import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { firstValueFrom } from 'rxjs';
import { environment } from '../../../environments/environment';
import { MovimientoStockApi, StockApiService } from './stock-api.service';

describe('StockApiService', () => {
  let service: StockApiService;
  let httpMock: HttpTestingController;
  const base = environment.apiUrl;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()],
    });
    service = TestBed.inject(StockApiService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => httpMock.verify());

  it('obtiene el stock de un producto como número', async () => {
    const promesa = firstValueFrom(service.obtenerStockProducto(4, 1));
    const req = httpMock.expectOne((r) => r.url === `${base}/stock_producto_sucursal`);
    expect(req.request.params.get('producto_id')).toBe('eq.4');
    expect(req.request.params.get('sucursal_id')).toBe('eq.1');
    req.flush([{ stock_actual: '12.000' }]);
    expect(await promesa).toBe(12);
  });

  it('devuelve 0 si el producto no tiene fila de stock', async () => {
    const promesa = firstValueFrom(service.obtenerStockProducto(4, 1));
    httpMock.expectOne((r) => r.url === `${base}/stock_producto_sucursal`).flush([]);
    expect(await promesa).toBe(0);
  });

  it('obtiene el stock de un ingrediente', async () => {
    const promesa = firstValueFrom(service.obtenerStockIngrediente(3, 1));
    const req = httpMock.expectOne((r) => r.url === `${base}/stock_sucursal`);
    expect(req.request.params.get('ingrediente_id')).toBe('eq.3');
    req.flush([{ stock_actual: 2 }]);
    expect(await promesa).toBe(2);
  });

  it('lista el stock de ingredientes activos con su unidad y sucursal', () => {
    service.listarStockIngredientes(null).subscribe();
    const req = httpMock.expectOne((r) => r.url === `${base}/stock_sucursal`);

    expect(req.request.params.get('select')).toBe(
      'ingrediente_id,sucursal_id,stock_actual,stock_minimo,' +
        'ingredientes!inner(nombre,unidades_medida(abreviatura)),sucursales!inner(nombre)',
    );
    expect(req.request.params.get('ingredientes.activo')).toBe('eq.true');
    expect(req.request.params.get('sucursales.activo')).toBe('eq.true');
    expect(req.request.params.has('sucursal_id')).toBe(false);
    req.flush([]);
  });

  it('lista el stock de productos de una sola sucursal', () => {
    service.listarStockProductos(3).subscribe();
    const req = httpMock.expectOne((r) => r.url === `${base}/stock_producto_sucursal`);

    expect(req.request.params.get('select')).toBe(
      'producto_id,sucursal_id,stock_actual,stock_minimo,' +
        'productos!inner(nombre),sucursales!inner(nombre)',
    );
    expect(req.request.params.get('productos.activo')).toBe('eq.true');
    expect(req.request.params.get('sucursales.activo')).toBe('eq.true');
    expect(req.request.params.get('sucursal_id')).toBe('eq.3');
    req.flush([]);
  });

  it('cambia solo el mínimo de la fila del producto y devuelve el valor guardado', async () => {
    const promesa = firstValueFrom(service.actualizarMinimo('producto', 4, 1, 2.5));
    const req = httpMock.expectOne((r) => r.url === `${base}/stock_producto_sucursal`);

    expect(req.request.method).toBe('PATCH');
    expect(req.request.body).toEqual({ stock_minimo: 2.5 });
    expect(req.request.params.get('producto_id')).toBe('eq.4');
    expect(req.request.params.get('sucursal_id')).toBe('eq.1');
    expect(req.request.params.get('select')).toBe('stock_minimo');
    expect(req.request.headers.get('Prefer')).toBe('return=representation');
    req.flush([{ stock_minimo: '2.500' }]);
    expect(await promesa).toBe(2.5);
  });

  it('devuelve null si el ingrediente no tiene fila de stock en esa sucursal', async () => {
    const promesa = firstValueFrom(service.actualizarMinimo('ingrediente', 3, 2, 1));
    const req = httpMock.expectOne((r) => r.url === `${base}/stock_sucursal`);

    expect(req.request.params.get('ingrediente_id')).toBe('eq.3');
    expect(req.request.params.get('sucursal_id')).toBe('eq.2');
    req.flush([]);
    expect(await promesa).toBeNull();
  });

  it('lista los ajustes manuales y mermas del periodo en todas las sucursales', () => {
    service
      .listarAjustesManuales(null, '2026-10-14T03:00:00', '2026-10-21T03:00:00', false)
      .subscribe();
    const req = httpMock.expectOne((r) => r.url === `${base}/movimientos_stock`);

    expect(req.request.method).toBe('GET');
    expect(req.request.params.get('select')).toBe(
      'id,ingrediente_id,producto_id,sucursal_id,tipo_movimiento,cantidad,nota,creado_en,' +
        'ingredientes(nombre,unidades_medida(abreviatura)),productos(nombre),sucursales(nombre),' +
        'usuarios(nombre)',
    );
    expect(req.request.params.get('tipo_movimiento')).toBe('in.(ajuste,merma)');
    // Entradas y salidas: no se filtra por signo.
    expect(req.request.params.has('cantidad')).toBe(false);
    expect(req.request.params.get('and')).toBe(
      '(creado_en.gte.2026-10-14T03:00:00,creado_en.lt.2026-10-21T03:00:00)',
    );
    expect(req.request.params.get('order')).toBe('creado_en.desc');
    expect(req.request.params.has('sucursal_id')).toBe(false);
    req.flush([]);
  });

  it('lista solo las mermas de una sucursal', () => {
    service
      .listarAjustesManuales(2, '2026-10-20T03:00:00', '2026-10-21T03:00:00', true)
      .subscribe();
    const req = httpMock.expectOne((r) => r.url === `${base}/movimientos_stock`);

    expect(req.request.params.get('sucursal_id')).toBe('eq.2');
    expect(req.request.params.get('tipo_movimiento')).toBe('eq.merma');
    req.flush([]);
  });

  it('ajusta stock llamando a fn_ajustar_stock con parámetros p_*', async () => {
    const respuesta = { id: 5, producto_id: 4, stock_resultante: 12 } as MovimientoStockApi;
    const promesa = firstValueFrom(
      service.ajustar({
        sucursal_id: 1,
        cantidad: 12,
        motivo: 'carga inicial',
        producto_id: 4,
        clave: 'clave-1',
      }),
    );
    const req = httpMock.expectOne(`${base}/rpc/fn_ajustar_stock`);
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual({
      p_sucursal_id: 1,
      p_cantidad: 12,
      p_motivo: 'carga inicial',
      p_ingrediente_id: null,
      p_producto_id: 4,
      p_clave: 'clave-1',
    });
    req.flush(respuesta);
    expect(await promesa).toEqual(respuesta);
  });

  it('asks the lightweight inventory version (H3.2 T06)', async () => {
    const promesa = firstValueFrom(service.versionInventario());
    const req = httpMock.expectOne(`${base}/rpc/fn_version_inventario`);
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual({});
    req.flush({ stock: 'abc', movimientos: 42 });
    expect(await promesa).toEqual({ stock: 'abc', movimientos: 42 });
  });
});
