import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { ProductoApi } from './productos-api.service';
import { VentaApi, VentaDetalleApi } from './ventas-api.service';

/** Fila de `turnos` tal como la devuelven fn_abrir_turno / fn_cerrar_turno. */
export interface TurnoApi {
  id: number;
  usuario_id: number;
  sucursal_id: number;
  hora_inicio: string;
  hora_fin: string | null;
  creado_en: string;
  monto_inicial: number;
}

export interface VentaTurnoApi extends Omit<VentaApi, 'detalle_venta'> {
  detalle_venta: (VentaDetalleApi & { productos: ProductoApi | null })[];
}

export interface TurnoRecuperadoApi {
  turno: TurnoApi | null;
  ventas: VentaTurnoApi[];
}

/**
 * Llama a los RPC `fn_abrir_turno` / `fn_cerrar_turno` (migración
 * 0003_apertura_control_turno.sql). Ambos corren SECURITY DEFINER en
 * PostgreSQL: el cajero no necesita permisos directos sobre la tabla
 * `turnos`, solo EXECUTE sobre estas funciones.
 *
 * `fn_abrir_turno` rechaza la apertura (HTTP con PostgrestError en el body)
 * si el cajero ya tiene un turno activo en esa sucursal. `fn_registrar_venta`
 * usa el turno activo automáticamente; no hace falta mandar el turno_id al
 * registrar una venta.
 */
@Injectable({ providedIn: 'root' })
export class TurnosApiService {
  private readonly http = inject(HttpClient);
  private readonly abrirUrl = `${environment.apiUrl}/rpc/fn_abrir_turno`;
  private readonly cerrarUrl = `${environment.apiUrl}/rpc/fn_cerrar_turno`;

  /** Recupera el turno y todas sus ventas con la identidad del JWT, sin abrir uno nuevo. */
  recuperar(): Observable<TurnoRecuperadoApi> {
    return this.http.post<TurnoRecuperadoApi>(`${environment.apiUrl}/rpc/fn_recuperar_turno`, {});
  }

  abrir(usuarioId: number, sucursalId: number, montoInicial: number): Observable<TurnoApi> {
    return this.http.post<TurnoApi>(this.abrirUrl, {
      p_usuario_id: usuarioId,
      p_sucursal_id: sucursalId,
      p_monto_inicial: montoInicial,
    });
  }

  cerrar(turnoId: number): Observable<TurnoApi> {
    return this.http.post<TurnoApi>(this.cerrarUrl, { p_turno_id: turnoId });
  }
}
