import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { firstValueFrom } from 'rxjs';
import { environment } from '../../../environments/environment';
import {
  IngredienteApi,
  IngredienteCreacion,
  IngredientesApiService,
} from './ingredientes-api.service';

const INGREDIENTES_URL = `${environment.apiUrl}/ingredientes`;

describe('IngredientesApiService', () => {
  let service: IngredientesApiService;
  let http: HttpTestingController;

  const ingrediente: IngredienteApi = {
    id: 3,
    nombre: 'Pan de molde',
    categoria_id: 1,
    unidad_id: 1,
    costo_unitario_promedio: 0,
    codigo_barras: '7800000000031',
    activo: true,
    creado_en: '2026-09-01T12:00:00Z',
    actualizado_en: '2026-09-01T12:00:00Z',
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()],
    });
    service = TestBed.inject(IngredientesApiService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  it('creates an ingredient in the database and requests the resulting row', async () => {
    const newIngrediente: IngredienteCreacion = {
      nombre: 'Queso gauda laminado',
      unidad_id: 1,
      categoria_id: 1,
      codigo_barras: null,
    };
    const createdIngrediente: IngredienteApi = {
      ...newIngrediente,
      id: 4,
      costo_unitario_promedio: 0,
      activo: true,
      creado_en: '2026-09-20T12:00:00Z',
      actualizado_en: '2026-09-20T12:00:00Z',
    };
    const resultPromise = firstValueFrom(service.crear(newIngrediente));
    const request = http.expectOne(
      (candidate) =>
        candidate.method === 'POST' &&
        candidate.url === INGREDIENTES_URL &&
        candidate.params.get('select')?.includes('unidad_id') === true,
    );

    expect(request.request.body).toEqual(newIngrediente);
    expect(request.request.headers.get('Prefer')).toBe('return=representation');
    request.flush([createdIngrediente]);

    await expect(resultPromise).resolves.toEqual(createdIngrediente);
  });

  it('requests the unit of measure when listing ingredients', async () => {
    const resultPromise = firstValueFrom(service.listar(false));
    const request = http.expectOne(
      (candidate) => candidate.method === 'GET' && candidate.url === INGREDIENTES_URL,
    );

    expect(request.request.params.get('select')?.split(',')).toContain('unidad_id');
    request.flush([ingrediente]);

    await expect(resultPromise).resolves.toEqual([ingrediente]);
  });

  it('only lists active ingredients by default', async () => {
    const resultPromise = firstValueFrom(service.listar());
    const request = http.expectOne(
      (candidate) => candidate.method === 'GET' && candidate.url === INGREDIENTES_URL,
    );

    expect(request.request.params.get('activo')).toBe('eq.true');
    request.flush([ingrediente]);

    await resultPromise;
  });

  it('updates an ingredient without touching its unit of measure', async () => {
    const changes = {
      nombre: ingrediente.nombre,
      categoria_id: ingrediente.categoria_id,
      codigo_barras: ingrediente.codigo_barras,
      activo: ingrediente.activo,
    };
    const resultPromise = firstValueFrom(service.actualizar(ingrediente.id, changes));
    const request = http.expectOne(
      (candidate) =>
        candidate.method === 'PATCH' &&
        candidate.url === INGREDIENTES_URL &&
        candidate.params.get('id') === 'eq.3',
    );

    expect(request.request.body).toEqual(changes);
    expect(request.request.body.unidad_id).toBeUndefined();
    expect(request.request.headers.get('Prefer')).toBe('return=representation');
    request.flush([ingrediente]);

    await expect(resultPromise).resolves.toEqual(ingrediente);
  });

  it('updates only the active state used to show an ingredient in the catalog', async () => {
    const inactiveIngrediente = { ...ingrediente, activo: false };
    const resultPromise = firstValueFrom(service.actualizarEstado(ingrediente.id, false));
    const request = http.expectOne(
      (candidate) =>
        candidate.method === 'PATCH' &&
        candidate.url === INGREDIENTES_URL &&
        candidate.params.get('id') === 'eq.3',
    );

    expect(request.request.body).toEqual({ activo: false });
    expect(request.request.headers.get('Prefer')).toBe('return=representation');
    request.flush([inactiveIngrediente]);

    await expect(resultPromise).resolves.toEqual(inactiveIngrediente);
  });
});
