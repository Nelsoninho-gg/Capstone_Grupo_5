export type RolUsuario = 'admin' | 'administrador' | 'cajero' | 'bodeguero';

export type EstadoFactura = 'pendiente_revision' | 'confirmada' | 'anulada';

export type TipoPromocion = 'porcentaje' | 'monto_fijo' | 'precio_fijo' | 'combo';

export type MedioPago = 'efectivo' | 'debito' | 'credito' | 'transferencia';

export type TipoVenta = 'normal' | 'empleado';

export type TipoMovimientoStock = 'compra' | 'venta' | 'ajuste' | 'merma' | 'anulacion_venta';

export type ReferenciaTipoMovimiento = 'factura_compra' | 'venta' | 'ajuste_manual';

export type AccionAuditoriaUsuario = 'creacion' | 'edicion' | 'deshabilitacion' | 'reactivacion';
