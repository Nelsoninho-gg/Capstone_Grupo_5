import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { firstValueFrom } from 'rxjs';
import { environment } from '../../../environments/environment';
import { VentaApi, VentasApiService } from './ventas-api.service';

const SALES_URL = `${environment.apiUrl}/ventas`;

describe('VentasApiService', () => {
  let service: VentasApiService;
  let http: HttpTestingController;
  const sale: VentaApi = {
    id: 7,
    sucursal_id: 1,
    cajero_id: 3,
    fecha_venta: '2026-10-01T17:28:24',
    medio_pago: 'efectivo',
    total: 9600,
    anulada: false,
    anulada_en: null,
    anulada_por: null,
    creado_en: '2026-10-01T17:28:24',
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()],
    });
    service = TestBed.inject(VentasApiService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  it('lists the sales of a single branch newest first, regardless of any open shift', async () => {
    const result = firstValueFrom(service.listar({ sucursalIds: [1] }));
    const request = http.expectOne((req) => req.method === 'GET' && req.url === SALES_URL);
    expect(request.request.params.get('sucursal_id')).toBe('eq.1');
    expect(request.request.params.get('order')).toBe('fecha_venta.desc,id.desc');
    expect(request.request.params.get('select')).toBe('*');
    expect(request.request.params.has('anulada')).toBe(false);
    request.flush([sale]);
    await expect(result).resolves.toEqual([sale]);
  });

  it('filters several branches at once for admins assigned to more than one', async () => {
    const result = firstValueFrom(service.listar({ sucursalIds: [1, 2, 3, 2] }));
    const request = http.expectOne((req) => req.method === 'GET' && req.url === SALES_URL);
    expect(request.request.params.get('sucursal_id')).toBe('in.(1,2,3)');
    request.flush([]);
    await expect(result).resolves.toEqual([]);
  });

  it('never queries the API without a branch, so other branches are not exposed', async () => {
    await expect(firstValueFrom(service.listar({ sucursalIds: [] }))).resolves.toEqual([]);
    http.expectNone(SALES_URL);
  });

  it('can exclude annulled sales', async () => {
    const result = firstValueFrom(service.listar({ sucursalIds: [1], soloVigentes: true }));
    const request = http.expectOne((req) => req.method === 'GET' && req.url === SALES_URL);
    expect(request.request.params.get('anulada')).toBe('eq.false');
    request.flush([sale]);
    await result;
  });

  it('applies the date range as UTC instants, since the server stores UTC', async () => {
    const result = firstValueFrom(
      service.listar({
        sucursalIds: [1],
        desde: new Date('2026-10-01T03:00:00Z'),
        hasta: new Date('2026-10-02T03:00:00Z'),
      }),
    );
    const request = http.expectOne((req) => req.method === 'GET' && req.url === SALES_URL);
    expect(request.request.params.getAll('fecha_venta')).toEqual([
      'gte.2026-10-01T03:00:00',
      'lt.2026-10-02T03:00:00',
    ]);
    request.flush([]);
    await result;
  });

  it('embeds the sold products only when the detail is requested', async () => {
    const result = firstValueFrom(service.listar({ sucursalIds: [1], incluirDetalle: true }));
    const request = http.expectOne((req) => req.method === 'GET' && req.url === SALES_URL);
    expect(request.request.params.get('select')).toBe(
      '*,detalle_venta(cantidad,precio_unitario,subtotal,productos(nombre))',
    );
    request.flush([]);
    await result;
  });

  it('asks which items were left without enough stock by a registered sale (H2.5 T04)', async () => {
    const fila = {
      tipo: 'ingrediente',
      item_id: 3,
      nombre: 'Queso',
      sucursal_id: 1,
      unidad: 'g',
      requerido: 120,
      disponible: 100,
      faltante: 20,
      stock_actual: -20,
    };
    const result = firstValueFrom(service.stockInsuficiente(7));
    const request = http.expectOne(`${environment.apiUrl}/rpc/fn_stock_insuficiente_venta`);
    expect(request.request.method).toBe('POST');
    expect(request.request.body).toEqual({ p_venta_id: 7 });
    request.flush([fila]);
    await expect(result).resolves.toEqual([fila]);
  });

  it('asks the server to annul without accepting a client-supplied actor or timestamp', async () => {
    const result = firstValueFrom(service.anular(7, 'Error de cobro'));
    const request = http.expectOne(`${environment.apiUrl}/rpc/fn_anular_venta`);
    expect(request.request.method).toBe('POST');
    expect(request.request.body).toEqual({ p_venta_id: 7, p_motivo: 'Error de cobro' });
    request.flush(7);
    await expect(result).resolves.toBeUndefined();
  });

  it('propagates the server rejection when the cashier attempts to annul another sale', async () => {
    const result = firstValueFrom(service.anular(99, 'Duplicada'));
    http
      .expectOne(`${environment.apiUrl}/rpc/fn_anular_venta`)
      .flush(
        { message: 'Solo puedes anular tus propias ventas' },
        { status: 403, statusText: 'Forbidden' },
      );
    await expect(result).rejects.toMatchObject({ status: 403 });
  });

  it('filters the cashier history in the API request', async () => {
    const result = firstValueFrom(service.listar({ sucursalIds: [1], cajeroId: 3 }));
    const request = http.expectOne((req) => req.method === 'GET' && req.url === SALES_URL);
    expect(request.request.params.get('cajero_id')).toBe('eq.3');
    request.flush([sale]);
    await expect(result).resolves.toEqual([sale]);
  });
});
