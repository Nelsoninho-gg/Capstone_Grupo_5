import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { firstValueFrom } from 'rxjs';
import { environment } from '../../../environments/environment';
import { aBase64, FacturasApiService, ResultadoIngresoFactura } from './facturas-api.service';

describe('FacturasApiService', () => {
  let service: FacturasApiService;
  let http: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()],
    });
    service = TestBed.inject(FacturasApiService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  it('sends the original file, the branch and what to do with each line to the server', async () => {
    // «ñ» en ISO-8859-1 es el byte 0xF1: el archivo viaja tal cual, sin recodificar.
    const xml = Uint8Array.from([0x3c, 0x61, 0x3e, 0xf1, 0x3c, 0x2f, 0x61, 0x3e]);
    const resultado: ResultadoIngresoFactura = {
      factura_compra_id: 7,
      factura_xml_id: 3,
      lineas_inventario: 1,
      lineas_no_inventario: 1,
    };

    const respuesta = firstValueFrom(
      service.ingresar(2, xml, 'factura.xml', [
        { numero_linea: 1, producto_id: 10, unidades_por_presentacion: 12 },
        { numero_linea: 2, no_corresponde_inventario: true },
      ]),
    );

    const solicitud = http.expectOne(`${environment.apiUrl}/rpc/fn_ingresar_factura_xml`);
    expect(solicitud.request.method).toBe('POST');
    expect(solicitud.request.body).toEqual({
      p_sucursal_id: 2,
      p_xml_base64: 'PGE+8TwvYT4=',
      p_xml_nombre: 'factura.xml',
      p_lineas: [
        { numero_linea: 1, producto_id: 10, unidades_por_presentacion: 12 },
        { numero_linea: 2, no_corresponde_inventario: true },
      ],
    });
    solicitud.flush(resultado);

    await expect(respuesta).resolves.toEqual(resultado);
  });
});

describe('aBase64', () => {
  it('encodes files larger than one chunk without losing bytes', () => {
    const bytes = Uint8Array.from({ length: 70_000 }, (_, i) => i % 256);

    const decodificado = Uint8Array.from(atob(aBase64(bytes)), (c) => c.charCodeAt(0));

    expect(decodificado).toEqual(bytes);
  });
});
