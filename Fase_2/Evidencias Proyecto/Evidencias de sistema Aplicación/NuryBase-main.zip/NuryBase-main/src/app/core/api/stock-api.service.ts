import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

export interface MovimientoStockApi {
  id: number;
  ingrediente_id: number | null;
  producto_id: number | null;
  sucursal_id: number;
  tipo_movimiento: string;
  cantidad: number | string;
  stock_resultante: number | string;
  referencia_tipo: string | null;
  referencia_id: number | null;
  nota: string | null;
}

/**
 * Ajuste manual de stock. `cantidad` es una DIFERENCIA con signo (+ entra, − sale),
 * no el stock final. Se debe indicar exactamente uno de ingrediente_id / producto_id.
 */
export interface AjusteStock {
  sucursal_id: number;
  cantidad: number;
  motivo: string;
  ingrediente_id?: number;
  producto_id?: number;
  /** UUID de la operación (H3.6 T06): se repite al reintentar para que no se aplique dos veces. */
  clave: string;
}

interface StockFila {
  stock_actual: number | string;
}

/** Tabla de stock y columna del artículo según su tipo. */
const TABLAS_STOCK = {
  ingrediente: { tabla: 'stock_sucursal', columna: 'ingrediente_id' },
  producto: { tabla: 'stock_producto_sucursal', columna: 'producto_id' },
} as const;

/** Fila de stock_sucursal con el ingrediente, su unidad y la sucursal. */
export interface StockIngredienteApi {
  ingrediente_id: number;
  sucursal_id: number;
  stock_actual: number | string;
  stock_minimo: number | string;
  ingredientes: { nombre: string; unidades_medida: { abreviatura: string } | null };
  sucursales: { nombre: string };
}

/** Fila de stock_producto_sucursal con el producto y la sucursal (los productos no tienen unidad). */
export interface StockProductoApi {
  producto_id: number;
  sucursal_id: number;
  stock_actual: number | string;
  stock_minimo: number | string;
  productos: { nombre: string };
  sucursales: { nombre: string };
}

/** Movimiento manual (ajuste o merma) de movimientos_stock, con artículo, sucursal y usuario. */
export interface AjusteManualApi {
  id: number;
  ingrediente_id: number | null;
  producto_id: number | null;
  sucursal_id: number;
  tipo_movimiento: 'ajuste' | 'merma';
  /** Positiva entra, negativa sale. */
  cantidad: number | string;
  /** fn_ajustar_stock guarda aquí el motivo. */
  nota: string | null;
  creado_en: string;
  ingredientes: { nombre: string; unidades_medida: { abreviatura: string } | null } | null;
  productos: { nombre: string } | null;
  sucursales: { nombre: string };
  usuarios: { nombre: string } | null;
}

/**
 * Filtros comunes a las dos consultas de existencias: solo artículos y sucursales
 * activos (`!inner` descarta la fila cuando el filtro del recurso embebido no se cumple)
 * y, si se indica, una sola sucursal.
 */
function filtrosExistencias(articulo: string, sucursalId: number | null): Record<string, string> {
  const params: Record<string, string> = {
    [`${articulo}.activo`]: 'eq.true',
    'sucursales.activo': 'eq.true',
  };
  if (sucursalId !== null) params['sucursal_id'] = `eq.${sucursalId}`;
  return params;
}

/** Versión liviana del inventario (fn_version_inventario, H3.2 T06). */
export interface VersionInventarioApi {
  /** Huella del stock y de los mínimos de todas las filas de stock. */
  stock: string;
  /** Id del último movimiento del kardex. */
  movimientos: number;
}

@Injectable({
  providedIn: 'root',
})
export class StockApiService {
  private readonly http = inject(HttpClient);
  private readonly apiUrl = environment.apiUrl;

  /** Stock actual de un ingrediente en una sucursal (0 si aún no tiene fila). */
  obtenerStockIngrediente(ingredienteId: number, sucursalId: number): Observable<number> {
    return this.http
      .get<StockFila[]>(`${this.apiUrl}/stock_sucursal`, {
        params: {
          select: 'stock_actual',
          ingrediente_id: `eq.${ingredienteId}`,
          sucursal_id: `eq.${sucursalId}`,
        },
      })
      .pipe(map(([fila]) => Number(fila?.stock_actual ?? 0)));
  }

  /** Stock actual de un producto de reventa en una sucursal (0 si aún no tiene fila). */
  obtenerStockProducto(productoId: number, sucursalId: number): Observable<number> {
    return this.http
      .get<StockFila[]>(`${this.apiUrl}/stock_producto_sucursal`, {
        params: {
          select: 'stock_actual',
          producto_id: `eq.${productoId}`,
          sucursal_id: `eq.${sucursalId}`,
        },
      })
      .pipe(map(([fila]) => Number(fila?.stock_actual ?? 0)));
  }

  /**
   * Existencias registradas de ingredientes (H3.4 T03): solo las filas que ya existen,
   * creadas por una compra, un ajuste o una venta. null consulta todas las sucursales.
   */
  listarStockIngredientes(sucursalId: number | null): Observable<StockIngredienteApi[]> {
    return this.http.get<StockIngredienteApi[]>(`${this.apiUrl}/stock_sucursal`, {
      params: {
        select:
          'ingrediente_id,sucursal_id,stock_actual,stock_minimo,' +
          'ingredientes!inner(nombre,unidades_medida(abreviatura)),sucursales!inner(nombre)',
        ...filtrosExistencias('ingredientes', sucursalId),
      },
    });
  }

  /** Existencias registradas de productos de reventa, con los mismos criterios. */
  listarStockProductos(sucursalId: number | null): Observable<StockProductoApi[]> {
    return this.http.get<StockProductoApi[]>(`${this.apiUrl}/stock_producto_sucursal`, {
      params: {
        select:
          'producto_id,sucursal_id,stock_actual,stock_minimo,' +
          'productos!inner(nombre),sucursales!inner(nombre)',
        ...filtrosExistencias('productos', sucursalId),
      },
    });
  }

  /**
   * Cambia solo el mínimo de una fila de stock (H3.5 T05); no toca stock_actual, así que no
   * interfiere con ventas ni ajustes simultáneos. Devuelve el mínimo guardado, o null si la
   * fila no existe (por ejemplo, si el artículo nunca tuvo stock en esa sucursal).
   */
  actualizarMinimo(
    tipo: keyof typeof TABLAS_STOCK,
    articuloId: number,
    sucursalId: number,
    stockMinimo: number,
  ): Observable<number | null> {
    const { tabla, columna } = TABLAS_STOCK[tipo];
    return this.http
      .patch<{ stock_minimo: number | string }[]>(
        `${this.apiUrl}/${tabla}`,
        { stock_minimo: stockMinimo },
        {
          params: {
            [columna]: `eq.${articuloId}`,
            sucursal_id: `eq.${sucursalId}`,
            select: 'stock_minimo',
          },
          headers: { Prefer: 'return=representation' },
        },
      )
      .pipe(map(([fila]) => (fila ? Number(fila.stock_minimo) : null)));
  }

  /**
   * Movimientos manuales de stock (H3.6 T07), del más reciente al más antiguo: ajustes y
   * mermas, o solo mermas. `desde` se incluye y `hasta` se excluye, en el formato de
   * creado_en (AAAA-MM-DDTHH:MM:SS, sin zona). null consulta todas las sucursales.
   */
  listarAjustesManuales(
    sucursalId: number | null,
    desde: string,
    hasta: string,
    soloMermas: boolean,
  ): Observable<AjusteManualApi[]> {
    // shortcut: sin paginar, vale para periodos acotados; con meses de datos conviene agrupar en la base.
    const params: Record<string, string> = {
      // El embebido usuarios(nombre) requiere la FK movimientos_stock.usuario_id → usuarios(id).
      select:
        'id,ingrediente_id,producto_id,sucursal_id,tipo_movimiento,cantidad,nota,creado_en,' +
        'ingredientes(nombre,unidades_medida(abreviatura)),productos(nombre),sucursales(nombre),' +
        'usuarios(nombre)',
      tipo_movimiento: soloMermas ? 'eq.merma' : 'in.(ajuste,merma)',
      and: `(creado_en.gte.${desde},creado_en.lt.${hasta})`,
      order: 'creado_en.desc',
    };
    if (sucursalId !== null) params['sucursal_id'] = `eq.${sucursalId}`;
    return this.http.get<AjusteManualApi[]>(`${this.apiUrl}/movimientos_stock`, { params });
  }

  /** Llama a fn_ajustar_stock y devuelve el movimiento de kardex creado. */
  ajustar(ajuste: AjusteStock): Observable<MovimientoStockApi> {
    return this.http.post<MovimientoStockApi>(`${this.apiUrl}/rpc/fn_ajustar_stock`, {
      p_sucursal_id: ajuste.sucursal_id,
      p_cantidad: ajuste.cantidad,
      p_motivo: ajuste.motivo,
      p_ingrediente_id: ajuste.ingrediente_id ?? null,
      p_producto_id: ajuste.producto_id ?? null,
      p_clave: ajuste.clave,
    });
  }

  /**
   * Versión del inventario para saber, sin traer las existencias, si algo cambió desde la
   * última consulta (H3.2 T06). Cambia con ventas, anulaciones, compras, ajustes y mínimos.
   */
  versionInventario(): Observable<VersionInventarioApi> {
    return this.http.post<VersionInventarioApi>(`${this.apiUrl}/rpc/fn_version_inventario`, {});
  }
}
