import { HttpClient, HttpParams } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { map, Observable, of } from 'rxjs';
import { environment } from '../../../environments/environment';

export interface VentaItemPayload {
  producto: string;
  cantidad: number;
  precio_unitario: number;
  promocion_id?: number;
}

export interface RegistrarVentaPayload {
  /**
   * Clave única de la venta (UUID, H2.5 T05). Un reintento con la misma clave devuelve la
   * venta ya registrada sin volver a descontar el inventario.
   */
  p_clave: string;
  p_sucursal_id: number;
  p_cajero_id: number | null;
  p_medio_pago: string;
  p_items: VentaItemPayload[];
  /** Solo en ventas a empleado (H2.12); si se omiten, la venta es normal. */
  p_tipo_venta?: 'empleado';
  p_empleado_id?: number;
}

const SELECT_CON_DETALLE = '*,detalle_venta(cantidad,precio_unitario,subtotal,productos(nombre))';

/** Fila de `ventas` tal como la devuelve PostgREST. */
/** Ítem que quedó con stock insuficiente tras una venta (fn_stock_insuficiente_venta, H2.5 T04). */
export interface StockInsuficienteApi {
  tipo: 'ingrediente' | 'producto';
  item_id: number;
  nombre: string;
  sucursal_id: number;
  unidad: string;
  /** Lo que consumió la venta (sumado si varios productos comparten el ingrediente). */
  requerido: number;
  /** Stock que había antes de la venta. */
  disponible: number;
  faltante: number;
  stock_actual: number;
}

export interface VentaApi {
  id: number;
  sucursal_id: number;
  cajero_id: number | null;
  fecha_venta: string;
  medio_pago: string | null;
  total: number;
  anulada: boolean;
  anulada_en: string | null;
  anulada_por: number | null;
  /**
   * Solo describe la lectura: toda anulación se envía con motivo (ver `anular`).
   * Puede faltar en la respuesta si el servidor aún no tiene la migración 0002.
   */
  anulada_motivo?: string | null;
  /** Venta a empleado (H2.12, migraciones 0004 y 0007). */
  tipo_venta?: 'normal' | 'empleado';
  venta_especial?: boolean;
  empleado_id?: number | null;
  descuento_porcentaje?: number;
  descuento_monto?: number;
  codigo_venta?: string;
  creado_en: string;
  /** Solo viene con `incluirDetalle`. */
  detalle_venta?: VentaDetalleApi[];
}

export interface VentaDetalleApi {
  cantidad: number;
  precio_unitario: number;
  subtotal: number;
  productos: { nombre: string } | null;
}

export interface FiltroVentas {
  /** Sucursales del usuario. Es obligatorio: sin sucursales no se consulta nada. */
  sucursalIds: number[];
  /** Si es true, excluye las ventas ya anuladas. */
  soloVigentes?: boolean;
  /** Instante inicial, inclusivo. */
  desde?: Date;
  /** Instante final, exclusivo (por ejemplo, el inicio del día siguiente). */
  hasta?: Date;
  /** Agrega los productos vendidos de cada venta (`detalle_venta`). */
  incluirDetalle?: boolean;
  /** Limita el historial al cajero; el servidor también verifica la propiedad. */
  cajeroId?: number;
}

/**
 * Llama al RPC `fn_registrar_venta_idempotente` (20261026_venta_idempotente.sql), que usa
 * `p_clave` para no duplicar reintentos y luego llama a `fn_registrar_venta` (schema_nury.sql):
 * inserta la cabecera en `ventas` y una línea en `detalle_venta` por cada
 * ítem, dentro de una única transacción en PostgreSQL. Eso dispara los
 * triggers existentes de descuento de stock por receta (kardex) y de
 * recálculo del total — no hay que reimplementar esa lógica en el frontend.
 */
@Injectable({ providedIn: 'root' })
export class VentasApiService {
  private readonly http = inject(HttpClient);
  private readonly url = `${environment.apiUrl}/rpc/fn_registrar_venta_idempotente`;

  registrar(payload: RegistrarVentaPayload): Observable<number> {
    return this.http.post<number>(this.url, payload);
  }

  /**
   * Ingredientes y productos de reventa que quedaron con stock insuficiente por una venta
   * ya registrada (H2.5 T04). La venta no se bloquea: es solo para avisar en el POS.
   */
  stockInsuficiente(ventaId: number): Observable<StockInsuficienteApi[]> {
    return this.http.post<StockInsuficienteApi[]>(
      `${environment.apiUrl}/rpc/fn_stock_insuficiente_venta`,
      { p_venta_id: ventaId },
    );
  }

  /**
   * Lista las ventas de una o más sucursales, de la más reciente a la más antigua,
   * sin depender del turno abierto en esta pestaña. Con `sucursalIds` vacío no
   * hace ninguna petición, para no traer ventas de otras sucursales por error.
   */
  listar(filtro: FiltroVentas): Observable<VentaApi[]> {
    const sucursalIds = [...new Set(filtro.sucursalIds)].filter((id) => Number.isInteger(id));
    if (sucursalIds.length === 0) {
      return of([]);
    }

    let params = new HttpParams()
      .set('select', filtro.incluirDetalle ? SELECT_CON_DETALLE : '*')
      .set(
        'sucursal_id',
        sucursalIds.length === 1 ? `eq.${sucursalIds[0]}` : `in.(${sucursalIds.join(',')})`,
      )
      .set('order', 'fecha_venta.desc,id.desc');

    if (filtro.soloVigentes) {
      params = params.set('anulada', 'eq.false');
    }
    if (filtro.cajeroId !== undefined) {
      params = params.set('cajero_id', `eq.${filtro.cajeroId}`);
    }
    if (filtro.desde) {
      params = params.append('fecha_venta', `gte.${instanteServidor(filtro.desde)}`);
    }
    if (filtro.hasta) {
      params = params.append('fecha_venta', `lt.${instanteServidor(filtro.hasta)}`);
    }

    return this.http.get<VentaApi[]>(`${environment.apiUrl}/ventas`, { params });
  }

  /**
   * Anular es un cambio de estado, nunca un DELETE (ver nota en schema_nury.sql).
   * El servidor valida la propiedad y registra quién y cuándo desde el JWT.
   */
  anular(ventaId: number, motivo: string): Observable<void> {
    return this.http
      .post<number>(`${environment.apiUrl}/rpc/fn_anular_venta`, {
        p_venta_id: ventaId,
        p_motivo: motivo,
      })
      .pipe(map(() => undefined));
  }
}

/** `ventas.fecha_venta` es TIMESTAMP sin zona y el servidor guarda la hora en UTC. */
function instanteServidor(fecha: Date): string {
  return fecha.toISOString().slice(0, 19);
}
