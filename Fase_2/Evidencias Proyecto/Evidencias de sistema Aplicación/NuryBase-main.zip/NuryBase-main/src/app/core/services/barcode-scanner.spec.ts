import { TestBed } from '@angular/core/testing';
import { BrowserMultiFormatReader } from '@zxing/browser';
import { BarcodeFormat, Result } from '@zxing/library';
import { BarcodeScanner } from './barcode-scanner';

describe('BarcodeScanner', () => {
  let service: BarcodeScanner;

  beforeEach(() => {
    TestBed.resetTestingModule();
    TestBed.configureTestingModule({});
    service = TestBed.inject(BarcodeScanner);
  });

  afterEach(() => {
    service.stop();
    vi.restoreAllMocks();
  });

  const result = (code: string) =>
    new Result(code, new Uint8Array(), 0, [], BarcodeFormat.CODE_128);

  async function startReader() {
    const controls = { stop: vi.fn() };
    const decode = vi.spyOn(BrowserMultiFormatReader.prototype, 'decodeFromVideoDevice')
      .mockResolvedValue(controls);
    const onCode = vi.fn();
    await service.start(document.createElement('video'), onCode);
    const callback = decode.mock.calls[0][2];
    return { controls, onCode, emit: (code?: string) =>
      callback(code === undefined ? undefined : result(code), undefined, controls) };
  }

  it('keeps scanning different products without counting a stationary barcode repeatedly', async () => {
    const { onCode, controls, emit } = await startReader();
    emit('NUR-101');
    emit('NUR-101');
    emit('NUR-201');
    emit('NUR-201');
    expect(onCode.mock.calls.map(([code]) => code)).toEqual(['NUR-101', 'NUR-201']);
    expect(controls.stop).not.toHaveBeenCalled();
    expect(service.isScanning).toBe(true);
  });

  it('accepts the same product again after removal, but ignores brief decoding failures', async () => {
    let now = 0;
    vi.spyOn(Date, 'now').mockImplementation(() => now);
    const { onCode, emit } = await startReader();
    emit('NUR-101');
    emit();
    now = 300;
    emit();
    emit('NUR-101');
    expect(onCode).toHaveBeenCalledTimes(1);
    now = 1000;
    emit();
    now = 1750;
    emit();
    emit('NUR-101');
    expect(onCode).toHaveBeenCalledTimes(2);
  });

  it('releases the camera on stop and ignores later callbacks', async () => {
    const { controls, onCode, emit } = await startReader();
    service.stop();
    emit('NUR-101');
    expect(controls.stop).toHaveBeenCalledOnce();
    expect(onCode).not.toHaveBeenCalled();
    expect(service.isScanning).toBe(false);
  });

  it('releases a camera that finishes starting after cancellation', async () => {
    const controls = { stop: vi.fn() };
    let resolveStart!: (value: typeof controls) => void;
    vi.spyOn(BrowserMultiFormatReader.prototype, 'decodeFromVideoDevice')
      .mockReturnValue(new Promise((resolve) => { resolveStart = resolve; }));
    const pending = service.start(document.createElement('video'), vi.fn());
    service.stop();
    resolveStart(controls);
    await pending;
    expect(controls.stop).toHaveBeenCalledOnce();
    expect(service.isScanning).toBe(false);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
