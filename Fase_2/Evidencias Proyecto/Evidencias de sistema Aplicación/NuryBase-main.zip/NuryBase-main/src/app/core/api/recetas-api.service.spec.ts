import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { firstValueFrom } from 'rxjs';
import { environment } from '../../../environments/environment';
import { RecetaApi, RecetaCreacion, RecetasApiService } from './recetas-api.service';

const RECETAS_URL = `${environment.apiUrl}/recetas`;

describe('RecetasApiService', () => {
  let service: RecetasApiService;
  let http: HttpTestingController;

  const receta: RecetaApi = {
    id: 1,
    producto_id: 10,
    ingrediente_id: 3,
    cantidad_necesaria: 2,
    unidad_id: 1,
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()],
    });
    service = TestBed.inject(RecetasApiService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  it('lists the recipe rows of a given product', async () => {
    const resultPromise = firstValueFrom(service.listarPorProducto(10));
    const request = http.expectOne(
      (candidate) => candidate.method === 'GET' && candidate.url === RECETAS_URL,
    );

    expect(request.request.params.get('producto_id')).toBe('eq.10');
    request.flush([receta]);

    await expect(resultPromise).resolves.toEqual([receta]);
  });

  it('adds an ingredient to a product recipe and requests the resulting row', async () => {
    const nuevaReceta: RecetaCreacion = {
      producto_id: 10,
      ingrediente_id: 3,
      cantidad_necesaria: 2,
      unidad_id: 1,
    };
    const resultPromise = firstValueFrom(service.agregar(nuevaReceta));
    const request = http.expectOne(
      (candidate) => candidate.method === 'POST' && candidate.url === RECETAS_URL,
    );

    expect(request.request.body).toEqual(nuevaReceta);
    expect(request.request.headers.get('Prefer')).toBe('return=representation');
    request.flush([receta]);

    await expect(resultPromise).resolves.toEqual(receta);
  });

  it('updates only the required quantity of a recipe row', async () => {
    const resultPromise = firstValueFrom(service.actualizar(receta.id, { cantidad_necesaria: 3 }));
    const request = http.expectOne(
      (candidate) =>
        candidate.method === 'PATCH' &&
        candidate.url === RECETAS_URL &&
        candidate.params.get('id') === 'eq.1',
    );

    expect(request.request.body).toEqual({ cantidad_necesaria: 3 });
    const recetaActualizada = { ...receta, cantidad_necesaria: 3 };
    request.flush([recetaActualizada]);

    await expect(resultPromise).resolves.toEqual(recetaActualizada);
  });

  it('removes an ingredient from a product recipe', async () => {
    const resultPromise = firstValueFrom(service.eliminar(receta.id));
    const request = http.expectOne(
      (candidate) =>
        candidate.method === 'DELETE' &&
        candidate.url === RECETAS_URL &&
        candidate.params.get('id') === 'eq.1',
    );

    expect(request.request.headers.get('Prefer')).toBe('return=representation');
    request.flush([receta]);

    await expect(resultPromise).resolves.toEqual(receta);
  });

  it('lists the recipe versions of a product with fn_versiones_receta (H2.5 T02)', async () => {
    const versiones = [
      { numero: 2, vigente_desde: '2026-10-20T18:40:00', creada_por: 'Rocío Fuentes', insumos: 3 },
    ];
    const resultPromise = firstValueFrom(service.listarVersiones(10));

    const req = http.expectOne(`${environment.apiUrl}/rpc/fn_versiones_receta`);
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual({ p_producto_id: 10 });
    req.flush(versiones);

    await expect(resultPromise).resolves.toEqual(versiones);
  });
});
