import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

export interface SucursalApi {
  id: number;
  nombre: string;
  direccion: string | null;
  telefono: string | null;
  activo: boolean;
  creado_en: string;
}

export type SucursalCreacion = Pick<SucursalApi, 'nombre' | 'direccion' | 'telefono' | 'activo'>;
export type SucursalActualizacion = Partial<SucursalCreacion>;

const BRANCH_FIELDS = 'id,nombre,direccion,telefono,activo,creado_en';

@Injectable({ providedIn: 'root' })
export class SucursalesApiService {
  private readonly http = inject(HttpClient);
  private readonly url = `${environment.apiUrl}/sucursales`;
  private readonly crearUrl = `${environment.apiUrl}/rpc/crear_sucursal`;

  listar(): Observable<SucursalApi[]> {
    return this.http.get<SucursalApi[]>(this.url, {
      params: { select: BRANCH_FIELDS, order: 'id.asc' },
    });
  }

  listarActivas(): Observable<SucursalApi[]> {
    return this.http.get<SucursalApi[]>(this.url, {
      params: {
        select: BRANCH_FIELDS,
        activo: 'eq.true',
        order: 'nombre.asc',
      },
    });
  }

  crear(sucursal: SucursalCreacion): Observable<SucursalApi> {
    return this.http
      .post<SucursalApi[]>(this.crearUrl, {
        p_nombre: sucursal.nombre,
        p_direccion: sucursal.direccion,
        p_telefono: sucursal.telefono,
        p_activo: sucursal.activo,
      })
      .pipe(map(([creada]) => this.exigirSucursal(creada, 'creada')));
  }

  actualizar(id: number, cambios: SucursalActualizacion): Observable<SucursalApi> {
    return this.http
      .patch<SucursalApi[]>(this.url, cambios, {
        headers: { Prefer: 'return=representation' },
        params: { id: `eq.${id}`, select: BRANCH_FIELDS },
      })
      .pipe(map(([actualizada]) => this.exigirSucursal(actualizada, 'actualizada')));
  }

  actualizarEstado(id: number, activo: boolean): Observable<SucursalApi> {
    return this.actualizar(id, { activo });
  }

  private exigirSucursal(sucursal: SucursalApi | undefined, accion: string): SucursalApi {
    if (!sucursal) {
      throw new Error(`La sucursal no existe o no pudo ser ${accion}.`);
    }
    return sucursal;
  }
}
