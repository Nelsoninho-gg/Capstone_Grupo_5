import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

export interface UnidadMedidaApi {
  id: number;
  nombre: string;
  abreviatura: string;
}

const UNIDAD_MEDIDA_FIELDS = 'id,nombre,abreviatura';

/**
 * Unidades de medida (kg, g, L, ml, un, paq). Es una tabla de catálogo casi fija:
 * no se crean ni editan desde la app por ahora, solo se listan para los
 * selectores de ingredientes y recetas.
 */
@Injectable({
  providedIn: 'root',
})
export class UnidadesMedidaApiService {
  private readonly http = inject(HttpClient);
  private readonly url = `${environment.apiUrl}/unidades_medida`;

  listar(): Observable<UnidadMedidaApi[]> {
    return this.http.get<UnidadMedidaApi[]>(this.url, {
      params: {
        select: UNIDAD_MEDIDA_FIELDS,
        order: 'nombre.asc',
      },
    });
  }
}
