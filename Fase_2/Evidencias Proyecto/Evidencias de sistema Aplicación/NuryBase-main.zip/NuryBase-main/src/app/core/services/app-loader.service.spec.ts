import { signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { LoadStatus } from '../../shared/components/coffee-loader/coffee-loader';
import { AppLoaderService, NAVIGATION_SETTLE_MS } from './app-loader.service';

describe('AppLoaderService', () => {
  let service: AppLoaderService;

  const flush = (ms = 0) => {
    vi.advanceTimersByTime(ms);
    TestBed.tick();
  };

  beforeEach(() => {
    vi.useFakeTimers({ toFake: ['setTimeout', 'clearTimeout'] });
    TestBed.configureTestingModule({});
    service = TestBed.inject(AppLoaderService);
  });

  afterEach(() => vi.useRealTimers());

  it('is idle and lets views use their own loader when nothing is loading', () => {
    expect(service.status()).toBe('ready');
    expect(service.join(signal<LoadStatus>('loading'))).toBe(false);
  });

  it('stays loading until navigation settles and every joined view is ready', () => {
    service.start();
    expect(service.status()).toBe('loading');

    const catalog = signal<LoadStatus>('loading');
    expect(service.join(catalog)).toBe(true);
    service.navigationDone();
    flush(NAVIGATION_SETTLE_MS);
    expect(service.status()).toBe('loading');

    catalog.set('ready');
    flush();
    expect(service.status()).toBe('ready');

    // Terminada la entrada, una recarga posterior de la vista ya no la reabre
    catalog.set('loading');
    flush();
    expect(service.status()).toBe('ready');
    expect(service.join(catalog)).toBe(false);
  });

  it('ends right after navigating when the view has nothing else to load', () => {
    service.start();
    service.navigationDone();
    flush(NAVIGATION_SETTLE_MS);
    expect(service.status()).toBe('ready');
  });

  it('reports a failed view and retries only that view', () => {
    service.start();
    const retryCatalog = vi.fn();
    const retryOther = vi.fn();
    service.join(signal<LoadStatus>('error'), retryCatalog);
    service.join(signal<LoadStatus>('loading'), retryOther);
    service.navigationDone();
    flush(NAVIGATION_SETTLE_MS);

    expect(service.status()).toBe('error');
    service.retry();
    expect(retryCatalog).toHaveBeenCalledTimes(1);
    expect(retryOther).not.toHaveBeenCalled();
  });

  it('reports a failed navigation and retries it', () => {
    const retryNavigation = vi.fn();
    service.start();
    service.navigationFailed(retryNavigation);

    expect(service.status()).toBe('error');
    service.retry();
    expect(retryNavigation).toHaveBeenCalledTimes(1);
  });
});
