-- ENSAYO de 20261017_equivalencias_lineas_xml.sql.
-- Ejecuta el mismo cambio, prueba las reglas con filas de ejemplo y termina en
-- ROLLBACK: no deja nada aplicado. Si todo sale bien, el último mensaje es ROLLBACK
-- y la consulta final muestra «OK» en cada fila.

BEGIN;

ALTER TABLE public.facturas_xml_pendientes_lineas
    ADD COLUMN IF NOT EXISTS unidades_por_presentacion NUMERIC(12,3);

ALTER TABLE public.facturas_xml_pendientes_lineas
    ADD COLUMN IF NOT EXISTS cantidad_ingreso NUMERIC(14,3)
        GENERATED ALWAYS AS (cantidad * unidades_por_presentacion) STORED;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint
                    WHERE conrelid = 'public.facturas_xml_pendientes_lineas'::regclass
                      AND conname = 'facturas_xml_lineas_equivalencia_positiva') THEN
        ALTER TABLE public.facturas_xml_pendientes_lineas
            ADD CONSTRAINT facturas_xml_lineas_equivalencia_positiva
            CHECK (unidades_por_presentacion IS NULL OR unidades_por_presentacion > 0);
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_constraint
                    WHERE conrelid = 'public.facturas_xml_pendientes_lineas'::regclass
                      AND conname = 'facturas_xml_lineas_equivalencia_con_articulo') THEN
        ALTER TABLE public.facturas_xml_pendientes_lineas
            ADD CONSTRAINT facturas_xml_lineas_equivalencia_con_articulo
            CHECK (unidades_por_presentacion IS NULL
                   OR num_nonnulls(ingrediente_id, producto_id) = 1);
    END IF;
END $$;

-- Pruebas con datos de ejemplo (se descartan con el ROLLBACK) -------------------

CREATE TEMP TABLE _resultados (prueba TEXT, resultado TEXT) ON COMMIT DROP;

DO $$
DECLARE
    v_factura   INTEGER;
    v_producto  INTEGER;
    v_cantidad  NUMERIC;
    v_sucursal  INTEGER;
    v_usuario   INTEGER;
BEGIN
    -- Datos propios del ensayo: no depende de lo que ya haya en la base.
    INSERT INTO public.sucursales (nombre) VALUES ('Ensayo T06') RETURNING id INTO v_sucursal;
    INSERT INTO public.usuarios (nombre, identificador_acceso, password_hash, rol)
        VALUES ('Admin ensayo T06', 'ensayo-t06-admin', 'x', 'admin') RETURNING id INTO v_usuario;
    INSERT INTO public.productos (nombre, precio_venta) VALUES ('Ensayo T06 producto', 1000) RETURNING id INTO v_producto;

    INSERT INTO public.facturas_xml_pendientes
        (sucursal_id, cargado_por, tipo_documento, folio, rut_emisor, rut_emisor_normalizado,
         fecha_emision, monto_neto, monto_iva, monto_total, xml_original, xml_sha256)
    VALUES
        (v_sucursal, v_usuario,
         33, 999999999, '82623500-4', '82623500-4', DATE '2026-10-15',
         1000, 190, 1190, 'x'::bytea, repeat('0', 64))
    RETURNING id INTO v_factura;

    -- 1) Cantidad a ingresar = cantidad × equivalencia.
    INSERT INTO public.facturas_xml_pendientes_lineas
        (factura_xml_id, numero_linea, descripcion, cantidad, precio_unitario, monto,
         producto_id, unidades_por_presentacion)
    VALUES (v_factura, 1, 'Caja de prueba', 7, 5139, 35973, v_producto, 12)
    RETURNING cantidad_ingreso INTO v_cantidad;
    INSERT INTO _resultados VALUES
        ('cantidad_ingreso = 7 × 12', CASE WHEN v_cantidad = 84 THEN 'OK' ELSE 'FALLA: ' || v_cantidad END);

    -- 2) Sin equivalencia, la cantidad a ingresar queda vacía.
    INSERT INTO public.facturas_xml_pendientes_lineas
        (factura_xml_id, numero_linea, descripcion, cantidad, precio_unitario, monto, producto_id)
    VALUES (v_factura, 2, 'Sin equivalencia', 3, 100, 300, v_producto)
    RETURNING cantidad_ingreso INTO v_cantidad;
    INSERT INTO _resultados VALUES
        ('sin equivalencia: cantidad_ingreso NULL', CASE WHEN v_cantidad IS NULL THEN 'OK' ELSE 'FALLA' END);

    -- 3) Equivalencia cero: rechazada.
    BEGIN
        INSERT INTO public.facturas_xml_pendientes_lineas
            (factura_xml_id, numero_linea, descripcion, cantidad, precio_unitario, monto,
             producto_id, unidades_por_presentacion)
        VALUES (v_factura, 3, 'Equivalencia cero', 1, 100, 100, v_producto, 0);
        INSERT INTO _resultados VALUES ('equivalencia 0 rechazada', 'FALLA: se aceptó');
    EXCEPTION WHEN check_violation THEN
        INSERT INTO _resultados VALUES ('equivalencia 0 rechazada', 'OK');
    END;

    -- 4) Equivalencia sin artículo: rechazada.
    BEGIN
        INSERT INTO public.facturas_xml_pendientes_lineas
            (factura_xml_id, numero_linea, descripcion, cantidad, precio_unitario, monto,
             no_corresponde_inventario, unidades_por_presentacion)
        VALUES (v_factura, 4, 'Servicio', 1, 100, 100, TRUE, 1);
        INSERT INTO _resultados VALUES ('equivalencia sin artículo rechazada', 'FALLA: se aceptó');
    EXCEPTION WHEN check_violation THEN
        INSERT INTO _resultados VALUES ('equivalencia sin artículo rechazada', 'OK');
    END;
END $$;

-- pgAdmin solo muestra el resultado de la última instrucción: por eso cada prueba se
-- informa como aviso (pestaña «Messages») y el ensayo falla con error si alguna no da OK.
DO $$
DECLARE
    r       RECORD;
    fallas  INTEGER := 0;
BEGIN
    FOR r IN SELECT prueba, resultado FROM _resultados ORDER BY prueba LOOP
        RAISE NOTICE '% | %', r.resultado, r.prueba;
        IF r.resultado <> 'OK' THEN
            fallas := fallas + 1;
        END IF;
    END LOOP;

    IF fallas > 0 THEN
        RAISE EXCEPTION 'El ensayo tiene % prueba(s) con FALLA: revisa los avisos de arriba', fallas;
    END IF;
    RAISE NOTICE 'ENSAYO COMPLETO: todas las pruebas dieron OK';
END $$;

ROLLBACK;
