-- H2.13 T03 — Almuerzo de empleados sin cobro: registro con descuento de stock.
--
-- fn_registrar_almuerzo_empleado guarda el almuerzo (cabecera y productos) y
-- descuenta el stock de la sucursal en una sola transacción: si algo falla,
-- no queda ni el almuerzo ni ningún descuento.
--
-- Reutiliza el mismo descuento que la venta (H3.2 y H2.5). Para no copiarlo,
-- el descuento por producto sale de fn_aplicar_venta a una función propia,
-- fn_descontar_stock_producto, que usan las dos:
--   - Producto con receta  -> descuenta los ingredientes de la versión de
--                             receta vigente (H2.5), guardada en la línea.
--   - Producto sin receta  -> descuenta las unidades de su stock propio (H3.2).
-- Igual que en la venta, el stock puede quedar negativo (no se bloquea).
--
-- Los movimientos del almuerzo quedan como consumo interno:
--   tipo_movimiento = 'consumo_interno', referencia_tipo = 'almuerzo_empleado',
--   referencia_id = id del almuerzo. No son 'venta', así que no los toman la
--   anulación de ventas ni el aviso de stock insuficiente de la venta.
--
-- Contenido:
--   T01  tipo de movimiento 'consumo_interno'
--   T02  fn_descontar_stock_producto (descuento compartido)
--   T03  fn_aplicar_venta usando el descuento compartido (mismo resultado)
--   T04  versión de receta en cada línea del almuerzo
--   T05  fn_registrar_almuerzo_empleado
--
-- Requiere: 20261022_almuerzos_empleado.sql, 20261020_versiones_receta.sql,
-- 0007_reponer_stock_anulacion_venta.sql y 20261012_permisos_cajero.sql.
--
-- ANTES DE APLICAR EN PRODUCCIÓN:
--   a) Confirmar que fn_aplicar_venta es la de 20261020_versiones_receta.sql (T03 la
--      reemplaza; solo cambia que el descuento se hace con la función compartida):
--        SELECT pg_get_functiondef('public.fn_aplicar_venta()'::regprocedure);
--   b) Confirmar el CHECK actual del tipo de movimiento (T01 lo reemplaza):
--        SELECT conname, pg_get_constraintdef(oid) FROM pg_constraint
--         WHERE conrelid = 'public.movimientos_stock'::regclass AND contype = 'c';
--   c) Correr database/tests/registrar_almuerzo_empleado.sql y las pruebas de venta.
--   d) Después de aplicar: NOTIFY pgrst, 'reload schema';

BEGIN;

-- T01) Nuevo tipo de movimiento ------------------------------------------------
-- Se reemplaza el CHECK que lista los tipos, igual que en 0007.
DO $$
DECLARE
    v_con TEXT;
BEGIN
    FOR v_con IN
        SELECT conname FROM pg_constraint
         WHERE conrelid = 'public.movimientos_stock'::regclass
           AND contype = 'c'
           AND pg_get_constraintdef(oid) ILIKE '%tipo_movimiento%'
    LOOP
        EXECUTE format('ALTER TABLE public.movimientos_stock DROP CONSTRAINT %I', v_con);
    END LOOP;
END $$;

ALTER TABLE public.movimientos_stock
    ADD CONSTRAINT movimientos_stock_tipo_movimiento_check
    CHECK (tipo_movimiento IN ('compra', 'venta', 'ajuste', 'merma', 'anulacion_venta', 'consumo_interno'));

-- T02) Descuento de stock de un producto ----------------------------------------
-- El mismo bloque que tenía fn_aplicar_venta (20261020_versiones_receta.sql), con el
-- tipo y la referencia del movimiento como parámetros. Interna: no se expone en PostgREST.
CREATE OR REPLACE FUNCTION public.fn_descontar_stock_producto(
    p_producto_id       INTEGER,
    p_sucursal_id       INTEGER,
    p_cantidad          NUMERIC,
    p_receta_version_id INTEGER,   -- NULL = producto de reventa
    p_tipo_movimiento   TEXT,
    p_referencia_tipo   TEXT,
    p_referencia_id     INTEGER
)
RETURNS VOID
LANGUAGE plpgsql
SET search_path = pg_catalog, public, pg_temp
AS $function$
DECLARE
    receta_row     RECORD;
    v_stock_previo NUMERIC(12,3);
    v_descuento    NUMERIC(12,3);
    v_nuevo_stock  NUMERIC(12,3);
BEGIN
    IF p_receta_version_id IS NOT NULL THEN
        -- H2.5: se descuentan exactamente los ingredientes de esa versión de receta.
        FOR receta_row IN
            SELECT ingrediente_id, cantidad_necesaria
              FROM recetas_version_detalle
             WHERE version_id = p_receta_version_id
        LOOP
            v_descuento := receta_row.cantidad_necesaria * p_cantidad;

            INSERT INTO stock_sucursal (ingrediente_id, sucursal_id, stock_actual, stock_minimo)
            VALUES (receta_row.ingrediente_id, p_sucursal_id, 0, 0)
            ON CONFLICT (ingrediente_id, sucursal_id) DO NOTHING;

            SELECT stock_actual INTO v_stock_previo
              FROM stock_sucursal
             WHERE ingrediente_id = receta_row.ingrediente_id AND sucursal_id = p_sucursal_id
             FOR UPDATE;

            v_nuevo_stock := v_stock_previo - v_descuento;

            UPDATE stock_sucursal
               SET stock_actual = v_nuevo_stock,
                   actualizado_en = now()
             WHERE ingrediente_id = receta_row.ingrediente_id AND sucursal_id = p_sucursal_id;

            INSERT INTO movimientos_stock
                (ingrediente_id, sucursal_id, tipo_movimiento, cantidad, stock_resultante, referencia_tipo, referencia_id)
            VALUES
                (receta_row.ingrediente_id, p_sucursal_id, p_tipo_movimiento, -v_descuento, v_nuevo_stock,
                 p_referencia_tipo, p_referencia_id);
        END LOOP;
    ELSE
        -- H3.2: producto de reventa, descuenta su propio stock en la sucursal.
        v_descuento := p_cantidad;

        INSERT INTO stock_producto_sucursal (producto_id, sucursal_id, stock_actual, stock_minimo)
        VALUES (p_producto_id, p_sucursal_id, 0, 0)
        ON CONFLICT (producto_id, sucursal_id) DO NOTHING;

        SELECT stock_actual INTO v_stock_previo
          FROM stock_producto_sucursal
         WHERE producto_id = p_producto_id AND sucursal_id = p_sucursal_id
         FOR UPDATE;

        v_nuevo_stock := v_stock_previo - v_descuento;

        UPDATE stock_producto_sucursal
           SET stock_actual = v_nuevo_stock,
               actualizado_en = now()
         WHERE producto_id = p_producto_id AND sucursal_id = p_sucursal_id;

        INSERT INTO movimientos_stock
            (producto_id, sucursal_id, tipo_movimiento, cantidad, stock_resultante, referencia_tipo, referencia_id)
        VALUES
            (p_producto_id, p_sucursal_id, p_tipo_movimiento, -v_descuento, v_nuevo_stock,
             p_referencia_tipo, p_referencia_id);
    END IF;
END;
$function$;

-- T03) fn_aplicar_venta con el descuento compartido -----------------------------
-- Igual a la de 20261020_versiones_receta.sql: el descuento ahora lo hace
-- fn_descontar_stock_producto con tipo y referencia 'venta'. La alerta de margen no cambia.
CREATE OR REPLACE FUNCTION public.fn_aplicar_venta() RETURNS TRIGGER AS $$
DECLARE
    v_sucursal_id  INTEGER;
    v_costo_receta NUMERIC(12,2);
BEGIN
    SELECT sucursal_id INTO v_sucursal_id FROM ventas WHERE id = NEW.venta_id;

    -- H2.5 T02: la versión de receta la fijó trg_detalle_venta_receta_version al insertar
    -- la línea; se descuentan exactamente sus ingredientes, aunque la receta cambie después.
    PERFORM fn_descontar_stock_producto(
        NEW.producto_id, v_sucursal_id, NEW.cantidad, NEW.receta_version_id,
        'venta', 'venta', NEW.venta_id);

    -- Alerta de margen: si la línea trae promoción y el precio aplicado queda bajo el costo de receta, se registra (no bloquea)
    IF NEW.promocion_id IS NOT NULL THEN
        SELECT COALESCE(SUM(r.cantidad_necesaria * i.costo_unitario_promedio), 0)
          INTO v_costo_receta
          FROM recetas_version_detalle r JOIN ingredientes i ON i.id = r.ingrediente_id
         WHERE r.version_id = NEW.receta_version_id;

        IF NEW.precio_unitario < v_costo_receta THEN
            INSERT INTO alertas_margen (promocion_id, producto_id, costo_receta, precio_aplicado, venta_id)
            VALUES (NEW.promocion_id, NEW.producto_id, v_costo_receta, NEW.precio_unitario, NEW.venta_id);
        END IF;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- T04) Cada línea del almuerzo guarda la versión de receta con que se descontó --
-- Se reutiliza el trigger de detalle_venta (20261020): decide la versión vigente del
-- producto, o NULL si no tiene receta.
-- Sin FK a recetas_version: crearla exige permiso REFERENCES sobre esa tabla, que es de
-- otro dueño. El valor lo pone siempre el trigger leyendo recetas_version, y las
-- versiones no se borran, así que la referencia queda válida igual.
ALTER TABLE public.almuerzos_empleado_detalle
    ADD COLUMN IF NOT EXISTS receta_version_id INTEGER;

COMMENT ON COLUMN public.almuerzos_empleado_detalle.receta_version_id IS
    'Versión de receta (recetas_version.id) con que se descontó el stock; NULL si es de reventa.';

DROP TRIGGER IF EXISTS trg_almuerzos_empleado_detalle_receta_version ON public.almuerzos_empleado_detalle;
CREATE TRIGGER trg_almuerzos_empleado_detalle_receta_version
    BEFORE INSERT ON public.almuerzos_empleado_detalle
    FOR EACH ROW EXECUTE FUNCTION public.fn_detalle_venta_receta_version();

-- T05) Registro del almuerzo -------------------------------------------------------
-- p_items: [{"producto_id": 12, "cantidad": 1}, ...]. Quien registra (cajero_id) es el
-- usuario de la sesión. Un cajero solo registra en su sucursal; el admin, en cualquiera.
-- No pide medio de pago ni turno abierto: no es una venta y no pasa por caja.
CREATE OR REPLACE FUNCTION public.fn_registrar_almuerzo_empleado(
    p_sucursal_id INTEGER,
    p_empleado_id INTEGER,
    p_items       JSONB
)
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $function$
DECLARE
    v_actor_id    INTEGER := public.fn_usuario_actual_id();
    v_actor       RECORD;
    v_almuerzo_id INTEGER;
    item          JSONB;
    v_producto_id INTEGER;
    v_cantidad    NUMERIC;
    v_vistos      INTEGER[] := '{}';
    linea         RECORD;
BEGIN
    IF v_actor_id IS NULL THEN
        RAISE EXCEPTION 'La sesión no identifica a un usuario autorizado' USING ERRCODE = '42501';
    END IF;

    SELECT rol, sucursal_id INTO v_actor FROM public.usuarios WHERE id = v_actor_id;

    IF NOT EXISTS (SELECT 1 FROM public.sucursales WHERE id = p_sucursal_id AND activo) THEN
        RAISE EXCEPTION 'La sucursal no existe o está deshabilitada' USING ERRCODE = '22023';
    END IF;

    IF v_actor.rol = 'cajero' AND v_actor.sucursal_id IS DISTINCT FROM p_sucursal_id THEN
        RAISE EXCEPTION 'Solo puedes registrar almuerzos en tu sucursal' USING ERRCODE = '42501';
    END IF;

    IF p_empleado_id IS NULL THEN
        RAISE EXCEPTION 'Debes indicar el empleado que almuerza' USING ERRCODE = '22023';
    END IF;

    IF NOT EXISTS (SELECT 1 FROM public.usuarios WHERE id = p_empleado_id AND activo) THEN
        RAISE EXCEPTION 'El empleado no existe o está deshabilitado' USING ERRCODE = '22023';
    END IF;

    IF p_items IS NULL OR jsonb_typeof(p_items) <> 'array' OR jsonb_array_length(p_items) = 0 THEN
        RAISE EXCEPTION 'El almuerzo no tiene productos' USING ERRCODE = '22023';
    END IF;

    INSERT INTO public.almuerzos_empleado (sucursal_id, empleado_id, cajero_id)
    VALUES (p_sucursal_id, p_empleado_id, v_actor_id)
    RETURNING id INTO v_almuerzo_id;

    FOR item IN SELECT * FROM jsonb_array_elements(p_items)
    LOOP
        IF jsonb_typeof(item->'producto_id') <> 'number'
           OR (item->>'producto_id') !~ '^[0-9]{1,9}$' THEN
            RAISE EXCEPTION 'Producto no válido: %', item->'producto_id' USING ERRCODE = '22023';
        END IF;
        v_producto_id := (item->>'producto_id')::INTEGER;

        IF jsonb_typeof(item->'cantidad') <> 'number' OR (item->>'cantidad')::NUMERIC <= 0 THEN
            RAISE EXCEPTION 'La cantidad debe ser mayor que 0' USING ERRCODE = '22023';
        END IF;
        v_cantidad := (item->>'cantidad')::NUMERIC;
        -- Se consumen unidades del producto (un menú, una bebida): no hay fracciones.
        IF v_cantidad <> trunc(v_cantidad) THEN
            RAISE EXCEPTION 'La cantidad debe ser un número entero' USING ERRCODE = '22023';
        END IF;

        IF v_producto_id = ANY (v_vistos) THEN
            RAISE EXCEPTION 'El producto % está repetido en el almuerzo', v_producto_id USING ERRCODE = '22023';
        END IF;
        v_vistos := v_vistos || v_producto_id;

        IF NOT EXISTS (SELECT 1 FROM public.productos WHERE id = v_producto_id AND activo) THEN
            RAISE EXCEPTION 'Producto no encontrado o inactivo: %', v_producto_id USING ERRCODE = '22023';
        END IF;

        -- trg_almuerzos_empleado_detalle_receta_version completa receta_version_id.
        INSERT INTO public.almuerzos_empleado_detalle (almuerzo_id, producto_id, cantidad)
        VALUES (v_almuerzo_id, v_producto_id, v_cantidad)
        RETURNING producto_id, cantidad, receta_version_id INTO linea;

        PERFORM public.fn_descontar_stock_producto(
            linea.producto_id, p_sucursal_id, linea.cantidad, linea.receta_version_id,
            'consumo_interno', 'almuerzo_empleado', v_almuerzo_id);
    END LOOP;

    RETURN v_almuerzo_id;
END;
$function$;

-- Dueño y permisos ---------------------------------------------------------------
-- Mismo dueño que `ventas` (escribe almuerzos y stock). Solo el registro se expone, y
-- solo a admin y cajero; el descuento compartido no se llama directo desde PostgREST.
DO $$
DECLARE
    v_owner TEXT;
BEGIN
    SELECT pg_get_userbyid(relowner) INTO v_owner
      FROM pg_class WHERE oid = 'public.ventas'::regclass;

    EXECUTE format('ALTER FUNCTION public.fn_descontar_stock_producto(integer, integer, numeric, integer, text, text, integer) OWNER TO %I', v_owner);
    EXECUTE format('ALTER FUNCTION public.fn_registrar_almuerzo_empleado(integer, integer, jsonb) OWNER TO %I', v_owner);
    EXECUTE format('GRANT EXECUTE ON FUNCTION public.fn_descontar_stock_producto(integer, integer, numeric, integer, text, text, integer) TO %I', v_owner);
END $$;

REVOKE ALL ON FUNCTION public.fn_descontar_stock_producto(integer, integer, numeric, integer, text, text, integer)
    FROM PUBLIC, web_anon, nury_cajero, nury_bodeguero;
REVOKE ALL ON FUNCTION public.fn_registrar_almuerzo_empleado(integer, integer, jsonb)
    FROM PUBLIC, web_anon, nury_bodeguero;
GRANT EXECUTE ON FUNCTION public.fn_registrar_almuerzo_empleado(integer, integer, jsonb)
    TO nury_admin, nury_cajero;

COMMIT;

NOTIFY pgrst, 'reload schema';
