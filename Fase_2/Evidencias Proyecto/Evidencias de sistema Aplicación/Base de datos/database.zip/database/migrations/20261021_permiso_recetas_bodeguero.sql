-- Lectura mínima de recetas para el bodeguero.
--
-- Hallazgo (2026-10-21): el bodeguero no tenía ningún permiso sobre recetas, y tres
-- pantallas que usa consultan GET /recetas?select=producto_id para descartar los
-- productos con receta (no tienen stock propio): el panel de Inventario, el modal
-- "Ajustar stock" y la carga de facturas XML. Con admin funcionaban; al bodeguero le
-- fallaban completas.
--
-- Se concede solo la columna producto_id: el bodeguero puede saber qué productos tienen
-- receta, pero no sus ingredientes ni cantidades.
--
-- YA APLICADA EN PRODUCCIÓN el 2026-10-21 (verificado: producto_id = true,
-- cantidad_necesaria = false). Es idempotente: se puede volver a correr sin efecto.
-- Debe ejecutarla el dueño de la tabla recetas.

BEGIN;

GRANT SELECT (producto_id) ON public.recetas TO nury_bodeguero;

COMMIT;

NOTIFY pgrst, 'reload schema';
