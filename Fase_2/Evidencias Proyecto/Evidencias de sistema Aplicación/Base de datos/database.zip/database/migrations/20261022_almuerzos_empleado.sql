-- H2.13 T02 — Almuerzo de empleados sin cobro: modelo del registro.
--
-- Contexto: el almuerzo diario de los empleados es consumo interno. No es una
-- venta: no tiene medio de pago ni total y no debe aparecer en ventas, caja ni
-- reportes de venta. Por eso se guarda en tablas propias, separadas de
-- `ventas` y `detalle_venta`.
--
--   almuerzos_empleado          cabecera: empleado, cajero, fecha y sucursal.
--   almuerzos_empleado_detalle  productos consumidos y sus cantidades.
--
-- Este script solo CREA tablas nuevas. No toca ventas ni stock: el registro
-- (con su descuento de stock) y la regla de un almuerzo por día se hacen en
-- las tareas siguientes de H2.13, mediante una función SECURITY DEFINER.
--
-- ANTES DE APLICAR EN PRODUCCIÓN:
--   a) Revisar el script completo con el responsable.
--   b) Ejecutarlo como dueño de `ventas` (las tablas nuevas quedan con ese dueño).
--   c) Después de aplicar: NOTIFY pgrst, 'reload schema';

BEGIN;

-- Cabecera del almuerzo --------------------------------------------------------

CREATE TABLE IF NOT EXISTS public.almuerzos_empleado (
    id              SERIAL PRIMARY KEY,
    sucursal_id     INTEGER NOT NULL REFERENCES public.sucursales(id),
    empleado_id     INTEGER NOT NULL REFERENCES public.usuarios(id),   -- quién almuerza
    cajero_id       INTEGER NOT NULL REFERENCES public.usuarios(id),   -- quién lo registra
    -- Día del almuerzo en hora de Chile (no la del servidor): define el "un almuerzo
    -- por día" y los filtros por periodo.
    fecha           DATE NOT NULL DEFAULT (now() AT TIME ZONE 'America/Santiago')::date,
    creado_en       TIMESTAMP NOT NULL DEFAULT now()
);

-- Consultas del administrador por sucursal, empleado y periodo.
CREATE INDEX IF NOT EXISTS idx_almuerzos_empleado_sucursal_fecha
    ON public.almuerzos_empleado(sucursal_id, fecha);
CREATE INDEX IF NOT EXISTS idx_almuerzos_empleado_empleado_fecha
    ON public.almuerzos_empleado(empleado_id, fecha);

COMMENT ON TABLE public.almuerzos_empleado IS
    'Almuerzo diario de empleados sin cobro (H2.13). Consumo interno: no es una venta.';
COMMENT ON COLUMN public.almuerzos_empleado.empleado_id IS 'Empleado que almuerza.';
COMMENT ON COLUMN public.almuerzos_empleado.cajero_id IS 'Usuario que registra el almuerzo.';
COMMENT ON COLUMN public.almuerzos_empleado.fecha IS 'Día del almuerzo, en hora de Chile.';

-- Productos consumidos -----------------------------------------------------------

CREATE TABLE IF NOT EXISTS public.almuerzos_empleado_detalle (
    id              SERIAL PRIMARY KEY,
    almuerzo_id     INTEGER NOT NULL REFERENCES public.almuerzos_empleado(id) ON DELETE CASCADE,
    producto_id     INTEGER NOT NULL REFERENCES public.productos(id),
    cantidad        NUMERIC(12,3) NOT NULL CHECK (cantidad > 0),   -- mismo tipo que detalle_venta
    UNIQUE (almuerzo_id, producto_id)                              -- un producto, una línea
);

CREATE INDEX IF NOT EXISTS idx_almuerzos_empleado_detalle_producto
    ON public.almuerzos_empleado_detalle(producto_id);

COMMENT ON TABLE public.almuerzos_empleado_detalle IS
    'Productos y cantidades de cada almuerzo de empleados (H2.13).';

-- Dueño y permisos ---------------------------------------------------------------
-- Mismo dueño que `ventas`, para que la función de registro (SECURITY DEFINER, con
-- ese dueño) pueda escribir. Nadie escribe directo: solo se concede lectura al
-- admin (consulta de almuerzos) y al cajero (revisar lo registrado en su turno).

DO $$
DECLARE
    v_owner TEXT;
    t       TEXT;
BEGIN
    SELECT pg_get_userbyid(relowner) INTO v_owner
      FROM pg_class WHERE oid = 'public.ventas'::regclass;

    FOREACH t IN ARRAY ARRAY['almuerzos_empleado', 'almuerzos_empleado_detalle'] LOOP
        EXECUTE format('ALTER TABLE public.%I OWNER TO %I', t, v_owner);
        EXECUTE format('ALTER SEQUENCE public.%I OWNER TO %I', t || '_id_seq', v_owner);
        EXECUTE format('REVOKE ALL ON public.%I FROM PUBLIC', t);
    END LOOP;
END $$;

REVOKE ALL ON public.almuerzos_empleado, public.almuerzos_empleado_detalle
    FROM web_anon, nury_cajero, nury_bodeguero;
GRANT SELECT ON public.almuerzos_empleado, public.almuerzos_empleado_detalle
    TO nury_admin, nury_cajero;

-- Lecturas que usa la pestaña «Almuerzo empleados» (H2.13 T01) -------------------
-- El cajero elige sucursal y ve si cada producto tiene receta. Igual que con el
-- bodeguero (20261021_permiso_recetas_bodeguero.sql), de recetas solo se concede
-- producto_id: no ve ingredientes ni cantidades. Ambos GRANT son idempotentes.

GRANT SELECT ON public.sucursales TO nury_cajero;
GRANT SELECT (producto_id) ON public.recetas TO nury_cajero;

COMMIT;

NOTIFY pgrst, 'reload schema';
