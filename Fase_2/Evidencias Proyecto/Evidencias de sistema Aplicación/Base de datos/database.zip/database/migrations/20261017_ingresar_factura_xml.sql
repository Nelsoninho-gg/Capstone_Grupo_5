-- Confirmación transaccional del ingreso de una factura XML (H3.1 T08) e
-- identidad única de la factura (H3.7 T02).
--
-- La pantalla envía el archivo XML tal cual llegó, la sucursal y qué hacer con cada
-- línea (artículo y equivalencia, o «No corresponde a inventario»). El servidor:
--   1. Valida el permiso y la sucursal (fn_validar_sucursal_ingreso, H3.1 T07).
--   2. Vuelve a leer el XML: no confía en los datos que calculó el navegador.
--      Tipo 33, folio, fecha, RUT emisor, totales y cada línea se validan aquí.
--   3. Rechaza la factura si ya fue ingresada (RUT emisor normalizado + tipo + folio),
--      aunque cambie el nombre del archivo o la sucursal.
--   4. Exige que cada línea tenga artículo y equivalencia, o esté marcada como no
--      inventariable.
--   5. En una sola transacción: crea facturas_compra, la factura y sus líneas en las
--      tablas de pendientes (como respaldo, con el XML original) y el detalle de compra.
--      El stock lo suma fn_aplicar_compra, una vez por línea de detalle.
--   Si algo falla, no queda nada guardado: ni factura, ni líneas, ni stock.
--
-- Costo (decidido el 17/10/2026): costo por unidad = monto neto de la línea ÷ cantidad
-- a ingresar, sin IVA. Si la factura indica IndMntBruto = 1, se descuenta el IVA.
-- precio_unitario solo admite 2 decimales: la diferencia de redondeo se deja en
-- descuento_monto (puede ser negativa) para que subtotal_neto sea exactamente el monto
-- de la línea del XML.
--
-- Facturas ingresadas a mano (sin RUT, tipo y folio) quedan fuera de la restricción
-- única (decidido el 17/10/2026): la restricción trata los NULL como distintos.
--
-- REQUIERE (aplicados antes): 20261016_facturas_xml_pendientes.sql,
-- 20261017_equivalencias_lineas_xml.sql y 20261017_permisos_ingreso_facturas.sql.
--
-- ANTES DE APLICAR EN PRODUCCIÓN:
--   a) Revisar el script completo con el responsable.
--   b) Correr primero 20261017_ingresar_factura_xml.ENSAYO.sql (termina en ROLLBACK).
--   c) Después de aplicar: NOTIFY pgrst, 'reload schema';

BEGIN;

-- 1) Identidad de la factura en facturas_compra (H3.7 T02) ------------------------

ALTER TABLE public.facturas_compra
    ADD COLUMN IF NOT EXISTS origen                 VARCHAR(10) NOT NULL DEFAULT 'manual',
    ADD COLUMN IF NOT EXISTS rut_emisor_normalizado VARCHAR(12),
    ADD COLUMN IF NOT EXISTS tipo_documento         SMALLINT,
    ADD COLUMN IF NOT EXISTS folio                  BIGINT;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint
                    WHERE conrelid = 'public.facturas_compra'::regclass
                      AND conname = 'facturas_compra_origen_check') THEN
        ALTER TABLE public.facturas_compra
            ADD CONSTRAINT facturas_compra_origen_check CHECK (origen IN ('manual', 'xml'));
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_constraint
                    WHERE conrelid = 'public.facturas_compra'::regclass
                      AND conname = 'facturas_compra_identidad_xml') THEN
        -- Toda factura que entra por XML trae su identidad completa.
        ALTER TABLE public.facturas_compra
            ADD CONSTRAINT facturas_compra_identidad_xml
            CHECK (origen <> 'xml'
                   OR (rut_emisor_normalizado IS NOT NULL AND tipo_documento IS NOT NULL AND folio IS NOT NULL));
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_constraint
                    WHERE conrelid = 'public.facturas_compra'::regclass
                      AND conname = 'facturas_compra_identidad_unica') THEN
        ALTER TABLE public.facturas_compra
            ADD CONSTRAINT facturas_compra_identidad_unica
            UNIQUE (rut_emisor_normalizado, tipo_documento, folio);
    END IF;
END $$;

-- 2) RUT normalizado: 12345678-K, con el dígito verificador comprobado -------------

CREATE OR REPLACE FUNCTION public.fn_normalizar_rut(p_rut TEXT)
RETURNS TEXT
LANGUAGE plpgsql
IMMUTABLE
SET search_path = pg_catalog, pg_temp
AS $$
DECLARE
    v_partes  TEXT[];
    v_cuerpo  TEXT;
    v_dv      TEXT;
    v_suma    INTEGER := 0;
    v_factor  INTEGER := 2;
    v_resto   INTEGER;
    v_pos     INTEGER;
BEGIN
    v_partes := regexp_match(upper(regexp_replace(COALESCE(p_rut, ''), '[.\s]', '', 'g')),
                             '^0*([0-9]{1,8})-?([0-9K])$');
    IF v_partes IS NULL THEN
        RETURN NULL;
    END IF;
    v_cuerpo := v_partes[1];
    v_dv := v_partes[2];

    FOR v_pos IN REVERSE length(v_cuerpo)..1 LOOP
        v_suma := v_suma + substr(v_cuerpo, v_pos, 1)::INTEGER * v_factor;
        v_factor := CASE WHEN v_factor = 7 THEN 2 ELSE v_factor + 1 END;
    END LOOP;
    v_resto := 11 - (v_suma % 11);

    IF (CASE v_resto WHEN 11 THEN '0' WHEN 10 THEN 'K' ELSE v_resto::TEXT END) <> v_dv THEN
        RETURN NULL;
    END IF;
    RETURN v_cuerpo || '-' || v_dv;
END;
$$;

-- 3) Lectura de un valor del DTE sin depender del namespace ------------------------
-- p_ruta es relativa al Documento ('Encabezado/IdDoc/Folio'), o a su línea número
-- p_detalle ('NmbItem'). Devuelve el texto sin espacios en los extremos, o NULL.

CREATE OR REPLACE FUNCTION public.fn_dte_texto(p_doc XML, p_ruta TEXT, p_detalle INTEGER DEFAULT NULL)
RETURNS TEXT
LANGUAGE plpgsql
IMMUTABLE
SET search_path = pg_catalog, pg_temp
AS $$
DECLARE
    v_xpath TEXT := '//*[local-name()="Documento"]';
    v_parte TEXT;
    v_valor TEXT;
BEGIN
    IF p_detalle IS NOT NULL THEN
        v_xpath := '(' || v_xpath || '/*[local-name()="Detalle"])[' || p_detalle || ']';
    END IF;
    FOREACH v_parte IN ARRAY string_to_array(p_ruta, '/') LOOP
        v_xpath := v_xpath || '/*[local-name()="' || v_parte || '"]';
    END LOOP;

    v_valor := (xpath('string(' || v_xpath || '[1])', p_doc))[1]::TEXT;
    -- xpath() devuelve el texto como XML: se deshacen las entidades básicas.
    v_valor := replace(replace(replace(replace(replace(v_valor,
                   '&lt;', '<'), '&gt;', '>'), '&quot;', '"'), '&apos;', ''''), '&amp;', '&');
    RETURN NULLIF(btrim(v_valor), '');
END;
$$;

-- 4) Ingreso completo de la factura ---------------------------------------------------

CREATE OR REPLACE FUNCTION public.fn_ingresar_factura_xml(
    p_sucursal_id INTEGER,
    p_xml_base64  TEXT,
    p_xml_nombre  TEXT,
    p_lineas      JSONB
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    c_documento CONSTANT TEXT := '//*[local-name()="Documento"]';
    c_tamano_maximo CONSTANT INTEGER := 5 * 1024 * 1024;

    v_actor            INTEGER;
    v_bytes            BYTEA;
    v_contenido        BYTEA;
    v_codificacion     TEXT;
    v_texto            TEXT;
    v_doc              XML;
    v_cantidad_docs    INTEGER;

    v_tipo             TEXT;
    v_folio_txt        TEXT;
    v_folio            BIGINT;
    v_fecha_txt        TEXT;
    v_fecha            DATE;
    v_venc_txt         TEXT;
    v_venc             DATE;
    v_rut              TEXT;
    v_rut_norm         TEXT;
    v_neto             NUMERIC;
    v_exento           NUMERIC;
    v_iva              NUMERIC;
    v_total            NUMERIC;
    v_tasa             NUMERIC;
    v_otros_txt        TEXT;
    v_otros            NUMERIC;
    v_incluye_iva      BOOLEAN;
    v_forma_pago       TEXT;
    v_orden_compra     TEXT;

    v_existente        INTEGER;
    v_proveedor        INTEGER;
    v_factura          INTEGER;
    v_pendiente        INTEGER;

    v_total_lineas     INTEGER;
    v_numeros          INTEGER[] := '{}';
    v_pos              INTEGER;
    v_nro              INTEGER;
    v_nro_txt          TEXT;
    v_desc             TEXT;
    v_codigo           TEXT;
    v_codigo_tipo      TEXT;
    v_qty_txt          TEXT;
    v_qty              NUMERIC;
    v_prc_txt          TEXT;
    v_prc              NUMERIC;
    v_monto_txt        TEXT;
    v_monto            NUMERIC;

    v_cuenta           INTEGER;
    v_asoc             JSONB;
    v_ingrediente      INTEGER;
    v_producto         INTEGER;
    v_no_inventario    BOOLEAN;
    v_equivalencia     NUMERIC;
    v_unidad           INTEGER;
    v_cantidad         NUMERIC;
    v_costo            NUMERIC;
    v_precio           NUMERIC;

    v_sin_asociar      INTEGER := 0;
    v_sin_equivalencia INTEGER := 0;
    v_lineas_stock     INTEGER := 0;
    v_lineas_otras     INTEGER := 0;
BEGIN
    -- Permiso y sucursal (42501 si no corresponde).
    v_actor := public.fn_validar_sucursal_ingreso(p_sucursal_id);

    IF p_lineas IS NULL OR jsonb_typeof(p_lineas) <> 'array' THEN
        RAISE EXCEPTION 'Indica qué hacer con cada línea de la factura' USING ERRCODE = '22023';
    END IF;

    -- Archivo ------------------------------------------------------------------
    BEGIN
        v_bytes := decode(COALESCE(p_xml_base64, ''), 'base64');
    EXCEPTION WHEN OTHERS THEN
        RAISE EXCEPTION 'El archivo no llegó completo. Vuelve a elegirlo.' USING ERRCODE = '22023';
    END;
    IF length(v_bytes) = 0 THEN
        RAISE EXCEPTION 'El archivo está vacío.' USING ERRCODE = '22023';
    END IF;
    IF length(v_bytes) > c_tamano_maximo THEN
        RAISE EXCEPTION 'El archivo pesa más de 5 MB.' USING ERRCODE = '22023';
    END IF;

    -- Codificación declarada en <?xml ... encoding="..."?>; sin declaración, UTF-8.
    IF substring(v_bytes FROM 1 FOR 3) = '\xefbbbf'::BYTEA THEN
        v_contenido := substring(v_bytes FROM 4);
        v_codificacion := 'UTF8';
    ELSE
        v_contenido := v_bytes;
        v_codificacion := COALESCE(
            substring(convert_from(substring(v_bytes FROM 1 FOR 200), 'LATIN1')
                      FROM '^\s*<\?xml[^>]*encoding\s*=\s*["'']([^"'']+)["'']'),
            'UTF8');
    END IF;

    BEGIN
        v_texto := convert_from(v_contenido, v_codificacion);
    EXCEPTION WHEN OTHERS THEN
        RAISE EXCEPTION 'El archivo declara una codificación desconocida o tiene caracteres inválidos (%).',
            v_codificacion USING ERRCODE = '22023';
    END;
    -- El texto ya está en la codificación de la base: se quita la declaración.
    v_texto := regexp_replace(v_texto, '^\s*<\?xml[^>]*\?>', '');

    BEGIN
        v_doc := XMLPARSE(DOCUMENT v_texto);
    EXCEPTION WHEN OTHERS THEN
        RAISE EXCEPTION 'El archivo no es un XML válido o está dañado.' USING ERRCODE = '22023';
    END;

    v_cantidad_docs := (xpath('count(' || c_documento || ')', v_doc))[1]::TEXT::NUMERIC::INTEGER;
    IF v_cantidad_docs = 0 THEN
        RAISE EXCEPTION 'El archivo no contiene un documento tributario electrónico (DTE).' USING ERRCODE = '22023';
    END IF;
    IF v_cantidad_docs > 1 THEN
        RAISE EXCEPTION 'El archivo contiene % documentos. Carga una factura a la vez.', v_cantidad_docs
            USING ERRCODE = '22023';
    END IF;

    -- Encabezado ----------------------------------------------------------------
    v_tipo := public.fn_dte_texto(v_doc, 'Encabezado/IdDoc/TipoDTE');
    IF v_tipo IS NULL THEN
        RAISE EXCEPTION 'No indica el tipo de documento (TipoDTE).' USING ERRCODE = '22023';
    END IF;
    IF v_tipo <> '33' THEN
        RAISE EXCEPTION 'El documento es tipo %. Solo se aceptan facturas electrónicas (tipo 33).', v_tipo
            USING ERRCODE = '22023';
    END IF;

    v_folio_txt := public.fn_dte_texto(v_doc, 'Encabezado/IdDoc/Folio');
    IF v_folio_txt IS NULL OR v_folio_txt !~ '^[0-9]{1,18}$' OR v_folio_txt::BIGINT <= 0 THEN
        RAISE EXCEPTION 'El folio falta o no es un número válido.' USING ERRCODE = '22023';
    END IF;
    v_folio := v_folio_txt::BIGINT;

    v_fecha_txt := public.fn_dte_texto(v_doc, 'Encabezado/IdDoc/FchEmis');
    BEGIN
        IF v_fecha_txt !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$' THEN
            RAISE EXCEPTION 'fecha';
        END IF;
        v_fecha := v_fecha_txt::DATE;
    EXCEPTION WHEN OTHERS THEN
        RAISE EXCEPTION 'La fecha de emisión falta o no es válida.' USING ERRCODE = '22023';
    END;
    IF v_fecha IS NULL THEN
        RAISE EXCEPTION 'La fecha de emisión falta o no es válida.' USING ERRCODE = '22023';
    END IF;

    v_venc_txt := public.fn_dte_texto(v_doc, 'Encabezado/IdDoc/FchVenc');
    IF v_venc_txt IS NOT NULL THEN
        BEGIN
            IF v_venc_txt !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$' THEN
                RAISE EXCEPTION 'fecha';
            END IF;
            v_venc := v_venc_txt::DATE;
        EXCEPTION WHEN OTHERS THEN
            RAISE EXCEPTION 'La fecha de vencimiento no es válida.' USING ERRCODE = '22023';
        END;
    END IF;

    v_rut := public.fn_dte_texto(v_doc, 'Encabezado/Emisor/RUTEmisor');
    IF v_rut IS NULL THEN
        RAISE EXCEPTION 'No indica el RUT del emisor.' USING ERRCODE = '22023';
    END IF;
    v_rut_norm := public.fn_normalizar_rut(v_rut);
    IF v_rut_norm IS NULL THEN
        RAISE EXCEPTION 'El RUT del emisor (%) no es válido.', v_rut USING ERRCODE = '22023';
    END IF;

    v_neto   := CASE WHEN public.fn_dte_texto(v_doc, 'Encabezado/Totales/MntNeto') ~ '^-?[0-9]+$'
                     THEN public.fn_dte_texto(v_doc, 'Encabezado/Totales/MntNeto')::NUMERIC END;
    v_iva    := CASE WHEN public.fn_dte_texto(v_doc, 'Encabezado/Totales/IVA') ~ '^-?[0-9]+$'
                     THEN public.fn_dte_texto(v_doc, 'Encabezado/Totales/IVA')::NUMERIC END;
    v_total  := CASE WHEN public.fn_dte_texto(v_doc, 'Encabezado/Totales/MntTotal') ~ '^-?[0-9]+$'
                     THEN public.fn_dte_texto(v_doc, 'Encabezado/Totales/MntTotal')::NUMERIC END;
    v_exento := CASE WHEN public.fn_dte_texto(v_doc, 'Encabezado/Totales/MntExe') ~ '^-?[0-9]+$'
                     THEN public.fn_dte_texto(v_doc, 'Encabezado/Totales/MntExe')::NUMERIC ELSE 0 END;
    v_tasa   := CASE WHEN public.fn_dte_texto(v_doc, 'Encabezado/Totales/TasaIVA') ~ '^[0-9]+(\.[0-9]+)?$'
                     THEN public.fn_dte_texto(v_doc, 'Encabezado/Totales/TasaIVA')::NUMERIC END;
    IF v_neto IS NULL THEN
        RAISE EXCEPTION 'Falta el monto neto (MntNeto) o no es un número entero.' USING ERRCODE = '22023';
    END IF;
    IF v_iva IS NULL THEN
        RAISE EXCEPTION 'Falta el IVA o no es un número entero.' USING ERRCODE = '22023';
    END IF;
    IF v_total IS NULL THEN
        RAISE EXCEPTION 'Falta el monto total (MntTotal) o no es un número entero.' USING ERRCODE = '22023';
    END IF;

    v_otros_txt := (xpath('sum(' || c_documento || '/*[local-name()="Encabezado"]/*[local-name()="Totales"]'
                          || '/*[local-name()="ImptoReten"]/*[local-name()="MontoImp"])', v_doc))[1]::TEXT;
    IF v_otros_txt !~ '^-?[0-9]+(\.[0-9]+)?$' THEN
        RAISE EXCEPTION 'Los impuestos adicionales (ImptoReten) no son números válidos.' USING ERRCODE = '22023';
    END IF;
    v_otros := v_otros_txt::NUMERIC;

    IF v_neto + v_exento + v_iva + v_otros <> v_total THEN
        RAISE EXCEPTION 'Los totales no cuadran: neto, exento, IVA e impuestos suman %, pero el total informado es %.',
            v_neto + v_exento + v_iva + v_otros, v_total USING ERRCODE = '22023';
    END IF;

    v_incluye_iva := COALESCE(public.fn_dte_texto(v_doc, 'Encabezado/IdDoc/IndMntBruto') = '1', FALSE);
    v_forma_pago := public.fn_dte_texto(v_doc, 'Encabezado/IdDoc/FmaPago');
    v_orden_compra := NULLIF(btrim((xpath('string(' || c_documento
        || '/*[local-name()="Referencia"][*[local-name()="TpoDocRef"]="801"][1]/*[local-name()="FolioRef"])',
        v_doc))[1]::TEXT), '');

    -- ¿Ya fue ingresada? (H3.7) -------------------------------------------------------
    -- El candado serializa dos confirmaciones de la misma factura (doble clic o dos
    -- sesiones): la segunda espera y luego ve la primera. La restricción única es la
    -- última defensa.
    PERFORM pg_advisory_xact_lock(hashtext('factura_xml:' || v_rut_norm || ':33:' || v_folio));

    SELECT f.id INTO v_existente
      FROM public.facturas_compra f
     WHERE f.rut_emisor_normalizado = v_rut_norm AND f.tipo_documento = 33 AND f.folio = v_folio;
    IF FOUND THEN
        RAISE EXCEPTION 'Esta factura ya fue ingresada (folio % del emisor %).', v_folio, v_rut_norm
            USING ERRCODE = '23505', DETAIL = 'factura_compra_id=' || v_existente;
    END IF;

    -- Proveedor por RUT; si no existe queda NULL (decidido el 16/10/2026).
    SELECT p.id INTO v_proveedor
      FROM public.proveedores p
     WHERE public.fn_normalizar_rut(p.rut) = v_rut_norm
     LIMIT 1;

    -- Cabeceras ------------------------------------------------------------------
    INSERT INTO public.facturas_compra
        (proveedor_id, sucursal_id, numero_factura, fecha_factura, monto_neto, monto_iva,
         monto_impuestos_especificos, monto_total, estado, origen,
         rut_emisor_normalizado, tipo_documento, folio)
    VALUES
        (v_proveedor, p_sucursal_id, v_folio::TEXT, v_fecha, v_neto, v_iva,
         v_otros, v_total, 'confirmada', 'xml',
         v_rut_norm, 33, v_folio)
    RETURNING id INTO v_factura;

    INSERT INTO public.facturas_xml_pendientes
        (sucursal_id, cargado_por, estado, tipo_documento, folio, rut_emisor, rut_emisor_normalizado,
         razon_social_emisor, rut_receptor, fecha_emision, fecha_vencimiento, forma_pago,
         orden_compra_referencia, monto_neto, monto_iva, tasa_iva, monto_total,
         xml_original, xml_nombre, xml_sha256, detalle_incluye_iva,
         factura_id, confirmado_por, confirmado_en)
    VALUES
        (p_sucursal_id, v_actor, 'confirmada', 33, v_folio, left(v_rut, 12), v_rut_norm,
         left(public.fn_dte_texto(v_doc, 'Encabezado/Emisor/RznSoc'), 150),
         left(public.fn_dte_texto(v_doc, 'Encabezado/Receptor/RUTRecep'), 12),
         v_fecha, v_venc,
         CASE WHEN v_forma_pago ~ '^[0-9]{1,4}$' THEN v_forma_pago::SMALLINT END,
         left(v_orden_compra, 60), v_neto, v_iva, v_tasa, v_total,
         v_bytes, left(p_xml_nombre, 255), encode(sha256(v_bytes), 'hex'), v_incluye_iva,
         v_factura, v_actor, now())
    RETURNING id INTO v_pendiente;

    -- Líneas -------------------------------------------------------------------------
    v_total_lineas := (xpath('count(' || c_documento || '/*[local-name()="Detalle"])', v_doc))[1]::TEXT::NUMERIC::INTEGER;
    IF v_total_lineas = 0 THEN
        RAISE EXCEPTION 'La factura no trae líneas de detalle.' USING ERRCODE = '22023';
    END IF;

    FOR v_pos IN 1..v_total_lineas LOOP
        v_nro_txt := public.fn_dte_texto(v_doc, 'NroLinDet', v_pos);
        v_nro := CASE WHEN v_nro_txt ~ '^[0-9]{1,9}$' THEN v_nro_txt::INTEGER ELSE v_pos END;
        IF v_nro = ANY (v_numeros) THEN
            RAISE EXCEPTION 'La factura repite el número de línea %.', v_nro USING ERRCODE = '22023';
        END IF;
        v_numeros := v_numeros || v_nro;

        v_desc := public.fn_dte_texto(v_doc, 'NmbItem', v_pos);
        v_codigo := public.fn_dte_texto(v_doc, 'CdgItem/VlrCodigo', v_pos);
        v_codigo_tipo := public.fn_dte_texto(v_doc, 'CdgItem/TpoCodigo', v_pos);
        v_qty_txt := public.fn_dte_texto(v_doc, 'QtyItem', v_pos);
        v_prc_txt := public.fn_dte_texto(v_doc, 'PrcItem', v_pos);
        v_monto_txt := public.fn_dte_texto(v_doc, 'MontoItem', v_pos);

        IF v_desc IS NULL THEN
            RAISE EXCEPTION 'Línea %: falta la descripción del artículo.', v_nro USING ERRCODE = '22023';
        END IF;
        IF v_qty_txt IS NULL OR v_qty_txt !~ '^[0-9]+(\.[0-9]+)?$' OR v_qty_txt::NUMERIC <= 0 THEN
            RAISE EXCEPTION 'Línea %: la cantidad falta o no es mayor que cero.', v_nro USING ERRCODE = '22023';
        END IF;
        IF v_prc_txt IS NULL OR v_prc_txt !~ '^[0-9]+(\.[0-9]+)?$' THEN
            RAISE EXCEPTION 'Línea %: falta el precio unitario.', v_nro USING ERRCODE = '22023';
        END IF;
        IF v_monto_txt IS NULL OR v_monto_txt !~ '^-?[0-9]+$' THEN
            RAISE EXCEPTION 'Línea %: falta el monto de la línea.', v_nro USING ERRCODE = '22023';
        END IF;
        v_qty := v_qty_txt::NUMERIC;
        v_prc := v_prc_txt::NUMERIC;
        v_monto := v_monto_txt::NUMERIC;

        -- Qué eligió el usuario para esta línea.
        SELECT count(*) INTO v_cuenta
          FROM jsonb_array_elements(p_lineas) e
         WHERE e->>'numero_linea' = v_nro::TEXT;
        IF v_cuenta > 1 THEN
            RAISE EXCEPTION 'La línea % aparece más de una vez en la asociación.', v_nro USING ERRCODE = '22023';
        END IF;
        SELECT e INTO v_asoc
          FROM jsonb_array_elements(p_lineas) e
         WHERE e->>'numero_linea' = v_nro::TEXT;

        v_ingrediente := CASE WHEN v_asoc->>'ingrediente_id' ~ '^[0-9]{1,9}$'
                              THEN (v_asoc->>'ingrediente_id')::INTEGER END;
        v_producto := CASE WHEN v_asoc->>'producto_id' ~ '^[0-9]{1,9}$'
                           THEN (v_asoc->>'producto_id')::INTEGER END;
        v_no_inventario := COALESCE(v_asoc->'no_corresponde_inventario' = 'true'::JSONB, FALSE);
        v_equivalencia := CASE WHEN jsonb_typeof(v_asoc->'unidades_por_presentacion') = 'number'
                               THEN (v_asoc->>'unidades_por_presentacion')::NUMERIC END;

        IF num_nonnulls(v_ingrediente, v_producto) + (CASE WHEN v_no_inventario THEN 1 ELSE 0 END) > 1 THEN
            RAISE EXCEPTION 'La línea % tiene más de una clasificación.', v_nro USING ERRCODE = '22023';
        END IF;

        IF v_asoc IS NULL OR (num_nonnulls(v_ingrediente, v_producto) = 0 AND NOT v_no_inventario) THEN
            v_sin_asociar := v_sin_asociar + 1;
            CONTINUE;
        END IF;

        IF v_no_inventario THEN
            INSERT INTO public.facturas_xml_pendientes_lineas
                (factura_xml_id, numero_linea, codigo_tipo, codigo_proveedor, descripcion,
                 cantidad, precio_unitario, monto, no_corresponde_inventario)
            VALUES
                (v_pendiente, v_nro, left(v_codigo_tipo, 20), left(v_codigo, 60), left(v_desc, 255),
                 v_qty, v_prc, v_monto, TRUE);
            v_lineas_otras := v_lineas_otras + 1;
            CONTINUE;
        END IF;

        IF v_equivalencia IS NULL OR v_equivalencia <= 0 OR v_equivalencia <> round(v_equivalencia, 3) THEN
            v_sin_equivalencia := v_sin_equivalencia + 1;
            CONTINUE;
        END IF;

        IF v_ingrediente IS NOT NULL THEN
            SELECT i.unidad_id INTO v_unidad
              FROM public.ingredientes i
             WHERE i.id = v_ingrediente AND i.activo;
            IF NOT FOUND THEN
                RAISE EXCEPTION 'Línea %: la materia prima elegida no existe o está inactiva.', v_nro
                    USING ERRCODE = '22023';
            END IF;
        ELSE
            IF NOT EXISTS (SELECT 1 FROM public.productos p WHERE p.id = v_producto AND p.activo) THEN
                RAISE EXCEPTION 'Línea %: el producto elegido no existe o está inactivo.', v_nro
                    USING ERRCODE = '22023';
            END IF;
            IF EXISTS (SELECT 1 FROM public.recetas r WHERE r.producto_id = v_producto) THEN
                RAISE EXCEPTION 'Línea %: el producto elegido tiene receta; su stock sale de sus ingredientes.', v_nro
                    USING ERRCODE = '22023';
            END IF;
            v_unidad := NULL;
        END IF;

        v_cantidad := round(v_qty * v_equivalencia, 3);
        IF v_cantidad <= 0 THEN
            RAISE EXCEPTION 'Línea %: la cantidad a ingresar es demasiado pequeña.', v_nro USING ERRCODE = '22023';
        END IF;

        INSERT INTO public.facturas_xml_pendientes_lineas
            (factura_xml_id, numero_linea, codigo_tipo, codigo_proveedor, descripcion,
             cantidad, precio_unitario, monto, ingrediente_id, producto_id, unidades_por_presentacion)
        VALUES
            (v_pendiente, v_nro, left(v_codigo_tipo, 20), left(v_codigo, 60), left(v_desc, 255),
             v_qty, v_prc, v_monto, v_ingrediente, v_producto, v_equivalencia);

        -- Costo neto de la línea; si los montos incluyen IVA, se le descuenta.
        v_costo := CASE WHEN v_incluye_iva
                        THEN round(v_monto / (1 + COALESCE(v_tasa, 19) / 100), 2)
                        ELSE v_monto END;
        v_precio := round(v_costo / v_cantidad, 2);

        -- El stock lo suma fn_aplicar_compra (AFTER INSERT), una sola vez por fila.
        INSERT INTO public.detalle_factura_compra
            (factura_id, ingrediente_id, producto_id, codigo_proveedor, unidades_por_presentacion,
             cantidad, unidad_id, precio_unitario, descuento_monto)
        VALUES
            (v_factura, v_ingrediente, v_producto, left(v_codigo, 30),
             CASE WHEN v_equivalencia = round(v_equivalencia, 2) AND v_equivalencia < 100000000
                  THEN v_equivalencia END,
             v_cantidad, v_unidad, v_precio,
             -- Diferencia de redondeo de precio_unitario (2 decimales): así subtotal_neto
             -- es exactamente el monto de la línea.
             round(v_cantidad * v_precio, 2) - v_costo);

        v_lineas_stock := v_lineas_stock + 1;
    END LOOP;

    IF v_sin_asociar > 0 THEN
        RAISE EXCEPTION 'Faltan asociar % línea(s): elige un artículo o márcalas como «No corresponde a inventario».',
            v_sin_asociar USING ERRCODE = '22023';
    END IF;
    IF v_sin_equivalencia > 0 THEN
        RAISE EXCEPTION 'Falta la equivalencia de % línea(s) asociadas a un artículo.', v_sin_equivalencia
            USING ERRCODE = '22023';
    END IF;
    IF EXISTS (SELECT 1 FROM jsonb_array_elements(p_lineas) e
                WHERE NOT (e->>'numero_linea' ~ '^[0-9]{1,9}$'
                           AND (e->>'numero_linea')::INTEGER = ANY (v_numeros))) THEN
        RAISE EXCEPTION 'La asociación menciona líneas que no están en la factura.' USING ERRCODE = '22023';
    END IF;

    RETURN jsonb_build_object(
        'factura_compra_id', v_factura,
        'factura_xml_id', v_pendiente,
        'lineas_inventario', v_lineas_stock,
        'lineas_no_inventario', v_lineas_otras);
END;
$$;

-- Solo roles de inventario. Las funciones auxiliares no se publican como RPC.
REVOKE ALL ON FUNCTION public.fn_ingresar_factura_xml(integer, text, text, jsonb)
    FROM PUBLIC, web_anon, nury_cajero;
GRANT EXECUTE ON FUNCTION public.fn_ingresar_factura_xml(integer, text, text, jsonb)
    TO nury_admin, nury_bodeguero;
REVOKE ALL ON FUNCTION public.fn_dte_texto(xml, text, integer) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.fn_normalizar_rut(text) FROM PUBLIC;

COMMIT;
