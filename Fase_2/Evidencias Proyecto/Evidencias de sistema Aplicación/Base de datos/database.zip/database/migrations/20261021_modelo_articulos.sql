-- H3.3 T02 - Modelar artículos, tipo (producto normal o materia prima), unidad de medida,
-- estado activo y su relación con las existencias por sucursal.
--
-- Un ARTÍCULO es lo que se guarda en bodega y tiene stock propio. No es una tabla nueva:
-- se apoya en las dos que ya existen y las presenta con un solo formato.
--
--   tipo           tabla del artículo                      existencias por sucursal
--   materia_prima  ingredientes (unidad_id → unidades)     stock_sucursal
--   producto       productos SIN receta (siempre "un")     stock_producto_sucursal
--
-- Reglas del modelo:
--   - Un producto CON receta no es artículo: no tiene stock propio, descuenta sus
--     ingredientes (misma regla que fn_aplicar_venta, fn_aplicar_compra y fn_ajustar_stock).
--   - Los productos normales se cuentan siempre por unidad (decisión 2026-10-21: no se
--     venden por peso), por eso productos no tiene unidad_id.
--   - Desactivar = activo FALSE; un artículo con historial nunca se borra.
--   - La unidad de una materia prima no cambia si ya está en uso (recetas o movimientos):
--     no hay conversión de unidades (T03).
--
-- Contenido:
--   T01  v_articulos: catálogo de artículos (Catálogo de Inventario, H3.3 T01/T03/T04)
--   T02  v_existencias_articulos: existencias de cada artículo por sucursal
--   T03  la unidad de una materia prima en uso no se puede cambiar
--
-- Las vistas leen con los permisos de su dueño (no security_invoker): el bodeguero no
-- tiene lectura sobre recetas (verificado en producción el 2026-10-21) y la necesita solo
-- para saber si un producto tiene receta. La vista no expone ingredientes ni cantidades
-- de las recetas, y solo admin y bodeguero pueden consultarla.
--
-- ANTES DE APLICAR EN PRODUCCIÓN:
--   a) Correr database/tests/modelo_articulos.sql en una base de pruebas y luego
--      20261021_modelo_articulos.ENSAYO.sql (termina en ROLLBACK).
--   b) Después de aplicar: NOTIFY pgrst, 'reload schema';

BEGIN;

-- T01) Catálogo de artículos -------------------------------------------------------
CREATE OR REPLACE VIEW public.v_articulos AS
SELECT 'materia_prima'::VARCHAR(20)  AS tipo,
       i.id                          AS articulo_id,
       i.nombre,
       i.unidad_id,
       um.abreviatura                AS unidad,
       um.nombre                     AS unidad_nombre,
       i.codigo_barras,
       i.activo,
       i.creado_en
  FROM public.ingredientes i
  JOIN public.unidades_medida um ON um.id = i.unidad_id
UNION ALL
SELECT 'producto'::VARCHAR(20),
       p.id,
       p.nombre,
       NULL::INTEGER,
       'un'::VARCHAR(10),
       'Unidad'::VARCHAR(40),
       p.codigo_barras,
       p.activo,
       p.creado_en
  FROM public.productos p
 WHERE NOT EXISTS (SELECT 1 FROM public.recetas r WHERE r.producto_id = p.id);

COMMENT ON VIEW public.v_articulos IS
    'Artículos de bodega (H3.3 T02): materias primas (ingredientes) y productos normales (productos sin receta). Los productos se cuentan por unidad.';
COMMENT ON COLUMN public.v_articulos.tipo IS 'materia_prima | producto';
COMMENT ON COLUMN public.v_articulos.articulo_id IS 'ingredientes.id o productos.id según tipo';
COMMENT ON COLUMN public.v_articulos.unidad_id IS 'Unidad de la materia prima; NULL en productos (siempre "un")';

-- T02) Existencias de cada artículo por sucursal -----------------------------------
CREATE OR REPLACE VIEW public.v_existencias_articulos AS
SELECT 'materia_prima'::VARCHAR(20) AS tipo,
       s.ingrediente_id             AS articulo_id,
       i.nombre,
       um.abreviatura               AS unidad,
       i.activo,
       s.sucursal_id,
       su.nombre                    AS sucursal,
       s.stock_actual,
       s.stock_minimo,
       s.actualizado_en
  FROM public.stock_sucursal s
  JOIN public.ingredientes i ON i.id = s.ingrediente_id
  JOIN public.unidades_medida um ON um.id = i.unidad_id
  JOIN public.sucursales su ON su.id = s.sucursal_id
UNION ALL
SELECT 'producto'::VARCHAR(20),
       s.producto_id,
       p.nombre,
       'un'::VARCHAR(10),
       p.activo,
       s.sucursal_id,
       su.nombre,
       s.stock_actual,
       s.stock_minimo,
       s.actualizado_en
  FROM public.stock_producto_sucursal s
  JOIN public.productos p ON p.id = s.producto_id
  JOIN public.sucursales su ON su.id = s.sucursal_id
 WHERE NOT EXISTS (SELECT 1 FROM public.recetas r WHERE r.producto_id = s.producto_id);

COMMENT ON VIEW public.v_existencias_articulos IS
    'Existencias de cada artículo por sucursal (H3.3 T02). Una fila por artículo y sucursal que ya tiene stock registrado.';

-- Solo los roles de inventario.
REVOKE ALL ON public.v_articulos, public.v_existencias_articulos FROM PUBLIC;
GRANT SELECT ON public.v_articulos, public.v_existencias_articulos TO nury_admin, nury_bodeguero;

-- T03) Unidad fija de una materia prima en uso -------------------------------------
CREATE OR REPLACE FUNCTION public.fn_ingrediente_unidad_fija()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $function$
BEGIN
    IF NEW.unidad_id IS DISTINCT FROM OLD.unidad_id AND (
           EXISTS (SELECT 1 FROM public.recetas WHERE ingrediente_id = OLD.id)
        OR EXISTS (SELECT 1 FROM public.movimientos_stock WHERE ingrediente_id = OLD.id)
        OR EXISTS (SELECT 1 FROM public.stock_sucursal WHERE ingrediente_id = OLD.id AND stock_actual <> 0)
    ) THEN
        RAISE EXCEPTION 'No se puede cambiar la unidad de "%": ya se usa en recetas o tiene stock', OLD.nombre
            USING ERRCODE = '22023';
    END IF;
    RETURN NEW;
END;
$function$;

DROP TRIGGER IF EXISTS trg_ingredientes_unidad_fija ON public.ingredientes;
CREATE TRIGGER trg_ingredientes_unidad_fija
    BEFORE UPDATE OF unidad_id ON public.ingredientes
    FOR EACH ROW EXECUTE FUNCTION public.fn_ingrediente_unidad_fija();

COMMIT;
