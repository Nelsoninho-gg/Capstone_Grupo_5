-- H2.5 T01 - Reglas de cálculo del consumo por receta: la receta usa la unidad base del
-- ingrediente.
--
-- Reglas (documentadas en docs/reglas-descuento-inventario.md):
--   1. Consumo de cada insumo = recetas.cantidad_necesaria × detalle_venta.cantidad
--      (fn_aplicar_venta, 0004). Ingredientes compartidos: cada línea descuenta lo suyo.
--   2. La cantidad de la receta está en la UNIDAD BASE del ingrediente (ingredientes.unidad_id,
--      fija desde H3.3). No hay conversión de unidades al vender.
--   3. Productos sin receta: descuentan su propio stock por unidad (H3.2, stock_producto_sucursal).
--   4. Saldo negativo permitido: la venta nunca se bloquea por falta de stock (H2.5 T04 avisa).
--
-- Lo que faltaba (regla 2): recetas.unidad_id es una columna propia y fn_aplicar_venta la
-- ignora. La pantalla siempre guarda la unidad del ingrediente, pero por la API se podía
-- guardar otra (p. ej. "g" para un ingrediente en "kg") y la venta descontaba mal.
--
-- trg_recetas_unidad_base (BEFORE INSERT/UPDATE): si unidad_id viene vacía, la completa
-- con la del ingrediente; si viene distinta, rechaza el cambio. Verificado en producción el
-- 2026-10-26: ninguna receta tenía hoy una unidad distinta a la de su ingrediente.
--
-- ANTES DE APLICAR EN PRODUCCIÓN: correr 20261027_receta_unidad_base.ENSAYO.sql (termina en
-- ROLLBACK) y la prueba database/tests/reglas_consumo_receta.sql en una base de pruebas.

BEGIN;

CREATE OR REPLACE FUNCTION public.fn_recetas_unidad_base()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $function$
DECLARE
    v_unidad     INTEGER;
    v_nombre     TEXT;
    v_abrev_base TEXT;
BEGIN
    SELECT i.unidad_id, i.nombre, um.abreviatura
      INTO v_unidad, v_nombre, v_abrev_base
      FROM public.ingredientes i
      JOIN public.unidades_medida um ON um.id = i.unidad_id
     WHERE i.id = NEW.ingrediente_id;

    IF NOT FOUND THEN
        RETURN NEW;  -- la llave foránea de ingrediente_id informa el error
    END IF;

    IF NEW.unidad_id IS NULL THEN
        NEW.unidad_id := v_unidad;
    ELSIF NEW.unidad_id <> v_unidad THEN
        RAISE EXCEPTION 'La receta debe usar la unidad base de "%" (%): no hay conversión de unidades al vender',
            v_nombre, v_abrev_base
            USING ERRCODE = '22023';
    END IF;
    RETURN NEW;
END;
$function$;

REVOKE ALL ON FUNCTION public.fn_recetas_unidad_base() FROM PUBLIC;

DROP TRIGGER IF EXISTS trg_recetas_unidad_base ON public.recetas;
CREATE TRIGGER trg_recetas_unidad_base
    BEFORE INSERT OR UPDATE OF unidad_id, ingrediente_id ON public.recetas
    FOR EACH ROW EXECUTE FUNCTION public.fn_recetas_unidad_base();

COMMENT ON COLUMN public.recetas.unidad_id IS
    'Siempre la unidad base del ingrediente (trg_recetas_unidad_base, H2.5 T01). cantidad_necesaria está en esa unidad.';

COMMIT;
