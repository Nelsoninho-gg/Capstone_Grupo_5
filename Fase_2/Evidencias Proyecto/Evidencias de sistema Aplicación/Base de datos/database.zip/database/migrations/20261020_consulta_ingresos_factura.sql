-- Consulta de ingresos de facturas XML realizados (H3.1 T09).
--
-- fn_listar_ingresos_factura(): facturas confirmadas, de la más reciente a la más antigua,
-- con su detalle original, el artículo asociado a cada línea, la equivalencia, la cantidad
-- incorporada, las líneas excluidas (no inventariables), quién y cuándo la ingresó, en qué
-- sucursal, y los intentos de volver a ingresarla (H3.7 T07).
--
-- fn_xml_factura(id): el XML original tal cual llegó, en base64, para descargarlo.
--
-- Quién ve qué (misma regla que el ingreso, H3.1 T07):
--   - admin: todas las sucursales.
--   - bodeguero: solo las facturas ingresadas en su sucursal (y los intentos sobre ellas).
--   - cajero y anónimos: sin acceso.
-- Son funciones SECURITY DEFINER porque reúnen datos de tablas que el bodeguero no lee
-- directamente (usuarios, proveedores); la regla de sucursal se aplica aquí.
--
-- shortcut: devuelve como máximo p_limite facturas (100 por defecto) sin paginar ni filtrar;
-- agregar paginación y filtros por fecha o proveedor cuando haya cientos de ingresos.
--
-- REQUIERE: 20261017_permisos_ingreso_facturas.sql, 20261017_ingresar_factura_xml.sql y
-- 20261020_intentos_factura_duplicada.sql.
--
-- ANTES DE APLICAR EN PRODUCCIÓN:
--   a) Revisar el script completo con el responsable.
--   b) Correr primero 20261020_consulta_ingresos_factura.ENSAYO.sql (termina en ROLLBACK).
--   c) Después de aplicar: NOTIFY pgrst, 'reload schema';

BEGIN;

-- 1) Listado de ingresos -----------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.fn_listar_ingresos_factura(p_limite INTEGER DEFAULT 100)
RETURNS JSONB
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_actor RECORD;
    v_admin BOOLEAN;
BEGIN
    SELECT * INTO v_actor FROM public.fn_actor_ingreso();
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Tu usuario no está autorizado para consultar ingresos de facturas'
            USING ERRCODE = '42501';
    END IF;
    v_admin := v_actor.rol IN ('admin', 'administrador');

    RETURN COALESCE((
        SELECT jsonb_agg(ingreso ORDER BY orden DESC, id DESC)
          FROM (
            SELECT x.id, x.confirmado_en AS orden,
                   jsonb_build_object(
                       'factura_xml_id', x.id,
                       'factura_compra_id', x.factura_id,
                       'folio', x.folio,
                       'tipo_documento', x.tipo_documento,
                       'rut_emisor', x.rut_emisor,
                       'razon_social_emisor', x.razon_social_emisor,
                       'proveedor', p.nombre,
                       'fecha_emision', x.fecha_emision,
                       'monto_neto', x.monto_neto,
                       'monto_iva', x.monto_iva,
                       'monto_total', x.monto_total,
                       'detalle_incluye_iva', x.detalle_incluye_iva,
                       'xml_nombre', x.xml_nombre,
                       'sucursal_id', x.sucursal_id,
                       'sucursal', s.nombre,
                       'ingresada_por', u.nombre,
                       'ingresada_en', x.confirmado_en,
                       'lineas', COALESCE((
                           SELECT jsonb_agg(jsonb_build_object(
                                      'numero_linea', l.numero_linea,
                                      'codigo_proveedor', l.codigo_proveedor,
                                      'descripcion', l.descripcion,
                                      'cantidad', l.cantidad,
                                      'precio_unitario', l.precio_unitario,
                                      'monto', l.monto,
                                      'tipo', CASE WHEN l.ingrediente_id IS NOT NULL THEN 'ingrediente'
                                                   WHEN l.producto_id IS NOT NULL THEN 'producto'
                                                   ELSE 'no-inventario' END,
                                      'articulo', COALESCE(i.nombre, pr.nombre),
                                      'unidad', CASE WHEN l.ingrediente_id IS NOT NULL THEN um.abreviatura
                                                     WHEN l.producto_id IS NOT NULL THEN 'un' END,
                                      'unidades_por_presentacion', l.unidades_por_presentacion,
                                      'cantidad_ingreso', l.cantidad_ingreso)
                                  ORDER BY l.numero_linea)
                             FROM public.facturas_xml_pendientes_lineas l
                             LEFT JOIN public.ingredientes i ON i.id = l.ingrediente_id
                             LEFT JOIN public.unidades_medida um ON um.id = i.unidad_id
                             LEFT JOIN public.productos pr ON pr.id = l.producto_id
                            WHERE l.factura_xml_id = x.id), '[]'::jsonb),
                       'intentos_duplicados', COALESCE((
                           SELECT jsonb_agg(jsonb_build_object(
                                      'creado_en', d.creado_en,
                                      'usuario', du.nombre,
                                      'sucursal_solicitada', ds.nombre,
                                      'xml_nombre', d.xml_nombre)
                                  ORDER BY d.creado_en DESC, d.id DESC)
                             FROM public.intentos_factura_duplicada d
                             LEFT JOIN public.usuarios du ON du.id = d.usuario_id
                             LEFT JOIN public.sucursales ds ON ds.id = d.sucursal_solicitada_id
                            WHERE d.factura_compra_id = x.factura_id), '[]'::jsonb)
                   ) AS ingreso
              FROM public.facturas_xml_pendientes x
              LEFT JOIN public.facturas_compra f ON f.id = x.factura_id
              LEFT JOIN public.proveedores p ON p.id = f.proveedor_id
              LEFT JOIN public.sucursales s ON s.id = x.sucursal_id
              LEFT JOIN public.usuarios u ON u.id = x.confirmado_por
             WHERE x.estado = 'confirmada'
               AND (v_admin OR x.sucursal_id = v_actor.sucursal_id)
             ORDER BY x.confirmado_en DESC, x.id DESC
             LIMIT GREATEST(LEAST(COALESCE(p_limite, 100), 500), 1)
          ) t
    ), '[]'::jsonb);
END;
$$;

REVOKE ALL ON FUNCTION public.fn_listar_ingresos_factura(integer) FROM PUBLIC, web_anon, nury_cajero;
GRANT EXECUTE ON FUNCTION public.fn_listar_ingresos_factura(integer) TO nury_admin, nury_bodeguero;

-- 2) XML original para descargar ----------------------------------------------------------

CREATE OR REPLACE FUNCTION public.fn_xml_factura(p_factura_xml_id INTEGER)
RETURNS JSONB
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_actor RECORD;
    v_xml   RECORD;
BEGIN
    SELECT * INTO v_actor FROM public.fn_actor_ingreso();
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Tu usuario no está autorizado para descargar facturas'
            USING ERRCODE = '42501';
    END IF;

    SELECT x.xml_nombre, x.xml_original, x.folio INTO v_xml
      FROM public.facturas_xml_pendientes x
     WHERE x.id = p_factura_xml_id
       AND x.estado = 'confirmada'
       AND (v_actor.rol IN ('admin', 'administrador') OR x.sucursal_id = v_actor.sucursal_id);
    -- Mismo mensaje si no existe o si es de otra sucursal: no revela qué facturas hay.
    IF NOT FOUND THEN
        RAISE EXCEPTION 'La factura no existe o no tienes acceso a ella'
            USING ERRCODE = '42501';
    END IF;

    RETURN jsonb_build_object(
        'xml_nombre', COALESCE(v_xml.xml_nombre, 'factura-' || v_xml.folio || '.xml'),
        'xml_base64', encode(v_xml.xml_original, 'base64'));
END;
$$;

REVOKE ALL ON FUNCTION public.fn_xml_factura(integer) FROM PUBLIC, web_anon, nury_cajero;
GRANT EXECUTE ON FUNCTION public.fn_xml_factura(integer) TO nury_admin, nury_bodeguero;

COMMIT;
