-- Ajuste manual de stock (carga inicial, conteo físico, correcciones).
--
-- Una sola función para los dos tipos de ítem con stock:
--   - un INGREDIENTE (stock_sucursal), o
--   - un PRODUCTO DE REVENTA, es decir sin receta (stock_producto_sucursal).
-- Deja siempre el rastro en el kardex (movimientos_stock) con tipo 'ajuste'.
-- No reemplaza a las compras: una factura sigue entrando por fn_aplicar_compra
-- con tipo 'compra'.
--
-- Requiere haber aplicado antes 0004_stock_producto_reventa.sql.
--
-- Semántica: p_cantidad es la DIFERENCIA a aplicar (positiva = entra stock,
-- negativa = sale stock), no el nuevo valor absoluto.
--
-- Después de aplicar: NOTIFY pgrst, 'reload schema';

BEGIN;

CREATE OR REPLACE FUNCTION public.fn_ajustar_stock(
    p_sucursal_id    INTEGER,
    p_cantidad       NUMERIC,
    p_motivo         TEXT,
    p_ingrediente_id INTEGER DEFAULT NULL,
    p_producto_id    INTEGER DEFAULT NULL
)
RETURNS public.movimientos_stock
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $function$
DECLARE
    v_motivo       TEXT := btrim(COALESCE(p_motivo, ''));
    v_stock_previo NUMERIC(12,3);
    v_nuevo_stock  NUMERIC(12,3);
    v_mov          public.movimientos_stock%ROWTYPE;
BEGIN
    -- Debe indicarse exactamente uno de los dos ítems.
    IF (p_ingrediente_id IS NULL) = (p_producto_id IS NULL) THEN
        RAISE EXCEPTION 'Indica un ingrediente o un producto (solo uno de los dos)'
            USING ERRCODE = '22023';
    END IF;

    IF p_cantidad IS NULL OR p_cantidad = 0 THEN
        RAISE EXCEPTION 'La cantidad del ajuste es obligatoria y no puede ser 0'
            USING ERRCODE = '22023';
    END IF;

    IF v_motivo = '' THEN
        RAISE EXCEPTION 'El motivo del ajuste es obligatorio'
            USING ERRCODE = '22023';
    END IF;

    IF NOT EXISTS (SELECT 1 FROM public.sucursales WHERE id = p_sucursal_id) THEN
        RAISE EXCEPTION 'La sucursal indicada no existe'
            USING ERRCODE = '23503';
    END IF;

    IF p_ingrediente_id IS NOT NULL THEN
        IF NOT EXISTS (SELECT 1 FROM public.ingredientes WHERE id = p_ingrediente_id) THEN
            RAISE EXCEPTION 'El ingrediente indicado no existe'
                USING ERRCODE = '23503';
        END IF;

        INSERT INTO public.stock_sucursal (ingrediente_id, sucursal_id, stock_actual, stock_minimo)
        VALUES (p_ingrediente_id, p_sucursal_id, 0, 0)
        ON CONFLICT (ingrediente_id, sucursal_id) DO NOTHING;

        SELECT stock_actual INTO v_stock_previo
          FROM public.stock_sucursal
         WHERE ingrediente_id = p_ingrediente_id AND sucursal_id = p_sucursal_id
         FOR UPDATE;
    ELSE
        IF NOT EXISTS (SELECT 1 FROM public.productos WHERE id = p_producto_id) THEN
            RAISE EXCEPTION 'El producto indicado no existe'
                USING ERRCODE = '23503';
        END IF;

        -- Un producto con receta no tiene stock propio: su stock son sus ingredientes.
        IF EXISTS (SELECT 1 FROM public.recetas WHERE producto_id = p_producto_id) THEN
            RAISE EXCEPTION 'Este producto tiene receta: su stock se ajusta a través de sus ingredientes'
                USING ERRCODE = '22023';
        END IF;

        INSERT INTO public.stock_producto_sucursal (producto_id, sucursal_id, stock_actual, stock_minimo)
        VALUES (p_producto_id, p_sucursal_id, 0, 0)
        ON CONFLICT (producto_id, sucursal_id) DO NOTHING;

        SELECT stock_actual INTO v_stock_previo
          FROM public.stock_producto_sucursal
         WHERE producto_id = p_producto_id AND sucursal_id = p_sucursal_id
         FOR UPDATE;
    END IF;

    v_nuevo_stock := v_stock_previo + p_cantidad;

    -- Un ajuste de salida no puede dejar el stock en negativo. Una entrada sí se
    -- permite aunque el stock siga negativo (p. ej. para regularizar ventas de prueba).
    IF p_cantidad < 0 AND v_nuevo_stock < 0 THEN
        RAISE EXCEPTION 'El ajuste dejaría el stock en negativo (actual: %, ajuste: %)',
            v_stock_previo, p_cantidad
            USING ERRCODE = '23514';
    END IF;

    IF p_ingrediente_id IS NOT NULL THEN
        UPDATE public.stock_sucursal
           SET stock_actual = v_nuevo_stock, actualizado_en = now()
         WHERE ingrediente_id = p_ingrediente_id AND sucursal_id = p_sucursal_id;
    ELSE
        UPDATE public.stock_producto_sucursal
           SET stock_actual = v_nuevo_stock, actualizado_en = now()
         WHERE producto_id = p_producto_id AND sucursal_id = p_sucursal_id;
    END IF;

    INSERT INTO public.movimientos_stock
        (ingrediente_id, producto_id, sucursal_id, tipo_movimiento, cantidad,
         stock_resultante, referencia_tipo, nota)
    VALUES
        (p_ingrediente_id, p_producto_id, p_sucursal_id, 'ajuste', p_cantidad,
         v_nuevo_stock, 'ajuste_manual', v_motivo)
    RETURNING * INTO v_mov;

    RETURN v_mov;
END;
$function$;

-- Solo roles de inventario. PostgREST publica únicamente lo ejecutable por el rol de la sesión.
REVOKE ALL ON FUNCTION public.fn_ajustar_stock(integer, numeric, text, integer, integer) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.fn_ajustar_stock(integer, numeric, text, integer, integer)
    TO nury_admin, nury_bodeguero;

COMMIT;
