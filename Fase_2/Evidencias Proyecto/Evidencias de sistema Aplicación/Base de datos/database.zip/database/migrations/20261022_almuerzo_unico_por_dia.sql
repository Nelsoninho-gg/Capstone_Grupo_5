-- H2.13 T04 — Almuerzo de empleados: al menos un producto y un solo almuerzo
-- por empleado al día, informando el motivo del rechazo.
--
--   - Un almuerzo sin productos ya lo rechazaba fn_registrar_almuerzo_empleado
--     (T03): "El almuerzo no tiene productos". Se mantiene.
--   - Un empleado solo registra un almuerzo por fecha (en hora de Chile), sin
--     importar la sucursal ni quién lo registre. Lo asegura un índice único, así
--     que ni dos cajeros registrando a la vez pueden duplicarlo. El rechazo
--     explica quién, dónde y a qué hora se registró el almuerzo del día.
--
-- Contenido:
--   T01  índice único (empleado_id, fecha)
--   T02  fn_registrar_almuerzo_empleado con el control diario (reemplaza la de T03)
--
-- Requiere: 20261022_registrar_almuerzo_empleado.sql.
--
-- ANTES DE APLICAR EN PRODUCCIÓN:
--   a) Revisar que no haya almuerzos repetidos (si hay, T01 falla y no se aplica nada):
--        SELECT empleado_id, fecha, count(*) FROM almuerzos_empleado
--         GROUP BY 1, 2 HAVING count(*) > 1;
--   b) Correr database/tests/almuerzo_unico_por_dia.sql.
--   c) Después de aplicar: NOTIFY pgrst, 'reload schema';

BEGIN;

-- T01) Un almuerzo por empleado y día --------------------------------------------
-- Reemplaza al índice no único de 20261022_almuerzos_empleado.sql, que cubría las
-- mismas columnas para la consulta por empleado y periodo.
CREATE UNIQUE INDEX IF NOT EXISTS ux_almuerzos_empleado_empleado_fecha
    ON public.almuerzos_empleado(empleado_id, fecha);

DROP INDEX IF EXISTS public.idx_almuerzos_empleado_empleado_fecha;

-- T02) Registro con el control diario ------------------------------------------------
-- Igual a la de 20261022_registrar_almuerzo_empleado.sql, más el control de un almuerzo
-- por día antes de guardar (con el detalle del ya registrado) y, si otro registro entra
-- al mismo tiempo, la traducción del índice único al mismo motivo.
CREATE OR REPLACE FUNCTION public.fn_registrar_almuerzo_empleado(
    p_sucursal_id INTEGER,
    p_empleado_id INTEGER,
    p_items       JSONB
)
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $function$
DECLARE
    v_actor_id    INTEGER := public.fn_usuario_actual_id();
    v_actor       RECORD;
    v_fecha       DATE := (now() AT TIME ZONE 'America/Santiago')::date;
    v_empleado    TEXT;
    v_previo      RECORD;
    v_almuerzo_id INTEGER;
    item          JSONB;
    v_producto_id INTEGER;
    v_cantidad    NUMERIC;
    v_vistos      INTEGER[] := '{}';
    linea         RECORD;
BEGIN
    IF v_actor_id IS NULL THEN
        RAISE EXCEPTION 'La sesión no identifica a un usuario autorizado' USING ERRCODE = '42501';
    END IF;

    SELECT rol, sucursal_id INTO v_actor FROM public.usuarios WHERE id = v_actor_id;

    IF NOT EXISTS (SELECT 1 FROM public.sucursales WHERE id = p_sucursal_id AND activo) THEN
        RAISE EXCEPTION 'La sucursal no existe o está deshabilitada' USING ERRCODE = '22023';
    END IF;

    IF v_actor.rol = 'cajero' AND v_actor.sucursal_id IS DISTINCT FROM p_sucursal_id THEN
        RAISE EXCEPTION 'Solo puedes registrar almuerzos en tu sucursal' USING ERRCODE = '42501';
    END IF;

    IF p_empleado_id IS NULL THEN
        RAISE EXCEPTION 'Debes indicar el empleado que almuerza' USING ERRCODE = '22023';
    END IF;

    SELECT nombre INTO v_empleado FROM public.usuarios WHERE id = p_empleado_id AND activo;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'El empleado no existe o está deshabilitado' USING ERRCODE = '22023';
    END IF;

    IF p_items IS NULL OR jsonb_typeof(p_items) <> 'array' OR jsonb_array_length(p_items) = 0 THEN
        RAISE EXCEPTION 'El almuerzo no tiene productos: agrega al menos uno' USING ERRCODE = '22023';
    END IF;

    -- Un almuerzo por día: se informa cuándo, dónde y quién registró el de hoy.
    SELECT a.creado_en, s.nombre AS sucursal, u.nombre AS cajero INTO v_previo
      FROM public.almuerzos_empleado a
      JOIN public.sucursales s ON s.id = a.sucursal_id
      JOIN public.usuarios u ON u.id = a.cajero_id
     WHERE a.empleado_id = p_empleado_id AND a.fecha = v_fecha;
    IF FOUND THEN
        RAISE EXCEPTION '% ya registró su almuerzo hoy (a las % en %, lo registró %). Solo se permite un almuerzo por día',
            v_empleado, to_char(v_previo.creado_en::timestamptz AT TIME ZONE 'America/Santiago', 'HH24:MI'),
            v_previo.sucursal, v_previo.cajero
            USING ERRCODE = '23505';
    END IF;

    BEGIN
        INSERT INTO public.almuerzos_empleado (sucursal_id, empleado_id, cajero_id, fecha)
        VALUES (p_sucursal_id, p_empleado_id, v_actor_id, v_fecha)
        RETURNING id INTO v_almuerzo_id;
    EXCEPTION
        WHEN unique_violation THEN
            -- Otro registro del mismo empleado entró justo antes que este.
            RAISE EXCEPTION '% ya registró su almuerzo hoy. Solo se permite un almuerzo por día', v_empleado
                USING ERRCODE = '23505';
    END;

    FOR item IN SELECT * FROM jsonb_array_elements(p_items)
    LOOP
        IF jsonb_typeof(item->'producto_id') <> 'number'
           OR (item->>'producto_id') !~ '^[0-9]{1,9}$' THEN
            RAISE EXCEPTION 'Producto no válido: %', item->'producto_id' USING ERRCODE = '22023';
        END IF;
        v_producto_id := (item->>'producto_id')::INTEGER;

        IF jsonb_typeof(item->'cantidad') <> 'number' OR (item->>'cantidad')::NUMERIC <= 0 THEN
            RAISE EXCEPTION 'La cantidad debe ser mayor que 0' USING ERRCODE = '22023';
        END IF;
        v_cantidad := (item->>'cantidad')::NUMERIC;
        -- Se consumen unidades del producto (un menú, una bebida): no hay fracciones.
        IF v_cantidad <> trunc(v_cantidad) THEN
            RAISE EXCEPTION 'La cantidad debe ser un número entero' USING ERRCODE = '22023';
        END IF;

        IF v_producto_id = ANY (v_vistos) THEN
            RAISE EXCEPTION 'El producto % está repetido en el almuerzo', v_producto_id USING ERRCODE = '22023';
        END IF;
        v_vistos := v_vistos || v_producto_id;

        IF NOT EXISTS (SELECT 1 FROM public.productos WHERE id = v_producto_id AND activo) THEN
            RAISE EXCEPTION 'Producto no encontrado o inactivo: %', v_producto_id USING ERRCODE = '22023';
        END IF;

        -- trg_almuerzos_empleado_detalle_receta_version completa receta_version_id.
        INSERT INTO public.almuerzos_empleado_detalle (almuerzo_id, producto_id, cantidad)
        VALUES (v_almuerzo_id, v_producto_id, v_cantidad)
        RETURNING producto_id, cantidad, receta_version_id INTO linea;

        PERFORM public.fn_descontar_stock_producto(
            linea.producto_id, p_sucursal_id, linea.cantidad, linea.receta_version_id,
            'consumo_interno', 'almuerzo_empleado', v_almuerzo_id);
    END LOOP;

    RETURN v_almuerzo_id;
END;
$function$;

COMMIT;

NOTIFY pgrst, 'reload schema';
