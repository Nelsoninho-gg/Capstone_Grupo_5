-- H3.3 T03 - El bodeguero crea, edita y activa o desactiva materias primas desde el Catálogo.
--
-- Hallazgo (2026-10-25): nury_bodeguero solo tenía SELECT sobre ingredientes, sin INSERT,
-- UPDATE ni uso de la secuencia del id. Por eso al bodeguero le fallaba guardar en la
-- pantalla antigua de Ingredientes y le fallaría en el Catálogo de Inventario. Con admin
-- funcionaba.
--
-- Se conceden solo las columnas que la app envía:
--   - INSERT: nombre, unidad_id, categoria_id, codigo_barras (activo, costo y fechas
--     quedan con su valor por defecto).
--   - UPDATE: nombre, codigo_barras, activo y categoria_id (esta última la sigue enviando
--     la pantalla antigua de Ingredientes hasta que se retire en H3.3 T04).
-- Nunca unidad_id (queda fija: trg_ingredientes_unidad_fija) ni costo_unitario_promedio
-- (lo calcula el ingreso de facturas). Sin DELETE: las materias primas se desactivan.
--
-- Productos de reventa: el bodeguero NO recibe permisos nuevos. Activarlos o desactivarlos
-- los saca o devuelve a la venta en el POS, y eso queda para admin (Maestro de Productos).
--
-- ANTES DE APLICAR EN PRODUCCIÓN: correr 20261025_catalogo_materias_primas_bodeguero.ENSAYO.sql
-- (termina en ROLLBACK). Idempotente. Debe ejecutarla el dueño de la tabla ingredientes.

BEGIN;

GRANT INSERT (nombre, unidad_id, categoria_id, codigo_barras) ON public.ingredientes TO nury_bodeguero;
GRANT UPDATE (nombre, codigo_barras, activo, categoria_id) ON public.ingredientes TO nury_bodeguero;
GRANT USAGE ON SEQUENCE public.ingredientes_id_seq TO nury_bodeguero;

COMMIT;

NOTIFY pgrst, 'reload schema';
