-- H3.2 T03 - Los consumos de la venta (receta H2.5 y stock propio H3.2) se aplican una sola
-- vez por venta.
--
-- El descuento ya es un único proceso: el trigger fn_aplicar_venta corre una vez por línea de
-- detalle_venta, dentro de la transacción de fn_registrar_venta, y descuenta ingredientes
-- (producto con receta) o el stock propio (producto sin receta). Los reintentos del POS no
-- duplican gracias a fn_registrar_venta_idempotente (H2.5 T05).
--
-- Faltaba: el trigger solo actúa al INSERTAR. Con permisos de admin por la API se podía
--   - agregar una línea a una venta ya registrada o anulada → se descontaba otra vez;
--   - cambiar el producto o la cantidad de una línea → el stock no se ajustaba;
--   - borrar una línea → el stock no se devolvía.
--
-- trg_ventas_en_curso (AFTER INSERT en ventas): marca la venta como "en curso" en una variable
-- local de la transacción (set_config(..., true)), que desaparece al terminarla.
-- trg_detalle_venta_una_vez (BEFORE INSERT/UPDATE/DELETE en detalle_venta):
--   - INSERT solo mientras la venta está en curso, es decir, en la misma transacción en que se
--     creó (dentro de fn_registrar_venta), y nunca en una venta anulada.
--   - UPDATE de venta_id, producto_id o cantidad: rechazado.
--   - DELETE: rechazado, salvo cuando se borra la venta completa (ON DELETE CASCADE).
-- Para corregir una venta se anula (repone el stock exacto, 0007) y se registra de nuevo.
--
-- ANTES DE APLICAR EN PRODUCCIÓN: correr 20261027_detalle_venta_una_vez.ENSAYO.sql (termina
-- en ROLLBACK) y la prueba database/tests/detalle_venta_una_vez.sql.

BEGIN;

CREATE OR REPLACE FUNCTION public.fn_ventas_en_curso()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = pg_catalog, public, pg_temp
AS $function$
BEGIN
    PERFORM set_config('nury.venta_en_curso_' || NEW.id, 'si', true);
    RETURN NEW;
END;
$function$;

REVOKE ALL ON FUNCTION public.fn_ventas_en_curso() FROM PUBLIC;

DROP TRIGGER IF EXISTS trg_ventas_en_curso ON public.ventas;
CREATE TRIGGER trg_ventas_en_curso
    AFTER INSERT ON public.ventas
    FOR EACH ROW EXECUTE FUNCTION public.fn_ventas_en_curso();

CREATE OR REPLACE FUNCTION public.fn_detalle_venta_una_vez()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $function$
DECLARE
    v_venta public.ventas%ROWTYPE;
BEGIN
    IF TG_OP = 'INSERT' THEN
        SELECT * INTO v_venta FROM public.ventas WHERE id = NEW.venta_id;
        IF NOT FOUND THEN
            RETURN NEW;  -- la llave foránea informa el error
        END IF;
        IF v_venta.anulada THEN
            RAISE EXCEPTION 'La venta #% está anulada: no se le pueden agregar productos', NEW.venta_id
                USING ERRCODE = '22023';
        END IF;
        -- La marca la deja trg_ventas_en_curso y solo vive en la transacción que creó la venta.
        IF current_setting('nury.venta_en_curso_' || NEW.venta_id, true) IS DISTINCT FROM 'si' THEN
            RAISE EXCEPTION 'La venta #% ya está registrada: sus productos solo se agregan al registrarla', NEW.venta_id
                USING ERRCODE = '22023';
        END IF;
        RETURN NEW;
    END IF;

    IF TG_OP = 'UPDATE' THEN
        IF NEW.venta_id IS DISTINCT FROM OLD.venta_id
           OR NEW.producto_id IS DISTINCT FROM OLD.producto_id
           OR NEW.cantidad IS DISTINCT FROM OLD.cantidad THEN
            RAISE EXCEPTION 'No se puede cambiar el producto ni la cantidad de una venta registrada: anúlala y regístrala de nuevo'
                USING ERRCODE = '22023';
        END IF;
        RETURN NEW;
    END IF;

    -- DELETE: solo como parte de borrar la venta completa (la venta ya no existe).
    IF EXISTS (SELECT 1 FROM public.ventas WHERE id = OLD.venta_id) THEN
        RAISE EXCEPTION 'No se pueden quitar productos de una venta registrada: anúlala y regístrala de nuevo'
            USING ERRCODE = '22023';
    END IF;
    RETURN OLD;
END;
$function$;

REVOKE ALL ON FUNCTION public.fn_detalle_venta_una_vez() FROM PUBLIC;

DROP TRIGGER IF EXISTS trg_detalle_venta_una_vez ON public.detalle_venta;
CREATE TRIGGER trg_detalle_venta_una_vez
    BEFORE INSERT OR UPDATE OR DELETE ON public.detalle_venta
    FOR EACH ROW EXECUTE FUNCTION public.fn_detalle_venta_una_vez();

COMMIT;
