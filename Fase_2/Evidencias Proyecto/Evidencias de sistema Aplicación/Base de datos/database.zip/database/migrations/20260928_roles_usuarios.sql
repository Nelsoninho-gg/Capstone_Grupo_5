-- Alinea los roles aceptados por usuarios con los roles que usa la aplicación.
-- La edición del esquema base cubre instalaciones nuevas; esta migración
-- actualiza bases de datos que ya fueron inicializadas.
ALTER TABLE usuarios
    DROP CONSTRAINT IF EXISTS usuarios_rol_check;

ALTER TABLE usuarios
    ADD CONSTRAINT usuarios_rol_check
    CHECK (rol IN ('admin', 'administrador', 'cajero', 'bodeguero'));
