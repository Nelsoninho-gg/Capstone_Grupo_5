-- Alta de usuarios desde la aplicación. El hash se genera en PostgreSQL;
-- el RPC nunca retorna password_hash.
CREATE EXTENSION IF NOT EXISTS pgcrypto;

ALTER TABLE usuarios
    DROP CONSTRAINT IF EXISTS usuarios_rol_check;

ALTER TABLE usuarios
    ADD CONSTRAINT usuarios_rol_check
    CHECK (rol IN ('admin', 'administrador', 'cajero', 'bodeguero'));

CREATE OR REPLACE FUNCTION crear_usuario(
    p_nombre VARCHAR(120),
    p_identificador_acceso VARCHAR(120),
    p_contrasena TEXT,
    p_rol VARCHAR(20),
    p_sucursal_id INTEGER,
    p_debe_cambiar_password BOOLEAN,
    p_activo BOOLEAN
)
RETURNS TABLE (
    id INTEGER,
    nombre VARCHAR(120),
    identificador_acceso VARCHAR(120),
    rol VARCHAR(20),
    sucursal_id INTEGER,
    debe_cambiar_password BOOLEAN,
    activo BOOLEAN,
    creado_en TIMESTAMP,
    actualizado_en TIMESTAMP
)
LANGUAGE plpgsql
AS $$
BEGIN
    IF p_nombre IS NULL OR btrim(p_nombre) = '' THEN
        RAISE EXCEPTION 'El nombre es obligatorio';
    END IF;

    IF p_identificador_acceso IS NULL OR btrim(p_identificador_acceso) = '' THEN
        RAISE EXCEPTION 'El usuario de acceso es obligatorio';
    END IF;

    IF p_contrasena IS NULL OR length(p_contrasena) < 4 THEN
        RAISE EXCEPTION 'La contraseña debe tener al menos 4 caracteres';
    END IF;

    RETURN QUERY
    INSERT INTO usuarios AS u (
        nombre,
        identificador_acceso,
        password_hash,
        rol,
        sucursal_id,
        debe_cambiar_password,
        activo
    )
    VALUES (
        p_nombre,
        p_identificador_acceso,
        crypt(p_contrasena, gen_salt('bf')),
        p_rol,
        p_sucursal_id,
        p_debe_cambiar_password,
        p_activo
    )
    RETURNING u.id, u.nombre, u.identificador_acceso, u.rol, u.sucursal_id,
              u.debe_cambiar_password, u.activo, u.creado_en, u.actualizado_en;
END;
$$;

-- PostgREST solo publica las funciones ejecutables por el rol de la sesión.
REVOKE ALL ON FUNCTION public.crear_usuario(
    character varying,
    character varying,
    text,
    character varying,
    integer,
    boolean,
    boolean
) FROM PUBLIC;

GRANT EXECUTE ON FUNCTION public.crear_usuario(
    character varying,
    character varying,
    text,
    character varying,
    integer,
    boolean,
    boolean
) TO nury_admin;

-- Refresca el caché de funciones de PostgREST después de aplicar la migración.
NOTIFY pgrst, 'reload schema';
