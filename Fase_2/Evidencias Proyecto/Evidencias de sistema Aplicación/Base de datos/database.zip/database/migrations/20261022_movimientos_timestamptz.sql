-- Zona horaria para movimientos de stock (Pedido 10).
--
-- Contexto (2026-10-22):
-- movimientos_stock.creado_en fue definido originalmente como TIMESTAMP (sin zona horaria)
-- y almacenaba en UTC. Al enviarse por PostgREST sin offset/zona explícita, requería
-- conversión manual en el cliente.
-- Se migra a TIMESTAMPTZ asumiendo que los registros existentes están en UTC, y se fija
-- DEFAULT now() para asegurar que todo evento guarde zona horaria explícita.
--
-- APLICADA EN PRODUCCIÓN/VPS el 2026-10-22 por dev_patricio (con rol nury_admin).
-- Requiere ser ejecutada por el dueño de las tablas (nury_admin).

SET ROLE nury_admin;

BEGIN;

ALTER TABLE public.movimientos_stock
    ALTER COLUMN creado_en TYPE TIMESTAMPTZ USING creado_en AT TIME ZONE 'UTC',
    ALTER COLUMN creado_en SET DEFAULT now();

COMMIT;

NOTIFY pgrst, 'reload schema';

RESET ROLE;
