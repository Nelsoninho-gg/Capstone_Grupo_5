-- H2.5 T05 - Venta idempotente: un reintento del POS no duplica la venta ni el descuento.
--
-- Problema: si la base guarda la venta (y descuenta el stock) pero la respuesta no llega
-- al POS (corte de red o los 15 s de espera), el carrito sigue lleno y el cajero vuelve a
-- cobrar: quedaban dos ventas y el stock descontado dos veces.
--
-- Solución, sin modificar fn_registrar_venta (la mantienen otros integrantes):
--   - ventas_idempotencia: una fila por clave (UUID que genera el POS por venta) con la
--     venta que produjo y el cajero.
--   - fn_registrar_venta_idempotente(p_clave, ...mismos parámetros...): bloquea la clave
--     durante la transacción (pg_advisory_xact_lock, así dos reintentos simultáneos se
--     esperan), y si ya existe devuelve la venta original sin volver a registrar nada. Si
--     no existe, llama a fn_registrar_venta tal cual y guarda la clave en la MISMA
--     transacción: si la venta falla, la clave tampoco queda y el reintento vuelve a
--     intentar.
--   - Una clave de otro cajero se rechaza (no se devuelve una venta ajena).
--
-- El descuento de inventario sigue siendo el de siempre (fn_aplicar_venta, trigger de
-- detalle_venta), dentro de la misma transacción de la venta.
--
-- ANTES DE APLICAR EN PRODUCCIÓN: correr 20261026_venta_idempotente.ENSAYO.sql (termina en
-- ROLLBACK) y la prueba database/tests/venta_idempotente.sql en una base de pruebas.

BEGIN;

CREATE TABLE IF NOT EXISTS public.ventas_idempotencia (
    clave      UUID PRIMARY KEY,
    venta_id   INTEGER NOT NULL UNIQUE REFERENCES public.ventas(id),
    cajero_id  INTEGER REFERENCES public.usuarios(id),
    creado_en  TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE public.ventas_idempotencia IS
    'Clave única por venta enviada por el POS (H2.5 T05): un reintento con la misma clave devuelve la venta original.';

-- Solo la usa la función (SECURITY DEFINER); los roles de la app no la leen ni escriben.
REVOKE ALL ON public.ventas_idempotencia FROM PUBLIC;

CREATE OR REPLACE FUNCTION public.fn_registrar_venta_idempotente(
    p_clave UUID,
    p_sucursal_id INTEGER,
    p_cajero_id INTEGER,
    p_medio_pago CHARACTER VARYING,
    p_items JSONB,
    p_tipo_venta CHARACTER VARYING DEFAULT 'normal',
    p_empleado_id INTEGER DEFAULT NULL
)
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $function$
DECLARE
    v_existente public.ventas_idempotencia%ROWTYPE;
    v_venta_id  INTEGER;
BEGIN
    IF p_clave IS NULL THEN
        RAISE EXCEPTION 'Falta la clave única de la venta' USING ERRCODE = '22023';
    END IF;

    -- Dos envíos simultáneos de la misma venta: el segundo espera al primero.
    PERFORM pg_advisory_xact_lock(hashtextextended(p_clave::text, 0));

    SELECT * INTO v_existente FROM public.ventas_idempotencia WHERE clave = p_clave;
    IF FOUND THEN
        IF v_existente.cajero_id IS DISTINCT FROM p_cajero_id THEN
            RAISE EXCEPTION 'La clave de esta venta pertenece a otro cajero' USING ERRCODE = '42501';
        END IF;
        RETURN v_existente.venta_id;  -- reintento: la venta ya quedó registrada
    END IF;

    v_venta_id := public.fn_registrar_venta(
        p_sucursal_id, p_cajero_id, p_medio_pago, p_items, p_tipo_venta, p_empleado_id);

    INSERT INTO public.ventas_idempotencia (clave, venta_id, cajero_id)
    VALUES (p_clave, v_venta_id, p_cajero_id);

    RETURN v_venta_id;
END;
$function$;

COMMENT ON FUNCTION public.fn_registrar_venta_idempotente(uuid, integer, integer, character varying, jsonb, character varying, integer) IS
    'Registra la venta una sola vez por clave (H2.5 T05). Mismos parámetros que fn_registrar_venta más p_clave.';

-- Mismos roles que usan fn_registrar_venta desde la app.
REVOKE ALL ON FUNCTION public.fn_registrar_venta_idempotente(uuid, integer, integer, character varying, jsonb, character varying, integer) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.fn_registrar_venta_idempotente(uuid, integer, integer, character varying, jsonb, character varying, integer)
    TO nury_admin, nury_cajero;

COMMIT;

NOTIFY pgrst, 'reload schema';
