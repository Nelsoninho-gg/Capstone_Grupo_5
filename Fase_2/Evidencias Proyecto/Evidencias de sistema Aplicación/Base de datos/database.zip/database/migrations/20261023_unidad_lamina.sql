-- Unidad "Lámina" para materias primas que se cuentan por lámina (queso o jamón
-- laminado, por ejemplo). Criterio de H3.3: "unidad de medida (gramos, litros,
-- unidades, láminas, etc.)".
--
-- YA APLICADA EN PRODUCCIÓN el 2026-10-23 (INSERT 0 1). Idempotente: nombre y
-- abreviatura son UNIQUE, así que volver a correrla no hace nada.

BEGIN;

INSERT INTO public.unidades_medida (nombre, abreviatura) VALUES ('Lámina', 'lám')
ON CONFLICT DO NOTHING;

COMMIT;
