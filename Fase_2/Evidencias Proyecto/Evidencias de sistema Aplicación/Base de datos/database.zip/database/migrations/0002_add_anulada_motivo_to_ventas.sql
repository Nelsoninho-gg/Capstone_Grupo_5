-- =====================================================================
-- Migración: agrega ventas.anulada_motivo
--
-- Por qué: al anular una venta se debe registrar el motivo, además de
-- quién (anulada_por) y cuándo (anulada_en), para que la anulación
-- quede trazable.
-- =====================================================================

ALTER TABLE ventas
    ADD COLUMN IF NOT EXISTS anulada_motivo TEXT;

COMMENT ON COLUMN ventas.anulada_motivo IS
    'Motivo ingresado al anular la venta. Nulo si la venta no está anulada.';
