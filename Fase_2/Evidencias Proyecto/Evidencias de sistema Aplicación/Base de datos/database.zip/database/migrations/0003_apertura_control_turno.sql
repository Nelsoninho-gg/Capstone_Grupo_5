-- 2.11 — Apertura y control de turno de caja.
--
-- Resuelve los criterios de aceptación que hoy no se cumplen:
--   1. Registrar cajero, sucursal, fecha/hora y monto inicial al abrir turno.
--   2. No permitir más de un turno activo para el mismo cajero y sucursal.
--   3. Bloquear ventas si no existe un turno activo autorizado.
--   4. Bloquear nuevas ventas después del cierre del turno.
--
-- Decisiones confirmadas (2026-10-01):
--   - monto_inicial es obligatorio en cada apertura, pero 0 es un valor válido.
--   - Abrir turno duplicado (mismo cajero + sucursal con uno ya activo) se
--     rechaza con un error claro, no se reutiliza el turno existente.
--   - Se agrega ventas.turno_id para poder asociar cada venta a su turno.
--
-- No toca fn_registrar_venta en su firma: sigue recibiendo los mismos
-- parámetros que ya usa el frontend; internamente ahora busca el turno
-- activo del cajero y rechaza la venta si no existe uno.

BEGIN;

-- 1) Columnas nuevas -------------------------------------------------------

ALTER TABLE public.turnos
    ADD COLUMN IF NOT EXISTS monto_inicial NUMERIC(12,2) NOT NULL DEFAULT 0
        CONSTRAINT turnos_monto_inicial_no_negativo CHECK (monto_inicial >= 0);

-- Sin DEFAULT: las ventas históricas quedan con turno_id NULL; las nuevas
-- siempre lo van a tener porque fn_registrar_venta lo exige.
ALTER TABLE public.ventas
    ADD COLUMN IF NOT EXISTS turno_id INTEGER REFERENCES public.turnos(id);

CREATE INDEX IF NOT EXISTS idx_ventas_turno_id ON public.ventas(turno_id);

-- 2) Un solo turno activo por cajero + sucursal -----------------------------
-- Defensa a nivel de base de datos además de la validación en fn_abrir_turno;
-- cubre condiciones de carrera (dos aperturas casi simultáneas).
CREATE UNIQUE INDEX IF NOT EXISTS turnos_activo_unico
    ON public.turnos (usuario_id, sucursal_id)
    WHERE hora_fin IS NULL;

-- 3) Abrir turno -------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.fn_abrir_turno(
    p_usuario_id INTEGER,
    p_sucursal_id INTEGER,
    p_monto_inicial NUMERIC
)
RETURNS public.turnos
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $function$
DECLARE
    v_turno public.turnos%ROWTYPE;
BEGIN
    IF p_monto_inicial IS NULL OR p_monto_inicial < 0 THEN
        RAISE EXCEPTION 'El monto inicial es obligatorio y no puede ser negativo'
            USING ERRCODE = '22023';
    END IF;

    IF EXISTS (
        SELECT 1 FROM public.turnos
         WHERE usuario_id = p_usuario_id
           AND sucursal_id = p_sucursal_id
           AND hora_fin IS NULL
    ) THEN
        RAISE EXCEPTION 'Ya existe un turno activo para este cajero en esta sucursal'
            USING ERRCODE = '23505';
    END IF;

    INSERT INTO public.turnos (usuario_id, sucursal_id, hora_inicio, monto_inicial)
    VALUES (p_usuario_id, p_sucursal_id, clock_timestamp(), p_monto_inicial)
    RETURNING * INTO v_turno;

    RETURN v_turno;
EXCEPTION
    WHEN unique_violation THEN
        -- Se perdió la carrera contra el índice único (dos aperturas casi
        -- simultáneas): mismo mensaje que la validación explícita de arriba.
        RAISE EXCEPTION 'Ya existe un turno activo para este cajero en esta sucursal'
            USING ERRCODE = '23505';
END;
$function$;

-- 4) Cerrar turno --------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.fn_cerrar_turno(
    p_turno_id INTEGER
)
RETURNS public.turnos
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $function$
DECLARE
    v_turno public.turnos%ROWTYPE;
BEGIN
    UPDATE public.turnos
       SET hora_fin = clock_timestamp()
     WHERE id = p_turno_id
       AND hora_fin IS NULL
    RETURNING * INTO v_turno;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'El turno no existe o ya estaba cerrado'
            USING ERRCODE = '22023';
    END IF;

    RETURN v_turno;
END;
$function$;

-- 5) fn_registrar_venta ahora exige turno activo -------------------------------
-- Misma firma que antes (no rompe el frontend actual). La única diferencia
-- es que ahora busca el turno activo del cajero/sucursal y lo asocia a la
-- venta; si no hay turno activo, rechaza la venta en vez de registrarla.

CREATE OR REPLACE FUNCTION public.fn_registrar_venta(
    p_sucursal_id INTEGER,
    p_cajero_id INTEGER,
    p_medio_pago CHARACTER VARYING,
    p_items JSONB
)
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'pg_catalog', 'public', 'pg_temp'
AS $function$
DECLARE
    v_venta_id      INTEGER;
    v_turno_id      INTEGER;
    item            JSONB;
    v_producto_id   INTEGER;
    v_precio_lista  NUMERIC(12,2);
    v_precio_final  NUMERIC(12,2);
    v_promocion_id  INTEGER;
    v_cantidad      NUMERIC(12,3);
BEGIN
    IF jsonb_array_length(p_items) = 0 THEN
        RAISE EXCEPTION 'La venta no tiene productos';
    END IF;

    SELECT id INTO v_turno_id
      FROM public.turnos
     WHERE usuario_id = p_cajero_id
       AND sucursal_id = p_sucursal_id
       AND hora_fin IS NULL
     ORDER BY hora_inicio DESC
     LIMIT 1;

    IF v_turno_id IS NULL THEN
        RAISE EXCEPTION 'No hay un turno activo para este cajero en esta sucursal; debes abrir turno antes de vender'
            USING ERRCODE = '28000';
    END IF;

    INSERT INTO ventas (sucursal_id, cajero_id, medio_pago, turno_id)
    VALUES (p_sucursal_id, p_cajero_id, p_medio_pago, v_turno_id)
    RETURNING id INTO v_venta_id;

    FOR item IN SELECT * FROM jsonb_array_elements(p_items)
    LOOP
        SELECT id, precio_venta INTO v_producto_id, v_precio_lista
          FROM productos
         WHERE nombre = item->>'producto' AND activo = TRUE;

        IF v_producto_id IS NULL THEN
            RAISE EXCEPTION 'Producto no encontrado o inactivo: %', item->>'producto';
        END IF;

        v_cantidad     := (item->>'cantidad')::NUMERIC;
        v_promocion_id := NULLIF(item->>'promocion_id', '')::INTEGER;
        v_precio_final := COALESCE((item->>'precio_unitario')::NUMERIC, v_precio_lista);

        INSERT INTO detalle_venta (venta_id, producto_id, promocion_id, cantidad, precio_lista, precio_unitario)
        VALUES (v_venta_id, v_producto_id, v_promocion_id, v_cantidad, v_precio_lista, v_precio_final);
    END LOOP;

    RETURN v_venta_id;
END;
$function$;

-- 6) Permisos ------------------------------------------------------------------
-- Mismo patrón que fn_registrar_venta: el cajero ejecuta las funciones (que
-- corren SECURITY DEFINER), no necesita grants directos sobre turnos/ventas.
GRANT EXECUTE ON FUNCTION public.fn_abrir_turno(integer, integer, numeric) TO nury_cajero, nury_admin;
GRANT EXECUTE ON FUNCTION public.fn_cerrar_turno(integer) TO nury_cajero, nury_admin;

COMMIT;
