-- H2.12 T02 — Venta a empleados: datos de la venta.
--
-- Agrega a `ventas`:
--   - tipo_venta: 'normal' (por defecto) o 'empleado'.
--   - empleado_id: usuario de Nury's que compra (solo en ventas a empleado).
--   - descuento_porcentaje / descuento_monto: descuento aplicado a la venta.
--   - codigo_venta: código para reportes, generado por la base de datos:
--       'TK-<id>' para ventas normales y 'EMP-<id>' para ventas a empleado.
--
-- Las ventas existentes quedan como 'normal', sin descuento y con código
-- 'TK-<id>', que es el mismo folio que ya muestra el POS.
--
-- Esta migración solo agrega las columnas. El cálculo del 30% y su
-- validación en fn_registrar_venta corresponden a la tarea T03.

BEGIN;

ALTER TABLE public.ventas
    ADD COLUMN IF NOT EXISTS tipo_venta VARCHAR(20) NOT NULL DEFAULT 'normal'
        CONSTRAINT ventas_tipo_venta_valido CHECK (tipo_venta IN ('normal', 'empleado')),
    ADD COLUMN IF NOT EXISTS empleado_id INTEGER REFERENCES public.usuarios(id),
    ADD COLUMN IF NOT EXISTS descuento_porcentaje NUMERIC(5,2) NOT NULL DEFAULT 0
        CONSTRAINT ventas_descuento_porcentaje_rango CHECK (descuento_porcentaje BETWEEN 0 AND 100),
    ADD COLUMN IF NOT EXISTS descuento_monto NUMERIC(12,2) NOT NULL DEFAULT 0
        CONSTRAINT ventas_descuento_monto_no_negativo CHECK (descuento_monto >= 0),
    ADD COLUMN IF NOT EXISTS codigo_venta VARCHAR(20)
        GENERATED ALWAYS AS (
            CASE WHEN tipo_venta = 'empleado' THEN 'EMP-' ELSE 'TK-' END || id
        ) STORED;

-- Una venta normal no lleva empleado ni descuento; una venta a empleado
-- siempre indica qué empleado compra.
ALTER TABLE public.ventas
    ADD CONSTRAINT ventas_tipo_venta_consistente CHECK (
        (tipo_venta = 'normal'
            AND empleado_id IS NULL
            AND descuento_porcentaje = 0
            AND descuento_monto = 0)
        OR
        (tipo_venta = 'empleado'
            AND empleado_id IS NOT NULL)
    );

CREATE INDEX IF NOT EXISTS idx_ventas_tipo_venta ON public.ventas(tipo_venta);

COMMENT ON COLUMN public.ventas.tipo_venta IS
    'normal o empleado (H2.12). Las ventas a empleado llevan descuento y empleado_id.';
COMMENT ON COLUMN public.ventas.empleado_id IS
    'Usuario de Nury''s que compra en una venta a empleado. Nulo en ventas normales.';
COMMENT ON COLUMN public.ventas.codigo_venta IS
    'Código para reportes: TK-<id> en ventas normales, EMP-<id> en ventas a empleado.';

COMMIT;
