-- Stock propio para productos de reventa simple (por sucursal).
--
-- Contexto: hasta ahora solo los ingredientes tenían stock (stock_sucursal) y
-- un producto descontaba únicamente a través de su receta. Un producto sin
-- receta (ej. una bebida envasada) no descontaba nada. Se acordó con el equipo
-- usar una tabla intermedia producto + sucursal, en lugar de crear un
-- "ingrediente espejo" por cada producto de reventa.
--
-- Regla de negocio (confirmada 2026-10-10):
--   - Producto CON receta  = de fabricación propia -> descuenta ingredientes.
--   - Producto SIN receta  = de reventa            -> descuenta su propio stock.
--
-- Contenido:
--   T01  tabla stock_producto_sucursal
--   T02  movimientos_stock admite producto_id (ingrediente_id pasa a nullable)
--   T03  fn_aplicar_venta con la rama de stock propio
--
-- ANTES DE APLICAR EN PRODUCCIÓN:
--   a) Comparar la versión actual de fn_aplicar_venta contra la de este script:
--        SELECT pg_get_functiondef('public.fn_aplicar_venta()'::regprocedure);
--      (la T03 la reemplaza completa; si producción difiere del repo, ajustar).
--   b) Correr primero 0004_stock_producto_reventa.ENSAYO.sql (termina en ROLLBACK).
--   c) Después de aplicar: NOTIFY pgrst, 'reload schema';

BEGIN;

-- T01) Tabla de stock por producto y sucursal ---------------------------------

CREATE TABLE IF NOT EXISTS public.stock_producto_sucursal (
    id              SERIAL PRIMARY KEY,
    producto_id     INTEGER NOT NULL REFERENCES public.productos(id),
    sucursal_id     INTEGER NOT NULL REFERENCES public.sucursales(id),
    stock_actual    NUMERIC(12,3) NOT NULL DEFAULT 0,
    stock_minimo    NUMERIC(12,3) NOT NULL DEFAULT 0,   -- umbral de reposición, propio de cada local
    actualizado_en  TIMESTAMP NOT NULL DEFAULT now(),
    UNIQUE (producto_id, sucursal_id)
);

CREATE INDEX IF NOT EXISTS idx_stock_producto_sucursal_sucursal
    ON public.stock_producto_sucursal(sucursal_id);

-- El trigger de venta corre con los privilegios del dueño de fn_registrar_venta
-- (SECURITY DEFINER). Si esta tabla quedara a nombre de quien aplica la
-- migración, ese rol no podría escribir en ella y fallarían las ventas de todos
-- los productos sin receta. Por eso se deja con el mismo dueño que stock_sucursal.
DO $$
DECLARE
    v_owner TEXT;
BEGIN
    SELECT pg_get_userbyid(relowner) INTO v_owner
      FROM pg_class WHERE oid = 'public.stock_sucursal'::regclass;

    EXECUTE format('ALTER TABLE public.stock_producto_sucursal OWNER TO %I', v_owner);
    EXECUTE format('ALTER SEQUENCE public.stock_producto_sucursal_id_seq OWNER TO %I', v_owner);
END $$;

-- Mismos permisos de lectura/escritura que ya tiene stock_sucursal, sin
-- adivinar roles: se copian desde su ACL. Las escrituras de la app irán por
-- funciones SECURITY DEFINER (venta y, más adelante, ajuste de stock).
DO $$
DECLARE
    r RECORD;
BEGIN
    FOR r IN
        SELECT DISTINCT a.privilege_type, pg_get_userbyid(a.grantee) AS rol
          FROM pg_class c, aclexplode(c.relacl) a
         WHERE c.oid = 'public.stock_sucursal'::regclass
           AND a.grantee <> 0
           AND a.grantee <> c.relowner
    LOOP
        EXECUTE format('GRANT %s ON public.stock_producto_sucursal TO %I',
                       r.privilege_type, r.rol);
    END LOOP;
END $$;

-- T02) Kardex: un movimiento es de un ingrediente O de un producto -------------

ALTER TABLE public.movimientos_stock
    ALTER COLUMN ingrediente_id DROP NOT NULL;

ALTER TABLE public.movimientos_stock
    ADD COLUMN IF NOT EXISTS producto_id INTEGER REFERENCES public.productos(id);

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
         WHERE conname = 'movimientos_stock_un_solo_item'
           AND conrelid = 'public.movimientos_stock'::regclass
    ) THEN
        ALTER TABLE public.movimientos_stock
            ADD CONSTRAINT movimientos_stock_un_solo_item
            CHECK ((ingrediente_id IS NULL) <> (producto_id IS NULL));
    END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_movimientos_producto_sucursal
    ON public.movimientos_stock(producto_id, sucursal_id, creado_en)
    WHERE producto_id IS NOT NULL;

-- T03) fn_aplicar_venta: receta -> ingredientes; sin receta -> stock propio -----
-- La rama con receta es la misma de siempre, sin cambios.

CREATE OR REPLACE FUNCTION public.fn_aplicar_venta() RETURNS TRIGGER AS $$
DECLARE
    v_sucursal_id  INTEGER;
    v_tiene_receta BOOLEAN;
    receta_row     RECORD;
    v_stock_previo NUMERIC(12,3);
    v_descuento    NUMERIC(12,3);
    v_nuevo_stock  NUMERIC(12,3);
    v_costo_receta NUMERIC(12,2);
BEGIN
    SELECT sucursal_id INTO v_sucursal_id FROM ventas WHERE id = NEW.venta_id;

    SELECT EXISTS (SELECT 1 FROM recetas WHERE producto_id = NEW.producto_id)
      INTO v_tiene_receta;

    IF v_tiene_receta THEN
        FOR receta_row IN
            SELECT ingrediente_id, cantidad_necesaria
              FROM recetas
             WHERE producto_id = NEW.producto_id
        LOOP
            v_descuento := receta_row.cantidad_necesaria * NEW.cantidad;

            INSERT INTO stock_sucursal (ingrediente_id, sucursal_id, stock_actual, stock_minimo)
            VALUES (receta_row.ingrediente_id, v_sucursal_id, 0, 0)
            ON CONFLICT (ingrediente_id, sucursal_id) DO NOTHING;

            SELECT stock_actual INTO v_stock_previo
              FROM stock_sucursal
             WHERE ingrediente_id = receta_row.ingrediente_id AND sucursal_id = v_sucursal_id
             FOR UPDATE;

            v_nuevo_stock := v_stock_previo - v_descuento;

            UPDATE stock_sucursal
               SET stock_actual = v_nuevo_stock,
                   actualizado_en = now()
             WHERE ingrediente_id = receta_row.ingrediente_id AND sucursal_id = v_sucursal_id;

            INSERT INTO movimientos_stock
                (ingrediente_id, sucursal_id, tipo_movimiento, cantidad, stock_resultante, referencia_tipo, referencia_id)
            VALUES
                (receta_row.ingrediente_id, v_sucursal_id, 'venta', -v_descuento, v_nuevo_stock, 'venta', NEW.venta_id);
        END LOOP;
    ELSE
        -- Producto de reventa: descuenta su propio stock en la sucursal de la venta.
        v_descuento := NEW.cantidad;

        INSERT INTO stock_producto_sucursal (producto_id, sucursal_id, stock_actual, stock_minimo)
        VALUES (NEW.producto_id, v_sucursal_id, 0, 0)
        ON CONFLICT (producto_id, sucursal_id) DO NOTHING;

        SELECT stock_actual INTO v_stock_previo
          FROM stock_producto_sucursal
         WHERE producto_id = NEW.producto_id AND sucursal_id = v_sucursal_id
         FOR UPDATE;

        v_nuevo_stock := v_stock_previo - v_descuento;

        UPDATE stock_producto_sucursal
           SET stock_actual = v_nuevo_stock,
               actualizado_en = now()
         WHERE producto_id = NEW.producto_id AND sucursal_id = v_sucursal_id;

        INSERT INTO movimientos_stock
            (producto_id, sucursal_id, tipo_movimiento, cantidad, stock_resultante, referencia_tipo, referencia_id)
        VALUES
            (NEW.producto_id, v_sucursal_id, 'venta', -v_descuento, v_nuevo_stock, 'venta', NEW.venta_id);
    END IF;

    -- Alerta de margen: si la línea trae promoción y el precio aplicado queda bajo el costo de receta, se registra (no bloquea)
    IF NEW.promocion_id IS NOT NULL THEN
        SELECT COALESCE(SUM(r.cantidad_necesaria * i.costo_unitario_promedio), 0)
          INTO v_costo_receta
          FROM recetas r JOIN ingredientes i ON i.id = r.ingrediente_id
         WHERE r.producto_id = NEW.producto_id;

        IF NEW.precio_unitario < v_costo_receta THEN
            INSERT INTO alertas_margen (promocion_id, producto_id, costo_receta, precio_aplicado, venta_id)
            VALUES (NEW.promocion_id, NEW.producto_id, v_costo_receta, NEW.precio_unitario, NEW.venta_id);
        END IF;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

COMMIT;
