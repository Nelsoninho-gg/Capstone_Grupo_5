-- ENSAYO de 20261017_ingresar_factura_xml.sql (H3.1 T08 y H3.7 T02).
-- Aplica el mismo cambio (el bloque entre «Cambio a ensayar» y «Datos de ejemplo» es
-- copia exacta del script real), ingresa facturas de ejemplo como admin, bodeguero y
-- cajero, revisa lo guardado y termina en ROLLBACK: no deja nada aplicado.
--
-- REQUIERE aplicados: 20261016_facturas_xml_pendientes.sql,
-- 20261017_equivalencias_lineas_xml.sql y 20261017_permisos_ingreso_facturas.sql.
--
-- Resultado: pestaña «Messages» de pgAdmin. Cada prueba aparece como «OK | ...» y al
-- final «ENSAYO COMPLETO». Si alguna falla, el ensayo termina con error: ejecuta
-- ROLLBACK; solo y pégame los avisos.

BEGIN;

-- Cambio a ensayar (igual al script real) ----------------------------------------------

-- 1) Identidad de la factura en facturas_compra (H3.7 T02) ------------------------

ALTER TABLE public.facturas_compra
    ADD COLUMN IF NOT EXISTS origen                 VARCHAR(10) NOT NULL DEFAULT 'manual',
    ADD COLUMN IF NOT EXISTS rut_emisor_normalizado VARCHAR(12),
    ADD COLUMN IF NOT EXISTS tipo_documento         SMALLINT,
    ADD COLUMN IF NOT EXISTS folio                  BIGINT;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint
                    WHERE conrelid = 'public.facturas_compra'::regclass
                      AND conname = 'facturas_compra_origen_check') THEN
        ALTER TABLE public.facturas_compra
            ADD CONSTRAINT facturas_compra_origen_check CHECK (origen IN ('manual', 'xml'));
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_constraint
                    WHERE conrelid = 'public.facturas_compra'::regclass
                      AND conname = 'facturas_compra_identidad_xml') THEN
        -- Toda factura que entra por XML trae su identidad completa.
        ALTER TABLE public.facturas_compra
            ADD CONSTRAINT facturas_compra_identidad_xml
            CHECK (origen <> 'xml'
                   OR (rut_emisor_normalizado IS NOT NULL AND tipo_documento IS NOT NULL AND folio IS NOT NULL));
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_constraint
                    WHERE conrelid = 'public.facturas_compra'::regclass
                      AND conname = 'facturas_compra_identidad_unica') THEN
        ALTER TABLE public.facturas_compra
            ADD CONSTRAINT facturas_compra_identidad_unica
            UNIQUE (rut_emisor_normalizado, tipo_documento, folio);
    END IF;
END $$;

-- 2) RUT normalizado: 12345678-K, con el dígito verificador comprobado -------------

CREATE OR REPLACE FUNCTION public.fn_normalizar_rut(p_rut TEXT)
RETURNS TEXT
LANGUAGE plpgsql
IMMUTABLE
SET search_path = pg_catalog, pg_temp
AS $$
DECLARE
    v_partes  TEXT[];
    v_cuerpo  TEXT;
    v_dv      TEXT;
    v_suma    INTEGER := 0;
    v_factor  INTEGER := 2;
    v_resto   INTEGER;
    v_pos     INTEGER;
BEGIN
    v_partes := regexp_match(upper(regexp_replace(COALESCE(p_rut, ''), '[.\s]', '', 'g')),
                             '^0*([0-9]{1,8})-?([0-9K])$');
    IF v_partes IS NULL THEN
        RETURN NULL;
    END IF;
    v_cuerpo := v_partes[1];
    v_dv := v_partes[2];

    FOR v_pos IN REVERSE length(v_cuerpo)..1 LOOP
        v_suma := v_suma + substr(v_cuerpo, v_pos, 1)::INTEGER * v_factor;
        v_factor := CASE WHEN v_factor = 7 THEN 2 ELSE v_factor + 1 END;
    END LOOP;
    v_resto := 11 - (v_suma % 11);

    IF (CASE v_resto WHEN 11 THEN '0' WHEN 10 THEN 'K' ELSE v_resto::TEXT END) <> v_dv THEN
        RETURN NULL;
    END IF;
    RETURN v_cuerpo || '-' || v_dv;
END;
$$;

-- 3) Lectura de un valor del DTE sin depender del namespace ------------------------
-- p_ruta es relativa al Documento ('Encabezado/IdDoc/Folio'), o a su línea número
-- p_detalle ('NmbItem'). Devuelve el texto sin espacios en los extremos, o NULL.

CREATE OR REPLACE FUNCTION public.fn_dte_texto(p_doc XML, p_ruta TEXT, p_detalle INTEGER DEFAULT NULL)
RETURNS TEXT
LANGUAGE plpgsql
IMMUTABLE
SET search_path = pg_catalog, pg_temp
AS $$
DECLARE
    v_xpath TEXT := '//*[local-name()="Documento"]';
    v_parte TEXT;
    v_valor TEXT;
BEGIN
    IF p_detalle IS NOT NULL THEN
        v_xpath := '(' || v_xpath || '/*[local-name()="Detalle"])[' || p_detalle || ']';
    END IF;
    FOREACH v_parte IN ARRAY string_to_array(p_ruta, '/') LOOP
        v_xpath := v_xpath || '/*[local-name()="' || v_parte || '"]';
    END LOOP;

    v_valor := (xpath('string(' || v_xpath || '[1])', p_doc))[1]::TEXT;
    -- xpath() devuelve el texto como XML: se deshacen las entidades básicas.
    v_valor := replace(replace(replace(replace(replace(v_valor,
                   '&lt;', '<'), '&gt;', '>'), '&quot;', '"'), '&apos;', ''''), '&amp;', '&');
    RETURN NULLIF(btrim(v_valor), '');
END;
$$;

-- 4) Ingreso completo de la factura ---------------------------------------------------

CREATE OR REPLACE FUNCTION public.fn_ingresar_factura_xml(
    p_sucursal_id INTEGER,
    p_xml_base64  TEXT,
    p_xml_nombre  TEXT,
    p_lineas      JSONB
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    c_documento CONSTANT TEXT := '//*[local-name()="Documento"]';
    c_tamano_maximo CONSTANT INTEGER := 5 * 1024 * 1024;

    v_actor            INTEGER;
    v_bytes            BYTEA;
    v_contenido        BYTEA;
    v_codificacion     TEXT;
    v_texto            TEXT;
    v_doc              XML;
    v_cantidad_docs    INTEGER;

    v_tipo             TEXT;
    v_folio_txt        TEXT;
    v_folio            BIGINT;
    v_fecha_txt        TEXT;
    v_fecha            DATE;
    v_venc_txt         TEXT;
    v_venc             DATE;
    v_rut              TEXT;
    v_rut_norm         TEXT;
    v_neto             NUMERIC;
    v_exento           NUMERIC;
    v_iva              NUMERIC;
    v_total            NUMERIC;
    v_tasa             NUMERIC;
    v_otros_txt        TEXT;
    v_otros            NUMERIC;
    v_incluye_iva      BOOLEAN;
    v_forma_pago       TEXT;
    v_orden_compra     TEXT;

    v_existente        INTEGER;
    v_proveedor        INTEGER;
    v_factura          INTEGER;
    v_pendiente        INTEGER;

    v_total_lineas     INTEGER;
    v_numeros          INTEGER[] := '{}';
    v_pos              INTEGER;
    v_nro              INTEGER;
    v_nro_txt          TEXT;
    v_desc             TEXT;
    v_codigo           TEXT;
    v_codigo_tipo      TEXT;
    v_qty_txt          TEXT;
    v_qty              NUMERIC;
    v_prc_txt          TEXT;
    v_prc              NUMERIC;
    v_monto_txt        TEXT;
    v_monto            NUMERIC;

    v_cuenta           INTEGER;
    v_asoc             JSONB;
    v_ingrediente      INTEGER;
    v_producto         INTEGER;
    v_no_inventario    BOOLEAN;
    v_equivalencia     NUMERIC;
    v_unidad           INTEGER;
    v_cantidad         NUMERIC;
    v_costo            NUMERIC;
    v_precio           NUMERIC;

    v_sin_asociar      INTEGER := 0;
    v_sin_equivalencia INTEGER := 0;
    v_lineas_stock     INTEGER := 0;
    v_lineas_otras     INTEGER := 0;
BEGIN
    -- Permiso y sucursal (42501 si no corresponde).
    v_actor := public.fn_validar_sucursal_ingreso(p_sucursal_id);

    IF p_lineas IS NULL OR jsonb_typeof(p_lineas) <> 'array' THEN
        RAISE EXCEPTION 'Indica qué hacer con cada línea de la factura' USING ERRCODE = '22023';
    END IF;

    -- Archivo ------------------------------------------------------------------
    BEGIN
        v_bytes := decode(COALESCE(p_xml_base64, ''), 'base64');
    EXCEPTION WHEN OTHERS THEN
        RAISE EXCEPTION 'El archivo no llegó completo. Vuelve a elegirlo.' USING ERRCODE = '22023';
    END;
    IF length(v_bytes) = 0 THEN
        RAISE EXCEPTION 'El archivo está vacío.' USING ERRCODE = '22023';
    END IF;
    IF length(v_bytes) > c_tamano_maximo THEN
        RAISE EXCEPTION 'El archivo pesa más de 5 MB.' USING ERRCODE = '22023';
    END IF;

    -- Codificación declarada en <?xml ... encoding="..."?>; sin declaración, UTF-8.
    IF substring(v_bytes FROM 1 FOR 3) = '\xefbbbf'::BYTEA THEN
        v_contenido := substring(v_bytes FROM 4);
        v_codificacion := 'UTF8';
    ELSE
        v_contenido := v_bytes;
        v_codificacion := COALESCE(
            substring(convert_from(substring(v_bytes FROM 1 FOR 200), 'LATIN1')
                      FROM '^\s*<\?xml[^>]*encoding\s*=\s*["'']([^"'']+)["'']'),
            'UTF8');
    END IF;

    BEGIN
        v_texto := convert_from(v_contenido, v_codificacion);
    EXCEPTION WHEN OTHERS THEN
        RAISE EXCEPTION 'El archivo declara una codificación desconocida o tiene caracteres inválidos (%).',
            v_codificacion USING ERRCODE = '22023';
    END;
    -- El texto ya está en la codificación de la base: se quita la declaración.
    v_texto := regexp_replace(v_texto, '^\s*<\?xml[^>]*\?>', '');

    BEGIN
        v_doc := XMLPARSE(DOCUMENT v_texto);
    EXCEPTION WHEN OTHERS THEN
        RAISE EXCEPTION 'El archivo no es un XML válido o está dañado.' USING ERRCODE = '22023';
    END;

    v_cantidad_docs := (xpath('count(' || c_documento || ')', v_doc))[1]::TEXT::NUMERIC::INTEGER;
    IF v_cantidad_docs = 0 THEN
        RAISE EXCEPTION 'El archivo no contiene un documento tributario electrónico (DTE).' USING ERRCODE = '22023';
    END IF;
    IF v_cantidad_docs > 1 THEN
        RAISE EXCEPTION 'El archivo contiene % documentos. Carga una factura a la vez.', v_cantidad_docs
            USING ERRCODE = '22023';
    END IF;

    -- Encabezado ----------------------------------------------------------------
    v_tipo := public.fn_dte_texto(v_doc, 'Encabezado/IdDoc/TipoDTE');
    IF v_tipo IS NULL THEN
        RAISE EXCEPTION 'No indica el tipo de documento (TipoDTE).' USING ERRCODE = '22023';
    END IF;
    IF v_tipo <> '33' THEN
        RAISE EXCEPTION 'El documento es tipo %. Solo se aceptan facturas electrónicas (tipo 33).', v_tipo
            USING ERRCODE = '22023';
    END IF;

    v_folio_txt := public.fn_dte_texto(v_doc, 'Encabezado/IdDoc/Folio');
    IF v_folio_txt IS NULL OR v_folio_txt !~ '^[0-9]{1,18}$' OR v_folio_txt::BIGINT <= 0 THEN
        RAISE EXCEPTION 'El folio falta o no es un número válido.' USING ERRCODE = '22023';
    END IF;
    v_folio := v_folio_txt::BIGINT;

    v_fecha_txt := public.fn_dte_texto(v_doc, 'Encabezado/IdDoc/FchEmis');
    BEGIN
        IF v_fecha_txt !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$' THEN
            RAISE EXCEPTION 'fecha';
        END IF;
        v_fecha := v_fecha_txt::DATE;
    EXCEPTION WHEN OTHERS THEN
        RAISE EXCEPTION 'La fecha de emisión falta o no es válida.' USING ERRCODE = '22023';
    END;
    IF v_fecha IS NULL THEN
        RAISE EXCEPTION 'La fecha de emisión falta o no es válida.' USING ERRCODE = '22023';
    END IF;

    v_venc_txt := public.fn_dte_texto(v_doc, 'Encabezado/IdDoc/FchVenc');
    IF v_venc_txt IS NOT NULL THEN
        BEGIN
            IF v_venc_txt !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$' THEN
                RAISE EXCEPTION 'fecha';
            END IF;
            v_venc := v_venc_txt::DATE;
        EXCEPTION WHEN OTHERS THEN
            RAISE EXCEPTION 'La fecha de vencimiento no es válida.' USING ERRCODE = '22023';
        END;
    END IF;

    v_rut := public.fn_dte_texto(v_doc, 'Encabezado/Emisor/RUTEmisor');
    IF v_rut IS NULL THEN
        RAISE EXCEPTION 'No indica el RUT del emisor.' USING ERRCODE = '22023';
    END IF;
    v_rut_norm := public.fn_normalizar_rut(v_rut);
    IF v_rut_norm IS NULL THEN
        RAISE EXCEPTION 'El RUT del emisor (%) no es válido.', v_rut USING ERRCODE = '22023';
    END IF;

    v_neto   := CASE WHEN public.fn_dte_texto(v_doc, 'Encabezado/Totales/MntNeto') ~ '^-?[0-9]+$'
                     THEN public.fn_dte_texto(v_doc, 'Encabezado/Totales/MntNeto')::NUMERIC END;
    v_iva    := CASE WHEN public.fn_dte_texto(v_doc, 'Encabezado/Totales/IVA') ~ '^-?[0-9]+$'
                     THEN public.fn_dte_texto(v_doc, 'Encabezado/Totales/IVA')::NUMERIC END;
    v_total  := CASE WHEN public.fn_dte_texto(v_doc, 'Encabezado/Totales/MntTotal') ~ '^-?[0-9]+$'
                     THEN public.fn_dte_texto(v_doc, 'Encabezado/Totales/MntTotal')::NUMERIC END;
    v_exento := CASE WHEN public.fn_dte_texto(v_doc, 'Encabezado/Totales/MntExe') ~ '^-?[0-9]+$'
                     THEN public.fn_dte_texto(v_doc, 'Encabezado/Totales/MntExe')::NUMERIC ELSE 0 END;
    v_tasa   := CASE WHEN public.fn_dte_texto(v_doc, 'Encabezado/Totales/TasaIVA') ~ '^[0-9]+(\.[0-9]+)?$'
                     THEN public.fn_dte_texto(v_doc, 'Encabezado/Totales/TasaIVA')::NUMERIC END;
    IF v_neto IS NULL THEN
        RAISE EXCEPTION 'Falta el monto neto (MntNeto) o no es un número entero.' USING ERRCODE = '22023';
    END IF;
    IF v_iva IS NULL THEN
        RAISE EXCEPTION 'Falta el IVA o no es un número entero.' USING ERRCODE = '22023';
    END IF;
    IF v_total IS NULL THEN
        RAISE EXCEPTION 'Falta el monto total (MntTotal) o no es un número entero.' USING ERRCODE = '22023';
    END IF;

    v_otros_txt := (xpath('sum(' || c_documento || '/*[local-name()="Encabezado"]/*[local-name()="Totales"]'
                          || '/*[local-name()="ImptoReten"]/*[local-name()="MontoImp"])', v_doc))[1]::TEXT;
    IF v_otros_txt !~ '^-?[0-9]+(\.[0-9]+)?$' THEN
        RAISE EXCEPTION 'Los impuestos adicionales (ImptoReten) no son números válidos.' USING ERRCODE = '22023';
    END IF;
    v_otros := v_otros_txt::NUMERIC;

    IF v_neto + v_exento + v_iva + v_otros <> v_total THEN
        RAISE EXCEPTION 'Los totales no cuadran: neto, exento, IVA e impuestos suman %, pero el total informado es %.',
            v_neto + v_exento + v_iva + v_otros, v_total USING ERRCODE = '22023';
    END IF;

    v_incluye_iva := COALESCE(public.fn_dte_texto(v_doc, 'Encabezado/IdDoc/IndMntBruto') = '1', FALSE);
    v_forma_pago := public.fn_dte_texto(v_doc, 'Encabezado/IdDoc/FmaPago');
    v_orden_compra := NULLIF(btrim((xpath('string(' || c_documento
        || '/*[local-name()="Referencia"][*[local-name()="TpoDocRef"]="801"][1]/*[local-name()="FolioRef"])',
        v_doc))[1]::TEXT), '');

    -- ¿Ya fue ingresada? (H3.7) -------------------------------------------------------
    -- El candado serializa dos confirmaciones de la misma factura (doble clic o dos
    -- sesiones): la segunda espera y luego ve la primera. La restricción única es la
    -- última defensa.
    PERFORM pg_advisory_xact_lock(hashtext('factura_xml:' || v_rut_norm || ':33:' || v_folio));

    SELECT f.id INTO v_existente
      FROM public.facturas_compra f
     WHERE f.rut_emisor_normalizado = v_rut_norm AND f.tipo_documento = 33 AND f.folio = v_folio;
    IF FOUND THEN
        RAISE EXCEPTION 'Esta factura ya fue ingresada (folio % del emisor %).', v_folio, v_rut_norm
            USING ERRCODE = '23505', DETAIL = 'factura_compra_id=' || v_existente;
    END IF;

    -- Proveedor por RUT; si no existe queda NULL (decidido el 16/10/2026).
    SELECT p.id INTO v_proveedor
      FROM public.proveedores p
     WHERE public.fn_normalizar_rut(p.rut) = v_rut_norm
     LIMIT 1;

    -- Cabeceras ------------------------------------------------------------------
    INSERT INTO public.facturas_compra
        (proveedor_id, sucursal_id, numero_factura, fecha_factura, monto_neto, monto_iva,
         monto_impuestos_especificos, monto_total, estado, origen,
         rut_emisor_normalizado, tipo_documento, folio)
    VALUES
        (v_proveedor, p_sucursal_id, v_folio::TEXT, v_fecha, v_neto, v_iva,
         v_otros, v_total, 'confirmada', 'xml',
         v_rut_norm, 33, v_folio)
    RETURNING id INTO v_factura;

    INSERT INTO public.facturas_xml_pendientes
        (sucursal_id, cargado_por, estado, tipo_documento, folio, rut_emisor, rut_emisor_normalizado,
         razon_social_emisor, rut_receptor, fecha_emision, fecha_vencimiento, forma_pago,
         orden_compra_referencia, monto_neto, monto_iva, tasa_iva, monto_total,
         xml_original, xml_nombre, xml_sha256, detalle_incluye_iva,
         factura_id, confirmado_por, confirmado_en)
    VALUES
        (p_sucursal_id, v_actor, 'confirmada', 33, v_folio, left(v_rut, 12), v_rut_norm,
         left(public.fn_dte_texto(v_doc, 'Encabezado/Emisor/RznSoc'), 150),
         left(public.fn_dte_texto(v_doc, 'Encabezado/Receptor/RUTRecep'), 12),
         v_fecha, v_venc,
         CASE WHEN v_forma_pago ~ '^[0-9]{1,4}$' THEN v_forma_pago::SMALLINT END,
         left(v_orden_compra, 60), v_neto, v_iva, v_tasa, v_total,
         v_bytes, left(p_xml_nombre, 255), encode(sha256(v_bytes), 'hex'), v_incluye_iva,
         v_factura, v_actor, now())
    RETURNING id INTO v_pendiente;

    -- Líneas -------------------------------------------------------------------------
    v_total_lineas := (xpath('count(' || c_documento || '/*[local-name()="Detalle"])', v_doc))[1]::TEXT::NUMERIC::INTEGER;
    IF v_total_lineas = 0 THEN
        RAISE EXCEPTION 'La factura no trae líneas de detalle.' USING ERRCODE = '22023';
    END IF;

    FOR v_pos IN 1..v_total_lineas LOOP
        v_nro_txt := public.fn_dte_texto(v_doc, 'NroLinDet', v_pos);
        v_nro := CASE WHEN v_nro_txt ~ '^[0-9]{1,9}$' THEN v_nro_txt::INTEGER ELSE v_pos END;
        IF v_nro = ANY (v_numeros) THEN
            RAISE EXCEPTION 'La factura repite el número de línea %.', v_nro USING ERRCODE = '22023';
        END IF;
        v_numeros := v_numeros || v_nro;

        v_desc := public.fn_dte_texto(v_doc, 'NmbItem', v_pos);
        v_codigo := public.fn_dte_texto(v_doc, 'CdgItem/VlrCodigo', v_pos);
        v_codigo_tipo := public.fn_dte_texto(v_doc, 'CdgItem/TpoCodigo', v_pos);
        v_qty_txt := public.fn_dte_texto(v_doc, 'QtyItem', v_pos);
        v_prc_txt := public.fn_dte_texto(v_doc, 'PrcItem', v_pos);
        v_monto_txt := public.fn_dte_texto(v_doc, 'MontoItem', v_pos);

        IF v_desc IS NULL THEN
            RAISE EXCEPTION 'Línea %: falta la descripción del artículo.', v_nro USING ERRCODE = '22023';
        END IF;
        IF v_qty_txt IS NULL OR v_qty_txt !~ '^[0-9]+(\.[0-9]+)?$' OR v_qty_txt::NUMERIC <= 0 THEN
            RAISE EXCEPTION 'Línea %: la cantidad falta o no es mayor que cero.', v_nro USING ERRCODE = '22023';
        END IF;
        IF v_prc_txt IS NULL OR v_prc_txt !~ '^[0-9]+(\.[0-9]+)?$' THEN
            RAISE EXCEPTION 'Línea %: falta el precio unitario.', v_nro USING ERRCODE = '22023';
        END IF;
        IF v_monto_txt IS NULL OR v_monto_txt !~ '^-?[0-9]+$' THEN
            RAISE EXCEPTION 'Línea %: falta el monto de la línea.', v_nro USING ERRCODE = '22023';
        END IF;
        v_qty := v_qty_txt::NUMERIC;
        v_prc := v_prc_txt::NUMERIC;
        v_monto := v_monto_txt::NUMERIC;

        -- Qué eligió el usuario para esta línea.
        SELECT count(*) INTO v_cuenta
          FROM jsonb_array_elements(p_lineas) e
         WHERE e->>'numero_linea' = v_nro::TEXT;
        IF v_cuenta > 1 THEN
            RAISE EXCEPTION 'La línea % aparece más de una vez en la asociación.', v_nro USING ERRCODE = '22023';
        END IF;
        SELECT e INTO v_asoc
          FROM jsonb_array_elements(p_lineas) e
         WHERE e->>'numero_linea' = v_nro::TEXT;

        v_ingrediente := CASE WHEN v_asoc->>'ingrediente_id' ~ '^[0-9]{1,9}$'
                              THEN (v_asoc->>'ingrediente_id')::INTEGER END;
        v_producto := CASE WHEN v_asoc->>'producto_id' ~ '^[0-9]{1,9}$'
                           THEN (v_asoc->>'producto_id')::INTEGER END;
        v_no_inventario := COALESCE(v_asoc->'no_corresponde_inventario' = 'true'::JSONB, FALSE);
        v_equivalencia := CASE WHEN jsonb_typeof(v_asoc->'unidades_por_presentacion') = 'number'
                               THEN (v_asoc->>'unidades_por_presentacion')::NUMERIC END;

        IF num_nonnulls(v_ingrediente, v_producto) + (CASE WHEN v_no_inventario THEN 1 ELSE 0 END) > 1 THEN
            RAISE EXCEPTION 'La línea % tiene más de una clasificación.', v_nro USING ERRCODE = '22023';
        END IF;

        IF v_asoc IS NULL OR (num_nonnulls(v_ingrediente, v_producto) = 0 AND NOT v_no_inventario) THEN
            v_sin_asociar := v_sin_asociar + 1;
            CONTINUE;
        END IF;

        IF v_no_inventario THEN
            INSERT INTO public.facturas_xml_pendientes_lineas
                (factura_xml_id, numero_linea, codigo_tipo, codigo_proveedor, descripcion,
                 cantidad, precio_unitario, monto, no_corresponde_inventario)
            VALUES
                (v_pendiente, v_nro, left(v_codigo_tipo, 20), left(v_codigo, 60), left(v_desc, 255),
                 v_qty, v_prc, v_monto, TRUE);
            v_lineas_otras := v_lineas_otras + 1;
            CONTINUE;
        END IF;

        IF v_equivalencia IS NULL OR v_equivalencia <= 0 OR v_equivalencia <> round(v_equivalencia, 3) THEN
            v_sin_equivalencia := v_sin_equivalencia + 1;
            CONTINUE;
        END IF;

        IF v_ingrediente IS NOT NULL THEN
            SELECT i.unidad_id INTO v_unidad
              FROM public.ingredientes i
             WHERE i.id = v_ingrediente AND i.activo;
            IF NOT FOUND THEN
                RAISE EXCEPTION 'Línea %: la materia prima elegida no existe o está inactiva.', v_nro
                    USING ERRCODE = '22023';
            END IF;
        ELSE
            IF NOT EXISTS (SELECT 1 FROM public.productos p WHERE p.id = v_producto AND p.activo) THEN
                RAISE EXCEPTION 'Línea %: el producto elegido no existe o está inactivo.', v_nro
                    USING ERRCODE = '22023';
            END IF;
            IF EXISTS (SELECT 1 FROM public.recetas r WHERE r.producto_id = v_producto) THEN
                RAISE EXCEPTION 'Línea %: el producto elegido tiene receta; su stock sale de sus ingredientes.', v_nro
                    USING ERRCODE = '22023';
            END IF;
            v_unidad := NULL;
        END IF;

        v_cantidad := round(v_qty * v_equivalencia, 3);
        IF v_cantidad <= 0 THEN
            RAISE EXCEPTION 'Línea %: la cantidad a ingresar es demasiado pequeña.', v_nro USING ERRCODE = '22023';
        END IF;

        INSERT INTO public.facturas_xml_pendientes_lineas
            (factura_xml_id, numero_linea, codigo_tipo, codigo_proveedor, descripcion,
             cantidad, precio_unitario, monto, ingrediente_id, producto_id, unidades_por_presentacion)
        VALUES
            (v_pendiente, v_nro, left(v_codigo_tipo, 20), left(v_codigo, 60), left(v_desc, 255),
             v_qty, v_prc, v_monto, v_ingrediente, v_producto, v_equivalencia);

        -- Costo neto de la línea; si los montos incluyen IVA, se le descuenta.
        v_costo := CASE WHEN v_incluye_iva
                        THEN round(v_monto / (1 + COALESCE(v_tasa, 19) / 100), 2)
                        ELSE v_monto END;
        v_precio := round(v_costo / v_cantidad, 2);

        -- El stock lo suma fn_aplicar_compra (AFTER INSERT), una sola vez por fila.
        INSERT INTO public.detalle_factura_compra
            (factura_id, ingrediente_id, producto_id, codigo_proveedor, unidades_por_presentacion,
             cantidad, unidad_id, precio_unitario, descuento_monto)
        VALUES
            (v_factura, v_ingrediente, v_producto, left(v_codigo, 30),
             CASE WHEN v_equivalencia = round(v_equivalencia, 2) AND v_equivalencia < 100000000
                  THEN v_equivalencia END,
             v_cantidad, v_unidad, v_precio,
             -- Diferencia de redondeo de precio_unitario (2 decimales): así subtotal_neto
             -- es exactamente el monto de la línea.
             round(v_cantidad * v_precio, 2) - v_costo);

        v_lineas_stock := v_lineas_stock + 1;
    END LOOP;

    IF v_sin_asociar > 0 THEN
        RAISE EXCEPTION 'Faltan asociar % línea(s): elige un artículo o márcalas como «No corresponde a inventario».',
            v_sin_asociar USING ERRCODE = '22023';
    END IF;
    IF v_sin_equivalencia > 0 THEN
        RAISE EXCEPTION 'Falta la equivalencia de % línea(s) asociadas a un artículo.', v_sin_equivalencia
            USING ERRCODE = '22023';
    END IF;
    IF EXISTS (SELECT 1 FROM jsonb_array_elements(p_lineas) e
                WHERE NOT (e->>'numero_linea' ~ '^[0-9]{1,9}$'
                           AND (e->>'numero_linea')::INTEGER = ANY (v_numeros))) THEN
        RAISE EXCEPTION 'La asociación menciona líneas que no están en la factura.' USING ERRCODE = '22023';
    END IF;

    RETURN jsonb_build_object(
        'factura_compra_id', v_factura,
        'factura_xml_id', v_pendiente,
        'lineas_inventario', v_lineas_stock,
        'lineas_no_inventario', v_lineas_otras);
END;
$$;

-- Solo roles de inventario. Las funciones auxiliares no se publican como RPC.
REVOKE ALL ON FUNCTION public.fn_ingresar_factura_xml(integer, text, text, jsonb)
    FROM PUBLIC, web_anon, nury_cajero;
GRANT EXECUTE ON FUNCTION public.fn_ingresar_factura_xml(integer, text, text, jsonb)
    TO nury_admin, nury_bodeguero;
REVOKE ALL ON FUNCTION public.fn_dte_texto(xml, text, integer) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.fn_normalizar_rut(text) FROM PUBLIC;

-- Datos de ejemplo (se descartan con el ROLLBACK) -----------------------------------

CREATE TEMP TABLE _resultados (prueba TEXT, resultado TEXT);
GRANT ALL ON _resultados TO PUBLIC;

CREATE TEMP TABLE _casos (
    s1 INTEGER, s2 INTEGER, admin INTEGER, bodeguero INTEGER, cajero INTEGER,
    ingrediente INTEGER, producto INTEGER, con_receta INTEGER, proveedor INTEGER
);
GRANT SELECT ON _casos TO PUBLIC;

-- Archivos y asociaciones de cada caso, preparados por el propietario.
CREATE TEMP TABLE _xml (caso TEXT PRIMARY KEY, b64 TEXT, asoc JSONB);
GRANT SELECT ON _xml TO PUBLIC;

-- Factura de ensayo en ISO-8859-1: queso (en gramos), producto de reventa y un flete.
-- Neto 12.940 + 32.464 + 5.000 = 50.404; IVA 9.577; total 59.981.
CREATE FUNCTION pg_temp.dte(
    p_folio BIGINT, p_tipo TEXT DEFAULT '33', p_total TEXT DEFAULT '59981',
    p_namespace BOOLEAN DEFAULT FALSE, p_detalle TEXT DEFAULT NULL,
    p_neto TEXT DEFAULT '50404', p_iva TEXT DEFAULT '9577', p_relleno TEXT DEFAULT ''
)
RETURNS TEXT
LANGUAGE sql
AS $f$
    SELECT '<?xml version="1.0" encoding="ISO-8859-1"?>'
        || '<SetDTE' || CASE WHEN p_namespace THEN ' xmlns="http://www.sii.cl/SiiDte"' ELSE '' END || '>'
        || '<DTE version="1.0"><Documento ID="E' || p_folio || '">'
        || '<Encabezado><IdDoc><TipoDTE>' || p_tipo || '</TipoDTE><Folio>' || p_folio || '</Folio>'
        || '<FchEmis>2026-10-15</FchEmis></IdDoc>'
        || '<Emisor><RUTEmisor>76.086.428-5</RUTEmisor><RznSoc>Proveedor de ensayo</RznSoc></Emisor>'
        || '<Receptor><RUTRecep>11111111-1</RUTRecep></Receptor>'
        || '<Totales><MntNeto>' || p_neto || '</MntNeto><TasaIVA>19</TasaIVA><IVA>' || p_iva || '</IVA>'
        || '<MntTotal>' || p_total || '</MntTotal></Totales></Encabezado>'
        || COALESCE(p_detalle,
               '<Detalle><NroLinDet>1</NroLinDet><CdgItem><TpoCodigo/><VlrCodigo>Q1</VlrCodigo></CdgItem>'
            || '<NmbItem>Queso Piñón &amp; Cía</NmbItem><QtyItem>20</QtyItem><PrcItem>647</PrcItem>'
            || '<MontoItem>12940</MontoItem></Detalle>'
            || '<Detalle><NroLinDet>2</NroLinDet><CdgItem><TpoCodigo/><VlrCodigo>P2</VlrCodigo></CdgItem>'
            || '<NmbItem>Pingüino 2p 80g</NmbItem><QtyItem>16</QtyItem><PrcItem>2029</PrcItem>'
            || '<MontoItem>32464</MontoItem></Detalle>'
            || '<Detalle><NroLinDet>3</NroLinDet><NmbItem>Flete</NmbItem><QtyItem>1</QtyItem>'
            || '<PrcItem>5000</PrcItem><MontoItem>5000</MontoItem></Detalle>')
        || '<Referencia><NroLinRef>1</NroLinRef><TpoDocRef>801</TpoDocRef><FolioRef>188117</FolioRef></Referencia>'
        || '</Documento></DTE></SetDTE>' || p_relleno
$f$;

CREATE FUNCTION pg_temp.b64(p_xml TEXT) RETURNS TEXT LANGUAGE sql
AS $f$ SELECT encode(convert_to(p_xml, 'LATIN1'), 'base64') $f$;

DO $$
DECLARE
    g INTEGER; s1 INTEGER; s2 INTEGER; adm INTEGER; bod INTEGER; caj INTEGER;
    ing INTEGER; prod INTEGER; rec INTEGER; prov INTEGER;
    completa JSONB;
BEGIN
    SELECT id INTO g FROM public.unidades_medida WHERE abreviatura = 'g';
    INSERT INTO public.sucursales (nombre) VALUES ('Ensayo T08 S1') RETURNING id INTO s1;
    INSERT INTO public.sucursales (nombre) VALUES ('Ensayo T08 S2') RETURNING id INTO s2;
    INSERT INTO public.usuarios (nombre, identificador_acceso, password_hash, rol)
        VALUES ('Admin ensayo T08', 'ensayo-t08-admin', 'x', 'admin') RETURNING id INTO adm;
    INSERT INTO public.usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('Bodeguero ensayo T08', 'ensayo-t08-bodeguero', 'x', 'bodeguero', s2) RETURNING id INTO bod;
    INSERT INTO public.usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('Cajero ensayo T08', 'ensayo-t08-cajero', 'x', 'cajero', s1) RETURNING id INTO caj;
    INSERT INTO public.ingredientes (nombre, unidad_id) VALUES ('Ensayo T08 Queso', g) RETURNING id INTO ing;
    INSERT INTO public.productos (nombre, precio_venta) VALUES ('Ensayo T08 Pingüino', 1000) RETURNING id INTO prod;
    INSERT INTO public.productos (nombre, precio_venta) VALUES ('Ensayo T08 Sándwich', 3000) RETURNING id INTO rec;
    INSERT INTO public.recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id) VALUES (rec, ing, 30, g);
    INSERT INTO public.proveedores (nombre, rut) VALUES ('Proveedor ensayo T08', '76086428-5')
        ON CONFLICT (rut) DO NOTHING;
    SELECT id INTO prov FROM public.proveedores WHERE rut = '76086428-5';
    INSERT INTO _casos VALUES (s1, s2, adm, bod, caj, ing, prod, rec, prov);

    completa := jsonb_build_array(
        jsonb_build_object('numero_linea', 1, 'ingrediente_id', ing, 'unidades_por_presentacion', 500.5),
        jsonb_build_object('numero_linea', 2, 'producto_id', prod, 'unidades_por_presentacion', 6),
        jsonb_build_object('numero_linea', 3, 'no_corresponde_inventario', TRUE));

    INSERT INTO _xml VALUES
        ('ok',                pg_temp.b64(pg_temp.dte(990000001)), completa),
        ('otro_archivo',      pg_temp.b64(pg_temp.dte(990000001, p_relleno => '   ')), completa),
        ('sin_asociar',       pg_temp.b64(pg_temp.dte(990000011)), completa - 2),
        ('sin_equivalencia',  pg_temp.b64(pg_temp.dte(990000012)),
            jsonb_set(completa, '{1}', jsonb_build_object('numero_linea', 2, 'producto_id', prod))),
        ('con_receta',        pg_temp.b64(pg_temp.dte(990000013)),
            jsonb_set(completa, '{1}', jsonb_build_object('numero_linea', 2, 'producto_id', rec,
                                                          'unidades_por_presentacion', 1))),
        ('tipo34',            pg_temp.b64(pg_temp.dte(990000014, '34')), completa),
        ('totales',           pg_temp.b64(pg_temp.dte(990000015, p_total => '60000')), completa),
        ('danado',            pg_temp.b64(left(pg_temp.dte(990000016), 300)), completa),
        ('linea_inexistente', pg_temp.b64(pg_temp.dte(990000017)),
            completa || jsonb_build_array(jsonb_build_object('numero_linea', 9, 'no_corresponde_inventario', TRUE))),
        ('servicios_ns',      pg_temp.b64(pg_temp.dte(990000018, p_namespace => TRUE,
            p_detalle => '<Detalle><NroLinDet>1</NroLinDet><NmbItem>Servicio</NmbItem><QtyItem>1</QtyItem>'
                      || '<PrcItem>50404</PrcItem><MontoItem>50404</MontoItem></Detalle>')),
            jsonb_build_array(jsonb_build_object('numero_linea', 1, 'no_corresponde_inventario', TRUE))),
        ('cuatro_decimales',  pg_temp.b64(pg_temp.dte(990000019)),
            jsonb_set(completa, '{0}', jsonb_build_object('numero_linea', 1, 'ingrediente_id', ing,
                                                          'unidades_por_presentacion', 500.1234))),
        ('bodeguero_propia',  pg_temp.b64(pg_temp.dte(990000021)), completa),
        ('bodeguero_ajena',   pg_temp.b64(pg_temp.dte(990000022)), completa),
        ('cajero',            pg_temp.b64(pg_temp.dte(990000023)), completa);
END $$;

-- Fase A: admin -----------------------------------------------------------------------

SELECT set_config('request.jwt.claims', json_build_object('role', 'nury_admin', 'user_id', admin)::text, TRUE)
  FROM _casos;
SET LOCAL ROLE nury_admin;

DO $$
DECLARE
    c    _casos%ROWTYPE;
    x    RECORD;
    r    RECORD;
    resp JSONB;
BEGIN
    SELECT * INTO c FROM _casos;

    SELECT * INTO x FROM _xml WHERE caso = 'ok';
    resp := public.fn_ingresar_factura_xml(c.s1, x.b64, 'ok.xml', x.asoc);
    INSERT INTO _resultados VALUES ('A01 ingreso completo: 2 líneas a stock y 1 no inventariable',
        CASE WHEN resp->>'lineas_inventario' = '2' AND resp->>'lineas_no_inventario' = '1'
             THEN 'OK' ELSE 'FALLA: ' || resp::TEXT END);

    SELECT * INTO x FROM _xml WHERE caso = 'servicios_ns';
    resp := public.fn_ingresar_factura_xml(c.s1, x.b64, 'servicios.xml', x.asoc);
    INSERT INTO _resultados VALUES ('A02 factura solo de servicios y con namespace del SII',
        CASE WHEN resp->>'lineas_inventario' = '0' AND resp->>'lineas_no_inventario' = '1'
             THEN 'OK' ELSE 'FALLA: ' || resp::TEXT END);

    -- Casos que deben rechazarse sin dejar nada guardado.
    FOR r IN
        SELECT * FROM (VALUES
            ('A03 la misma factura no se ingresa dos veces',              'ok',                's1', '23505'),
            ('A04 tampoco con otro archivo ni en otra sucursal',          'otro_archivo',      's2', '23505'),
            ('A05 bloquea si falta asociar una línea',                    'sin_asociar',       's1', '22023'),
            ('A06 bloquea si falta la equivalencia',                      'sin_equivalencia',  's1', '22023'),
            ('A07 rechaza un producto con receta',                        'con_receta',        's1', '22023'),
            ('A08 rechaza un documento que no es tipo 33',                'tipo34',            's1', '22023'),
            ('A09 rechaza totales que no cuadran',                        'totales',           's1', '22023'),
            ('A10 rechaza un XML dañado',                                 'danado',            's1', '22023'),
            ('A11 rechaza asociaciones de líneas que no existen',         'linea_inexistente', 's1', '22023'),
            ('A12 rechaza una equivalencia con más de 3 decimales',       'cuatro_decimales',  's1', '22023')
        ) AS t(prueba, caso, sucursal, esperado)
    LOOP
        SELECT * INTO x FROM _xml WHERE caso = r.caso;
        BEGIN
            PERFORM public.fn_ingresar_factura_xml(
                CASE r.sucursal WHEN 's1' THEN c.s1 ELSE c.s2 END, x.b64, r.caso || '.xml', x.asoc);
            INSERT INTO _resultados VALUES (r.prueba, 'FALLA: se aceptó');
        EXCEPTION WHEN OTHERS THEN
            -- El mensaje del servidor acompaña al resultado: así se ve que el rechazo
            -- fue por el motivo esperado y no por otro error con el mismo código.
            INSERT INTO _resultados VALUES (r.prueba || ' → «' || SQLERRM || '»',
                CASE WHEN SQLSTATE = r.esperado THEN 'OK'
                     ELSE 'FALLA: ' || SQLSTATE || ' ' || SQLERRM END);
        END;
    END LOOP;
END $$;

RESET ROLE;

-- Fase B: bodeguero de S2 ------------------------------------------------------------------

SELECT set_config('request.jwt.claims', json_build_object('role', 'nury_bodeguero', 'user_id', bodeguero)::text, TRUE)
  FROM _casos;
SET LOCAL ROLE nury_bodeguero;

DO $$
DECLARE
    c    _casos%ROWTYPE;
    x    RECORD;
    resp JSONB;
BEGIN
    SELECT * INTO c FROM _casos;

    SELECT * INTO x FROM _xml WHERE caso = 'bodeguero_ajena';
    BEGIN
        PERFORM public.fn_ingresar_factura_xml(c.s1, x.b64, 'ajena.xml', x.asoc);
        INSERT INTO _resultados VALUES ('B01 bodeguero no ingresa en otra sucursal', 'FALLA: se aceptó');
    EXCEPTION WHEN insufficient_privilege THEN
        INSERT INTO _resultados VALUES ('B01 bodeguero no ingresa en otra sucursal', 'OK');
    END;

    SELECT * INTO x FROM _xml WHERE caso = 'bodeguero_propia';
    resp := public.fn_ingresar_factura_xml(c.s2, x.b64, 'propia.xml', x.asoc);
    INSERT INTO _resultados VALUES ('B02 bodeguero ingresa en su sucursal',
        CASE WHEN resp->>'lineas_inventario' = '2' THEN 'OK' ELSE 'FALLA: ' || resp::TEXT END);
END $$;

RESET ROLE;

-- Fase C: cajero ------------------------------------------------------------------------------

SELECT set_config('request.jwt.claims', json_build_object('role', 'nury_cajero', 'sub', cajero)::text, TRUE)
  FROM _casos;
SET LOCAL ROLE nury_cajero;

DO $$
DECLARE
    c _casos%ROWTYPE;
    x RECORD;
BEGIN
    SELECT * INTO c FROM _casos;
    SELECT * INTO x FROM _xml WHERE caso = 'cajero';
    BEGIN
        PERFORM public.fn_ingresar_factura_xml(c.s1, x.b64, 'cajero.xml', x.asoc);
        INSERT INTO _resultados VALUES ('C01 cajero no ingresa facturas', 'FALLA: se aceptó');
    EXCEPTION WHEN insufficient_privilege THEN
        INSERT INTO _resultados VALUES ('C01 cajero no ingresa facturas', 'OK');
    END;
END $$;

RESET ROLE;

-- Fase V: el propietario revisa lo que quedó guardado ------------------------------------------

DO $$
DECLARE
    c          _casos%ROWTYPE;
    fc         public.facturas_compra%ROWTYPE;
    pend       public.facturas_xml_pendientes%ROWTYPE;
    v_num      NUMERIC;
    v_cuenta   INTEGER;
    v_texto    TEXT;
BEGIN
    SELECT * INTO c FROM _casos;

    SELECT * INTO fc FROM public.facturas_compra WHERE folio = 990000001;
    INSERT INTO _resultados VALUES ('V01 facturas_compra con identidad, origen XML, sucursal y proveedor',
        CASE WHEN fc.origen = 'xml' AND fc.rut_emisor_normalizado = '76086428-5' AND fc.tipo_documento = 33
                  AND fc.sucursal_id = c.s1 AND fc.proveedor_id = c.proveedor AND fc.monto_total = 59981
                  AND fc.numero_factura = '990000001' AND fc.estado = 'confirmada'
             THEN 'OK' ELSE 'FALLA: ' || row_to_json(fc)::TEXT END);

    SELECT stock_actual INTO v_num FROM public.stock_sucursal WHERE ingrediente_id = c.ingrediente AND sucursal_id = c.s1;
    INSERT INTO _resultados VALUES ('V02 stock del queso en S1 = 20 × 500,5 g = 10.010 (una sola vez)',
        CASE WHEN v_num = 10010 THEN 'OK' ELSE 'FALLA: ' || COALESCE(v_num::TEXT, 'sin fila') END);

    SELECT stock_actual INTO v_num FROM public.stock_producto_sucursal WHERE producto_id = c.producto AND sucursal_id = c.s1;
    INSERT INTO _resultados VALUES ('V03 stock del producto en S1 = 16 × 6 = 96',
        CASE WHEN v_num = 96 THEN 'OK' ELSE 'FALLA: ' || COALESCE(v_num::TEXT, 'sin fila') END);

    SELECT count(*), sum(subtotal_neto) INTO v_cuenta, v_num FROM public.detalle_factura_compra WHERE factura_id = fc.id;
    INSERT INTO _resultados VALUES ('V04 detalle: 2 líneas que suman exactamente 45.404',
        CASE WHEN v_cuenta = 2 AND v_num = 45404 THEN 'OK' ELSE 'FALLA: ' || v_cuenta || ' líneas, ' || v_num END);

    SELECT count(*) INTO v_cuenta FROM public.movimientos_stock
     WHERE referencia_tipo = 'factura_compra' AND referencia_id = fc.id AND tipo_movimiento = 'compra';
    INSERT INTO _resultados VALUES ('V05 kardex: 2 movimientos de compra',
        CASE WHEN v_cuenta = 2 THEN 'OK' ELSE 'FALLA: ' || v_cuenta END);

    SELECT * INTO pend FROM public.facturas_xml_pendientes WHERE factura_id = fc.id;
    INSERT INTO _resultados VALUES ('V06 respaldo: XML original, hash, quién y cuándo',
        CASE WHEN pend.estado = 'confirmada' AND pend.cargado_por = c.admin AND pend.confirmado_por = c.admin
                  AND pend.confirmado_en IS NOT NULL AND pend.rut_emisor = '76.086.428-5'
                  AND pend.orden_compra_referencia = '188117'
                  AND pend.xml_sha256 = encode(sha256(decode((SELECT b64 FROM _xml WHERE caso = 'ok'), 'base64')), 'hex')
             THEN 'OK' ELSE 'FALLA: ' || row_to_json(pend)::TEXT END);

    SELECT descripcion INTO v_texto FROM public.facturas_xml_pendientes_lineas
     WHERE factura_xml_id = pend.id AND numero_linea = 1;
    INSERT INTO _resultados VALUES ('V07 la descripción conserva ñ, tildes y &',
        CASE WHEN v_texto = 'Queso Piñón & Cía' THEN 'OK' ELSE 'FALLA: ' || COALESCE(v_texto, 'sin línea') END);

    SELECT count(*) INTO v_cuenta FROM public.facturas_xml_pendientes_lineas
     WHERE factura_xml_id = pend.id
       AND ((numero_linea = 1 AND cantidad_ingreso = 10010)
         OR (numero_linea = 2 AND cantidad_ingreso = 96)
         OR (numero_linea = 3 AND no_corresponde_inventario AND cantidad_ingreso IS NULL));
    INSERT INTO _resultados VALUES ('V08 las 3 líneas originales quedan con su asociación',
        CASE WHEN v_cuenta = 3 THEN 'OK' ELSE 'FALLA: ' || v_cuenta END);

    SELECT costo_unitario_promedio INTO v_num FROM public.ingredientes WHERE id = c.ingrediente;
    INSERT INTO _resultados VALUES ('V09 costo del queso = 12.940 ÷ 10.010 g (1,29)',
        CASE WHEN v_num = 1.29 THEN 'OK' ELSE 'FALLA: ' || v_num END);

    SELECT precio_compra INTO v_num FROM public.productos WHERE id = c.producto;
    INSERT INTO _resultados VALUES ('V10 costo del producto = 32.464 ÷ 96 (338,17)',
        CASE WHEN v_num = 338.17 THEN 'OK' ELSE 'FALLA: ' || v_num END);

    SELECT count(*) INTO v_cuenta FROM public.facturas_compra
     WHERE folio IN (990000011, 990000012, 990000013, 990000014, 990000015, 990000016, 990000017, 990000019);
    SELECT v_cuenta + count(*) INTO v_cuenta FROM public.facturas_xml_pendientes
     WHERE folio IN (990000011, 990000012, 990000013, 990000014, 990000015, 990000016, 990000017, 990000019);
    INSERT INTO _resultados VALUES ('V11 los ingresos rechazados no dejaron nada guardado',
        CASE WHEN v_cuenta = 0 THEN 'OK' ELSE 'FALLA: quedaron ' || v_cuenta || ' filas' END);

    SELECT count(*) INTO v_cuenta FROM public.facturas_compra WHERE folio = 990000001;
    INSERT INTO _resultados VALUES ('V12 solo existe una factura con el folio repetido',
        CASE WHEN v_cuenta = 1 THEN 'OK' ELSE 'FALLA: ' || v_cuenta END);

    SELECT count(*) INTO v_cuenta FROM public.detalle_factura_compra d
      JOIN public.facturas_compra f ON f.id = d.factura_id WHERE f.folio = 990000018;
    INSERT INTO _resultados VALUES ('V13 la factura de servicios no suma stock',
        CASE WHEN v_cuenta = 0 AND EXISTS (SELECT 1 FROM public.facturas_compra WHERE folio = 990000018)
             THEN 'OK' ELSE 'FALLA: ' || v_cuenta || ' líneas de detalle' END);

    SELECT p.* INTO pend FROM public.facturas_xml_pendientes p WHERE p.folio = 990000021;
    INSERT INTO _resultados VALUES ('V14 el ingreso del bodeguero queda en su sucursal y a su nombre',
        CASE WHEN pend.sucursal_id = c.s2 AND pend.cargado_por = c.bodeguero THEN 'OK'
             ELSE 'FALLA: ' || COALESCE(row_to_json(pend)::TEXT, 'sin fila') END);

    INSERT INTO _resultados VALUES ('V15 normalización de RUT',
        CASE WHEN public.fn_normalizar_rut('76.086.428-5') = '76086428-5'
                  AND public.fn_normalizar_rut('6-k') = '6-K'
                  AND public.fn_normalizar_rut('76086428-4') IS NULL
             THEN 'OK' ELSE 'FALLA' END);
END $$;

-- pgAdmin solo muestra el resultado de la última instrucción: por eso cada prueba se
-- informa como aviso (pestaña «Messages») y el ensayo falla con error si alguna no da OK.
DO $$
DECLARE
    r       RECORD;
    fallas  INTEGER := 0;
BEGIN
    FOR r IN SELECT prueba, resultado FROM _resultados ORDER BY prueba LOOP
        RAISE NOTICE '% | %', r.resultado, r.prueba;
        IF r.resultado <> 'OK' THEN
            fallas := fallas + 1;
        END IF;
    END LOOP;

    IF fallas > 0 THEN
        RAISE EXCEPTION 'El ensayo tiene % prueba(s) con FALLA: revisa los avisos de arriba', fallas;
    END IF;
    RAISE NOTICE 'ENSAYO COMPLETO: todas las pruebas dieron OK';
END $$;

ROLLBACK;