-- Requiere 0003_apertura_control_turno.sql y 20261012_permisos_cajero.sql.
-- Recupera un turno existente. No abre, cierra ni modifica turnos o ventas.
BEGIN;

DO $$
BEGIN
    IF to_regprocedure('public.fn_usuario_actual_id()') IS NULL THEN
        RAISE EXCEPTION 'Aplica primero 20261012_permisos_cajero.sql';
    END IF;
END;
$$;

CREATE OR REPLACE FUNCTION public.fn_recuperar_turno()
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $$
DECLARE
    actor_id INTEGER := public.fn_usuario_actual_id();
    sucursal INTEGER;
    turno public.turnos%ROWTYPE;
    ventas JSONB;
BEGIN
    IF actor_id IS NULL THEN
        RAISE EXCEPTION 'La sesión no identifica a un usuario autorizado' USING ERRCODE = '42501';
    END IF;
    SELECT sucursal_id INTO sucursal FROM public.usuarios WHERE id = actor_id;
    SELECT * INTO turno FROM public.turnos
     WHERE usuario_id = actor_id AND sucursal_id = sucursal AND hora_fin IS NULL
     ORDER BY hora_inicio DESC, id DESC LIMIT 1;
    IF NOT FOUND THEN
        RETURN jsonb_build_object('turno', NULL, 'ventas', '[]'::jsonb);
    END IF;

    SELECT COALESCE(jsonb_agg(to_jsonb(v) || jsonb_build_object('detalle_venta', (
        SELECT COALESCE(jsonb_agg(to_jsonb(d) || jsonb_build_object('productos', to_jsonb(p)) ORDER BY d.id), '[]'::jsonb)
          FROM public.detalle_venta d
          LEFT JOIN public.productos p ON p.id = d.producto_id
         WHERE d.venta_id = v.id
    )) ORDER BY v.fecha_venta DESC, v.id DESC), '[]'::jsonb)
      INTO ventas FROM public.ventas v
     WHERE v.turno_id = turno.id AND v.cajero_id = actor_id AND v.sucursal_id = sucursal;

    RETURN jsonb_build_object('turno', to_jsonb(turno), 'ventas', ventas);
END;
$$;

REVOKE ALL ON FUNCTION public.fn_recuperar_turno() FROM PUBLIC, web_anon, nury_bodeguero;
GRANT EXECUTE ON FUNCTION public.fn_recuperar_turno() TO nury_admin, nury_cajero;
NOTIFY pgrst, 'reload schema';
COMMIT;
