-- H3.2 T01 - Relación entre ventas y movimientos de inventario.
--
-- Cada venta ya deja sus movimientos en movimientos_stock (fn_aplicar_venta, 0004; la
-- anulación los repone, 0007) con la venta (referencia_tipo/referencia_id), el artículo
-- (ingrediente_id o producto_id), la cantidad, la fecha (creado_en) y la sucursal. Lo que
-- faltaba era verlo junto y con el catálogo de H3.3: la unidad no es columna del kardex
-- (se deduce del artículo, y desde H3.3 queda fija) y el nombre del artículo había que
-- cruzarlo a mano.
--
-- v_movimientos_articulos: una fila por movimiento con tipo, venta, artículo (de
-- v_articulos), cantidad, unidad, stock resultante, fecha y sucursal. Solo lectura, sin
-- cambios en tablas ni en cómo se registran las ventas.
--
-- Un producto que vendió como reventa y después recibió receta sale de v_articulos (ya no
-- se guarda en bodega), pero sus movimientos antiguos siguen visibles: se completa el
-- nombre desde productos y la unidad es "un".
--
-- Permisos: SELECT para admin y bodeguero, igual que v_articulos. La vista corre con los
-- permisos de su dueño (como v_articulos), así el bodeguero no necesita leer las tablas.
--
-- ANTES DE APLICAR EN PRODUCCIÓN: correr 20261026_movimientos_articulos.ENSAYO.sql (termina
-- en ROLLBACK) y la prueba database/tests/movimientos_articulos.sql en una base de pruebas.

BEGIN;

CREATE OR REPLACE VIEW public.v_movimientos_articulos AS
SELECT m.id                                            AS movimiento_id,
       m.tipo_movimiento,
       CASE WHEN m.referencia_tipo = 'venta' THEN m.referencia_id END AS venta_id,
       m.referencia_tipo,
       m.referencia_id,
       CASE WHEN m.ingrediente_id IS NOT NULL THEN 'materia_prima' ELSE 'producto' END::VARCHAR(20)
                                                       AS tipo_articulo,
       COALESCE(m.ingrediente_id, m.producto_id)       AS articulo_id,
       COALESCE(a.nombre, p.nombre)                    AS articulo,
       COALESCE(a.unidad, 'un')::VARCHAR(10)           AS unidad,
       m.cantidad,
       m.stock_resultante,
       m.sucursal_id,
       s.nombre                                        AS sucursal,
       m.creado_en                                     AS fecha,
       m.nota
  FROM public.movimientos_stock m
  LEFT JOIN public.v_articulos a
         ON (a.tipo = 'materia_prima' AND a.articulo_id = m.ingrediente_id)
         OR (a.tipo = 'producto'      AND a.articulo_id = m.producto_id)
  LEFT JOIN public.productos p ON p.id = m.producto_id
  JOIN public.sucursales s ON s.id = m.sucursal_id;

COMMENT ON VIEW public.v_movimientos_articulos IS
    'Kardex con el catálogo de H3.3 (H3.2 T01): venta, artículo, cantidad, unidad, fecha y sucursal de cada movimiento.';
COMMENT ON COLUMN public.v_movimientos_articulos.venta_id IS 'Venta que originó el movimiento (venta o anulacion_venta); NULL en compras y ajustes';
COMMENT ON COLUMN public.v_movimientos_articulos.unidad IS 'Unidad del artículo (fija desde H3.3); "un" en productos';

REVOKE ALL ON public.v_movimientos_articulos FROM PUBLIC;
GRANT SELECT ON public.v_movimientos_articulos TO nury_admin, nury_bodeguero;

COMMIT;

NOTIFY pgrst, 'reload schema';
