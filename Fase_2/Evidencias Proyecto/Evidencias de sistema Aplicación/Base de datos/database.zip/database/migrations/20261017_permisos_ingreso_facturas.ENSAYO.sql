-- ENSAYO de 20261017_permisos_ingreso_facturas.sql.
-- Aplica el mismo cambio, prueba las reglas con usuarios de ejemplo de cada rol
-- (cambiando de rol y de JWT como lo hace PostgREST) y termina en ROLLBACK:
-- no deja nada aplicado. La consulta final debe mostrar «OK» en todas las filas.
--
-- Corre con el propietario de las tablas. Si pgAdmin responde «permission denied
-- to set role», ese usuario no puede cambiar a nury_admin / nury_bodeguero /
-- nury_cajero: avísame con el mensaje y lo ajustamos.

BEGIN;

-- Cambio a ensayar (igual al script real) -------------------------------------

CREATE OR REPLACE FUNCTION public.fn_actor_ingreso()
RETURNS TABLE (usuario_id INTEGER, rol TEXT, sucursal_id INTEGER)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
    WITH sesion AS (
        SELECT COALESCE(NULLIF(current_setting('request.jwt.claims', TRUE), ''), '{}')::jsonb AS claims
    ), identidad AS (
        SELECT claims->>'role' AS rol_jwt,
               COALESCE(claims->>'user_id', claims->>'usuario_id', claims->>'sub', claims->>'id') AS id
          FROM sesion
    )
    SELECT u.id, u.rol::TEXT, u.sucursal_id
      FROM public.usuarios u, identidad i
     WHERE u.id = CASE WHEN i.id ~ '^[0-9]{1,10}$' THEN i.id::bigint ELSE NULL END
       AND u.activo
       AND CASE WHEN u.rol IN ('admin', 'administrador') THEN 'nury_admin'
                WHEN u.rol = 'bodeguero' THEN 'nury_bodeguero' END = i.rol_jwt;
$$;

REVOKE ALL ON FUNCTION public.fn_actor_ingreso() FROM PUBLIC, web_anon, nury_cajero;
GRANT EXECUTE ON FUNCTION public.fn_actor_ingreso() TO nury_admin, nury_bodeguero;

CREATE OR REPLACE FUNCTION public.fn_validar_sucursal_ingreso(p_sucursal_id INTEGER)
RETURNS INTEGER
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    v_actor  RECORD;
BEGIN
    SELECT * INTO v_actor FROM public.fn_actor_ingreso();
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Tu usuario no está autorizado para ingresar facturas'
            USING ERRCODE = '42501';
    END IF;

    IF p_sucursal_id IS NULL THEN
        RAISE EXCEPTION 'Indica la sucursal que recibirá el stock'
            USING ERRCODE = '22023';
    END IF;

    IF NOT EXISTS (SELECT 1 FROM public.sucursales WHERE id = p_sucursal_id AND activo) THEN
        RAISE EXCEPTION 'La sucursal indicada no existe o está inactiva'
            USING ERRCODE = '23503';
    END IF;

    IF v_actor.rol NOT IN ('admin', 'administrador') THEN
        IF v_actor.sucursal_id IS NULL THEN
            RAISE EXCEPTION 'Tu usuario no tiene una sucursal asignada: no puede ingresar facturas'
                USING ERRCODE = '42501';
        END IF;
        IF v_actor.sucursal_id <> p_sucursal_id THEN
            RAISE EXCEPTION 'Solo puedes ingresar facturas en tu propia sucursal'
                USING ERRCODE = '42501';
        END IF;
    END IF;

    RETURN v_actor.usuario_id;
END;
$$;

REVOKE ALL ON FUNCTION public.fn_validar_sucursal_ingreso(integer) FROM PUBLIC, web_anon, nury_cajero;
GRANT EXECUTE ON FUNCTION public.fn_validar_sucursal_ingreso(integer) TO nury_admin, nury_bodeguero;

CREATE OR REPLACE FUNCTION public.fn_facturas_xml_permisos()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public, pg_temp
AS $$
DECLARE
    v_usuario INTEGER;
BEGIN
    v_usuario := public.fn_validar_sucursal_ingreso(NEW.sucursal_id);

    IF TG_OP = 'INSERT' THEN
        NEW.cargado_por := v_usuario;
    ELSE
        NEW.cargado_por := OLD.cargado_por;
    END IF;

    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_facturas_xml_permisos ON public.facturas_xml_pendientes;
CREATE TRIGGER trg_facturas_xml_permisos
BEFORE INSERT OR UPDATE ON public.facturas_xml_pendientes
FOR EACH ROW EXECUTE FUNCTION public.fn_facturas_xml_permisos();

ALTER TABLE public.facturas_xml_pendientes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.facturas_xml_pendientes_lineas ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS facturas_xml_admin ON public.facturas_xml_pendientes;
CREATE POLICY facturas_xml_admin ON public.facturas_xml_pendientes
    TO nury_admin USING (TRUE) WITH CHECK (TRUE);

DROP POLICY IF EXISTS facturas_xml_bodeguero ON public.facturas_xml_pendientes;
CREATE POLICY facturas_xml_bodeguero ON public.facturas_xml_pendientes
    TO nury_bodeguero
    USING (sucursal_id = (SELECT a.sucursal_id FROM public.fn_actor_ingreso() a))
    WITH CHECK (sucursal_id = (SELECT a.sucursal_id FROM public.fn_actor_ingreso() a));

DROP POLICY IF EXISTS facturas_xml_lineas_admin ON public.facturas_xml_pendientes_lineas;
CREATE POLICY facturas_xml_lineas_admin ON public.facturas_xml_pendientes_lineas
    TO nury_admin USING (TRUE) WITH CHECK (TRUE);

DROP POLICY IF EXISTS facturas_xml_lineas_bodeguero ON public.facturas_xml_pendientes_lineas;
CREATE POLICY facturas_xml_lineas_bodeguero ON public.facturas_xml_pendientes_lineas
    TO nury_bodeguero
    USING (EXISTS (SELECT 1 FROM public.facturas_xml_pendientes f WHERE f.id = factura_xml_id))
    WITH CHECK (EXISTS (SELECT 1 FROM public.facturas_xml_pendientes f WHERE f.id = factura_xml_id));

REVOKE ALL ON public.facturas_xml_pendientes, public.facturas_xml_pendientes_lineas
    FROM PUBLIC, web_anon, nury_cajero;
REVOKE ALL ON SEQUENCE public.facturas_xml_pendientes_id_seq, public.facturas_xml_pendientes_lineas_id_seq
    FROM PUBLIC, web_anon, nury_cajero;

GRANT USAGE ON SCHEMA public TO nury_admin, nury_bodeguero;
GRANT SELECT, INSERT, UPDATE ON public.facturas_xml_pendientes TO nury_admin, nury_bodeguero;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.facturas_xml_pendientes_lineas TO nury_admin, nury_bodeguero;
GRANT USAGE ON SEQUENCE public.facturas_xml_pendientes_id_seq,
                        public.facturas_xml_pendientes_lineas_id_seq TO nury_admin, nury_bodeguero;

-- Datos de ejemplo (se descartan con el ROLLBACK) -----------------------------------

CREATE TEMP TABLE _resultados (prueba TEXT, resultado TEXT);
GRANT ALL ON _resultados TO PUBLIC;

CREATE TEMP TABLE _casos (
    s1 INTEGER, s2 INTEGER, s_inactiva INTEGER,
    admin INTEGER, bodeguero_a INTEGER, bodeguero_b INTEGER, cajero INTEGER
);
GRANT SELECT ON _casos TO PUBLIC;

-- id de la factura del admin en S2, para probar que otro rol no puede apuntarle líneas.
CREATE TEMP TABLE _ids (factura_s2 INTEGER);
GRANT ALL ON _ids TO PUBLIC;

DO $$
DECLARE
    s1 INTEGER; s2 INTEGER; s_inactiva INTEGER;
    adm INTEGER; bod_a INTEGER; bod_b INTEGER; caj INTEGER;
BEGIN
    INSERT INTO public.sucursales (nombre) VALUES ('Ensayo permisos S1') RETURNING id INTO s1;
    INSERT INTO public.sucursales (nombre) VALUES ('Ensayo permisos S2') RETURNING id INTO s2;
    INSERT INTO public.sucursales (nombre, activo) VALUES ('Ensayo permisos inactiva', FALSE) RETURNING id INTO s_inactiva;
    INSERT INTO public.usuarios (nombre, identificador_acceso, password_hash, rol)
        VALUES ('Admin ensayo', 'ensayo-ingreso-admin', 'x', 'admin') RETURNING id INTO adm;
    INSERT INTO public.usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('Bodeguero A ensayo', 'ensayo-ingreso-bodeguero-a', 'x', 'bodeguero', s1) RETURNING id INTO bod_a;
    INSERT INTO public.usuarios (nombre, identificador_acceso, password_hash, rol)
        VALUES ('Bodeguero B ensayo (sin sucursal)', 'ensayo-ingreso-bodeguero-b', 'x', 'bodeguero') RETURNING id INTO bod_b;
    INSERT INTO public.usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('Cajero ensayo', 'ensayo-ingreso-cajero', 'x', 'cajero', s1) RETURNING id INTO caj;
    INSERT INTO _casos VALUES (s1, s2, s_inactiva, adm, bod_a, bod_b, caj);
END $$;

-- Fase A: admin ---------------------------------------------------------------------

SELECT set_config('request.jwt.claims',
                  json_build_object('role', 'nury_admin', 'user_id', admin)::text, TRUE)
  FROM _casos;
SET LOCAL ROLE nury_admin;

DO $$
DECLARE
    c _casos%ROWTYPE;
    f1 INTEGER; f2 INTEGER; quien INTEGER;
BEGIN
    SELECT * INTO c FROM _casos;

    -- El cliente intenta atribuir la carga a otro usuario: se ignora.
    INSERT INTO public.facturas_xml_pendientes
        (sucursal_id, cargado_por, tipo_documento, folio, rut_emisor, rut_emisor_normalizado,
         fecha_emision, monto_neto, monto_iva, monto_total, xml_original, xml_sha256)
    VALUES (c.s1, c.bodeguero_a, 33, 900000001, '82623500-4', '82623500-4', DATE '2026-10-15',
            1000, 190, 1190, 'x'::bytea, repeat('0', 64))
    RETURNING id, cargado_por INTO f1, quien;
    INSERT INTO _resultados VALUES ('A1 admin ingresa en S1 y cargado_por es el admin real',
        CASE WHEN quien = c.admin THEN 'OK' ELSE 'FALLA: cargado_por = ' || quien END);

    INSERT INTO public.facturas_xml_pendientes
        (sucursal_id, cargado_por, tipo_documento, folio, rut_emisor, rut_emisor_normalizado,
         fecha_emision, monto_neto, monto_iva, monto_total, xml_original, xml_sha256)
    VALUES (c.s2, c.admin, 33, 900000002, '82623500-4', '82623500-4', DATE '2026-10-15',
            1000, 190, 1190, 'x'::bytea, repeat('0', 64))
    RETURNING id INTO f2;
    INSERT INTO _ids VALUES (f2);
    INSERT INTO _resultados VALUES ('A2 admin ingresa en otra sucursal (S2)', 'OK');

    BEGIN
        INSERT INTO public.facturas_xml_pendientes
            (sucursal_id, cargado_por, tipo_documento, folio, rut_emisor, rut_emisor_normalizado,
             fecha_emision, monto_neto, monto_iva, monto_total, xml_original, xml_sha256)
        VALUES (c.s_inactiva, c.admin, 33, 900000003, '82623500-4', '82623500-4', DATE '2026-10-15',
                1000, 190, 1190, 'x'::bytea, repeat('0', 64));
        INSERT INTO _resultados VALUES ('A3 sucursal inactiva rechazada', 'FALLA: se aceptó');
    EXCEPTION WHEN foreign_key_violation THEN
        INSERT INTO _resultados VALUES ('A3 sucursal inactiva rechazada', 'OK');
    END;

    INSERT INTO public.facturas_xml_pendientes_lineas
        (factura_xml_id, numero_linea, descripcion, cantidad, precio_unitario, monto)
    VALUES (f2, 1, 'Línea de S2', 1, 100, 100);
    INSERT INTO _resultados VALUES ('A4 admin guarda una línea de la factura de S2', 'OK');
END $$;

RESET ROLE;

-- Fase B: bodeguero con sucursal (S1) -------------------------------------------------

SELECT set_config('request.jwt.claims',
                  json_build_object('role', 'nury_bodeguero', 'user_id', bodeguero_a)::text, TRUE)
  FROM _casos;
SET LOCAL ROLE nury_bodeguero;

DO $$
DECLARE
    c _casos%ROWTYPE;
    propia INTEGER; filas INTEGER; lineas INTEGER; ajena INTEGER;
BEGIN
    SELECT * INTO c FROM _casos;

    INSERT INTO public.facturas_xml_pendientes
        (sucursal_id, cargado_por, tipo_documento, folio, rut_emisor, rut_emisor_normalizado,
         fecha_emision, monto_neto, monto_iva, monto_total, xml_original, xml_sha256)
    VALUES (c.s1, c.admin, 33, 900000004, '82623500-4', '82623500-4', DATE '2026-10-15',
            1000, 190, 1190, 'x'::bytea, repeat('0', 64))
    RETURNING id INTO propia;
    INSERT INTO _resultados VALUES ('B1 bodeguero ingresa en su sucursal',
        CASE WHEN (SELECT cargado_por FROM public.facturas_xml_pendientes WHERE id = propia) = c.bodeguero_a
             THEN 'OK' ELSE 'FALLA: cargado_por no es el bodeguero' END);

    BEGIN
        INSERT INTO public.facturas_xml_pendientes
            (sucursal_id, cargado_por, tipo_documento, folio, rut_emisor, rut_emisor_normalizado,
             fecha_emision, monto_neto, monto_iva, monto_total, xml_original, xml_sha256)
        VALUES (c.s2, c.bodeguero_a, 33, 900000005, '82623500-4', '82623500-4', DATE '2026-10-15',
                1000, 190, 1190, 'x'::bytea, repeat('0', 64));
        INSERT INTO _resultados VALUES ('B2 bodeguero no ingresa en otra sucursal', 'FALLA: se aceptó');
    EXCEPTION WHEN insufficient_privilege THEN
        INSERT INTO _resultados VALUES ('B2 bodeguero no ingresa en otra sucursal', 'OK');
    END;

    SELECT count(*) INTO filas FROM public.facturas_xml_pendientes;
    INSERT INTO _resultados VALUES ('B3 bodeguero solo ve las facturas de su sucursal (2)',
        CASE WHEN filas = 2 THEN 'OK' ELSE 'FALLA: ve ' || filas END);

    BEGIN
        UPDATE public.facturas_xml_pendientes SET sucursal_id = c.s2 WHERE id = propia;
        INSERT INTO _resultados VALUES ('B4 bodeguero no cambia la factura a otra sucursal', 'FALLA: se aceptó');
    EXCEPTION WHEN insufficient_privilege THEN
        INSERT INTO _resultados VALUES ('B4 bodeguero no cambia la factura a otra sucursal', 'OK');
    END;

    INSERT INTO public.facturas_xml_pendientes_lineas
        (factura_xml_id, numero_linea, descripcion, cantidad, precio_unitario, monto)
    VALUES (propia, 1, 'Línea propia', 1, 100, 100);
    INSERT INTO _resultados VALUES ('B5 bodeguero guarda una línea de su factura', 'OK');

    SELECT id INTO ajena FROM public.facturas_xml_pendientes WHERE folio = 900000002;
    INSERT INTO _resultados VALUES ('B6 bodeguero no ve la factura de otra sucursal',
        CASE WHEN ajena IS NULL THEN 'OK' ELSE 'FALLA: la ve' END);

    -- El bodeguero no ve la factura de S2, pero un cliente malicioso podría adivinar su id.
    BEGIN
        INSERT INTO public.facturas_xml_pendientes_lineas
            (factura_xml_id, numero_linea, descripcion, cantidad, precio_unitario, monto)
        VALUES ((SELECT factura_s2 FROM _ids), 2, 'Línea en factura ajena', 1, 100, 100);
        INSERT INTO _resultados VALUES ('B7 bodeguero no agrega líneas a una factura ajena', 'FALLA: se aceptó');
    EXCEPTION WHEN insufficient_privilege THEN
        INSERT INTO _resultados VALUES ('B7 bodeguero no agrega líneas a una factura ajena', 'OK');
    END;

    SELECT count(*) INTO lineas FROM public.facturas_xml_pendientes_lineas;
    INSERT INTO _resultados VALUES ('B8 bodeguero solo ve líneas de su sucursal (1)',
        CASE WHEN lineas = 1 THEN 'OK' ELSE 'FALLA: ve ' || lineas END);

    BEGIN
        DELETE FROM public.facturas_xml_pendientes WHERE id = propia;
        INSERT INTO _resultados VALUES ('B9 bodeguero no elimina facturas', 'FALLA: se aceptó');
    EXCEPTION WHEN insufficient_privilege THEN
        INSERT INTO _resultados VALUES ('B9 bodeguero no elimina facturas', 'OK');
    END;
END $$;

RESET ROLE;

-- Fase C: bodeguero sin sucursal --------------------------------------------------------

SELECT set_config('request.jwt.claims',
                  json_build_object('role', 'nury_bodeguero', 'user_id', bodeguero_b)::text, TRUE)
  FROM _casos;
SET LOCAL ROLE nury_bodeguero;

DO $$
DECLARE
    c _casos%ROWTYPE;
    filas INTEGER;
BEGIN
    SELECT * INTO c FROM _casos;

    BEGIN
        INSERT INTO public.facturas_xml_pendientes
            (sucursal_id, cargado_por, tipo_documento, folio, rut_emisor, rut_emisor_normalizado,
             fecha_emision, monto_neto, monto_iva, monto_total, xml_original, xml_sha256)
        VALUES (c.s1, c.bodeguero_b, 33, 900000006, '82623500-4', '82623500-4', DATE '2026-10-15',
                1000, 190, 1190, 'x'::bytea, repeat('0', 64));
        INSERT INTO _resultados VALUES ('C1 bodeguero sin sucursal no ingresa', 'FALLA: se aceptó');
    EXCEPTION WHEN insufficient_privilege THEN
        INSERT INTO _resultados VALUES ('C1 bodeguero sin sucursal no ingresa', 'OK');
    END;

    SELECT count(*) INTO filas FROM public.facturas_xml_pendientes;
    INSERT INTO _resultados VALUES ('C2 bodeguero sin sucursal no ve ninguna factura',
        CASE WHEN filas = 0 THEN 'OK' ELSE 'FALLA: ve ' || filas END);
END $$;

RESET ROLE;

-- Fase D: cajero ---------------------------------------------------------------------------

SELECT set_config('request.jwt.claims',
                  json_build_object('role', 'nury_cajero', 'sub', cajero)::text, TRUE)
  FROM _casos;
SET LOCAL ROLE nury_cajero;

DO $$
DECLARE
    c _casos%ROWTYPE;
BEGIN
    SELECT * INTO c FROM _casos;

    BEGIN
        PERFORM count(*) FROM public.facturas_xml_pendientes;
        INSERT INTO _resultados VALUES ('D1 cajero no lee facturas pendientes', 'FALLA: pudo leer');
    EXCEPTION WHEN insufficient_privilege THEN
        INSERT INTO _resultados VALUES ('D1 cajero no lee facturas pendientes', 'OK');
    END;

    BEGIN
        INSERT INTO public.facturas_xml_pendientes
            (sucursal_id, cargado_por, tipo_documento, folio, rut_emisor, rut_emisor_normalizado,
             fecha_emision, monto_neto, monto_iva, monto_total, xml_original, xml_sha256)
        VALUES (c.s1, c.cajero, 33, 900000007, '82623500-4', '82623500-4', DATE '2026-10-15',
                1000, 190, 1190, 'x'::bytea, repeat('0', 64));
        INSERT INTO _resultados VALUES ('D2 cajero no ingresa facturas', 'FALLA: se aceptó');
    EXCEPTION WHEN insufficient_privilege THEN
        INSERT INTO _resultados VALUES ('D2 cajero no ingresa facturas', 'OK');
    END;
END $$;

RESET ROLE;

-- Fase E: JWT que no corresponde al usuario -----------------------------------------------------

-- Un JWT de rol admin con el id de un bodeguero no sirve: el rol debe coincidir con el real.
SELECT set_config('request.jwt.claims',
                  json_build_object('role', 'nury_admin', 'user_id', bodeguero_a)::text, TRUE)
  FROM _casos;
SET LOCAL ROLE nury_admin;

DO $$
DECLARE
    c _casos%ROWTYPE;
BEGIN
    SELECT * INTO c FROM _casos;

    BEGIN
        INSERT INTO public.facturas_xml_pendientes
            (sucursal_id, cargado_por, tipo_documento, folio, rut_emisor, rut_emisor_normalizado,
             fecha_emision, monto_neto, monto_iva, monto_total, xml_original, xml_sha256)
        VALUES (c.s2, c.bodeguero_a, 33, 900000008, '82623500-4', '82623500-4', DATE '2026-10-15',
                1000, 190, 1190, 'x'::bytea, repeat('0', 64));
        INSERT INTO _resultados VALUES ('E1 JWT con rol que no es el del usuario', 'FALLA: se aceptó');
    EXCEPTION WHEN insufficient_privilege THEN
        INSERT INTO _resultados VALUES ('E1 JWT con rol que no es el del usuario', 'OK');
    END;
END $$;

RESET ROLE;

-- pgAdmin solo muestra el resultado de la última instrucción: por eso cada prueba se
-- informa como aviso (pestaña «Messages») y el ensayo falla con error si alguna no da OK.
DO $$
DECLARE
    r       RECORD;
    fallas  INTEGER := 0;
BEGIN
    FOR r IN SELECT prueba, resultado FROM _resultados ORDER BY prueba LOOP
        RAISE NOTICE '% | %', r.resultado, r.prueba;
        IF r.resultado <> 'OK' THEN
            fallas := fallas + 1;
        END IF;
    END LOOP;

    IF fallas > 0 THEN
        RAISE EXCEPTION 'El ensayo tiene % prueba(s) con FALLA: revisa los avisos de arriba', fallas;
    END IF;
    RAISE NOTICE 'ENSAYO COMPLETO: todas las pruebas dieron OK';
END $$;

ROLLBACK;
