"""H3.2 T05 - Ventas simultáneas: sin cantidades perdidas ni bloqueos cruzados.

Abre varias conexiones a la vez y registra ventas con fn_registrar_venta_idempotente sobre los
mismos ingredientes en orden cruzado (X usa harina y luego queso; Y usa queso y luego harina).
Al final el stock debe ser exactamente el inicial menos todo lo vendido, sin ventas perdidas ni
"deadlock detected".

Uso (base de PRUEBAS con las migraciones hasta 20261027_venta_concurrente.sql):
    PGHOST=... PGPORT=... PGUSER=... PGDATABASE=... python3 database/tests/venta_concurrente.py
Crea sus propios datos con prefijo "VC " y los borra al terminar.
"""
import os
import threading
import uuid

import psycopg2

HILOS = int(os.environ.get('VC_HILOS', '8'))
VENTAS_POR_HILO = int(os.environ.get('VC_VENTAS', '40'))


def conectar():
    conexion = psycopg2.connect('')  # usa PGHOST, PGPORT, PGUSER, PGDATABASE...
    conexion.autocommit = True
    return conexion


def preparar(cur):
    cur.execute("""
        INSERT INTO sucursales (nombre) VALUES ('VC sucursal'), ('VC otra') RETURNING id""")
    suc, otra = [fila[0] for fila in cur.fetchall()]
    cur.execute("""INSERT INTO usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
                   VALUES ('VC cajero', 'vc-cajero', 'x', 'cajero', %s) RETURNING id""", (suc,))
    cajero = cur.fetchone()[0]
    cur.execute('INSERT INTO turnos (usuario_id, sucursal_id, hora_inicio) VALUES (%s, %s, now())', (cajero, suc))
    cur.execute("INSERT INTO unidades_medida (nombre, abreviatura) VALUES ('VC gramo', 'gvc') RETURNING id")
    un = cur.fetchone()[0]
    ids = {}
    for nombre in ('VC Harina', 'VC Queso'):
        cur.execute('INSERT INTO ingredientes (nombre, unidad_id) VALUES (%s, %s) RETURNING id', (nombre, un))
        ids[nombre] = cur.fetchone()[0]
    for nombre in ('VC X', 'VC Y', 'VC Bebida'):
        cur.execute('INSERT INTO productos (nombre, precio_venta) VALUES (%s, 1000) RETURNING id', (nombre,))
        ids[nombre] = cur.fetchone()[0]
    # Recetas en orden cruzado: X = harina, queso; Y = queso, harina.
    for prod, ing in (('VC X', 'VC Harina'), ('VC X', 'VC Queso'), ('VC Y', 'VC Queso'), ('VC Y', 'VC Harina')):
        cur.execute('INSERT INTO recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id) VALUES (%s, %s, 1, %s)',
                    (ids[prod], ids[ing], un))
    for ing in ('VC Harina', 'VC Queso'):
        cur.execute('INSERT INTO stock_sucursal (ingrediente_id, sucursal_id, stock_actual) VALUES (%s, %s, 10000), (%s, %s, 10000)',
                    (ids[ing], suc, ids[ing], otra))
    cur.execute('INSERT INTO stock_producto_sucursal (producto_id, sucursal_id, stock_actual) VALUES (%s, %s, 10000), (%s, %s, 10000)',
                (ids['VC Bebida'], suc, ids['VC Bebida'], otra))
    return suc, otra, cajero, ids


def vender(suc, cajero, n_hilo, errores, ventas):
    conexion = conectar()
    cur = conexion.cursor()
    for i in range(VENTAS_POR_HILO):
        orden = ['VC X', 'VC Y'] if (n_hilo + i) % 2 == 0 else ['VC Y', 'VC X']
        items = '[' + ','.join('{"producto":"%s","cantidad":1}' % p for p in orden + ['VC Bebida']) + ']'
        try:
            cur.execute('SELECT fn_registrar_venta_idempotente(%s, %s, %s, %s, %s::jsonb)',
                        (str(uuid.uuid4()), suc, cajero, 'efectivo', items))
            ventas.append(cur.fetchone()[0])
        except psycopg2.Error as error:
            errores.append(f'{error.pgcode}: {error.pgerror.strip().splitlines()[0]}')
    conexion.close()


def limpiar(cur, ids):
    cur.execute("SELECT id FROM ventas WHERE sucursal_id IN (SELECT id FROM sucursales WHERE nombre LIKE 'VC %')")
    ventas = [fila[0] for fila in cur.fetchall()]
    if ventas:
        cur.execute("DELETE FROM movimientos_stock WHERE referencia_tipo = 'venta' AND referencia_id = ANY(%s)", (ventas,))
        cur.execute('DELETE FROM ventas_idempotencia WHERE venta_id = ANY(%s)', (ventas,))
        cur.execute('DELETE FROM ventas WHERE id = ANY(%s)', (ventas,))
    cur.execute("DELETE FROM stock_sucursal WHERE ingrediente_id IN (SELECT id FROM ingredientes WHERE nombre LIKE 'VC %')")
    cur.execute("DELETE FROM stock_producto_sucursal WHERE producto_id IN (SELECT id FROM productos WHERE nombre LIKE 'VC %')")
    cur.execute("DELETE FROM recetas WHERE producto_id IN (SELECT id FROM productos WHERE nombre LIKE 'VC %')")
    cur.execute("""DELETE FROM recetas_version_detalle WHERE version_id IN
                   (SELECT id FROM recetas_version WHERE producto_id IN (SELECT id FROM productos WHERE nombre LIKE 'VC %'))""")
    cur.execute("DELETE FROM recetas_version WHERE producto_id IN (SELECT id FROM productos WHERE nombre LIKE 'VC %')")
    cur.execute("DELETE FROM productos WHERE nombre LIKE 'VC %'")
    cur.execute("DELETE FROM ingredientes WHERE nombre LIKE 'VC %'")
    cur.execute("DELETE FROM unidades_medida WHERE abreviatura = 'gvc'")
    cur.execute("DELETE FROM turnos WHERE usuario_id IN (SELECT id FROM usuarios WHERE identificador_acceso = 'vc-cajero')")
    cur.execute("DELETE FROM usuarios WHERE identificador_acceso = 'vc-cajero'")
    cur.execute("DELETE FROM sucursales WHERE nombre LIKE 'VC %'")


def main():
    conexion = conectar()
    cur = conexion.cursor()
    limpiar(cur, None)
    suc, otra, cajero, ids = preparar(cur)
    errores, ventas = [], []
    hilos = [threading.Thread(target=vender, args=(suc, cajero, n, errores, ventas)) for n in range(HILOS)]
    for hilo in hilos:
        hilo.start()
    for hilo in hilos:
        hilo.join()

    total = HILOS * VENTAS_POR_HILO
    cur.execute('SELECT stock_actual FROM stock_sucursal WHERE ingrediente_id = %s AND sucursal_id = %s', (ids['VC Harina'], suc))
    harina = cur.fetchone()[0]
    cur.execute('SELECT stock_actual FROM stock_producto_sucursal WHERE producto_id = %s AND sucursal_id = %s', (ids['VC Bebida'], suc))
    bebida = cur.fetchone()[0]
    cur.execute('SELECT stock_actual FROM stock_sucursal WHERE ingrediente_id = %s AND sucursal_id = %s', (ids['VC Harina'], otra))
    harina_otra = cur.fetchone()[0]
    limpiar(cur, ids)
    conexion.close()

    print(f'{total} ventas intentadas, {len(ventas)} registradas, {len(errores)} errores')
    for error in sorted(set(errores))[:5]:
        print('  error:', error, f'(x{errores.count(error)})')
    # Cada venta lleva X e Y (1 harina cada uno) y 1 bebida.
    ok = (not errores and len(ventas) == total
          and harina == 10000 - 2 * total and bebida == 10000 - total and harina_otra == 10000)
    print(f'harina {harina} (esperado {10000 - 2 * total}), bebida {bebida} (esperado {10000 - total}), '
          f'otra sucursal {harina_otra} (esperado 10000)')
    print('venta_concurrente: OK' if ok else 'venta_concurrente: FALLA')
    raise SystemExit(0 if ok else 1)


if __name__ == '__main__':
    main()
