-- H3.3 T08 - Prueba integral del catálogo de artículos: ambos tipos, duplicados, unidades,
-- permisos, desactivación y conservación del historial.
-- Base de pruebas con todas las migraciones de H3.3 (modelo de artículos, unidad fija,
-- permisos del bodeguero, nombres únicos, receta con ingrediente activo) y
-- 20261026_movimientos_articulos.sql. Todo se revierte al terminar.
-- Complementa las pruebas de cada tarea: modelo_articulos, unidad_fija_ingrediente,
-- catalogo_materias_primas_bodeguero, nombres_unicos_normalizados y receta_ingrediente_activo.
\set ON_ERROR_STOP on
BEGIN;
DO $$
DECLARE
    suc INTEGER; cajero INTEGER; kg INTEGER; g INTEGER;
    harina INTEGER; bebida INTEGER; sandwich INTEGER; venta INTEGER; n INTEGER;
BEGIN
    INSERT INTO sucursales (nombre) VALUES ('CI sucursal') RETURNING id INTO suc;
    INSERT INTO usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('CI cajero', 'ci-cajero', 'x', 'cajero', suc) RETURNING id INTO cajero;
    INSERT INTO turnos (usuario_id, sucursal_id, hora_inicio) VALUES (cajero, suc, now());
    INSERT INTO unidades_medida (nombre, abreviatura) VALUES ('CI Kilo', 'ckg') RETURNING id INTO kg;
    INSERT INTO unidades_medida (nombre, abreviatura) VALUES ('CI Gramo', 'cg') RETURNING id INTO g;

    -- 1) Ambos tipos ---------------------------------------------------------------------
    INSERT INTO ingredientes (nombre, unidad_id) VALUES ('CI Harina', kg) RETURNING id INTO harina;
    INSERT INTO productos (nombre, precio_venta, codigo_barras) VALUES ('CI Bebida', 1000, '780CI1') RETURNING id INTO bebida;
    INSERT INTO productos (nombre, precio_venta) VALUES ('CI Sandwich', 3000) RETURNING id INTO sandwich;
    INSERT INTO recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id) VALUES (sandwich, harina, 0.2, kg);
    SELECT count(*) INTO n FROM v_articulos
     WHERE (tipo = 'materia_prima' AND articulo_id = harina AND unidad = 'ckg')
        OR (tipo = 'producto' AND articulo_id = bebida AND unidad = 'un');
    IF n <> 2 THEN RAISE EXCEPTION 'Caso 1: faltan artículos de algún tipo (% de 2)', n; END IF;
    IF EXISTS (SELECT 1 FROM v_articulos WHERE tipo = 'producto' AND articulo_id = sandwich) THEN
        RAISE EXCEPTION 'Caso 1: un producto con receta no es artículo de bodega';
    END IF;

    -- 2) Duplicados ignorando mayúsculas y espacios ---------------------------------------
    BEGIN
        INSERT INTO ingredientes (nombre, unidad_id) VALUES (' ci   HARINA', kg);
        RAISE EXCEPTION 'Caso 2: ingrediente repetido aceptado';
    EXCEPTION WHEN unique_violation THEN NULL;
    END;
    BEGIN
        INSERT INTO productos (nombre, precio_venta, codigo_barras) VALUES ('CI Otra', 900, '780ci 1');
        RAISE EXCEPTION 'Caso 2: código de barras repetido aceptado';
    EXCEPTION WHEN unique_violation THEN NULL;
    END;

    -- 3) Unidades: obligatoria, fija y base de la receta ----------------------------------
    BEGIN
        INSERT INTO ingredientes (nombre, unidad_id) VALUES ('CI Sin unidad', NULL);
        RAISE EXCEPTION 'Caso 3: ingrediente sin unidad aceptado';
    EXCEPTION WHEN not_null_violation THEN NULL;
    END;
    BEGIN
        UPDATE ingredientes SET unidad_id = g WHERE id = harina;
        RAISE EXCEPTION 'Caso 3: cambio de unidad aceptado';
    EXCEPTION WHEN invalid_parameter_value THEN NULL;
    END;

    -- 4) Desactivación y conservación del historial ---------------------------------------
    INSERT INTO stock_sucursal (ingrediente_id, sucursal_id, stock_actual) VALUES (harina, suc, 5);
    INSERT INTO stock_producto_sucursal (producto_id, sucursal_id, stock_actual) VALUES (bebida, suc, 5);
    INSERT INTO ventas (sucursal_id, cajero_id) VALUES (suc, cajero) RETURNING id INTO venta;
    INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_lista, precio_unitario) VALUES
        (venta, sandwich, 2, 3000, 3000), (venta, bebida, 1, 1000, 1000);
    UPDATE ingredientes SET activo = false WHERE id = harina;
    UPDATE productos SET activo = false WHERE id = bebida;

    SELECT count(*) INTO n FROM v_articulos
     WHERE NOT activo AND ((tipo = 'materia_prima' AND articulo_id = harina) OR (tipo = 'producto' AND articulo_id = bebida));
    IF n <> 2 THEN RAISE EXCEPTION 'Caso 4: los inactivos deben seguir en el catálogo (% de 2)', n; END IF;
    SELECT count(*) INTO n FROM v_movimientos_articulos WHERE venta_id = venta;
    IF n <> 2 THEN RAISE EXCEPTION 'Caso 4: se perdió historial tras desactivar (% de 2)', n; END IF;
    IF NOT EXISTS (SELECT 1 FROM recetas WHERE producto_id = sandwich AND ingrediente_id = harina) THEN
        RAISE EXCEPTION 'Caso 4: desactivar borró la receta anterior';
    END IF;
    IF (SELECT stock_actual FROM stock_sucursal WHERE ingrediente_id = harina AND sucursal_id = suc) <> 4.6 THEN
        RAISE EXCEPTION 'Caso 4: el stock de la harina cambió al desactivar';
    END IF;
    -- No se puede asociar un inactivo en una receta nueva...
    BEGIN
        INSERT INTO productos (nombre, precio_venta) VALUES ('CI Tostada', 2000);
        INSERT INTO recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id)
        SELECT id, harina, 0.1, kg FROM productos WHERE nombre = 'CI Tostada';
        RAISE EXCEPTION 'Caso 4: se asoció un ingrediente inactivo';
    EXCEPTION WHEN invalid_parameter_value THEN NULL;
    END;
    -- ...ni vender un producto inactivo.
    BEGIN
        PERFORM fn_registrar_venta(suc, cajero, 'efectivo', '[{"producto":"CI Bebida","cantidad":1}]');
        RAISE EXCEPTION 'Caso 4: se vendió un producto inactivo';
    EXCEPTION WHEN raise_exception THEN
        IF SQLERRM NOT LIKE '%inactivo%' OR SQLERRM LIKE 'Caso 4%' THEN RAISE; END IF;
    END;

    RAISE NOTICE 'catálogo H3.3: tipos, duplicados, unidades, desactivación e historial OK';
END $$;

-- 5) Permisos ----------------------------------------------------------------------------
DO $$
BEGIN
    IF NOT has_table_privilege('nury_bodeguero', 'public.v_articulos', 'SELECT')
       OR NOT has_table_privilege('nury_bodeguero', 'public.v_movimientos_articulos', 'SELECT')
       OR NOT has_column_privilege('nury_bodeguero', 'public.ingredientes', 'nombre', 'INSERT')
       OR NOT has_column_privilege('nury_bodeguero', 'public.ingredientes', 'activo', 'UPDATE')
       OR has_column_privilege('nury_bodeguero', 'public.ingredientes', 'unidad_id', 'UPDATE')
       OR has_table_privilege('nury_bodeguero', 'public.ingredientes', 'DELETE')
       OR has_column_privilege('nury_bodeguero', 'public.productos', 'activo', 'UPDATE')
       OR has_table_privilege('nury_cajero', 'public.v_articulos', 'SELECT')
       OR has_column_privilege('nury_cajero', 'public.ingredientes', 'nombre', 'INSERT') THEN
        RAISE EXCEPTION 'Caso 5: permisos del catálogo incorrectos';
    END IF;
    RAISE NOTICE 'catalogo_integral_h33: OK';
END $$;
ROLLBACK;
