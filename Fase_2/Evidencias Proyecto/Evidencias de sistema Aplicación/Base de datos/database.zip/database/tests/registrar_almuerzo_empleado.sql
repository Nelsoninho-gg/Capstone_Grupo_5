-- H2.13 T03 — Pruebas del registro de almuerzos con descuento de stock.
--
-- Requiere las migraciones 20261022_almuerzos_empleado.sql y
-- 20261022_registrar_almuerzo_empleado.sql aplicadas.
--
-- Todo corre dentro de un único bloque que termina con un error a propósito,
-- así PostgreSQL deshace los almuerzos, productos y movimientos de la prueba:
-- no queda nada guardado.
--
-- Resultado:
--   - Si todo está bien, el último mensaje es
--     "TODAS LAS PRUEBAS PASARON ... se deshizo todo".
--   - Si algo falla, el mensaje empieza con "FALLO" e indica qué caso.
-- Cada caso aprobado deja una línea NOTICE "OK ..." en la pestaña Messages.

DO $$
DECLARE
    v_suc        INTEGER;
    v_otra_suc   INTEGER;
    v_cajero     INTEGER;
    v_admin      INTEGER;
    v_empleado   INTEGER;
    v_inactivo   INTEGER;
    v_unidad     INTEGER;
    v_pan        INTEGER;
    v_queso      INTEGER;
    v_menu       INTEGER;
    v_bebida     INTEGER;
    v_version    INTEGER;
    v_id         INTEGER;
    v_id2        INTEGER;
    a            RECORD;
    v_ventas     BIGINT;
    v_movs_venta BIGINT;
    v_almuerzos  BIGINT;
    v_movs       BIGINT;
    v_casos      INTEGER := 0;
    v_error      TEXT;
BEGIN
    -- Datos propios de la prueba ------------------------------------------------
    INSERT INTO sucursales (nombre) VALUES ('Almuerzo prueba A') RETURNING id INTO v_suc;
    INSERT INTO sucursales (nombre) VALUES ('Almuerzo prueba B') RETURNING id INTO v_otra_suc;
    INSERT INTO usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('Cajero almuerzo', 'cajero.almuerzo', 'x', 'cajero', v_suc) RETURNING id INTO v_cajero;
    INSERT INTO usuarios (nombre, identificador_acceso, password_hash, rol)
        VALUES ('Admin almuerzo', 'admin.almuerzo', 'x', 'admin') RETURNING id INTO v_admin;
    INSERT INTO usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('Empleado almuerzo', 'empleado.almuerzo', 'x', 'cajero', v_suc) RETURNING id INTO v_empleado;
    INSERT INTO usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id, activo)
        VALUES ('Inactivo almuerzo', 'inactivo.almuerzo', 'x', 'cajero', v_suc, FALSE) RETURNING id INTO v_inactivo;
    INSERT INTO unidades_medida (nombre, abreviatura) VALUES ('Unidad almuerzo', 'ualm') RETURNING id INTO v_unidad;
    INSERT INTO ingredientes (nombre, unidad_id) VALUES ('Pan almuerzo', v_unidad) RETURNING id INTO v_pan;
    INSERT INTO ingredientes (nombre, unidad_id) VALUES ('Queso almuerzo', v_unidad) RETURNING id INTO v_queso;
    INSERT INTO productos (nombre, precio_venta) VALUES ('Menú almuerzo prueba', 5000) RETURNING id INTO v_menu;
    INSERT INTO productos (nombre, precio_venta) VALUES ('Bebida almuerzo prueba', 1000) RETURNING id INTO v_bebida;
    -- Menú con receta (2 pan + 30 queso); la bebida es de reventa.
    INSERT INTO recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id)
        VALUES (v_menu, v_pan, 2, v_unidad), (v_menu, v_queso, 30, v_unidad);
    SELECT id INTO v_version FROM recetas_version WHERE producto_id = v_menu ORDER BY numero DESC LIMIT 1;
    INSERT INTO stock_sucursal (ingrediente_id, sucursal_id, stock_actual) VALUES (v_pan, v_suc, 10), (v_queso, v_suc, 100);
    INSERT INTO stock_producto_sucursal (producto_id, sucursal_id, stock_actual) VALUES (v_bebida, v_suc, 5);

    SELECT count(*) INTO v_ventas FROM ventas;
    SELECT count(*) INTO v_movs_venta FROM movimientos_stock WHERE tipo_movimiento = 'venta';

    -- Sesión del cajero (como la deja PostgREST con su JWT).
    PERFORM set_config('request.jwt.claims',
        json_build_object('role', 'nury_cajero', 'user_id', v_cajero)::text, TRUE);

    -- 1) Registra el almuerzo con empleado, productos, cantidades, cajero, fecha y sucursal
    v_id := fn_registrar_almuerzo_empleado(v_suc, v_empleado,
        jsonb_build_array(
            jsonb_build_object('producto_id', v_menu, 'cantidad', 1),
            jsonb_build_object('producto_id', v_bebida, 'cantidad', 2)));
    SELECT * INTO a FROM almuerzos_empleado WHERE id = v_id;
    IF a.sucursal_id <> v_suc OR a.empleado_id <> v_empleado OR a.cajero_id <> v_cajero
        OR a.fecha <> (now() AT TIME ZONE 'America/Santiago')::date THEN
        RAISE EXCEPTION 'FALLO 1: cabecera incorrecta: %', row_to_json(a);
    END IF;
    IF (SELECT count(*) FROM almuerzos_empleado_detalle WHERE almuerzo_id = v_id) <> 2
        OR (SELECT cantidad FROM almuerzos_empleado_detalle WHERE almuerzo_id = v_id AND producto_id = v_bebida) <> 2 THEN
        RAISE EXCEPTION 'FALLO 1: el detalle no guardó los productos y cantidades';
    END IF;
    v_casos := v_casos + 1;
    RAISE NOTICE 'OK 1. Almuerzo guardado: empleado, cajero de la sesión, fecha, sucursal y productos';

    -- 2) Producto con receta: descuenta ingredientes de la versión vigente ---------
    IF (SELECT stock_actual FROM stock_sucursal WHERE ingrediente_id = v_pan AND sucursal_id = v_suc) <> 8
        OR (SELECT stock_actual FROM stock_sucursal WHERE ingrediente_id = v_queso AND sucursal_id = v_suc) <> 70 THEN
        RAISE EXCEPTION 'FALLO 2: no descontó los ingredientes de la receta (pan 10→8, queso 100→70)';
    END IF;
    IF (SELECT receta_version_id FROM almuerzos_empleado_detalle WHERE almuerzo_id = v_id AND producto_id = v_menu)
        IS DISTINCT FROM v_version
        OR (SELECT receta_version_id FROM almuerzos_empleado_detalle WHERE almuerzo_id = v_id AND producto_id = v_bebida)
        IS NOT NULL THEN
        RAISE EXCEPTION 'FALLO 2: la línea no guardó la versión de receta usada';
    END IF;
    v_casos := v_casos + 1;
    RAISE NOTICE 'OK 2. Producto con receta: descuenta sus ingredientes y guarda la versión de receta';

    -- 3) Producto de reventa: descuenta sus unidades --------------------------------
    IF (SELECT stock_actual FROM stock_producto_sucursal WHERE producto_id = v_bebida AND sucursal_id = v_suc) <> 3 THEN
        RAISE EXCEPTION 'FALLO 3: no descontó las unidades del producto (5→3)';
    END IF;
    v_casos := v_casos + 1;
    RAISE NOTICE 'OK 3. Producto de reventa: descuenta sus unidades';

    -- 4) Movimientos identificados como consumo interno -----------------------------
    IF (SELECT count(*) FROM movimientos_stock
         WHERE tipo_movimiento = 'consumo_interno' AND referencia_tipo = 'almuerzo_empleado'
           AND referencia_id = v_id AND sucursal_id = v_suc) <> 3
        OR EXISTS (SELECT 1 FROM movimientos_stock
                    WHERE referencia_tipo = 'almuerzo_empleado' AND referencia_id = v_id
                      AND tipo_movimiento <> 'consumo_interno') THEN
        RAISE EXCEPTION 'FALLO 4: los movimientos no quedaron como consumo interno del almuerzo';
    END IF;
    IF (SELECT cantidad FROM movimientos_stock
         WHERE referencia_tipo = 'almuerzo_empleado' AND referencia_id = v_id AND producto_id = v_bebida) <> -2
        OR (SELECT stock_resultante FROM movimientos_stock
             WHERE referencia_tipo = 'almuerzo_empleado' AND referencia_id = v_id AND ingrediente_id = v_queso) <> 70 THEN
        RAISE EXCEPTION 'FALLO 4: cantidad o stock resultante incorrecto en el kardex';
    END IF;
    v_casos := v_casos + 1;
    RAISE NOTICE 'OK 4. Kardex: 3 movimientos consumo_interno ligados al almuerzo, con cantidad y saldo';

    -- 5) No es una venta ---------------------------------------------------------------
    IF (SELECT count(*) FROM ventas) <> v_ventas
        OR (SELECT count(*) FROM movimientos_stock WHERE tipo_movimiento = 'venta') <> v_movs_venta THEN
        RAISE EXCEPTION 'FALLO 5: el almuerzo creó ventas o movimientos de venta';
    END IF;
    v_casos := v_casos + 1;
    RAISE NOTICE 'OK 5. No crea ventas ni movimientos de venta';

    -- 6) Todo o nada: si una línea falla no queda el almuerzo ni ningún descuento ----
    SELECT count(*) INTO v_almuerzos FROM almuerzos_empleado;
    SELECT count(*) INTO v_movs FROM movimientos_stock;
    BEGIN
        PERFORM fn_registrar_almuerzo_empleado(v_suc, v_admin,
            jsonb_build_array(
                jsonb_build_object('producto_id', v_bebida, 'cantidad', 1),
                jsonb_build_object('producto_id', -1, 'cantidad', 1)));
        RAISE EXCEPTION 'FALLO 6: se aceptó un producto que no existe';
    EXCEPTION
        WHEN invalid_parameter_value THEN NULL;
    END;
    IF (SELECT count(*) FROM almuerzos_empleado) <> v_almuerzos
        OR (SELECT count(*) FROM movimientos_stock) <> v_movs
        OR (SELECT stock_actual FROM stock_producto_sucursal WHERE producto_id = v_bebida AND sucursal_id = v_suc) <> 3 THEN
        RAISE EXCEPTION 'FALLO 6: quedaron cambios parciales después del error';
    END IF;
    v_casos := v_casos + 1;
    RAISE NOTICE 'OK 6. Si falla una línea no queda el almuerzo ni descuentos parciales';

    -- 7) Validaciones con su motivo -----------------------------------------------------
    FOR v_error IN SELECT unnest(ARRAY['sin productos', 'cantidad 0', 'cantidad decimal',
                                       'producto repetido', 'empleado inactivo', 'sin empleado'])
    LOOP
        BEGIN
            CASE v_error
                WHEN 'sin productos' THEN
                    PERFORM fn_registrar_almuerzo_empleado(v_suc, v_admin, '[]'::jsonb);
                WHEN 'cantidad 0' THEN
                    PERFORM fn_registrar_almuerzo_empleado(v_suc, v_admin,
                        jsonb_build_array(jsonb_build_object('producto_id', v_bebida, 'cantidad', 0)));
                WHEN 'cantidad decimal' THEN
                    PERFORM fn_registrar_almuerzo_empleado(v_suc, v_admin,
                        jsonb_build_array(jsonb_build_object('producto_id', v_bebida, 'cantidad', 1.5)));
                WHEN 'producto repetido' THEN
                    PERFORM fn_registrar_almuerzo_empleado(v_suc, v_admin,
                        jsonb_build_array(jsonb_build_object('producto_id', v_bebida, 'cantidad', 1),
                                          jsonb_build_object('producto_id', v_bebida, 'cantidad', 1)));
                WHEN 'empleado inactivo' THEN
                    PERFORM fn_registrar_almuerzo_empleado(v_suc, v_inactivo,
                        jsonb_build_array(jsonb_build_object('producto_id', v_bebida, 'cantidad', 1)));
                WHEN 'sin empleado' THEN
                    PERFORM fn_registrar_almuerzo_empleado(v_suc, NULL,
                        jsonb_build_array(jsonb_build_object('producto_id', v_bebida, 'cantidad', 1)));
            END CASE;
            RAISE EXCEPTION 'FALLO 7: se aceptó un almuerzo con %', v_error;
        EXCEPTION
            WHEN invalid_parameter_value THEN NULL;
        END;
    END LOOP;
    v_casos := v_casos + 1;
    RAISE NOTICE 'OK 7. Rechaza: sin productos, cantidad 0 o decimal, producto repetido, empleado inactivo o sin empleado';

    -- 8) Sesión y sucursal ----------------------------------------------------------------
    BEGIN
        PERFORM fn_registrar_almuerzo_empleado(v_otra_suc, v_admin,
            jsonb_build_array(jsonb_build_object('producto_id', v_bebida, 'cantidad', 1)));
        RAISE EXCEPTION 'FALLO 8: el cajero registró un almuerzo en otra sucursal';
    EXCEPTION
        WHEN insufficient_privilege THEN NULL;
    END;
    PERFORM set_config('request.jwt.claims', '{}', TRUE);
    BEGIN
        PERFORM fn_registrar_almuerzo_empleado(v_suc, v_admin,
            jsonb_build_array(jsonb_build_object('producto_id', v_bebida, 'cantidad', 1)));
        RAISE EXCEPTION 'FALLO 8: se registró un almuerzo sin sesión';
    EXCEPTION
        WHEN insufficient_privilege THEN NULL;
    END;
    -- El admin sí puede registrar en otra sucursal (otro empleado: uno por día, H2.13 T04).
    PERFORM set_config('request.jwt.claims',
        json_build_object('role', 'nury_admin', 'user_id', v_admin)::text, TRUE);
    v_id2 := fn_registrar_almuerzo_empleado(v_otra_suc, v_cajero,
        jsonb_build_array(jsonb_build_object('producto_id', v_bebida, 'cantidad', 1)));
    IF (SELECT cajero_id FROM almuerzos_empleado WHERE id = v_id2) <> v_admin
        OR (SELECT stock_actual FROM stock_producto_sucursal WHERE producto_id = v_bebida AND sucursal_id = v_otra_suc) <> -1
        OR (SELECT stock_actual FROM stock_producto_sucursal WHERE producto_id = v_bebida AND sucursal_id = v_suc) <> 3 THEN
        RAISE EXCEPTION 'FALLO 8: el admin no registró en la otra sucursal o se descontó de la sucursal equivocada';
    END IF;
    v_casos := v_casos + 1;
    RAISE NOTICE 'OK 8. Cajero solo en su sucursal, sin sesión no se puede, admin en cualquiera (descuenta de esa sucursal, puede quedar negativo)';

    -- 9) Permisos de las funciones -------------------------------------------------------
    IF NOT has_function_privilege('nury_cajero', 'public.fn_registrar_almuerzo_empleado(integer,integer,jsonb)', 'EXECUTE')
        OR NOT has_function_privilege('nury_admin', 'public.fn_registrar_almuerzo_empleado(integer,integer,jsonb)', 'EXECUTE')
        OR has_function_privilege('web_anon', 'public.fn_registrar_almuerzo_empleado(integer,integer,jsonb)', 'EXECUTE')
        OR has_function_privilege('nury_bodeguero', 'public.fn_registrar_almuerzo_empleado(integer,integer,jsonb)', 'EXECUTE')
        OR has_function_privilege('nury_cajero',
               'public.fn_descontar_stock_producto(integer,integer,numeric,integer,text,text,integer)', 'EXECUTE')
        OR has_function_privilege('web_anon',
               'public.fn_descontar_stock_producto(integer,integer,numeric,integer,text,text,integer)', 'EXECUTE') THEN
        RAISE EXCEPTION 'FALLO 9: permisos incorrectos en las funciones del almuerzo';
    END IF;
    v_casos := v_casos + 1;
    RAISE NOTICE 'OK 9. Permisos: cajero y admin registran; sin sesión y bodeguero no; el descuento no se llama directo';

    RAISE EXCEPTION 'TODAS LAS PRUEBAS PASARON (% de 9). Se deshizo todo: no quedó ningún almuerzo ni movimiento guardado.',
        v_casos;
END;
$$;
