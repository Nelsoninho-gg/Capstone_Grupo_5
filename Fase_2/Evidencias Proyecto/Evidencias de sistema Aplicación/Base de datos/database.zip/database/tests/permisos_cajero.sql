-- Ejecutar con el propietario en una base de pruebas con el esquema,
-- los roles JWT y 20261012_permisos_cajero.sql. Todo se revierte al terminar.
\set ON_ERROR_STOP on
BEGIN;

CREATE TEMP TABLE casos_cajero (
    cajero INTEGER, otro_cajero INTEGER, admin INTEGER,
    propia INTEGER, ajena INTEGER, otra_sucursal INTEGER, sin_cajero INTEGER
);
GRANT SELECT ON casos_cajero TO nury_cajero, nury_admin;

DO $$
DECLARE
    sucursal INTEGER;
    segunda INTEGER;
    cajero INTEGER;
    otro INTEGER;
    admin INTEGER;
    producto INTEGER;
    propia INTEGER;
    ajena INTEGER;
    otra_sucursal INTEGER;
    sin_cajero INTEGER;
BEGIN
    INSERT INTO public.sucursales (nombre) VALUES ('Prueba permisos cajero') RETURNING id INTO sucursal;
    INSERT INTO public.sucursales (nombre) VALUES ('Prueba otra sucursal') RETURNING id INTO segunda;
    INSERT INTO public.usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('Cajero 1', 'prueba-permisos-cajero-1', 'test', 'cajero', sucursal) RETURNING id INTO cajero;
    INSERT INTO public.usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('Cajero 2', 'prueba-permisos-cajero-2', 'test', 'cajero', sucursal) RETURNING id INTO otro;
    INSERT INTO public.usuarios (nombre, identificador_acceso, password_hash, rol)
        VALUES ('Admin', 'prueba-permisos-admin', 'test', 'admin') RETURNING id INTO admin;
    INSERT INTO public.productos (nombre, precio_venta) VALUES ('Prueba permisos producto', 1000) RETURNING id INTO producto;
    INSERT INTO public.ventas (sucursal_id, cajero_id) VALUES (sucursal, cajero) RETURNING id INTO propia;
    INSERT INTO public.ventas (sucursal_id, cajero_id) VALUES (sucursal, otro) RETURNING id INTO ajena;
    INSERT INTO public.ventas (sucursal_id, cajero_id) VALUES (segunda, otro) RETURNING id INTO otra_sucursal;
    INSERT INTO public.ventas (sucursal_id) VALUES (sucursal) RETURNING id INTO sin_cajero;
    INSERT INTO public.detalle_venta (venta_id, producto_id, cantidad, precio_lista, precio_unitario)
        VALUES (propia, producto, 1, 1000, 1000), (ajena, producto, 1, 1000, 1000);
    INSERT INTO casos_cajero VALUES (cajero, otro, admin, propia, ajena, otra_sucursal, sin_cajero);
END;
$$;

SELECT set_config('request.jwt.claims', json_build_object('role', 'nury_cajero', 'sub', cajero)::text, TRUE)
  FROM casos_cajero;
SET LOCAL ROLE nury_cajero;

DO $$
DECLARE
    caso casos_cajero%ROWTYPE;
    producto INTEGER;
    venta_id INTEGER;
    claim TEXT;
BEGIN
    SELECT * INTO caso FROM casos_cajero;
    FOREACH claim IN ARRAY ARRAY['user_id', 'usuario_id', 'sub', 'id'] LOOP
        PERFORM set_config('request.jwt.claims', jsonb_build_object('role', 'nury_cajero', claim, caso.cajero)::text, TRUE);
        IF public.fn_usuario_actual_id() IS DISTINCT FROM caso.cajero THEN
            RAISE EXCEPTION 'No se reconoce la identidad JWT en %', claim;
        END IF;
    END LOOP;
    IF (SELECT count(*) FROM public.ventas) <> 1
        OR NOT EXISTS (SELECT 1 FROM public.ventas WHERE id = caso.propia)
        OR (SELECT count(*) FROM public.detalle_venta) <> 1 THEN
        RAISE EXCEPTION 'El cajero puede leer ventas o detalles ajenos';
    END IF;

    FOREACH venta_id IN ARRAY ARRAY[caso.ajena, caso.otra_sucursal, caso.sin_cajero] LOOP
        BEGIN
            PERFORM public.fn_anular_venta(venta_id, 'Error al cobrar');
            RAISE EXCEPTION 'Se permitió anular una venta ajena o sin cajero';
        EXCEPTION WHEN insufficient_privilege THEN NULL;
        END;
    END LOOP;
    BEGIN
        UPDATE public.ventas SET anulada = TRUE, anulada_por = caso.otro_cajero WHERE id = caso.propia;
        RAISE EXCEPTION 'Se permitió anular por PATCH o suplantar al actor';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
    BEGIN
        PERFORM public.fn_anular_venta(caso.propia, '  ');
        RAISE EXCEPTION 'Se permitió un motivo vacío';
    EXCEPTION WHEN invalid_parameter_value THEN NULL;
    END;
    BEGIN
        PERFORM public.fn_anular_venta(caso.propia, repeat('x', 251));
        RAISE EXCEPTION 'Se permitió un motivo demasiado largo';
    EXCEPTION WHEN invalid_parameter_value THEN NULL;
    END;
    PERFORM public.fn_anular_venta(caso.propia, '  Error al cobrar  ');
    IF NOT EXISTS (SELECT 1 FROM public.ventas
                    WHERE id = caso.propia AND anulada AND anulada_por = caso.cajero
                      AND anulada_motivo = 'Error al cobrar' AND anulada_en IS NOT NULL) THEN
        RAISE EXCEPTION 'La anulación propia no registra actor, fecha y motivo';
    END IF;
    BEGIN
        PERFORM public.fn_anular_venta(caso.propia, 'Otro motivo');
        RAISE EXCEPTION 'Se permitió anular dos veces';
    EXCEPTION WHEN invalid_parameter_value THEN NULL;
    END;

    INSERT INTO public.productos (nombre, precio_venta)
        VALUES ('Alta por cajero', 2000) RETURNING id INTO producto;
    UPDATE public.productos SET nombre = 'Edición por cajero', precio_venta = 2500 WHERE id = producto;
    IF NOT EXISTS (SELECT 1 FROM public.productos WHERE id = producto AND activo AND precio_venta = 2500) THEN
        RAISE EXCEPTION 'El cajero no puede crear y editar un producto activo';
    END IF;
    BEGIN
        UPDATE public.productos SET activo = FALSE WHERE id = producto;
        RAISE EXCEPTION 'El cajero puede deshabilitar productos';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
    BEGIN
        INSERT INTO public.productos (nombre, precio_venta, activo) VALUES ('Alta inactiva por cajero', 1000, FALSE);
        RAISE EXCEPTION 'El cajero puede crear productos deshabilitados';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
    BEGIN
        DELETE FROM public.productos WHERE id = producto;
        RAISE EXCEPTION 'El cajero puede eliminar productos';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
    BEGIN
        UPDATE public.productos SET id = id + 1000 WHERE id = producto;
        RAISE EXCEPTION 'El cajero puede cambiar identificadores';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
END;
$$;

-- Una sesión sin identidad o con un rol incompatible no puede actuar.
SELECT set_config('request.jwt.claims', '{"role":"nury_cajero"}', TRUE);
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM public.ventas) THEN RAISE EXCEPTION 'Hay ventas sin identidad JWT'; END IF;
    BEGIN
        PERFORM public.fn_anular_venta((SELECT ajena FROM casos_cajero), 'Error al cobrar');
        RAISE EXCEPTION 'Se permitió anular sin identidad';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
END;
$$;
SELECT set_config('request.jwt.claims', json_build_object('role', 'nury_cajero', 'sub', admin)::text, TRUE)
  FROM casos_cajero;
DO $$
BEGIN
    IF public.fn_usuario_actual_id() IS NOT NULL THEN RAISE EXCEPTION 'Se aceptó un rol incompatible'; END IF;
END;
$$;

RESET ROLE;
SELECT set_config('request.jwt.claims', json_build_object('role', 'nury_admin', 'user_id', admin)::text, TRUE)
  FROM casos_cajero;
SET LOCAL ROLE nury_admin;
DO $$
DECLARE
    caso casos_cajero%ROWTYPE;
    producto INTEGER;
BEGIN
    SELECT * INTO caso FROM casos_cajero;
    IF (SELECT count(*) FROM public.ventas) <> 4 OR (SELECT count(*) FROM public.detalle_venta) <> 2 THEN
        RAISE EXCEPTION 'El admin perdió lectura del historial completo';
    END IF;
    IF EXISTS (SELECT 1 FROM public.ventas WHERE id IN (caso.ajena, caso.otra_sucursal, caso.sin_cajero) AND anulada) THEN
        RAISE EXCEPTION 'Un intento rechazado modificó una venta';
    END IF;
    PERFORM public.fn_anular_venta(caso.ajena, 'Anulación por admin');
    PERFORM public.fn_anular_venta(caso.sin_cajero, 'Anulación por admin');
    IF NOT EXISTS (SELECT 1 FROM public.ventas WHERE id = caso.ajena AND anulada_por = caso.admin) THEN
        RAISE EXCEPTION 'El administrador perdió la anulación de otros cajeros';
    END IF;
    INSERT INTO public.productos (nombre, precio_venta) VALUES ('Alta por admin', 1000) RETURNING id INTO producto;
    UPDATE public.productos SET activo = FALSE WHERE id = producto;
    DELETE FROM public.productos WHERE id = producto;
END;
$$;
RESET ROLE;

UPDATE public.usuarios SET activo = FALSE WHERE id = (SELECT cajero FROM casos_cajero);
SELECT set_config('request.jwt.claims', json_build_object('role', 'nury_cajero', 'user_id', cajero)::text, TRUE)
  FROM casos_cajero;
SET LOCAL ROLE nury_cajero;
DO $$
BEGIN
    IF public.fn_usuario_actual_id() IS NOT NULL OR EXISTS (SELECT 1 FROM public.ventas) THEN
        RAISE EXCEPTION 'Un usuario deshabilitado conserva acceso al historial';
    END IF;
    BEGIN
        PERFORM public.fn_anular_venta((SELECT otra_sucursal FROM casos_cajero), 'Error al cobrar');
        RAISE EXCEPTION 'Un usuario deshabilitado puede anular';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
END;
$$;
RESET ROLE;

DO $$
DECLARE
    rol TEXT;
BEGIN
    FOREACH rol IN ARRAY ARRAY['web_anon', 'nury_bodeguero'] LOOP
        IF has_function_privilege(rol, 'public.fn_anular_venta(integer,text)', 'EXECUTE') THEN
            RAISE EXCEPTION '% puede ejecutar anulaciones', rol;
        END IF;
    END LOOP;
END;
$$;

ROLLBACK;
\echo 'PASS: historial propio, anulación, auditoría, productos y permisos por rol.'
