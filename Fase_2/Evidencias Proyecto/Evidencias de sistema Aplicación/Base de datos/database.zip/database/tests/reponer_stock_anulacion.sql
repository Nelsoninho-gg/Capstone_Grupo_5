-- H3.2 T08 - Reponer el stock al anular una venta.
-- Ejecutar con el propietario en una base de pruebas con el esquema, los roles
-- JWT y las migraciones hasta 0007_reponer_stock_anulacion_venta.sql.
-- Todo se revierte al terminar.
\set ON_ERROR_STOP on
BEGIN;

CREATE TEMP TABLE caso_t08 (
    suc1 INTEGER, suc2 INTEGER, cajero INTEGER, cajero2 INTEGER,
    pan INTEGER, queso INTEGER, sandwich INTEGER, bebida INTEGER,
    venta1 INTEGER, venta2 INTEGER, venta_sin_mov INTEGER
);
GRANT SELECT ON caso_t08 TO nury_cajero;

-- Datos: un producto con receta (2 pan + 30 queso) y uno de reventa sin receta.
DO $$
DECLARE
    c caso_t08%ROWTYPE;
    unidad INTEGER;
BEGIN
    INSERT INTO public.sucursales (nombre) VALUES ('T08 sucursal 1') RETURNING id INTO c.suc1;
    INSERT INTO public.sucursales (nombre) VALUES ('T08 sucursal 2') RETURNING id INTO c.suc2;
    INSERT INTO public.usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('T08 cajero', 't08-cajero', 'test', 'cajero', c.suc1) RETURNING id INTO c.cajero;
    INSERT INTO public.usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('T08 cajero 2', 't08-cajero-2', 'test', 'cajero', c.suc2) RETURNING id INTO c.cajero2;
    INSERT INTO public.unidades_medida (nombre, abreviatura) VALUES ('T08 unidad', 't08') RETURNING id INTO unidad;
    INSERT INTO public.ingredientes (nombre, unidad_id) VALUES ('T08 pan', unidad) RETURNING id INTO c.pan;
    INSERT INTO public.ingredientes (nombre, unidad_id) VALUES ('T08 queso', unidad) RETURNING id INTO c.queso;
    INSERT INTO public.productos (nombre, precio_venta) VALUES ('T08 sandwich', 3000) RETURNING id INTO c.sandwich;
    INSERT INTO public.productos (nombre, precio_venta) VALUES ('T08 bebida', 1000) RETURNING id INTO c.bebida;
    INSERT INTO public.recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id)
        VALUES (c.sandwich, c.pan, 2, unidad), (c.sandwich, c.queso, 30, unidad);

    INSERT INTO public.stock_sucursal (ingrediente_id, sucursal_id, stock_actual) VALUES
        (c.pan, c.suc1, 100), (c.queso, c.suc1, 1000), (c.pan, c.suc2, 50), (c.queso, c.suc2, 500);
    INSERT INTO public.stock_producto_sucursal (producto_id, sucursal_id, stock_actual) VALUES
        (c.bebida, c.suc1, 20), (c.bebida, c.suc2, 10);

    -- Venta 1 (sucursal 1): 2 sándwiches en dos líneas (1 + 1) y 3 bebidas.
    INSERT INTO public.ventas (sucursal_id, cajero_id) VALUES (c.suc1, c.cajero) RETURNING id INTO c.venta1;
    INSERT INTO public.detalle_venta (venta_id, producto_id, cantidad, precio_lista, precio_unitario) VALUES
        (c.venta1, c.sandwich, 1, 3000, 3000), (c.venta1, c.sandwich, 1, 3000, 3000), (c.venta1, c.bebida, 3, 1000, 1000);
    -- Venta 2 (sucursal 2): 1 sándwich y 1 bebida.
    INSERT INTO public.ventas (sucursal_id, cajero_id) VALUES (c.suc2, c.cajero2) RETURNING id INTO c.venta2;
    INSERT INTO public.detalle_venta (venta_id, producto_id, cantidad, precio_lista, precio_unitario) VALUES
        (c.venta2, c.sandwich, 1, 3000, 3000), (c.venta2, c.bebida, 1, 1000, 1000);
    -- Venta sin movimientos de stock (como las anteriores al control de stock).
    INSERT INTO public.ventas (sucursal_id, cajero_id) VALUES (c.suc1, c.cajero) RETURNING id INTO c.venta_sin_mov;

    INSERT INTO caso_t08 SELECT c.*;
END;
$$;

-- Control: la venta descontó lo esperado.
DO $$
DECLARE c caso_t08%ROWTYPE;
BEGIN
    SELECT * INTO c FROM caso_t08;
    IF (SELECT stock_actual FROM stock_sucursal WHERE ingrediente_id = c.pan AND sucursal_id = c.suc1) <> 96
    OR (SELECT stock_actual FROM stock_sucursal WHERE ingrediente_id = c.queso AND sucursal_id = c.suc1) <> 940
    OR (SELECT stock_actual FROM stock_producto_sucursal WHERE producto_id = c.bebida AND sucursal_id = c.suc1) <> 17
    OR (SELECT stock_actual FROM stock_sucursal WHERE ingrediente_id = c.pan AND sucursal_id = c.suc2) <> 48 THEN
        RAISE EXCEPTION 'El descuento previo a la anulación no es el esperado';
    END IF;
    -- La receta cambia después de la venta: la reposición debe usar lo descontado, no la receta nueva.
    UPDATE recetas SET cantidad_necesaria = 5 WHERE producto_id = c.sandwich AND ingrediente_id = c.pan;
END;
$$;

-- El cajero anula su venta 1 por la API (rol nury_cajero).
SELECT set_config('request.jwt.claims', json_build_object('role', 'nury_cajero', 'sub', cajero)::text, TRUE) FROM caso_t08;
SET LOCAL ROLE nury_cajero;
SELECT public.fn_anular_venta(venta1, 'Prueba T08 cliente se arrepintió') FROM caso_t08;

-- La función interna no se puede llamar directo desde la API.
DO $$
BEGIN
    BEGIN
        PERFORM public.fn_reponer_stock_anulacion(1, 'x');
        RAISE EXCEPTION 'nury_cajero puede ejecutar fn_reponer_stock_anulacion';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
END;
$$;

-- Segunda anulación de la misma venta: rechazada.
DO $$
DECLARE v INTEGER;
BEGIN
    SELECT venta1 INTO v FROM caso_t08;
    BEGIN
        PERFORM public.fn_anular_venta(v, 'Segundo intento de anulación');
        RAISE EXCEPTION 'Se pudo anular dos veces la misma venta';
    EXCEPTION WHEN SQLSTATE '22023' THEN NULL;
    END;
END;
$$;

-- Venta sin movimientos: se anula sin error y no repone nada.
SELECT public.fn_anular_venta(venta_sin_mov, 'Prueba venta sin stock') FROM caso_t08;
RESET ROLE;

DO $$
DECLARE c caso_t08%ROWTYPE; n INTEGER;
BEGIN
    SELECT * INTO c FROM caso_t08;
    -- Stock de la sucursal 1 vuelve al valor original (2 sándwiches con receta original: 4 pan, 60 queso).
    IF (SELECT stock_actual FROM stock_sucursal WHERE ingrediente_id = c.pan AND sucursal_id = c.suc1) <> 100 THEN
        RAISE EXCEPTION 'Pan sucursal 1 no se repuso a 100';
    END IF;
    IF (SELECT stock_actual FROM stock_sucursal WHERE ingrediente_id = c.queso AND sucursal_id = c.suc1) <> 1000 THEN
        RAISE EXCEPTION 'Queso sucursal 1 no se repuso a 1000';
    END IF;
    IF (SELECT stock_actual FROM stock_producto_sucursal WHERE producto_id = c.bebida AND sucursal_id = c.suc1) <> 20 THEN
        RAISE EXCEPTION 'Bebida sucursal 1 no se repuso a 20';
    END IF;
    -- La sucursal 2 (venta no anulada) no se toca.
    IF (SELECT stock_actual FROM stock_sucursal WHERE ingrediente_id = c.pan AND sucursal_id = c.suc2) <> 48
    OR (SELECT stock_actual FROM stock_producto_sucursal WHERE producto_id = c.bebida AND sucursal_id = c.suc2) <> 9 THEN
        RAISE EXCEPTION 'La anulación tocó el stock de otra sucursal';
    END IF;
    -- Kardex: un movimiento contrario por ítem, vinculado a la venta original, en su sucursal.
    SELECT count(*) INTO n FROM movimientos_stock
     WHERE tipo_movimiento = 'anulacion_venta' AND referencia_tipo = 'venta' AND referencia_id = c.venta1
       AND sucursal_id = c.suc1 AND cantidad > 0;
    IF n <> 3 THEN RAISE EXCEPTION 'Se esperaban 3 movimientos de reposición, hay %', n; END IF;
    IF (SELECT cantidad FROM movimientos_stock WHERE tipo_movimiento = 'anulacion_venta'
          AND referencia_id = c.venta1 AND ingrediente_id = c.pan) <> 4
    OR (SELECT stock_resultante FROM movimientos_stock WHERE tipo_movimiento = 'anulacion_venta'
          AND referencia_id = c.venta1 AND producto_id = c.bebida) <> 20 THEN
        RAISE EXCEPTION 'Cantidad o stock resultante de la reposición incorrectos';
    END IF;
    -- La suma del kardex de la venta anulada queda en cero.
    IF EXISTS (SELECT 1 FROM movimientos_stock WHERE referencia_tipo = 'venta' AND referencia_id = c.venta1
                GROUP BY ingrediente_id, producto_id HAVING SUM(cantidad) <> 0) THEN
        RAISE EXCEPTION 'El kardex de la venta anulada no suma cero';
    END IF;
    IF EXISTS (SELECT 1 FROM movimientos_stock WHERE referencia_id = c.venta_sin_mov) THEN
        RAISE EXCEPTION 'La venta sin movimientos generó reposición';
    END IF;
    -- Una sola reposición por venta, aunque se intente insertar a mano.
    BEGIN
        INSERT INTO movimientos_stock (ingrediente_id, sucursal_id, tipo_movimiento, cantidad, stock_resultante, referencia_tipo, referencia_id)
        VALUES (c.pan, c.suc1, 'anulacion_venta', 4, 104, 'venta', c.venta1);
        RAISE EXCEPTION 'Se pudo registrar dos veces la reposición de la misma venta';
    EXCEPTION WHEN unique_violation THEN NULL;
    END;
    -- Llamar de nuevo a la reposición (como dueño) también se rechaza.
    BEGIN
        PERFORM public.fn_reponer_stock_anulacion(c.venta1, 'reintento');
        RAISE EXCEPTION 'La reposición se pudo ejecutar dos veces';
    EXCEPTION WHEN unique_violation THEN NULL;
    END;
END;
$$;

\echo 'PASS: reposición exacta, sucursal correcta, kardex vinculado, una sola vez y sin acceso directo.'
ROLLBACK;
