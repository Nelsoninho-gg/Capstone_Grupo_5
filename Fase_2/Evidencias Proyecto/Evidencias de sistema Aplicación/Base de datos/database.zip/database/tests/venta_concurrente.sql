-- H3.2 T05 - La venta descuenta solo en su sucursal, y el bloqueo previo
-- (fn_bloquear_stock_venta, 20261027_venta_concurrente.sql) no cambia el resultado.
-- La concurrencia real (varias conexiones a la vez) se prueba en venta_concurrente.py.
-- Base de pruebas; todo se revierte.
\set ON_ERROR_STOP on
BEGIN;
DO $$
DECLARE
    a INTEGER; b INTEGER; cajero INTEGER; un INTEGER; pan INTEGER; bebida INTEGER; venta INTEGER;
BEGIN
    INSERT INTO sucursales (nombre) VALUES ('VS A') RETURNING id INTO a;
    INSERT INTO sucursales (nombre) VALUES ('VS B') RETURNING id INTO b;
    INSERT INTO usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('VS cajero', 'vs-cajero', 'x', 'cajero', a) RETURNING id INTO cajero;
    INSERT INTO turnos (usuario_id, sucursal_id, hora_inicio) VALUES (cajero, a, now());
    INSERT INTO unidades_medida (nombre, abreviatura) VALUES ('VS gramo', 'gvs') RETURNING id INTO un;
    INSERT INTO ingredientes (nombre, unidad_id) VALUES ('VS Pan', un) RETURNING id INTO pan;
    INSERT INTO productos (nombre, precio_venta) VALUES ('VS Sandwich', 3000);
    INSERT INTO productos (nombre, precio_venta) VALUES ('VS Bebida', 1000) RETURNING id INTO bebida;
    INSERT INTO recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id)
    SELECT id, pan, 2, un FROM productos WHERE nombre = 'VS Sandwich';
    -- Stock en las dos sucursales.
    INSERT INTO stock_sucursal (ingrediente_id, sucursal_id, stock_actual) VALUES (pan, a, 10), (pan, b, 10);
    INSERT INTO stock_producto_sucursal (producto_id, sucursal_id, stock_actual) VALUES (bebida, a, 5), (bebida, b, 5);

    venta := fn_registrar_venta_idempotente('e1e1e1e1-0000-4000-8000-000000000001', a, cajero, 'efectivo',
        '[{"producto":"VS Sandwich","cantidad":1},{"producto":"VS Bebida","cantidad":2}]');

    -- Solo la sucursal A cambia.
    IF (SELECT stock_actual FROM stock_sucursal WHERE ingrediente_id = pan AND sucursal_id = a) <> 8
       OR (SELECT stock_actual FROM stock_producto_sucursal WHERE producto_id = bebida AND sucursal_id = a) <> 3 THEN
        RAISE EXCEPTION 'No descontó en la sucursal de la venta';
    END IF;
    IF (SELECT stock_actual FROM stock_sucursal WHERE ingrediente_id = pan AND sucursal_id = b) <> 10
       OR (SELECT stock_actual FROM stock_producto_sucursal WHERE producto_id = bebida AND sucursal_id = b) <> 5 THEN
        RAISE EXCEPTION 'Descontó en otra sucursal';
    END IF;
    IF EXISTS (SELECT 1 FROM movimientos_stock WHERE referencia_tipo = 'venta' AND referencia_id = venta AND sucursal_id <> a) THEN
        RAISE EXCEPTION 'El kardex registró otra sucursal';
    END IF;

    -- Un cajero no puede vender en una sucursal donde no tiene turno.
    BEGIN
        PERFORM fn_registrar_venta_idempotente('e1e1e1e1-0000-4000-8000-000000000002', b, cajero, 'efectivo',
            '[{"producto":"VS Bebida","cantidad":1}]');
        RAISE EXCEPTION 'Vendió en una sucursal sin turno';
    EXCEPTION WHEN invalid_authorization_specification THEN NULL;
    END;
    IF (SELECT stock_actual FROM stock_producto_sucursal WHERE producto_id = bebida AND sucursal_id = b) <> 5 THEN
        RAISE EXCEPTION 'La venta rechazada dejó descuento';
    END IF;

    -- El bloqueo previo crea en 0 (como la venta) solo las filas de la sucursal de la venta.
    INSERT INTO productos (nombre, precio_venta) VALUES ('VS Nuevo', 500);
    PERFORM fn_bloquear_stock_venta(a, '[{"producto":"VS Nuevo","cantidad":1}]');
    IF NOT EXISTS (SELECT 1 FROM stock_producto_sucursal s JOIN productos p ON p.id = s.producto_id
                    WHERE p.nombre = 'VS Nuevo' AND s.sucursal_id = a AND s.stock_actual = 0)
       OR EXISTS (SELECT 1 FROM stock_producto_sucursal s JOIN productos p ON p.id = s.producto_id
                   WHERE p.nombre = 'VS Nuevo' AND s.sucursal_id = b) THEN
        RAISE EXCEPTION 'El bloqueo previo creó filas fuera de la sucursal';
    END IF;

    RAISE NOTICE 'venta_concurrente: OK';
END $$;
DO $$
BEGIN
    IF has_function_privilege('nury_cajero', 'public.fn_bloquear_stock_venta(integer, jsonb)', 'EXECUTE') THEN
        RAISE EXCEPTION 'fn_bloquear_stock_venta no debe ser ejecutable desde la API';
    END IF;
END $$;
ROLLBACK;
