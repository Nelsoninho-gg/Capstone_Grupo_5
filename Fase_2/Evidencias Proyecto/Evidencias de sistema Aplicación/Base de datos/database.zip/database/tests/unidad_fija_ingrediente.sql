-- Unidad fija de la materia prima (20261023_unidad_fija_ingrediente.sql).
\set ON_ERROR_STOP on
BEGIN;
DO $$
DECLARE v_kg INTEGER; v_g INTEGER; v_ing INTEGER;
BEGIN
    INSERT INTO unidades_medida (nombre, abreviatura) VALUES ('Kilo fija', 'kgf') RETURNING id INTO v_kg;
    INSERT INTO unidades_medida (nombre, abreviatura) VALUES ('Gramo fija', 'grf') RETURNING id INTO v_g;
    INSERT INTO ingredientes (nombre, unidad_id) VALUES ('Sin uso fija', v_kg) RETURNING id INTO v_ing;

    -- 1) Aunque no tenga recetas, movimientos ni stock, la unidad no cambia.
    BEGIN
        UPDATE ingredientes SET unidad_id = v_g WHERE id = v_ing;
        RAISE EXCEPTION 'Caso 1: se cambió la unidad de una materia prima sin uso';
    EXCEPTION WHEN invalid_parameter_value THEN NULL;
    END;

    -- 2) Los demás datos se siguen editando, y repetir la misma unidad no es un cambio.
    UPDATE ingredientes SET nombre = 'Sin uso fija editada', unidad_id = v_kg, activo = FALSE WHERE id = v_ing;
    IF (SELECT unidad_id FROM ingredientes WHERE id = v_ing) <> v_kg
       OR (SELECT nombre FROM ingredientes WHERE id = v_ing) <> 'Sin uso fija editada' THEN
        RAISE EXCEPTION 'Caso 2: no se pudieron editar los otros datos';
    END IF;
    RAISE NOTICE 'unidad_fija_ingrediente: 2 casos OK';
END $$;
ROLLBACK;
