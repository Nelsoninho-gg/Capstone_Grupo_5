-- Permiso mínimo de recetas para el bodeguero (20261021_permiso_recetas_bodeguero.sql).
\set ON_ERROR_STOP on
BEGIN;
DO $$
BEGIN
    IF NOT has_column_privilege('nury_bodeguero', 'public.recetas', 'producto_id', 'SELECT')
       OR has_column_privilege('nury_bodeguero', 'public.recetas', 'cantidad_necesaria', 'SELECT')
       OR has_column_privilege('nury_bodeguero', 'public.recetas', 'ingrediente_id', 'SELECT')
       OR has_table_privilege('nury_bodeguero', 'public.recetas', 'INSERT,UPDATE,DELETE') THEN
        RAISE EXCEPTION 'El bodeguero debe leer solo recetas.producto_id';
    END IF;
END $$;
SET LOCAL ROLE nury_bodeguero;
DO $$
BEGIN
    PERFORM producto_id FROM public.recetas LIMIT 1;           -- permitido
    BEGIN
        PERFORM cantidad_necesaria FROM public.recetas LIMIT 1;
        RAISE EXCEPTION 'El bodeguero pudo leer las cantidades de las recetas';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
    RAISE NOTICE 'permiso_recetas_bodeguero: OK';
END $$;
RESET ROLE;
ROLLBACK;
