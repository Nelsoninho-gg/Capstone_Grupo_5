-- H3.2 T01 - v_movimientos_articulos (20261026_movimientos_articulos.sql).
-- Base de pruebas con el esquema y las migraciones hasta esa. Todo se revierte.
\set ON_ERROR_STOP on
BEGIN;
DO $$
DECLARE
    suc INTEGER; cajero INTEGER; un_g INTEGER;
    pan INTEGER; sandwich INTEGER; bebida INTEGER; venta INTEGER;
    n INTEGER; r RECORD;
BEGIN
    INSERT INTO sucursales (nombre) VALUES ('MA sucursal') RETURNING id INTO suc;
    INSERT INTO usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('MA cajero', 'ma-cajero', 'x', 'cajero', suc) RETURNING id INTO cajero;
    INSERT INTO unidades_medida (nombre, abreviatura) VALUES ('MA gramo', 'gma') RETURNING id INTO un_g;
    INSERT INTO ingredientes (nombre, unidad_id) VALUES ('MA Pan', un_g) RETURNING id INTO pan;
    INSERT INTO productos (nombre, precio_venta) VALUES ('MA Sandwich', 3000) RETURNING id INTO sandwich;
    INSERT INTO productos (nombre, precio_venta) VALUES ('MA Bebida', 1000) RETURNING id INTO bebida;
    INSERT INTO recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id) VALUES (sandwich, pan, 2, un_g);
    INSERT INTO stock_sucursal (ingrediente_id, sucursal_id, stock_actual) VALUES (pan, suc, 10);
    INSERT INTO stock_producto_sucursal (producto_id, sucursal_id, stock_actual) VALUES (bebida, suc, 5);

    INSERT INTO ventas (sucursal_id, cajero_id) VALUES (suc, cajero) RETURNING id INTO venta;
    INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_lista, precio_unitario) VALUES
        (venta, sandwich, 1, 3000, 3000), (venta, bebida, 2, 1000, 1000);

    -- Una fila por artículo descontado, con los seis datos de la tarea.
    SELECT count(*) INTO n FROM v_movimientos_articulos WHERE venta_id = venta;
    IF n <> 2 THEN RAISE EXCEPTION 'Se esperaban 2 movimientos de la venta, hay %', n; END IF;

    SELECT * INTO r FROM v_movimientos_articulos WHERE venta_id = venta AND tipo_articulo = 'producto';
    IF r.articulo <> 'MA Bebida' OR r.cantidad <> -2 OR r.unidad <> 'un' OR r.sucursal <> 'MA sucursal'
       OR r.tipo_movimiento <> 'venta' OR r.stock_resultante <> 3 OR r.fecha IS NULL THEN
        RAISE EXCEPTION 'Movimiento de la bebida incorrecto: %', r;
    END IF;

    SELECT * INTO r FROM v_movimientos_articulos WHERE venta_id = venta AND tipo_articulo = 'materia_prima';
    IF r.articulo <> 'MA Pan' OR r.cantidad <> -2 OR r.unidad <> 'gma' OR r.stock_resultante <> 8 THEN
        RAISE EXCEPTION 'Movimiento del pan incorrecto: %', r;
    END IF;

    -- La bebida recibe receta después: sale del catálogo, pero su movimiento sigue visible.
    INSERT INTO recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id) VALUES (bebida, pan, 1, un_g);
    SELECT * INTO r FROM v_movimientos_articulos WHERE venta_id = venta AND tipo_articulo = 'producto';
    IF r.articulo IS DISTINCT FROM 'MA Bebida' OR r.unidad <> 'un' THEN
        RAISE EXCEPTION 'El movimiento antiguo perdió el artículo: %', r;
    END IF;

    -- Movimientos que no son de venta: venta_id queda NULL.
    PERFORM 1 FROM v_movimientos_articulos WHERE venta_id IS NOT NULL AND referencia_tipo <> 'venta';
    IF FOUND THEN RAISE EXCEPTION 'venta_id solo debe venir en movimientos de ventas'; END IF;
END $$;

DO $$
BEGIN
    IF NOT has_table_privilege('nury_bodeguero', 'public.v_movimientos_articulos', 'SELECT')
       OR NOT has_table_privilege('nury_admin', 'public.v_movimientos_articulos', 'SELECT')
       OR has_table_privilege('nury_cajero', 'public.v_movimientos_articulos', 'SELECT') THEN
        RAISE EXCEPTION 'Permisos de v_movimientos_articulos incorrectos';
    END IF;
    RAISE NOTICE 'movimientos_articulos: OK';
END $$;
ROLLBACK;
