-- H3.2 T03 - Consumos de receta (H2.5) y stock propio (H3.2) en un solo proceso, aplicados
-- una sola vez por venta (20261027_detalle_venta_una_vez.sql).
-- Base de pruebas con las migraciones hasta esa y 20261026_venta_idempotente.sql.
-- La venta se registra en una transacción y las modificaciones posteriores en otra, como en
-- producción. Al final se limpia todo lo creado.
\set ON_ERROR_STOP on

-- Transacción 1: registrar una venta mixta (receta + reventa).
BEGIN;
CREATE TEMP TABLE dvu_ids (clave TEXT PRIMARY KEY, valor INTEGER);
DO $$
DECLARE
    suc INTEGER; cajero INTEGER; un INTEGER; pan INTEGER; sandwich INTEGER; bebida INTEGER; venta INTEGER;
BEGIN
    INSERT INTO sucursales (nombre) VALUES ('DVU sucursal') RETURNING id INTO suc;
    INSERT INTO usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('DVU cajero', 'dvu-cajero', 'x', 'cajero', suc) RETURNING id INTO cajero;
    INSERT INTO turnos (usuario_id, sucursal_id, hora_inicio) VALUES (cajero, suc, now());
    INSERT INTO unidades_medida (nombre, abreviatura) VALUES ('DVU gramo', 'gdvu') RETURNING id INTO un;
    INSERT INTO ingredientes (nombre, unidad_id) VALUES ('DVU Pan', un) RETURNING id INTO pan;
    INSERT INTO productos (nombre, precio_venta) VALUES ('DVU Sandwich', 3000) RETURNING id INTO sandwich;
    INSERT INTO productos (nombre, precio_venta) VALUES ('DVU Bebida', 1000) RETURNING id INTO bebida;
    INSERT INTO recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id) VALUES (sandwich, pan, 2, un);
    INSERT INTO stock_sucursal (ingrediente_id, sucursal_id, stock_actual) VALUES (pan, suc, 10);
    INSERT INTO stock_producto_sucursal (producto_id, sucursal_id, stock_actual) VALUES (bebida, suc, 5);

    venta := fn_registrar_venta_idempotente('d0d0d0d0-0000-4000-8000-000000000001', suc, cajero, 'efectivo',
        '[{"producto":"DVU Sandwich","cantidad":2},{"producto":"DVU Bebida","cantidad":3}]');

    -- Un solo proceso: el pan (receta, H2.5) y la bebida (stock propio, H3.2) descontados juntos.
    IF (SELECT stock_actual FROM stock_sucursal WHERE ingrediente_id = pan) <> 6
       OR (SELECT stock_actual FROM stock_producto_sucursal WHERE producto_id = bebida) <> 2
       OR (SELECT count(*) FROM movimientos_stock WHERE referencia_tipo = 'venta' AND referencia_id = venta) <> 2 THEN
        RAISE EXCEPTION 'La venta mixta no descontó una vez cada consumo';
    END IF;
    INSERT INTO dvu_ids VALUES ('venta', venta), ('pan', pan), ('bebida', bebida), ('sandwich', sandwich);
END $$;
COMMIT;

-- Transacción 2: intentos de volver a aplicar o desajustar el descuento.
BEGIN;
DO $$
DECLARE
    venta INTEGER := (SELECT valor FROM dvu_ids WHERE clave = 'venta');
    pan INTEGER := (SELECT valor FROM dvu_ids WHERE clave = 'pan');
    bebida INTEGER := (SELECT valor FROM dvu_ids WHERE clave = 'bebida');
    sandwich INTEGER := (SELECT valor FROM dvu_ids WHERE clave = 'sandwich');
BEGIN
    -- Agregar una línea a una venta ya registrada: rechazado (se descontaría otra vez).
    BEGIN
        INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_lista, precio_unitario)
        VALUES (venta, sandwich, 1, 3000, 3000);
        RAISE EXCEPTION 'Se agregó una línea a una venta registrada';
    EXCEPTION WHEN invalid_parameter_value THEN NULL;
    END;
    -- Cambiar la cantidad o el producto: rechazado.
    BEGIN
        UPDATE detalle_venta SET cantidad = 10 WHERE venta_id = venta AND producto_id = bebida;
        RAISE EXCEPTION 'Se cambió la cantidad de una línea registrada';
    EXCEPTION WHEN invalid_parameter_value THEN NULL;
    END;
    BEGIN
        UPDATE detalle_venta SET producto_id = sandwich WHERE venta_id = venta AND producto_id = bebida;
        RAISE EXCEPTION 'Se cambió el producto de una línea registrada';
    EXCEPTION WHEN invalid_parameter_value THEN NULL;
    END;
    -- Borrar una línea: rechazado.
    BEGIN
        DELETE FROM detalle_venta WHERE venta_id = venta AND producto_id = bebida;
        RAISE EXCEPTION 'Se borró una línea de una venta registrada';
    EXCEPTION WHEN invalid_parameter_value THEN NULL;
    END;
    -- El stock sigue como lo dejó la venta.
    IF (SELECT stock_actual FROM stock_sucursal WHERE ingrediente_id = pan) <> 6
       OR (SELECT stock_actual FROM stock_producto_sucursal WHERE producto_id = bebida) <> 2 THEN
        RAISE EXCEPTION 'El stock cambió sin una venta ni anulación';
    END IF;

    -- La corrección correcta: anular repone exactamente lo descontado, una vez.
    UPDATE ventas SET anulada = true WHERE id = venta;
    PERFORM fn_reponer_stock_anulacion(venta, 'prueba H3.2 T03');
    IF (SELECT stock_actual FROM stock_sucursal WHERE ingrediente_id = pan) <> 10
       OR (SELECT stock_actual FROM stock_producto_sucursal WHERE producto_id = bebida) <> 5 THEN
        RAISE EXCEPTION 'La anulación no repuso el stock';
    END IF;
    -- Y a una venta anulada no se le agregan productos.
    BEGIN
        INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_lista, precio_unitario)
        VALUES (venta, bebida, 1, 1000, 1000);
        RAISE EXCEPTION 'Se agregó una línea a una venta anulada';
    EXCEPTION WHEN invalid_parameter_value THEN NULL;
    END;
    RAISE NOTICE 'detalle_venta_una_vez: OK';
END $$;
ROLLBACK;

-- Limpieza: borrar la venta completa sí está permitido (sus líneas caen por CASCADE).
BEGIN;
DELETE FROM movimientos_stock WHERE referencia_tipo = 'venta' AND referencia_id = (SELECT valor FROM dvu_ids WHERE clave = 'venta');
DELETE FROM ventas_idempotencia WHERE venta_id = (SELECT valor FROM dvu_ids WHERE clave = 'venta');
DELETE FROM ventas WHERE id = (SELECT valor FROM dvu_ids WHERE clave = 'venta');
DELETE FROM stock_sucursal WHERE ingrediente_id = (SELECT valor FROM dvu_ids WHERE clave = 'pan');
DELETE FROM stock_producto_sucursal WHERE producto_id = (SELECT valor FROM dvu_ids WHERE clave = 'bebida');
DELETE FROM recetas WHERE producto_id = (SELECT valor FROM dvu_ids WHERE clave = 'sandwich');
DELETE FROM recetas_version_detalle WHERE version_id IN
    (SELECT id FROM recetas_version WHERE producto_id IN (SELECT id FROM productos WHERE nombre LIKE 'DVU %'));
DELETE FROM recetas_version WHERE producto_id IN (SELECT id FROM productos WHERE nombre LIKE 'DVU %');
DELETE FROM productos WHERE nombre LIKE 'DVU %';
DELETE FROM ingredientes WHERE nombre LIKE 'DVU %';
DELETE FROM unidades_medida WHERE abreviatura = 'gdvu';
DELETE FROM turnos WHERE usuario_id IN (SELECT id FROM usuarios WHERE identificador_acceso = 'dvu-cajero');
DELETE FROM usuarios WHERE identificador_acceso = 'dvu-cajero';
DELETE FROM sucursales WHERE nombre = 'DVU sucursal';
COMMIT;
