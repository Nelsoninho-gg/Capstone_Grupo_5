-- H3.3 T07 - Desactivar sin borrar e impedir nuevas asociaciones con artículos inactivos
-- (20261027_receta_ingrediente_activo.sql). Base de pruebas; todo se revierte.
\set ON_ERROR_STOP on
BEGIN;
DO $$
DECLARE
    suc INTEGER; cajero INTEGER; un INTEGER;
    pan INTEGER; queso INTEGER; sandwich INTEGER; tostada INTEGER; venta INTEGER; n NUMERIC;
BEGIN
    INSERT INTO sucursales (nombre) VALUES ('IA sucursal') RETURNING id INTO suc;
    INSERT INTO usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('IA cajero', 'ia-cajero', 'x', 'cajero', suc) RETURNING id INTO cajero;
    INSERT INTO unidades_medida (nombre, abreviatura) VALUES ('IA gramo', 'gia') RETURNING id INTO un;
    INSERT INTO ingredientes (nombre, unidad_id) VALUES ('IA Pan', un) RETURNING id INTO pan;
    INSERT INTO ingredientes (nombre, unidad_id) VALUES ('IA Queso', un) RETURNING id INTO queso;
    INSERT INTO productos (nombre, precio_venta) VALUES ('IA Sandwich', 3000) RETURNING id INTO sandwich;
    INSERT INTO productos (nombre, precio_venta) VALUES ('IA Tostada', 2000) RETURNING id INTO tostada;
    INSERT INTO recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id) VALUES (sandwich, pan, 2, un);
    INSERT INTO stock_sucursal (ingrediente_id, sucursal_id, stock_actual) VALUES (pan, suc, 10);

    -- Desactivar no borra la receta ni el stock.
    UPDATE ingredientes SET activo = false WHERE id = pan;
    IF NOT EXISTS (SELECT 1 FROM recetas WHERE producto_id = sandwich AND ingrediente_id = pan)
       OR (SELECT stock_actual FROM stock_sucursal WHERE ingrediente_id = pan) <> 10 THEN
        RAISE EXCEPTION 'Desactivar borró la receta o el stock';
    END IF;

    -- Nueva asociación con un inactivo: rechazada.
    BEGIN
        INSERT INTO recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id) VALUES (tostada, pan, 1, un);
        RAISE EXCEPTION 'Se agregó un ingrediente inactivo a una receta';
    EXCEPTION WHEN invalid_parameter_value THEN NULL;
    END;
    -- Cambiar un insumo por uno inactivo: rechazado.
    INSERT INTO recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id) VALUES (tostada, queso, 1, un);
    BEGIN
        UPDATE recetas SET ingrediente_id = pan WHERE producto_id = tostada AND ingrediente_id = queso;
        RAISE EXCEPTION 'Se cambió un insumo por un ingrediente inactivo';
    EXCEPTION WHEN invalid_parameter_value OR unique_violation THEN NULL;
    END;

    -- La receta anterior sigue funcionando: editar la cantidad y vender.
    UPDATE recetas SET cantidad_necesaria = 3 WHERE producto_id = sandwich AND ingrediente_id = pan;
    INSERT INTO ventas (sucursal_id, cajero_id) VALUES (suc, cajero) RETURNING id INTO venta;
    INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_lista, precio_unitario)
        VALUES (venta, sandwich, 1, 3000, 3000);
    SELECT stock_actual INTO n FROM stock_sucursal WHERE ingrediente_id = pan;
    IF n <> 7 THEN RAISE EXCEPTION 'La receta anterior no descontó (stock %)', n; END IF;
    -- Y se puede quitar el insumo inactivo.
    DELETE FROM recetas WHERE producto_id = sandwich AND ingrediente_id = pan;

    -- Al reactivarlo se puede volver a usar.
    UPDATE ingredientes SET activo = true WHERE id = pan;
    INSERT INTO recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id) VALUES (sandwich, pan, 2, un);

    RAISE NOTICE 'receta_ingrediente_activo: OK';
END $$;
ROLLBACK;
