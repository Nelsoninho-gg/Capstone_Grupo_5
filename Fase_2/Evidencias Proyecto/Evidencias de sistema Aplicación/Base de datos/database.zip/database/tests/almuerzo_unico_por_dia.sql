-- H2.13 T04 — Pruebas: al menos un producto y un solo almuerzo por empleado al día.
--
-- Requiere las migraciones 20261022_almuerzos_empleado.sql,
-- 20261022_registrar_almuerzo_empleado.sql y 20261022_almuerzo_unico_por_dia.sql.
--
-- Todo corre dentro de un único bloque que termina con un error a propósito,
-- así PostgreSQL deshace los almuerzos y movimientos de la prueba: no queda
-- nada guardado.
--
-- Resultado:
--   - Si todo está bien, el último mensaje es
--     "TODAS LAS PRUEBAS PASARON ... se deshizo todo".
--   - Si algo falla, el mensaje empieza con "FALLO" e indica qué caso.
-- Cada caso aprobado deja una línea NOTICE "OK ..." en la pestaña Messages.

DO $$
DECLARE
    v_suc       INTEGER;
    v_otra_suc  INTEGER;
    v_cajero    INTEGER;
    v_admin     INTEGER;
    v_empleado  INTEGER;
    v_otro      INTEGER;
    v_bebida    INTEGER;
    v_items     JSONB;
    v_id        INTEGER;
    v_almuerzos BIGINT;
    v_movs      BIGINT;
    v_stock     NUMERIC;
    v_estado    TEXT;
    v_mensaje   TEXT;
    v_casos     INTEGER := 0;
BEGIN
    -- Datos propios de la prueba ------------------------------------------------
    INSERT INTO sucursales (nombre) VALUES ('Almuerzo diario A') RETURNING id INTO v_suc;
    INSERT INTO sucursales (nombre) VALUES ('Almuerzo diario B') RETURNING id INTO v_otra_suc;
    INSERT INTO usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('Cajero diario', 'cajero.diario', 'x', 'cajero', v_suc) RETURNING id INTO v_cajero;
    INSERT INTO usuarios (nombre, identificador_acceso, password_hash, rol)
        VALUES ('Admin diario', 'admin.diario', 'x', 'admin') RETURNING id INTO v_admin;
    INSERT INTO usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('Empleada diaria', 'empleada.diaria', 'x', 'cajero', v_suc) RETURNING id INTO v_empleado;
    INSERT INTO usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('Otro empleado diario', 'otro.diario', 'x', 'cajero', v_suc) RETURNING id INTO v_otro;
    INSERT INTO productos (nombre, precio_venta) VALUES ('Bebida almuerzo diario', 1000) RETURNING id INTO v_bebida;
    INSERT INTO stock_producto_sucursal (producto_id, sucursal_id, stock_actual) VALUES (v_bebida, v_suc, 10);
    v_items := jsonb_build_array(jsonb_build_object('producto_id', v_bebida, 'cantidad', 1));

    PERFORM set_config('request.jwt.claims',
        json_build_object('role', 'nury_cajero', 'user_id', v_cajero)::text, TRUE);

    -- 1) Sin productos: se rechaza e informa el motivo ---------------------------------
    BEGIN
        PERFORM fn_registrar_almuerzo_empleado(v_suc, v_empleado, '[]'::jsonb);
        RAISE EXCEPTION 'FALLO 1: se aceptó un almuerzo sin productos';
    EXCEPTION
        WHEN invalid_parameter_value THEN
            GET STACKED DIAGNOSTICS v_mensaje = MESSAGE_TEXT;
            IF v_mensaje NOT LIKE '%al menos uno%' THEN
                RAISE EXCEPTION 'FALLO 1: el motivo no lo explica: %', v_mensaje;
            END IF;
    END;
    BEGIN
        PERFORM fn_registrar_almuerzo_empleado(v_suc, v_empleado, NULL);
        RAISE EXCEPTION 'FALLO 1: se aceptó un almuerzo con productos NULL';
    EXCEPTION
        WHEN invalid_parameter_value THEN NULL;
    END;
    v_casos := v_casos + 1;
    RAISE NOTICE 'OK 1. Sin productos se rechaza: "%"', v_mensaje;

    -- 2) El primer almuerzo del día se registra ---------------------------------------
    v_id := fn_registrar_almuerzo_empleado(v_suc, v_empleado, v_items);
    IF v_id IS NULL THEN
        RAISE EXCEPTION 'FALLO 2: no se registró el primer almuerzo del día';
    END IF;
    v_casos := v_casos + 1;
    RAISE NOTICE 'OK 2. Primer almuerzo del día registrado (id %)', v_id;

    -- 3) Un segundo almuerzo el mismo día se rechaza con el motivo ---------------------
    SELECT count(*) INTO v_almuerzos FROM almuerzos_empleado;
    SELECT count(*) INTO v_movs FROM movimientos_stock;
    SELECT stock_actual INTO v_stock FROM stock_producto_sucursal WHERE producto_id = v_bebida AND sucursal_id = v_suc;
    BEGIN
        PERFORM fn_registrar_almuerzo_empleado(v_suc, v_empleado, v_items);
        RAISE EXCEPTION 'FALLO 3: se aceptó un segundo almuerzo el mismo día';
    EXCEPTION
        WHEN unique_violation THEN
            GET STACKED DIAGNOSTICS v_estado = RETURNED_SQLSTATE, v_mensaje = MESSAGE_TEXT;
            IF v_mensaje NOT LIKE 'Empleada diaria ya registró su almuerzo hoy%'
               OR v_mensaje NOT LIKE '%Almuerzo diario A%'
               OR v_mensaje NOT LIKE '%Cajero diario%'
               OR v_mensaje NOT LIKE '%un almuerzo por día%' THEN
                RAISE EXCEPTION 'FALLO 3: el motivo no informa quién, dónde y cuándo: %', v_mensaje;
            END IF;
    END;
    IF (SELECT count(*) FROM almuerzos_empleado) <> v_almuerzos
        OR (SELECT count(*) FROM movimientos_stock) <> v_movs
        OR (SELECT stock_actual FROM stock_producto_sucursal WHERE producto_id = v_bebida AND sucursal_id = v_suc) <> v_stock THEN
        RAISE EXCEPTION 'FALLO 3: el rechazo dejó cambios (almuerzo o stock)';
    END IF;
    v_casos := v_casos + 1;
    RAISE NOTICE 'OK 3. Segundo almuerzo rechazado (SQLSTATE %) sin tocar stock: "%"', v_estado, v_mensaje;

    -- 4) Tampoco en otra sucursal ni registrado por otro usuario -----------------------
    PERFORM set_config('request.jwt.claims',
        json_build_object('role', 'nury_admin', 'user_id', v_admin)::text, TRUE);
    BEGIN
        PERFORM fn_registrar_almuerzo_empleado(v_otra_suc, v_empleado, v_items);
        RAISE EXCEPTION 'FALLO 4: el admin registró un segundo almuerzo en otra sucursal';
    EXCEPTION
        WHEN unique_violation THEN NULL;
    END;
    v_casos := v_casos + 1;
    RAISE NOTICE 'OK 4. El límite es por empleado: tampoco se puede en otra sucursal ni por otro usuario';

    -- 5) Otro empleado sí puede almorzar el mismo día ---------------------------------
    IF fn_registrar_almuerzo_empleado(v_suc, v_otro, v_items) IS NULL THEN
        RAISE EXCEPTION 'FALLO 5: no se registró el almuerzo de otro empleado';
    END IF;
    v_casos := v_casos + 1;
    RAISE NOTICE 'OK 5. Otro empleado registra su almuerzo el mismo día';

    -- 6) Al día siguiente el mismo empleado puede volver a almorzar --------------------
    UPDATE almuerzos_empleado SET fecha = fecha - 1 WHERE id = v_id;   -- el de "ayer"
    IF fn_registrar_almuerzo_empleado(v_suc, v_empleado, v_items) IS NULL THEN
        RAISE EXCEPTION 'FALLO 6: no se registró el almuerzo del día siguiente';
    END IF;
    v_casos := v_casos + 1;
    RAISE NOTICE 'OK 6. Un día distinto sí permite un nuevo almuerzo';

    -- 7) La base asegura la regla aunque se salte la función ---------------------------
    BEGIN
        INSERT INTO almuerzos_empleado (sucursal_id, empleado_id, cajero_id)
        VALUES (v_suc, v_empleado, v_cajero);
        RAISE EXCEPTION 'FALLO 7: el índice único no impidió el duplicado';
    EXCEPTION
        WHEN unique_violation THEN NULL;
    END;
    v_casos := v_casos + 1;
    RAISE NOTICE 'OK 7. El índice único impide dos almuerzos del mismo empleado el mismo día';

    RAISE EXCEPTION 'TODAS LAS PRUEBAS PASARON (% de 7). Se deshizo todo: no quedó ningún almuerzo ni movimiento guardado.',
        v_casos;
END;
$$;
