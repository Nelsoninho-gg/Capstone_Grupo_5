-- Base de pruebas con el esquema y las migraciones 0003,
-- 20261012_permisos_cajero y 20261012_recuperar_turno aplicadas.
\set ON_ERROR_STOP on
BEGIN;
CREATE TEMP TABLE casos_recuperacion (
    cajero INTEGER, otro INTEGER, turno INTEGER, turno_otro INTEGER,
    vigente INTEGER, anulada INTEGER
);
GRANT SELECT ON casos_recuperacion TO nury_cajero;
DO $$
DECLARE
    sucursal INTEGER;
    segunda INTEGER;
    cajero INTEGER;
    otro INTEGER;
    producto INTEGER;
    turno INTEGER;
    turno_otro INTEGER;
    anterior INTEGER;
    ajeno INTEGER;
    vigente INTEGER;
    anulada INTEGER;
BEGIN
    INSERT INTO public.sucursales (nombre) VALUES ('Prueba recuperar turno') RETURNING id INTO sucursal;
    INSERT INTO public.sucursales (nombre) VALUES ('Prueba recuperar otra sucursal') RETURNING id INTO segunda;
    INSERT INTO public.usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
    VALUES ('Cajero', 'prueba-recuperar-cajero', 'test', 'cajero', sucursal) RETURNING id INTO cajero;
    INSERT INTO public.usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
    VALUES ('Otro', 'prueba-recuperar-otro', 'test', 'cajero', sucursal) RETURNING id INTO otro;
    INSERT INTO public.productos (nombre, precio_venta) VALUES ('Prueba recuperar producto', 1500) RETURNING id INTO producto;
    INSERT INTO public.turnos (usuario_id, sucursal_id, hora_inicio, monto_inicial)
    VALUES (cajero, sucursal, '2026-10-11T12:00:00', 5000) RETURNING id INTO turno;
    INSERT INTO public.turnos (usuario_id, sucursal_id, hora_inicio, monto_inicial)
    VALUES (otro, sucursal, '2026-10-12T12:00:00', 0) RETURNING id INTO turno_otro;
    INSERT INTO public.turnos (usuario_id, sucursal_id, hora_inicio, hora_fin, monto_inicial)
    VALUES (cajero, sucursal, '2026-10-10T12:00:00', '2026-10-10T20:00:00', 0) RETURNING id INTO anterior;
    INSERT INTO public.turnos (usuario_id, sucursal_id, hora_inicio, monto_inicial)
    VALUES (cajero, segunda, '2026-10-12T12:00:00', 0) RETURNING id INTO ajeno;
    INSERT INTO public.ventas (sucursal_id, cajero_id, turno_id, medio_pago)
    VALUES (sucursal, cajero, turno, 'efectivo') RETURNING id INTO vigente;
    INSERT INTO public.ventas (sucursal_id, cajero_id, turno_id, medio_pago, anulada, anulada_motivo)
    VALUES (sucursal, cajero, turno, 'credito', TRUE, 'Error al cobrar') RETURNING id INTO anulada;
    INSERT INTO public.detalle_venta (venta_id, producto_id, cantidad, precio_lista, precio_unitario)
    VALUES (vigente, producto, 2, 1500, 1000);
    INSERT INTO public.ventas (sucursal_id, cajero_id, turno_id, medio_pago)
    VALUES (sucursal, cajero, anterior, 'efectivo'), (segunda, cajero, ajeno, 'efectivo'),
           (sucursal, otro, turno_otro, 'efectivo'), (sucursal, otro, turno, 'efectivo');
    INSERT INTO casos_recuperacion VALUES (cajero, otro, turno, turno_otro, vigente, anulada);
END;
$$;

SELECT set_config('request.jwt.claims', json_build_object('role', 'nury_cajero', 'user_id', cajero)::text, TRUE)
FROM casos_recuperacion;
SET LOCAL ROLE nury_cajero;
DO $$
DECLARE
    caso casos_recuperacion%ROWTYPE;
    recuperado JSONB;
    venta JSONB;
BEGIN
    SELECT * INTO caso FROM casos_recuperacion;
    recuperado := public.fn_recuperar_turno();
    IF (recuperado->'turno'->>'id')::integer <> caso.turno
        OR (recuperado->'turno'->>'monto_inicial')::numeric <> 5000
        OR recuperado->'turno'->>'hora_inicio' <> '2026-10-11T12:00:00'
        OR jsonb_array_length(recuperado->'ventas') <> 2 THEN
        RAISE EXCEPTION 'No recupera el turno original o incluye ventas ajenas/históricas';
    END IF;
    SELECT v INTO venta FROM jsonb_array_elements(recuperado->'ventas') v
     WHERE (v->>'id')::integer = caso.vigente;
    IF (venta->>'total')::numeric <> 2000
        OR (venta->'detalle_venta'->0->>'precio_unitario')::numeric <> 1000
        OR venta->'detalle_venta'->0->'productos'->>'nombre' <> 'Prueba recuperar producto' THEN
        RAISE EXCEPTION 'No recupera los totales ni el detalle de los productos vendidos';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM jsonb_array_elements(recuperado->'ventas') v
        WHERE (v->>'id')::integer = caso.anulada AND (v->>'anulada')::boolean
          AND v->>'anulada_motivo' = 'Error al cobrar') THEN
        RAISE EXCEPTION 'No recupera las anulaciones';
    END IF;
    PERFORM public.fn_recuperar_turno();
    IF (public.fn_recuperar_turno()->'turno'->>'id')::integer <> caso.turno THEN
        RAISE EXCEPTION 'Consultar varias veces cambia el turno';
    END IF;
END;
$$;

SELECT set_config('request.jwt.claims', json_build_object('role', 'nury_cajero', 'user_id', otro)::text, TRUE)
FROM casos_recuperacion;
DO $$
DECLARE
    recuperado JSONB := public.fn_recuperar_turno();
BEGIN
    IF (recuperado->'turno'->>'id')::integer <> (SELECT turno_otro FROM casos_recuperacion)
       OR jsonb_array_length(recuperado->'ventas') <> 1 THEN
        RAISE EXCEPTION 'Un cajero hereda el turno de otro';
    END IF;
END;
$$;
RESET ROLE;

UPDATE public.turnos SET hora_fin = now() WHERE id = (SELECT turno FROM casos_recuperacion);
SELECT set_config('request.jwt.claims', json_build_object('role', 'nury_cajero', 'user_id', cajero)::text, TRUE)
FROM casos_recuperacion;
SET LOCAL ROLE nury_cajero;
DO $$
BEGIN
    IF public.fn_recuperar_turno() <> '{"turno": null, "ventas": []}'::jsonb THEN
        RAISE EXCEPTION 'Se recupera un turno ya cerrado o de otra sucursal';
    END IF;
END;
$$;
SELECT set_config('request.jwt.claims', '{"role":"nury_cajero"}', TRUE);
DO $$
BEGIN
    BEGIN
        PERFORM public.fn_recuperar_turno();
        RAISE EXCEPTION 'Se recupera un turno sin identidad JWT';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
END;
$$;
RESET ROLE;
DO $$
DECLARE
    rol TEXT;
BEGIN
    FOREACH rol IN ARRAY ARRAY['web_anon', 'nury_bodeguero'] LOOP
        IF has_function_privilege(rol, 'public.fn_recuperar_turno()', 'EXECUTE') THEN
            RAISE EXCEPTION '% puede recuperar turnos', rol;
        END IF;
    END LOOP;
    IF (SELECT count(*) FROM public.turnos) <> 4 THEN
        RAISE EXCEPTION 'Recuperar creó o eliminó un turno';
    END IF;
END;
$$;
ROLLBACK;
\echo 'PASS: recuperación, ventas completas, anulaciones, sucursal, identidad y turnos cerrados.'
