-- Prueba de integración sobre una base de pruebas con el esquema, los
-- roles JWT y 20260930_sucursales_api.sql aplicados. Las filas se revierten.
\set ON_ERROR_STOP on
BEGIN;

DO $$
DECLARE
    test_role TEXT;
    test_column TEXT;
BEGIN
    FOREACH test_role IN ARRAY ARRAY['web_anon', 'nury_cajero', 'nury_bodeguero'] LOOP
        IF has_function_privilege(test_role,
            'public.crear_sucursal(character varying, character varying, character varying, boolean)',
            'EXECUTE') THEN
            RAISE EXCEPTION '% puede ejecutar el alta de sucursales', test_role;
        END IF;
        FOREACH test_column IN ARRAY ARRAY['nombre', 'direccion', 'telefono', 'activo'] LOOP
            IF has_column_privilege(test_role, 'public.sucursales', test_column, 'INSERT')
                OR has_column_privilege(test_role, 'public.sucursales', test_column, 'UPDATE') THEN
                RAISE EXCEPTION '% puede modificar sucursales', test_role;
            END IF;
        END LOOP;
    END LOOP;
END;
$$;

SET LOCAL ROLE nury_admin;

DO $$
DECLARE
    created public.sucursales%ROWTYPE;
    updated public.sucursales%ROWTYPE;
BEGIN
    SELECT * INTO created FROM public.crear_sucursal(
        '  Prueba API sucursales  ', '  Avenida de prueba 123  ', '  ', TRUE
    );
    IF created.nombre <> 'Prueba API sucursales'
        OR created.direccion <> 'Avenida de prueba 123'
        OR created.telefono IS NOT NULL OR NOT created.activo
        OR created.id IS NULL OR created.creado_en IS NULL THEN
        RAISE EXCEPTION 'El alta no devuelve los campos normalizados';
    END IF;

    UPDATE public.sucursales
       SET nombre = '  Prueba API editada  ', direccion = ' ',
           telefono = '  +56 9 1234 5678  ', activo = FALSE
     WHERE id = created.id
     RETURNING * INTO updated;
    IF updated.nombre <> 'Prueba API editada' OR updated.direccion IS NOT NULL
        OR updated.telefono <> '+56 9 1234 5678' OR updated.activo
        OR updated.id <> created.id OR updated.creado_en <> created.creado_en THEN
        RAISE EXCEPTION 'La edición modifica campos ajenos o no normaliza los datos';
    END IF;

    BEGIN
        PERFORM public.crear_sucursal('  Prueba API editada  ');
        RAISE EXCEPTION 'Se permitió un nombre duplicado';
    EXCEPTION WHEN unique_violation THEN NULL;
    END;
    BEGIN
        PERFORM public.crear_sucursal('   ');
        RAISE EXCEPTION 'Se permitió un nombre vacío';
    EXCEPTION WHEN check_violation THEN NULL;
    END;
    BEGIN
        PERFORM public.crear_sucursal(NULL);
        RAISE EXCEPTION 'Se permitió un nombre nulo';
    EXCEPTION WHEN not_null_violation THEN NULL;
    END;
    BEGIN
        UPDATE public.sucursales SET nombre = ' ' WHERE id = created.id;
        RAISE EXCEPTION 'Se permitió vaciar el nombre al editar';
    EXCEPTION WHEN check_violation THEN NULL;
    END;
    BEGIN
        PERFORM public.crear_sucursal(repeat('x', 121));
        RAISE EXCEPTION 'Se permitió un nombre de más de 120 caracteres';
    EXCEPTION WHEN string_data_right_truncation THEN NULL;
    END;
    BEGIN
        UPDATE public.sucursales SET direccion = repeat('x', 201) WHERE id = created.id;
        RAISE EXCEPTION 'Se permitió una dirección de más de 200 caracteres';
    EXCEPTION WHEN string_data_right_truncation THEN NULL;
    END;
    BEGIN
        UPDATE public.sucursales SET telefono = repeat('x', 31) WHERE id = created.id;
        RAISE EXCEPTION 'Se permitió un teléfono de más de 30 caracteres';
    EXCEPTION WHEN string_data_right_truncation THEN NULL;
    END;
    BEGIN
        UPDATE public.sucursales SET activo = NULL WHERE id = created.id;
        RAISE EXCEPTION 'Se permitió un estado nulo';
    EXCEPTION WHEN not_null_violation THEN NULL;
    END;
    BEGIN
        UPDATE public.sucursales SET id = id + 100 WHERE id = created.id;
        RAISE EXCEPTION 'Se permitió cambiar el ID de una sucursal';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
    BEGIN
        UPDATE public.sucursales SET creado_en = now() WHERE id = created.id;
        RAISE EXCEPTION 'Se permitió cambiar la fecha de creación';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;

    IF NOT EXISTS (SELECT 1 FROM public.sucursales WHERE id = created.id AND NOT activo) THEN
        RAISE EXCEPTION 'El listado no incluye sucursales inactivas';
    END IF;
    IF EXISTS (SELECT 1 FROM public.sucursales WHERE id = created.id AND activo) THEN
        RAISE EXCEPTION 'El filtro de sucursales activas incluye una inactiva';
    END IF;
END;
$$;

ROLLBACK;
\echo 'PASS: alta, edición, listado, validaciones y permisos de sucursales.'
