-- H2.5 T04 - Ingredientes con stock insuficiente devueltos al POS.
-- Ejecutar con el propietario en una base de pruebas con el esquema, los roles
-- JWT y las migraciones hasta 20261017_stock_insuficiente_venta.sql.
-- Todo se revierte al terminar.
\set ON_ERROR_STOP on
BEGIN;

CREATE TEMP TABLE caso_h25 (
    suc INTEGER, cajero INTEGER, otro_cajero INTEGER, admin INTEGER,
    pan INTEGER, queso INTEGER, palta INTEGER, bebida INTEGER,
    venta INTEGER, venta_ok INTEGER
);
GRANT SELECT ON caso_h25 TO nury_cajero, nury_admin;

DO $$
DECLARE
    c caso_h25%ROWTYPE;
    un INTEGER; sandwich INTEGER; tostada INTEGER; palta_p INTEGER;
BEGIN
    INSERT INTO sucursales (nombre) VALUES ('H25 sucursal') RETURNING id INTO c.suc;
    INSERT INTO usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('H25 cajero', 'h25-cajero', 'x', 'cajero', c.suc) RETURNING id INTO c.cajero;
    INSERT INTO usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('H25 cajero 2', 'h25-cajero-2', 'x', 'cajero', c.suc) RETURNING id INTO c.otro_cajero;
    INSERT INTO usuarios (nombre, identificador_acceso, password_hash, rol)
        VALUES ('H25 admin', 'h25-admin', 'x', 'admin') RETURNING id INTO c.admin;
    INSERT INTO unidades_medida (nombre, abreviatura) VALUES ('H25 gramo', 'g25') RETURNING id INTO un;
    INSERT INTO ingredientes (nombre, unidad_id) VALUES ('H25 Pan', un) RETURNING id INTO c.pan;
    INSERT INTO ingredientes (nombre, unidad_id) VALUES ('H25 Queso', un) RETURNING id INTO c.queso;
    INSERT INTO ingredientes (nombre, unidad_id) VALUES ('H25 Palta', un) RETURNING id INTO c.palta;
    INSERT INTO productos (nombre, precio_venta) VALUES ('H25 Sandwich', 3000) RETURNING id INTO sandwich;
    INSERT INTO productos (nombre, precio_venta) VALUES ('H25 Tostada', 2000) RETURNING id INTO tostada;
    INSERT INTO productos (nombre, precio_venta) VALUES ('H25 Palta extra', 800) RETURNING id INTO palta_p;
    INSERT INTO productos (nombre, precio_venta) VALUES ('H25 Bebida', 1000) RETURNING id INTO c.bebida;
    -- Pan y queso los comparten sándwich y tostada.
    INSERT INTO recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id) VALUES
        (sandwich, c.pan, 2, un), (sandwich, c.queso, 30, un),
        (tostada, c.pan, 1, un), (tostada, c.queso, 15, un),
        (palta_p, c.palta, 50, un);
    -- Pan: alcanza justo (3×2 + 2×1 = 8 de 8). Queso: hay 100 y se necesitan 120.
    -- Palta: no tiene fila de stock (parte en 0). Bebida (reventa): hay 1 y se venden 3.
    INSERT INTO stock_sucursal (ingrediente_id, sucursal_id, stock_actual) VALUES
        (c.pan, c.suc, 8), (c.queso, c.suc, 100);
    INSERT INTO stock_producto_sucursal (producto_id, sucursal_id, stock_actual) VALUES (c.bebida, c.suc, 1);

    INSERT INTO ventas (sucursal_id, cajero_id) VALUES (c.suc, c.cajero) RETURNING id INTO c.venta;
    INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_lista, precio_unitario) VALUES
        (c.venta, sandwich, 3, 3000, 3000), (c.venta, tostada, 2, 2000, 2000),
        (c.venta, palta_p, 1, 800, 800), (c.venta, c.bebida, 3, 1000, 1000);

    -- Venta con stock suficiente.
    INSERT INTO ventas (sucursal_id, cajero_id) VALUES (c.suc, c.cajero) RETURNING id INTO c.venta_ok;
    INSERT INTO stock_producto_sucursal (producto_id, sucursal_id, stock_actual)
        VALUES (tostada, c.suc, 0) ON CONFLICT DO NOTHING;
    UPDATE stock_sucursal SET stock_actual = 100 WHERE ingrediente_id = c.pan;
    UPDATE stock_sucursal SET stock_actual = 1000 WHERE ingrediente_id = c.queso;
    INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_lista, precio_unitario)
        VALUES (c.venta_ok, tostada, 1, 2000, 2000);

    INSERT INTO caso_h25 SELECT c.*;
END;
$$;

-- El cajero dueño de la venta consulta por la API (rol nury_cajero).
SELECT set_config('request.jwt.claims', json_build_object('role', 'nury_cajero', 'sub', cajero)::text, TRUE)
  FROM caso_h25;
SET LOCAL ROLE nury_cajero;

DO $$
DECLARE
    c caso_h25%ROWTYPE;
    r RECORD;
    n INTEGER;
BEGIN
    SELECT * INTO c FROM caso_h25;

    SELECT count(*) INTO n FROM public.fn_stock_insuficiente_venta(c.venta);
    IF n <> 3 THEN RAISE EXCEPTION 'Se esperaban 3 ítems sin stock suficiente (queso, palta, bebida), hay %', n; END IF;

    -- Queso compartido: 3×30 + 2×15 = 120 requeridos, había 100, faltan 20, queda -20.
    SELECT * INTO r FROM public.fn_stock_insuficiente_venta(c.venta) WHERE item_id = c.queso AND tipo = 'ingrediente';
    IF r.requerido <> 120 OR r.disponible <> 100 OR r.faltante <> 20 OR r.stock_actual <> -20
       OR r.unidad <> 'g25' OR r.sucursal_id <> c.suc OR r.nombre <> 'H25 Queso' THEN
        RAISE EXCEPTION 'Queso incorrecto: %', r;
    END IF;

    -- Palta sin fila de stock previa: había 0, faltan los 50.
    SELECT * INTO r FROM public.fn_stock_insuficiente_venta(c.venta) WHERE item_id = c.palta AND tipo = 'ingrediente';
    IF r.requerido <> 50 OR r.disponible <> 0 OR r.faltante <> 50 THEN
        RAISE EXCEPTION 'Palta incorrecta: %', r;
    END IF;

    -- Producto de reventa: había 1, se vendieron 3, faltan 2.
    SELECT * INTO r FROM public.fn_stock_insuficiente_venta(c.venta) WHERE item_id = c.bebida AND tipo = 'producto';
    IF r.requerido <> 3 OR r.disponible <> 1 OR r.faltante <> 2 OR r.unidad <> 'unid.' THEN
        RAISE EXCEPTION 'Bebida incorrecta: %', r;
    END IF;

    -- El pan alcanzó justo (8 de 8, queda en 0): no se informa.
    IF EXISTS (SELECT 1 FROM public.fn_stock_insuficiente_venta(c.venta) WHERE item_id = c.pan AND tipo = 'ingrediente') THEN
        RAISE EXCEPTION 'El pan alcanzó y no debía informarse';
    END IF;

    -- Venta con stock suficiente: lista vacía.
    SELECT count(*) INTO n FROM public.fn_stock_insuficiente_venta(c.venta_ok);
    IF n <> 0 THEN RAISE EXCEPTION 'La venta con stock suficiente devolvió % ítems', n; END IF;

    -- Venta inexistente.
    BEGIN
        PERFORM public.fn_stock_insuficiente_venta(-1);
        RAISE EXCEPTION 'Aceptó una venta inexistente';
    EXCEPTION WHEN SQLSTATE '22023' THEN NULL;
    END;
END;
$$;

-- Otro cajero no puede consultar una venta ajena.
SELECT set_config('request.jwt.claims', json_build_object('role', 'nury_cajero', 'sub', otro_cajero)::text, TRUE)
  FROM caso_h25;
DO $$
DECLARE v INTEGER;
BEGIN
    SELECT venta INTO v FROM caso_h25;
    BEGIN
        PERFORM public.fn_stock_insuficiente_venta(v);
        RAISE EXCEPTION 'Un cajero pudo consultar una venta ajena';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
END;
$$;
RESET ROLE;

-- El admin sí puede.
SELECT set_config('request.jwt.claims', json_build_object('role', 'nury_admin', 'sub', admin)::text, TRUE)
  FROM caso_h25;
SET LOCAL ROLE nury_admin;
DO $$
DECLARE v INTEGER; n INTEGER;
BEGIN
    SELECT venta INTO v FROM caso_h25;
    SELECT count(*) INTO n FROM public.fn_stock_insuficiente_venta(v);
    IF n <> 3 THEN RAISE EXCEPTION 'El admin obtuvo % ítems', n; END IF;
END;
$$;
RESET ROLE;

-- Bodeguero y anónimo no tienen acceso.
DO $$
BEGIN
    IF has_function_privilege('nury_bodeguero', 'public.fn_stock_insuficiente_venta(integer)', 'EXECUTE')
    OR has_function_privilege('web_anon', 'public.fn_stock_insuficiente_venta(integer)', 'EXECUTE') THEN
        RAISE EXCEPTION 'Bodeguero o anónimo pueden ejecutar fn_stock_insuficiente_venta';
    END IF;
END;
$$;

\echo 'PASS: consumo compartido sumado, faltantes por ingrediente y reventa, venta suficiente vacía y permisos.'
ROLLBACK;
