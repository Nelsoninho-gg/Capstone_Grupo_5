-- H2.13 T02 — Pruebas del modelo de almuerzos de empleados.
--
-- Requiere la migración 20261022_almuerzos_empleado.sql aplicada.
--
-- Todo corre dentro de un único bloque que termina con un error a propósito,
-- así PostgreSQL deshace los almuerzos de la prueba: no queda nada guardado.
--
-- Resultado:
--   - Si todo está bien, el último mensaje es
--     "TODAS LAS PRUEBAS PASARON ... se deshizo todo".
--   - Si algo falla, el mensaje empieza con "FALLO" e indica qué caso.
-- Cada caso aprobado deja una línea NOTICE "OK ..." en la pestaña Messages.

DO $$
DECLARE
    v_sucursal    INTEGER;
    v_empleado    INTEGER;
    v_cajero      INTEGER;
    p1            INTEGER;
    p2            INTEGER;
    a             RECORD;
    v_id          INTEGER;
    v_ventas      BIGINT;
    v_detalles    BIGINT;
    v_movs        BIGINT;
    v_casos       INTEGER := 0;
BEGIN
    -- Datos de prueba ---------------------------------------------------------
    SELECT id INTO v_sucursal FROM sucursales ORDER BY id LIMIT 1;
    SELECT id INTO v_empleado FROM usuarios WHERE activo ORDER BY id LIMIT 1;
    SELECT id INTO v_cajero FROM usuarios WHERE activo ORDER BY id DESC LIMIT 1;
    SELECT id INTO p1 FROM productos WHERE activo ORDER BY id LIMIT 1;
    SELECT id INTO p2 FROM productos WHERE activo ORDER BY id OFFSET 1 LIMIT 1;
    IF v_sucursal IS NULL OR v_empleado IS NULL OR p1 IS NULL OR p2 IS NULL THEN
        RAISE EXCEPTION 'FALLO: faltan datos de prueba (una sucursal, un usuario activo y dos productos activos)';
    END IF;

    SELECT count(*) INTO v_ventas FROM ventas;
    SELECT count(*) INTO v_detalles FROM detalle_venta;
    SELECT count(*) INTO v_movs FROM movimientos_stock;

    -- 1) Se guarda con empleado, cajero, fecha y sucursal -----------------------
    INSERT INTO almuerzos_empleado (sucursal_id, empleado_id, cajero_id)
    VALUES (v_sucursal, v_empleado, v_cajero)
    RETURNING id INTO v_id;
    SELECT * INTO a FROM almuerzos_empleado WHERE id = v_id;
    IF a.sucursal_id <> v_sucursal OR a.empleado_id <> v_empleado OR a.cajero_id <> v_cajero
        OR a.creado_en IS NULL THEN
        RAISE EXCEPTION 'FALLO 1: la cabecera no guardó sucursal, empleado, cajero o creado_en';
    END IF;
    v_casos := v_casos + 1;
    RAISE NOTICE 'OK 1. Cabecera con sucursal, empleado, cajero y fecha de creación';

    -- 2) La fecha por defecto es el día en Chile --------------------------------
    IF a.fecha <> (now() AT TIME ZONE 'America/Santiago')::date THEN
        RAISE EXCEPTION 'FALLO 2: fecha = %, se esperaba el día de hoy en Chile', a.fecha;
    END IF;
    v_casos := v_casos + 1;
    RAISE NOTICE 'OK 2. Fecha por defecto = hoy en hora de Chile (%)', a.fecha;

    -- 3) Productos y cantidades --------------------------------------------------
    INSERT INTO almuerzos_empleado_detalle (almuerzo_id, producto_id, cantidad)
    VALUES (v_id, p1, 1), (v_id, p2, 2);
    IF (SELECT count(*) FROM almuerzos_empleado_detalle WHERE almuerzo_id = v_id) <> 2
        OR (SELECT cantidad FROM almuerzos_empleado_detalle WHERE almuerzo_id = v_id AND producto_id = p2) <> 2 THEN
        RAISE EXCEPTION 'FALLO 3: el detalle no guardó los productos o sus cantidades';
    END IF;
    v_casos := v_casos + 1;
    RAISE NOTICE 'OK 3. Detalle con productos y cantidades';

    -- 4) Cantidad cero o negativa se rechaza -------------------------------------
    BEGIN
        INSERT INTO almuerzos_empleado_detalle (almuerzo_id, producto_id, cantidad)
        VALUES (v_id, (SELECT id FROM productos WHERE id NOT IN (p1, p2) ORDER BY id LIMIT 1), 0);
        RAISE EXCEPTION 'FALLO 4: se aceptó una cantidad 0';
    EXCEPTION
        WHEN check_violation OR not_null_violation THEN NULL;
    END;
    v_casos := v_casos + 1;
    RAISE NOTICE 'OK 4. Cantidad 0 rechazada';

    -- 5) El mismo producto no se repite en un almuerzo ---------------------------
    BEGIN
        INSERT INTO almuerzos_empleado_detalle (almuerzo_id, producto_id, cantidad)
        VALUES (v_id, p1, 1);
        RAISE EXCEPTION 'FALLO 5: se aceptó el mismo producto dos veces';
    EXCEPTION
        WHEN unique_violation THEN NULL;
    END;
    v_casos := v_casos + 1;
    RAISE NOTICE 'OK 5. Producto repetido en el mismo almuerzo rechazado';

    -- 6) Empleado, cajero y sucursal son obligatorios ----------------------------
    BEGIN
        INSERT INTO almuerzos_empleado (sucursal_id, empleado_id, cajero_id)
        VALUES (v_sucursal, NULL, v_cajero);
        RAISE EXCEPTION 'FALLO 6: se aceptó un almuerzo sin empleado';
    EXCEPTION
        WHEN not_null_violation THEN NULL;
    END;
    BEGIN
        INSERT INTO almuerzos_empleado (sucursal_id, empleado_id, cajero_id)
        VALUES (NULL, v_empleado, v_cajero);
        RAISE EXCEPTION 'FALLO 6: se aceptó un almuerzo sin sucursal';
    EXCEPTION
        WHEN not_null_violation THEN NULL;
    END;
    BEGIN
        INSERT INTO almuerzos_empleado (sucursal_id, empleado_id, cajero_id)
        VALUES (v_sucursal, v_empleado, NULL);
        RAISE EXCEPTION 'FALLO 6: se aceptó un almuerzo sin cajero';
    EXCEPTION
        WHEN not_null_violation THEN NULL;
    END;
    v_casos := v_casos + 1;
    RAISE NOTICE 'OK 6. Empleado, sucursal y cajero obligatorios';

    -- 7) Separado de las ventas y sin tocar stock --------------------------------
    IF (SELECT count(*) FROM ventas) <> v_ventas
        OR (SELECT count(*) FROM detalle_venta) <> v_detalles
        OR (SELECT count(*) FROM movimientos_stock) <> v_movs THEN
        RAISE EXCEPTION 'FALLO 7: registrar el almuerzo creó ventas o movimientos de stock';
    END IF;
    IF EXISTS (
        SELECT 1 FROM information_schema.columns
         WHERE table_schema = 'public' AND table_name = 'almuerzos_empleado'
           AND column_name IN ('medio_pago', 'total')
    ) THEN
        RAISE EXCEPTION 'FALLO 7: el almuerzo tiene medio de pago o total';
    END IF;
    v_casos := v_casos + 1;
    RAISE NOTICE 'OK 7. No crea ventas ni movimientos de stock y no tiene medio de pago ni total';

    -- 8) Borrar la cabecera borra su detalle ------------------------------------
    DELETE FROM almuerzos_empleado WHERE id = v_id;
    IF EXISTS (SELECT 1 FROM almuerzos_empleado_detalle WHERE almuerzo_id = v_id) THEN
        RAISE EXCEPTION 'FALLO 8: quedó detalle sin cabecera';
    END IF;
    v_casos := v_casos + 1;
    RAISE NOTICE 'OK 8. El detalle se borra con su almuerzo';

    -- 9) Permisos: nadie escribe directo; admin y cajero leen --------------------
    IF has_table_privilege('nury_cajero', 'public.almuerzos_empleado', 'INSERT')
        OR has_table_privilege('nury_cajero', 'public.almuerzos_empleado_detalle', 'INSERT')
        OR has_table_privilege('nury_cajero', 'public.almuerzos_empleado', 'UPDATE')
        OR has_table_privilege('nury_cajero', 'public.almuerzos_empleado', 'DELETE')
        OR has_table_privilege('web_anon', 'public.almuerzos_empleado', 'SELECT')
        OR has_table_privilege('nury_bodeguero', 'public.almuerzos_empleado', 'SELECT')
        OR NOT has_table_privilege('nury_admin', 'public.almuerzos_empleado', 'SELECT')
        OR NOT has_table_privilege('nury_cajero', 'public.almuerzos_empleado', 'SELECT')
        OR NOT has_table_privilege('nury_cajero', 'public.almuerzos_empleado_detalle', 'SELECT') THEN
        RAISE EXCEPTION 'FALLO 9: permisos incorrectos en las tablas de almuerzos';
    END IF;
    IF NOT has_table_privilege('nury_cajero', 'public.sucursales', 'SELECT')
        OR NOT has_column_privilege('nury_cajero', 'public.recetas', 'producto_id', 'SELECT') THEN
        RAISE EXCEPTION 'FALLO 9: el cajero no puede leer sucursales o recetas.producto_id';
    END IF;
    v_casos := v_casos + 1;
    RAISE NOTICE 'OK 9. Permisos: admin y cajero leen; nadie escribe directo; sin sesión no ve nada';

    RAISE EXCEPTION 'TODAS LAS PRUEBAS PASARON (% de 9). Se deshizo todo: no quedó ningún almuerzo guardado.',
        v_casos;
END;
$$;
