-- Prueba de tipo de dato timestamptz en movimientos_stock.
\set ON_ERROR_STOP on
BEGIN;

DO $$
DECLARE
    v_tipo TEXT;
BEGIN
    SELECT data_type INTO v_tipo
      FROM information_schema.columns
     WHERE table_schema = 'public'
       AND table_name = 'movimientos_stock'
       AND column_name = 'creado_en';

    IF v_tipo <> 'timestamp with time zone' THEN
        RAISE EXCEPTION 'movimientos_stock.creado_en debe ser timestamp with time zone, pero es %', v_tipo;
    END IF;

    RAISE NOTICE 'movimientos_timestamptz: OK';
END $$;

ROLLBACK;
