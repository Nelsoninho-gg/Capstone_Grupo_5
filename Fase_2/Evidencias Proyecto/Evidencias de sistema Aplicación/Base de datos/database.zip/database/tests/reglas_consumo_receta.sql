-- H2.5 T01 - Reglas de cálculo del consumo por receta (docs/reglas-descuento-inventario.md).
-- Base de pruebas con el esquema y las migraciones hasta 20261027_receta_unidad_base.sql.
-- Todo se revierte al terminar.
\set ON_ERROR_STOP on
BEGIN;
DO $$
DECLARE
    suc INTEGER; cajero INTEGER; kg INTEGER; g INTEGER; un INTEGER;
    harina INTEGER; queso INTEGER; pan INTEGER; empanada INTEGER; bebida INTEGER;
    venta INTEGER; r_id INTEGER; n NUMERIC;
BEGIN
    INSERT INTO sucursales (nombre) VALUES ('RC sucursal') RETURNING id INTO suc;
    INSERT INTO usuarios (nombre, identificador_acceso, password_hash, rol, sucursal_id)
        VALUES ('RC cajero', 'rc-cajero', 'x', 'cajero', suc) RETURNING id INTO cajero;
    INSERT INTO unidades_medida (nombre, abreviatura) VALUES ('RC Kilo', 'rkg') RETURNING id INTO kg;
    INSERT INTO unidades_medida (nombre, abreviatura) VALUES ('RC Gramo', 'rg') RETURNING id INTO g;
    INSERT INTO ingredientes (nombre, unidad_id) VALUES ('RC Harina', kg) RETURNING id INTO harina;
    INSERT INTO ingredientes (nombre, unidad_id) VALUES ('RC Queso', g) RETURNING id INTO queso;
    INSERT INTO productos (nombre, precio_venta) VALUES ('RC Pan', 500) RETURNING id INTO pan;
    INSERT INTO productos (nombre, precio_venta) VALUES ('RC Empanada', 1500) RETURNING id INTO empanada;
    INSERT INTO productos (nombre, precio_venta) VALUES ('RC Bebida', 1000) RETURNING id INTO bebida;

    -- Regla 2: la receta usa la unidad base del ingrediente ----------------------------
    -- a) sin unidad: se completa con la del ingrediente.
    INSERT INTO recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id)
    VALUES (pan, harina, 0.250, NULL) RETURNING unidad_id INTO r_id;
    IF r_id <> kg THEN RAISE EXCEPTION 'Regla 2a: no completó la unidad base'; END IF;
    -- b) con otra unidad: se rechaza.
    BEGIN
        INSERT INTO recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id)
        VALUES (empanada, harina, 100, g);
        RAISE EXCEPTION 'Regla 2b: aceptó gramos para un ingrediente en kilos';
    EXCEPTION WHEN invalid_parameter_value THEN NULL;
    END;
    -- c) cambiar la unidad de una receta existente también se rechaza.
    BEGIN
        UPDATE recetas SET unidad_id = g WHERE producto_id = pan AND ingrediente_id = harina;
        RAISE EXCEPTION 'Regla 2c: permitió cambiar la unidad de la receta';
    EXCEPTION WHEN invalid_parameter_value THEN NULL;
    END;
    -- d) con la unidad correcta funciona (es lo que envía la pantalla).
    INSERT INTO recetas (producto_id, ingrediente_id, cantidad_necesaria, unidad_id) VALUES
        (empanada, harina, 0.100, kg), (empanada, queso, 40, g);
    -- e) editar solo la cantidad sigue permitido.
    UPDATE recetas SET cantidad_necesaria = 0.300 WHERE producto_id = pan AND ingrediente_id = harina;

    -- Reglas 1, 3 y 4 al vender ---------------------------------------------------------
    INSERT INTO stock_sucursal (ingrediente_id, sucursal_id, stock_actual) VALUES (harina, suc, 1), (queso, suc, 100);
    INSERT INTO stock_producto_sucursal (producto_id, sucursal_id, stock_actual) VALUES (bebida, suc, 1);
    INSERT INTO ventas (sucursal_id, cajero_id) VALUES (suc, cajero) RETURNING id INTO venta;
    INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_lista, precio_unitario) VALUES
        (venta, pan, 2, 500, 500), (venta, empanada, 3, 1500, 1500), (venta, bebida, 2, 1000, 1000);

    -- Regla 1: harina = 2×0,300 + 3×0,100 = 0,900 kg (compartida); queso = 3×40 = 120 g.
    SELECT -sum(cantidad) INTO n FROM movimientos_stock
     WHERE referencia_tipo = 'venta' AND referencia_id = venta AND ingrediente_id = harina;
    IF n <> 0.900 THEN RAISE EXCEPTION 'Regla 1: harina descontada % kg, se esperaban 0,900', n; END IF;
    -- Regla 4: el queso queda negativo (100 − 120) sin bloquear la venta.
    SELECT stock_actual INTO n FROM stock_sucursal WHERE ingrediente_id = queso AND sucursal_id = suc;
    IF n <> -20 THEN RAISE EXCEPTION 'Regla 4: queso quedó en %, se esperaba −20', n; END IF;
    SELECT stock_actual INTO n FROM stock_sucursal WHERE ingrediente_id = harina AND sucursal_id = suc;
    IF n <> 0.100 THEN RAISE EXCEPTION 'Regla 1: harina quedó en %, se esperaba 0,100', n; END IF;
    -- Regla 3: la bebida sin receta descuenta 2 unidades de su propio stock (1 − 2 = −1).
    SELECT stock_actual INTO n FROM stock_producto_sucursal WHERE producto_id = bebida AND sucursal_id = suc;
    IF n <> -1 THEN RAISE EXCEPTION 'Regla 3: la bebida quedó en %, se esperaba −1', n; END IF;
    IF EXISTS (SELECT 1 FROM movimientos_stock WHERE referencia_id = venta AND referencia_tipo = 'venta'
                AND producto_id IS NOT NULL AND producto_id <> bebida) THEN
        RAISE EXCEPTION 'Regla 3: un producto con receta descontó stock propio';
    END IF;

    RAISE NOTICE 'reglas_consumo_receta: OK';
END $$;
ROLLBACK;
