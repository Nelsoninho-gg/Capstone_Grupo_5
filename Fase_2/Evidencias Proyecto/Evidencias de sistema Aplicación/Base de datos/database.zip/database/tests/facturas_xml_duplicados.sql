-- H3.7 T08 - Identidad de la factura frente a variaciones del XML.
-- Ejecutar en pgAdmin (o psql) con las migraciones hasta 20261020_intentos_factura_duplicada.sql.
-- Ingresa facturas de ejemplo como admin y comprueba qué se considera la misma factura:
--   - el mismo RUT escrito de otra forma (con puntos, con «k» minúscula) es la misma factura;
--   - el folio con ceros a la izquierda es el mismo folio;
--   - el mismo folio de otro emisor es otra factura;
--   - el mismo folio y emisor con otro tipo de documento se rechaza por el tipo, no como duplicado.
-- Resultado: pestaña «Messages». Todo se revierte al terminar (ROLLBACK).

BEGIN;

CREATE TEMP TABLE _resultados (prueba TEXT, resultado TEXT);
GRANT ALL ON _resultados TO PUBLIC;
CREATE TEMP TABLE _casos (s1 INTEGER, admin INTEGER, ingrediente INTEGER);
GRANT SELECT ON _casos TO PUBLIC;

-- Factura mínima de una línea (Queso), con RUT, folio y tipo como texto, tal cual irían en el XML.
CREATE FUNCTION pg_temp.b64(p_rut TEXT, p_folio TEXT, p_tipo TEXT DEFAULT '33')
RETURNS TEXT
LANGUAGE sql
AS $f$
    SELECT encode(convert_to(
           '<?xml version="1.0" encoding="ISO-8859-1"?>'
        || '<SetDTE><DTE version="1.0"><Documento ID="T08">'
        || '<Encabezado><IdDoc><TipoDTE>' || p_tipo || '</TipoDTE><Folio>' || p_folio || '</Folio>'
        || '<FchEmis>2026-10-15</FchEmis></IdDoc>'
        || '<Emisor><RUTEmisor>' || p_rut || '</RUTEmisor><RznSoc>Emisor de ensayo</RznSoc></Emisor>'
        || '<Totales><MntNeto>1000</MntNeto><TasaIVA>19</TasaIVA><IVA>190</IVA><MntTotal>1190</MntTotal></Totales>'
        || '</Encabezado>'
        || '<Detalle><NroLinDet>1</NroLinDet><NmbItem>Queso</NmbItem><QtyItem>2</QtyItem>'
        || '<PrcItem>500</PrcItem><MontoItem>1000</MontoItem></Detalle>'
        || '</Documento></DTE></SetDTE>', 'LATIN1'), 'base64')
$f$;

DO $$
DECLARE
    g INTEGER; s1 INTEGER; adm INTEGER; ing INTEGER;
BEGIN
    SELECT id INTO g FROM public.unidades_medida WHERE abreviatura = 'g';
    INSERT INTO public.sucursales (nombre) VALUES ('Prueba H3.7 T08') RETURNING id INTO s1;
    INSERT INTO public.usuarios (nombre, identificador_acceso, password_hash, rol)
        VALUES ('Admin prueba H3.7 T08', 'prueba-h37-t08-admin', 'x', 'admin') RETURNING id INTO adm;
    INSERT INTO public.ingredientes (nombre, unidad_id) VALUES ('Prueba H3.7 T08 Queso', g) RETURNING id INTO ing;
    INSERT INTO _casos VALUES (s1, adm, ing);
END $$;

SELECT set_config('request.jwt.claims', json_build_object('role', 'nury_admin', 'user_id', admin)::text, TRUE)
  FROM _casos;
SET LOCAL ROLE nury_admin;

DO $$
DECLARE
    c    _casos%ROWTYPE;
    asoc JSONB;
    resp JSONB;
BEGIN
    SELECT * INTO c FROM _casos;
    asoc := jsonb_build_array(jsonb_build_object('numero_linea', 1, 'ingrediente_id', c.ingrediente,
                                                 'unidades_por_presentacion', 1));

    -- Emisor con «K» como dígito verificador: 6-K es un RUT válido.
    resp := public.fn_ingresar_factura_xml(c.s1, pg_temp.b64('6-K', '990004001'), 'original.xml', asoc);
    INSERT INTO _resultados VALUES ('T01 se ingresa la factura original (RUT 6-K, folio 990004001)',
        CASE WHEN resp->>'lineas_inventario' = '1' THEN 'OK' ELSE 'FALLA: ' || resp::TEXT END);

    resp := public.fn_ingresar_factura_xml(c.s1, pg_temp.b64('6-k', '990004001'), 'minuscula.xml', asoc);
    INSERT INTO _resultados VALUES ('T02 el mismo RUT con «k» minúscula es la misma factura',
        CASE WHEN resp->>'ya_ingresada' = 'true' THEN 'OK' ELSE 'FALLA: ' || resp::TEXT END);

    resp := public.fn_ingresar_factura_xml(c.s1, pg_temp.b64('000.000.006-K', '990004001'), 'puntos.xml', asoc);
    INSERT INTO _resultados VALUES ('T03 el mismo RUT con puntos y ceros a la izquierda es la misma factura',
        CASE WHEN resp->>'ya_ingresada' = 'true' THEN 'OK' ELSE 'FALLA: ' || resp::TEXT END);

    resp := public.fn_ingresar_factura_xml(c.s1, pg_temp.b64('6-K', '000990004001'), 'ceros.xml', asoc);
    INSERT INTO _resultados VALUES ('T04 el folio con ceros a la izquierda es el mismo folio',
        CASE WHEN resp->>'ya_ingresada' = 'true' THEN 'OK' ELSE 'FALLA: ' || resp::TEXT END);

    resp := public.fn_ingresar_factura_xml(c.s1, pg_temp.b64('76.086.428-5', '990004001'), 'otro_emisor.xml', asoc);
    INSERT INTO _resultados VALUES ('T05 el mismo folio de otro emisor es otra factura y se ingresa',
        CASE WHEN resp->>'lineas_inventario' = '1' THEN 'OK' ELSE 'FALLA: ' || resp::TEXT END);

    BEGIN
        PERFORM public.fn_ingresar_factura_xml(c.s1, pg_temp.b64('6-K', '990004001', '34'), 'tipo34.xml', asoc);
        INSERT INTO _resultados VALUES ('T06 el mismo folio y emisor con tipo 34 se rechaza por el tipo', 'FALLA: se aceptó');
    EXCEPTION WHEN SQLSTATE '22023' THEN
        INSERT INTO _resultados VALUES ('T06 el mismo folio y emisor con tipo 34 se rechaza por el tipo',
            CASE WHEN SQLERRM LIKE '%tipo 34%' THEN 'OK' ELSE 'FALLA: ' || SQLERRM END);
    END;

    BEGIN
        PERFORM public.fn_ingresar_factura_xml(c.s1, pg_temp.b64('6-1', '990004001'), 'dv_malo.xml', asoc);
        INSERT INTO _resultados VALUES ('T07 un RUT con dígito verificador incorrecto no se confunde con otro', 'FALLA: se aceptó');
    EXCEPTION WHEN SQLSTATE '22023' THEN
        INSERT INTO _resultados VALUES ('T07 un RUT con dígito verificador incorrecto no se confunde con otro', 'OK');
    END;
END $$;

RESET ROLE;

-- Verificación como propietario.
DO $$
DECLARE
    v_facturas INTEGER;
    v_intentos INTEGER;
    v_lineas   INTEGER;
BEGIN
    SELECT count(*) INTO v_facturas FROM public.facturas_compra WHERE folio = 990004001;
    SELECT count(*) INTO v_intentos FROM public.intentos_factura_duplicada WHERE folio = 990004001;
    SELECT count(*) INTO v_lineas FROM public.detalle_factura_compra d
      JOIN public.facturas_compra f ON f.id = d.factura_id
     WHERE f.folio = 990004001 AND f.rut_emisor_normalizado = '6-K';
    INSERT INTO _resultados VALUES ('V01 quedan 2 facturas con ese folio (una por emisor) y 3 intentos registrados',
        CASE WHEN v_facturas = 2 AND v_intentos = 3 THEN 'OK'
             ELSE 'FALLA: ' || v_facturas || ' facturas, ' || v_intentos || ' intentos' END);
    INSERT INTO _resultados VALUES ('V02 la factura de 6-K sumó stock una sola vez',
        CASE WHEN v_lineas = 1 THEN 'OK' ELSE 'FALLA: ' || v_lineas || ' líneas' END);
END $$;

DO $$
DECLARE
    r       RECORD;
    fallas  INTEGER := 0;
BEGIN
    FOR r IN SELECT prueba, resultado FROM _resultados ORDER BY prueba LOOP
        RAISE NOTICE '% | %', r.resultado, r.prueba;
        IF r.resultado <> 'OK' THEN
            fallas := fallas + 1;
        END IF;
    END LOOP;

    IF fallas > 0 THEN
        RAISE EXCEPTION 'La prueba tiene % caso(s) con FALLA: revisa los avisos de arriba', fallas;
    END IF;
    RAISE NOTICE 'PRUEBA COMPLETA: todos los casos dieron OK';
END $$;

ROLLBACK;
