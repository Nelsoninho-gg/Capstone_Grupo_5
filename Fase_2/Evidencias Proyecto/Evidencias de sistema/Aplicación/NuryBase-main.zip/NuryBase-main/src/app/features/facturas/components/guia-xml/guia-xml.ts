import { NgTemplateOutlet } from '@angular/common';
import { AfterViewInit, Component, ElementRef, output, ViewChild } from '@angular/core';

interface PasoGuia {
  titulo: string;
  texto: string;
  imagen?: { src: string; alt: string; ancho: number; alto: number };
}

const CARPETA = 'ayuda/factura-xml/';

/**
 * Guía para obtener el XML de las facturas recibidas desde el SII y subirlo a Nury.
 * Se abre en un modal desde «Facturas ingresadas» y desde la zona de carga.
 */
@Component({
  selector: 'app-guia-xml',
  imports: [NgTemplateOutlet],
  // Reutiliza encabezado de modal y botones de la pantalla de carga.
  styleUrls: ['../../pages/carga-factura/carga-factura.css', './guia-xml.css'],
  templateUrl: './guia-xml.html',
})
export class GuiaXml implements AfterViewInit {
  readonly cerrar = output<void>();

  @ViewChild('botonCerrar') private readonly botonCerrar?: ElementRef<HTMLButtonElement>;

  /** Atajo al paso 4; el SII pide iniciar sesión antes. */
  protected readonly urlRecibidos = 'https://www1.sii.cl/cgi-bin/Portal001/mipeLaunchPage.cgi?OPCION=1&TIPO=4';

  protected readonly pasosSii: PasoGuia[] = [
    {
      titulo: 'Inicia sesión en el SII',
      texto: 'Entra a sii.cl e ingresa con el RUT y la clave tributaria de la empresa.',
    },
    {
      titulo: 'Servicios online → Factura electrónica',
      texto: 'En el menú de arriba abre «Servicios online» y elige «Factura electrónica».',
      imagen: { src: '02-servicios-online.webp', alt: 'Menú «Servicios online» del SII con «Factura electrónica» destacado.', ancho: 1147, alto: 868 },
    },
    {
      titulo: 'Sistema de facturación gratuito del SII',
      texto: 'Entre las opciones, elige «Sistema de facturación gratuito del SII».',
      imagen: { src: '03-facturacion-gratuita.webp', alt: 'Página «Factura electrónica» del SII con «Sistema de facturación gratuito del SII» destacado.', ancho: 1182, alto: 864 },
    },
    {
      titulo: 'Ver documentos recibidos',
      texto: 'Abre «Historial de DTE y respuesta a documentos recibidos» y presiona «Ver documentos recibidos - Generar respuesta al emisor».',
      imagen: { src: '04-documentos-recibidos.webp', alt: 'Sección «Historial de DTE» abierta, con el enlace «Ver documentos recibidos - Generar respuesta al emisor».', ancho: 1166, alto: 836 },
    },
    {
      titulo: 'Filtra por fecha y busca',
      texto: 'Abre «Selección de documentos». Para las facturas de un día, pon esa misma fecha en «Fecha desde» y «Fecha hasta», y presiona «Buscar documentos».',
      imagen: { src: '05-filtrar-fechas.webp', alt: 'Panel «Selección de documentos» con la misma fecha en «Fecha desde» y «Fecha hasta».', ancho: 1147, alto: 281 },
    },
    {
      titulo: 'Descarga el archivo de respaldo',
      texto: 'Revisa que en la lista estén las facturas que buscas y presiona «Archivo Respaldo».',
      imagen: { src: '06-archivo-respaldo.webp', alt: 'Lista de documentos recibidos filtrada y los botones de abajo, entre ellos «Archivo Respaldo».', ancho: 1200, alto: 561 },
    },
    {
      titulo: 'Listo: ya tienes el XML',
      texto: 'Se descarga un archivo como «DTE_DOWN….xml», con todas las facturas de la lista, en tu carpeta de descargas.',
      imagen: { src: '07-descarga.webp', alt: 'Descarga terminada del archivo DTE_DOWN104920152026-11-01.xml.', ancho: 318, alto: 67 },
    },
  ];

  // shortcut: pasos de Nury sin captura, agregar las imágenes cuando estén.
  protected readonly pasosNury: PasoGuia[] = [
    {
      titulo: 'Carga el archivo',
      texto: 'En «Facturas ingresadas» presiona «Cargar factura» y arrastra el archivo, o elígelo desde tu equipo.',
    },
    {
      titulo: 'Elige la factura',
      texto: 'Si el archivo trae varias facturas, aparecen en una lista: presiona «Revisar» en cada una, de a una.',
    },
    {
      titulo: 'Revisa la sucursal y las líneas',
      texto: 'La sucursal se elige según la dirección de la factura; cámbiala si no corresponde. Asocia cada línea a su artículo del catálogo y revisa cuántas unidades trae cada presentación.',
    },
    {
      titulo: 'Confirma el ingreso',
      texto: 'Presiona «Confirmar ingreso»: el stock se suma a la sucursal y la factura queda en «Facturas ingresadas». Si el archivo trae más, sigue con la siguiente.',
    },
  ];

  protected readonly carpeta = CARPETA;

  ngAfterViewInit(): void {
    this.botonCerrar?.nativeElement.focus();
  }
}
