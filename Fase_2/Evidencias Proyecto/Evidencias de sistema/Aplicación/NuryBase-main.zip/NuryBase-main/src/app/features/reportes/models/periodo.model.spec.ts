import {
  diasEntre,
  etiquetaPeriodoAnterior,
  periodoAnterior,
  rangoDePeriodo,
  textoRango,
} from './periodo.model';

const hoy = '2026-11-04'; // miércoles

describe('rangoDePeriodo', () => {
  it('uses the chosen day', () => {
    expect(rangoDePeriodo({ tipo: 'dia', referencia: '2026-10-20' }, hoy)).toEqual({
      desde: '2026-10-20',
      hasta: '2026-10-20',
    });
  });

  it('takes the week from Monday to Sunday', () => {
    expect(rangoDePeriodo({ tipo: 'semana', referencia: '2026-10-22' }, hoy)).toEqual({
      desde: '2026-10-19',
      hasta: '2026-10-25',
    });
    // Un domingo pertenece a la semana que empezó el lunes anterior.
    expect(rangoDePeriodo({ tipo: 'semana', referencia: '2026-10-25' }, hoy)).toEqual({
      desde: '2026-10-19',
      hasta: '2026-10-25',
    });
  });

  it('does not go past today in the current week or month', () => {
    expect(rangoDePeriodo({ tipo: 'semana', referencia: hoy }, hoy)).toEqual({
      desde: '2026-11-02',
      hasta: '2026-11-04',
    });
    expect(rangoDePeriodo({ tipo: 'mes', referencia: hoy }, hoy)).toEqual({
      desde: '2026-11-01',
      hasta: '2026-11-04',
    });
  });

  it('takes the whole month of a past date', () => {
    expect(rangoDePeriodo({ tipo: 'mes', referencia: '2026-02-10' }, hoy)).toEqual({
      desde: '2026-02-01',
      hasta: '2026-02-28',
    });
  });

  it('validates a custom range', () => {
    const rango = (desde?: string, hasta?: string) =>
      rangoDePeriodo({ tipo: 'rango', referencia: hoy, desde, hasta }, hoy);
    expect(rango('2026-10-01', '2026-10-15')).toEqual({ desde: '2026-10-01', hasta: '2026-10-15' });
    expect(rango('2026-10-15', '2026-10-01')).toEqual({
      error: 'La fecha inicial no puede ser posterior a la final.',
    });
    expect(rango(undefined, '2026-10-01')).toEqual({
      error: 'Indica la fecha inicial y la final.',
    });
    expect(rango('2025-01-01', '2026-10-01')).toEqual({
      error: 'El período no puede superar un año.',
    });
  });
});

describe('periodoAnterior', () => {
  it('is the previous day for a day', () => {
    expect(periodoAnterior({ desde: '2026-10-20', hasta: '2026-10-20' }, 'dia')).toEqual({
      desde: '2026-10-19',
      hasta: '2026-10-19',
    });
  });

  it('is the same days of the previous week for a week, also an unfinished one', () => {
    expect(periodoAnterior({ desde: '2026-10-19', hasta: '2026-10-25' }, 'semana')).toEqual({
      desde: '2026-10-12',
      hasta: '2026-10-18',
    });
    // Lunes 2 a miércoles 4 de noviembre contra lunes 26 a miércoles 28 de octubre.
    expect(periodoAnterior({ desde: '2026-11-02', hasta: '2026-11-04' }, 'semana')).toEqual({
      desde: '2026-10-26',
      hasta: '2026-10-28',
    });
  });

  it('is the same days of the previous month, without passing its last day', () => {
    expect(periodoAnterior({ desde: '2026-11-01', hasta: '2026-11-04' }, 'mes')).toEqual({
      desde: '2026-10-01',
      hasta: '2026-10-04',
    });
    expect(periodoAnterior({ desde: '2026-03-01', hasta: '2026-03-31' }, 'mes')).toEqual({
      desde: '2026-02-01',
      hasta: '2026-02-28',
    });
  });

  it('is the same number of days right before for a range', () => {
    expect(periodoAnterior({ desde: '2026-11-01', hasta: '2026-11-04' }, 'rango')).toEqual({
      desde: '2026-10-28',
      hasta: '2026-10-31',
    });
    expect(periodoAnterior({ desde: '2026-11-01', hasta: '2026-11-04' })).toEqual({
      desde: '2026-10-28',
      hasta: '2026-10-31',
    });
  });

  it('counts days across month changes', () => {
    expect(diasEntre('2026-10-30', '2026-11-02')).toBe(3);
  });
});

describe('etiquetaPeriodoAnterior', () => {
  it('names the period it is compared with', () => {
    const rango = { desde: '2026-10-01', hasta: '2026-10-07' };
    expect(etiquetaPeriodoAnterior('dia', rango)).toBe('Día anterior');
    expect(etiquetaPeriodoAnterior('semana', rango)).toBe('Semana anterior');
    expect(etiquetaPeriodoAnterior('mes', rango)).toBe('Mes anterior');
    expect(etiquetaPeriodoAnterior('rango', rango)).toBe('7 días anteriores');
    expect(etiquetaPeriodoAnterior('rango', { desde: '2026-10-01', hasta: '2026-10-01' })).toBe(
      'Día anterior',
    );
  });
});

describe('textoRango', () => {
  it('shows one day or the range', () => {
    expect(textoRango({ desde: '2026-10-20', hasta: '2026-10-20' })).toContain('2026');
    expect(textoRango({ desde: '2026-10-19', hasta: '2026-10-25' })).toMatch(/19.*–.*25.*2026/);
  });
});
