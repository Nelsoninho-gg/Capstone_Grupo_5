/** Cómo se elige el período del reporte (H4.1): un día, una semana, un mes o un rango. */
export type TipoPeriodo = 'dia' | 'semana' | 'mes' | 'rango';

/** Días de Chile, ambos incluidos, en formato AAAA-MM-DD (lo que reciben las funciones). */
export interface RangoFechas {
  desde: string;
  hasta: string;
}

export interface SeleccionPeriodo {
  tipo: TipoPeriodo;
  /** Día de referencia para día, semana y mes. */
  referencia: string;
  /** Solo para "rango". */
  desde?: string;
  hasta?: string;
}

/**
 * Traduce la selección a un rango de días. La semana va de lunes a domingo y el mes del 1 al
 * último día; ninguno pasa de `hoy`, porque no hay ventas futuras que mostrar.
 */
export function rangoDePeriodo(
  seleccion: SeleccionPeriodo,
  hoy: string,
): RangoFechas | { error: string } {
  const referencia = seleccion.referencia > hoy ? hoy : seleccion.referencia;
  switch (seleccion.tipo) {
    case 'dia':
      return { desde: referencia, hasta: referencia };
    case 'semana': {
      const fecha = aFecha(referencia);
      const lunes = sumarDias(fecha, -((fecha.getDay() + 6) % 7));
      return { desde: aTexto(lunes), hasta: menor(aTexto(sumarDias(lunes, 6)), hoy) };
    }
    case 'mes': {
      const fecha = aFecha(referencia);
      const primero = new Date(fecha.getFullYear(), fecha.getMonth(), 1);
      const ultimo = new Date(fecha.getFullYear(), fecha.getMonth() + 1, 0);
      return { desde: aTexto(primero), hasta: menor(aTexto(ultimo), hoy) };
    }
    case 'rango': {
      const { desde, hasta } = seleccion;
      if (!desde || !hasta) return { error: 'Indica la fecha inicial y la final.' };
      if (desde > hasta) return { error: 'La fecha inicial no puede ser posterior a la final.' };
      if (diasEntre(desde, hasta) > 366) return { error: 'El período no puede superar un año.' };
      return { desde, hasta };
    }
  }
}

/**
 * El período anterior de igual duración, para medir tendencia (H4.2):
 *   - día: el día anterior;
 *   - semana: los mismos días de la semana anterior (lunes a miércoles contra lunes a
 *     miércoles de la semana pasada, no contra los tres días previos);
 *   - mes: los mismos días del mes anterior (1 al 4 de noviembre contra 1 al 4 de octubre),
 *     sin pasar del último día de ese mes;
 *   - rango: los mismos días inmediatamente antes.
 */
export function periodoAnterior(rango: RangoFechas, tipo: TipoPeriodo = 'rango'): RangoFechas {
  const dias = diasEntre(rango.desde, rango.hasta) + 1;
  if (tipo === 'semana') {
    return {
      desde: aTexto(sumarDias(aFecha(rango.desde), -7)),
      hasta: aTexto(sumarDias(aFecha(rango.hasta), -7)),
    };
  }
  if (tipo === 'mes') {
    const inicio = aFecha(rango.desde);
    const primero = new Date(inicio.getFullYear(), inicio.getMonth() - 1, 1);
    const ultimo = new Date(inicio.getFullYear(), inicio.getMonth(), 0);
    const hasta = sumarDias(primero, dias - 1);
    return { desde: aTexto(primero), hasta: aTexto(hasta > ultimo ? ultimo : hasta) };
  }
  const hasta = sumarDias(aFecha(rango.desde), -1);
  return { desde: aTexto(sumarDias(hasta, -(dias - 1))), hasta: aTexto(hasta) };
}

/** Cómo se nombra el período con que se compara: "Semana anterior", "7 días anteriores"... */
export function etiquetaPeriodoAnterior(tipo: TipoPeriodo, rango: RangoFechas): string {
  switch (tipo) {
    case 'dia':
      return 'Día anterior';
    case 'semana':
      return 'Semana anterior';
    case 'mes':
      return 'Mes anterior';
    case 'rango': {
      const dias = diasEntre(rango.desde, rango.hasta) + 1;
      return dias === 1 ? 'Día anterior' : `${dias} días anteriores`;
    }
  }
}

/** Cantidad de días entre dos fechas (0 si es el mismo día). */
export function diasEntre(desde: string, hasta: string): number {
  return Math.round((aFecha(hasta).getTime() - aFecha(desde).getTime()) / 86_400_000);
}

const formatoDia = new Intl.DateTimeFormat('es-CL', { day: 'numeric', month: 'short' });
const formatoDiaAnio = new Intl.DateTimeFormat('es-CL', {
  day: 'numeric',
  month: 'short',
  year: 'numeric',
});

/** "20 oct 2026" o "1 oct – 31 oct 2026". */
export function textoRango(rango: RangoFechas): string {
  if (rango.desde === rango.hasta) return formatoDiaAnio.format(aFecha(rango.desde));
  return `${formatoDia.format(aFecha(rango.desde))} – ${formatoDiaAnio.format(aFecha(rango.hasta))}`;
}

/** Fecha local de hoy en AAAA-MM-DD. */
export function hoyLocal(ahora = new Date()): string {
  return aTexto(ahora);
}

function aFecha(texto: string): Date {
  const [anio, mes, dia] = texto.split('-').map(Number);
  return new Date(anio, mes - 1, dia);
}

function aTexto(fecha: Date): string {
  const mes = String(fecha.getMonth() + 1).padStart(2, '0');
  const dia = String(fecha.getDate()).padStart(2, '0');
  return `${fecha.getFullYear()}-${mes}-${dia}`;
}

function sumarDias(fecha: Date, dias: number): Date {
  const resultado = new Date(fecha);
  resultado.setDate(resultado.getDate() + dias);
  return resultado;
}

function menor(a: string, b: string): string {
  return a < b ? a : b;
}
