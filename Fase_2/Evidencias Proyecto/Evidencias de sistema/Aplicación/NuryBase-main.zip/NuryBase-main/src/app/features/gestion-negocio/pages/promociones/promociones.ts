import { HttpErrorResponse } from '@angular/common/http';
import { Component, HostListener, OnInit, computed, effect, inject, signal } from '@angular/core';
import {
  AbstractControl,
  FormBuilder,
  ReactiveFormsModule,
  ValidationErrors,
  Validators,
} from '@angular/forms';
import { forkJoin } from 'rxjs';
import { ProductosApiService } from '../../../../core/api/productos-api.service';
import {
  PromocionApi,
  PromocionGuardar,
  PromocionesApiService,
} from '../../../../core/api/promociones-api.service';
import { SucursalApi, SucursalesApiService } from '../../../../core/api/sucursales-api.service';
import { TipoPromocion } from '../../../../core/models/comun.model';
import { BusinessTabs } from '../../components/business-tabs/business-tabs';
import {
  ETIQUETAS_ESTADO,
  EstadoPromocion,
  TIPOS_PROMOCION,
  aFechaHoraChile,
  desdeFechaHoraChile,
  esCombo,
  estadoPromocion,
  formatearFechaHora,
  sePuedeDesactivar,
  textoDescuento,
  textoSucursales,
} from '../../models/promocion';

/** Tope de unidades por producto: una promoción arma un combo, no una carga de stock. */
const CANTIDAD_MAXIMA = 99;
const MAX_RESULTADOS = 8;

interface ProductoOpcion {
  id: number;
  nombre: string;
}

interface LineaPromocion {
  producto: ProductoOpcion;
  cantidad: number;
}

/** Fila del listado con el estado ya calculado. */
interface FilaPromocion {
  promocion: PromocionApi;
  estado: EstadoPromocion;
}

/** Igual que en el POS: sin tildes ni mayúsculas, para buscar "cafe" y encontrar "Café". */
function normalizar(valor: string): string {
  return valor.normalize('NFD').replace(/[̀-ͯ]/g, '').trim().toLowerCase();
}

/** Si es porcentaje, el descuento no puede pasar de 100 (el mínimo lo valida el campo). */
function validarPorcentaje(grupo: AbstractControl): ValidationErrors | null {
  const tipo = grupo.get('tipo')?.value as TipoPromocion;
  const valor = grupo.get('valor')?.value as number | null;
  return tipo === 'porcentaje' && valor !== null && valor > 100 ? { porcentajeMaximo: true } : null;
}

/** Mensaje de la base si rechazó los datos (400, 22023), o uno genérico. */
function mensajeDeError(error: unknown, generico: string): string {
  if (error instanceof HttpErrorResponse) {
    if (error.status === 403) return 'Solo el administrador puede modificar promociones.';
    const mensaje = (error.error as { message?: unknown } | null)?.message;
    if (error.status === 400 && typeof mensaje === 'string' && mensaje) return mensaje;
  }
  return generico;
}

/** Sin «Todas las sucursales», hay que elegir al menos una. */
function validarSucursales(grupo: AbstractControl): ValidationErrors | null {
  const todas = grupo.get('todasLasSucursales')?.value as boolean;
  const elegidas = grupo.get('sucursales')?.value as number[];
  return !todas && !elegidas.length ? { sinSucursales: true } : null;
}

/** El término debe ser posterior al inicio. */
function validarVigencia(grupo: AbstractControl): ValidationErrors | null {
  const inicio = grupo.get('inicio')?.value as string;
  const termino = grupo.get('termino')?.value as string;
  // Ambos en hora de Chile con el mismo formato: se comparan como texto.
  return inicio && termino && termino <= inicio ? { terminoAntesDelInicio: true } : null;
}

/**
 * Promociones en Gestión de negocio (H5.2 T02): listado con estado, vigencia y sucursales, y el
 * formulario para crear, editar, programar y desactivar. El administrador programa la ventana
 * (inicio y término con hora) y el sistema la aplica solo dentro de ella.
 * Guardar crea o edita la promoción con sus productos en una sola transacción
 * (fn_guardar_promocion); desactivar la apaga antes de su término.
 */
@Component({
  selector: 'app-promociones',
  imports: [BusinessTabs, ReactiveFormsModule],
  templateUrl: './promociones.html',
  styleUrls: ['../gestion-negocio/gestion-negocio.css', './promociones.css'],
})
export class Promociones implements OnInit {
  private readonly promocionesApi = inject(PromocionesApiService);
  private readonly sucursalesApi = inject(SucursalesApiService);
  private readonly productosApi = inject(ProductosApiService);
  private readonly formBuilder = inject(FormBuilder);

  protected readonly tipos = TIPOS_PROMOCION;
  protected readonly cantidadMaxima = CANTIDAD_MAXIMA;

  protected readonly promociones = signal<PromocionApi[]>([]);
  protected readonly sucursales = signal<SucursalApi[]>([]);
  private readonly productos = signal<ProductoOpcion[]>([]);
  protected readonly cargando = signal(true);
  protected readonly error = signal<string | null>(null);
  protected readonly mensajeExito = signal<string | null>(null);

  protected readonly formularioAbierto = signal(false);
  protected readonly promocionEnEdicion = signal<PromocionApi | null>(null);
  protected readonly guardando = signal(false);
  protected readonly errorFormulario = signal<string | null>(null);
  protected readonly lineas = signal<LineaPromocion[]>([]);
  /** Combo: varios productos o unidades. Sin combo, un solo producto que el POS muestra rebajado. */
  protected readonly esCombo = signal(false);
  protected readonly errorProductos = computed(() => {
    const lineas = this.lineas();
    if (!lineas.length) return 'Agrega al menos un producto.';
    const combo = esCombo({ productos: lineas });
    if (this.esCombo() && !combo)
      return 'Un combo lleva más de un producto: agrega otro o sube las unidades.';
    if (!this.esCombo() && combo)
      return 'Sin combo, la promoción es de un solo producto. Marca «Es combo» o deja uno.';
    return null;
  });
  /** Se marca al intentar guardar, para mostrar el error de productos. */
  protected readonly intentoGuardar = signal(false);

  protected readonly promocionPorDesactivar = signal<PromocionApi | null>(null);
  protected readonly errorDesactivacion = signal<string | null>(null);

  protected readonly sucursalesAbiertas = signal(false);

  protected readonly busqueda = signal('');
  protected readonly listaAbierta = signal(false);
  protected readonly indiceActivo = signal(0);

  protected readonly formulario = this.formBuilder.nonNullable.group(
    {
      nombre: ['', [Validators.required, Validators.maxLength(120)]],
      tipo: ['porcentaje' as TipoPromocion, Validators.required],
      valor: this.formBuilder.control<number | null>(null, [
        Validators.required,
        Validators.min(0.01),
      ]),
      todasLasSucursales: [true],
      sucursales: this.formBuilder.nonNullable.control<number[]>([]),
      inicio: ['', Validators.required],
      termino: ['', Validators.required],
    },
    { validators: [validarPorcentaje, validarVigencia, validarSucursales] },
  );

  /** Sin combo, la promoción se llama como su producto y el nombre no se edita. */
  private readonly nombreDelProducto = effect(() => {
    const nombre = this.formulario.controls.nombre;
    if (this.esCombo()) {
      nombre.enable();
      return;
    }
    nombre.disable();
    nombre.setValue(this.lineas()[0]?.producto.nombre ?? '');
  });

  protected readonly filas = computed<FilaPromocion[]>(() => {
    const ahora = new Date();
    return this.promociones().map((promocion) => ({
      promocion,
      estado: estadoPromocion(promocion, ahora),
    }));
  });

  protected readonly conteo = computed(() => {
    const conteo: Record<EstadoPromocion, number> = {
      programada: 0,
      vigente: 0,
      terminada: 0,
      desactivada: 0,
    };
    for (const fila of this.filas()) conteo[fila.estado]++;
    return conteo;
  });

  private readonly coincidencias = computed(() => {
    const consulta = normalizar(this.busqueda());
    const elegidos = new Set(this.lineas().map((linea) => linea.producto.id));
    return this.productos().filter(
      (producto) =>
        !elegidos.has(producto.id) && (!consulta || normalizar(producto.nombre).includes(consulta)),
    );
  });
  protected readonly resultados = computed(() => this.coincidencias().slice(0, MAX_RESULTADOS));

  ngOnInit(): void {
    this.cargar();
  }

  protected cargar(): void {
    this.cargando.set(true);
    this.error.set(null);
    forkJoin({
      promociones: this.promocionesApi.listar(),
      sucursales: this.sucursalesApi.listarActivas(),
      productos: this.productosApi.listar(true),
    }).subscribe({
      next: ({ promociones, sucursales, productos }) => {
        this.promociones.set(promociones);
        this.sucursales.set(sucursales);
        this.productos.set(
          productos
            .map((p) => ({ id: p.id, nombre: p.nombre }))
            .sort((a, b) => a.nombre.localeCompare(b.nombre, 'es')),
        );
        this.cargando.set(false);
      },
      error: () => {
        this.error.set(
          'No pudimos cargar las promociones. Revisa la conexión e inténtalo nuevamente.',
        );
        this.cargando.set(false);
      },
    });
  }

  // Listado ---------------------------------------------------------------------------

  protected etiquetaEstado(estado: EstadoPromocion): string {
    return ETIQUETAS_ESTADO[estado];
  }

  protected descuento(promocion: PromocionApi): string {
    return textoDescuento(promocion.tipo, promocion.valor_descuento);
  }

  protected fechaHora(fecha: string): string {
    return formatearFechaHora(fecha);
  }

  protected sucursalesDe(promocion: PromocionApi): string {
    return textoSucursales(promocion);
  }

  protected productosDe(promocion: PromocionApi): string {
    return promocion.productos
      .map((linea) => `${linea.cantidad} × ${linea.producto?.nombre ?? 'Producto eliminado'}`)
      .join(' + ');
  }

  protected sePuedeDesactivar(estado: EstadoPromocion): boolean {
    return sePuedeDesactivar(estado);
  }

  // Formulario --------------------------------------------------------------------------

  protected abrirFormulario(): void {
    this.promocionEnEdicion.set(null);
    this.formulario.reset({
      nombre: '',
      tipo: 'porcentaje',
      valor: null,
      todasLasSucursales: true,
      sucursales: [],
      inicio: '',
      termino: '',
    });
    this.lineas.set([]);
    this.esCombo.set(false);
    this.prepararFormulario();
  }

  protected editarPromocion(promocion: PromocionApi): void {
    this.promocionEnEdicion.set(promocion);
    this.formulario.reset({
      nombre: promocion.nombre,
      tipo: promocion.tipo,
      valor: Number(promocion.valor_descuento),
      todasLasSucursales: !promocion.sucursales.length,
      // Solo las activas: una sucursal cerrada ya no se ofrece ni se puede guardar.
      sucursales: promocion.sucursales
        .map((fila) => fila.sucursal_id)
        .filter((id) => this.sucursales().some((sucursal) => sucursal.id === id)),
      inicio: aFechaHoraChile(promocion.inicio),
      termino: aFechaHoraChile(promocion.termino),
    });
    this.lineas.set(
      promocion.productos.map((linea) => ({
        producto: {
          id: linea.producto_id,
          nombre: linea.producto?.nombre ?? 'Producto eliminado',
        },
        cantidad: linea.cantidad,
      })),
    );
    this.esCombo.set(esCombo(promocion));
    this.prepararFormulario();
  }

  private prepararFormulario(): void {
    this.errorFormulario.set(null);
    this.mensajeExito.set(null);
    this.intentoGuardar.set(false);
    this.busqueda.set('');
    this.listaAbierta.set(false);
    this.sucursalesAbiertas.set(false);
    this.formularioAbierto.set(true);
  }

  @HostListener('document:keydown.escape')
  protected cerrarModales(): void {
    // Escape cierra primero el desplegable de sucursales, no todo el formulario.
    if (this.sucursalesAbiertas()) {
      this.sucursalesAbiertas.set(false);
      return;
    }
    if (this.guardando()) return;
    this.formularioAbierto.set(false);
    this.promocionEnEdicion.set(null);
    this.promocionPorDesactivar.set(null);
  }

  /** Error de un campo, solo después de tocarlo o de intentar guardar. */
  protected invalido(campo: keyof typeof this.formulario.controls): boolean {
    const control = this.formulario.controls[campo];
    // Los errores que dependen de dos campos quedan en el grupo; se muestran en el campo que
    // hay que corregir.
    const delGrupo =
      (campo === 'valor' && this.formulario.hasError('porcentajeMaximo')) ||
      (campo === 'termino' && this.formulario.hasError('terminoAntesDelInicio')) ||
      (campo === 'sucursales' && this.formulario.hasError('sinSucursales'));
    return (control.invalid || delGrupo) && (control.touched || this.intentoGuardar());
  }

  protected errorValor(): string {
    const control = this.formulario.controls.valor;
    if (control.hasError('required')) return 'Ingresa el valor del descuento.';
    if (control.invalid) return 'El descuento debe ser mayor que 0.';
    return 'El porcentaje no puede ser mayor a 100.';
  }

  protected errorTermino(): string {
    return this.formulario.controls.termino.hasError('required')
      ? 'Indica la fecha y hora de término.'
      : 'El término debe ser posterior al inicio.';
  }

  // Sucursales de la promoción ---------------------------------------------------------------

  @HostListener('document:click', ['$event'])
  protected cerrarSucursalesAlHacerClicFuera(evento: MouseEvent): void {
    if (!(evento.target as Element | null)?.closest?.('.branch-picker')) {
      this.sucursalesAbiertas.set(false);
    }
  }

  /** "Todas las sucursales", el nombre de la única elegida o "3 sucursales". */
  protected textoSucursalesElegidas(): string {
    const { todasLasSucursales, sucursales } = this.formulario.controls;
    if (todasLasSucursales.value) return 'Todas las sucursales';
    const elegidas = sucursales.value;
    if (!elegidas.length) return 'Elige las sucursales';
    if (elegidas.length === 1) {
      return this.sucursales().find((s) => s.id === elegidas[0])?.nombre ?? '1 sucursal';
    }
    return `${elegidas.length} sucursales`;
  }

  protected sucursalElegida(sucursalId: number): boolean {
    return this.formulario.controls.sucursales.value.includes(sucursalId);
  }

  protected alternarSucursal(sucursalId: number, evento: Event): void {
    const marcada = (evento.target as HTMLInputElement).checked;
    const control = this.formulario.controls.sucursales;
    const sinEsta = control.value.filter((id) => id !== sucursalId);
    control.setValue(marcada ? [...sinEsta, sucursalId] : sinEsta);
    control.markAsTouched();
  }

  // Productos de la promoción ---------------------------------------------------------------

  protected alEscribirBusqueda(valor: string): void {
    this.busqueda.set(valor);
    this.indiceActivo.set(0);
    this.listaAbierta.set(true);
  }

  protected abrirLista(): void {
    this.indiceActivo.set(0);
    this.listaAbierta.set(true);
  }

  protected cerrarLista(): void {
    this.listaAbierta.set(false);
  }

  protected agregarProducto(producto: ProductoOpcion): void {
    // Sin combo hay un solo producto: elegir otro lo reemplaza.
    this.lineas.update((lineas) => [...(this.esCombo() ? lineas : []), { producto, cantidad: 1 }]);
    this.busqueda.set('');
    this.listaAbierta.set(false);
  }

  protected alTeclearBusqueda(evento: KeyboardEvent): void {
    const resultados = this.resultados();
    switch (evento.key) {
      case 'ArrowDown':
        evento.preventDefault();
        this.listaAbierta.set(true);
        this.indiceActivo.update((i) => Math.min(i + 1, Math.max(resultados.length - 1, 0)));
        break;
      case 'ArrowUp':
        evento.preventDefault();
        this.indiceActivo.update((i) => Math.max(i - 1, 0));
        break;
      case 'Enter': {
        evento.preventDefault();
        const elegido = this.listaAbierta() ? resultados[this.indiceActivo()] : null;
        if (elegido) this.agregarProducto(elegido);
        break;
      }
      case 'Escape':
        if (this.listaAbierta()) {
          evento.stopPropagation();
          this.listaAbierta.set(false);
        }
        break;
    }
  }

  protected cambiarCantidad(productoId: number, delta: number): void {
    this.lineas.update((lineas) =>
      lineas.map((linea) =>
        linea.producto.id === productoId
          ? { ...linea, cantidad: Math.min(CANTIDAD_MAXIMA, Math.max(1, linea.cantidad + delta)) }
          : linea,
      ),
    );
  }

  protected quitarProducto(productoId: number): void {
    this.lineas.update((lineas) => lineas.filter((linea) => linea.producto.id !== productoId));
  }

  // Guardar y desactivar -----------------------------------------------------------------------

  protected guardarPromocion(): void {
    if (this.guardando()) return;
    this.intentoGuardar.set(true);
    this.formulario.markAllAsTouched();
    const valores = this.formulario.getRawValue();
    if (!valores.nombre.trim()) this.formulario.controls.nombre.setErrors({ required: true });
    if (this.formulario.invalid || this.errorProductos()) return;

    const edicion = this.promocionEnEdicion();
    const datos: PromocionGuardar = {
      nombre: valores.nombre.trim(),
      tipo: valores.tipo,
      valor_descuento: valores.valor!,
      sucursales: valores.todasLasSucursales ? [] : [...valores.sucursales].sort((a, b) => a - b),
      inicio: desdeFechaHoraChile(valores.inicio),
      termino: desdeFechaHoraChile(valores.termino),
      productos: this.lineas().map((linea) => ({
        producto_id: linea.producto.id,
        cantidad: linea.cantidad,
      })),
    };
    this.guardando.set(true);
    this.errorFormulario.set(null);
    this.promocionesApi.guardar(edicion?.id ?? null, datos).subscribe({
      next: () => {
        this.guardando.set(false);
        this.formularioAbierto.set(false);
        this.promocionEnEdicion.set(null);
        this.mensajeExito.set(
          `La promoción «${datos.nombre}» se ${edicion ? 'actualizó' : 'guardó'}.`,
        );
        this.recargarPromociones();
      },
      error: (error: unknown) => {
        this.guardando.set(false);
        this.errorFormulario.set(
          mensajeDeError(error, 'No pudimos guardar la promoción. Inténtalo nuevamente.'),
        );
      },
    });
  }

  protected pedirDesactivacion(promocion: PromocionApi): void {
    this.mensajeExito.set(null);
    this.errorDesactivacion.set(null);
    this.promocionPorDesactivar.set(promocion);
  }

  protected cancelarDesactivacion(): void {
    if (this.guardando()) return;
    this.promocionPorDesactivar.set(null);
  }

  protected confirmarDesactivacion(): void {
    const promocion = this.promocionPorDesactivar();
    if (!promocion || this.guardando()) return;
    this.guardando.set(true);
    this.errorDesactivacion.set(null);
    this.promocionesApi.desactivar(promocion.id).subscribe({
      next: () => {
        this.guardando.set(false);
        this.promocionPorDesactivar.set(null);
        this.mensajeExito.set(`La promoción «${promocion.nombre}» se desactivó.`);
        this.recargarPromociones();
      },
      error: (error: unknown) => {
        this.guardando.set(false);
        this.errorDesactivacion.set(
          mensajeDeError(error, 'No pudimos desactivar la promoción. Inténtalo nuevamente.'),
        );
      },
    });
  }

  /** Vuelve a leer el listado después de guardar, sin vaciar la tabla mientras carga. */
  private recargarPromociones(): void {
    this.promocionesApi.listar().subscribe({
      next: (promociones) => this.promociones.set(promociones),
      error: () =>
        this.error.set(
          'No pudimos actualizar el listado de promociones. Revisa la conexión e inténtalo nuevamente.',
        ),
    });
  }

  protected contarProductos(cantidad: number): string {
    return `${cantidad} ${cantidad === 1 ? 'producto' : 'productos'}`;
  }
}
