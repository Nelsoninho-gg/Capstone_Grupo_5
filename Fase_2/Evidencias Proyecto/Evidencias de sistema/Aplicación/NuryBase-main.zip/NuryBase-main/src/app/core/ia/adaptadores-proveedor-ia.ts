import { environment } from '../../../environments/environment';
import { MensajesIA, ProveedorIAConfig } from './proveedores-ia.config';

export interface PeticionHTTPPreparada {
  url: string;
  headers: Record<string, string>;
  body: unknown;
}

/** El proveedor respondió 200, pero sin contenido utilizable. */
export class RespuestaInutilizableError extends Error {}

/**
 * Prepara la URL, cabeceras HTTP y cuerpo para la petición según el formato del proveedor.
 *
 * REGLA CRÍTICA DE SEGURIDAD:
 * El token JWT de sesión de NuryBase SOLO puede ser enviado a rutas bajo environment.apiUrl (api.nury.cl).
 * Nunca debe viajar a dominios externos (Google, OpenRouter, etc.).
 * Si un proveedor configurado con 'sesion-nury' apunta a un dominio ajeno, se rechaza de inmediato.
 */
export function prepararPeticionIA(
  proveedor: ProveedorIAConfig,
  mensajes: MensajesIA,
  tokenSesion: string | null = null,
): PeticionHTTPPreparada {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };

  if (proveedor.autenticacion === 'sesion-nury') {
    if (!proveedor.baseUrl.startsWith(environment.apiUrl)) {
      throw new Error(
        `Seguridad: El JWT de sesión solo puede viajar a ${environment.apiUrl}. ` +
          `No está permitido enviarlo a: ${proveedor.baseUrl}`,
      );
    }
    if (!tokenSesion || !tokenSesion.trim()) {
      throw new Error(
        `Autenticación requerida: el proveedor '${proveedor.id}' requiere una sesión activa con token JWT de NuryBase.`,
      );
    }
    headers['Authorization'] = `Bearer ${tokenSesion.trim()}`;
  } else if (proveedor.autenticacion === 'api-key') {
    if (proveedor.apiKey) {
      if (proveedor.formato === 'gemini') {
        headers['x-goog-api-key'] = proveedor.apiKey;
      } else {
        headers['Authorization'] = `Bearer ${proveedor.apiKey}`;
      }
    }
  }

  if (proveedor.formato === 'gemini') {
    return {
      url: `${proveedor.baseUrl}/models/${proveedor.modelo}:generateContent`,
      headers,
      body: {
        systemInstruction: {
          parts: [{ text: mensajes.sistema }],
        },
        contents: [
          {
            role: 'user',
            parts: [{ text: mensajes.usuario }],
          },
        ],
        generationConfig: {
          responseMimeType: 'application/json',
          temperature: 0,
        },
      },
    };
  }

  // openai-compatible (OpenRouter, Ollama, etc.)
  return {
    url: `${proveedor.baseUrl}/chat/completions`,
    headers,
    body: {
      model: proveedor.modelo,
      messages: [
        { role: 'system', content: mensajes.sistema },
        { role: 'user', content: mensajes.usuario },
      ],
      response_format: { type: 'json_object' },
      temperature: 0,
    },
  };
}

/**
 * Remueve delimitadores de bloques de código Markdown (```json ... ``` o ``` ... ```)
 * para evitar fallos de sintaxis al parsear el JSON generado por modelos de IA.
 */
export function limpiarMarkdownJson(texto: string): string {
  const recortado = texto.trim();
  const match = recortado.match(/^```(?:json)?\s*([\s\S]*?)\s*```$/i);
  return match ? match[1].trim() : recortado;
}

/**
 * Extrae el texto del contenido generado por el modelo según su formato de respuesta.
 * Lanza un error si la respuesta es nula, vacía o no contiene la estructura esperada,
 * lo que permite al orquestador considerarlo un fallo y rotar al siguiente proveedor.
 */
export function extraerTextoRespuestaIA(
  proveedor: ProveedorIAConfig,
  respuesta: unknown,
): string {
  if (!respuesta || typeof respuesta !== 'object') {
    throw new RespuestaInutilizableError('Respuesta del proveedor de IA vacía o con formato inesperado');
  }

  if (proveedor.formato === 'gemini') {
    const raw = respuesta as {
      candidates?: { content?: { parts?: { text?: string; thought?: boolean }[] } }[];
    };
    // Gemma entrega primero su razonamiento, marcado con `thought`, y después la respuesta.
    const texto = (raw.candidates?.[0]?.content?.parts ?? [])
      .filter((parte) => !parte.thought)
      .map((parte) => parte.text ?? '')
      .join('');
    if (!texto.trim()) {
      throw new RespuestaInutilizableError('Respuesta de Gemini vacía o sin contenido textual');
    }
    return limpiarMarkdownJson(texto);
  }

  // openai-compatible
  const raw = respuesta as {
    choices?: { message?: { content?: string } }[];
  };
  const texto = raw.choices?.[0]?.message?.content;
  if (typeof texto !== 'string' || !texto.trim()) {
    throw new RespuestaInutilizableError('Respuesta de proveedor OpenAI vacía o sin contenido textual');
  }
  return limpiarMarkdownJson(texto);
}
