export type RolUsuario = 'admin' | 'administrador' | 'cajero' | 'bodeguero';

export type EstadoFactura = 'pendiente_revision' | 'confirmada' | 'anulada';

/** Tipo de descuento de una promoción (H5.2). Un combo es una promoción con varios productos. */
export type TipoPromocion = 'porcentaje' | 'monto_fijo';

export type MedioPago = 'efectivo' | 'debito' | 'credito' | 'transferencia';

export type TipoVenta = 'normal' | 'empleado';

export type TipoMovimientoStock =
    | 'compra'
    | 'venta'
    | 'ajuste'
    | 'merma'
    | 'anulacion_venta'
    | 'consumo_interno';

export type ReferenciaTipoMovimiento = 'factura_compra' | 'venta' | 'ajuste_manual' | 'almuerzo_empleado';

export type AccionAuditoriaUsuario = 'creacion' | 'edicion' | 'deshabilitacion' | 'reactivacion';
