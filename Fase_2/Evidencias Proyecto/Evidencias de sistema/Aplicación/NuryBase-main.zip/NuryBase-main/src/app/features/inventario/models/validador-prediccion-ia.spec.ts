import { describe, expect, it } from 'vitest';
import { ArticuloEntradaPrediccionIA } from './prediccion-ia.contract';
import { validarInterpretacionIA } from './validador-prediccion-ia';

const HARINA: ArticuloEntradaPrediccionIA = {
  articuloId: 'art-harina',
  nombre: 'Harina Panadera',
  tipo: 'materia_prima',
  sucursalId: 1,
  sucursal: 'Nury Providencia',
  unidad: 'kg',
  stockActual: 300,
  stockMinimo: 250,
  diasHistorial: 40,
  aptoParaPredecir: true,
  metricasConsumo: {
    promedioDiarioBase: 50,
    promedioDiarioSinFiltrar: 55,
    desviacionEstandar: 0.5,
    diasNormalesContabilizados: 20,
    totalPicosAislados: 0,
  },
  picosAislados: [],
  calculo: {
    estado: 'comprar-hoy',
    tasaDiariaEstimada: 50,
    diasHastaMinimo: 1,
    fechaRecomendadaPedido: '2026-11-05',
    cantidadSugerida: 0,
  },
};
const LECHE: ArticuloEntradaPrediccionIA = { ...HARINA, articuloId: 'art-leche', stockActual: 900 };

const salida = (...predicciones: unknown[]) => JSON.stringify({ predicciones });

describe('validarInterpretacionIA (H4.5 T07)', () => {
  it('acepta texto por artículo, como objeto o como JSON', () => {
    const item = { articuloId: 'art-harina', justificacion: 'Quedan 300 kg y el consumo es regular.' };

    const desdeJson = validarInterpretacionIA(salida(item), [HARINA]);
    expect(desdeJson.exito).toBe(true);
    if (desdeJson.exito) {
      expect(desdeJson.justificaciones.get('art-harina')).toContain('300 kg');
    }

    expect(validarInterpretacionIA({ predicciones: [item] }, [HARINA]).exito).toBe(true);
  });

  it.each([
    ['JSON malformado', '{"predicciones": ['],
    ['raíz sin predicciones', '{"otra": []}'],
    ['raíz nula', 'null'],
    ['lista vacía', '{"predicciones": []}'],
  ])('rechaza %s', (_caso, crudo) => {
    expect(validarInterpretacionIA(crudo, [HARINA]).exito).toBe(false);
  });

  it('descarta artículos no solicitados, textos vacíos y textos demasiado largos', () => {
    const resultado = validarInterpretacionIA(
      salida(
        { articuloId: 'inventado', justificacion: 'x' },
        { articuloId: 'art-harina', justificacion: '   ' },
        { articuloId: 'art-leche', justificacion: 'y'.repeat(201) },
        null,
      ),
      [HARINA, LECHE],
    );
    expect(resultado.exito).toBe(false);
    expect(resultado.errores).toHaveLength(4);
  });

  it('descarta una justificación con cifras que no vienen de los cálculos', () => {
    const resultado = validarInterpretacionIA(
      salida({ articuloId: 'art-harina', justificacion: 'Conviene comprar 777 kg hoy.' }),
      [HARINA],
    );
    expect(resultado.exito).toBe(false);
    expect(resultado.errores[0].mensaje).toContain('777');
  });

  it('descarta nombres que no vienen de los datos del artículo y acepta los que sí', () => {
    const resultado = validarInterpretacionIA(
      salida(
        { articuloId: 'art-harina', justificacion: 'Conviene pedirla a Rodrigo Valenzuela.' },
        { articuloId: 'art-leche', justificacion: 'Queda poca Harina Panadera en Nury Providencia.' },
      ),
      [HARINA, LECHE],
    );

    expect(resultado.exito).toBe(true);
    if (resultado.exito) {
      expect([...resultado.justificaciones.keys()]).toEqual(['art-leche']);
      expect(resultado.errores[0].mensaje).toContain('Rodrigo, Valenzuela');
    }
  });

  it('solo verifica contra los datos del mismo artículo', () => {
    const resultado = validarInterpretacionIA(
      salida({ articuloId: 'art-harina', justificacion: 'Quedan 900 kg.' }),
      [HARINA, LECHE],
    );
    expect(resultado.exito).toBe(false);
  });

  it('conserva lo válido cuando solo falla una parte', () => {
    const resultado = validarInterpretacionIA(
      salida(
        { articuloId: 'art-harina', justificacion: 'Consumo regular.' },
        { articuloId: 'art-leche', justificacion: 'Comprar 777 l.' },
      ),
      [HARINA, LECHE],
    );
    expect(resultado.exito).toBe(true);
    if (resultado.exito) {
      expect([...resultado.justificaciones.keys()]).toEqual(['art-harina']);
      expect(resultado.errores).toHaveLength(1);
    }
  });
});
