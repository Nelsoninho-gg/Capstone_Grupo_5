import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { TipoPromocion } from '../models/comun.model';

/** Promoción con sus sucursales y productos, como la devuelve PostgREST (H5.2). */
export interface PromocionApi {
  id: number;
  nombre: string;
  tipo: TipoPromocion;
  /** PostgREST envía NUMERIC como texto. */
  valor_descuento: number | string;
  /** ISO con zona: rige desde inicio (incluido) hasta termino (no incluido). */
  inicio: string;
  termino: string;
  activa: boolean;
  creado_en: string;
  /**
   * Sucursales donde rige; vacío = todas (también las que se abran después). Al cajero la
   * base le muestra solo la fila de su sucursal.
   */
  sucursales: { sucursal_id: number; sucursal: { nombre: string } | null }[];
  productos: { producto_id: number; cantidad: number; producto: { nombre: string } | null }[];
}

/** Datos del formulario para crear o editar una promoción (fn_guardar_promocion). */
export interface PromocionGuardar {
  nombre: string;
  tipo: TipoPromocion;
  valor_descuento: number;
  /** Vacío = todas las sucursales. */
  sucursales: number[];
  /** ISO con zona. */
  inicio: string;
  termino: string;
  productos: { producto_id: number; cantidad: number }[];
}

const CAMPOS =
  'id,nombre,tipo,valor_descuento,inicio,termino,activa,creado_en,' +
  'sucursales:promocion_sucursales(sucursal_id,sucursal:sucursales(nombre)),' +
  'productos:promocion_productos(producto_id,cantidad,producto:productos(nombre))';

/**
 * Promociones programadas (H5.2). Lectura directa de `promociones` y `promocion_productos`:
 * el administrador las administra; el cajero solo lee las vigentes de su sucursal y no puede
 * crearlas ni cambiarlas (20261105_promociones.sql y 20261105_promociones_permisos.sql).
 */
@Injectable({ providedIn: 'root' })
export class PromocionesApiService {
  private readonly http = inject(HttpClient);
  private readonly url = `${environment.apiUrl}/promociones`;

  /** Todas las promociones, de la que empieza más tarde a la más antigua (administrador). */
  listar(): Observable<PromocionApi[]> {
    return this.http.get<PromocionApi[]>(this.url, {
      params: { select: CAMPOS, order: 'inicio.desc,id.desc' },
    });
  }

  /**
   * Promociones que se aplican ahora en la sucursal de la venta (H5.2 T04): activas, dentro de
   * su ventana y de esa sucursal o de todas. La hora la pone el servidor
   * (fn_promociones_vigentes, 20261105_promociones_vigentes.sql), no el reloj de este equipo:
   * empiezan y terminan solas aunque el reloj del POS esté corrido. Para el cajero la base
   * además limita a su sucursal (RLS).
   */
  listarVigentes(sucursalId: number): Observable<PromocionApi[]> {
    return this.http.get<PromocionApi[]>(`${environment.apiUrl}/rpc/fn_promociones_vigentes`, {
      params: { p_sucursal_id: sucursalId, select: CAMPOS },
    });
  }

  /**
   * Crea (id null) o edita una promoción con sus productos en una sola transacción
   * (fn_guardar_promocion, 20261108_promociones_sucursales.sql). Devuelve el id. Si los datos no
   * sirven, la base responde 400 con el motivo en `message`.
   */
  guardar(id: number | null, promocion: PromocionGuardar): Observable<number> {
    return this.http.post<number>(`${environment.apiUrl}/rpc/fn_guardar_promocion`, {
      p_id: id,
      p_nombre: promocion.nombre,
      p_tipo: promocion.tipo,
      p_valor: promocion.valor_descuento,
      p_sucursales: promocion.sucursales.length ? promocion.sucursales : null,
      p_inicio: promocion.inicio,
      p_termino: promocion.termino,
      p_productos: promocion.productos,
    });
  }

  /** Apaga la promoción antes de su término; las ventas ya hechas no cambian. */
  desactivar(id: number): Observable<void> {
    return this.http.patch<void>(this.url, { activa: false }, { params: { id: `eq.${id}` } });
  }
}
