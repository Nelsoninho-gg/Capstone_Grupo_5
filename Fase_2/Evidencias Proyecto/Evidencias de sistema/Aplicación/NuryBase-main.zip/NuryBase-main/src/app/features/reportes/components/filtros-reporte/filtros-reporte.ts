import {
  Component,
  ElementRef,
  HostListener,
  computed,
  inject,
  input,
  model,
  signal,
} from '@angular/core';
import { SeleccionPeriodo, TipoPeriodo } from '../../models/periodo.model';

/**
 * Filtros compartidos por todo el dashboard de Reportes, con el estilo de los filtros de
 * Inventario: un desplegable de sucursales con casillas (ninguna marcada = todas) y otro, con
 * el mismo diseño, para el período (día, semana, mes o rango), con su fecha.
 */
@Component({
  selector: 'app-filtros-reporte',
  templateUrl: './filtros-reporte.html',
  styleUrl: './filtros-reporte.css',
})
export class FiltrosReporte {
  private readonly elemento = inject<ElementRef<HTMLElement>>(ElementRef);

  readonly sucursales = input.required<{ id: number; nombre: string }[]>();
  readonly hoy = input.required<string>();
  /** Vacío = todas las sucursales. */
  readonly seleccionadas = model<number[]>([]);
  readonly periodo = model.required<SeleccionPeriodo>();

  protected readonly periodos: { tipo: TipoPeriodo; etiqueta: string }[] = [
    { tipo: 'dia', etiqueta: 'Día' },
    { tipo: 'semana', etiqueta: 'Semana' },
    { tipo: 'mes', etiqueta: 'Mes' },
    { tipo: 'rango', etiqueta: 'Rango personalizado' },
  ];

  /** Desplegable abierto: solo uno a la vez. */
  protected readonly abierto = signal<'sucursales' | 'periodo' | null>(null);
  protected readonly todas = computed(() => this.seleccionadas().length === 0);

  /** "Todas las sucursales", el nombre de la única elegida o "3 sucursales". */
  protected readonly textoSucursales = computed(() => {
    const elegidas = this.seleccionadas();
    if (!elegidas.length) return 'Todas las sucursales';
    if (elegidas.length === 1) {
      return this.sucursales().find((s) => s.id === elegidas[0])?.nombre ?? '1 sucursal';
    }
    return `${elegidas.length} sucursales`;
  });

  protected readonly textoPeriodo = computed(
    () => this.periodos.find((p) => p.tipo === this.periodo().tipo)?.etiqueta ?? '',
  );

  protected alternarDesplegable(cual: 'sucursales' | 'periodo'): void {
    this.abierto.update((abierto) => (abierto === cual ? null : cual));
  }

  @HostListener('document:click', ['$event'])
  protected cerrarAlHacerClicFuera(event: MouseEvent): void {
    const dentro = (event.target as Element | null)?.closest?.('.picker');
    if (this.abierto() && (!dentro || !this.elemento.nativeElement.contains(dentro))) {
      this.abierto.set(null);
    }
  }

  @HostListener('document:keydown.escape')
  protected cerrarConEscape(): void {
    this.abierto.set(null);
  }

  protected estaElegida(id: number): boolean {
    return this.seleccionadas().includes(id);
  }

  protected alternarSucursal(id: number): void {
    this.seleccionadas.update((actuales) =>
      actuales.includes(id) ? actuales.filter((x) => x !== id) : [...actuales, id],
    );
  }

  protected elegirTodas(): void {
    this.seleccionadas.set([]);
  }

  protected elegirPeriodo(tipo: TipoPeriodo): void {
    this.periodo.update((actual) => ({ ...actual, tipo }));
    this.abierto.set(null);
  }

  protected actualizarFecha(campo: 'referencia' | 'desde' | 'hasta', event: Event): void {
    const valor = (event.target as HTMLInputElement).value;
    if (!valor && campo === 'referencia') return;
    this.periodo.update((actual) => ({ ...actual, [campo]: valor || undefined }));
  }
}
