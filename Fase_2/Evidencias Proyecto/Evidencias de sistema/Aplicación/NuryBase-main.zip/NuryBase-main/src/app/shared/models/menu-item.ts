import type { UserRole } from '../../features/auth/models/auth.model';

export interface MenuItem {
  label: string;
  icon: string;
  route: string;
  allowedRoles: readonly UserRole[];
  /** Título del grupo en el menú; los ítems seguidos con el mismo título van juntos. */
  section?: string;
}
