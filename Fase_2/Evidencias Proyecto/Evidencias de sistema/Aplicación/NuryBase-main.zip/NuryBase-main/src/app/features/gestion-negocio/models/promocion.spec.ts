import {
  aFechaHoraChile,
  desdeFechaHoraChile,
  esCombo,
  estadoPromocion,
  formatearFechaHora,
  sePuedeDesactivar,
  textoDescuento,
  textoSucursales,
} from './promocion';

describe('promocion', () => {
  const ahora = new Date('2026-11-07T15:00:00Z');
  const ventana = (inicio: string, termino: string, activa = true) => ({ inicio, termino, activa });

  it('is a combo only with more than one unit in total', () => {
    const linea = (producto_id: number, cantidad: number) => ({
      producto_id,
      cantidad,
      producto: null,
    });
    expect(esCombo({ productos: [linea(1, 1)] })).toBe(false);
    expect(esCombo({ productos: [linea(1, 2)] })).toBe(true);
    expect(esCombo({ productos: [linea(1, 1), linea(2, 1)] })).toBe(true);
  });

  it('derives the state from the window, without manual activation', () => {
    expect(estadoPromocion(ventana('2026-11-08T03:00:00Z', '2026-11-10T03:00:00Z'), ahora)).toBe(
      'programada',
    );
    expect(estadoPromocion(ventana('2026-11-07T03:00:00Z', '2026-11-09T03:00:00Z'), ahora)).toBe(
      'vigente',
    );
    expect(estadoPromocion(ventana('2026-11-01T03:00:00Z', '2026-11-03T03:00:00Z'), ahora)).toBe(
      'terminada',
    );
  });

  it('starts exactly at its start and ends exactly at its end', () => {
    expect(estadoPromocion(ventana('2026-11-07T15:00:00Z', '2026-11-08T15:00:00Z'), ahora)).toBe(
      'vigente',
    );
    expect(estadoPromocion(ventana('2026-11-06T15:00:00Z', '2026-11-07T15:00:00Z'), ahora)).toBe(
      'terminada',
    );
  });

  it('marks a switched-off promotion as deactivated until its window ends', () => {
    expect(
      estadoPromocion(ventana('2026-11-07T03:00:00Z', '2026-11-09T03:00:00Z', false), ahora),
    ).toBe('desactivada');
    expect(
      estadoPromocion(ventana('2026-11-01T03:00:00Z', '2026-11-03T03:00:00Z', false), ahora),
    ).toBe('terminada');
  });

  it('only scheduled or current promotions can be deactivated', () => {
    expect(sePuedeDesactivar('programada')).toBe(true);
    expect(sePuedeDesactivar('vigente')).toBe(true);
    expect(sePuedeDesactivar('terminada')).toBe(false);
    expect(sePuedeDesactivar('desactivada')).toBe(false);
  });

  it('names the branches of the promotion, or all of them when none is chosen', () => {
    expect(textoSucursales({ sucursales: [] })).toBe('Todas las sucursales');
    expect(
      textoSucursales({
        sucursales: [
          { sucursal_id: 2, sucursal: { nombre: 'Ñuñoa' } },
          { sucursal_id: 1, sucursal: { nombre: 'Providencia' } },
        ],
      }),
    ).toBe('Ñuñoa, Providencia');
  });

  it('describes the discount', () => {
    expect(textoDescuento('porcentaje', '20.00')).toBe('20 % de descuento');
    expect(textoDescuento('monto_fijo', 1000).replace(/\s/g, ' ')).toBe('$1.000 de descuento');
  });

  it('reads the form date and time as Chile time, whatever the device zone (H5.2 T04)', () => {
    // Noviembre: horario de verano, UTC−3.
    expect(desdeFechaHoraChile('2026-11-07T00:00')).toBe('2026-11-07T03:00:00.000Z');
    expect(desdeFechaHoraChile('2026-11-08T23:59')).toBe('2026-11-09T02:59:00.000Z');
    // Julio: horario de invierno, UTC−4.
    expect(desdeFechaHoraChile('2027-07-03T00:00')).toBe('2027-07-03T04:00:00.000Z');
  });

  it('shows the stored instant in Chile time for editing', () => {
    expect(aFechaHoraChile('2026-11-07T03:00:00Z')).toBe('2026-11-07T00:00');
    expect(aFechaHoraChile('2027-07-03T04:00:00+00:00')).toBe('2027-07-03T00:00');
    expect(aFechaHoraChile(desdeFechaHoraChile('2026-12-31T23:30'))).toBe('2026-12-31T23:30');
  });

  it('handles the days when Chile changes its clock', () => {
    // 4/4/2027: a las 00:00 de verano el reloj vuelve a las 23:00 del sábado (UTC−3 → UTC−4).
    expect(desdeFechaHoraChile('2027-04-04T12:00')).toBe('2027-04-04T16:00:00.000Z');
    // 5/9/2027: el reloj salta de 00:00 a 01:00 (UTC−4 → UTC−3).
    expect(desdeFechaHoraChile('2027-09-05T12:00')).toBe('2027-09-05T15:00:00.000Z');
  });

  it('formats the window in Chile time', () => {
    expect(formatearFechaHora('2026-11-07T03:00:00Z')).toBe('07-11-2026, 00:00');
  });
});
