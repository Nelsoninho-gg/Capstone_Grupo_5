import { Component, computed, effect, inject, input, signal } from '@angular/core';
import { TipoArticulo } from '../../models/inventario.model';
import {
  MENSAJE_DATOS_INSUFICIENTES,
  PrediccionArticuloIA,
  formatearFechaChile,
} from '../../models/prediccion-ia.contract';
import {
  ArticuloPredictivo,
  ETIQUETAS_ESTADO_PREDICCION,
  EstadoPrediccion,
  EstimacionPreliminarArticulo,
  FiltroTipoPrediccion,
  FiltroUrgenciaPrediccion,
  ResumenMadurezDatos,
  UMBRAL_DIAS_HISTORIAL,
  cantidadSugeridaCompra,
  contarPredicciones,
  diasFaltantesParaUmbral,
  diasHastaMinimo,
  evaluarEstadoPredictivo,
  evaluarMadurezDatos,
  filtrarPredicciones,
  obtenerEstimacionPreliminar,
  textoDiasOperacion,
  tieneHistorialSuficiente,
} from '../../models/prediccion.model';
import {
  PrediccionStockService,
  ResultadoPrediccionStock,
  calcularPrediccionArticulo,
} from '../../services/prediccion-stock.service';

const TODAS_LAS_SUCURSALES = 'todas';
const ARTICULOS_POR_PAGINA = 20;
// En el dashboard y en móvil cada fila ocupa más espacio.
const ARTICULOS_POR_PAGINA_RESUMEN = 10;

/** Primero lo que hay que comprar, aunque el artículo aún no tenga historial para predecir. */
function prioridadCompra(articulo: ArticuloPredictivo): number {
  const estado = evaluarEstadoPredictivo(articulo);
  if (articulo.stockActual < articulo.stockMinimo || estado === 'comprar-hoy') return 0;
  if (estado === 'proximo-pedido') return 1;
  return estado === 'estable' ? 2 : 3;
}
const formatoNumero = new Intl.NumberFormat('es-CL', { maximumFractionDigits: 1 });

@Component({
  selector: 'app-panel-predictivo',
  templateUrl: './panel-predictivo.html',
  styleUrls: ['../../styles/inventario-base.css', './panel-predictivo.css'],
})
export class PanelPredictivo {
  private readonly prediccionService = inject(PrediccionStockService, { optional: true });

  readonly sucursales = input<{ id: number; nombre: string }[]>([]);
  readonly sucursalInicial = input(TODAS_LAS_SUCURSALES);
  /** Versión para el dashboard: sin encabezado, aviso ni selector de sucursal, que ya están en la página. */
  readonly resumen = input(false);

  protected readonly filtroSucursal = signal(TODAS_LAS_SUCURSALES);
  protected readonly filtroUrgencia = signal<FiltroUrgenciaPrediccion>('todos');
  protected readonly filtroTipo = signal<FiltroTipoPrediccion>('todos');
  protected readonly busqueda = signal('');
  protected readonly cargando = signal(false);
  protected readonly baseArticulos = signal<readonly ArticuloPredictivo[]>([]);
  protected readonly resultadoIa = signal<ResultadoPrediccionStock | null>(null);

  protected readonly mapaPredicciones = computed(() => {
    const mapa = new Map<string, PrediccionArticuloIA>();
    const res = this.resultadoIa();
    if (res?.predicciones) {
      for (const p of res.predicciones) {
        mapa.set(p.articuloId, p);
      }
    }
    return mapa;
  });

  private readonly sucursalId = computed(() => {
    const valor = this.filtroSucursal();
    return valor === TODAS_LAS_SUCURSALES ? null : Number(valor);
  });

  protected readonly articulosSucursal = computed(() =>
    filtrarPredicciones(this.baseArticulos(), this.sucursalId(), 'todos', '', this.filtroTipo()),
  );

  protected readonly conteo = computed(() => contarPredicciones(this.articulosSucursal()));

  protected readonly madurez = computed<ResumenMadurezDatos>(() =>
    evaluarMadurezDatos(this.articulosSucursal()),
  );

  protected readonly articulosFiltrados = computed(() =>
    filtrarPredicciones(
      this.baseArticulos(),
      this.sucursalId(),
      this.filtroUrgencia(),
      this.busqueda(),
      this.filtroTipo(),
    ),
  );

  protected readonly pagina = signal(1);
  private readonly articulosPorPagina = computed(() =>
    this.resumen() ? ARTICULOS_POR_PAGINA_RESUMEN : ARTICULOS_POR_PAGINA,
  );
  protected readonly totalPaginas = computed(() =>
    Math.max(1, Math.ceil(this.articulosFiltrados().length / this.articulosPorPagina())),
  );

  protected readonly articulosVisibles = computed(() => {
    const ordenados = [...this.articulosFiltrados()].sort(
      (a, b) => prioridadCompra(a) - prioridadCompra(b),
    );
    const inicio = (this.pagina() - 1) * this.articulosPorPagina();
    return ordenados.slice(inicio, inicio + this.articulosPorPagina());
  });

  protected readonly hayFiltrosActivos = computed(
    () =>
      this.filtroUrgencia() !== 'todos' ||
      this.filtroTipo() !== 'todos' ||
      this.busqueda().trim().length > 0 ||
      (!this.resumen() && this.filtroSucursal() !== TODAS_LAS_SUCURSALES),
  );

  protected readonly tarjetasResumen: readonly {
    estado: EstadoPrediccion;
    titulo: string;
    subtitulo: string;
    claseTono: string;
  }[] = [
    {
      estado: 'comprar-hoy',
      titulo: 'Sugerido comprar hoy',
      subtitulo: 'Alcanza para hoy o mañana',
      claseTono: 'state-agotado',
    },
    {
      estado: 'proximo-pedido',
      titulo: 'Sugerido comprar pronto',
      subtitulo: 'Quedan de 2 a 4 días',
      claseTono: 'state-critico',
    },
    {
      estado: 'estable',
      titulo: 'Stock suficiente',
      subtitulo: 'Más de 4 días disponibles',
      claseTono: 'state-estable',
    },
    {
      estado: 'datos-insuficientes',
      titulo: 'Datos insuficientes',
      subtitulo: 'Artículos nuevos (< 4 semanas)',
      claseTono: 'state-insuficiente',
    },
  ];

  constructor() {
    effect(() => {
      this.articulosFiltrados();
      this.pagina.set(1);
    });

    effect(() => {
      const inicial = this.sucursalInicial();
      const lista = this.sucursales();
      if (
        inicial === TODAS_LAS_SUCURSALES ||
        lista.some((s) => `${s.id}` === inicial)
      ) {
        this.filtroSucursal.set(inicial);
      }
    });

    effect(() => {
      const sucId = this.sucursalId();
      this.cargarDatosYPredicciones(sucId);
    });
  }

  protected cargarDatosYPredicciones(sucId: number | null = this.sucursalId()): void {
    if (!this.prediccionService) {
      return;
    }
    this.cargando.set(true);
    this.prediccionService.cargarArticulos(sucId).subscribe({
      next: (lista) => {
        this.baseArticulos.set(lista);
        this.prediccionService!.generarSugerencias(lista).subscribe({
          next: (res) => {
            this.resultadoIa.set(res);
            this.cargando.set(false);
          },
          error: () => {
            this.cargando.set(false);
          },
        });
      },
      error: () => {
        this.cargando.set(false);
      },
    });
  }

  protected cambiarSucursal(evento: Event): void {
    this.filtroSucursal.set((evento.target as HTMLSelectElement).value);
  }

  protected cambiarUrgencia(evento: Event): void {
    this.filtroUrgencia.set(
      (evento.target as HTMLSelectElement).value as FiltroUrgenciaPrediccion,
    );
  }

  protected cambiarTipo(evento: Event): void {
    this.filtroTipo.set(
      (evento.target as HTMLSelectElement).value as FiltroTipoPrediccion,
    );
  }

  protected alternarTarjetaUrgencia(estado: EstadoPrediccion): void {
    this.filtroUrgencia.update((actual) => (actual === estado ? 'todos' : estado));
  }

  protected actualizarBusqueda(evento: Event): void {
    this.busqueda.set((evento.target as HTMLInputElement).value);
  }

  protected limpiarFiltros(): void {
    this.filtroUrgencia.set('todos');
    this.filtroTipo.set('todos');
    this.busqueda.set('');
    if (!this.resumen()) this.filtroSucursal.set(TODAS_LAS_SUCURSALES);
  }

  protected estadoDe(articulo: ArticuloPredictivo): EstadoPrediccion {
    return evaluarEstadoPredictivo(articulo);
  }

  protected etiquetaEstado(articulo: ArticuloPredictivo): string {
    return ETIQUETAS_ESTADO_PREDICCION[evaluarEstadoPredictivo(articulo)];
  }

  protected historialSuficiente(articulo: ArticuloPredictivo): boolean {
    return tieneHistorialSuficiente(articulo.diasHistorial);
  }

  protected diasFaltantes(articulo: ArticuloPredictivo): number {
    return diasFaltantesParaUmbral(articulo.diasHistorial);
  }

  protected estimacionPreliminarDe(articulo: ArticuloPredictivo): EstimacionPreliminarArticulo {
    return obtenerEstimacionPreliminar(articulo);
  }

  protected coberturaTexto(articulo: ArticuloPredictivo): string {
    if (!tieneHistorialSuficiente(articulo.diasHistorial)) {
      const preliminar = obtenerEstimacionPreliminar(articulo);
      if (preliminar.diasCoberturaEstimados !== null) {
        const d = preliminar.diasCoberturaEstimados;
        const texto = d <= 1 ? 'Se agota hoy' : `Alcanza para ${textoDiasOperacion(d)}`;
        return `${texto} (preliminar)`;
      }
      return `Recién agregado (${articulo.diasHistorial} de ${UMBRAL_DIAS_HISTORIAL} días)`;
    }
    const dias = diasHastaMinimo(
      articulo.stockActual,
      articulo.stockMinimo,
      articulo.consumoDiarioBase,
    );
    if (dias === null) return '—';
    if (dias <= 1) return 'Se agota hoy';
    return `Alcanza para ${textoDiasOperacion(dias)}`;
  }

  protected compraSugerida(articulo: ArticuloPredictivo): number {
    if (tieneHistorialSuficiente(articulo.diasHistorial)) {
      return cantidadSugeridaCompra(articulo);
    }
    return obtenerEstimacionPreliminar(articulo).compraSugeridaPreliminar;
  }

  protected formatearCantidad(valor: number): string {
    return formatoNumero.format(valor);
  }

  protected etiquetaTipo(tipo: TipoArticulo): string {
    return tipo === 'producto' ? 'Producto' : 'Ingrediente';
  }

  protected prediccionDe(articulo: ArticuloPredictivo): PrediccionArticuloIA | null {
    return this.mapaPredicciones().get(articulo.id) ?? null;
  }

  protected justificacionDe(articulo: ArticuloPredictivo): string {
    const pred = this.prediccionDe(articulo);
    if (pred?.justificacion && pred.justificacion !== MENSAJE_DATOS_INSUFICIENTES) {
      return pred.justificacion;
    }
    if (!this.historialSuficiente(articulo)) {
      return this.justificacionPreliminar(articulo);
    }
    return calcularPrediccionArticulo(articulo, formatearFechaChile()).justificacion;
  }

  private justificacionPreliminar(articulo: ArticuloPredictivo): string {
    const prelim = this.estimacionPreliminarDe(articulo);
    const cant = (valor: number) => `${this.formatearCantidad(valor)} ${articulo.unidad}`;
    const dias = articulo.diasHistorial;
    const base = `Lleva ${dias} ${dias === 1 ? 'día' : 'días'} de historial y faltan ${this.diasFaltantes(articulo)} para predecir su consumo.`;
    const compra = prelim.compraSugeridaPreliminar;

    if (articulo.stockActual < articulo.stockMinimo) {
      const bajoMinimo = `${base} Su stock (${cant(articulo.stockActual)}) está bajo el mínimo (${cant(articulo.stockMinimo)});`;
      return compra > 0
        ? `${bajoMinimo} por ahora conviene comprar ${cant(compra)}.`
        : `${bajoMinimo} conviene revisarlo contra el stock físico.`;
    }
    if (prelim.urgenciaPreliminar === 'comprar-hoy' && compra > 0) {
      return `${base} Por ahora conviene comprar ${cant(compra)} hoy.`;
    }
    if (prelim.diasCoberturaEstimados !== null) {
      return `${base} Por ahora alcanzaría para ${textoDiasOperacion(prelim.diasCoberturaEstimados)}.`;
    }
    return `${base} Todavía no registra consumo.`;
  }

  protected fechaPedidoDe(articulo: ArticuloPredictivo): string | null {
    if (this.estadoDe(articulo) === 'estable') return null;
    const fecha = this.prediccionDe(articulo)?.fechaRecomendadaPedido;
    return fecha ? fecha.split('-').reverse().join('-') : null;
  }
}
