import { TestBed } from '@angular/core/testing';
import { firstValueFrom, of } from 'rxjs';
import { ReportesApiService } from '../../../core/api/reportes-api.service';
import { ReportesService } from './reportes.service';

describe('ReportesService', () => {
  const api = {
    resumenVentasSucursal: vi.fn(),
    productosVendidosSucursal: vi.fn(),
    rendimientoCajeros: vi.fn(),
    cuadraturaVentasStock: vi.fn(),
    turnosReporte: vi.fn(),
    costoActualProductos: vi.fn(),
  };
  let service: ReportesService;
  const filtro = { sucursales: [1], desde: '2026-10-20', hasta: '2026-10-20' };

  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [{ provide: ReportesApiService, useValue: api }] });
    service = TestBed.inject(ReportesService);
  });

  it('maps the branch summary with numbers, payment methods and voided sales apart', async () => {
    api.resumenVentasSucursal.mockReturnValue(
      of([
        {
          sucursal_id: 1,
          sucursal: 'Nury Providencia',
          ventas: 4,
          total: '7500.00',
          ticket_promedio: '1875.00',
          ventas_normales: 3,
          total_normales: '6000.00',
          ventas_empleado: 1,
          total_empleado: '1500.00',
          medios_pago: { efectivo: '3000.00', debito: 3000, credito: '1500.00' },
          anuladas: 1,
          total_anuladas: '5000.00',
        },
        {
          sucursal_id: null,
          sucursal: 'Sin sucursal',
          ventas: 1,
          total: 800,
          ticket_promedio: 800,
          ventas_normales: 1,
          total_normales: 800,
          ventas_empleado: 0,
          total_empleado: 0,
          medios_pago: {},
          anuladas: 0,
          total_anuladas: 0,
        },
      ]),
    );

    const [providencia, sinSucursal] = await firstValueFrom(service.resumenPorSucursal(filtro));
    expect(api.resumenVentasSucursal).toHaveBeenCalledWith(filtro);
    expect(providencia).toEqual({
      sucursalId: 1,
      sucursal: 'Nury Providencia',
      ventas: 4,
      total: 7500,
      ticketPromedio: 1875,
      normales: { ventas: 3, total: 6000 },
      empleado: { ventas: 1, total: 1500 },
      mediosPago: { efectivo: 3000, debito: 3000, credito: 1500 },
      anuladas: { ventas: 1, total: 5000 },
    });
    expect(sinSucursal.sucursalId).toBeNull();
    expect(sinSucursal.sucursal).toBe('Sin sucursal');
    expect(sinSucursal.mediosPago).toEqual({});
  });

  it('maps the cashier metrics with voided sales apart', async () => {
    api.rendimientoCajeros.mockReturnValue(
      of([
        {
          cajero_id: 7,
          cajero: 'Camila Rojas',
          sucursales: 'Nury Providencia',
          turnos: 2,
          ventas: 3,
          total: '6000.00',
          venta_promedio: '2000.00',
          productos: '6.000',
          anuladas: 1,
          total_anuladas: '5000.00',
        },
      ]),
    );
    expect(await firstValueFrom(service.rendimientoCajeros(filtro))).toEqual([
      {
        cajeroId: 7,
        cajero: 'Camila Rojas',
        sucursales: 'Nury Providencia',
        turnos: 2,
        ventas: 3,
        total: 6000,
        ventaPromedio: 2000,
        productos: 6,
        anuladas: { ventas: 1, total: 5000 },
      },
    ]);
    expect(api.rendimientoCajeros).toHaveBeenCalledWith(filtro);
  });

  it('sends the chosen shift, or 0 for the sales without shift (H4.3 T03)', async () => {
    api.rendimientoCajeros.mockReturnValue(of([]));
    await firstValueFrom(service.rendimientoCajeros(filtro, 7));
    expect(api.rendimientoCajeros).toHaveBeenLastCalledWith(filtro, 7);
    await firstValueFrom(service.rendimientoCajeros(filtro, 'sin-turno'));
    expect(api.rendimientoCajeros).toHaveBeenLastCalledWith(filtro, 0);
  });

  it('maps the current product costs, keeping null when there is none (H4.4 T03)', async () => {
    api.costoActualProductos.mockReturnValue(
      of([
        {
          producto_id: 1,
          origen: 'receta',
          costo_unitario: '800.00',
          ingredientes: 2,
          ingredientes_sin_costo: 1,
        },
        {
          producto_id: 2,
          origen: 'sin_costo',
          costo_unitario: null,
          ingredientes: 0,
          ingredientes_sin_costo: 0,
        },
      ]),
    );
    expect(await firstValueFrom(service.costoActualProductos())).toEqual([
      {
        productoId: 1,
        origen: 'receta',
        costoUnitario: 800,
        ingredientes: 2,
        ingredientesSinCosto: 1,
      },
      {
        productoId: 2,
        origen: 'sin_costo',
        costoUnitario: null,
        ingredientes: 0,
        ingredientesSinCosto: 0,
      },
    ]);
  });

  it('maps the shifts of the period with numbers', async () => {
    api.turnosReporte.mockReturnValue(
      of([
        {
          turno_id: 7,
          cajero_id: 3,
          cajero: 'Ana',
          sucursal_id: 1,
          sucursal: 'Nury Providencia',
          inicio: '2026-10-20T09:00:00',
          fin: null,
          ventas: 4,
          total: '12000.00',
          anuladas: 1,
        },
      ]),
    );
    expect(await firstValueFrom(service.turnosReporte(filtro))).toEqual([
      {
        turnoId: 7,
        cajeroId: 3,
        cajero: 'Ana',
        sucursalId: 1,
        sucursal: 'Nury Providencia',
        inicio: '2026-10-20T09:00:00',
        fin: null,
        ventas: 4,
        total: 12000,
        anuladas: 1,
      },
    ]);
  });

  it('maps the reconciliation rows with numbers', async () => {
    api.cuadraturaVentasStock.mockReturnValue(
      of([
        {
          sucursal_id: 1,
          sucursal: 'Nury Providencia',
          tipo: 'producto',
          articulo_id: 4,
          articulo: 'Chaparrita',
          unidad: 'un',
          esperado: '3.000',
          registrado: '4.000',
          diferencia: '1.000',
          cuadra: false,
        },
      ]),
    );
    expect(await firstValueFrom(service.cuadraturaVentasStock(filtro))).toEqual([
      {
        sucursalId: 1,
        sucursal: 'Nury Providencia',
        tipo: 'producto',
        articuloId: 4,
        articulo: 'Chaparrita',
        unidad: 'un',
        esperado: 3,
        registrado: 4,
        diferencia: 1,
        cuadra: false,
      },
    ]);
  });

  it('maps the products sold by branch', async () => {
    api.productosVendidosSucursal.mockReturnValue(
      of([
        {
          sucursal_id: 1,
          sucursal: 'Nury Providencia',
          producto_id: 9,
          producto: 'Sándwich',
          categoria: 'Comida',
          con_receta: true,
          unidades: '2.000',
          ventas: 2,
          monto_bruto: '6000.00',
          descuento: '900.00',
          monto: '5100.00',
        },
      ]),
    );

    expect(await firstValueFrom(service.productosPorSucursal(filtro))).toEqual([
      {
        sucursalId: 1,
        sucursal: 'Nury Providencia',
        productoId: 9,
        producto: 'Sándwich',
        categoria: 'Comida',
        conReceta: true,
        unidades: 2,
        ventas: 2,
        montoBruto: 6000,
        descuento: 900,
        monto: 5100,
      },
    ]);
    expect(api.productosVendidosSucursal).toHaveBeenCalledWith(filtro);
  });
});
