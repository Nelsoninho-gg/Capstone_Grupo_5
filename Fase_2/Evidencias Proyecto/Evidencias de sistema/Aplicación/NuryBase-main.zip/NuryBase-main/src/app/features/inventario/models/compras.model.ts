import { HojaXlsx } from '../../../shared/utils/xlsx';
import { TipoArticulo } from './inventario.model';

/**
 * Artículo crítico para la compra del día siguiente (Inventario > Por comprar): su stock no
 * cubre el mínimo más el consumo de un día. Viene de fn_articulos_por_comprar.
 */
export interface ArticuloPorComprar {
  /** tipo-articulo-sucursal, el mismo formato que las existencias. */
  id: string;
  articuloId: number;
  articulo: string;
  tipo: TipoArticulo;
  unidad: string;
  sucursalId: number;
  sucursal: string;
  stock: number;
  minimo: number;
  /** Total vendido en el periodo elegido (ventas menos anulaciones); es lo que se muestra. */
  vendido: number;
  /**
   * Promedio diario vendido en el periodo, solo para el cálculo: en productos da fracciones de
   * unidad (1 bebida en 7 días = 0,143), así que no se muestra.
   */
  consumoDiario: number;
  /** Mínimo + consumo diario: lo que debería haber al empezar el día. */
  objetivo: number;
  /** Cantidad a comprar para llegar al objetivo (productos en unidades enteras). */
  sugerido: number;
}

/**
 * Por qué está en la lista: agotado (sin stock o en negativo), bajo el mínimo, o sobre el
 * mínimo pero sin alcanzar para el consumo de mañana.
 */
export type MotivoCompra = 'agotado' | 'bajo-minimo' | 'consumo';

export function motivoCompra(articulo: ArticuloPorComprar): MotivoCompra {
  if (articulo.stock <= 0) return 'agotado';
  return articulo.stock < articulo.minimo ? 'bajo-minimo' : 'consumo';
}

export const ETIQUETAS_MOTIVO: Record<MotivoCompra, string> = {
  agotado: 'Agotado',
  'bajo-minimo': 'Bajo el mínimo',
  consumo: 'No alcanza para mañana',
};

export type ConteoMotivos = Record<MotivoCompra, number> & { total: number };

export function contarMotivos(articulos: readonly ArticuloPorComprar[]): ConteoMotivos {
  const conteo: ConteoMotivos = { total: 0, agotado: 0, 'bajo-minimo': 0, consumo: 0 };
  for (const articulo of articulos) {
    conteo.total++;
    conteo[motivoCompra(articulo)]++;
  }
  return conteo;
}

/** Encabezado de la columna de ventas según el periodo: "Vendido (7 días)". */
export function etiquetaVendido(dias: number): string {
  return dias === 1 ? 'Vendido (último día)' : `Vendido (${dias} días)`;
}

const formatoPlanilla = new Intl.NumberFormat('es-CL', {
  maximumFractionDigits: 3,
  useGrouping: false,
});

/**
 * Planilla de compras en CSV para abrir en Excel: separador punto y coma y coma decimal,
 * como lo espera Excel en español. El BOM lo agrega quien descarga el archivo.
 */
export function planillaCompras(articulos: readonly ArticuloPorComprar[], dias: number): string {
  const encabezado = [
    'Sucursal',
    'Artículo',
    'Tipo',
    'Unidad',
    'Stock actual',
    'Mínimo',
    etiquetaVendido(dias),
    'Comprar',
    'Motivo',
  ];
  const filas = articulos.map((articulo) => [
    articulo.sucursal,
    articulo.articulo,
    articulo.tipo === 'producto' ? 'Producto' : 'Materia prima',
    articulo.unidad,
    formatoPlanilla.format(articulo.stock),
    formatoPlanilla.format(articulo.minimo),
    formatoPlanilla.format(articulo.vendido),
    formatoPlanilla.format(articulo.sugerido),
    ETIQUETAS_MOTIVO[motivoCompra(articulo)],
  ]);
  return [encabezado, ...filas].map((fila) => fila.map(celdaCsv).join(';')).join('\r\n');
}

/** Comillas solo cuando hacen falta; las comillas internas se duplican. */
function celdaCsv(valor: string): string {
  return /[";\r\n]/.test(valor) ? `"${valor.replace(/"/g, '""')}"` : valor;
}

/**
 * La misma planilla como hoja de Excel: los números quedan como números (se pueden sumar y
 * ordenar), con el encabezado fijo y filtros, y la columna "Comprar" en negrita.
 */
export function hojaCompras(articulos: readonly ArticuloPorComprar[], dias: number): HojaXlsx {
  return {
    nombre: 'Por comprar',
    columnas: [
      { titulo: 'Sucursal', ancho: 26 },
      { titulo: 'Artículo', ancho: 34 },
      { titulo: 'Tipo', ancho: 15 },
      { titulo: 'Unidad', ancho: 9 },
      { titulo: 'Stock actual', ancho: 13 },
      { titulo: 'Mínimo', ancho: 10 },
      { titulo: etiquetaVendido(dias), ancho: 18 },
      { titulo: 'Comprar', ancho: 11, destacada: true },
      { titulo: 'Motivo', ancho: 24 },
    ],
    filas: articulos.map((articulo) => [
      articulo.sucursal,
      articulo.articulo,
      articulo.tipo === 'producto' ? 'Producto' : 'Materia prima',
      articulo.unidad,
      articulo.stock,
      articulo.minimo,
      articulo.vendido,
      articulo.sugerido,
      ETIQUETAS_MOTIVO[motivoCompra(articulo)],
    ]),
  };
}
