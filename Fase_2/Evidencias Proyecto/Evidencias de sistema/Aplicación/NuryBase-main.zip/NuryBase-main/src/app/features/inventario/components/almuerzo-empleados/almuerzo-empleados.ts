import { Component, OnInit, computed, inject, output, signal } from '@angular/core';
import { catchError, concatMap, finalize, forkJoin, from, map, of, toArray } from 'rxjs';
import { AlmuerzosApiService, fechaHoyChile } from '../../../../core/api/almuerzos-api.service';
import { ProductosApiService } from '../../../../core/api/productos-api.service';
import { RecetasApiService } from '../../../../core/api/recetas-api.service';
import { SucursalApi, SucursalesApiService } from '../../../../core/api/sucursales-api.service';
import { EmpleadoApi, UsuariosApiService } from '../../../../core/api/usuarios-api.service';
import { AuthService } from '../../../auth/services/auth.service';
import { FalloAlmuerzo, interpretarFalloAlmuerzo } from '../../models/fallo-almuerzo';
import { sucursalesAutorizadas } from '../../services/inventario.service';

type Paso = 'formulario' | 'confirmacion';

/** Producto que se puede agregar al almuerzo. */
interface ProductoAlmuerzo {
  id: number;
  nombre: string;
  codigo: string | null;
  /** Con receta descuenta ingredientes; sin receta, sus propias unidades. */
  conReceta: boolean;
}

interface LineaAlmuerzo {
  producto: ProductoAlmuerzo;
  cantidad: number;
}

/** Almuerzo de un empleado listo para registrar; se confirman varios de una vez. */
interface AlmuerzoPendiente {
  empleado: EmpleadoApi;
  lineas: LineaAlmuerzo[];
}

/** Resultado del registro de un almuerzo de la lista. */
interface ResultadoRegistro {
  almuerzo: AlmuerzoPendiente;
  fallo: FalloAlmuerzo | null;
}

/** Cantidad máxima de coincidencias que se muestran bajo el buscador. */
const MAX_RESULTADOS = 8;
/** Tope por línea: un almuerzo es un consumo personal, no una carga de stock. */
const CANTIDAD_MAXIMA = 99;

/** Igual que en el POS: sin tildes ni mayúsculas, para buscar "cafe" y encontrar "Café". */
function normalizar(valor: string): string {
  return valor
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .trim()
    .toLowerCase();
}

/**
 * Almuerzo de empleados sin cobro (H2.13): se elige al empleado y los productos que
 * consume, y se confirma sin paso de pago. Es consumo interno: no es una venta ni pasa
 * por caja.
 * Valida que haya al menos un producto y que el empleado no haya almorzado hoy (T04);
 * la base aplica las mismas reglas al registrar.
 * Al confirmar registra el almuerzo y descuenta el stock en la base (T05, vía
 * fn_registrar_almuerzo_empleado) e informa el resultado o el motivo del rechazo.
 * Se pueden juntar varios empleados, cada uno con sus productos, y confirmarlos de una vez:
 * cada almuerzo se registra por separado, así el rechazo de uno no frena a los demás.
 */
@Component({
  selector: 'app-almuerzo-empleados',
  templateUrl: './almuerzo-empleados.html',
  styleUrls: ['../../styles/inventario-base.css', './almuerzo-empleados.css'],
})
export class AlmuerzoEmpleados implements OnInit {
  private readonly sucursalesApi = inject(SucursalesApiService);
  private readonly usuariosApi = inject(UsuariosApiService);
  private readonly productosApi = inject(ProductosApiService);
  private readonly recetasApi = inject(RecetasApiService);
  private readonly almuerzosApi = inject(AlmuerzosApiService);
  private readonly authService = inject(AuthService);

  /** Se emite cuando el almuerzo quedó registrado y el stock de la sucursal cambió. */
  readonly registrado = output<void>();

  protected readonly cantidadMaxima = CANTIDAD_MAXIMA;

  protected readonly sucursales = signal<SucursalApi[]>([]);
  protected readonly empleados = signal<EmpleadoApi[]>([]);
  /** Empleados que ya registraron su almuerzo hoy: solo se permite uno por día. */
  protected readonly conAlmuerzoHoy = signal<ReadonlySet<number>>(new Set());
  private readonly productos = signal<ProductoAlmuerzo[]>([]);

  protected readonly cargando = signal(true);
  protected readonly error = signal<string | null>(null);

  protected readonly paso = signal<Paso>('formulario');
  protected readonly sucursalId = signal<number | null>(null);
  protected readonly empleadoId = signal<number | null>(null);
  protected readonly lineas = signal<LineaAlmuerzo[]>([]);
  /** Almuerzos ya armados que se confirmarán juntos. */
  protected readonly pendientes = signal<AlmuerzoPendiente[]>([]);
  /** Aviso al agregar un empleado a la lista. */
  protected readonly avisoLista = signal<string | null>(null);
  /** Se marcan al intentar continuar, para mostrar qué falta. */
  protected readonly intentoContinuar = signal(false);
  protected readonly guardando = signal(false);
  protected readonly mensajeExito = signal<string | null>(null);
  protected readonly errorRegistro = signal<string | null>(null);

  /** Texto del buscador de productos. */
  protected readonly busqueda = signal('');
  protected readonly listaAbierta = signal(false);
  /** Opción resaltada con las flechas del teclado. */
  protected readonly indiceActivo = signal(0);

  protected readonly cajero = computed(() => this.authService.currentUser()?.nombre ?? '');
  protected readonly fechaHoy = new Intl.DateTimeFormat('es-CL', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  }).format(new Date());

  protected readonly sucursalElegida = computed(
    () => this.sucursales().find((s) => s.id === this.sucursalId()) ?? null,
  );
  protected readonly empleadoElegido = computed(
    () => this.empleados().find((e) => e.id === this.empleadoId()) ?? null,
  );
  protected readonly totalUnidades = computed(() =>
    this.lineas().reduce((total, linea) => total + linea.cantidad, 0),
  );
  protected readonly empleadoYaAlmorzo = computed(() => {
    const id = this.empleadoId();
    return id !== null && this.conAlmuerzoHoy().has(id);
  });
  /** Empleados que ya están en la lista: no se pueden repetir. */
  protected readonly idsEnLista = computed(
    () => new Set(this.pendientes().map((almuerzo) => almuerzo.empleado.id)),
  );
  /** El empleado elegido y sus productos forman un almuerzo válido. */
  private readonly almuerzoEnCursoValido = computed(
    () => this.empleadoId() !== null && !this.empleadoYaAlmorzo() && this.lineas().length > 0,
  );
  protected readonly puedeContinuar = computed(
    () =>
      this.sucursalId() !== null &&
      (this.almuerzoEnCursoValido() ||
        (this.empleadoId() === null && this.pendientes().length > 0)),
  );
  /** Almuerzos que se revisarán: los de la lista más el que se está armando. */
  protected readonly totalAlmuerzos = computed(
    () => this.pendientes().length + (this.empleadoId() !== null ? 1 : 0),
  );
  protected readonly textoRevisar = computed(() =>
    this.totalAlmuerzos() > 1 ? `Revisar ${this.totalAlmuerzos()} almuerzos` : 'Revisar almuerzo',
  );
  /** Algún empleado de la lista ya almorzó (lo registró otro cajero mientras tanto). */
  protected readonly hayQuienYaAlmorzo = computed(() =>
    this.pendientes().some((almuerzo) => this.conAlmuerzoHoy().has(almuerzo.empleado.id)),
  );
  protected readonly unidadesPendientes = computed(() =>
    this.pendientes().reduce((total, almuerzo) => total + unidades(almuerzo), 0),
  );

  private readonly coincidencias = computed(() => {
    const consulta = normalizar(this.busqueda());
    if (!consulta) return this.productos();
    return this.productos().filter(
      (producto) =>
        normalizar(producto.nombre).includes(consulta) ||
        (producto.codigo ?? '').toLowerCase().includes(consulta),
    );
  });

  /** Coincidencias por nombre (sin tildes) o por código de barras. */
  protected readonly resultados = computed(() => this.coincidencias().slice(0, MAX_RESULTADOS));
  protected readonly totalCoincidencias = computed(() => this.coincidencias().length);

  ngOnInit(): void {
    this.cargarDatos();
  }

  protected cargarDatos(): void {
    this.cargando.set(true);
    this.error.set(null);
    forkJoin({
      sucursales: this.sucursalesApi.listarActivas(),
      empleados: this.usuariosApi.listarEmpleados(),
      productos: this.productosApi.listar(true),
      conReceta: this.recetasApi.listarIdsProductosConReceta(),
      conAlmuerzo: this.almuerzosApi.empleadosConAlmuerzo(fechaHoyChile()),
    }).subscribe({
      next: ({ sucursales, empleados, productos, conReceta, conAlmuerzo }) => {
        const idsConReceta = new Set(conReceta);
        this.sucursales.set(this.filtrarAutorizadas(sucursales));
        if (this.sucursales().length === 1) this.sucursalId.set(this.sucursales()[0].id);
        this.empleados.set(empleados);
        this.conAlmuerzoHoy.set(new Set(conAlmuerzo));
        this.productos.set(
          productos
            .map((p) => ({
              id: p.id,
              nombre: p.nombre,
              codigo: p.codigo_barras,
              conReceta: idsConReceta.has(p.id),
            }))
            .sort((a, b) => a.nombre.localeCompare(b.nombre, 'es')),
        );
        this.cargando.set(false);
      },
      error: () => {
        this.error.set('No pudimos cargar los datos. Revisa la conexión e inténtalo nuevamente.');
        this.cargando.set(false);
      },
    });
  }

  /** Mismas sucursales que el panel (H3.4 T08): el admin, todas; el resto, solo la suya. */
  private filtrarAutorizadas(sucursales: SucursalApi[]): SucursalApi[] {
    const alcance = sucursalesAutorizadas(this.authService.currentUser());
    if (alcance === null) return sucursales;
    return sucursales.filter((sucursal) => sucursal.id === alcance);
  }

  protected alCambiarSucursal(evento: Event): void {
    const valor = (evento.target as HTMLSelectElement).value;
    this.sucursalId.set(valor ? Number(valor) : null);
  }

  protected alCambiarEmpleado(evento: Event): void {
    const valor = (evento.target as HTMLSelectElement).value;
    this.empleadoId.set(valor ? Number(valor) : null);
  }

  protected alEscribirBusqueda(valor: string): void {
    this.busqueda.set(valor);
    this.indiceActivo.set(0);
    this.listaAbierta.set(true);
  }

  protected abrirLista(): void {
    this.indiceActivo.set(0);
    this.listaAbierta.set(true);
  }

  protected cerrarLista(): void {
    this.listaAbierta.set(false);
  }

  /** Agrega el producto o, si ya está en la lista, suma una unidad. */
  protected agregarProducto(producto: ProductoAlmuerzo): void {
    if (this.lineas().some((linea) => linea.producto.id === producto.id)) {
      this.cambiarCantidad(producto.id, 1);
    } else {
      this.lineas.update((lineas) => [...lineas, { producto, cantidad: 1 }]);
    }
    this.busqueda.set('');
    this.listaAbierta.set(false);
  }

  protected alTeclearBusqueda(evento: KeyboardEvent): void {
    const resultados = this.resultados();
    switch (evento.key) {
      case 'ArrowDown':
        evento.preventDefault();
        this.listaAbierta.set(true);
        this.indiceActivo.update((i) => Math.min(i + 1, Math.max(resultados.length - 1, 0)));
        break;
      case 'ArrowUp':
        evento.preventDefault();
        this.indiceActivo.update((i) => Math.max(i - 1, 0));
        break;
      case 'Enter': {
        evento.preventDefault();
        // Un código de barras exacto (pistola lectora) agrega el producto directamente.
        const texto = this.busqueda().trim();
        const porCodigo = this.productos().find((p) => p.codigo && p.codigo === texto);
        const elegido = porCodigo ?? (this.listaAbierta() ? resultados[this.indiceActivo()] : null);
        if (elegido) this.agregarProducto(elegido);
        break;
      }
      case 'Escape':
        this.listaAbierta.set(false);
        break;
    }
  }

  protected cambiarCantidad(productoId: number, delta: number): void {
    this.lineas.update((lineas) =>
      lineas.map((linea) =>
        linea.producto.id === productoId
          ? {
              ...linea,
              cantidad: Math.min(CANTIDAD_MAXIMA, Math.max(1, linea.cantidad + delta)),
            }
          : linea,
      ),
    );
  }

  protected quitarProducto(productoId: number): void {
    this.lineas.update((lineas) => lineas.filter((linea) => linea.producto.id !== productoId));
  }

  /** Deja al empleado elegido en la lista; los productos quedan para el siguiente. */
  protected agregarALista(): void {
    this.intentoContinuar.set(true);
    if (this.sucursalId() === null || !this.almuerzoEnCursoValido()) return;
    const empleado = this.empleadoElegido()!;
    this.moverALista();
    this.intentoContinuar.set(false);
    this.avisoLista.set(
      `${empleado.nombre} quedó en la lista. Elige al siguiente empleado: los productos se ` +
        'mantienen, cámbialos si almuerza otra cosa.',
    );
  }

  protected continuar(): void {
    this.intentoContinuar.set(true);
    if (!this.puedeContinuar()) return;
    if (this.empleadoId() !== null) this.moverALista();
    this.intentoContinuar.set(false);
    this.mensajeExito.set(null);
    this.errorRegistro.set(null);
    this.avisoLista.set(null);
    this.paso.set('confirmacion');
  }

  private moverALista(): void {
    const empleado = this.empleadoElegido()!;
    const lineas = this.lineas().map((linea) => ({ ...linea }));
    this.pendientes.update((lista) => [...lista, { empleado, lineas }]);
    this.empleadoId.set(null);
  }

  /** Vuelve a armar el almuerzo de la lista: el empleado y sus productos pasan al formulario. */
  protected editarPendiente(empleadoId: number): void {
    if (this.empleadoId() !== null) return;
    const almuerzo = this.pendientes().find((a) => a.empleado.id === empleadoId);
    if (!almuerzo) return;
    this.quitarPendiente(empleadoId);
    this.empleadoId.set(almuerzo.empleado.id);
    this.lineas.set(almuerzo.lineas.map((linea) => ({ ...linea })));
    this.avisoLista.set(null);
  }

  protected quitarPendiente(empleadoId: number): void {
    this.pendientes.update((lista) => lista.filter((a) => a.empleado.id !== empleadoId));
  }

  protected volver(): void {
    if (this.guardando()) return;
    this.errorRegistro.set(null);
    this.paso.set('formulario');
  }

  /**
   * Registra los almuerzos de la lista, uno tras otro: la base guarda cada uno y descuenta
   * su stock en una sola transacción. Los rechazados quedan en pantalla con su motivo.
   */
  protected confirmar(): void {
    const sucursal = this.sucursalElegida();
    const almuerzos = this.pendientes();
    if (this.guardando() || this.hayQuienYaAlmorzo() || !sucursal || !almuerzos.length) return;

    this.guardando.set(true);
    this.errorRegistro.set(null);
    this.mensajeExito.set(null);
    from(almuerzos)
      .pipe(
        concatMap((almuerzo) =>
          this.almuerzosApi
            .registrar({
              p_sucursal_id: sucursal.id,
              p_empleado_id: almuerzo.empleado.id,
              p_items: almuerzo.lineas.map((linea) => ({
                producto_id: linea.producto.id,
                cantidad: linea.cantidad,
              })),
            })
            .pipe(
              map((): ResultadoRegistro => ({ almuerzo, fallo: null })),
              catchError((error: unknown) =>
                of<ResultadoRegistro>({ almuerzo, fallo: interpretarFalloAlmuerzo(error) }),
              ),
            ),
        ),
        toArray(),
        finalize(() => this.guardando.set(false)),
      )
      .subscribe((resultados) => this.alRegistrar(sucursal, resultados));
  }

  private alRegistrar(sucursal: SucursalApi, resultados: ResultadoRegistro[]): void {
    const registrados = resultados.filter((r) => !r.fallo).map((r) => r.almuerzo);
    const rechazados = resultados.filter((r) => r.fallo);

    for (const almuerzo of registrados) this.marcarConAlmuerzo(almuerzo.empleado.id);
    // Ya almorzó hoy (quizás lo registró otro cajero): queda marcado en el selector.
    for (const { almuerzo, fallo } of rechazados) {
      if (fallo!.tipo === 'ya-almorzo') this.marcarConAlmuerzo(almuerzo.empleado.id);
    }

    if (registrados.length) {
      this.mensajeExito.set(mensajeRegistro(registrados, sucursal.nombre));
      this.registrado.emit();
    }
    if (!rechazados.length) {
      this.reiniciar();
      return;
    }
    // Quedan solo los rechazados, para revisarlos o reintentar.
    this.pendientes.set(rechazados.map((r) => r.almuerzo));
    this.errorRegistro.set(
      resultados.length === 1
        ? rechazados[0].fallo!.mensaje
        : rechazados.map((r) => `${r.almuerzo.empleado.nombre}: ${r.fallo!.mensaje}`).join('\n'),
    );
  }

  private marcarConAlmuerzo(empleadoId: number): void {
    this.conAlmuerzoHoy.update((ids) => new Set([...ids, empleadoId]));
  }

  protected reiniciar(): void {
    this.errorRegistro.set(null);
    this.avisoLista.set(null);
    this.paso.set('formulario');
    this.empleadoId.set(null);
    this.lineas.set([]);
    this.pendientes.set([]);
    this.busqueda.set('');
    this.intentoContinuar.set(false);
  }

  protected contarProductos(cantidad: number): string {
    return contarProductos(cantidad);
  }
}

function unidades(almuerzo: AlmuerzoPendiente): number {
  return almuerzo.lineas.reduce((total, linea) => total + linea.cantidad, 0);
}

function contarProductos(cantidad: number): string {
  return `${cantidad} ${cantidad === 1 ? 'producto' : 'productos'}`;
}

/** "Almuerzo de Ana registrado…" o "3 almuerzos registrados (Ana, Luis y Pedro)…". */
function mensajeRegistro(registrados: AlmuerzoPendiente[], sucursal: string): string {
  const productos = contarProductos(registrados.reduce((t, a) => t + unidades(a), 0));
  if (registrados.length === 1) {
    return (
      `Almuerzo de ${registrados[0].empleado.nombre} registrado sin cobro: ` +
      `${productos} descontados del stock de ${sucursal}.`
    );
  }
  const nombres = registrados.map((a) => a.empleado.nombre);
  const lista = `${nombres.slice(0, -1).join(', ')} y ${nombres[nombres.length - 1]}`;
  return (
    `${registrados.length} almuerzos registrados sin cobro (${lista}): ` +
    `${productos} descontados del stock de ${sucursal}.`
  );
}
