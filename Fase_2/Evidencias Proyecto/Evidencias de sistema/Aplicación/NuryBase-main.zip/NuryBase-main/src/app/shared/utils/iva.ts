/** IVA de Chile: 19% sobre el precio neto. */
export const TASA_IVA = 0.19;

/**
 * Neto sin IVA de un monto que ya incluye IVA: total ÷ 1,19.
 * El IVA es el 19% del neto (no del total): $1.800 = $1.513 neto + $287 IVA.
 */
export function netoSinIva(totalConIva: number): number {
  return totalConIva / (1 + TASA_IVA);
}

/** Desglose redondeado a pesos: neto + IVA suman exactamente el total. */
export function desglosarIva(totalConIva: number): { neto: number; iva: number } {
  const total = Math.round(totalConIva);
  const neto = Math.round(netoSinIva(total));
  return { neto, iva: total - neto };
}
