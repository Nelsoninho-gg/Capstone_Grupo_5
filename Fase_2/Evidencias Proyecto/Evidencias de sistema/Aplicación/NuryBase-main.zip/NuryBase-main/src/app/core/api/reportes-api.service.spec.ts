import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { Observable, firstValueFrom } from 'rxjs';
import { environment } from '../../../environments/environment';
import { FiltroReporteApi, ReportesApiService } from './reportes-api.service';

describe('ReportesApiService', () => {
  let service: ReportesApiService;
  let http: HttpTestingController;
  const base = environment.apiUrl;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()],
    });
    service = TestBed.inject(ReportesApiService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  it('asks the sales summary of the chosen branches and period', async () => {
    const promesa = firstValueFrom(
      service.resumenVentasSucursal({
        sucursales: [1, 3],
        desde: '2026-10-01',
        hasta: '2026-10-31',
      }),
    );
    const req = http.expectOne(`${base}/rpc/fn_reporte_ventas_sucursal`);
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual({
      p_sucursales: [1, 3],
      p_desde: '2026-10-01',
      p_hasta: '2026-10-31',
    });
    req.flush([]);
    expect(await promesa).toEqual([]);
  });

  it('sends null to ask every branch when none or an empty list is chosen', () => {
    void firstValueFrom(
      service.resumenVentasSucursal({ sucursales: null, desde: '2026-10-20', hasta: '2026-10-20' }),
    );
    void firstValueFrom(
      service.productosVendidosSucursal({
        sucursales: [],
        desde: '2026-10-20',
        hasta: '2026-10-20',
      }),
    );
    const [resumen, productos] = [
      http.expectOne(`${base}/rpc/fn_reporte_ventas_sucursal`),
      http.expectOne(`${base}/rpc/fn_reporte_productos_sucursal`),
    ];
    expect(resumen.request.body.p_sucursales).toBeNull();
    expect(productos.request.body.p_sucursales).toBeNull();
    resumen.flush([]);
    productos.flush([]);
  });

  it('asks the reconciliation with the stock movements', async () => {
    const promesa = firstValueFrom(
      service.cuadraturaVentasStock({ sucursales: [1], desde: '2026-11-01', hasta: '2026-11-05' }),
    );
    const req = http.expectOne(`${base}/rpc/fn_cuadratura_ventas_stock`);
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual({
      p_sucursales: [1],
      p_desde: '2026-11-01',
      p_hasta: '2026-11-05',
    });
    req.flush([]);
    expect(await promesa).toEqual([]);
  });

  it('asks the cashier metrics', async () => {
    const promesa = firstValueFrom(
      service.rendimientoCajeros({ sucursales: null, desde: '2026-10-20', hasta: '2026-10-26' }),
    );
    const req = http.expectOne(`${base}/rpc/fn_reporte_cajeros`);
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual({
      p_sucursales: null,
      p_desde: '2026-10-20',
      p_hasta: '2026-10-26',
    });
    req.flush([]);
    expect(await promesa).toEqual([]);
  });

  it('asks the cashier metrics of one shift and the shifts of the period (H4.3 T03)', async () => {
    const filtro = { sucursales: [2], desde: '2026-10-20', hasta: '2026-10-20' };
    const metricas = firstValueFrom(service.rendimientoCajeros(filtro, 7));
    const reqMetricas = http.expectOne(`${base}/rpc/fn_reporte_cajeros`);
    expect(reqMetricas.request.body).toEqual({
      p_sucursales: [2],
      p_desde: '2026-10-20',
      p_hasta: '2026-10-20',
      p_turno: 7,
    });
    reqMetricas.flush([]);
    expect(await metricas).toEqual([]);

    const turnos = firstValueFrom(service.turnosReporte(filtro));
    const reqTurnos = http.expectOne(`${base}/rpc/fn_turnos_reporte`);
    expect(reqTurnos.request.method).toBe('POST');
    expect(reqTurnos.request.body).toEqual({
      p_sucursales: [2],
      p_desde: '2026-10-20',
      p_hasta: '2026-10-20',
    });
    reqTurnos.flush([]);
    expect(await turnos).toEqual([]);
  });

  it('asks the current product costs (H4.4 T03)', async () => {
    const promesa = firstValueFrom(service.costoActualProductos());
    const req = http.expectOne(`${base}/rpc/fn_costo_actual_productos`);
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual({});
    req.flush([]);
    expect(await promesa).toEqual([]);
  });

  it('asks the products sold by branch', async () => {
    const promesa = firstValueFrom(
      service.productosVendidosSucursal({
        sucursales: [2],
        desde: '2026-10-20',
        hasta: '2026-10-26',
      }),
    );
    const req = http.expectOne(`${base}/rpc/fn_reporte_productos_sucursal`);
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual({
      p_sucursales: [2],
      p_desde: '2026-10-20',
      p_hasta: '2026-10-26',
    });
    req.flush([]);
    expect(await promesa).toEqual([]);
  });

  it.each([
    ['promocionesPorDia', 'fn_reporte_promociones_periodo'],
    ['promocionesPorProducto', 'fn_reporte_promociones_producto'],
  ] as const)('asks %s with the chosen branches and period (H5.2 T08)', async (metodo, funcion) => {
    const consultar = service[metodo].bind(service) as (
      filtro: FiltroReporteApi,
    ) => Observable<unknown[]>;
    const promesa = firstValueFrom(
      consultar({ sucursales: [], desde: '2026-11-01', hasta: '2026-11-05' }),
    );
    const req = http.expectOne(`${base}/rpc/${funcion}`);
    expect(req.request.method).toBe('POST');
    // Sin sucursales elegidas se piden todas.
    expect(req.request.body).toEqual({ p_sucursales: null, p_desde: '2026-11-01', p_hasta: '2026-11-05' });
    req.flush([]);
    expect(await promesa).toEqual([]);
  });
});
