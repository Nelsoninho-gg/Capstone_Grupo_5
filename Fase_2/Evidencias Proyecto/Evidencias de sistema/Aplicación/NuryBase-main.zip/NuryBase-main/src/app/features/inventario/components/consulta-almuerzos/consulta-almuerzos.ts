import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, computed, inject, input, signal } from '@angular/core';
import { rxResource } from '@angular/core/rxjs-interop';
import { forkJoin } from 'rxjs';
import {
  AlmuerzoConsultaApi,
  AlmuerzosApiService,
  fechaHoyChile,
} from '../../../../core/api/almuerzos-api.service';
import { SucursalApi, SucursalesApiService } from '../../../../core/api/sucursales-api.service';
import { EmpleadoApi, UsuariosApiService } from '../../../../core/api/usuarios-api.service';

type Periodo = 'hoy' | '7-dias' | '30-dias' | 'mes' | 'personalizado';

const TODOS = 'todos';

const formatoCantidad = new Intl.NumberFormat('es-CL', { maximumFractionDigits: 3 });
const formatoFecha = new Intl.DateTimeFormat('es-CL', {
  day: '2-digit',
  month: '2-digit',
  year: 'numeric',
});
const formatoHora = new Intl.DateTimeFormat('es-CL', {
  hour: '2-digit',
  minute: '2-digit',
  hourCycle: 'h23',
  timeZone: 'America/Santiago',
});

/** Fila de la tabla: un almuerzo con sus productos ya en palabras. */
export interface AlmuerzoConsultado {
  id: number;
  /** Día del almuerzo (YYYY-MM-DD, hora de Chile). */
  fecha: string;
  registradoEn: Date;
  empleado: string;
  cajero: string;
  sucursal: string;
  productos: { nombre: string; cantidad: number }[];
  unidades: number;
}

/**
 * Consulta de almuerzos de empleados para el administrador (H2.13 T07), filtrable por
 * sucursal, empleado y periodo. Es consumo interno: no muestra montos porque el almuerzo
 * no tiene precio ni medio de pago.
 */
@Component({
  selector: 'app-consulta-almuerzos',
  templateUrl: './consulta-almuerzos.html',
  styleUrls: [
    '../../styles/inventario-base.css',
    '../reporte-mermas/reporte-mermas.css',
    './consulta-almuerzos.css',
  ],
})
export class ConsultaAlmuerzos implements OnInit {
  private readonly almuerzosApi = inject(AlmuerzosApiService);
  private readonly sucursalesApi = inject(SucursalesApiService);
  private readonly usuariosApi = inject(UsuariosApiService);

  /** Cambia con cada almuerzo registrado para volver a consultar sin recargar la página. */
  readonly version = input(0);

  protected readonly periodos: { valor: Periodo; etiqueta: string }[] = [
    { valor: 'hoy', etiqueta: 'Hoy' },
    { valor: '7-dias', etiqueta: 'Últimos 7 días' },
    { valor: '30-dias', etiqueta: 'Últimos 30 días' },
    { valor: 'mes', etiqueta: 'Este mes' },
    { valor: 'personalizado', etiqueta: 'Personalizado' },
  ];

  protected readonly sucursales = signal<SucursalApi[]>([]);
  protected readonly empleados = signal<EmpleadoApi[]>([]);

  protected readonly filtroSucursal = signal(TODOS);
  protected readonly filtroEmpleado = signal(TODOS);
  protected readonly periodo = signal<Periodo>('7-dias');
  protected readonly hoy = fechaHoyChile();
  protected readonly desdePersonalizado = signal(sumarDias(this.hoy, -6));
  protected readonly hastaPersonalizado = signal(this.hoy);

  /** Rango consultado (días de Chile, como la columna fecha), o por qué no se puede consultar. */
  protected readonly rango = computed((): { desde: string; hasta: string } | { error: string } => {
    const hoy = this.hoy;
    switch (this.periodo()) {
      case 'hoy':
        return { desde: hoy, hasta: hoy };
      case '7-dias':
        return { desde: sumarDias(hoy, -6), hasta: hoy };
      case '30-dias':
        return { desde: sumarDias(hoy, -29), hasta: hoy };
      case 'mes':
        return { desde: `${hoy.slice(0, 7)}-01`, hasta: hoy };
      case 'personalizado': {
        const desde = this.desdePersonalizado();
        const hasta = this.hastaPersonalizado();
        if (!desde || !hasta) return { error: 'Indica la fecha inicial y la final.' };
        if (desde > hasta) return { error: 'La fecha inicial no puede ser posterior a la final.' };
        return { desde, hasta };
      }
    }
  });

  protected readonly errorRango = computed(() => {
    const rango = this.rango();
    return 'error' in rango ? rango.error : null;
  });

  protected readonly consulta = rxResource({
    params: () => {
      const rango = this.rango();
      if ('error' in rango) return undefined;
      const sucursal = this.filtroSucursal();
      const empleado = this.filtroEmpleado();
      return {
        sucursalId: sucursal === TODOS ? null : Number(sucursal),
        empleadoId: empleado === TODOS ? null : Number(empleado),
        ...rango,
        version: this.version(),
      };
    },
    stream: ({ params }) =>
      this.almuerzosApi.listar({
        sucursalId: params.sucursalId,
        empleadoId: params.empleadoId,
        desde: params.desde,
        hasta: params.hasta,
      }),
  });

  protected readonly almuerzos = computed<AlmuerzoConsultado[]>(() =>
    this.consulta.hasValue() ? this.consulta.value().map(almuerzoConsultado) : [],
  );
  protected readonly totalUnidades = computed(() =>
    this.almuerzos().reduce((total, almuerzo) => total + almuerzo.unidades, 0),
  );
  protected readonly totalEmpleados = computed(
    () => new Set(this.almuerzos().map((almuerzo) => almuerzo.empleado)).size,
  );
  protected readonly cargando = computed(() => this.consulta.isLoading());
  protected readonly conError = computed(() => this.consulta.status() === 'error');
  /** PostgREST responde 403 cuando el rol de la sesión no puede leer los almuerzos. */
  protected readonly sinPermiso = computed(() => {
    const error = this.consulta.error();
    return error instanceof HttpErrorResponse && error.status === 403;
  });

  protected readonly textoPeriodo = computed(() => {
    const rango = this.rango();
    if ('error' in rango) return '';
    const desde = this.formatearDia(rango.desde);
    const hasta = this.formatearDia(rango.hasta);
    return desde === hasta ? `el ${desde}` : `del ${desde} al ${hasta}`;
  });

  ngOnInit(): void {
    // Los filtros se pueden usar aunque estas listas fallen: la consulta no depende de ellas.
    forkJoin({
      sucursales: this.sucursalesApi.listarActivas(),
      empleados: this.usuariosApi.listarEmpleados(),
    }).subscribe({
      next: ({ sucursales, empleados }) => {
        this.sucursales.set(sucursales);
        this.empleados.set(empleados);
      },
      error: () => {},
    });
  }

  protected reintentar(): void {
    this.consulta.reload();
  }

  protected actualizarSucursal(event: Event): void {
    this.filtroSucursal.set((event.target as HTMLSelectElement).value);
  }

  protected actualizarEmpleado(event: Event): void {
    this.filtroEmpleado.set((event.target as HTMLSelectElement).value);
  }

  protected actualizarPeriodo(event: Event): void {
    this.periodo.set((event.target as HTMLSelectElement).value as Periodo);
  }

  protected actualizarDesde(event: Event): void {
    this.desdePersonalizado.set((event.target as HTMLInputElement).value);
  }

  protected actualizarHasta(event: Event): void {
    this.hastaPersonalizado.set((event.target as HTMLInputElement).value);
  }

  protected contar(cantidad: number, singular: string, plural: string): string {
    return `${cantidad} ${cantidad === 1 ? singular : plural}`;
  }

  protected formatearCantidad(cantidad: number): string {
    return formatoCantidad.format(cantidad);
  }

  /** "2026-10-22" → "22-10-2026", sin pasar por la zona horaria del navegador. */
  protected formatearDia(dia: string): string {
    const [anio, mes, numero] = dia.split('-').map(Number);
    return formatoFecha.format(new Date(anio, mes - 1, numero));
  }

  protected formatearHora(fecha: Date): string {
    return formatoHora.format(fecha);
  }
}

export function almuerzoConsultado(fila: AlmuerzoConsultaApi): AlmuerzoConsultado {
  const productos = fila.detalle.map((linea) => ({
    nombre: linea.producto?.nombre ?? 'Producto eliminado',
    cantidad: Number(linea.cantidad),
  }));
  return {
    id: fila.id,
    fecha: fila.fecha,
    registradoEn: fechaDeLaBase(fila.creado_en),
    empleado: fila.empleado?.nombre ?? `Usuario #${fila.empleado_id}`,
    cajero: fila.cajero?.nombre ?? '—',
    sucursal: fila.sucursal?.nombre ?? '—',
    productos,
    unidades: productos.reduce((total, producto) => total + producto.cantidad, 0),
  };
}

/** creado_en es TIMESTAMP sin zona con hora UTC (como en movimientos): se lee como UTC. */
function fechaDeLaBase(texto: string): Date {
  return new Date(/(Z|[+-]\d{2}(:?\d{2})?)$/.test(texto) ? texto : `${texto}Z`);
}

/** Suma días a una fecha YYYY-MM-DD sin depender de la zona del navegador. */
function sumarDias(dia: string, dias: number): string {
  const [anio, mes, numero] = dia.split('-').map(Number);
  const fecha = new Date(Date.UTC(anio, mes - 1, numero + dias));
  return fecha.toISOString().slice(0, 10);
}
