import { ProductoVendido, ResumenSucursal } from './reportes.model';

/** Totales de todas las sucursales del reporte, para las tarjetas de arriba. */
export interface TotalesReporte {
  ventas: number;
  total: number;
  ticketPromedio: number;
  anuladas: number;
  totalAnuladas: number;
}

export function totalesReporte(resumenes: readonly ResumenSucursal[]): TotalesReporte {
  const ventas = suma(resumenes, (r) => r.ventas);
  const total = suma(resumenes, (r) => r.total);
  return {
    ventas,
    total,
    ticketPromedio: ventas ? Math.round((total / ventas) * 100) / 100 : 0,
    anuladas: suma(resumenes, (r) => r.anuladas.ventas),
    totalAnuladas: suma(resumenes, (r) => r.anuladas.total),
  };
}

/**
 * Variación porcentual contra el período anterior, con un decimal. null cuando antes no hubo
 * nada: no hay base para un porcentaje.
 */
export function variacion(actual: number, anterior: number): number | null {
  if (!anterior) return null;
  return Math.round(((actual - anterior) / anterior) * 1000) / 10;
}

const MEDIOS: Record<string, string> = {
  efectivo: 'Efectivo',
  debito: 'Débito',
  credito: 'Crédito',
  // Junaeb se paga con Pluxee o Edenred. Pluxee se guarda como 'sodexo' en ventas.medio_pago (ver caja.model.ts).
  sodexo: 'Pluxee (Junaeb)',
  edenred: 'Edenred (Junaeb)',
  transferencia: 'Transferencia',
  sin_medio: 'Sin medio',
};

/** Orden fijo de los medios de pago, para que los colores y leyendas no cambien de lugar. */
export const ORDEN_MEDIOS = Object.keys(MEDIOS);

export function etiquetaMedio(medio: string): string {
  return MEDIOS[medio] ?? medio.charAt(0).toUpperCase() + medio.slice(1);
}

/** Medios de pago presentes en el reporte, en el orden fijo y luego los desconocidos. */
export function mediosPresentes(resumenes: readonly ResumenSucursal[]): string[] {
  const presentes = new Set(resumenes.flatMap((r) => Object.keys(r.mediosPago)));
  return [
    ...ORDEN_MEDIOS.filter((medio) => presentes.has(medio)),
    ...[...presentes].filter((medio) => !ORDEN_MEDIOS.includes(medio)).sort(),
  ];
}

/** Porcentaje (0–100) de un valor respecto del mayor, para el largo de las barras. */
export function proporcion(valor: number, maximo: number): number {
  return maximo > 0 ? Math.max(0, Math.min(100, (valor / maximo) * 100)) : 0;
}

export type OrdenProductos = 'monto' | 'unidades' | 'ventas';

/** Un producto con las sucursales elegidas juntas. */
export interface ProductoAgrupado {
  productoId: number;
  producto: string;
  categoria: string | null;
  unidades: number;
  ventas: number;
  monto: number;
}

/** Junta el mismo producto de varias sucursales: suma unidades, ventas y monto. */
export function agruparProductos(productos: readonly ProductoVendido[]): ProductoAgrupado[] {
  const porProducto = new Map<number, ProductoAgrupado>();
  for (const fila of productos) {
    const actual = porProducto.get(fila.productoId) ?? {
      productoId: fila.productoId,
      producto: fila.producto,
      categoria: fila.categoria,
      unidades: 0,
      ventas: 0,
      monto: 0,
    };
    actual.unidades += fila.unidades;
    actual.ventas += fila.ventas;
    actual.monto += fila.monto;
    porProducto.set(fila.productoId, actual);
  }
  return [...porProducto.values()];
}

/** Ordena de mayor a menor por la métrica y, en empate, por nombre. */
export function ordenarProductos(
  productos: readonly ProductoAgrupado[],
  orden: OrdenProductos,
): ProductoAgrupado[] {
  return [...productos].sort(
    (a, b) => b[orden] - a[orden] || a.producto.localeCompare(b.producto, 'es'),
  );
}

/** Los más vendidos del reporte, juntando las sucursales elegidas. */
export function productosDestacados(
  productos: readonly ProductoVendido[],
  orden: OrdenProductos,
  limite = 10,
): ProductoAgrupado[] {
  return ordenarProductos(agruparProductos(productos), orden).slice(0, limite);
}

/** Texto sin tildes ni mayúsculas, para buscar "cafe" y encontrar "Café". */
export function normalizar(texto: string): string {
  return texto
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim();
}

function suma<T>(filas: readonly T[], valor: (fila: T) => number): number {
  return Math.round(filas.reduce((total, fila) => total + valor(fila), 0) * 100) / 100;
}
