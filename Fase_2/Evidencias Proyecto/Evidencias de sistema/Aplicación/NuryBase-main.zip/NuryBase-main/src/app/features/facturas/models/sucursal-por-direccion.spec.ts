import { detectarSucursal } from './sucursal-por-direccion';

// Direcciones tal como vienen en una factura real de CCU (01-11-2026): el proveedor perdió
// la ñ y la í, que llegan como dos espacios.
const CCU = {
  direccion_despacho: 'Los Placeres401, Valpara  so 1680, VALPARAISO',
  direccion_receptor: 'AVENIDA ESPA  A 1680, VALPARAISO',
};

const PLACERES = { id: 1, nombre: 'Nury Los Placeres', direccion: 'Av. Los Placeres 401, Valparaíso' };
const ESPANA = { id: 2, nombre: 'Nury España', direccion: 'Avenida España 1680, Valparaíso' };
const PROVIDENCIA = { id: 3, nombre: 'Nury Providencia', direccion: 'Av. Providencia 1680, Providencia' };

describe('detectarSucursal', () => {
  it('prefers the delivery address over the billing one', () => {
    expect(detectarSucursal(CCU, [ESPANA, PLACERES, PROVIDENCIA])).toEqual({
      ids: [1],
      origen: 'despacho',
      direccion: CCU.direccion_despacho,
    });
  });

  it('falls back to the billing address, even with the letters the supplier lost', () => {
    expect(detectarSucursal(CCU, [ESPANA, PROVIDENCIA])).toEqual({
      ids: [2],
      origen: 'receptor',
      direccion: CCU.direccion_receptor,
    });
  });

  it('needs the same street, not only the same number or the same city', () => {
    // «Valpara  so 1680» del despacho no es la calle España 1680, aunque comparta número y comuna.
    expect(detectarSucursal({ ...CCU, direccion_receptor: null }, [ESPANA])).toBeNull();
    expect(detectarSucursal(CCU, [PROVIDENCIA])).toBeNull();
    expect(detectarSucursal(CCU, [{ ...PLACERES, direccion: 'Los Placeres 410, Valparaíso' }])).toBeNull();
  });

  it('returns every branch that shares the address', () => {
    // Dos locales en el mismo campus, como están registrados («AVDA, Playa Ancha 850»).
    const ciencias = { id: 8, nombre: "Nury's UPLA Ciencias", direccion: 'AVDA, Playa Ancha 850' };
    const central = { id: 9, nombre: "Nury's UPLA Casa Central", direccion: 'AVDA, Playa Ancha 850' };
    const factura = { direccion_despacho: 'AV. PLAYA ANCHA 850, VALPARAISO', direccion_receptor: null };

    expect(detectarSucursal(factura, [PLACERES, ciencias, central])?.ids).toEqual([8, 9]);
  });

  it('returns null without addresses on either side', () => {
    expect(detectarSucursal({ direccion_despacho: null, direccion_receptor: null }, [PLACERES])).toBeNull();
    expect(detectarSucursal(CCU, [{ id: 5, nombre: 'Sin dirección', direccion: null }])).toBeNull();
    expect(detectarSucursal(CCU, [{ id: 6, nombre: 'Sin dirección registrada' }])).toBeNull();
  });
});
