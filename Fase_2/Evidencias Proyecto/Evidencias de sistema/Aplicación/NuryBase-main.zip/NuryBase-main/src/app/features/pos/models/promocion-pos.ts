import { PromocionApi } from '../../../core/api/promociones-api.service';
import { CartItem, PosProduct } from './pos.model';

/** Producto de una promoción con su precio de lista y el precio con descuento, por unidad. */
export interface PrecioPromocion {
  producto: PosProduct;
  /** Unidades del producto en una aplicación de la promoción (1 sándwich + 1 café). */
  cantidad: number;
  precioLista: number;
  precioUnitario: number;
}

/** Promoción aplicada a la comanda: sus productos se agregan juntos, `veces` veces. */
export interface PromocionAplicada {
  promocion: PromocionApi;
  veces: number;
}

/**
 * Precio de cada producto de la promoción (H5.2 T05). Es la misma regla que aplica la base al
 * registrar la venta (fn_precios_promocion, 20261105_promociones_venta.sql); la base vuelve a
 * calcularlo y no usa el precio que envía el POS:
 *   porcentaje  precio × (100 − %) / 100, redondeado a pesos.
 *   monto_fijo  el monto (como máximo el valor de la promoción) se reparte según el precio de
 *               lista, redondeado; el resto del redondeo va al producto más caro con cantidad 1.
 * Devuelve null si algún producto no está en el catálogo del POS (inactivo): no se puede aplicar.
 */
export function preciosPromocion(
  promocion: PromocionApi,
  catalogo: ReadonlyMap<number, PosProduct>,
): PrecioPromocion[] | null {
  const base = promocion.productos.map((linea) => ({
    producto: catalogo.get(linea.producto_id),
    cantidad: linea.cantidad,
  }));
  if (!base.length || base.some((linea) => !linea.producto)) return null;

  const lineas = base.map((linea) => ({
    producto: linea.producto!,
    cantidad: linea.cantidad,
    precio: linea.producto!.precioVenta,
  }));
  const valor = Number(promocion.valor_descuento);
  const total = lineas.reduce((suma, linea) => suma + linea.precio * linea.cantidad, 0);

  const descuentos = new Map<number, number>();
  if (promocion.tipo === 'porcentaje') {
    for (const linea of lineas) {
      descuentos.set(linea.producto.id, linea.precio - Math.round((linea.precio * (100 - valor)) / 100));
    }
  } else if (total > 0) {
    const monto = Math.min(valor, total);
    for (const linea of lineas) {
      descuentos.set(linea.producto.id, Math.round((monto * linea.precio) / total));
    }
    const repartido = lineas.reduce(
      (suma, linea) => suma + descuentos.get(linea.producto.id)! * linea.cantidad,
      0,
    );
    const resto = monto - repartido;
    const ajustado = lineas
      .filter((linea) => linea.cantidad === 1)
      .sort((a, b) => b.precio - a.precio || a.producto.id - b.producto.id)[0];
    if (resto !== 0 && ajustado) {
      descuentos.set(ajustado.producto.id, descuentos.get(ajustado.producto.id)! + resto);
    }
  }

  return lineas
    .map((linea) => {
      const descuento = Math.min(descuentos.get(linea.producto.id) ?? 0, linea.precio);
      return {
        producto: linea.producto,
        cantidad: linea.cantidad,
        precioLista: linea.precio,
        precioUnitario: Math.max(linea.precio - descuento, 0),
      };
    })
    .sort((a, b) => a.producto.id - b.producto.id);
}

/** Líneas de la comanda que aporta una promoción aplicada `veces` veces. */
export function lineasDePromocion(
  aplicada: PromocionAplicada,
  catalogo: ReadonlyMap<number, PosProduct>,
): CartItem[] {
  const precios = preciosPromocion(aplicada.promocion, catalogo) ?? [];
  return precios.map((precio) => {
    const cantidad = precio.cantidad * aplicada.veces;
    return {
      producto: precio.producto,
      cantidad,
      subtotal: precio.precioUnitario * cantidad,
      precioUnitario: precio.precioUnitario,
      promocion: { id: aplicada.promocion.id, nombre: aplicada.promocion.nombre },
    };
  });
}

/** Lo que descuenta la comanda por promociones (precio de lista − cobrado). */
export function descuentoPorPromociones(items: CartItem[]): number {
  return items
    .filter((item) => item.promocion)
    .reduce((suma, item) => suma + item.producto.precioVenta * item.cantidad - item.subtotal, 0);
}
