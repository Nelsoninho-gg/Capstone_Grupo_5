import { provideHttpClient } from '@angular/common/http';
import {
  HttpTestingController,
  provideHttpClientTesting,
} from '@angular/common/http/testing';
import { signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { describe, expect, it } from 'vitest';
import { environment } from '../../../environments/environment';
import { AuthService } from '../../features/auth/services/auth.service';
import { ConexionService } from '../services/conexion.service';
import {
  OrquestadorIaService,
  SinProveedoresIAError,
} from './orquestador-ia.service';
import {
  IA_PROVEEDORES,
  IA_RELOJ,
  MensajesIA,
  ProveedorIAConfig,
} from './proveedores-ia.config';

describe('OrquestadorIaService (H4.5 T06)', () => {
  let service: OrquestadorIaService;
  let httpMock: HttpTestingController;
  let tiempoActual = 1000000;
  const mockReloj = () => tiempoActual;
  const conexionEnLineaSignal = signal(true);

  const mockAuthService = {
    getToken: () => 'jwt-valido-nury',
  };

  const mockConexionService = {
    enLinea: conexionEnLineaSignal,
  };

  const proveedoresPrueba: ProveedorIAConfig[] = [
    {
      id: 'gemini-primario',
      formato: 'gemini',
      modelo: 'gemini-flash',
      baseUrl: `${environment.apiUrl}/ia/gemini/v1beta`,
      autenticacion: 'sesion-nury',
      timeoutMs: 5000,
    },
    {
      id: 'respaldo-secundario',
      formato: 'openai-compatible',
      modelo: 'llama-3.3-70b',
      baseUrl: `${environment.apiUrl}/ia/respaldo/v1`,
      autenticacion: 'sesion-nury',
      timeoutMs: 5000,
    },
    {
      id: 'openrouter-terciario',
      formato: 'openai-compatible',
      modelo: 'gemini-free',
      baseUrl: `${environment.apiUrl}/ia/openrouter/api/v1`,
      autenticacion: 'sesion-nury',
      timeoutMs: 5000,
    },
  ];

  const mensajesPrueba: MensajesIA = {
    sistema: 'Instrucciones del sistema',
    usuario: '{"articulos": []}',
  };

  function configurarTestBed(proveedores: readonly ProveedorIAConfig[] = proveedoresPrueba) {
    tiempoActual = 1000000;
    conexionEnLineaSignal.set(true);

    TestBed.configureTestingModule({
      providers: [
        provideHttpClient(),
        provideHttpClientTesting(),
        OrquestadorIaService,
        { provide: IA_PROVEEDORES, useValue: proveedores },
        { provide: IA_RELOJ, useValue: mockReloj },
        { provide: AuthService, useValue: mockAuthService },
        { provide: ConexionService, useValue: mockConexionService },
      ],
    });

    service = TestBed.inject(OrquestadorIaService);
    httpMock = TestBed.inject(HttpTestingController);
  }

  afterEach(() => {
    httpMock.verify();
  });

  it('usa el primer proveedor cuando responde exitosamente (200 OK)', () => {
    configurarTestBed();

    let resultado: any;
    service.solicitar(mensajesPrueba).subscribe((res) => {
      resultado = res;
    });

    const req = httpMock.expectOne(
      `${environment.apiUrl}/ia/gemini/v1beta/models/gemini-flash:generateContent`,
    );
    expect(req.request.method).toBe('POST');
    expect(req.request.headers.get('Authorization')).toBe('Bearer jwt-valido-nury');

    req.flush({
      candidates: [
        {
          content: {
            parts: [{ text: '{"predicciones": []}' }],
          },
        },
      ],
    });

    expect(resultado).toBeDefined();
    expect(resultado.proveedorId).toBe('gemini-primario');
    expect(resultado.modelo).toBe('gemini-flash');
    expect(resultado.contenido).toBe('{"predicciones": []}');
    expect(resultado.intentos).toHaveLength(1);
    expect(resultado.intentos[0].exitoso).toBe(true);
  });

  it('rota automáticamente al segundo proveedor cuando el primero devuelve HTTP 429 Too Many Requests', () => {
    configurarTestBed();

    let resultado: any;
    service.solicitar(mensajesPrueba).subscribe((res) => {
      resultado = res;
    });

    // Petición al primer proveedor falla con 429
    const req1 = httpMock.expectOne(
      `${environment.apiUrl}/ia/gemini/v1beta/models/gemini-flash:generateContent`,
    );
    req1.flush('Cuota diaria agotada', {
      status: 429,
      statusText: 'Too Many Requests',
    });

    // Automáticamente salta al segundo proveedor
    const req2 = httpMock.expectOne(
      `${environment.apiUrl}/ia/respaldo/v1/chat/completions`,
    );
    expect(req2.request.method).toBe('POST');
    req2.flush({
      choices: [
        {
          message: {
            content: '{"predicciones": [{"articuloId": "1"}]}',
          },
        },
      ],
    });

    expect(resultado).toBeDefined();
    expect(resultado.proveedorId).toBe('respaldo-secundario');
    expect(resultado.modelo).toBe('llama-3.3-70b');
    expect(resultado.intentos).toHaveLength(2);
    expect(resultado.intentos[0].proveedorId).toBe('gemini-primario');
    expect(resultado.intentos[0].exitoso).toBe(false);
    expect(resultado.intentos[0].codigoEstado).toBe(429);
    expect(resultado.intentos[1].proveedorId).toBe('respaldo-secundario');
    expect(resultado.intentos[1].exitoso).toBe(true);

    // Comprobar que el primer proveedor quedó en enfriamiento
    const estados = service.estadoProveedores();
    expect(estados[0].id).toBe('gemini-primario');
    expect(estados[0].disponible).toBe(false);
    expect(estados[0].enfriandoHasta).toBe(tiempoActual + 60 * 1000);
    expect(estados[1].disponible).toBe(true);
  });

  it('salta de inmediato el proveedor en enfriamiento en peticiones subsiguientes', () => {
    configurarTestBed();

    // 1ra solicitud: primer proveedor falla con 429
    service.solicitar(mensajesPrueba).subscribe();
    httpMock
      .expectOne(
        `${environment.apiUrl}/ia/gemini/v1beta/models/gemini-flash:generateContent`,
      )
      .flush('Quota exceeded', { status: 429, statusText: 'Too Many Requests' });
    httpMock
      .expectOne(`${environment.apiUrl}/ia/respaldo/v1/chat/completions`)
      .flush({
        choices: [{ message: { content: '{"ok": true}' } }],
      });

    // 2da solicitud: gemini-primario está en enfriamiento, debe ir DIRECTO a respaldo-secundario
    let resultado2: any;
    service.solicitar(mensajesPrueba).subscribe((res) => {
      resultado2 = res;
    });

    // No debe existir petición a gemini-primario
    httpMock.expectNone(
      `${environment.apiUrl}/ia/gemini/v1beta/models/gemini-flash:generateContent`,
    );
    const reqSub = httpMock.expectOne(
      `${environment.apiUrl}/ia/respaldo/v1/chat/completions`,
    );
    reqSub.flush({
      choices: [{ message: { content: '{"ok": 2}' } }],
    });

    expect(resultado2.proveedorId).toBe('respaldo-secundario');
    expect(resultado2.intentos).toHaveLength(1);
    expect(resultado2.intentos[0].proveedorId).toBe('respaldo-secundario');
  });

  it('vuelve a intentar con el primer proveedor cuando el tiempo de enfriamiento expira', () => {
    configurarTestBed();

    // Provocamos enfriamiento de 60s en gemini
    service.solicitar(mensajesPrueba).subscribe();
    httpMock
      .expectOne(
        `${environment.apiUrl}/ia/gemini/v1beta/models/gemini-flash:generateContent`,
      )
      .flush('Quota exceeded', { status: 429, statusText: 'Too Many Requests' });
    httpMock
      .expectOne(`${environment.apiUrl}/ia/respaldo/v1/chat/completions`)
      .flush({
        choices: [{ message: { content: '{"ok": 1}' } }],
      });

    // Adelantamos el reloj 61 segundos
    tiempoActual += 61 * 1000;

    // Próxima petición debe intentar gemini-primario nuevamente
    let resultado: any;
    service.solicitar(mensajesPrueba).subscribe((res) => {
      resultado = res;
    });

    const reqGemini = httpMock.expectOne(
      `${environment.apiUrl}/ia/gemini/v1beta/models/gemini-flash:generateContent`,
    );
    reqGemini.flush({
      candidates: [{ content: { parts: [{ text: '{"recuperado": true}' }] } }],
    });

    expect(resultado.proveedorId).toBe('gemini-primario');
  });

  it('respeta la cabecera Retry-After en segundos en caso de HTTP 429', () => {
    configurarTestBed();

    service.solicitar(mensajesPrueba).subscribe();
    const req1 = httpMock.expectOne(
      `${environment.apiUrl}/ia/gemini/v1beta/models/gemini-flash:generateContent`,
    );
    req1.flush('Wait', {
      status: 429,
      statusText: 'Too Many Requests',
      headers: { 'Retry-After': '120' },
    });
    httpMock
      .expectOne(`${environment.apiUrl}/ia/respaldo/v1/chat/completions`)
      .flush({
        choices: [{ message: { content: '{"ok": true}' } }],
      });

    const estados = service.estadoProveedores();
    expect(estados[0].enfriandoHasta).toBe(tiempoActual + 120 * 1000);
  });

  it('aplica 30 segundos de enfriamiento ante HTTP 500 / 503 o errores de red (status 0)', () => {
    configurarTestBed();

    service.solicitar(mensajesPrueba).subscribe();
    httpMock
      .expectOne(
        `${environment.apiUrl}/ia/gemini/v1beta/models/gemini-flash:generateContent`,
      )
      .flush('Server error', { status: 503, statusText: 'Service Unavailable' });
    httpMock
      .expectOne(`${environment.apiUrl}/ia/respaldo/v1/chat/completions`)
      .flush({
        choices: [{ message: { content: '{"ok": true}' } }],
      });

    const estados = service.estadoProveedores();
    expect(estados[0].enfriandoHasta).toBe(tiempoActual + 30 * 1000);
  });

  it('aplica 1 hora de enfriamiento ante HTTP 401 / 403 (clave errónea o rol no autorizado) o 404 (ruta Caddy no creada)', () => {
    configurarTestBed();

    service.solicitar(mensajesPrueba).subscribe();
    httpMock
      .expectOne(
        `${environment.apiUrl}/ia/gemini/v1beta/models/gemini-flash:generateContent`,
      )
      .flush('Not Found', { status: 404, statusText: 'Not Found' });
    httpMock
      .expectOne(`${environment.apiUrl}/ia/respaldo/v1/chat/completions`)
      .flush({
        choices: [{ message: { content: '{"ok": true}' } }],
      });

    const estados = service.estadoProveedores();
    expect(estados[0].enfriandoHasta).toBe(tiempoActual + 60 * 60 * 1000);
  });

  it('ante HTTP 400 pasa al siguiente proveedor sin aplicar enfriamiento', () => {
    configurarTestBed();

    service.solicitar(mensajesPrueba).subscribe();
    httpMock
      .expectOne(
        `${environment.apiUrl}/ia/gemini/v1beta/models/gemini-flash:generateContent`,
      )
      .flush('Bad request', { status: 400, statusText: 'Bad Request' });
    httpMock
      .expectOne(`${environment.apiUrl}/ia/respaldo/v1/chat/completions`)
      .flush({
        choices: [{ message: { content: '{"ok": true}' } }],
      });

    const estados = service.estadoProveedores();
    expect(estados[0].disponible).toBe(true);
    expect(estados[0].enfriandoHasta).toBeNull();
  });

  it('ante una respuesta 200 con contenido vacío rota al siguiente y aplica 30s de enfriamiento', () => {
    configurarTestBed();

    let resultado: any;
    service.solicitar(mensajesPrueba).subscribe((res) => {
      resultado = res;
    });

    // Gemini responde 200 pero sin texto utilizable
    httpMock
      .expectOne(
        `${environment.apiUrl}/ia/gemini/v1beta/models/gemini-flash:generateContent`,
      )
      .flush({ candidates: [] });

    // Salta al proveedor secundario
    httpMock
      .expectOne(`${environment.apiUrl}/ia/respaldo/v1/chat/completions`)
      .flush({
        choices: [{ message: { content: '{"contenido": "valido"}' } }],
      });

    expect(resultado.proveedorId).toBe('respaldo-secundario');
    const estados = service.estadoProveedores();
    // Respondió 200: una respuesta vacía no debe sacarlo de la cadena en la siguiente ronda.
    expect(estados[0].disponible).toBe(true);
    expect(estados[0].enfriandoHasta).toBeNull();
  });

  it('emite SinProveedoresIAError(agotados) con la lista completa de intentos si todos fallan', () => {
    configurarTestBed();

    let errorRecibido: any;
    service.solicitar(mensajesPrueba).subscribe({
      error: (err) => {
        errorRecibido = err;
      },
    });

    httpMock
      .expectOne(
        `${environment.apiUrl}/ia/gemini/v1beta/models/gemini-flash:generateContent`,
      )
      .flush('Error 1', { status: 500, statusText: 'Server error' });
    httpMock
      .expectOne(`${environment.apiUrl}/ia/respaldo/v1/chat/completions`)
      .flush('Error 2', { status: 429, statusText: 'Too many' });
    httpMock
      .expectOne(`${environment.apiUrl}/ia/openrouter/api/v1/chat/completions`)
      .flush('Error 3', { status: 502, statusText: 'Bad Gateway' });

    expect(errorRecibido).toBeInstanceOf(SinProveedoresIAError);
    expect(errorRecibido.motivo).toBe('agotados');
    expect(errorRecibido.intentos).toHaveLength(3);
    expect(errorRecibido.intentos[0].proveedorId).toBe('gemini-primario');
    expect(errorRecibido.intentos[1].proveedorId).toBe('respaldo-secundario');
    expect(errorRecibido.intentos[2].proveedorId).toBe('openrouter-terciario');
  });

  it('falla inmediatamente con SinProveedoresIAError(sin-conexion) si el navegador está offline sin hacer peticiones', () => {
    configurarTestBed();
    conexionEnLineaSignal.set(false);

    let errorRecibido: any;
    service.solicitar(mensajesPrueba).subscribe({
      error: (err) => {
        errorRecibido = err;
      },
    });

    httpMock.expectNone(`${environment.apiUrl}/ia/gemini/v1beta/models/gemini-flash:generateContent`);
    expect(errorRecibido).toBeInstanceOf(SinProveedoresIAError);
    expect(errorRecibido.motivo).toBe('sin-conexion');
    expect(errorRecibido.intentos).toHaveLength(0);
  });

  it('falla inmediatamente con SinProveedoresIAError(sin-configuracion) si no hay proveedores inyectados', () => {
    configurarTestBed([]);

    let errorRecibido: any;
    service.solicitar(mensajesPrueba).subscribe({
      error: (err) => {
        errorRecibido = err;
      },
    });

    expect(errorRecibido).toBeInstanceOf(SinProveedoresIAError);
    expect(errorRecibido.motivo).toBe('sin-configuracion');
  });

  it('limpiarEnfriamientos restaura de inmediato todos los proveedores', () => {
    configurarTestBed();

    service.solicitar(mensajesPrueba).subscribe();
    httpMock
      .expectOne(
        `${environment.apiUrl}/ia/gemini/v1beta/models/gemini-flash:generateContent`,
      )
      .flush('429', { status: 429, statusText: 'Too many' });
    httpMock
      .expectOne(`${environment.apiUrl}/ia/respaldo/v1/chat/completions`)
      .flush({ choices: [{ message: { content: '{}' } }] });

    expect(service.estadoProveedores()[0].disponible).toBe(false);

    service.limpiarEnfriamientos();
    expect(service.estadoProveedores()[0].disponible).toBe(true);
  });

  it('respeta la cabecera Retry-After en formato fecha HTTP (Date.parse)', () => {
    configurarTestBed();

    service.solicitar(mensajesPrueba).subscribe();
    const fechaFutura = new Date(tiempoActual + 180 * 1000).toUTCString();
    httpMock
      .expectOne(
        `${environment.apiUrl}/ia/gemini/v1beta/models/gemini-flash:generateContent`,
      )
      .flush('Wait', {
        status: 429,
        statusText: 'Too Many Requests',
        headers: { 'Retry-After': fechaFutura },
      });
    httpMock
      .expectOne(`${environment.apiUrl}/ia/respaldo/v1/chat/completions`)
      .flush({
        choices: [{ message: { content: '{"ok": true}' } }],
      });

    const estados = service.estadoProveedores();
    expect(estados[0].enfriandoHasta).toBe(Date.parse(fechaFutura));
  });

  it('si todos los proveedores ya están en enfriamiento antes de solicitar, falla sin peticiones HTTP', () => {
    configurarTestBed();

    // Ponemos los 3 proveedores en enfriamiento
    service.solicitar(mensajesPrueba).subscribe({ error: () => {} });
    httpMock
      .expectOne(`${environment.apiUrl}/ia/gemini/v1beta/models/gemini-flash:generateContent`)
      .flush('Err 1', { status: 503, statusText: 'Err' });
    httpMock
      .expectOne(`${environment.apiUrl}/ia/respaldo/v1/chat/completions`)
      .flush('Err 2', { status: 503, statusText: 'Err' });
    httpMock
      .expectOne(`${environment.apiUrl}/ia/openrouter/api/v1/chat/completions`)
      .flush('Err 3', { status: 503, statusText: 'Err' });

    // Segunda solicitud inmediata
    let errorRecibido: any;
    service.solicitar(mensajesPrueba).subscribe({
      error: (err) => {
        errorRecibido = err;
      },
    });

    // Ninguna petición debe generarse
    httpMock.expectNone(`${environment.apiUrl}/ia/gemini/v1beta/models/gemini-flash:generateContent`);
    httpMock.expectNone(`${environment.apiUrl}/ia/respaldo/v1/chat/completions`);
    httpMock.expectNone(`${environment.apiUrl}/ia/openrouter/api/v1/chat/completions`);

    expect(errorRecibido).toBeInstanceOf(SinProveedoresIAError);
    expect(errorRecibido.motivo).toBe('agotados');
  });

  it('salta de forma segura proveedores con error de preparación (ej. url externa con sesion-nury)', () => {
    const proveedoresConUnoInvalido: ProveedorIAConfig[] = [
      {
        id: 'invalido-externo',
        formato: 'gemini',
        modelo: 'gemini-flash',
        baseUrl: 'https://generativelanguage.googleapis.com', // Inseguro con sesion-nury
        autenticacion: 'sesion-nury',
      },
      {
        id: 'valido-secundario',
        formato: 'openai-compatible',
        modelo: 'llama-3.3-70b',
        baseUrl: `${environment.apiUrl}/ia/respaldo/v1`,
        autenticacion: 'sesion-nury',
      },
    ];

    configurarTestBed(proveedoresConUnoInvalido);

    let resultado: any;
    service.solicitar(mensajesPrueba).subscribe((res) => {
      resultado = res;
    });

    // No debe llamar al inválido externo
    httpMock.expectNone('https://generativelanguage.googleapis.com');

    // Debe llamar al válido secundario
    const req = httpMock.expectOne(
      `${environment.apiUrl}/ia/respaldo/v1/chat/completions`,
    );
    req.flush({
      choices: [{ message: { content: '{"ok": true}' } }],
    });

    expect(resultado.proveedorId).toBe('valido-secundario');
    expect(resultado.intentos).toHaveLength(2);
    expect(resultado.intentos[0].proveedorId).toBe('invalido-externo');
    expect(resultado.intentos[0].exitoso).toBe(false);
    expect(resultado.intentos[1].proveedorId).toBe('valido-secundario');
    expect(resultado.intentos[1].exitoso).toBe(true);
  });

  it('calcularTiempoEnfriamiento maneja correctamente todas las causas y códigos de estado', () => {
    configurarTestBed();
    const t0 = 500000;

    // 429 sin retry-after -> 60s
    expect(service.calcularTiempoEnfriamiento({ status: 429 }, t0)).toBe(t0 + 60000);

    // 429 con retry-after inválido -> 60s
    expect(
      service.calcularTiempoEnfriamiento(
        { status: 429, headers: { get: () => 'invalido' } },
        t0,
      ),
    ).toBe(t0 + 60000);

    // 401 y 403 -> 1 hora
    expect(service.calcularTiempoEnfriamiento({ status: 401 }, t0)).toBe(t0 + 3600000);
    expect(service.calcularTiempoEnfriamiento({ status: 403 }, t0)).toBe(t0 + 3600000);

    // 404 -> 1 hora
    expect(service.calcularTiempoEnfriamiento({ status: 404 }, t0)).toBe(t0 + 3600000);

    // 400 y 422 -> 0 (sin enfriamiento)
    expect(service.calcularTiempoEnfriamiento({ status: 400 }, t0)).toBe(0);
    expect(service.calcularTiempoEnfriamiento({ status: 422 }, t0)).toBe(0);

    // 500, 502, 503, 529 (overloaded) -> 30s
    expect(service.calcularTiempoEnfriamiento({ status: 500 }, t0)).toBe(t0 + 30000);
    expect(service.calcularTiempoEnfriamiento({ status: 502 }, t0)).toBe(t0 + 30000);
    expect(service.calcularTiempoEnfriamiento({ status: 503 }, t0)).toBe(t0 + 30000);
    expect(service.calcularTiempoEnfriamiento({ status: 529 }, t0)).toBe(t0 + 30000);

    // 429 con headers en objeto plano (sin función get)
    expect(
      service.calcularTiempoEnfriamiento(
        { status: 429, headers: { 'Retry-After': '45' } },
        t0,
      ),
    ).toBe(t0 + 45000);
    expect(
      service.calcularTiempoEnfriamiento(
        { status: 429, headers: { 'retry-after': '25' } },
        t0,
      ),
    ).toBe(t0 + 25000);

    // Status 0 -> 30s
    expect(service.calcularTiempoEnfriamiento({ status: 0 }, t0)).toBe(t0 + 30000);

    // Timeout de RxJS / objeto TimeoutError -> 30s
    expect(service.calcularTiempoEnfriamiento({ name: 'TimeoutError' }, t0)).toBe(t0 + 30000);

    // Error no HTTP -> 30s
    expect(service.calcularTiempoEnfriamiento(new Error('desconocido'), t0)).toBe(t0 + 30000);
  });

  it('estadoProveedores limpia los enfriamientos expirados al ser consultado', () => {
    configurarTestBed();

    // Falla 429 para ponerlo en enfriamiento 60s
    service.solicitar(mensajesPrueba).subscribe();
    httpMock
      .expectOne(`${environment.apiUrl}/ia/gemini/v1beta/models/gemini-flash:generateContent`)
      .flush('429', { status: 429, statusText: 'Too many' });
    httpMock
      .expectOne(`${environment.apiUrl}/ia/respaldo/v1/chat/completions`)
      .flush({ choices: [{ message: { content: '{}' } }] });

    expect(service.estadoProveedores()[0].disponible).toBe(false);

    // Adelantamos el reloj más allá de los 60s
    tiempoActual += 65 * 1000;

    // Al consultar estadoProveedores, se debe purgar el enfriamiento expirado
    const estados = service.estadoProveedores();
    expect(estados[0].disponible).toBe(true);
    expect(estados[0].enfriandoHasta).toBeNull();
  });
});
