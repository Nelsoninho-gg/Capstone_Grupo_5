import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

/** Los NUMERIC pueden llegar como número o como texto. */
type Numero = number | string;

/** Fila de fn_reporte_ventas_sucursal (H4.1 T02): una por sucursal, o "Sin sucursal". */
export interface ResumenVentasSucursalApi {
  sucursal_id: number | null;
  sucursal: string;
  ventas: number;
  total: Numero;
  ticket_promedio: Numero;
  ventas_normales: number;
  total_normales: Numero;
  ventas_empleado: number;
  total_empleado: Numero;
  /** Total por medio de pago de las ventas válidas: { efectivo: 1000, debito: 3000 }. */
  medios_pago: Record<string, Numero>;
  anuladas: number;
  total_anuladas: Numero;
}

/** Fila de fn_reporte_productos_sucursal (H4.1 T03): una por sucursal y producto. */
export interface ProductoVendidoSucursalApi {
  sucursal_id: number | null;
  sucursal: string;
  producto_id: number;
  producto: string;
  categoria: string | null;
  con_receta: boolean;
  unidades: Numero;
  ventas: number;
  monto_bruto: Numero;
  descuento: Numero;
  monto: Numero;
}

/** Fila de fn_reporte_cajeros (H4.3 T02): una por cajero, o "Sin cajero". */
export interface RendimientoCajeroApi {
  cajero_id: number | null;
  cajero: string;
  /** Sucursales donde vendió en el período, separadas por coma. */
  sucursales: string;
  turnos: number;
  ventas: number;
  total: Numero;
  venta_promedio: Numero;
  productos: Numero;
  anuladas: number;
  total_anuladas: Numero;
}

/** Fila de fn_cuadratura_ventas_stock (H4.1 T04): esperado contra registrado en el kardex. */
export interface CuadraturaArticuloApi {
  sucursal_id: number | null;
  sucursal: string;
  tipo: 'materia_prima' | 'producto';
  articulo_id: number;
  articulo: string;
  unidad: string;
  esperado: Numero;
  registrado: Numero;
  diferencia: Numero;
  cuadra: boolean;
}

/** Fila de fn_turnos_reporte (H4.3 T03): un turno real, o turno_id null = ventas sin turno. */
export interface TurnoReporteApi {
  turno_id: number | null;
  cajero_id: number | null;
  /** Nombre del cajero; "Sin turno registrado" en la fila sin turno. */
  cajero: string;
  sucursal_id: number | null;
  sucursal: string | null;
  /** Hora de Chile, AAAA-MM-DDTHH:MM:SS. */
  inicio: string | null;
  /** null = turno abierto. */
  fin: string | null;
  ventas: number;
  total: Numero;
  anuladas: number;
}

/** Fila de fn_costo_actual_productos (H4.4 T03): costo actual de un producto. */
export interface CostoProductoApi {
  producto_id: number;
  origen: 'receta' | 'compra' | 'sin_costo';
  /** null cuando no hay receta ni precio de compra. */
  costo_unitario: Numero | null;
  ingredientes: number;
  /** Ingredientes de la receta con costo 0: el costo queda incompleto. */
  ingredientes_sin_costo: number;
}

/** Período y sucursales de un reporte; `sucursales` null = todas. Fechas AAAA-MM-DD de Chile. */
/** Un día del período con lo vendido con promoción (H5.2 T08). */
export interface PromocionesDiaApi {
  dia: string;
  vendido: Numero;
  vendido_con_descuento: Numero;
  precio_lista_con_descuento: Numero;
  unidades_con_descuento: Numero;
  ventas_con_promocion: number;
  margen_sacrificado: Numero;
}

/** Un producto con lo vendido con promoción y el margen sacrificado (H5.2 T08). */
export interface PromocionesProductoApi {
  producto_id: number;
  producto: string;
  categoria: string | null;
  unidades: Numero;
  vendido: Numero;
  unidades_con_descuento: Numero;
  vendido_con_descuento: Numero;
  precio_lista_con_descuento: Numero;
  margen_sacrificado: Numero;
  /** null si ninguna línea con promoción tiene costo registrado. */
  margen_con_descuento: Numero | null;
  promociones: string | null;
}

export interface FiltroReporteApi {
  sucursales: number[] | null;
  desde: string;
  hasta: string;
}

/**
 * Reportes de ventas por sucursal (H4.1) y por cajero (H4.3). Las funciones son solo para el administrador y
 * reciben días de Chile; la conversión de horas la hace la base.
 */
@Injectable({ providedIn: 'root' })
export class ReportesApiService {
  private readonly http = inject(HttpClient);
  private readonly apiUrl = environment.apiUrl;

  resumenVentasSucursal(filtro: FiltroReporteApi): Observable<ResumenVentasSucursalApi[]> {
    return this.http.post<ResumenVentasSucursalApi[]>(
      `${this.apiUrl}/rpc/fn_reporte_ventas_sucursal`,
      cuerpo(filtro),
    );
  }

  productosVendidosSucursal(filtro: FiltroReporteApi): Observable<ProductoVendidoSucursalApi[]> {
    return this.http.post<ProductoVendidoSucursalApi[]>(
      `${this.apiUrl}/rpc/fn_reporte_productos_sucursal`,
      cuerpo(filtro),
    );
  }

  /**
   * `turno` (H4.3 T03): id de un turno = solo sus ventas; 0 = solo las ventas sin turno;
   * sin indicar = todo el período.
   */
  rendimientoCajeros(filtro: FiltroReporteApi, turno?: number): Observable<RendimientoCajeroApi[]> {
    return this.http.post<RendimientoCajeroApi[]>(
      `${this.apiUrl}/rpc/fn_reporte_cajeros`,
      turno === undefined ? cuerpo(filtro) : { ...cuerpo(filtro), p_turno: turno },
    );
  }

  costoActualProductos(): Observable<CostoProductoApi[]> {
    return this.http.post<CostoProductoApi[]>(`${this.apiUrl}/rpc/fn_costo_actual_productos`, {});
  }

  turnosReporte(filtro: FiltroReporteApi): Observable<TurnoReporteApi[]> {
    return this.http.post<TurnoReporteApi[]>(
      `${this.apiUrl}/rpc/fn_turnos_reporte`,
      cuerpo(filtro),
    );
  }

  cuadraturaVentasStock(filtro: FiltroReporteApi): Observable<CuadraturaArticuloApi[]> {
    return this.http.post<CuadraturaArticuloApi[]>(
      `${this.apiUrl}/rpc/fn_cuadratura_ventas_stock`,
      cuerpo(filtro),
    );
  }

  /** H5.2 T08: por día, lo vendido con promoción y el margen sacrificado. */
  promocionesPorDia(filtro: FiltroReporteApi): Observable<PromocionesDiaApi[]> {
    return this.http.post<PromocionesDiaApi[]>(
      `${this.apiUrl}/rpc/fn_reporte_promociones_periodo`,
      cuerpo(filtro),
    );
  }

  /** H5.2 T08: por producto, lo vendido con promoción y el margen sacrificado. */
  promocionesPorProducto(filtro: FiltroReporteApi): Observable<PromocionesProductoApi[]> {
    return this.http.post<PromocionesProductoApi[]>(
      `${this.apiUrl}/rpc/fn_reporte_promociones_producto`,
      cuerpo(filtro),
    );
  }
}

/** Una lista vacía significa "ninguna elegida": se envía null para pedir todas. */
function cuerpo(filtro: FiltroReporteApi) {
  return {
    p_sucursales: filtro.sucursales?.length ? filtro.sucursales : null,
    p_desde: filtro.desde,
    p_hasta: filtro.hasta,
  };
}
