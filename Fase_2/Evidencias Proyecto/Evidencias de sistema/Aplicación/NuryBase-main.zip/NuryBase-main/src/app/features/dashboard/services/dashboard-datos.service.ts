import { Injectable, inject } from '@angular/core';
import { Observable, forkJoin, map } from 'rxjs';
import { IngredientesApiService } from '../../../core/api/ingredientes-api.service';
import { ProductosApiService } from '../../../core/api/productos-api.service';
import { StockApiService } from '../../../core/api/stock-api.service';
import { VentasApiService } from '../../../core/api/ventas-api.service';
import {
  DIAS_HISTORIAL_PROYECCION,
  EscenarioDashboard,
  ItemCatalogoEstado,
  PeriodoDashboard,
  calcularRangoPeriodo,
  construirEscenario,
} from '../models/dashboard.model';

const DIA_MS = 24 * 60 * 60 * 1000;
const MAX_INSUMOS_URGENTES = 20;

export interface InsumoUrgente {
  articulo: string;
  sucursal: string;
  stock: number;
  minimo: number;
  sugerido: number;
}

export interface DatosDashboard {
  escenario: EscenarioDashboard;
  diasHistorial: number;
  catalogo: readonly ItemCatalogoEstado[];
  insumosUrgentes: readonly InsumoUrgente[];
}

/** Reúne desde PostgREST lo que muestra el Dashboard y lo que recibe el asistente. */
@Injectable({ providedIn: 'root' })
export class DashboardDatosService {
  private readonly ventasApi = inject(VentasApiService);
  private readonly productosApi = inject(ProductosApiService);
  private readonly ingredientesApi = inject(IngredientesApiService);
  private readonly stockApi = inject(StockApiService);

  cargar(
    periodo: PeriodoDashboard,
    sucursalId: number | null,
    ahora: Date = new Date(),
  ): Observable<DatosDashboard> {
    const { inicioPrevio, inicio } = calcularRangoPeriodo(periodo, ahora);
    // "Hoy" necesita varias semanas del mismo día de la semana para proyectar el cierre.
    // Se resta con la fecha local, no en milisegundos: el cambio de hora de Chile movería la hora.
    const desde =
      periodo === '1d'
        ? new Date(
            inicio.getFullYear(),
            inicio.getMonth(),
            inicio.getDate() - DIAS_HISTORIAL_PROYECCION,
          )
        : inicioPrevio;

    return forkJoin({
      ventas: this.ventasApi.listarParaDashboard(desde, sucursalId),
      primeraVenta: this.ventasApi.primeraVenta(sucursalId),
      costos: this.productosApi.listarCostosReceta(),
      porComprar: this.stockApi.listarPorComprar(sucursalId, 1),
      productos: this.productosApi.listar(false),
      ingredientes: this.ingredientesApi.listar(false),
    }).pipe(
      map(({ ventas, primeraVenta, costos, porComprar, productos, ingredientes }) => ({
        escenario: construirEscenario(
          ventas,
          new Map(costos.map((c) => [c.producto_id, Number(c.costo_receta) || 0])),
          periodo,
          ahora,
        ),
        diasHistorial: primeraVenta
          ? Math.floor((ahora.getTime() - primeraVenta.getTime()) / DIA_MS)
          : 0,
        catalogo: [
          ...productos.map((p) => ({
            nombre: p.nombre,
            tipo: 'producto' as const,
            categoria: p.categoria ?? 'Sin categoría',
            activo: p.activo,
          })),
          ...ingredientes.map((i) => ({
            nombre: i.nombre,
            tipo: 'materia_prima' as const,
            categoria: 'Ingrediente',
            activo: i.activo,
          })),
        ],
        insumosUrgentes: porComprar.slice(0, MAX_INSUMOS_URGENTES).map((a) => ({
          articulo: a.nombre,
          sucursal: a.sucursal,
          stock: Number(a.stock_actual),
          minimo: Number(a.stock_minimo),
          sugerido: Number(a.sugerido),
        })),
      })),
    );
  }
}
