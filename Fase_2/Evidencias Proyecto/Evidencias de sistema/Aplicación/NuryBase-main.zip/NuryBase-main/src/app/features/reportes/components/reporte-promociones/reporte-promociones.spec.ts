import { HttpErrorResponse } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { of, throwError } from 'rxjs';
import { PromocionesPeriodo, PromocionesProducto } from '../../models/reporte-promociones.model';
import { ReportesService } from '../../services/reportes.service';
import { ReportePromociones } from './reporte-promociones';

const dia = (desde: string, vendido: number, conDescuento: number, margen: number): PromocionesPeriodo => ({
  desde,
  hasta: desde,
  vendido,
  vendidoConDescuento: conDescuento,
  precioListaConDescuento: conDescuento + margen,
  unidadesConDescuento: conDescuento ? 2 : 0,
  ventasConPromocion: conDescuento ? 1 : 0,
  margenSacrificado: margen,
});

const producto = (
  productoId: number,
  nombre: string,
  extra: Partial<PromocionesProducto> = {},
): PromocionesProducto => ({
  productoId,
  producto: nombre,
  categoria: null,
  unidades: 3,
  vendido: 5272,
  unidadesConDescuento: 2,
  vendidoConDescuento: 3272,
  precioListaConDescuento: 4000,
  margenSacrificado: 728,
  margenConDescuento: 2072,
  promociones: ['Sándwich + café'],
  ...extra,
});

describe('ReportePromociones (H5.2 T08)', () => {
  let fixture: ComponentFixture<ReportePromociones>;
  const reportes = { promocionesPorDia: vi.fn(), promocionesPorProducto: vi.fn() };
  const FILTRO = { sucursales: [1], desde: '2026-11-01', hasta: '2026-11-05' };

  async function render(filtro: typeof FILTRO | null = FILTRO) {
    await TestBed.configureTestingModule({
      imports: [ReportePromociones],
      providers: [{ provide: ReportesService, useValue: reportes }],
    }).compileComponents();
    fixture = TestBed.createComponent(ReportePromociones);
    fixture.componentRef.setInput('filtro', filtro);
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
  }
  const el = () => fixture.nativeElement as HTMLElement;
  const texto = (selector: string) =>
    (el().querySelector(selector)?.textContent ?? '').replace(/\s+/g, ' ').trim();
  const filas = (selector: string) =>
    [...el().querySelectorAll(`${selector} tbody tr`)].map((fila) =>
      [...fila.children].map((celda) => (celda.textContent ?? '').replace(/\s+/g, ' ').trim()),
    );

  beforeEach(() => {
    reportes.promocionesPorDia.mockReset().mockReturnValue(
      of([
        dia('2026-11-01', 1000, 0, 0),
        dia('2026-11-02', 6500, 4500, 1000),
        dia('2026-11-03', 0, 0, 0),
        dia('2026-11-04', 4500, 4500, 1000),
        dia('2026-11-05', 2000, 0, 0),
      ]),
    );
    reportes.promocionesPorProducto.mockReset().mockReturnValue(
      of([
        producto(1, 'Sándwich', { vendido: 5728, vendidoConDescuento: 5728, margenSacrificado: 1272 }),
        producto(2, 'Café'),
        producto(3, 'Jugo', {
          unidadesConDescuento: 0,
          vendidoConDescuento: 0,
          margenSacrificado: 0,
          margenConDescuento: null,
          promociones: [],
        }),
      ]),
    );
  });

  it('asks with the branches and period of the dashboard', async () => {
    await render();
    expect(reportes.promocionesPorDia).toHaveBeenCalledWith(FILTRO);
    expect(reportes.promocionesPorProducto).toHaveBeenCalledWith(FILTRO);
  });

  it('shows how much was sold with discount and the margin given up', async () => {
    await render();
    const kpis = texto('.promo-kpis').replace(/\s/g, ' ');
    expect(kpis).toContain('Vendido con descuento$9.000');
    expect(kpis).toContain('64,3 % de lo vendido');
    expect(kpis).toContain('Margen sacrificado$2.000');
    expect(kpis).toContain('Ventas con promoción2');
  });

  it('splits the results by day, week or month', async () => {
    await render();
    expect(filas('.promos-period-table')).toHaveLength(5);

    (el().querySelectorAll('.segmented button')[1] as HTMLButtonElement).click();
    fixture.detectChanges();
    const semanas = filas('.promos-period-table');
    expect(semanas).toHaveLength(2);
    expect(semanas[1][0]).toBe('02-11-2026 al 05-11-2026');
    expect(semanas[1][5].replace(/\s/g, ' ')).toBe('$2.000');

    (el().querySelectorAll('.segmented button')[2] as HTMLButtonElement).click();
    fixture.detectChanges();
    expect(filas('.promos-period-table')[0][0]).toBe('noviembre de 2026');
  });

  it('lists products sold with promotion, or every product on demand', async () => {
    await render();
    let productos = filas('.promos-product-table');
    expect(productos.map((f) => f[0])).toEqual(['Sándwich Sándwich + café', 'Café Sándwich + café']);
    expect(productos[1][3]).toBe('2 de 3');
    expect(productos[1][4].replace(/\s/g, ' ')).toBe('$728');

    const check = el().querySelector<HTMLInputElement>('.check-control input')!;
    check.checked = false;
    check.dispatchEvent(new Event('change'));
    fixture.detectChanges();
    productos = filas('.promos-product-table');
    expect(productos).toHaveLength(3);
    expect(productos[2][5]).toBe('Sin costo');
  });

  it('says when there were no sales with promotion', async () => {
    reportes.promocionesPorDia.mockReturnValue(of([dia('2026-11-01', 1000, 0, 0)]));
    await render();
    expect(texto('.card')).toContain('No hubo ventas con promoción en este período.');
    expect(el().querySelector('.promos-period-table')).toBeNull();
  });

  it('does not ask while the period is not valid', async () => {
    await render(null);
    expect(reportes.promocionesPorDia).not.toHaveBeenCalled();
  });

  it('explains a permission error and offers a retry on other errors', async () => {
    reportes.promocionesPorDia.mockReturnValue(throwError(() => new HttpErrorResponse({ status: 403 })));
    await render();
    expect(texto('[role="alert"]')).toContain('Solo el administrador');

    TestBed.resetTestingModule();
    reportes.promocionesPorDia.mockReturnValue(throwError(() => new HttpErrorResponse({ status: 0 })));
    await render();
    expect(texto('[role="alert"]')).toContain('No pudimos cargar el reporte de promociones');
    reportes.promocionesPorDia.mockReturnValue(of([dia('2026-11-02', 6500, 4500, 1000)]));
    (el().querySelector('.retry-button') as HTMLButtonElement).click();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(el().querySelector('.promo-kpis')).not.toBeNull();
  });
});
