import {
  HttpBackend,
  HttpClient,
  HttpErrorResponse,
} from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, TimeoutError, throwError } from 'rxjs';
import { catchError, map, timeout } from 'rxjs/operators';
import { AuthService } from '../../features/auth/services/auth.service';
import { ConexionService } from '../services/conexion.service';
import {
  PeticionHTTPPreparada,
  RespuestaInutilizableError,
  extraerTextoRespuestaIA,
  prepararPeticionIA,
} from './adaptadores-proveedor-ia';
import {
  IA_PROVEEDORES,
  IA_RELOJ,
  MensajesIA,
  ProveedorIAConfig,
} from './proveedores-ia.config';

export type MotivoSinProveedores = 'sin-configuracion' | 'sin-conexion' | 'agotados';

export interface IntentoProveedorIA {
  proveedorId: string;
  modelo: string;
  exitoso: boolean;
  codigoEstado?: number;
  error?: string;
  duracionMs: number;
}

export interface RespuestaOrquestadorIA {
  proveedorId: string;
  modelo: string;
  contenido: string;
  intentos: IntentoProveedorIA[];
}

export interface EstadoProveedorIA {
  id: string;
  modelo: string;
  disponible: boolean;
  enfriandoHasta: number | null;
  motivoUltimoFallo?: string;
}

export class SinProveedoresIAError extends Error {
  constructor(
    public readonly motivo: MotivoSinProveedores,
    public readonly intentos: IntentoProveedorIA[] = [],
    mensaje?: string,
  ) {
    super(mensaje ?? `No hay proveedores de IA disponibles: ${motivo}`);
    this.name = 'SinProveedoresIAError';
  }
}

/**
 * Orquestador multimodelo con rotación automática (failover) y enfriamiento en memoria.
 * Garantiza continuidad operativa saltando al siguiente proveedor de forma transparente
 * cuando uno se agota (HTTP 429), falla (5xx, timeout, error de red) o no está disponible.
 *
 * NOTA DE SEGURIDAD:
 * Se instancia HttpClient directamente sobre HttpBackend para evitar que authInterceptor
 * agregue automáticamente el JWT de sesión a endpoints externos. El token solo se adjunta
 * de forma manual si el proveedor tiene autenticación 'sesion-nury' hacia api.nury.cl.
 */
@Injectable({ providedIn: 'root' })
export class OrquestadorIaService {
  private readonly httpBackend = inject(HttpBackend);
  private readonly http = new HttpClient(this.httpBackend);
  private readonly proveedores = inject(IA_PROVEEDORES);
  private readonly reloj = inject(IA_RELOJ);
  private readonly authService = inject(AuthService);
  private readonly conexionService = inject(ConexionService);

  private readonly enfriamientos = new Map<string, number>();
  private readonly motivosFallo = new Map<string, string>();

  /**
   * Envía los mensajes a la cadena de proveedores activos y retorna la primera respuesta exitosa.
   */
  solicitar(mensajes: MensajesIA): Observable<RespuestaOrquestadorIA> {
    if (!this.conexionService.enLinea()) {
      return throwError(
        () =>
          new SinProveedoresIAError(
            'sin-conexion',
            [],
            'Sin conexión a internet: no es posible solicitar predicción por IA',
          ),
      );
    }

    if (!this.proveedores || this.proveedores.length === 0) {
      return throwError(
        () =>
          new SinProveedoresIAError(
            'sin-configuracion',
            [],
            'No hay proveedores de IA configurados en el sistema',
          ),
      );
    }

    const ahora = this.reloj();
    this.limpiarEnfriamientosExpirados(ahora);

    // Filtrar únicamente proveedores disponibles
    const disponibles = this.proveedores.filter(
      (p) => !this.enfriamientos.has(p.id),
    );

    if (disponibles.length === 0) {
      return throwError(
        () =>
          new SinProveedoresIAError(
            'agotados',
            [],
            'Todos los proveedores de IA están temporalmente en enfriamiento',
          ),
      );
    }

    return this.intentarSiguiente(disponibles, 0, mensajes, []);
  }

  /**
   * Retorna el estado actual de disponibilidad y enfriamiento de cada proveedor configurado.
   */
  estadoProveedores(): EstadoProveedorIA[] {
    const ahora = this.reloj();
    this.limpiarEnfriamientosExpirados(ahora);

    return (this.proveedores ?? []).map((p) => {
      const expira = this.enfriamientos.get(p.id);
      const enfriando = expira !== undefined && ahora < expira;
      return {
        id: p.id,
        modelo: p.modelo,
        disponible: !enfriando,
        enfriandoHasta: enfriando ? expira : null,
        motivoUltimoFallo: this.motivosFallo.get(p.id),
      };
    });
  }

  /**
   * Limpia todos los enfriamientos en memoria (útil para reintentos forzados o pruebas).
   */
  limpiarEnfriamientos(): void {
    this.enfriamientos.clear();
    this.motivosFallo.clear();
  }

  /**
   * Purga los enfriamientos cuya ventana de penalización temporal ya haya vencido.
   */
  private limpiarEnfriamientosExpirados(ahora: number): void {
    for (const [id, expira] of this.enfriamientos.entries()) {
      if (ahora >= expira) {
        this.enfriamientos.delete(id);
        this.motivosFallo.delete(id);
      }
    }
  }

  /**
   * Calcula el tiempo de enfriamiento (timestamp ms) según la causa del error.
   */
  calcularTiempoEnfriamiento(error: unknown, ahora: number): number {
    const status = (error as any)?.status;
    const headers = (error as any)?.headers;

    if (typeof status === 'number') {
      // 429: Cuota agotada
      if (status === 429) {
        const retryAfter =
          typeof headers?.get === 'function'
            ? headers.get('Retry-After')
            : (headers?.['Retry-After'] ?? headers?.['retry-after']);
        if (retryAfter) {
          const segundos = parseInt(retryAfter, 10);
          if (Number.isFinite(segundos) && segundos > 0) {
            return ahora + segundos * 1000;
          }
          const fechaMs = Date.parse(retryAfter);
          if (!Number.isNaN(fechaMs) && fechaMs > ahora) {
            return fechaMs;
          }
        }
        return ahora + 60 * 1000; // 60s por defecto
      }

      // 401 / 403: No autorizado (clave inválida o no admin en Caddy)
      if (status === 401 || status === 403) {
        return ahora + 60 * 60 * 1000; // 1h
      }

      // 404: Ruta /ia/* no existe aún en Caddy
      if (status === 404) {
        return ahora + 60 * 60 * 1000; // 1h
      }

      // 400 u otro 4xx: Fallo en la solicitud, sin enfriamiento al proveedor
      if (status >= 400 && status < 500) {
        return 0;
      }

      // 5xx: Caída temporal del servicio o gateway (incluye 500, 502, 503, 504, 529 overloaded)
      if (status >= 500 && status < 600) {
        return ahora + 30 * 1000; // 30s
      }

      // Status 0: Error de red o timeout de cliente
      if (status === 0) {
        return ahora + 30 * 1000; // 30s
      }
    }

    // Timeout de RxJS
    if (
      error instanceof TimeoutError ||
      (error as Error)?.name === 'TimeoutError' ||
      (error as any)?.name === 'TimeoutError'
    ) {
      return ahora + 30 * 1000; // 30s
    }

    // Respondió 200 sin texto utilizable: el proveedor funciona, así que no se enfría
    if (error instanceof RespuestaInutilizableError) {
      return 0;
    }

    // Cualquier otro error inesperado
    return ahora + 30 * 1000; // 30s
  }

  private intentarSiguiente(
    proveedores: readonly ProveedorIAConfig[],
    indice: number,
    mensajes: MensajesIA,
    intentos: IntentoProveedorIA[],
  ): Observable<RespuestaOrquestadorIA> {
    if (indice >= proveedores.length) {
      return throwError(
        () =>
          new SinProveedoresIAError(
            'agotados',
            intentos,
            'Todos los proveedores disponibles fallaron',
          ),
      );
    }

    const proveedor = proveedores[indice];
    const inicio = this.reloj();

    let peticion: PeticionHTTPPreparada;
    try {
      peticion = prepararPeticionIA(
        proveedor,
        mensajes,
        this.authService.getToken(),
      );
    } catch (err: any) {
      const duracionMs = Math.max(0, this.reloj() - inicio);
      intentos.push({
        proveedorId: proveedor.id,
        modelo: proveedor.modelo,
        exitoso: false,
        error: err?.message ?? String(err),
        duracionMs,
      });
      return this.intentarSiguiente(proveedores, indice + 1, mensajes, intentos);
    }

    const timeoutMs =
      typeof proveedor.timeoutMs === 'number' && proveedor.timeoutMs > 0
        ? proveedor.timeoutMs
        : 15000;

    return this.http
      .post<unknown>(peticion.url, peticion.body, { headers: peticion.headers })
      .pipe(
        timeout(timeoutMs),
        map((respuesta) => {
          const contenido = extraerTextoRespuestaIA(proveedor, respuesta);
          const duracionMs = Math.max(0, this.reloj() - inicio);
          intentos.push({
            proveedorId: proveedor.id,
            modelo: proveedor.modelo,
            exitoso: true,
            duracionMs,
          });
          return {
            proveedorId: proveedor.id,
            modelo: proveedor.modelo,
            contenido,
            intentos,
          };
        }),
        catchError((error) => {
          const fin = this.reloj();
          const duracionMs = Math.max(0, fin - inicio);
          const codigoEstado =
            error instanceof HttpErrorResponse ? error.status : undefined;
          const mensajeError =
            error instanceof Error
              ? error.message
              : error?.message ?? String(error);

          intentos.push({
            proveedorId: proveedor.id,
            modelo: proveedor.modelo,
            exitoso: false,
            codigoEstado,
            error: mensajeError,
            duracionMs,
          });

          const enfriarHasta = this.calcularTiempoEnfriamiento(error, fin);
          if (enfriarHasta > fin) {
            this.enfriamientos.set(proveedor.id, enfriarHasta);
            this.motivosFallo.set(proveedor.id, mensajeError);
          }

          return this.intentarSiguiente(
            proveedores,
            indice + 1,
            mensajes,
            intentos,
          );
        }),
      );
  }
}
