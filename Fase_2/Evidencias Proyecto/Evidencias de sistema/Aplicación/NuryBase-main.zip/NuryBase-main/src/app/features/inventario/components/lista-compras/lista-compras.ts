import { HttpErrorResponse } from '@angular/common/http';
import {
  Component,
  DOCUMENT,
  OnInit,
  computed,
  inject,
  input,
  linkedSignal,
  signal,
} from '@angular/core';
import { rxResource } from '@angular/core/rxjs-interop';
import {
  ArticuloPorComprar,
  ETIQUETAS_MOTIVO,
  MotivoCompra,
  contarMotivos,
  etiquetaVendido,
  hojaCompras,
  motivoCompra,
  planillaCompras,
} from '../../models/compras.model';
import { TIPO_XLSX, crearXlsx } from '../../../../shared/utils/xlsx';
import { TipoArticulo } from '../../models/inventario.model';
import { InventarioService } from '../../services/inventario.service';

const TODAS_LAS_SUCURSALES = 'todas';

/** Periodo de ventas con el que se calcula el consumo de un día (promedio). */
export const PERIODOS_VENTAS: readonly { dias: number; etiqueta: string }[] = [
  { dias: 1, etiqueta: 'Ventas del último día' },
  { dias: 7, etiqueta: 'Ventas de 7 días' },
  { dias: 14, etiqueta: 'Ventas de 14 días' },
  { dias: 30, etiqueta: 'Ventas de 30 días' },
];
const DIAS_POR_DEFECTO = 7;

const formatoCantidad = new Intl.NumberFormat('es-CL', { maximumFractionDigits: 3 });
const formatoHora = new Intl.DateTimeFormat('es-CL', {
  hour: '2-digit',
  minute: '2-digit',
  hourCycle: 'h23',
});

/**
 * Inventario > Por comprar: los artículos críticos para la compra del día siguiente.
 * Un artículo entra cuando su stock no cubre el mínimo más el consumo diario promedio del
 * periodo de ventas elegido; en pantalla se muestra el total vendido en ese periodo
 * (fn_articulos_por_comprar). La lista se actualiza sola cuando cambia el stock (el panel
 * avisa con `version`) y se puede descargar como planilla Excel (.xlsx) o CSV.
 */
@Component({
  selector: 'app-lista-compras',
  templateUrl: './lista-compras.html',
  styleUrls: ['../../styles/inventario-base.css', './lista-compras.css'],
})
export class ListaCompras implements OnInit {
  private readonly inventarioService = inject(InventarioService);
  private readonly documento = inject(DOCUMENT);

  readonly sucursales = input.required<{ id: number; nombre: string }[]>();
  /** Sucursal elegida en el panel de existencias, para abrir la lista en el mismo contexto. */
  readonly sucursalInicial = input(TODAS_LAS_SUCURSALES);
  /** Cambia cuando cambia el stock o hay movimientos nuevos, para volver a consultar. */
  readonly version = input(0);

  protected readonly periodos = PERIODOS_VENTAS;
  protected readonly filtroSucursal = signal(TODAS_LAS_SUCURSALES);
  protected readonly dias = signal(DIAS_POR_DEFECTO);

  private readonly sucursalId = computed(() => {
    const sucursal = this.filtroSucursal();
    return sucursal === TODAS_LAS_SUCURSALES ? null : Number(sucursal);
  });

  protected readonly compras = rxResource({
    params: () => ({ sucursalId: this.sucursalId(), dias: this.dias(), version: this.version() }),
    stream: ({ params }) => this.inventarioService.listarPorComprar(params.sucursalId, params.dias),
  });

  private readonly respuesta = computed(() =>
    this.compras.hasValue() ? this.compras.value() : undefined,
  );

  /**
   * Mientras se vuelve a consultar por un cambio de stock se mantiene la lista anterior; al
   * cambiar la sucursal o el periodo se espera la nueva (null = sin datos para mostrar).
   */
  protected readonly articulos = linkedSignal<
    { filtros: string; valor: ArticuloPorComprar[] | undefined },
    ArticuloPorComprar[] | null
  >({
    source: () => ({ filtros: `${this.sucursalId()}-${this.dias()}`, valor: this.respuesta() }),
    computation: (actual, anterior) =>
      actual.valor ??
      (anterior && anterior.source.filtros === actual.filtros ? anterior.value : null),
  });

  protected readonly actualizadoEn = linkedSignal<ArticuloPorComprar[] | undefined, Date | null>({
    source: this.respuesta,
    computation: (valor, anterior) => (valor ? new Date() : (anterior?.value ?? null)),
  });

  protected readonly conteo = computed(() => contarMotivos(this.articulos() ?? []));
  protected readonly cargando = computed(
    () => this.articulos() === null && this.compras.isLoading(),
  );
  protected readonly conError = computed(
    () => this.articulos() === null && this.compras.status() === 'error',
  );
  /** Falló una actualización, pero sigue visible la última lista recibida. */
  protected readonly sinActualizar = computed(
    () => this.articulos() !== null && this.compras.status() === 'error',
  );
  protected readonly sinPermiso = computed(() => {
    const error = this.compras.error();
    return error instanceof HttpErrorResponse && error.status === 403;
  });
  protected readonly variasSucursales = computed(
    () => this.sucursalId() === null && this.sucursales().length > 1,
  );
  protected readonly textoPeriodo = computed(
    () => PERIODOS_VENTAS.find((periodo) => periodo.dias === this.dias())?.etiqueta ?? '',
  );
  protected readonly etiquetaVendido = computed(() => etiquetaVendido(this.dias()));

  ngOnInit(): void {
    const inicial = this.sucursalInicial();
    const existe = this.sucursales().some((sucursal) => String(sucursal.id) === inicial);
    this.filtroSucursal.set(existe ? inicial : TODAS_LAS_SUCURSALES);
  }

  protected reintentar(): void {
    this.compras.reload();
  }

  protected actualizarSucursal(event: Event): void {
    this.filtroSucursal.set((event.target as HTMLSelectElement).value);
  }

  protected actualizarDias(event: Event): void {
    this.dias.set(Number((event.target as HTMLSelectElement).value));
  }

  /** Descarga la lista visible como planilla de Excel (.xlsx). */
  protected descargarExcel(): void {
    const articulos = this.articulos();
    if (!articulos?.length) return;
    // Copia a un ArrayBuffer propio: Blob no acepta vistas sobre un SharedArrayBuffer.
    const bytes = new Uint8Array(crearXlsx(hojaCompras(articulos, this.dias())));
    this.descargar(new Blob([bytes], { type: TIPO_XLSX }), 'xlsx');
  }

  /** La misma lista en CSV (Excel lo abre directo, con tildes gracias al BOM). */
  protected descargarCsv(): void {
    const articulos = this.articulos();
    if (!articulos?.length) return;
    const archivo = new Blob(['\uFEFF' + planillaCompras(articulos, this.dias())], {
      type: 'text/csv;charset=utf-8',
    });
    this.descargar(archivo, 'csv');
  }

  private descargar(archivo: Blob, extension: 'xlsx' | 'csv'): void {
    const url = URL.createObjectURL(archivo);
    const enlace = this.documento.createElement('a');
    enlace.href = url;
    enlace.download = `por-comprar_${fechaLocal(new Date())}.${extension}`;
    this.documento.body.appendChild(enlace);
    enlace.click();
    enlace.remove();
    URL.revokeObjectURL(url);
  }

  protected motivo(articulo: ArticuloPorComprar): MotivoCompra {
    return motivoCompra(articulo);
  }

  protected etiquetaMotivo(motivo: MotivoCompra): string {
    return ETIQUETAS_MOTIVO[motivo];
  }

  protected etiquetaTipo(tipo: TipoArticulo): string {
    return tipo === 'producto' ? 'Producto' : 'Materia prima';
  }

  protected formatearCantidad(cantidad: number): string {
    return formatoCantidad.format(cantidad);
  }

  protected formatearHora(fecha: Date): string {
    return formatoHora.format(fecha);
  }
}

/** Fecha local en formato AAAA-MM-DD. */
function fechaLocal(fecha: Date): string {
  const mes = String(fecha.getMonth() + 1).padStart(2, '0');
  const dia = String(fecha.getDate()).padStart(2, '0');
  return `${fecha.getFullYear()}-${mes}-${dia}`;
}
