import { HttpErrorResponse } from '@angular/common/http';
import { Component, computed, inject, linkedSignal, signal } from '@angular/core';
import { rxResource } from '@angular/core/rxjs-interop';
import { ActivatedRoute, Router } from '@angular/router';
import { forkJoin, map } from 'rxjs';
import { SucursalesApiService } from '../../../../core/api/sucursales-api.service';
import {
  CuadraturaStock,
  EstadoCuadratura,
} from '../../components/cuadratura-stock/cuadratura-stock';
import { FiltrosReporte } from '../../components/filtros-reporte/filtros-reporte';
import { ReporteCajeros } from '../../components/reporte-cajeros/reporte-cajeros';
import {
  EstadoCostos,
  ReporteProductos,
} from '../../components/reporte-productos/reporte-productos';
import { ReportePromociones } from '../../components/reporte-promociones/reporte-promociones';
import { ReporteSucursales } from '../../components/reporte-sucursales/reporte-sucursales';
import { formatoClp, formatoNumero, textoVariacion, tonoVariacion } from '../../models/formato';
import {
  RangoFechas,
  SeleccionPeriodo,
  etiquetaPeriodoAnterior,
  hoyLocal,
  periodoAnterior,
  rangoDePeriodo,
  textoRango,
} from '../../models/periodo.model';
import {
  agruparProductos,
  ordenarProductos,
  totalesReporte,
  variacion,
} from '../../models/reporte-ventas.model';
import {
  FiltroReporte,
  FiltroTurno,
  ProductoVendido,
  RendimientoCajero,
  ResumenSucursal,
} from '../../models/reportes.model';
import { ReportesService } from '../../services/reportes.service';

type Vista = 'sucursales' | 'productos' | 'cajeros' | 'promociones';
const VISTAS: readonly Vista[] = ['sucursales', 'productos', 'cajeros', 'promociones'];

/** Pestaña pedida en la URL (?vista=productos); cualquier otro valor abre Sucursales. */
export function vistaReporteDesdeUrl(valor: string | null | undefined): Vista {
  return VISTAS.find((vista) => vista === valor) ?? 'sucursales';
}

interface DatosReporte {
  resumen: ResumenSucursal[];
  productos: ProductoVendido[];
  cajeros: RendimientoCajero[];
  resumenAnterior: ResumenSucursal[];
  productosAnterior: ProductoVendido[];
  cajerosAnterior: RendimientoCajero[];
}

interface Tarjeta {
  clave: string;
  etiqueta: string;
  valor: string;
  variacion: number | null;
  /** El mismo indicador en el período anterior, ya formateado (H4.2). */
  anterior: string;
  /** En las anuladas, subir es malo. */
  menosEsMejor?: boolean;
  detalle?: string;
}

/**
 * Dashboard de Reportes, solo para el administrador. Filtros compartidos (sucursales y
 * período) arriba; tarjetas con los totales y lo más destacado; y una pestaña por área:
 * sucursales (H4.1), productos (H4.4) y cajeros (H4.3). Cada número se compara con el período
 * anterior de igual largo.
 */
@Component({
  selector: 'app-reportes',
  imports: [
    FiltrosReporte,
    ReporteSucursales,
    ReporteProductos,
    ReporteCajeros,
    CuadraturaStock,
    ReportePromociones,
  ],
  templateUrl: './reportes.html',
  styleUrl: './reportes.css',
})
export class Reportes {
  private readonly reportes = inject(ReportesService);
  private readonly sucursalesApi = inject(SucursalesApiService);
  private readonly ruta = inject(ActivatedRoute, { optional: true });
  private readonly router = inject(Router);

  protected readonly hoy = signal(hoyLocal());
  protected readonly seleccionadas = signal<number[]>([]);
  protected readonly periodo = signal<SeleccionPeriodo>({ tipo: 'semana', referencia: hoyLocal() });
  protected readonly vista = signal<Vista>(
    vistaReporteDesdeUrl(this.ruta?.snapshot.queryParamMap.get('vista')),
  );

  protected readonly listaSucursales = rxResource({
    stream: () =>
      this.sucursalesApi
        .listarActivas()
        .pipe(map((filas) => filas.map((s) => ({ id: s.id, nombre: s.nombre })))),
  });
  protected readonly sucursales = computed(() =>
    this.listaSucursales.hasValue() ? this.listaSucursales.value() : [],
  );

  private readonly rango = computed(() => rangoDePeriodo(this.periodo(), this.hoy()));
  protected readonly errorRango = computed(() => {
    const rango = this.rango();
    return 'error' in rango ? rango.error : null;
  });
  private readonly rangoValido = computed<RangoFechas | null>(() => {
    const rango = this.rango();
    return 'error' in rango ? null : rango;
  });
  /** Filtro vigente para la pestaña Promociones (H5.2 T08), que hace sus propias consultas. */
  protected readonly filtroActual = computed<FiltroReporte | null>(() => {
    const rango = this.rangoValido();
    return rango ? { sucursales: this.seleccionadas(), ...rango } : null;
  });
  private readonly rangoAnterior = computed(() => {
    const rango = this.rangoValido();
    return rango ? periodoAnterior(rango, this.periodo().tipo) : null;
  });
  /** "Semana anterior", "Mes anterior", "7 días anteriores"... */
  protected readonly etiquetaAnterior = computed(() => {
    const rango = this.rangoValido();
    return rango ? etiquetaPeriodoAnterior(this.periodo().tipo, rango) : '';
  });
  protected readonly textoPeriodo = computed(() => {
    const rango = this.rangoValido();
    const anterior = this.rangoAnterior();
    return rango && anterior
      ? `${textoRango(rango)} · comparado con ${this.etiquetaAnterior().toLowerCase()} (${textoRango(anterior)})`
      : '';
  });

  protected readonly datos = rxResource({
    params: () => {
      const rango = this.rangoValido();
      const rangoAnterior = this.rangoAnterior();
      if (!rango || !rangoAnterior) return undefined;
      const sucursales = this.seleccionadas();
      const actual: FiltroReporte = { sucursales, ...rango };
      const anterior: FiltroReporte = { sucursales, ...rangoAnterior };
      return { actual, anterior };
    },
    stream: ({ params }) =>
      forkJoin({
        resumen: this.reportes.resumenPorSucursal(params.actual),
        productos: this.reportes.productosPorSucursal(params.actual),
        cajeros: this.reportes.rendimientoCajeros(params.actual),
        resumenAnterior: this.reportes.resumenPorSucursal(params.anterior),
        productosAnterior: this.reportes.productosPorSucursal(params.anterior),
        cajerosAnterior: this.reportes.rendimientoCajeros(params.anterior),
      }),
  });

  /**
   * Cuadratura con movimientos_stock (H4.1 T04), aparte de los datos: si falla, el resto del
   * reporte se sigue viendo.
   */
  protected readonly cuadratura = rxResource({
    params: () => {
      const rango = this.rangoValido();
      return rango ? ({ sucursales: this.seleccionadas(), ...rango } as FiltroReporte) : undefined;
    },
    stream: ({ params }) => this.reportes.cuadraturaVentasStock(params),
  });
  protected readonly estadoCuadratura = computed<EstadoCuadratura>(() => {
    if (this.cuadratura.isLoading()) return 'cargando';
    return this.cuadratura.status() === 'error' ? 'error' : 'listo';
  });
  protected readonly filasCuadratura = computed(() =>
    this.cuadratura.hasValue() ? this.cuadratura.value() : null,
  );

  /** Costo actual de los productos para el margen (H4.4 T03); no depende de los filtros. */
  protected readonly costos = rxResource({
    stream: () => this.reportes.costoActualProductos(),
  });
  protected readonly costosProductos = computed(() =>
    this.costos.hasValue() ? this.costos.value() : [],
  );
  protected readonly estadoCostos = computed<EstadoCostos>(() => {
    if (this.costos.hasValue()) return 'listo';
    return this.costos.status() === 'error' ? 'error' : 'cargando';
  });

  /** Turnos reales del período para la pestaña Cajeros (H4.3 T03). */
  protected readonly listaTurnos = rxResource({
    params: () => this.filtroActual() ?? undefined,
    stream: ({ params }) => this.reportes.turnosReporte(params),
  });
  protected readonly turnos = computed(() =>
    this.listaTurnos.hasValue() ? this.listaTurnos.value() : [],
  );
  /** Turno elegido; al cambiar sucursales o período se vuelve a "Todos los turnos". */
  protected readonly turno = linkedSignal<FiltroReporte | null, FiltroTurno>({
    source: () => this.filtroActual(),
    computation: () => null,
  });
  /** Cifras por cajero del turno elegido (solo se piden si hay uno). */
  protected readonly cajerosTurno = rxResource({
    params: () => {
      const filtro = this.filtroActual();
      const turno = this.turno();
      return filtro && turno !== null ? { filtro, turno } : undefined;
    },
    stream: ({ params }) => this.reportes.rendimientoCajeros(params.filtro, params.turno),
  });
  private readonly ultimosCajerosTurno = linkedSignal<
    RendimientoCajero[] | undefined,
    RendimientoCajero[]
  >({
    source: () => (this.cajerosTurno.hasValue() ? this.cajerosTurno.value() : undefined),
    computation: (valor, anterior) => valor ?? anterior?.value ?? [],
  });
  protected readonly cargandoTurno = computed(() => this.cajerosTurno.isLoading());

  /** Lo que muestra la pestaña Cajeros: el período completo o el turno elegido. */
  protected cajerosVisibles(datos: DatosReporte): RendimientoCajero[] {
    return this.turno() === null ? datos.cajeros : this.ultimosCajerosTurno();
  }

  /** Mientras se consultan los filtros nuevos se mantienen los datos anteriores, atenuados. */
  protected readonly ultimos = linkedSignal<DatosReporte | undefined, DatosReporte | null>({
    source: () => (this.datos.hasValue() ? this.datos.value() : undefined),
    computation: (valor, anterior) => valor ?? anterior?.value ?? null,
  });
  protected readonly cargando = computed(() => this.datos.isLoading());
  protected readonly conError = computed(() => this.datos.status() === 'error');
  protected readonly sinPermiso = computed(() => {
    const error = this.datos.error();
    return error instanceof HttpErrorResponse && error.status === 403;
  });

  private readonly totales = computed(() => {
    const datos = this.ultimos();
    return datos
      ? { actual: totalesReporte(datos.resumen), antes: totalesReporte(datos.resumenAnterior) }
      : null;
  });

  /** H4.2: sin ninguna venta (ni anulada) en el período se muestra "Sin ventas en este período". */
  protected readonly sinVentas = computed(() => {
    const totales = this.totales();
    return !!totales && totales.actual.ventas === 0 && totales.actual.anuladas === 0;
  });

  /** Lo que hubo en el período anterior, para el mensaje sin ventas. */
  protected readonly textoAnteriorSinVentas = computed(() => {
    const antes = this.totales()?.antes;
    if (!antes?.ventas) return `${this.etiquetaAnterior()}: tampoco hubo ventas.`;
    return `${this.etiquetaAnterior()}: ${formatoNumero.format(antes.ventas)} ${
      antes.ventas === 1 ? 'venta' : 'ventas'
    } por ${formatoClp.format(antes.total)}.`;
  });

  protected readonly tarjetas = computed<Tarjeta[]>(() => {
    const totales = this.totales();
    if (!totales) return [];
    const { actual, antes } = totales;
    const clp = (valor: number) => formatoClp.format(valor);
    const numero = (valor: number) => formatoNumero.format(valor);
    return [
      {
        clave: 'total',
        etiqueta: 'Total vendido',
        valor: clp(actual.total),
        anterior: clp(antes.total),
        variacion: variacion(actual.total, antes.total),
      },
      {
        clave: 'ventas',
        etiqueta: 'Ventas',
        valor: numero(actual.ventas),
        anterior: numero(antes.ventas),
        variacion: variacion(actual.ventas, antes.ventas),
      },
      {
        clave: 'ticket',
        etiqueta: 'Ticket promedio',
        valor: clp(actual.ticketPromedio),
        anterior: clp(antes.ticketPromedio),
        variacion: variacion(actual.ticketPromedio, antes.ticketPromedio),
      },
      {
        clave: 'anuladas',
        etiqueta: 'Anuladas',
        valor: numero(actual.anuladas),
        anterior: numero(antes.anuladas),
        variacion: variacion(actual.anuladas, antes.anuladas),
        menosEsMejor: true,
        detalle: `${clp(actual.totalAnuladas)} fuera del total`,
      },
    ];
  });

  /** Lo más destacado del período: la sucursal, el producto y el cajero que más vendieron. */
  protected readonly destacados = computed(() => {
    const datos = this.ultimos();
    if (!datos) return [];
    const sucursal = [...datos.resumen]
      .filter((s) => s.total > 0)
      .sort((a, b) => b.total - a.total)[0];
    const producto = ordenarProductos(agruparProductos(datos.productos), 'monto')[0];
    const cajero = [...datos.cajeros]
      .filter((c) => c.cajeroId !== null && c.total > 0)
      .sort((a, b) => b.total - a.total)[0];
    const clp = (valor: number) => formatoClp.format(valor);
    const numero = (valor: number) => formatoNumero.format(valor);
    return [
      {
        clave: 'sucursal',
        etiqueta: 'Sucursal que más vendió',
        nombre: sucursal?.sucursal ?? '—',
        detalle: sucursal
          ? `${clp(sucursal.total)} · ${numero(sucursal.ventas)} ventas`
          : 'Sin ventas',
        vista: 'sucursales' as Vista,
      },
      {
        clave: 'producto',
        etiqueta: 'Producto estrella',
        nombre: producto?.producto ?? '—',
        detalle: producto
          ? `${clp(producto.monto)} · ${numero(producto.unidades)} unidades`
          : 'Sin ventas',
        vista: 'productos' as Vista,
      },
      {
        clave: 'cajero',
        etiqueta: 'Cajero con más ventas',
        nombre: cajero?.cajero ?? '—',
        detalle: cajero ? `${clp(cajero.total)} · ${numero(cajero.ventas)} ventas` : 'Sin ventas',
        vista: 'cajeros' as Vista,
      },
    ];
  });

  protected cambiarVista(vista: Vista): void {
    this.vista.set(vista);
    if (!this.ruta) return;
    void this.router.navigate([], {
      relativeTo: this.ruta,
      queryParams: { vista: vista === 'sucursales' ? null : vista },
      queryParamsHandling: 'merge',
      replaceUrl: true,
    });
  }

  protected reintentar(): void {
    this.datos.reload();
  }

  protected readonly textoVariacion = textoVariacion;
  protected readonly tonoVariacion = tonoVariacion;
}
