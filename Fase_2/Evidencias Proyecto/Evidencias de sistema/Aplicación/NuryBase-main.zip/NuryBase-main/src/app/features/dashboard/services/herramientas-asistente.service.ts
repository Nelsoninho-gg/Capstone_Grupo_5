import { Injectable, inject } from '@angular/core';
import { Observable, catchError, forkJoin, map, of, switchMap, throwError, timeout } from 'rxjs';
import { SucursalesApiService } from '../../../core/api/sucursales-api.service';
import {
  construirPayloadHistoricoIA,
} from '../../inventario/models/analisis-historico.model';
import { formatearFechaChile } from '../../inventario/models/prediccion-ia.contract';
import { diasEnteros, obtenerEstimacionPreliminar } from '../../inventario/models/prediccion.model';
import {
  PrediccionStockService,
  calcularPrediccionArticulo,
} from '../../inventario/services/prediccion-stock.service';
import { PeriodoDashboard, TIEMPO_LIMITE_CONSULTA_MS, costoUnitario } from '../models/dashboard.model';
import {
  AgregacionFilas,
  LlamadaHerramienta,
  MAX_FACTURAS_LEIDAS,
  OrdenRanking,
  ResultadoHerramienta,
  agregarFilas,
  calcularMargenProducto,
  calcularRankingProductos,
  contarPorMedioPago,
  fechasEnHoraChile,
  listarFacturasIngresadas,
  resumirVentasPeriodo,
} from '../models/herramientas-asistente.model';
import {
  ConsultaAsistente,
  ConsultasAsistenteService,
  EsquemaBase,
} from './consultas-asistente.service';
import { DashboardDatosService } from './dashboard-datos.service';

const FECHA = /^\d{4}-\d{2}-\d{2}$/;
const MAX_PRODUCTOS_MARGEN = 20;
const MAX_ARTICULOS_PREDICCION = 30;
const MAX_CAMBIOS_AUDITORIA = 30;
const PERIODOS: readonly PeriodoDashboard[] = ['1d', '7d', '30d', '90d'];
const ANULADA_SIN_RESPONSABLE = 'Antes de registrar al responsable';
const NOTA_SIN_FILAS =
  'Sin filas. Si filtraste texto con eq., puede ser por mayúsculas: reintenta con ilike antes de concluir que no hay datos.';

type Filas = Record<string, unknown>[];

/** Ejecuta los cálculos que pide el modelo de IA: mismos datos, mismos resultados. */
@Injectable({ providedIn: 'root' })
export class HerramientasAsistenteService {
  private readonly consultas = inject(ConsultasAsistenteService);
  private readonly sucursalesApi = inject(SucursalesApiService);
  private readonly dashboard = inject(DashboardDatosService);
  private readonly prediccion = inject(PrediccionStockService);

  /** Nunca falla: un error vuelve como dato para que el modelo corrija o lo informe. */
  ejecutar(llamada: LlamadaHerramienta, esquema: EsquemaBase): Observable<ResultadoHerramienta> {
    const parametros = llamada.parametros ?? {};
    let calculo: Observable<unknown>;
    try {
      calculo = this.calcular(llamada.nombre, parametros, esquema);
    } catch (error) {
      calculo = throwError(() => error);
    }
    return calculo.pipe(
      timeout({
        first: TIEMPO_LIMITE_CONSULTA_MS,
        with: () => throwError(() => new Error('La consulta tardó más de 30 segundos y se canceló.')),
      }),
      map((datos) => ({ herramienta: llamada.nombre, parametros, datos: fechasEnHoraChile(datos) })),
      catchError((error: Error) =>
        of({ herramienta: llamada.nombre, parametros, error: error?.message ?? String(error) }),
      ),
    );
  }

  private calcular(
    nombre: string,
    p: Record<string, unknown>,
    esquema: EsquemaBase,
  ): Observable<unknown> {
    switch (nombre) {
      case 'margen_producto':
        return this.margenProducto(p, esquema);
      case 'auditoria_usuarios':
        return this.auditoriaUsuarios(p, esquema);
      case 'stock_articulo':
        return this.stockArticulo(p, esquema);
      case 'receta_producto':
        return this.recetaProducto(p, esquema);
      case 'ventas_periodo':
        return this.ventasPeriodo(p, esquema);
      case 'ranking_productos':
        return this.rankingProductos(p, esquema);
      case 'ranking_cajeros':
        return this.reporte('fn_reporte_cajeros', p, esquema).pipe(
          map((filas) => filas.slice().sort((a, b) => Number(b['total']) - Number(a['total']))),
        );
      case 'analisis_dashboard':
        return this.analisisDashboard(p);
      case 'prediccion_stock':
        return this.prediccionStock(p);
      case 'por_comprar':
        return this.leer(
          {
            recurso: 'rpc/fn_articulos_por_comprar',
            filtros: {
              p_dias: String(Number(p['dias']) || 1),
              ...(Number.isInteger(p['sucursal_id']) ? { p_sucursal_id: String(p['sucursal_id']) } : {}),
            },
          },
          esquema,
        );
      case 'facturas_ingresadas':
        return this.facturasIngresadas(p, esquema);
      case 'consultar':
        return this.consultar(p, esquema);
      default:
        return throwError(() => new Error(`Herramienta desconocida: ${nombre}`));
    }
  }

  /** Lee todas las filas o falla: nunca calcula sobre datos incompletos. */
  private leer(consulta: ConsultaAsistente, esquema: EsquemaBase): Observable<Filas> {
    return this.consultas.ejecutar(consulta, esquema, true).pipe(
      map((resultado) => {
        if (resultado.error) {
          throw new Error(resultado.error);
        }
        if (resultado.truncado) {
          throw new Error(
            `Hay ${resultado.total} filas y solo se leyeron ${resultado.filas?.length}: acota la consulta.`,
          );
        }
        return (resultado.filas ?? []) as Filas;
      }),
    );
  }

  private margenProducto(p: Record<string, unknown>, esquema: EsquemaBase): Observable<unknown> {
    const filtro: Record<string, string> | null = Number.isInteger(p['producto_id'])
      ? { id: `eq.${p['producto_id']}` }
      : typeof p['nombre'] === 'string' && p['nombre'].trim()
        ? { nombre: `ilike.*${p['nombre'].trim()}*` }
        : null;
    if (!filtro) {
      return throwError(() => new Error('Indica nombre o producto_id'));
    }
    return forkJoin({
      productos: this.leer(
        {
          recurso: 'productos',
          select: 'id,nombre,precio_venta,precio_compra,activo',
          filtros: filtro,
          limite: MAX_PRODUCTOS_MARGEN,
        },
        esquema,
      ),
      costos: this.costosReceta(esquema),
    }).pipe(
      map(({ productos, costos }) =>
        productos.map((producto) =>
          calcularMargenProducto(
            producto as Parameters<typeof calcularMargenProducto>[0],
            costos.get(Number(producto['id'])),
          ),
        ),
      ),
    );
  }

  private auditoriaUsuarios(p: Record<string, unknown>, esquema: EsquemaBase): Observable<unknown> {
    const buscado = typeof p['usuario'] === 'string' ? p['usuario'].trim().toLowerCase() : '';
    return forkJoin({
      cambios: this.leer(
        {
          recurso: 'auditoria_usuarios',
          select: 'usuario_id,accion,campo_modificado,valor_anterior,valor_nuevo,realizado_por,creado_en',
          filtros: typeof p['campo'] === 'string' ? { campo_modificado: `eq.${p['campo']}` } : undefined,
          orden: 'creado_en.desc',
        },
        esquema,
      ),
      usuarios: this.leer({ recurso: 'usuarios', select: 'id,nombre', limite: 5000 }, esquema),
    }).pipe(
      map(({ cambios, usuarios }) => {
        const nombres = new Map(usuarios.map((u) => [u['id'], String(u['nombre'])]));
        return cambios
          .map(({ usuario_id, realizado_por, ...cambio }) => ({
            usuario: usuario_id === null ? 'Usuario no disponible' : (nombres.get(usuario_id) ?? `id ${usuario_id}`),
            ...cambio,
            realizado_por: realizado_por === null ? null : (nombres.get(realizado_por) ?? `id ${realizado_por}`),
          }))
          .filter((cambio) => !buscado || cambio.usuario.toLowerCase().includes(buscado))
          .slice(0, Number(p['limite']) || MAX_CAMBIOS_AUDITORIA);
      }),
    );
  }

  private stockArticulo(p: Record<string, unknown>, esquema: EsquemaBase): Observable<unknown> {
    if (typeof p['nombre'] !== 'string' || !p['nombre'].trim()) {
      return throwError(() => new Error('Indica nombre'));
    }
    return this.leer(
      {
        recurso: 'v_existencias_articulos',
        select: 'nombre,tipo,unidad,activo,sucursal,stock_actual,stock_minimo',
        filtros: {
          nombre: `ilike.*${p['nombre'].trim()}*`,
          ...(Number.isInteger(p['sucursal_id']) ? { sucursal_id: `eq.${p['sucursal_id']}` } : {}),
        },
        limite: MAX_PRODUCTOS_MARGEN,
      },
      esquema,
    );
  }

  private recetaProducto(p: Record<string, unknown>, esquema: EsquemaBase): Observable<unknown> {
    const filtro: Record<string, string> | null = Number.isInteger(p['producto_id'])
      ? { id: `eq.${p['producto_id']}` }
      : typeof p['nombre'] === 'string' && p['nombre'].trim()
        ? { nombre: `ilike.*${p['nombre'].trim()}*` }
        : null;
    if (!filtro) {
      return throwError(() => new Error('Indica nombre o producto_id'));
    }
    return forkJoin({
      productos: this.leer(
        { recurso: 'productos', select: 'id,nombre,activo', filtros: filtro, limite: MAX_PRODUCTOS_MARGEN },
        esquema,
      ),
      costos: this.costosReceta(esquema),
    }).pipe(
      switchMap(({ productos, costos }) => {
        if (productos.length === 0) {
          return of([]);
        }
        const ids = productos.map((producto) => producto['id']).join(',');
        return this.leer(
          {
            recurso: 'recetas',
            select: 'producto_id,cantidad_necesaria,ingredientes(nombre),unidades_medida(nombre)',
            filtros: { producto_id: `in.(${ids})` },
            limite: 5000,
          },
          esquema,
        ).pipe(
          map((lineas) =>
            productos.map((producto) => ({
              producto: producto['nombre'],
              activo: producto['activo'],
              costo_receta: costos.get(Number(producto['id'])) ?? null,
              ingredientes: lineas
                .filter((linea) => linea['producto_id'] === producto['id'])
                .map((linea) => ({
                  ingrediente: (linea['ingredientes'] as { nombre?: string } | null)?.nombre,
                  cantidad: linea['cantidad_necesaria'],
                  unidad: (linea['unidades_medida'] as { nombre?: string } | null)?.nombre,
                })),
            })),
          ),
        );
      }),
    );
  }

  private costosReceta(esquema: EsquemaBase): Observable<Map<number, number>> {
    return this.leer(
      { recurso: 'v_costo_producto', select: 'producto_id,costo_receta', limite: 5000 },
      esquema,
    ).pipe(
      map((filas) => new Map(filas.map((f) => [Number(f['producto_id']), Number(f['costo_receta']) || 0]))),
    );
  }

  /** Reportes de sucursal: por defecto toda la red, porque un {} vacío no devuelve nada. */
  private reporte(funcion: string, p: Record<string, unknown>, esquema: EsquemaBase): Observable<Filas> {
    const { desde, hasta, sucursal_ids: ids } = p;
    if (typeof desde !== 'string' || typeof hasta !== 'string' || !FECHA.test(desde) || !FECHA.test(hasta)) {
      return throwError(() => new Error('desde y hasta son obligatorios, en formato YYYY-MM-DD'));
    }
    const pedidas = Array.isArray(ids) ? ids.filter(Number.isInteger) : [];
    const sucursales$ = pedidas.length
      ? of(pedidas as number[])
      : this.sucursalesApi.listar().pipe(map((lista) => lista.map((s) => s.id)));

    return sucursales$.pipe(
      switchMap((sucursales) =>
        this.leer(
          {
            recurso: `rpc/${funcion}`,
            filtros: { p_desde: desde, p_hasta: hasta, p_sucursales: `{${sucursales.join(',')}}` },
            limite: 5000,
          },
          esquema,
        ),
      ),
    );
  }

  private ventasPeriodo(p: Record<string, unknown>, esquema: EsquemaBase): Observable<unknown> {
    return this.reporte('fn_reporte_ventas_sucursal', p, esquema).pipe(
      switchMap((filas) => {
        const sucursales = filas.map((f) => f['sucursal_id']).filter(Number.isInteger);
        if (sucursales.length === 0) {
          return of(resumirVentasPeriodo(filas));
        }
        const { desde, hasta } = p as { desde: string; hasta: string };
        // Rango en UTC con zona explícita más amplio que los días en Chile; contarPorMedioPago deja solo los pedidos.
        const finUtc = new Date(Date.parse(`${hasta}T00:00:00Z`) + 30 * 3_600_000).toISOString();
        return this.leer(
          {
            recurso: 'ventas',
            select: 'fecha_venta,medio_pago',
            filtros: {
              anulada: 'eq.false',
              sucursal_id: `in.(${sucursales.join(',')})`,
              fecha_venta: [`gte.${desde}T00:00:00.000Z`, `lt.${finUtc}`],
            },
            limite: 5000,
          },
          esquema,
        ).pipe(
          map((ventas) => contarPorMedioPago(ventas, desde, hasta)),
          catchError(() => of(null)),
          map((ventasPorMedio) => resumirVentasPeriodo(filas, ventasPorMedio)),
        );
      }),
    );
  }

  private rankingProductos(p: Record<string, unknown>, esquema: EsquemaBase): Observable<unknown> {
    return forkJoin({
      filas: this.reporte('fn_reporte_productos_sucursal', p, esquema),
      costos: this.costosReceta(esquema),
      compras: this.leer({ recurso: 'productos', select: 'id,precio_compra', limite: 5000 }, esquema),
    }).pipe(
      map(({ filas, costos, compras }) => {
        const precios = new Map(compras.map((c) => [Number(c['id']), c['precio_compra']]));
        return calcularRankingProductos(
          filas,
          (id) => costoUnitario(costos.get(id), precios.get(id)),
          p['orden'] as OrdenRanking,
          Number(p['limite']) || undefined,
        );
      }),
    );
  }

  private analisisDashboard(p: Record<string, unknown>): Observable<unknown> {
    const periodo = PERIODOS.includes(p['periodo'] as PeriodoDashboard)
      ? (p['periodo'] as PeriodoDashboard)
      : '30d';
    const sucursalId = Number.isInteger(p['sucursal_id']) ? (p['sucursal_id'] as number) : null;
    return this.dashboard.cargar(periodo, sucursalId).pipe(
      map(({ escenario, diasHistorial }) => ({
        periodo,
        sucursal_id: sucursalId,
        dias_de_historial: diasHistorial,
        // La IA interpreta este estado, pero la cifra de cierre la calcula el algoritmo.
        proyeccion: escenario.proyeccion,
        kpis: escenario.kpis,
        familias: escenario.lineasNegocio,
        productos_comprados_juntos: escenario.comprasConjuntas,
        productos_destacados: escenario.productosDestacados,
        productos_mas_vendidos: escenario.productosMasVendidos,
        demanda_por_franja: escenario.demandaHoraria,
        ventas_por_dia_semana: escenario.demandaPorDiaSemana,
      })),
    );
  }

  private prediccionStock(p: Record<string, unknown>): Observable<unknown> {
    const sucursalId = Number.isInteger(p['sucursal_id']) ? (p['sucursal_id'] as number) : null;
    const buscado = typeof p['articulo'] === 'string' ? p['articulo'].trim().toLowerCase() : '';
    const hoy = formatearFechaChile(new Date());

    return this.prediccion.cargarArticulos(sucursalId).pipe(
      map((articulos) =>
        articulos
          .filter((a) => !buscado || a.articulo.toLowerCase().includes(buscado))
          .map((a) => {
            const calculo = calcularPrediccionArticulo(a, hoy);
            const { metricasConsumo, picosAislados } = construirPayloadHistoricoIA(a, a.serieConsumo ?? []);
            const preliminar = obtenerEstimacionPreliminar(a);
            return {
              articulo: a.articulo,
              sucursal: a.sucursal,
              unidad: a.unidad,
              stock_actual: a.stockActual,
              stock_minimo: a.stockMinimo,
              dias_de_historial: a.diasHistorial,
              consumo_diario_base: a.consumoDiarioBase,
              consumo_diario_sin_filtrar: metricasConsumo.promedioDiarioSinFiltrar,
              dias_operativos_contados: a.serieConsumo?.length ?? 0,
              picos_excluidos: picosAislados,
              estado: calculo.estado,
              dias_hasta_minimo: diasEnteros(calculo.diasHastaMinimo ?? preliminar.diasCoberturaEstimados),
              fecha_recomendada_pedido: calculo.fechaRecomendadaPedido,
              cantidad_sugerida: preliminar.esPreliminar
                ? preliminar.compraSugeridaPreliminar
                : calculo.cantidadSugerida,
              es_preliminar: preliminar.esPreliminar,
            };
          })
          .slice(0, MAX_ARTICULOS_PREDICCION),
      ),
    );
  }

  private facturasIngresadas(p: Record<string, unknown>, esquema: EsquemaBase): Observable<unknown> {
    const { emisor, desde, hasta } = p;
    if ([desde, hasta].some((fecha) => fecha && (typeof fecha !== 'string' || !FECHA.test(fecha)))) {
      return throwError(() => new Error('desde y hasta deben ir en formato YYYY-MM-DD'));
    }
    return this.leer(
      { recurso: 'rpc/fn_listar_ingresos_factura', filtros: { p_limite: String(MAX_FACTURAS_LEIDAS) } },
      esquema,
    ).pipe(
      map((filas) =>
        listarFacturasIngresadas(filas, {
          emisor: typeof emisor === 'string' ? emisor : undefined,
          desde: desde as string | undefined,
          hasta: hasta as string | undefined,
          limite: Number(p['limite']) || undefined,
        }),
      ),
    );
  }

  private consultar(p: Record<string, unknown>, esquema: EsquemaBase): Observable<unknown> {
    const consulta: ConsultaAsistente = {
      recurso: String(p['recurso'] ?? ''),
      select: p['select'] as string | undefined,
      filtros: excluirAnuladas(String(p['recurso'] ?? ''), normalizarFiltros(p['filtros'])),
      orden: p['orden'] as string | undefined,
      limite: p['limite'] as number | undefined,
    };
    const agregar = p['agregar'] as AgregacionFilas | undefined;

    if (agregar) {
      // Sin `orden`: uno sobre la métrica haría fallar a PostgREST y el resultado ya viene ordenado.
      // Sin embeber, basta con las columnas del cálculo.
      const columnas = [agregar.agrupar_por, ...(agregar.suma ?? []), ...(agregar.promedio ?? [])].filter(Boolean);
      const embebe = consulta.select?.includes('(');
      if (agregar.agrupar_por?.includes('.') && !embebe) {
        return throwError(
          () =>
            new Error(
              `Para agrupar por ${agregar.agrupar_por} trae esa tabla en select, por ejemplo: usuarios!anulada_por(nombre)`,
            ),
        );
      }
      // Anulada, pero sin responsable: es anterior a que la base lo registrara, no un dato perdido.
      const porResponsableDeAnulacion =
        consulta.recurso === 'ventas' &&
        String(consulta.filtros?.['anulada']).includes('eq.true') &&
        `${consulta.select} ${agregar.agrupar_por}`.includes('anulada_por');
      return this.leer(
        {
          recurso: consulta.recurso,
          filtros: consulta.filtros,
          select: !embebe && columnas.length > 0 ? [...new Set(columnas)].join(',') : consulta.select,
          limite: 5000,
        },
        esquema,
      ).pipe(map((filas) => (
          filas.length > 0
            ? agregarFilas(filas, agregar, porResponsableDeAnulacion ? ANULADA_SIN_RESPONSABLE : undefined)
            : { filas: 0, nota_para_ia: NOTA_SIN_FILAS }
        )));
    }
    return this.consultas.ejecutar(consulta, esquema).pipe(
      map((resultado) => {
        if (resultado.error) {
          throw new Error(resultado.error);
        }
        return {
          filas: resultado.filas,
          filas_encontradas: resultado.total,
          truncado: resultado.truncado,
          nota_para_ia: resultado.filas?.length ? undefined : NOTA_SIN_FILAS,
        };
      }),
    );
  }
}

/** Una venta anulada no es una venta: solo se incluye si el modelo filtra por `anulada` a propósito. */
function excluirAnuladas(
  recurso: string,
  filtros: Record<string, string | string[]> | undefined,
): Record<string, string | string[]> | undefined {
  return recurso === 'ventas' && !filtros?.['anulada'] ? { ...filtros, anulada: 'eq.false' } : filtros;
}

/** Acepta {"a":"eq.1"}, {"a":["gte.1","lte.2"]} y la lista ["a.eq.1"] que a veces envía el modelo. */
function normalizarFiltros(filtros: unknown): Record<string, string | string[]> | undefined {
  if (!Array.isArray(filtros)) {
    return filtros as Record<string, string | string[]> | undefined;
  }
  const normalizados: Record<string, string[]> = {};
  for (const filtro of filtros.filter((f): f is string => typeof f === 'string')) {
    const punto = filtro.indexOf('.');
    if (punto > 0) {
      (normalizados[filtro.slice(0, punto)] ??= []).push(filtro.slice(punto + 1));
    }
  }
  return normalizados;
}
