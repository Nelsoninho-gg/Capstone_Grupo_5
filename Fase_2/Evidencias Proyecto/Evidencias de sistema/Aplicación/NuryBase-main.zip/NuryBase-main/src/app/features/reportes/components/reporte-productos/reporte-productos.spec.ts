import { TestBed } from '@angular/core/testing';
import { productoDePrueba } from '../../models/datos-prueba';
import { ReporteProductos } from './reporte-productos';

describe('ReporteProductos', () => {
  const cafe = productoDePrueba();
  const cafeNunoa = productoDePrueba({
    sucursalId: 2,
    sucursal: 'Ñuñoa',
    unidades: 5,
    ventas: 4,
    monto: 9000,
  });
  const torta = productoDePrueba({
    productoId: 2,
    producto: 'Torta de chocolate',
    categoria: 'Pastelería',
    unidades: 3,
    ventas: 3,
    monto: 36000,
  });

  function render(
    productos = [cafe, cafeNunoa, torta],
    anteriores = [productoDePrueba({ monto: 20000 })],
  ) {
    const fixture = TestBed.createComponent(ReporteProductos);
    fixture.componentRef.setInput('productos', productos);
    fixture.componentRef.setInput('productosAnterior', anteriores);
    fixture.detectChanges();
    const element = fixture.nativeElement as HTMLElement;
    const nombres = () =>
      Array.from(element.querySelectorAll('tbody tr')).map((f) =>
        f.querySelector('.product-name > span:last-child')?.firstChild?.textContent?.trim(),
      );
    const cambiar = (etiqueta: string, valor: string) => {
      const control = element.querySelector<HTMLInputElement | HTMLButtonElement>(
        `[aria-label="${etiqueta}"]`,
      )!;
      if (control.tagName === 'INPUT') {
        (control as HTMLInputElement).value = valor;
        control.dispatchEvent(new Event('input'));
      } else {
        control.click();
        fixture.detectChanges();
        control
          .closest('app-desplegable')!
          .querySelector<HTMLButtonElement>(`[role="option"][data-value="${valor}"]`)!
          .click();
      }
      fixture.detectChanges();
    };
    return { element, nombres, cambiar, fixture };
  }

  it('joins the branches and shows units and amount separately, sorted by amount', () => {
    const { element, nombres } = render();
    expect(nombres()).toEqual(['Torta de chocolate', 'Café americano']);
    const cafeFila = element.querySelectorAll('tbody tr')[1];
    expect(cafeFila.querySelector('[data-label="Unidades"]')?.textContent?.trim()).toBe('15');
    expect(cafeFila.querySelector('[data-label="Monto"]')?.textContent?.trim()).toBe('$27.000');
    expect(cafeFila.querySelector('[data-label="% del monto"]')?.textContent?.trim()).toBe(
      '42,9 %',
    );
    expect(cafeFila.querySelector('[data-label="Período anterior"]')?.textContent).toContain(
      '▲ 35 %',
    );
    expect(cafeFila.querySelector('[data-label="Período anterior"]')?.textContent).toContain(
      '$20.000',
    );
  });

  it('sorts by units or sales and filters by text and category', () => {
    const { nombres, cambiar, element, fixture } = render();
    cambiar('Ordenar productos por', 'unidades');
    expect(nombres()).toEqual(['Café americano', 'Torta de chocolate']);

    (element.querySelector('th button') as HTMLButtonElement).click();
    fixture.detectChanges();
    expect(nombres()[0]).toBe('Café americano');

    cambiar('Buscar producto', 'TORTA');
    expect(nombres()).toEqual(['Torta de chocolate']);
    cambiar('Buscar producto', '');
    cambiar('Categoría', 'Bebidas');
    expect(nombres()).toEqual(['Café americano']);
    cambiar('Buscar producto', 'pan');
    expect(element.textContent).toContain('Ningún producto coincide con la búsqueda.');
  });

  it('says there were no sales', () => {
    expect(render([], []).element.textContent).toContain('Sin ventas en este período.');
  });

  describe('margin (H4.4)', () => {
    const costo = (productoId: number, costoUnitario: number | null, ingredientesSinCosto = 0) => ({
      productoId,
      origen: costoUnitario === null ? ('sin_costo' as const) : ('receta' as const),
      costoUnitario,
      ingredientes: 2,
      ingredientesSinCosto,
    });

    function conCostos(
      costos: ReturnType<typeof costo>[],
      estado = 'listo',
      productos = [cafe, cafeNunoa, torta],
    ) {
      const vista = render(productos);
      vista.fixture.componentRef.setInput('costos', costos);
      vista.fixture.componentRef.setInput('estadoCostos', estado);
      vista.fixture.detectChanges();
      return vista;
    }
    const celdaMargen = (element: HTMLElement, fila: number) =>
      element.querySelectorAll('tbody tr')[fila].querySelector('[data-label="Margen"]')!;

    it('shows the margin with the current cost, and sorts by it', () => {
      // Café: 15 un × 1.500 = 22.500 de costo sobre 27.000 → 4.500 (16,7 %).
      // Torta: 3 un × 4.000 = 12.000 sobre 36.000 → 24.000 (66,7 %).
      const { element, nombres, cambiar } = conCostos([costo(1, 1500), costo(2, 4000)]);
      expect(celdaMargen(element, 1).textContent).toContain('$4.500');
      expect(celdaMargen(element, 1).textContent).toContain('16,7 % · costo $1.500 c/u');
      expect(element.querySelector('.summary')?.textContent).toContain('margen $28.500 (45,2 %)');

      cambiar('Ordenar productos por', 'margenPct');
      expect(nombres()).toEqual(['Torta de chocolate', 'Café americano']);
    });

    it('shows products without cost apart, warns incomplete recipes and negative margins', () => {
      const { element } = conCostos([costo(1, 2000, 1), costo(2, null)]);
      expect(celdaMargen(element, 0).textContent?.trim()).toBe('Sin costo');
      const cafe = celdaMargen(element, 1);
      expect(cafe.textContent).toContain('-$3.000');
      expect(cafe.textContent).toContain('costo incompleto');
      expect(cafe.className).toContain('negative');
      const aviso = element.querySelector('.cost-notice')?.textContent ?? '';
      expect(aviso).toContain('1 producto no tiene costo cargado');
      expect(aviso).toContain('1 tiene receta con ingredientes sin costo');
    });

    it('highlights high-volume, low-margin products', () => {
      // Café (más unidades) con 10 % de margen: 15 × 1.620 = 24.300 sobre 27.000.
      const { element } = conCostos([costo(1, 1620), costo(2, 4000)]);
      const lista = element.querySelector('.low-margin')?.textContent ?? '';
      expect(lista).toContain('Café americano');
      expect(lista).toContain('10 % · $2.700');
      expect(lista).not.toContain('Torta');
    });

    it('suggests high-margin, low-volume products to promote', () => {
      // Torta: 3 unidades (la que menos vende) y 66,7 % de margen; el resto vende más.
      const otros = [3, 4, 5].map((id) =>
        productoDePrueba({ productoId: id, producto: `Bebida ${id}`, unidades: 20, monto: 20000 }),
      );
      const { element } = conCostos(
        [costo(1, 1500), costo(2, 4000), ...otros.map((p) => costo(p.productoId, 700))],
        'listo',
        [cafe, cafeNunoa, torta, ...otros],
      );
      const lista = element.querySelector('.promote')?.textContent ?? '';
      expect(lista).toContain('Torta de chocolate');
      expect(lista).toContain('66,7 % · $24.000');
      expect(lista).not.toContain('Café');
    });

    it('keeps the sales without margin when the costs fail', () => {
      const { element } = conCostos([], 'error');
      expect(element.querySelector('[data-label="Margen"]')).toBeNull();
      expect(element.querySelector('.cost-notice')?.textContent).toContain(
        'No se pudo cargar el costo',
      );
      expect(element.querySelector('#low-margin-title')).toBeNull();
    });
  });
});
