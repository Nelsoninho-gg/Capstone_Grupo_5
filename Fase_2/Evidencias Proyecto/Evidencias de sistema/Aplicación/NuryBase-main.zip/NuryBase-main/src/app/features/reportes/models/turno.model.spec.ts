import { TurnoReporte } from './reportes.model';
import { etiquetaTurno, horarioTurno } from './turno.model';

const turno = (parcial: Partial<TurnoReporte>): TurnoReporte => ({
  turnoId: 7,
  cajeroId: 3,
  cajero: 'Ana',
  sucursalId: 1,
  sucursal: 'Providencia',
  inicio: '2026-10-20T09:00:00',
  fin: '2026-10-20T17:00:00',
  ventas: 4,
  total: 12000,
  anuladas: 0,
  ...parcial,
});

describe('horarioTurno', () => {
  it('shows a same-day shift with its weekday', () => {
    expect(horarioTurno(turno({}))).toBe('mar 20-10 · 09:00 a 17:00');
  });

  it('shows both days when the shift crosses midnight', () => {
    expect(horarioTurno(turno({ inicio: '2026-10-20T23:00:00', fin: '2026-10-21T02:00:00' }))).toBe(
      'mar 20-10 23:00 a mié 21-10 02:00',
    );
  });

  it('marks an open shift', () => {
    expect(horarioTurno(turno({ inicio: '2026-10-20 12:00:00', fin: null }))).toBe(
      'mar 20-10 · desde 12:00 (abierto)',
    );
  });
});

describe('etiquetaTurno', () => {
  it('joins cashier and schedule, or names the row without shift', () => {
    expect(etiquetaTurno(turno({}))).toBe('Ana · mar 20-10 · 09:00 a 17:00');
    expect(
      etiquetaTurno(turno({ turnoId: null, cajero: 'Sin turno registrado', inicio: null })),
    ).toBe('Sin turno registrado');
  });
});
