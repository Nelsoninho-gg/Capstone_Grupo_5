import { ComponentFixture, TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import { ARTICULOS_PREDICTIVOS_DEMO } from '../../models/prediccion.model';
import { PrediccionStockService } from '../../services/prediccion-stock.service';
import { PanelPredictivo } from './panel-predictivo';

describe('PanelPredictivo (H4.5 T01 y T08)', () => {
  let fixture: ComponentFixture<PanelPredictivo>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PanelPredictivo],
      providers: [
        {
          provide: PrediccionStockService,
          useValue: {
            cargarArticulos: (sucursalId: number | null) =>
              of(
                ARTICULOS_PREDICTIVOS_DEMO.filter(
                  (a) => sucursalId === null || a.sucursalId === sucursalId,
                ),
              ),
            generarSugerencias: () => of({ origen: 'respaldo-local', predicciones: [] }),
          },
        },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(PanelPredictivo);
    fixture.componentRef.setInput('sucursales', [
      { id: 1, nombre: 'Nury Providencia (Equipo de desarrollo)' },
      { id: 2, nombre: 'Nury Las Condes' },
      { id: 3, nombre: 'Nury Ñuñoa' },
    ]);
    fixture.detectChanges();
  });

  it('renderiza las 4 tarjetas de resumen y la tabla limpia sin tiempos de entrega de proveedor', () => {
    const el = fixture.nativeElement as HTMLElement;
    const cards = el.querySelectorAll('.pred-card');
    expect(cards).toHaveLength(4);
    expect(el.textContent).toContain('Sugerido comprar hoy');
    expect(el.textContent).toContain('Datos insuficientes para sugerir');
    expect(el.textContent).toContain('Harina Panadera 000');
    expect(el.textContent).not.toContain('Entrega prov.');
  });

  it('marca solo las filas que interpretó la IA', () => {
    const panel = fixture.componentInstance as unknown as { resultadoIa: { set(valor: unknown): void } };
    panel.resultadoIa.set({
      origen: 'ia',
      predicciones: [
        { articuloId: ARTICULOS_PREDICTIVOS_DEMO[0].id, justificacion: 'Texto de la IA', interpretadaPorIa: true },
      ],
    });
    fixture.detectChanges();

    expect((fixture.nativeElement as HTMLElement).querySelectorAll('.fila-ia')).toHaveLength(1);
  });

  it('filtra la tabla al pulsar una tarjeta de urgencia y vuelve a mostrar todos al pulsarla otra vez', () => {
    const el = fixture.nativeElement as HTMLElement;
    const totalInicial = el.querySelectorAll('tr.pred-row').length;
    const cardInsuficiente = el.querySelectorAll<HTMLButtonElement>('.pred-card')[3];

    cardInsuficiente.click();
    fixture.detectChanges();

    const filasFiltradas = el.querySelectorAll('tr.pred-row');
    expect(filasFiltradas.length).toBeGreaterThan(0);
    expect(filasFiltradas.length).toBeLessThan(totalInicial);
    expect(el.textContent).toContain('Té Matcha Japonés');

    cardInsuficiente.click();
    fixture.detectChanges();
    expect(el.querySelectorAll('tr.pred-row').length).toBe(totalInicial);
  });

  it('muestra la duración estimada y sugerencia de compra diaria para artículos con historial suficiente', () => {
    const el = fixture.nativeElement as HTMLElement;
    expect(el.textContent).toContain('Alcanza para');
    expect(el.textContent).toContain('Sugerido para comprar');
    expect(el.querySelectorAll('.suggest-qty').length).toBeGreaterThan(0);
  });

  it('sincroniza reactivamente el filtro de sucursal cuando cambia el input sucursalInicial desde el Dashboard', () => {
    const el = fixture.nativeElement as HTMLElement;
    const totalInicial = el.querySelectorAll('tr.pred-row').length;

    fixture.componentRef.setInput('sucursalInicial', '2');
    fixture.detectChanges();

    const filasSucursal2 = el.querySelectorAll('tr.pred-row');
    expect(filasSucursal2.length).toBeGreaterThan(0);
    expect(filasSucursal2.length).toBeLessThan(totalInicial);
    expect(el.textContent).toContain('Nury Las Condes');
    expect(el.textContent).not.toContain('Harina Panadera 000');
  });

  it('filtra por tipo de artículo (Ingredientes vs Productos) y permite restablecer los filtros', () => {
    const el = fixture.nativeElement as HTMLElement;
    const totalInicial = el.querySelectorAll('tr.pred-row').length;
    const selectTipo = el.querySelector<HTMLSelectElement>('select[aria-label="Tipo de artículo"]');
    expect(selectTipo).not.toBeNull();

    selectTipo!.value = 'producto';
    selectTipo!.dispatchEvent(new Event('change'));
    fixture.detectChanges();

    const filasProductos = el.querySelectorAll('tr.pred-row');
    expect(filasProductos.length).toBe(1);
    expect(el.textContent).toContain('Croissant Vegano');

    const btnLimpiar = Array.from(el.querySelectorAll<HTMLButtonElement>('button')).find((b) =>
      b.textContent?.includes('Ver todos'),
    );
    expect(btnLimpiar).toBeDefined();
    btnLimpiar!.click();
    fixture.detectChanges();

    expect(el.querySelectorAll('tr.pred-row').length).toBe(totalInicial);
  });

  it('muestra el banner de madurez temprana y los días faltantes para artículos con menos de 28 días', () => {
    const el = fixture.nativeElement as HTMLElement;
    const banner = el.querySelector('.preliminary-maturity-banner');
    expect(banner).not.toBeNull();
    expect(banner?.textContent).toContain('Modo de estimación temprana activo');
    expect(banner?.textContent).toContain('28 días');

    // Comprobar que en la tabla se visualizan los días faltantes y etiquetas preliminares
    expect(el.textContent).toContain('faltan');
    expect(el.textContent).toContain('(preliminar)');
  });

  it('muestra la columna de interpretación y diagnóstico en cada fila del análisis', () => {
    const el = fixture.nativeElement as HTMLElement;
    const columnas = el.querySelectorAll('.predictive-table th');
    expect(Array.from(columnas).some((c) => c.textContent?.includes('Interpretación'))).toBe(true);

    const celdasDiagnostico = el.querySelectorAll('.diagnosis-cell');
    expect(celdasDiagnostico.length).toBeGreaterThan(0);
    expect(celdasDiagnostico[0].textContent?.trim().length).toBeGreaterThan(10);
  });

  describe('con muchos artículos', () => {
    const base = ARTICULOS_PREDICTIVOS_DEMO[0];
    const cargar = (articulos: unknown[]) =>
      (fixture.componentInstance as unknown as { baseArticulos: { set(v: unknown): void } }).baseArticulos.set(articulos);
    const muchos = () => [
      ...Array.from({ length: 24 }, (_, i) => ({
        ...base,
        id: `art-${i}`,
        articulo: `Con stock ${i}`,
        stockActual: 500,
        stockMinimo: 5,
        consumoDiarioBase: 1,
        diasHistorial: 40,
      })),
      { ...base, id: 'bajo', articulo: 'Bajo minimo', stockActual: -1, stockMinimo: 0, consumoDiarioBase: 0, diasHistorial: 3 },
    ];

    it('en el dashboard muestra todos por páginas, con lo urgente primero y sin selector de sucursal', () => {
      fixture.componentRef.setInput('resumen', true);
      cargar(muchos());
      fixture.detectChanges();
      const el = fixture.nativeElement as HTMLElement;

      expect(el.querySelector('#predictive-title')).toBeNull();
      expect(el.querySelector('select[aria-label="Sucursal"]')).toBeNull();
      expect(el.querySelector('input[type="search"]')).not.toBeNull();
      expect(el.querySelectorAll('tr.pred-row')).toHaveLength(10);
      expect(el.querySelector('tr.pred-row')?.textContent).toContain('Bajo minimo');
      expect(el.querySelector('.pred-pagination')?.textContent).toContain('Página 1 de 3 · 25 artículos');

      el.querySelector<HTMLButtonElement>('[aria-label="Página siguiente"]')!.click();
      fixture.detectChanges();
      expect(el.querySelector('.pred-pagination')?.textContent).toContain('Página 2 de 3');
      expect(el.querySelector('tr.pred-row')?.textContent).not.toContain('Bajo minimo');
    });

    it('en Inventario muestra 20 por página y vuelve a la primera al filtrar', () => {
      cargar(muchos());
      fixture.detectChanges();
      const el = fixture.nativeElement as HTMLElement;
      expect(el.querySelectorAll('tr.pred-row')).toHaveLength(20);

      el.querySelector<HTMLButtonElement>('[aria-label="Página siguiente"]')!.click();
      fixture.detectChanges();
      expect(el.querySelectorAll('tr.pred-row')).toHaveLength(5);

      const buscador = el.querySelector<HTMLInputElement>('input[type="search"]')!;
      buscador.value = 'Bajo minimo';
      buscador.dispatchEvent(new Event('input'));
      fixture.detectChanges();
      expect(el.querySelectorAll('tr.pred-row')).toHaveLength(1);
      expect(el.querySelector('.pred-pagination')?.textContent).toContain('Página 1 de 1');
    });

    it('no sugiere comprar cero ni muestra cifras sin formato', () => {
      cargar([
        { ...base, id: 'a', articulo: 'Sin historial', stockActual: -1, stockMinimo: 0, consumoDiarioBase: 0, diasHistorial: 14, unidad: 'un' },
        { ...base, id: 'b', articulo: 'Mucho stock', stockActual: 499968, stockMinimo: 0, consumoDiarioBase: 0.4, diasHistorial: 40, unidad: 'un' },
      ]);
      fixture.detectChanges();
      const el = fixture.nativeElement as HTMLElement;
      const texto = Array.from(el.querySelectorAll('.ia-justification-text')).map((c) => c.textContent).join(' ');

      expect(texto).toContain('faltan 14');
      expect(texto).toContain('conviene revisarlo contra el stock físico');
      expect(texto).toContain('499.968 un');
      expect(texto).toContain('más de 1 año de operación');
      expect(texto).not.toContain('+0');
      expect(texto).not.toContain('499968');
      expect(el.textContent).not.toContain('Pedido sugerido');
    });
  });
});
