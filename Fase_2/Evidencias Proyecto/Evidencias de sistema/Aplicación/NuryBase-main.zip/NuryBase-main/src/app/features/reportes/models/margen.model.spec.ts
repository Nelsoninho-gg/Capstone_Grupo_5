import { ProductoAgrupado } from './reporte-ventas.model';
import { CostoProducto } from './reportes.model';
import {
  altoMargenBajoVolumen,
  altoVolumenBajoMargen,
  margenDe,
  resumenMargen,
} from './margen.model';

const producto = (id: number, unidades: number, monto: number): ProductoAgrupado => ({
  productoId: id,
  producto: `Producto ${id}`,
  categoria: null,
  unidades,
  ventas: unidades,
  monto,
});
const costo = (
  id: number,
  unitario: number | null,
  cambio: Partial<CostoProducto> = {},
): CostoProducto => ({
  productoId: id,
  origen: unitario === null ? 'sin_costo' : 'receta',
  costoUnitario: unitario,
  ingredientes: 2,
  ingredientesSinCosto: 0,
  ...cambio,
});

describe('margenDe', () => {
  it('subtracts the current cost of the units sold from the amount charged', () => {
    expect(margenDe(producto(1, 10, 35000), costo(1, 800))).toEqual({
      estado: 'completo',
      origen: 'receta',
      costoUnitario: 800,
      costo: 8000,
      margen: 27000,
      margenPct: 77.1,
    });
  });

  it('leaves the margin empty without cost instead of assuming 0', () => {
    const sinCosto = margenDe(producto(1, 10, 35000), costo(1, null));
    expect(sinCosto.estado).toBe('sin_costo');
    expect(sinCosto.margen).toBeNull();
    expect(margenDe(producto(1, 10, 35000), undefined).margenPct).toBeNull();
  });

  it('marks an incomplete recipe, allows a negative margin and has no % without amount', () => {
    expect(
      margenDe(producto(1, 2, 1000), costo(1, 600, { ingredientesSinCosto: 1 })),
    ).toMatchObject({
      estado: 'incompleto',
      margen: -200,
      margenPct: -20,
    });
    expect(margenDe(producto(1, 2, 0), costo(1, 600)).margenPct).toBeNull();
  });
});

describe('resumenMargen', () => {
  it('adds the products with cost and counts the ones without or incomplete', () => {
    const costos = new Map([
      [1, costo(1, 800)],
      [2, costo(2, 300, { ingredientesSinCosto: 1 })],
      [3, costo(3, null)],
    ]);
    expect(
      resumenMargen([producto(1, 10, 35000), producto(2, 4, 6000), producto(3, 5, 4500)], costos),
    ).toEqual({ margen: 31800, margenPct: 77.6, sinCosto: 1, incompletos: 1 });
  });
});

describe('altoVolumenBajoMargen', () => {
  it('keeps the top quarter by units with a margin under 15 % and at least 3 units', () => {
    // 8 productos con costo completo: el cuarto superior son los 2 con más unidades.
    const productos = [
      producto(1, 50, 50000), // costo 900 → 10 %: se destaca
      producto(2, 40, 40000), // costo 500 → 50 %: margen sano
      producto(3, 30, 30000), // fuera del cuarto superior aunque tenga margen bajo
      ...[4, 5, 6, 7, 8].map((id) => producto(id, 5, 5000)),
    ];
    const costos = new Map<number, CostoProducto>([
      [1, costo(1, 900)],
      [2, costo(2, 500)],
      [3, costo(3, 990)],
      ...[4, 5, 6, 7, 8].map((id): [number, CostoProducto] => [id, costo(id, 100)]),
    ]);
    expect(altoVolumenBajoMargen(productos, costos).map((p) => p.producto.productoId)).toEqual([1]);
  });

  it('ignores products without full cost and the ones under the minimum units', () => {
    const productos = [producto(1, 2, 2000), producto(2, 50, 50000)];
    const costos = new Map([
      [1, costo(1, 990)],
      [2, costo(2, 990, { ingredientesSinCosto: 1 })],
    ]);
    expect(altoVolumenBajoMargen(productos, costos)).toEqual([]);
  });
});

describe('altoMargenBajoVolumen', () => {
  it('keeps the best quarter by margin that is also in the quarter with fewest units', () => {
    const productos = [
      producto(1, 1, 5000), // costo 1.000 → 80 %, 1 unidad: candidato a promocionar
      producto(2, 2, 2000), // costo 900 → 10 %: poco volumen pero margen bajo
      producto(3, 60, 60000), // costo 200 → 80 %: buen margen pero vende mucho
      ...[4, 5, 6, 7, 8].map((id) => producto(id, 20, 20000)),
    ];
    const costos = new Map<number, CostoProducto>([
      [1, costo(1, 1000)],
      [2, costo(2, 900)],
      [3, costo(3, 200)],
      ...[4, 5, 6, 7, 8].map((id): [number, CostoProducto] => [id, costo(id, 500)]),
    ]);
    expect(altoMargenBajoVolumen(productos, costos).map((p) => p.producto.productoId)).toEqual([1]);
  });

  it('ignores products without full cost and needs at least 4 products to compare', () => {
    const productos = [producto(1, 1, 5000), producto(2, 30, 30000)];
    const costos = new Map([
      [1, costo(1, 100, { ingredientesSinCosto: 1 })],
      [2, costo(2, 500)],
    ]);
    expect(altoMargenBajoVolumen(productos, costos)).toEqual([]);
  });
});
