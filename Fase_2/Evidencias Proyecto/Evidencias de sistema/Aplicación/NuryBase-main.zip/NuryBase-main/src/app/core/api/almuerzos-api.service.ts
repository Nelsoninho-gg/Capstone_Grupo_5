import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

export interface AlmuerzoItemPayload {
  producto_id: number;
  /** Unidades consumidas (entero mayor que 0). */
  cantidad: number;
}

export interface RegistrarAlmuerzoPayload {
  p_sucursal_id: number;
  /** Empleado que almuerza. */
  p_empleado_id: number;
  p_items: AlmuerzoItemPayload[];
}

/** Filtros de la consulta de almuerzos del administrador (H2.13 T07). */
export interface FiltroAlmuerzos {
  /** null consulta todas las sucursales. */
  sucursalId: number | null;
  /** null consulta a todos los empleados. */
  empleadoId: number | null;
  /** Días en hora de Chile (YYYY-MM-DD); ambos extremos se incluyen. */
  desde: string;
  hasta: string;
}

/** Almuerzo registrado con su detalle y los nombres de quien almuerza y quien registra. */
export interface AlmuerzoConsultaApi {
  id: number;
  fecha: string;
  creado_en: string;
  sucursal_id: number;
  empleado_id: number;
  sucursal: { nombre: string } | null;
  empleado: { nombre: string } | null;
  cajero: { nombre: string } | null;
  detalle: { cantidad: number | string; producto: { nombre: string } | null }[];
}

/** Dos FK a usuarios: PostgREST necesita el nombre de la relación para cada una. */
const CAMPOS_CONSULTA =
  'id,fecha,creado_en,sucursal_id,empleado_id,' +
  'sucursal:sucursales(nombre),' +
  'empleado:usuarios!almuerzos_empleado_empleado_id_fkey(nombre),' +
  'cajero:usuarios!almuerzos_empleado_cajero_id_fkey(nombre),' +
  'detalle:almuerzos_empleado_detalle(cantidad,producto:productos(nombre))';

/**
 * Almuerzo de empleados sin cobro (H2.13). Llama al RPC `fn_registrar_almuerzo_empleado`,
 * que en una sola transacción guarda el almuerzo y descuenta el stock de la sucursal con
 * el mismo proceso de la venta (receta o unidades), con movimientos de consumo interno.
 * Quien registra lo toma la base de la sesión; no se envía medio de pago.
 */
@Injectable({ providedIn: 'root' })
export class AlmuerzosApiService {
  private readonly http = inject(HttpClient);
  private readonly url = `${environment.apiUrl}/rpc/fn_registrar_almuerzo_empleado`;

  /** Devuelve el id del almuerzo registrado. */
  registrar(payload: RegistrarAlmuerzoPayload): Observable<number> {
    return this.http.post<number>(this.url, payload);
  }

  /**
   * Empleados que ya registraron su almuerzo en la fecha indicada (YYYY-MM-DD, hora de
   * Chile). Cada empleado puede registrar uno por día (H2.13 T04).
   */
  empleadosConAlmuerzo(fecha: string): Observable<number[]> {
    return this.http
      .get<{ empleado_id: number }[]>(`${environment.apiUrl}/almuerzos_empleado`, {
        params: { select: 'empleado_id', fecha: `eq.${fecha}` },
      })
      .pipe(map((filas) => filas.map((fila) => fila.empleado_id)));
  }

  /**
   * Almuerzos registrados por sucursal, empleado y periodo (H2.13 T07), del más reciente
   * al más antiguo. Lectura directa de las tablas: solo admin y cajero tienen SELECT.
   */
  listar(filtro: FiltroAlmuerzos): Observable<AlmuerzoConsultaApi[]> {
    const params: Record<string, string | string[]> = {
      select: CAMPOS_CONSULTA,
      fecha: [`gte.${filtro.desde}`, `lte.${filtro.hasta}`],
      order: 'fecha.desc,id.desc',
    };
    if (filtro.sucursalId !== null) params['sucursal_id'] = `eq.${filtro.sucursalId}`;
    if (filtro.empleadoId !== null) params['empleado_id'] = `eq.${filtro.empleadoId}`;
    return this.http.get<AlmuerzoConsultaApi[]>(`${environment.apiUrl}/almuerzos_empleado`, {
      params,
    });
  }
}

/** Fecha de hoy en Chile (YYYY-MM-DD), la misma que usa la base para el almuerzo. */
export function fechaHoyChile(ahora = new Date()): string {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'America/Santiago',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(ahora);
}
