import {
  agruparProductos,
  etiquetaMedio,
  normalizar,
  mediosPresentes,
  productosDestacados,
  proporcion,
  totalesReporte,
  variacion,
} from './reporte-ventas.model';
import { ProductoVendido, ResumenSucursal } from './reportes.model';

function resumen(cambio: Partial<ResumenSucursal>): ResumenSucursal {
  return {
    sucursalId: 1,
    sucursal: 'A',
    ventas: 0,
    total: 0,
    ticketPromedio: 0,
    normales: { ventas: 0, total: 0 },
    empleado: { ventas: 0, total: 0 },
    mediosPago: {},
    anuladas: { ventas: 0, total: 0 },
    ...cambio,
  };
}

describe('totalesReporte', () => {
  it('adds the branches and recomputes the average ticket over all sales', () => {
    expect(
      totalesReporte([
        resumen({ ventas: 4, total: 7500, anuladas: { ventas: 1, total: 5000 } }),
        resumen({ sucursalId: 2, ventas: 1, total: 4000 }),
      ]),
    ).toEqual({ ventas: 5, total: 11500, ticketPromedio: 2300, anuladas: 1, totalAnuladas: 5000 });
  });

  it('returns zeros without sales', () => {
    expect(totalesReporte([])).toEqual({
      ventas: 0,
      total: 0,
      ticketPromedio: 0,
      anuladas: 0,
      totalAnuladas: 0,
    });
  });
});

describe('variacion', () => {
  it('is the percentage change with one decimal', () => {
    expect(variacion(110, 100)).toBe(10);
    expect(variacion(90, 120)).toBe(-25);
    expect(variacion(1, 3)).toBe(-66.7);
  });

  it('is null without a previous value', () => {
    expect(variacion(100, 0)).toBeNull();
  });
});

describe('payment methods', () => {
  it('names the known methods and keeps a fixed order', () => {
    expect(etiquetaMedio('debito')).toBe('Débito');
    expect(etiquetaMedio('sin_medio')).toBe('Sin medio');
    expect(etiquetaMedio('sodexo')).toBe('Pluxee (Junaeb)');
    expect(etiquetaMedio('edenred')).toBe('Edenred (Junaeb)');
    expect(etiquetaMedio('cheque')).toBe('Cheque');
    expect(
      mediosPresentes([
        resumen({ mediosPago: { credito: 1, efectivo: 2 } }),
        resumen({ mediosPago: { cheque: 1, debito: 3 } }),
      ]),
    ).toEqual(['efectivo', 'debito', 'credito', 'cheque']);
  });
});

describe('proporcion', () => {
  it('is a 0–100 share of the maximum', () => {
    expect(proporcion(50, 200)).toBe(25);
    expect(proporcion(10, 0)).toBe(0);
    expect(proporcion(300, 200)).toBe(100);
  });
});

describe('productosDestacados', () => {
  const fila = (cambio: Partial<ProductoVendido>): ProductoVendido => ({
    sucursalId: 1,
    sucursal: 'A',
    productoId: 1,
    producto: 'Café',
    categoria: null,
    conReceta: false,
    unidades: 0,
    ventas: 0,
    montoBruto: 0,
    descuento: 0,
    monto: 0,
    ...cambio,
  });

  it('joins the same product across branches and sorts by amount or units', () => {
    const filas = [
      fila({ productoId: 1, producto: 'Café', unidades: 10, monto: 18000 }),
      fila({ sucursalId: 2, productoId: 1, producto: 'Café', unidades: 5, monto: 9000 }),
      fila({ productoId: 2, producto: 'Torta', unidades: 3, monto: 30000 }),
    ];
    expect(productosDestacados(filas, 'monto').map((p) => [p.producto, p.monto])).toEqual([
      ['Torta', 30000],
      ['Café', 27000],
    ]);
    expect(productosDestacados(filas, 'unidades').map((p) => [p.producto, p.unidades])).toEqual([
      ['Café', 15],
      ['Torta', 3],
    ]);
    expect(productosDestacados(filas, 'monto', 1)).toHaveLength(1);
  });
});

describe('agruparProductos y normalizar', () => {
  it('adds units, sales and amount of the same product', () => {
    const base = {
      sucursal: 'A',
      producto: 'Café',
      categoria: 'Bebidas',
      conReceta: false,
      montoBruto: 0,
      descuento: 0,
    };
    expect(
      agruparProductos([
        { ...base, sucursalId: 1, productoId: 1, unidades: 2, ventas: 2, monto: 3000 },
        { ...base, sucursalId: 2, productoId: 1, unidades: 3, ventas: 1, monto: 4500 },
      ]),
    ).toEqual([
      {
        productoId: 1,
        producto: 'Café',
        categoria: 'Bebidas',
        unidades: 5,
        ventas: 3,
        monto: 7500,
      },
    ]);
  });

  it('ignores accents and case to search', () => {
    expect(normalizar('  Café ÑANDÚ ')).toBe('cafe nandu');
  });
});
