/**
 * Generador mínimo de planillas Excel (.xlsx) sin dependencias.
 *
 * Un .xlsx es un ZIP con archivos XML (Office Open XML). Aquí se arma con una sola hoja,
 * encabezado en negrita con filtro, primera fila fija y anchos de columna. Los textos van
 * como "inline strings" y los números como números, para que Excel pueda sumar y ordenar.
 * El ZIP se guarda sin comprimir (método "stored"): las planillas son chicas y así no se
 * necesita una librería de compresión.
 */

export type CeldaXlsx = string | number | null;

export interface ColumnaXlsx {
  titulo: string;
  /** Ancho en caracteres. */
  ancho: number;
  /** Destaca la columna en negrita (por ejemplo, la cantidad a comprar). */
  destacada?: boolean;
}

export interface HojaXlsx {
  /** Nombre de la pestaña (máximo 31 caracteres; sin : \ / ? * [ ]). */
  nombre: string;
  columnas: ColumnaXlsx[];
  filas: CeldaXlsx[][];
}

export const TIPO_XLSX = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';

/** Arma el .xlsx completo como bytes, listo para un Blob. */
export function crearXlsx(hoja: HojaXlsx): Uint8Array {
  return crearZip([
    { nombre: '[Content_Types].xml', contenido: TIPOS_CONTENIDO },
    { nombre: '_rels/.rels', contenido: RELACIONES },
    { nombre: 'xl/workbook.xml', contenido: libro(hoja) },
    { nombre: 'xl/_rels/workbook.xml.rels', contenido: RELACIONES_LIBRO },
    { nombre: 'xl/styles.xml', contenido: ESTILOS },
    { nombre: 'xl/worksheets/sheet1.xml', contenido: hojaXml(hoja) },
  ]);
}

// Estilos: 0 normal, 1 encabezado, 2 número destacado.
const ESTILO_ENCABEZADO = 1;
const ESTILO_DESTACADO = 2;

const XML = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n';
const NS_HOJA = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main';
const NS_REL = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';
const NS_PAQUETE = 'http://schemas.openxmlformats.org/package/2006/relationships';

const TIPOS_CONTENIDO =
  XML +
  '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' +
  '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>' +
  '<Default Extension="xml" ContentType="application/xml"/>' +
  '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>' +
  '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' +
  '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>' +
  '</Types>';

const RELACIONES =
  XML +
  `<Relationships xmlns="${NS_PAQUETE}">` +
  `<Relationship Id="rId1" Type="${NS_REL}/officeDocument" Target="xl/workbook.xml"/>` +
  '</Relationships>';

const RELACIONES_LIBRO =
  XML +
  `<Relationships xmlns="${NS_PAQUETE}">` +
  `<Relationship Id="rId1" Type="${NS_REL}/worksheet" Target="worksheets/sheet1.xml"/>` +
  `<Relationship Id="rId2" Type="${NS_REL}/styles" Target="styles.xml"/>` +
  '</Relationships>';

const ESTILOS =
  XML +
  `<styleSheet xmlns="${NS_HOJA}">` +
  '<fonts count="2">' +
  '<font><sz val="11"/><name val="Calibri"/></font>' +
  '<font><b/><sz val="11"/><name val="Calibri"/></font>' +
  '</fonts>' +
  '<fills count="3">' +
  '<fill><patternFill patternType="none"/></fill>' +
  '<fill><patternFill patternType="gray125"/></fill>' +
  '<fill><patternFill patternType="solid"><fgColor rgb="FFE8EDE3"/><bgColor indexed="64"/></patternFill></fill>' +
  '</fills>' +
  '<borders count="2">' +
  '<border><left/><right/><top/><bottom/><diagonal/></border>' +
  '<border><left/><right/><top/><bottom style="thin"><color rgb="FF9AA58E"/></bottom><diagonal/></border>' +
  '</borders>' +
  '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>' +
  '<cellXfs count="3">' +
  '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>' +
  '<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"/>' +
  '<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/>' +
  '</cellXfs>' +
  '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>' +
  '</styleSheet>';

/** El filtro necesita su nombre definido (_xlnm._FilterDatabase) para que Excel lo respete. */
function libro(hoja: HojaXlsx): string {
  const nombre = nombreHoja(hoja.nombre);
  const rango = `$A$1:$${letraColumna(hoja.columnas.length - 1)}$${hoja.filas.length + 1}`;
  return (
    XML +
    `<workbook xmlns="${NS_HOJA}" xmlns:r="${NS_REL}">` +
    `<sheets><sheet name="${escaparXml(nombre)}" sheetId="1" r:id="rId1"/></sheets>` +
    '<definedNames>' +
    `<definedName name="_xlnm._FilterDatabase" localSheetId="0" hidden="1">` +
    `${escaparXml(`'${nombre.replace(/'/g, "''")}'!${rango}`)}</definedName>` +
    '</definedNames>' +
    '</workbook>'
  );
}

function hojaXml(hoja: HojaXlsx): string {
  const ultimaColumna = letraColumna(hoja.columnas.length - 1);
  const ultimaFila = hoja.filas.length + 1;
  const columnas = hoja.columnas
    .map(
      (columna, i) =>
        `<col min="${i + 1}" max="${i + 1}" width="${columna.ancho}" customWidth="1"/>`,
    )
    .join('');
  const encabezado = fila(
    1,
    hoja.columnas.map((columna) => columna.titulo),
    () => ESTILO_ENCABEZADO,
  );
  const cuerpo = hoja.filas
    .map((celdas, i) =>
      fila(i + 2, celdas, (columna, valor) =>
        hoja.columnas[columna]?.destacada && typeof valor === 'number' ? ESTILO_DESTACADO : 0,
      ),
    )
    .join('');
  return (
    XML +
    `<worksheet xmlns="${NS_HOJA}">` +
    `<dimension ref="A1:${ultimaColumna}${ultimaFila}"/>` +
    '<sheetViews><sheetView workbookViewId="0">' +
    '<pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/>' +
    '</sheetView></sheetViews>' +
    `<cols>${columnas}</cols>` +
    `<sheetData>${encabezado}${cuerpo}</sheetData>` +
    `<autoFilter ref="A1:${ultimaColumna}${ultimaFila}"/>` +
    '</worksheet>'
  );
}

function fila(
  numero: number,
  celdas: CeldaXlsx[],
  estilo: (columna: number, valor: CeldaXlsx) => number,
): string {
  const contenido = celdas
    .map((valor, columna) => {
      if (valor === null || valor === '') return '';
      const ref = `${letraColumna(columna)}${numero}`;
      const s = estilo(columna, valor);
      const atributoEstilo = s ? ` s="${s}"` : '';
      if (typeof valor === 'number') {
        return Number.isFinite(valor) ? `<c r="${ref}"${atributoEstilo}><v>${valor}</v></c>` : '';
      }
      return `<c r="${ref}"${atributoEstilo} t="inlineStr"><is><t xml:space="preserve">${escaparXml(valor)}</t></is></c>`;
    })
    .join('');
  return `<row r="${numero}">${contenido}</row>`;
}

/** 0 → A, 25 → Z, 26 → AA. */
export function letraColumna(indice: number): string {
  let letras = '';
  for (let n = indice + 1; n > 0; n = Math.floor((n - 1) / 26)) {
    letras = String.fromCharCode(65 + ((n - 1) % 26)) + letras;
  }
  return letras;
}

/** Excel rechaza nombres de hoja con : \ / ? * [ ] o de más de 31 caracteres. */
function nombreHoja(nombre: string): string {
  return (
    nombre
      .replace(/[:\\/?*[\]]/g, ' ')
      .slice(0, 31)
      .trim() || 'Hoja1'
  );
}

function escaparXml(texto: string): string {
  return (
    texto
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      // Caracteres de control que XML no admite.
      // eslint-disable-next-line no-control-regex
      .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '')
  );
}

// ZIP sin compresión ----------------------------------------------------------------

interface ArchivoZip {
  nombre: string;
  contenido: string;
}

const TABLA_CRC = (() => {
  const tabla = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    tabla[n] = c >>> 0;
  }
  return tabla;
})();

export function crc32(datos: Uint8Array): number {
  let crc = 0xffffffff;
  for (const byte of datos) crc = TABLA_CRC[(crc ^ byte) & 0xff] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}

/** Fecha fija (1-1-2026 00:00) en formato DOS: el contenido no depende de cuándo se genera. */
const FECHA_DOS = ((2026 - 1980) << 9) | (1 << 5) | 1;

function crearZip(archivos: ArchivoZip[]): Uint8Array {
  const codificador = new TextEncoder();
  const partes: Uint8Array[] = [];
  const directorio: Uint8Array[] = [];
  let desplazamiento = 0;

  for (const archivo of archivos) {
    const nombre = codificador.encode(archivo.nombre);
    const datos = codificador.encode(archivo.contenido);
    const crc = crc32(datos);

    const local = new DataView(new ArrayBuffer(30));
    local.setUint32(0, 0x04034b50, true); // firma de archivo local
    local.setUint16(4, 20, true); // versión necesaria
    local.setUint16(6, 0x0800, true); // nombres en UTF-8
    local.setUint16(8, 0, true); // sin compresión
    local.setUint16(10, 0, true); // hora
    local.setUint16(12, FECHA_DOS, true);
    local.setUint32(14, crc, true);
    local.setUint32(18, datos.length, true);
    local.setUint32(22, datos.length, true);
    local.setUint16(26, nombre.length, true);
    local.setUint16(28, 0, true);
    partes.push(new Uint8Array(local.buffer), nombre, datos);

    const central = new DataView(new ArrayBuffer(46));
    central.setUint32(0, 0x02014b50, true); // firma del directorio central
    central.setUint16(4, 20, true);
    central.setUint16(6, 20, true);
    central.setUint16(8, 0x0800, true);
    central.setUint16(10, 0, true);
    central.setUint16(12, 0, true);
    central.setUint16(14, FECHA_DOS, true);
    central.setUint32(16, crc, true);
    central.setUint32(20, datos.length, true);
    central.setUint32(24, datos.length, true);
    central.setUint16(28, nombre.length, true);
    central.setUint32(42, desplazamiento, true);
    directorio.push(new Uint8Array(central.buffer), nombre);

    desplazamiento += 30 + nombre.length + datos.length;
  }

  const tamanoDirectorio = directorio.reduce((total, parte) => total + parte.length, 0);
  const fin = new DataView(new ArrayBuffer(22));
  fin.setUint32(0, 0x06054b50, true); // fin del directorio central
  fin.setUint16(8, archivos.length, true);
  fin.setUint16(10, archivos.length, true);
  fin.setUint32(12, tamanoDirectorio, true);
  fin.setUint32(16, desplazamiento, true);

  return unir([...partes, ...directorio, new Uint8Array(fin.buffer)]);
}

function unir(partes: Uint8Array[]): Uint8Array {
  const resultado = new Uint8Array(partes.reduce((total, parte) => total + parte.length, 0));
  let posicion = 0;
  for (const parte of partes) {
    resultado.set(parte, posicion);
    posicion += parte.length;
  }
  return resultado;
}
