export interface PosCategory {
  id: string;
  nombre: string;
  icono: string;
}

export interface PosProduct {
  id: number;
  nombre: string;
  categoriaId: string;
  categoriaNombre: string;
  codigoInterno: string;
  codigoBarras: string;
  precioVenta: number;
  icono: string;
  descripcion: string;
  activo: boolean;
}

export interface CartItem {
  producto: PosProduct;
  cantidad: number;
  /** Lo que se cobra por la línea (con el descuento de la promoción, si tiene). */
  subtotal: number;
  /**
   * Precio cobrado por unidad cuando viene de una promoción (H5.2 T05); si falta, es el de
   * lista (`producto.precioVenta`). Lo calcula la regla de la promoción: no se edita.
   */
  precioUnitario?: number;
  /** Promoción con la que se vendió la línea (H5.2 T05). */
  promocion?: { id: number; nombre: string };
}

import { TipoVenta } from '../../../core/models/comun.model';

export type PaymentMethod = 'efectivo' | 'credito' | 'debito' | 'sodexo' | 'edenred';

/** Ítem que no alcanzó a cubrirse con el stock de la sucursal en una venta (H2.5 T04). */
export interface StockInsuficiente {
  nombre: string;
  unidad: string;
  requerido: number;
  disponible: number;
  faltante: number;
}

export interface CompletedSale {
  /** id real de la venta en la base de datos (ventas.id) */
  id: number;
  ticketFolio: string;
  fecha: Date;
  cajeroNombre: string;
  sucursalNombre: string;
  medioPago: PaymentMethod;
  /** Total cobrado (con el descuento ya aplicado en una venta a empleado). */
  total: number;
  /** Venta a empleado (H2.12). Ausente en ventas anteriores: se tratan como normales. */
  tipoVenta?: TipoVenta;
  /** Suma de los productos a precio de lista, antes de cualquier descuento. */
  subtotal?: number;
  /** Descuento de venta a empleado (H2.12). */
  descuento?: number;
  /** Lo que descontaron las promociones (H5.2 T05). */
  descuentoPromociones?: number;
  empleadoNombre?: string;
  montoRecibido: number;
  vuelto: number;
  items: CartItem[];
  codigoAutorizacion?: string;
  titularJunaeb?: string;
  saldoRestanteJunaeb?: number;
  /** Lo que quedó sin stock suficiente tras la venta; vacío o ausente si alcanzó todo. */
  stockInsuficiente?: StockInsuficiente[];
  /**
   * La venta quedó registrada, pero no se pudo consultar su stock (sin red, timeout o
   * error de la base). H2.5 T06: el POS lo avisa en vez de callar.
   */
  stockSinVerificar?: boolean;
}
