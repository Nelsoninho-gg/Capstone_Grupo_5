/**
 * Interpreta una fecha devuelta por PostgREST.
 * Respeta la zona horaria explícita (`Z`, `±HH:MM`, `±HHMM` o `±HH`) y, si viene sin zona
 * (columnas `TIMESTAMP` anteriores a `TIMESTAMPTZ`), la asume en UTC.
 */
export function parsearFechaServidor(valor: string): Date {
  const texto = valor.trim();
  if (/[zZ]|[+-]\d{2}:\d{2}$/.test(texto)) {
    return new Date(texto);
  }
  if (/[+-]\d{2}$/.test(texto)) {
    return new Date(`${texto}:00`);
  }
  if (/[+-]\d{4}$/.test(texto)) {
    return new Date(`${texto.slice(0, -2)}:${texto.slice(-2)}`);
  }
  return new Date(`${texto}Z`);
}
