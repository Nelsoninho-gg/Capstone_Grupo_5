import {
  ProductoVendido,
  RendimientoCajero,
  ResumenSucursal,
  TurnoReporte,
} from './reportes.model';

/** Fábricas para las pruebas del dashboard de Reportes. */
export function resumenDePrueba(cambio: Partial<ResumenSucursal> = {}): ResumenSucursal {
  return {
    sucursalId: 1,
    sucursal: 'Nury Providencia',
    ventas: 10,
    total: 50000,
    ticketPromedio: 5000,
    normales: { ventas: 9, total: 47000 },
    empleado: { ventas: 1, total: 3000 },
    mediosPago: { efectivo: 20000, debito: 30000 },
    anuladas: { ventas: 1, total: 4000 },
    ...cambio,
  };
}

export function productoDePrueba(cambio: Partial<ProductoVendido> = {}): ProductoVendido {
  return {
    sucursalId: 1,
    sucursal: 'Nury Providencia',
    productoId: 1,
    producto: 'Café americano',
    categoria: 'Bebidas',
    conReceta: false,
    unidades: 10,
    ventas: 8,
    montoBruto: 18000,
    descuento: 0,
    monto: 18000,
    ...cambio,
  };
}

export function cajeroDePrueba(cambio: Partial<RendimientoCajero> = {}): RendimientoCajero {
  return {
    cajeroId: 1,
    cajero: 'Camila Rojas',
    sucursales: 'Nury Providencia',
    turnos: 2,
    ventas: 10,
    total: 50000,
    ventaPromedio: 5000,
    productos: 25,
    anuladas: { ventas: 0, total: 0 },
    ...cambio,
  };
}

export function turnoDePrueba(cambio: Partial<TurnoReporte> = {}): TurnoReporte {
  return {
    turnoId: 7,
    cajeroId: 1,
    cajero: 'Camila Rojas',
    sucursalId: 1,
    sucursal: 'Nury Providencia',
    inicio: '2026-11-03T09:00:00',
    fin: '2026-11-03T17:00:00',
    ventas: 4,
    total: 18000,
    anuladas: 0,
    ...cambio,
  };
}
