import { ProductoAgrupado } from './reporte-ventas.model';
import { CostoProducto } from './reportes.model';

/**
 * Umbrales para destacar productos de alto volumen y bajo margen (H4.4 T05). Propuestos el
 * 06-11; si el equipo decide otros, basta con cambiarlos aquí.
 */
export const UMBRALES_MARGEN = {
  /** "Alto volumen" = el cuarto de los productos que más unidades vendió. */
  volumenSuperior: 0.25,
  /** "Bajo margen" = menos de este porcentaje sobre lo cobrado. */
  margenBajo: 15,
  /** Con menos unidades no se destaca: una o dos ventas no hacen tendencia. */
  unidadesMinimas: 3,
  /** "Alto margen" = el cuarto de los productos con mejor margen en porcentaje. */
  margenSuperior: 0.25,
  /** "Volumen casi nulo" = el cuarto de los productos que menos unidades vendió. */
  volumenInferior: 0.25,
} as const;

/** completo: hay costo de todo; incompleto: la receta tiene ingredientes sin costo; sin_costo. */
export type EstadoCosto = 'completo' | 'incompleto' | 'sin_costo';

export interface MargenProducto {
  estado: EstadoCosto;
  origen: CostoProducto['origen'];
  costoUnitario: number | null;
  /** Costo de las unidades vendidas; null sin costo. */
  costo: number | null;
  /** Monto cobrado − costo; null sin costo. */
  margen: number | null;
  /** Margen sobre lo cobrado, con un decimal; null sin costo o sin monto. */
  margenPct: number | null;
}

const redondear = (valor: number, decimales = 0) => {
  const factor = 10 ** decimales;
  return Math.round(valor * factor) / factor;
};

/**
 * Margen de un producto con el costo actual (H4.4 T03 y T04). El monto ya viene con descuentos
 * y venta a empleado, así que es lo realmente cobrado. Sin costo no se supone 0: el margen
 * queda vacío. Puede ser negativo (se vendió bajo el costo).
 */
export function margenDe(
  producto: ProductoAgrupado,
  costo: CostoProducto | undefined,
): MargenProducto {
  if (!costo || costo.costoUnitario === null) {
    return {
      estado: 'sin_costo',
      origen: costo?.origen ?? 'sin_costo',
      costoUnitario: null,
      costo: null,
      margen: null,
      margenPct: null,
    };
  }
  const total = redondear(costo.costoUnitario * producto.unidades);
  const margen = redondear(producto.monto - total);
  return {
    estado: costo.ingredientesSinCosto > 0 ? 'incompleto' : 'completo',
    origen: costo.origen,
    costoUnitario: costo.costoUnitario,
    costo: total,
    margen,
    margenPct: producto.monto > 0 ? redondear((margen / producto.monto) * 100, 1) : null,
  };
}

/** Margen total de los productos con costo, y cuántos quedan fuera o con costo incompleto. */
export function resumenMargen(
  productos: readonly ProductoAgrupado[],
  costos: ReadonlyMap<number, CostoProducto>,
) {
  let monto = 0;
  let margen = 0;
  let sinCosto = 0;
  let incompletos = 0;
  for (const producto of productos) {
    const calculo = margenDe(producto, costos.get(producto.productoId));
    if (calculo.margen === null) {
      sinCosto += 1;
      continue;
    }
    if (calculo.estado === 'incompleto') incompletos += 1;
    monto += producto.monto;
    margen += calculo.margen;
  }
  return {
    margen: redondear(margen),
    margenPct: monto > 0 ? redondear((margen / monto) * 100, 1) : null,
    sinCosto,
    incompletos,
  };
}

/**
 * Productos de alto volumen y bajo margen (H4.4 T05): entre los que tienen costo completo y al
 * menos `unidadesMinimas`, los del cuarto superior en unidades con margen bajo el umbral. Del
 * menor margen al mayor.
 */
export function altoVolumenBajoMargen(
  productos: readonly ProductoAgrupado[],
  costos: ReadonlyMap<number, CostoProducto>,
  umbrales: {
    volumenSuperior: number;
    margenBajo: number;
    unidadesMinimas: number;
  } = UMBRALES_MARGEN,
): { producto: ProductoAgrupado; margen: MargenProducto }[] {
  const conCosto = productos
    .map((producto) => ({ producto, margen: margenDe(producto, costos.get(producto.productoId)) }))
    .filter((p) => p.margen.estado === 'completo' && p.margen.margenPct !== null)
    .sort((a, b) => b.producto.unidades - a.producto.unidades);
  const superiores = conCosto.slice(0, Math.ceil(conCosto.length * umbrales.volumenSuperior));
  return superiores
    .filter(
      (p) =>
        p.producto.unidades >= umbrales.unidadesMinimas &&
        p.margen.margenPct! < umbrales.margenBajo,
    )
    .sort((a, b) => a.margen.margenPct! - b.margen.margenPct!);
}

export interface ProductoConMargen {
  producto: ProductoAgrupado;
  margen: MargenProducto;
}

function conCostoCompleto(
  productos: readonly ProductoAgrupado[],
  costos: ReadonlyMap<number, CostoProducto>,
): ProductoConMargen[] {
  return productos
    .map((producto) => ({ producto, margen: margenDe(producto, costos.get(producto.productoId)) }))
    .filter((p) => p.margen.estado === 'completo' && p.margen.margenPct !== null);
}

/**
 * Productos de alto margen y volumen casi nulo (H4.4 T05), candidatos a promocionar más: entre
 * los que tienen costo completo, los del cuarto con mejor margen % que además están en el
 * cuarto que menos unidades vendió (con al menos 4 productos con costo). Del mejor margen al
 * menor.
 */
export function altoMargenBajoVolumen(
  productos: readonly ProductoAgrupado[],
  costos: ReadonlyMap<number, CostoProducto>,
  umbrales: { margenSuperior: number; volumenInferior: number } = UMBRALES_MARGEN,
): ProductoConMargen[] {
  const conCosto = conCostoCompleto(productos, costos);
  // Con menos de 4 productos los cuartos no distinguen nada: el único es a la vez el mejor y
  // el que menos vende.
  if (conCosto.length < 4) return [];
  const cuantos = (fraccion: number) => Math.ceil(conCosto.length * fraccion);
  const mejores = new Set(
    [...conCosto]
      .sort((a, b) => b.margen.margenPct! - a.margen.margenPct!)
      .slice(0, cuantos(umbrales.margenSuperior))
      .map((p) => p.producto.productoId),
  );
  return [...conCosto]
    .sort((a, b) => a.producto.unidades - b.producto.unidades)
    .slice(0, cuantos(umbrales.volumenInferior))
    .filter((p) => mejores.has(p.producto.productoId) && p.margen.margenPct! > 0)
    .sort((a, b) => b.margen.margenPct! - a.margen.margenPct!);
}
