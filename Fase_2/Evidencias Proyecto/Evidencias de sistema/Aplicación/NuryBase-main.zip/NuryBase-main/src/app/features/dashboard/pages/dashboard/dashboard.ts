import { AppIconComponent } from '../../../../shared/components/app-icon/app-icon.component';
import {
  Component,
  DOCUMENT,
  DestroyRef,
  HostListener,
  computed,
  effect,
  inject,
  signal,
} from '@angular/core';
import { takeUntilDestroyed, toObservable, toSignal } from '@angular/core/rxjs-interop';
import { RouterLink } from '@angular/router';
import { catchError, fromEvent, interval, map, of, switchMap, tap, timeout } from 'rxjs';
import { SucursalesApiService } from '../../../../core/api/sucursales-api.service';
import { PanelPredictivo } from '../../../inventario/components/panel-predictivo/panel-predictivo';
import {
  EscenarioDashboard,
  MIN_BOLETAS_RECOMENDACION,
  MIN_PORCENTAJE_RECOMENDACION,
  MetricaGrafico,
  PREGUNTAS_RAPIDAS,
  PeriodoDashboard,
  PuntoSerieTemporal,
  TIEMPO_LIMITE_CONSULTA_MS,
  ResumenProductoDestacado,
  calcularMadurezDashboard,
  construirEscenario,
  construirVistaDiasSemana,
  construirVistaProyeccion,
  textoActualizado,
} from '../../models/dashboard.model';
import {
  AsistenteDashboardService,
  ContextoEjecutivoAsistente,
} from '../../services/asistente-dashboard.service';
import { DashboardDatosService, DatosDashboard } from '../../services/dashboard-datos.service';

const formatoClp = new Intl.NumberFormat('es-CL', {
  style: 'currency',
  currency: 'CLP',
  maximumFractionDigits: 0,
});

/** Cada cuánto se refresca sola la pantalla mientras se mira el día en curso. */
const INTERVALO_REFRESCO_MS = 3 * 60 * 1000;
/** Cada cuánto se recalcula el texto "actualizado hace…". */
const INTERVALO_RELOJ_MS = 30 * 1000;

type VistaDetalle = 'ventas' | 'productos' | 'compras';

export const CLAVE_METRICA_DIAS_SEMANA = 'nurybase.dashboard.metricaDiasSemana';

function leerMetricaDiasSemana(): MetricaGrafico {
  try {
    return localStorage.getItem(CLAVE_METRICA_DIAS_SEMANA) === 'ganancia' ? 'ganancia' : 'ingresos';
  } catch {
    return 'ingresos';
  }
}

@Component({
  selector: 'app-dashboard',
  imports: [RouterLink, PanelPredictivo, AppIconComponent],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css',
})
export class Dashboard {
  private readonly asistenteService = inject(AsistenteDashboardService);
  private readonly datosService = inject(DashboardDatosService);
  private readonly document = inject(DOCUMENT);
  private readonly destroyRef = inject(DestroyRef);

  protected readonly sucursales = toSignal(
    inject(SucursalesApiService).listarActivas().pipe(catchError(() => of([]))),
    { initialValue: [] },
  );

  protected readonly preguntasAsistente = PREGUNTAS_RAPIDAS;
  protected readonly asistenteAbierto = signal(false);

  protected readonly filtroSucursal = signal('todas');
  protected readonly periodo = signal<PeriodoDashboard>('30d');
  protected readonly metricaGrafico = signal<MetricaGrafico>('ganancia');
  /** La tarjeta por día de la semana recuerda la última métrica elegida; la primera vez parte en total vendido. */
  protected readonly metricaDiasSemana = signal<MetricaGrafico>(leerMetricaDiasSemana());
  protected readonly vistaDetalle = signal<VistaDetalle>('ventas');
  protected readonly pestanasDetalle: readonly { id: VistaDetalle; titulo: string }[] = [
    { id: 'ventas', titulo: 'Ventas' },
    { id: 'productos', titulo: 'Productos' },
    { id: 'compras', titulo: 'Compras' },
  ];

  protected readonly datos = signal<DatosDashboard | null>(null);
  protected readonly cargandoDatos = signal(true);
  /** Alturas fijas de las columnas del esqueleto de carga: solo dan forma, no son datos. */
  protected readonly alturasEsqueleto = [55, 80, 40, 95, 65, 75, 50];
  protected readonly errorDatos = signal(false);

  private readonly sucursalId = computed(() => {
    const valor = this.filtroSucursal();
    return valor === 'todas' ? null : Number(valor);
  });

  /** Refresco silencioso: mantiene los datos en pantalla en vez de mostrar el esqueleto de carga. */
  protected readonly actualizando = signal(false);
  protected readonly ultimaActualizacion = signal<Date | null>(null);
  private readonly reloj = signal(Date.now());
  private readonly refresco = signal(0);
  private ultimaClave = '';

  private readonly claveConsulta = computed(() => `${this.periodo()}|${this.sucursalId()}`);

  protected readonly textoActualizacion = computed(() =>
    this.cargandoDatos()
      ? 'Cargando…'
      : this.actualizando()
      ? 'Actualizando…'
      : textoActualizado(this.ultimaActualizacion(), new Date(this.reloj())),
  );

  protected readonly sucursalNombre = computed(() => {
    const id = this.sucursalId();
    if (id === null) return 'Todas las sucursales';
    return this.sucursales().find((s) => s.id === id)?.nombre ?? 'Sucursal seleccionada';
  });

  protected readonly madurezDashboard = computed(() =>
    calcularMadurezDashboard(
      this.datos()?.diasHistorial ?? 0,
      this.sucursalId() === null ? undefined : this.sucursalNombre(),
    ),
  );
  protected readonly textoPregunta = signal('');
  // Viven en el servicio para que la conversación sobreviva al cambiar de sección.
  protected readonly consultandoAsistente = this.asistenteService.consultando;
  protected readonly mensajesPersonalizados = this.asistenteService.mensajes;

  constructor() {
    toObservable(
      computed(() => ({
        periodo: this.periodo(),
        sucursalId: this.sucursalId(),
        refresco: this.refresco(),
      })),
    )
      .pipe(
        tap(() => {
          // Un refresco de los mismos datos no debe tapar la pantalla con "Cargando…".
          if (this.datos() !== null && this.claveConsulta() === this.ultimaClave) {
            this.actualizando.set(true);
          } else {
            this.cargandoDatos.set(true);
          }
          this.errorDatos.set(false);
        }),
        // switchMap descarta la respuesta anterior si el usuario cambia de filtro mientras carga.
        switchMap(({ periodo, sucursalId }) => {
          const clave = `${periodo}|${sucursalId}`;
          return this.datosService.cargar(periodo, sucursalId).pipe(
            timeout(TIEMPO_LIMITE_CONSULTA_MS),
            map((datos) => ({ datos, clave })),
            catchError(() => {
              this.errorDatos.set(true);
              return of({ datos: null, clave });
            }),
          );
        }),
        takeUntilDestroyed(),
      )
      .subscribe(({ datos, clave }) => {
        this.ultimaClave = clave;
        this.actualizando.set(false);
        this.cargandoDatos.set(false);
        // Si falla un refresco se conserva lo último cargado en vez de vaciar la pantalla.
        if (datos) {
          this.datos.set(datos);
          this.ultimaActualizacion.set(new Date());
        }
      });

    // El texto "actualizado hace…" necesita su propio reloj para no quedarse quieto.
    interval(INTERVALO_RELOJ_MS)
      .pipe(takeUntilDestroyed())
      .subscribe(() => this.reloj.set(Date.now()));

    interval(INTERVALO_REFRESCO_MS)
      .pipe(takeUntilDestroyed())
      .subscribe(() => this.refrescarSiCorresponde());

    // Al volver a la pestaña se refresca en el acto, como en Inventario (H3.2 T06).
    fromEvent(this.document, 'visibilitychange')
      .pipe(takeUntilDestroyed())
      .subscribe(() => {
        if (this.document.visibilityState === 'visible') this.refrescarSiCorresponde();
      });

    effect(() => {
      const abierto = this.asistenteAbierto();
      const body = this.document?.body;
      if (!body) return;
      if (abierto) {
        body.classList.add('assistant-drawer-open');
      } else {
        body.classList.remove('assistant-drawer-open');
      }
    });

    this.destroyRef.onDestroy(() => {
      this.document?.body?.classList.remove('assistant-drawer-open');
    });
  }

  /** Solo el día en curso se refresca solo: los otros períodos son consultas pesadas. */
  private refrescarSiCorresponde(): void {
    if (this.periodo() !== '1d') return;
    if (this.document.visibilityState === 'hidden') return;
    this.refresco.update((valor) => valor + 1);
  }

  protected actualizarAhora(): void {
    this.refresco.update((valor) => valor + 1);
  }

  @HostListener('document:keydown.escape')
  protected cerrarAsistenteConEscape(): void {
    if (this.asistenteAbierto()) {
      this.cerrarAsistente();
    }
    this.rankingAbierto.set(null);
  }

  /** Categoría cuyo ranking está abierto en el panel lateral; se guarda la categoría para seguir los datos al refrescar. */
  protected readonly rankingAbierto = signal<ResumenProductoDestacado['categoriaResumen'] | null>(null);

  protected readonly rankingVisible = computed(() => {
    const item = this.escenario().productosDestacados.find(
      (d) => d.categoriaResumen === this.rankingAbierto(),
    );
    if (!item) return null;
    // «Deja menos ganancia» se ordena por margen, así que la barra muestra el margen; las otras, unidades.
    const esMargen = item.categoriaResumen === 'margen-bajo';
    const valores = item.ranking.map((p) =>
      esMargen ? Math.round(((p.gananciaLimpiaClp ?? 0) / Math.max(p.ventasClp, 1)) * 100) : p.unidades,
    );
    const maximo = Math.max(0, ...valores);
    return {
      item,
      metrica: esMargen ? 'Margen de ganancia' : 'Unidades vendidas',
      unidad: esMargen ? 'de margen' : 'unidades',
      esMargen,
      barras: item.ranking.map((p, i) => ({
        ...p,
        valorTexto: esMargen ? `${valores[i]}%` : this.formatearNumero(valores[i]),
        // Un margen negativo no tiene altura: se ve su valor, no una barra hacia abajo.
        alturaPct: maximo > 0 ? (Math.max(0, valores[i]) / maximo) * 100 : 0,
      })),
    };
  });

  protected readonly escenario = computed<EscenarioDashboard>(
    () =>
      this.datos()?.escenario ?? construirEscenario([], new Map(), this.periodo(), new Date()),
  );

  protected readonly serieActiva = computed<readonly PuntoSerieTemporal[]>(() =>
    this.metricaGrafico() === 'ganancia'
      ? this.escenario().serieGanancias
      : this.escenario().serieIngresos,
  );

  // Avisa desde la pestaña, porque el panel de compras solo se carga al abrirla.
  protected readonly hayCompraPendiente = computed(
    () => (this.datos()?.insumosUrgentes.length ?? 0) > 0,
  );

  protected readonly proyeccion = computed(() => construirVistaProyeccion(this.serieActiva()));

  protected readonly diasSemana = computed(() =>
    construirVistaDiasSemana(this.escenario().demandaPorDiaSemana, this.metricaDiasSemana()),
  );
  protected readonly hayVentasPorDia = computed(() => this.diasSemana().some((d) => d.cantidadVentas > 0));
  protected readonly hayComboRecomendable = computed(() =>
    this.escenario().comprasConjuntas.some((c) => c.esRecomendable),
  );
  protected readonly minBoletasCombo = MIN_BOLETAS_RECOMENDACION;
  protected readonly minPorcentajeCombo = MIN_PORCENTAJE_RECOMENDACION;

  /** Estado que entrega el modelo: si no hay historial suficiente, no se muestra un cierre inventado. */
  protected readonly proyeccionCierre = computed(() => this.escenario().proyeccion);

  // El cierre estimado ya se muestra en la tarjeta de proyección.
  protected readonly kpisResumen = computed(() =>
    this.escenario().kpis.filter((kpi) => kpi.id !== 'proyeccion-ia'),
  );

  protected actualizarTextoPregunta(evento: Event): void {
    this.textoPregunta.set((evento.target as HTMLInputElement).value);
  }

  protected enviarMensaje(pregunta: string = this.textoPregunta()): void {
    const texto = pregunta.trim();
    if (!texto || this.consultandoAsistente()) return;

    this.textoPregunta.set('');

    const esc = this.escenario();
    const ventas = esc.kpis.find((k) => k.id === 'ingresos')?.montoClp ?? 0;
    const ganancia = esc.kpis.find((k) => k.id === 'ganancia-neta')?.montoClp ?? 0;

    const contexto: ContextoEjecutivoAsistente = {
      sucursalId: this.filtroSucursal(),
      sucursales: this.sucursales(),
      sucursalNombre: this.sucursalNombre(),
      periodo: this.periodo(),
      ventasTotalesClp: ventas,
      gananciaLimpiaClp: ganancia,
      demandaHoraria: esc.demandaHoraria,
      demandaPorDiaSemana: esc.demandaPorDiaSemana,
      madurez: this.madurezDashboard(),
      catalogo: this.datos()?.catalogo ?? [],
      insumosUrgentes: this.datos()?.insumosUrgentes ?? [],
      productosMasVendidos: esc.productosMasVendidos,
      lineasNegocio: esc.lineasNegocio,
      datosDisponibles: this.datos() !== null,
    };

    this.asistenteService.enviar(texto, contexto);
  }

  protected nuevaConversacion(): void {
    this.asistenteService.nuevaConversacion();
  }

  protected abrirAsistente(): void {
    this.asistenteAbierto.set(true);
  }

  protected cerrarAsistente(): void {
    this.asistenteAbierto.set(false);
  }

  protected alternarAsistente(): void {
    this.asistenteAbierto.update((v) => !v);
  }

  protected cambiarSucursal(evento: Event): void {
    this.filtroSucursal.set((evento.target as HTMLSelectElement).value);
  }

  protected seleccionarPeriodo(nuevo: PeriodoDashboard): void {
    this.periodo.set(nuevo);
  }

  protected seleccionarMetrica(metrica: MetricaGrafico): void {
    this.metricaGrafico.set(metrica);
  }

  protected seleccionarMetricaDias(metrica: MetricaGrafico): void {
    this.metricaDiasSemana.set(metrica);
    try {
      localStorage.setItem(CLAVE_METRICA_DIAS_SEMANA, metrica);
    } catch {
      // localStorage no disponible (modo privado, etc.): solo se pierde la preferencia.
    }
  }

  protected titulosConsultados(bloques: readonly { titulo: string }[]): string {
    return [...new Set(bloques.map((bloque) => bloque.titulo))].join(', ');
  }

  protected formatearClp(monto: number): string {
    return formatoClp.format(monto);
  }

  protected formatearNumero(valor: number): string {
    return valor.toLocaleString('es-CL');
  }

  protected formatearClpCorto(monto: number): string {
    if (monto < 0) return `-${this.formatearClpCorto(-monto)}`;
    if (monto >= 1000000) {
      return `$${(monto / 1000000).toFixed(1).replace('.', ',')}M`;
    }
    if (monto >= 1000) {
      return `$${Math.round(monto / 1000)}k`;
    }
    return `$${monto}`;
  }
}
