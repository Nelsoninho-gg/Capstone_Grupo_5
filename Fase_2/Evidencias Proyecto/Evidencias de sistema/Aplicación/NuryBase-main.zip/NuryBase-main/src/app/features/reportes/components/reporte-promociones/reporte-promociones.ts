import { HttpErrorResponse } from '@angular/common/http';
import { Component, computed, inject, input, signal } from '@angular/core';
import { rxResource } from '@angular/core/rxjs-interop';
import { forkJoin } from 'rxjs';
import { formatoClp, formatoNumero } from '../../models/formato';
import {
  AgrupacionPeriodo,
  PromocionesPeriodo,
  agruparPeriodos,
  porcentaje,
  totalPromociones,
} from '../../models/reporte-promociones.model';
import { FiltroReporte } from '../../models/reportes.model';
import { ReportesService } from '../../services/reportes.service';

const formatoDia = new Intl.DateTimeFormat('es-CL', {
  day: '2-digit',
  month: '2-digit',
  year: 'numeric',
  timeZone: 'UTC',
});
const formatoMes = new Intl.DateTimeFormat('es-CL', {
  month: 'long',
  year: 'numeric',
  timeZone: 'UTC',
});

/**
 * Pestaña Promociones del dashboard (H5.2 T08): cuánto de lo vendido vino con descuento por
 * promoción y cuánto margen se sacrificó, separado por período (día, semana o mes) y por
 * producto. Usa los mismos filtros de sucursales y período que el resto de Reportes, con sus
 * propias consultas (fn_reporte_promociones_periodo y fn_reporte_promociones_producto); la
 * consulta por producto está pensada para sumarse a Rendimiento por producto (H4.4).
 */
@Component({
  selector: 'app-reporte-promociones',
  templateUrl: './reporte-promociones.html',
  styleUrls: ['../../styles/reportes-base.css', './reporte-promociones.css'],
})
export class ReportePromociones {
  private readonly reportes = inject(ReportesService);

  /** Sucursales y período elegidos arriba; null mientras el período no es válido. */
  readonly filtro = input<FiltroReporte | null>(null);

  protected readonly agrupacion = signal<AgrupacionPeriodo>('dia');
  protected readonly soloConDescuento = signal(true);
  protected readonly opcionesAgrupacion: { valor: AgrupacionPeriodo; etiqueta: string }[] = [
    { valor: 'dia', etiqueta: 'Día' },
    { valor: 'semana', etiqueta: 'Semana' },
    { valor: 'mes', etiqueta: 'Mes' },
  ];

  protected readonly datos = rxResource({
    params: () => this.filtro() ?? undefined,
    stream: ({ params }) =>
      forkJoin({
        dias: this.reportes.promocionesPorDia(params),
        productos: this.reportes.promocionesPorProducto(params),
      }),
  });

  protected readonly cargando = computed(() => this.datos.isLoading());
  protected readonly conError = computed(() => this.datos.status() === 'error');
  protected readonly sinPermiso = computed(() => {
    const error = this.datos.error();
    return error instanceof HttpErrorResponse && error.status === 403;
  });

  private readonly dias = computed(() => (this.datos.hasValue() ? this.datos.value().dias : []));
  protected readonly total = computed(() => totalPromociones(this.dias()));
  protected readonly periodos = computed(() => agruparPeriodos(this.dias(), this.agrupacion()));
  protected readonly sinPromociones = computed(() => (this.total()?.vendidoConDescuento ?? 0) === 0);

  protected readonly productos = computed(() => {
    const todos = this.datos.hasValue() ? this.datos.value().productos : [];
    return this.soloConDescuento() ? todos.filter((p) => p.unidadesConDescuento > 0) : todos;
  });

  protected cambiarAgrupacion(valor: AgrupacionPeriodo): void {
    this.agrupacion.set(valor);
  }

  protected alternarSoloConDescuento(evento: Event): void {
    this.soloConDescuento.set((evento.target as HTMLInputElement).checked);
  }

  protected reintentar(): void {
    this.datos.reload();
  }

  protected clp(valor: number): string {
    return formatoClp.format(valor);
  }

  protected numero(valor: number): string {
    return formatoNumero.format(valor);
  }

  protected pct(parte: number, total: number): string {
    return `${formatoNumero.format(porcentaje(parte, total))} %`;
  }

  /** "05-11-2026", "Semana del 02-11-2026" o "noviembre de 2026". */
  protected etiquetaPeriodo(periodo: PromocionesPeriodo): string {
    const fecha = new Date(`${periodo.desde}T00:00:00Z`);
    switch (this.agrupacion()) {
      case 'semana':
        return `${formatoDia.format(fecha)} al ${formatoDia.format(new Date(`${periodo.hasta}T00:00:00Z`))}`;
      case 'mes':
        return formatoMes.format(fecha);
      default:
        return formatoDia.format(fecha);
    }
  }
}
