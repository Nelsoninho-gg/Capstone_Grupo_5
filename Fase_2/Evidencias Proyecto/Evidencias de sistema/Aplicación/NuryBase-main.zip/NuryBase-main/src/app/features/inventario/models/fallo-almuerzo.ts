import { HttpErrorResponse } from '@angular/common/http';

export type TipoFalloAlmuerzo =
  | 'conexion'
  | 'sesion'
  | 'permisos'
  | 'ya-almorzo'
  | 'datos-invalidos'
  | 'no-disponible'
  | 'servidor';

export interface FalloAlmuerzo {
  tipo: TipoFalloAlmuerzo;
  mensaje: string;
}

/** Cuerpo de error de PostgREST: `code` es el SQLSTATE de PostgreSQL o un código PGRST. */
interface ErrorPostgrest {
  code?: string;
  message?: string;
}

const SIN_CAMBIOS = 'El almuerzo no se registró y el stock no cambió.';

/**
 * Traduce el error de registrar un almuerzo a un mensaje para el cajero (H2.13 T05).
 * Sigue los códigos de `fn_registrar_almuerzo_empleado`
 * (database/migrations/20261022_almuerzo_unico_por_dia.sql): 23505 el empleado ya almorzó
 * hoy, 22023 datos inválidos y 42501 sin sesión o fuera de su sucursal. Para esos rechazos
 * muestra el texto de la base, que ya explica el motivo en español.
 */
export function interpretarFalloAlmuerzo(error: unknown): FalloAlmuerzo {
  if (!(error instanceof HttpErrorResponse)) return falloServidor();

  const { code = '', message = '' } = (error.error ?? {}) as ErrorPostgrest;

  if (error.status === 0) {
    return {
      tipo: 'conexion',
      mensaje:
        'No pudimos comunicarnos con el servidor y no sabemos si el almuerzo alcanzó a ' +
        'registrarse. Revisa la conexión y vuelve a confirmar: si ya se había registrado, ' +
        'el sistema lo avisará y no se descontará dos veces.',
    };
  }
  if (error.status === 401) {
    return {
      tipo: 'sesion',
      mensaje: `Tu sesión expiró. ${SIN_CAMBIOS} Vuelve a iniciar sesión para registrarlo.`,
    };
  }
  if (code === '23505') {
    return { tipo: 'ya-almorzo', mensaje: `${oracion(message, 'El empleado ya registró su almuerzo hoy.')} ${SIN_CAMBIOS}` };
  }
  if (error.status === 403 || code === '42501') {
    return {
      tipo: 'permisos',
      mensaje: `${oracion(message, 'Tu usuario no tiene permiso para registrar almuerzos.')} ${SIN_CAMBIOS}`,
    };
  }
  if (code === 'PGRST202') {
    return {
      tipo: 'no-disponible',
      mensaje: `El registro de almuerzos aún no está habilitado en el servidor. ${SIN_CAMBIOS} Avisa al administrador.`,
    };
  }
  if (code === '22023') {
    return { tipo: 'datos-invalidos', mensaje: `${oracion(message, 'Revisa los datos del almuerzo.')} ${SIN_CAMBIOS}` };
  }
  return falloServidor();
}

/** El texto de la base como oración (con punto final), o el de respaldo si no vino. */
function oracion(texto: string, respaldo: string): string {
  const limpio = texto.trim();
  if (!limpio) return respaldo;
  return /[.!?]$/.test(limpio) ? limpio : `${limpio}.`;
}

function falloServidor(): FalloAlmuerzo {
  return {
    tipo: 'servidor',
    mensaje: `No pudimos registrar el almuerzo. ${SIN_CAMBIOS} Inténtalo nuevamente.`,
  };
}
