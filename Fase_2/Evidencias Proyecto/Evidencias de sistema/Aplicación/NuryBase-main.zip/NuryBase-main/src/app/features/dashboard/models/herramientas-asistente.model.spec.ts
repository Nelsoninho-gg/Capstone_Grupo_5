import { describe, expect, it } from 'vitest';
import {
  DESCRIPCION_HERRAMIENTAS,
  agregarFilas,
  calcularMargenProducto,
  calcularRankingProductos,
  construirBloquesDatos,
  contarPorMedioPago,
  fechasEnHoraChile,
  listarFacturasIngresadas,
  periodosEspeciales,
  resumirVentasPeriodo,
} from './herramientas-asistente.model';

describe('DESCRIPCION_HERRAMIENTAS', () => {
  it('documenta el período "1d" de analisis_dashboard y el estado de la proyección', () => {
    expect(DESCRIPCION_HERRAMIENTAS).toContain('"1d" hoy');
    expect(DESCRIPCION_HERRAMIENTAS).toContain('proyeccion');
    expect(DESCRIPCION_HERRAMIENTAS).toContain('no inventes una cifra de cierre');
  });

  it('aclara qué herramientas excluyen o incluyen ventas a empleados', () => {
    expect(DESCRIPCION_HERRAMIENTAS).toContain('ranking_productos');
    expect(DESCRIPCION_HERRAMIENTAS).toContain('sí incluye ventas a empleados');
    expect(DESCRIPCION_HERRAMIENTAS).toContain('no cuentan ventas a empleados');
  });
});

describe('periodosEspeciales', () => {
  const periodo = (nombre: string, primeraVenta: string, hoy: string) =>
    periodosEspeciales(primeraVenta, hoy).find((p) => p.nombre === nombre);

  it('entrega los cuatro períodos con su última ocurrencia y si tiene registros', () => {
    expect(periodosEspeciales('2026-09-05', '2026-11-06')).toEqual([
      { nombre: 'Fiestas Patrias', desde: '2026-09-18', hasta: '2026-09-19', conRegistros: true },
      { nombre: 'Navidad', desde: '2025-12-25', hasta: '2025-12-25', conRegistros: false },
      { nombre: 'Vacaciones de verano', desde: '2026-01-01', hasta: '2026-02-28', conRegistros: false },
      { nombre: 'Vacaciones de invierno', desde: '2026-07-01', hasta: '2026-07-31', conRegistros: false },
    ]);
  });

  it('usa el año anterior si hoy es antes de la fecha, y el actual desde el primer día', () => {
    expect(periodo('Fiestas Patrias', '2020-01-01', '2026-09-17')?.desde).toBe('2025-09-18');
    expect(periodo('Fiestas Patrias', '2020-01-01', '2026-09-18')?.desde).toBe('2026-09-18');
    expect(periodo('Fiestas Patrias', '2020-01-01', '2026-09-20')?.desde).toBe('2026-09-18');
    expect(periodo('Navidad', '2020-01-01', '2026-12-24')?.desde).toBe('2025-12-25');
    expect(periodo('Navidad', '2020-01-01', '2026-12-25')?.desde).toBe('2026-12-25');
  });

  it('una ocurrencia en curso cuenta con registros', () => {
    expect(periodo('Vacaciones de verano', '2026-01-15', '2026-01-20')).toMatchObject({
      desde: '2026-01-01',
      hasta: '2026-02-28',
      conRegistros: true,
    });
  });

  it('hay registros si la primera venta es justo el último día, y no si es al día siguiente', () => {
    expect(periodo('Fiestas Patrias', '2026-09-19', '2026-11-06')?.conRegistros).toBe(true);
    expect(periodo('Fiestas Patrias', '2026-09-20', '2026-11-06')?.conRegistros).toBe(false);
    expect(periodo('Navidad', '2025-12-25', '2026-11-06')?.conRegistros).toBe(true);
    expect(periodo('Navidad', '2025-12-26', '2026-11-06')?.conRegistros).toBe(false);
  });

  it('febrero termina el 29 en un año bisiesto', () => {
    expect(periodo('Vacaciones de verano', '2020-01-01', '2028-03-01')?.hasta).toBe('2028-02-29');
  });
});

describe('listarFacturasIngresadas', () => {
  const filas = [
    {
      folio: 1250,
      proveedor: null,
      razon_social_emisor: 'DISTRIBUIDORA DE BEBIDAS LTDA',
      fecha_emision: '2026-10-05',
      monto_neto: 8100,
      monto_iva: 1900,
      monto_total: 10000,
      sucursal: 'Nury Providencia',
      ingresada_en: '2026-10-06 09:00',
      ingresada_por: 'Ana',
      lineas: [{ descripcion: 'Agua' }],
    },
    {
      folio: 77,
      proveedor: 'Lácteos-Sur',
      razon_social_emisor: 'LACTEOS DEL SUR SPA',
      fecha_emision: '2026-09-01',
      monto_neto: 810,
      monto_iva: 190,
      monto_total: 1000,
      sucursal: 'Nury Providencia',
      ingresada_en: '2026-09-02 10:00',
    },
  ];

  it('entrega solo los campos pedidos y usa la razón social si falta el proveedor', () => {
    expect(listarFacturasIngresadas(filas, {}).facturas).toEqual([
      {
        folio: '1250',
        emisor: 'DISTRIBUIDORA DE BEBIDAS LTDA',
        fecha_emision: '2026-10-05',
        monto_total: 10000,
        monto_neto: 8100,
        sucursal: 'Nury Providencia',
        ingresada_en: '2026-10-06 09:00',
      },
      {
        folio: '77',
        emisor: 'Lácteos-Sur',
        fecha_emision: '2026-09-01',
        monto_total: 1000,
        monto_neto: 810,
        sucursal: 'Nury Providencia',
        ingresada_en: '2026-09-02 10:00',
      },
    ]);
  });

  it.each(['DISTRIBUIDORA DE BEBIDAS', 'distribuidora-de bebidas', 'bebidas', 'Distribuidóra de Bebidas Ltda.'])(
    'encuentra al emisor con coincidencia parcial, sin importar mayúsculas, acentos ni guiones: %s',
    (emisor) => {
      expect(listarFacturasIngresadas(filas, { emisor }).facturas?.map((f) => f.folio)).toEqual(['1250']);
    },
  );

  it('busca también en la razón social cuando el proveedor tiene otro nombre', () => {
    expect(listarFacturasIngresadas(filas, { emisor: 'lacteos sur' }).facturas?.map((f) => f.folio)).toEqual(['77']);
    expect(listarFacturasIngresadas(filas, { emisor: 'lacteos del sur' }).facturas?.map((f) => f.folio)).toEqual(['77']);
  });

  it('filtra por fecha de emisión con ambos extremos incluidos', () => {
    const folios = (filtro: { desde?: string; hasta?: string }) =>
      listarFacturasIngresadas(filas, filtro).facturas?.map((f) => f.folio);
    expect(folios({ desde: '2026-10-05' })).toEqual(['1250']);
    expect(folios({ hasta: '2026-09-01' })).toEqual(['77']);
    expect(folios({ desde: '2026-09-01', hasta: '2026-10-05' })).toEqual(['1250', '77']);
  });

  it('suma todas las facturas encontradas, aunque el límite muestre menos', () => {
    const encontradas = [
      { folio: 1, monto_total: 119, monto_neto: 100 },
      { folio: 2, monto_total: 238, monto_neto: 200 },
    ];
    const resultado = listarFacturasIngresadas(encontradas, { limite: 1 });
    expect(resultado.facturas).toHaveLength(1);
    expect(resultado).toMatchObject({ suma_monto_total: 357, suma_monto_neto: 300 });
  });

  it('sin coincidencias lo dice con claridad y no trae facturas', () => {
    expect(listarFacturasIngresadas(filas, { emisor: 'Otro Proveedor' })).toEqual({
      facturas_encontradas: 0,
      resultado: 'No hay facturas ingresadas de Otro Proveedor.',
      truncado: false,
    });
    expect(listarFacturasIngresadas(filas, { desde: '2027-01-01' }).resultado).toBe(
      'No hay facturas ingresadas en esas fechas.',
    );
    expect(listarFacturasIngresadas([], {}).resultado).toBe('No hay facturas ingresadas.');
  });

  it('limita las filas sin perder el total y avisa si el reporte pudo quedar corto', () => {
    expect(listarFacturasIngresadas(filas, { limite: 1 })).toMatchObject({
      facturas_encontradas: 2,
      truncado: false,
      facturas: [{ folio: '1250' }],
    });
    const quinientas = Array.from({ length: 500 }, () => filas[0]);
    expect(listarFacturasIngresadas(quinientas, {})).toMatchObject({ facturas_encontradas: 500, truncado: true });
  });

  it('se lee bien en los datos calculados', () => {
    const datos = listarFacturasIngresadas(filas.slice(0, 1).concat(filas[0]), { limite: 2 });
    const [bloque] = construirBloquesDatos([
      { herramienta: 'facturas_ingresadas', parametros: { desde: '2026-10-01', hasta: '2026-10-31' }, datos },
    ]);
    expect(bloque.titulo).toBe('Facturas ingresadas (01-10-2026 a 31-10-2026)');
    expect(bloque.lineas).toEqual([
      'Facturas encontradas: 2',
      'Suma de los montos totales: $20.000',
      'Suma de los montos netos: $16.200',
      'Facturas:',
      'Folio: 1250 · Emisor: DISTRIBUIDORA DE BEBIDAS LTDA · Fecha de emisión: 05-10-2026 · Monto total: $10.000 · Monto neto: $8.100 · Sucursal: Nury Providencia · Fecha de ingreso: 06-10-2026 09:00',
      'Folio: 1250 · Emisor: DISTRIBUIDORA DE BEBIDAS LTDA · Fecha de emisión: 05-10-2026 · Monto total: $10.000 · Monto neto: $8.100 · Sucursal: Nury Providencia · Fecha de ingreso: 06-10-2026 09:00',
    ]);
    expect(
      construirBloquesDatos([{ herramienta: 'facturas_ingresadas', datos: listarFacturasIngresadas([], { emisor: 'X' }) }])[0].lineas,
    ).toEqual(['Facturas encontradas: 0', 'Resultado: No hay facturas ingresadas de X.']);
  });
});

describe('calcularMargenProducto', () => {
  const chaparrita = { id: 1, nombre: 'CHAPARRITA', precio_venta: 3000, precio_compra: 1710, activo: true };

  it('descuenta IVA y costo de compra', () => {
    expect(calcularMargenProducto(chaparrita, undefined)).toMatchObject({
      precio_venta: 3000,
      // $3.000 ÷ 1,19 = $2.521 neto y $479 de IVA.
      precio_neto: 2521,
      iva: 479,
      costo: 1710,
      fuente_costo: 'precio_compra',
      margen_por_unidad: 811,
      margen_porcentaje: 27,
    });
  });

  it('prioriza el costo de receta', () => {
    expect(calcularMargenProducto(chaparrita, 1000)).toMatchObject({
      costo: 1000,
      fuente_costo: 'receta',
      margen_por_unidad: 1521,
    });
  });

  it('no calcula margen sin costo registrado', () => {
    const margen = calcularMargenProducto({ ...chaparrita, precio_compra: null }, undefined);
    expect(margen.margen_por_unidad).toBeNull();
    expect(margen.margen_porcentaje).toBeNull();
    expect(margen.nota).toContain('Sin costo');
  });

  it('entrega siempre lo mismo con los mismos datos', () => {
    expect(calcularMargenProducto(chaparrita, undefined)).toEqual(calcularMargenProducto(chaparrita, undefined));
  });
});

describe('resumirVentasPeriodo', () => {
  it('suma la red, calcula el ticket y omite sucursales sin ventas', () => {
    const resumen = resumirVentasPeriodo([
      { sucursal: 'A', ventas: 3, total: '3000', anuladas: 1, total_anuladas: 500, medios_pago: { efectivo: 1000, debito: 2000 } },
      { sucursal: 'B', ventas: 1, total: 1000, anuladas: 0, total_anuladas: 0, medios_pago: { efectivo: 1000 } },
      { sucursal: 'C', ventas: 0, total: 0, medios_pago: null },
    ]);
    expect(resumen).toMatchObject({
      monto_total_clp: 4000,
      cantidad_ventas: 4,
      ticket_promedio_clp: 1000,
      cantidad_anuladas: 1,
      monto_anuladas_clp: 500,
    });
    expect(resumen.por_medio_de_pago).toEqual([
      { medio: 'efectivo', cantidad_ventas: null, monto_clp: 2000 },
      { medio: 'debito', cantidad_ventas: null, monto_clp: 2000 },
    ]);
    expect(resumen.por_sucursal.map((s) => s.sucursal)).toEqual(['A', 'B']);
  });

  it('entrega la cantidad por medio de pago solo si cuadra con el reporte', () => {
    const fila = { ventas: 30, total: 3000, medios_pago: { efectivo: 1000, debito: 2000 } };
    const cuadra = new Map([['efectivo', 17], ['debito', 13]]);
    expect(resumirVentasPeriodo([fila], cuadra).por_medio_de_pago).toEqual([
      { medio: 'debito', cantidad_ventas: 13, monto_clp: 2000 },
      { medio: 'efectivo', cantidad_ventas: 17, monto_clp: 1000 },
    ]);

    const noCuadra = new Map([['efectivo', 17], ['debito', 12]]);
    expect(resumirVentasPeriodo([fila], noCuadra).por_medio_de_pago.map((m) => m.cantidad_ventas)).toEqual([null, null]);
  });

  it('no divide por cero sin ventas', () => {
    expect(resumirVentasPeriodo([]).ticket_promedio_clp).toBe(0);
  });
});

describe('calcularRankingProductos', () => {
  const filas = [
    { producto_id: 1, producto: 'Café', categoria: 'X', unidades: 2, monto: 2000 },
    { producto_id: 1, producto: 'Café', categoria: 'X', unidades: 3, monto: 3000 },
    { producto_id: 2, producto: 'Pan', categoria: 'Y', unidades: 10, monto: 1000 },
    { producto_id: 3, producto: 'Sin venta', categoria: 'Y', unidades: 0, monto: 0 },
    { producto_id: 4, producto: 'Sin costo', categoria: 'Y', unidades: 1, monto: 9000 },
  ];
  const costoDe = (id: number) => (id === 1 ? 100 : id === 2 ? 50 : null);

  it('une sucursales y calcula la ganancia limpia', () => {
    const ranking = calcularRankingProductos(filas, costoDe);
    expect(ranking.productos_con_ventas).toBe(3);
    expect(ranking.productos[0]).toMatchObject({ producto: 'Pan', unidades: 10, ganancia_limpia: 340 });
    expect(ranking.productos.find((p) => p.producto === 'Café')).toMatchObject({
      unidades: 5,
      monto: 5000,
      ganancia_limpia: 3702,
    });
  });

  it('ordena según el criterio y respeta el límite', () => {
    expect(calcularRankingProductos(filas, costoDe, 'monto').productos[0].producto).toBe('Sin costo');
    expect(calcularRankingProductos(filas, costoDe, 'menos_vendidos').productos[0].producto).toBe('Sin costo');
    expect(calcularRankingProductos(filas, costoDe, 'ganancia').productos[0].producto).toBe('Café');
    expect(calcularRankingProductos(filas, costoDe, 'ganancia').productos.at(-1)?.ganancia_limpia).toBeNull();
    expect(calcularRankingProductos(filas, costoDe, 'unidades', 1).productos).toHaveLength(1);
  });
});

describe('agregarFilas', () => {
  const filas = [
    { rol: 'a', total: 10 },
    { rol: 'a', total: '20' },
    { rol: 'b', total: 5 },
  ];

  it('calcula sin agrupar', () => {
    expect(agregarFilas(filas, { suma: ['total'], promedio: ['total'], contar: true })).toEqual([
      { filas: 3, suma_total: 35, promedio_total: 11.67 },
    ]);
  });

  it('calcula por grupo', () => {
    expect(agregarFilas(filas, { suma: ['total'], agrupar_por: 'rol' })).toEqual([
      { rol: 'a', suma_total: 30 },
      { rol: 'b', suma_total: 5 },
    ]);
  });
});

describe('agregarFilas con tablas relacionadas', () => {
  it('agrupa por un campo embebido y marca los vacíos', () => {
    const filas = [
      { usuarios: { nombre: 'Ana' } },
      { usuarios: { nombre: 'Ana' } },
      { usuarios: null },
    ];
    expect(agregarFilas(filas, { contar: true, agrupar_por: 'usuarios.nombre' })).toEqual([
      { 'usuarios.nombre': 'Ana', filas: 2 },
      { 'usuarios.nombre': 'sin dato', filas: 1 },
    ]);
  });
});

describe('agregarFilas ordena de mayor a menor', () => {
  it('por la primera métrica', () => {
    const filas = [{ p: 'a' }, { p: 'b' }, { p: 'b' }];
    expect(agregarFilas(filas, { contar: true, agrupar_por: 'p' })).toEqual([
      { p: 'b', filas: 2 },
      { p: 'a', filas: 1 },
    ]);
  });
});

describe('contarPorMedioPago', () => {
  it('cuenta por día de Chile, aunque la fecha se guarde en UTC', () => {
    const conteo = contarPorMedioPago(
      [
        { fecha_venta: '2026-10-01T02:00:00', medio_pago: 'efectivo' }, // 30 de septiembre en Chile
        { fecha_venta: '2026-10-01T15:00:00', medio_pago: 'efectivo' },
        { fecha_venta: '2026-11-01T02:00:00', medio_pago: 'debito' }, // 31 de octubre en Chile
        { fecha_venta: '2026-10-31T23:30:00-03:00', medio_pago: 'credito' }, // 31 de octubre con TIMESTAMPTZ
        { fecha_venta: '2026-10-15T15:00:00', medio_pago: null },
      ],
      '2026-10-01',
      '2026-10-31',
    );
    expect([...conteo.entries()]).toEqual([['efectivo', 1], ['debito', 1], ['credito', 1], ['sin_medio', 1]]);
  });
});

describe('fechasEnHoraChile', () => {
  it('convierte las horas UTC de la base, en cualquier nivel, y deja lo demás igual', () => {
    expect(
      fechasEnHoraChile({
        creado_en: '2026-10-06T01:32:52.303326',
        con_zona: '2026-10-06T01:32:52Z',
        fecha_pedido: '2026-10-05',
        total: 100,
        filas: [{ fecha_venta: '2026-10-05T21:32:49.8376', nombre: 'Ana' }],
      }),
    ).toEqual({
      creado_en: '2026-10-05 22:32',
      con_zona: '2026-10-05 22:32',
      fecha_pedido: '2026-10-05',
      total: 100,
      filas: [{ fecha_venta: '2026-10-05 18:32', nombre: 'Ana' }],
    });
  });
});

describe('construirBloquesDatos', () => {
  it('muestra cada cifra con su etiqueta y formato, y omite los errores', () => {
    const [bloque, ...resto] = construirBloquesDatos([
      {
        herramienta: 'ventas_periodo',
        parametros: { desde: '2026-10-01', hasta: '2026-10-31' },
        datos: resumirVentasPeriodo(
          [{ sucursal: 'A', ventas: 30, total: 150000, ventas_normales: 30, total_normales: 150000, medios_pago: { efectivo: 150000 } }],
          new Map([['efectivo', 30]]),
        ),
      },
      { herramienta: 'margen_producto', error: 'falló' },
    ]);
    expect(resto).toEqual([]);
    expect(bloque.titulo).toBe('Ventas (01-10-2026 a 31-10-2026)');
    expect(bloque.lineas).toContain('Total vendido: $150.000');
    expect(bloque.lineas).toContain('Cantidad de ventas: 30');
    expect(bloque.lineas).toContain('Medio de pago: efectivo · Cantidad de ventas: 30 · Monto: $150.000');
  });

  it('una sola fila va campo por campo; varias, una por línea; y oculta lo interno', () => {
    expect(
      construirBloquesDatos([
        { herramienta: 'margen_producto', datos: [{ producto_id: 1, producto: 'Café', margen_por_unidad: 720, margen_porcentaje: 24 }] },
      ])[0].lineas,
    ).toEqual(['Producto: Café', 'Margen por unidad: $720', 'Margen porcentaje: 24%']);
    expect(
      construirBloquesDatos([{ herramienta: 'ranking_cajeros', datos: [{ cajero: 'A', total: 90 }, { cajero: 'B', total: 10 }] }])[0].lineas,
    ).toEqual(['Cajero: A · Total: $90', 'Cajero: B · Total: $10']);
  });

  it('no muestra notas para la IA ni un truncado falso, y avisa de uno verdadero', () => {
    const lineas = (datos: unknown) => construirBloquesDatos([{ herramienta: 'consultar', datos }])[0].lineas;
    expect(lineas({ filas: 0, nota_para_ia: 'Reintenta con ilike' })).toEqual(['Cantidad: 0']);
    expect(lineas({ filas: [{ nombre: 'A' }, { nombre: 'B' }], filas_encontradas: 2, truncado: false })).toEqual([
      'Filas encontradas: 2',
      'Nombre: A',
      'Nombre: B',
    ]);
    expect(lineas({ filas: [{ nombre: 'A' }, { nombre: 'B' }], filas_encontradas: 9, truncado: true })).toContain('Resultado incompleto: Sí');
  });

  it('agrupa con la etiqueta del último campo y muestra las fechas como día-mes-año', () => {
    expect(
      construirBloquesDatos([
        { herramienta: 'consultar', datos: [{ 'usuarios.nombre': 'Ana', filas: 5 }, { 'usuarios.nombre': 'sin dato', filas: 2 }] },
        { herramienta: 'consultar', datos: [{ fecha_venta: '2026-09-30 23:00', fecha_pedido: '2026-10-05' }] },
      ]).map((b) => b.lineas),
    ).toEqual([['Nombre: Ana · Cantidad: 5', 'Nombre: sin dato · Cantidad: 2'], ['Fecha venta: 30-09-2026 23:00', 'Fecha pedido: 05-10-2026']]);
  });

  it('explica en lenguaje simple los productos comprados juntos', () => {
    expect(
      construirBloquesDatos([
        {
          herramienta: 'x',
          datos: [{ productoPrincipal: 'A', acompanamiento: 'B', frecuenciaTexto: '3 de 19 boletas', soportePct: 0, confianzaPct: 16, lift: 1.2, consejoPractico: 'Tenerlos a mano' }],
        },
      ])[0].lineas,
    ).toEqual(['Producto principal: A', 'Acompañamiento: B', 'Frecuencia: 3 de 19 boletas']);
  });

  it('limita las líneas y los bloques', () => {
    const datos = Array.from({ length: 40 }, (_, i) => ({ i }));
    const [bloque] = construirBloquesDatos([{ herramienta: 'x', datos }]);
    expect(bloque.lineas).toHaveLength(26);
    expect(bloque.lineas.at(-1)).toBe('y 15 más');
    expect(construirBloquesDatos(Array.from({ length: 8 }, () => ({ herramienta: 'x', datos }))) ).toHaveLength(5);
  });
});
