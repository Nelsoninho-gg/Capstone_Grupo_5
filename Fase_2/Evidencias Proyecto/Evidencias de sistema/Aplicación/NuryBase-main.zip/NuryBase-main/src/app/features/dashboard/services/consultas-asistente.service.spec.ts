import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { firstValueFrom } from 'rxjs';
import { beforeEach, describe, expect, it } from 'vitest';
import { environment } from '../../../../environments/environment';
import {
  busquedaTolerante,
  ConsultasAsistenteService,
  EsquemaBase,
  validarConsultaAsistente,
} from './consultas-asistente.service';

const ESQUEMA: EsquemaBase = new Map([
  ['auditoria_usuarios', ['id', 'accion', 'campo_modificado', 'valor_nuevo']],
  ['ventas', ['id', 'total', 'anulada']],
  ['usuarios', ['id', 'nombre', 'rol']],
]);

describe('validarConsultaAsistente', () => {
  it('acepta tablas, columnas y reportes permitidos', () => {
    expect(
      validarConsultaAsistente(
        { recurso: 'ventas', select: 'id,total,detalle_venta(cantidad)', filtros: { anulada: 'eq.false' }, orden: 'id.desc' },
        ESQUEMA,
      ),
    ).toBeNull();
    expect(
      validarConsultaAsistente(
        { recurso: 'rpc/fn_reporte_ventas_sucursal', filtros: { p_desde: '2026-11-01' } },
        ESQUEMA,
      ),
    ).toBeNull();
  });

  it('acepta filtrar una tabla embebida, pero no credenciales ni auditoría', () => {
    expect(
      validarConsultaAsistente(
        { recurso: 'ventas', select: 'id,productos!inner(nombre)', filtros: { 'productos.nombre': 'ilike.*cafe*' } },
        ESQUEMA,
      ),
    ).toBeNull();
    expect(
      validarConsultaAsistente({ recurso: 'ventas', filtros: { 'auditoria_usuarios.valor_nuevo': 'eq.x' } }, ESQUEMA),
    ).not.toBeNull();
    expect(
      validarConsultaAsistente({ recurso: 'auditoria_usuarios', filtros: { 'usuarios.nombre': 'eq.x' } }, ESQUEMA),
    ).not.toBeNull();
  });

  it('sigue permitiendo el nombre del proveedor, la dirección de la sucursal y columnas que solo contienen "rut"', () => {
    const esquema: EsquemaBase = new Map([
      ['proveedores', ['id', 'nombre']],
      ['sucursales', ['id', 'direccion']],
      ['rutas', ['ruta']],
    ]);

    expect(validarConsultaAsistente({ recurso: 'proveedores', select: 'id,nombre' }, esquema)).toBeNull();
    expect(validarConsultaAsistente({ recurso: 'sucursales', select: 'direccion' }, esquema)).toBeNull();
    expect(validarConsultaAsistente({ recurso: 'rutas', select: 'ruta' }, esquema)).toBeNull();
  });

  it('al rechazar, indica qué columnas o recursos sí existen para que el modelo corrija', () => {
    expect(validarConsultaAsistente({ recurso: 'ventas', filtros: { nombre: 'eq.x' } }, ESQUEMA)).toContain(
      'Columnas de ventas: id, total, anulada',
    );
    expect(validarConsultaAsistente({ recurso: 'almuerzos' }, ESQUEMA)).toContain('Disponibles: auditoria_usuarios');
  });

  it.each([
    ['tabla bloqueada', { recurso: 'ventas_idempotencia' }],
    ['tabla desconocida', { recurso: 'pg_authid' }],
    ['recorrer rutas', { recurso: '../rpc/login' }],
    ['columna de credencial', { recurso: 'usuarios', select: 'id,password_hash' }],
    ['credencial con alias', { recurso: 'usuarios', select: 'x:password_hash' }],
    ['usuario de acceso', { recurso: 'usuarios', select: 'identificador_acceso' }],
    ['credencial embebida', { recurso: 'ventas', select: 'id,usuarios(password_hash)' }],
    ['asterisco', { recurso: 'usuarios', select: '*' }],
    ['asterisco embebido', { recurso: 'ventas', select: 'id,usuarios(*)' }],
    ['tabla bloqueada embebida', { recurso: 'ventas', select: 'id,ventas_idempotencia(clave)' }],
    ['auditoría embebida', { recurso: 'ventas', select: 'id,auditoria_usuarios(valor_nuevo)' }],
    ['orden por credencial', { recurso: 'usuarios', orden: 'password_hash.asc' }],
    ['filtro por credencial', { recurso: 'usuarios', filtros: { password_hash: 'like.a*' } }],
    ['filtro or', { recurso: 'usuarios', filtros: { or: '(password_hash.like.a*)' } }],
    ['filtro embebido', { recurso: 'ventas', filtros: { 'usuarios.password_hash': 'like.a*' } }],
    ['RUT de proveedor', { recurso: 'proveedores', select: 'nombre,rut' }],
    ['correo con alias', { recurso: 'proveedores', select: 'x:email' }],
    ['teléfono embebido', { recurso: 'facturas_compra', select: 'id,proveedores(telefono)' }],
    ['dirección de factura', { recurso: 'facturas_xml_pendientes', select: 'direccion_emisor' }],
    ['RUT de factura', { recurso: 'facturas_xml_pendientes', select: 'rut_emisor_normalizado' }],
    ['nombre del archivo XML', { recurso: 'facturas_xml_pendientes', select: 'xml_nombre' }],
    ['orden por RUT', { recurso: 'proveedores', orden: 'rut.asc' }],
    ['filtro por RUT', { recurso: 'proveedores', filtros: { rut: 'eq.1-9' } }],
    ['filtro embebido por correo', { recurso: 'facturas_compra', filtros: { 'proveedores.email': 'eq.a@b.cl' } }],
    ['reporte no permitido', { recurso: 'rpc/login' }],
    ['escritura por rpc', { recurso: 'rpc/fn_anular_venta' }],
    ['parámetro inválido en reporte', { recurso: 'rpc/fn_listar_empleados', filtros: { select: 'x' } }],
  ])('rechaza %s', (_caso, consulta) => {
    expect(validarConsultaAsistente(consulta, ESQUEMA)).not.toBeNull();
  });
});

describe('busquedaTolerante', () => {
  const encuentra = (busqueda: string, nombre: string) =>
    new RegExp(busquedaTolerante(busqueda).replace(/^imatch\./, ''), 'i').test(nombre);

  it.each([
    ['ilike.*coca cola*', 'Coca-cola zero'],
    ['ilike.*coca cola*', 'BOT COCA COLA NORMAL 591ML'],
    ['ilike.*coca cola*', 'Cocacola'],
    ['ilike.*coca*cola*', 'COCA y COLA'],
    ['ilike.*azucar*', 'Azúcar'],
    ['ilike.*azúcar*', 'BOT FANTA SIN AZUCAR 591'],
    ['ilike.*munoz*', 'ALIMENTOS GABRIELA MUÑOZ E.I.R.L.'],
    ['ilike.*s.a.*', 'Coca Cola Embonor S A'],
    ['ilike.efectivo', 'Efectivo'],
  ])('%s encuentra %s', (busqueda, nombre) => {
    expect(encuentra(busqueda, nombre)).toBe(true);
  });

  it.each([
    ['ilike.*pan*', 'pin'],
    ['ilike.efectivo', 'No efectivo'],
    ['ilike.*a(b*', 'ab'],
  ])('%s no encuentra %s', (busqueda, nombre) => {
    expect(encuentra(busqueda, nombre)).toBe(false);
  });

  it('solo cambia las búsquedas de texto', () => {
    expect(busquedaTolerante('ilike.*pan*')).toMatch(/^imatch\./);
    expect(busquedaTolerante('eq.coca cola')).toBe('eq.coca cola');
    expect(busquedaTolerante('gte.2026-10-01')).toBe('gte.2026-10-01');
  });
});

describe('ConsultasAsistenteService', () => {
  let servicio: ConsultasAsistenteService;
  let http: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()],
    });
    servicio = TestBed.inject(ConsultasAsistenteService);
    http = TestBed.inject(HttpTestingController);
  });

  it('lee el esquema una vez, sin tablas ni columnas sensibles', async () => {
    const primero = firstValueFrom(servicio.esquema());
    const req = http.expectOne(`${environment.apiUrl}/`);
    expect(req.request.headers.get('Accept')).toBe('application/openapi+json');
    req.flush({
      definitions: {
        usuarios: { properties: { id: {}, nombre: {}, password_hash: {}, identificador_acceso: {} } },
        ventas_idempotencia: { properties: { id: {} } },
        auditoria_usuarios: { properties: { id: {}, accion: {} } },
      },
    });

    const esquema = await primero;
    expect(esquema.get('usuarios')).toEqual(['id', 'nombre']);
    expect(esquema.has('ventas_idempotencia')).toBe(false);
    expect(esquema.get('auditoria_usuarios')).toEqual(['id', 'accion']);

    await firstValueFrom(servicio.esquema());
    http.expectNone(`${environment.apiUrl}/`);
  });

  it('describe el esquema indicando las llaves foráneas', async () => {
    const lectura = firstValueFrom(servicio.esquema());
    http.expectOne(`${environment.apiUrl}/`).flush({
      definitions: {
        ventas: {
          properties: {
            id: {},
            anulada_por: { description: 'Note:\nThis is a Foreign Key to `usuarios.id`.<fk table=usuarios>' },
          },
        },
      },
    });
    expect(servicio.describirEsquema(await lectura)).toBe('ventas(id, anulada_por->usuarios)');
  });

  it('un filtro en forma de lista aplica varias condiciones, como un rango de fechas', () => {
    servicio
      .ejecutar({ recurso: 'ventas', filtros: { total: ['gte.10', 'lte.20'] } }, ESQUEMA)
      .subscribe();
    const req = http.expectOne((r) => r.url.endsWith('/ventas'));
    expect(req.request.params.getAll('total')).toEqual(['gte.10', 'lte.20']);
    req.flush([], { headers: { 'Content-Range': '*/0' } });
  });

  it('reintenta el esquema si la lectura anterior falló', async () => {
    const fallida = firstValueFrom(servicio.esquema());
    http.expectOne(`${environment.apiUrl}/`).flush({}, { status: 500, statusText: 'Error' });
    await expect(fallida).rejects.toBeTruthy();

    const reintento = firstValueFrom(servicio.esquema());
    http.expectOne(`${environment.apiUrl}/`).flush({ definitions: {} });
    await expect(reintento).resolves.toBeTruthy();
  });

  it('consulta solo por GET, con columnas permitidas y límite máximo', async () => {
    const resultado = firstValueFrom(
      servicio.ejecutar({ recurso: 'usuarios', filtros: { rol: 'eq.admin' }, limite: 9999 }, ESQUEMA),
    );
    const req = http.expectOne((r) => r.url === `${environment.apiUrl}/usuarios`);
    expect(req.request.method).toBe('GET');
    expect(req.request.params.get('select')).toBe('id,nombre,rol');
    expect(req.request.params.get('rol')).toBe('eq.admin');
    expect(req.request.params.get('limit')).toBe('500');
    req.flush([{ id: 1 }], { headers: { 'Content-Range': '0-0/40' } });

    await expect(resultado).resolves.toMatchObject({ filas: [{ id: 1 }], total: 40, truncado: true });
  });

  it('llama a los reportes por GET, para que corran en solo lectura', async () => {
    const resultado = firstValueFrom(
      servicio.ejecutar(
        { recurso: 'rpc/fn_reporte_ventas_sucursal', filtros: { p_sucursales: '{1,2}' } },
        ESQUEMA,
      ),
    );
    const req = http.expectOne((r) => r.url.endsWith('/rpc/fn_reporte_ventas_sucursal'));
    expect(req.request.method).toBe('GET');
    expect(req.request.params.get('p_sucursales')).toBe('{1,2}');
    expect(req.request.params.has('select')).toBe(false);
    req.flush([{ total: 1 }], { headers: { 'Content-Range': '0-0/1' } });

    await expect(resultado).resolves.toMatchObject({ truncado: false });
  });

  it('la auditoría siempre excluye los cambios de usuario de acceso, aunque el modelo pida otro filtro', () => {
    servicio
      .ejecutar({ recurso: 'auditoria_usuarios', filtros: { campo_modificado: 'eq.identificador_acceso' } }, ESQUEMA)
      .subscribe();
    const req = http.expectOne((r) => r.url.endsWith('/auditoria_usuarios'));
    expect(req.request.params.getAll('campo_modificado')).toEqual([
      'eq.identificador_acceso',
      'neq.identificador_acceso',
    ]);
    req.flush([], { headers: { 'Content-Range': '*/0' } });
  });

  it('con lectura completa no recorta filas y permite más de 500', async () => {
    const resultado = firstValueFrom(servicio.ejecutar({ recurso: 'ventas' }, ESQUEMA, true));
    const req = http.expectOne((r) => r.url.endsWith('/ventas'));
    expect(req.request.params.get('limit')).toBe('5000');
    const filas = Array.from({ length: 100 }, () => ({ nota: 'x'.repeat(500) }));
    req.flush(filas, { headers: { 'Content-Range': '0-99/100' } });
    await expect(resultado).resolves.toMatchObject({ truncado: false });
    expect((await resultado).filas).toHaveLength(100);
  });

  it('un reporte que devuelve un JSON vacío no se considera incompleto, aunque cuente una fila', async () => {
    const respuesta = firstValueFrom(
      servicio.ejecutar({ recurso: 'rpc/fn_listar_ingresos_factura' }, ESQUEMA, true),
    );
    http
      .expectOne((r) => r.url.endsWith('/rpc/fn_listar_ingresos_factura'))
      .flush([], { headers: { 'Content-Range': '0-0/1' } });

    await expect(respuesta).resolves.toMatchObject({ filas: [], truncado: false });
  });

  it('quita RUT y datos de contacto de lo que devuelve un reporte, en cualquier nivel', async () => {
    const respuesta = firstValueFrom(
      servicio.ejecutar({ recurso: 'rpc/fn_listar_ingresos_factura' }, ESQUEMA, true),
    );
    http
      .expectOne((r) => r.url.endsWith('/rpc/fn_listar_ingresos_factura'))
      .flush([
        {
          folio: 10,
          proveedor: 'Lacteos Sur',
          rut_emisor: '76123456-7',
          xml_nombre: 'DTE_76123456-7.xml',
          lineas: [{ descripcion: 'Leche', telefono: '+56911111111', email: 'a@b.cl' }],
          intentos_duplicados: [{ usuario: 'Ana', xml_nombre: 'DTE_76123456-7.xml' }],
        },
      ]);

    expect((await respuesta).filas).toEqual([
      { folio: 10, proveedor: 'Lacteos Sur', lineas: [{ descripcion: 'Leche' }], intentos_duplicados: [{ usuario: 'Ana' }] },
    ]);
  });

  it('envía las búsquedas de texto ya toleradas, también en listas', () => {
    servicio
      .ejecutar({ recurso: 'ventas', filtros: { total: 'ilike.*a b*', anulada: ['ilike.*c-d*', 'eq.x y'] } }, ESQUEMA)
      .subscribe();

    const req = http.expectOne((r) => r.url.endsWith('/ventas'));
    expect(req.request.params.get('total')).toMatch(/^imatch\./);
    expect(req.request.params.getAll('anulada')).toEqual([busquedaTolerante('ilike.*c-d*'), 'eq.x y']);
  });

  describe('primeraVenta', () => {
    it('entrega la venta más antigua en hora de Chile', async () => {
      const fecha = firstValueFrom(servicio.primeraVenta(new Map([['ventas', ['fecha_venta']]])));
      const req = http.expectOne((r) => r.url.endsWith('/ventas'));
      expect(req.request.params.get('order')).toBe('fecha_venta.asc');
      req.flush([{ fecha_venta: '2026-09-01T02:00:00' }]);

      expect(await fecha).toBe('2026-08-31');
    });

    it('sin ventas o con error entrega null, sin romper el chat', async () => {
      const esquema: EsquemaBase = new Map([['ventas', ['fecha_venta']]]);
      const sinVentas = firstValueFrom(servicio.primeraVenta(esquema));
      http.expectOne((r) => r.url.endsWith('/ventas')).flush([]);
      expect(await sinVentas).toBeNull();

      const conError = firstValueFrom(servicio.primeraVenta(esquema));
      http.expectOne((r) => r.url.endsWith('/ventas')).flush({ message: 'x' }, { status: 500, statusText: 'Error' });
      expect(await conError).toBeNull();
    });
  });

  describe('nombresReales', () => {
    const esquema: EsquemaBase = new Map([
      ['usuarios', ['id', 'nombre']],
      ['proveedores', ['id', 'nombre']],
      ['facturas_xml_pendientes', ['id', 'razon_social_emisor']],
    ]);
    const responder = (recurso: string, filas: unknown[], rango = `0-${filas.length}/*`) =>
      http
        .expectOne((r) => r.url.endsWith(`/${recurso}`))
        .flush(filas, { headers: { 'Content-Range': rango } });

    it('junta personas, proveedores y razones sociales', async () => {
      const nombres = firstValueFrom(servicio.nombresReales(esquema));
      responder('usuarios', [{ nombre: 'Ana' }]);
      responder('proveedores', [{ nombre: 'Lacteos Sur' }]);
      responder('facturas_xml_pendientes', [{ razon_social_emisor: 'Juan Soto EIRL' }, { razon_social_emisor: null }]);

      expect(await nombres).toEqual({ personas: ['Ana'], proveedores: ['Lacteos Sur', 'Juan Soto EIRL'] });
    });

    it('falla si una lectura da error o queda incompleta', async () => {
      const conError = firstValueFrom(servicio.nombresReales(esquema));
      http
        .expectOne((r) => r.url.endsWith('/usuarios'))
        .flush({ message: 'sin permiso' }, { status: 403, statusText: 'Forbidden' });
      await expect(conError).rejects.toThrow('sin permiso');

      const incompleta = firstValueFrom(servicio.nombresReales(esquema));
      responder('usuarios', [{ nombre: 'Ana' }], '0-0/9000');
      await expect(incompleta).rejects.toThrow('lectura incompleta');
    });
  });

  it('no hace ninguna petición si la consulta se rechaza', async () => {
    const resultado = await firstValueFrom(
      servicio.ejecutar({ recurso: 'usuarios', select: 'password_hash' }, ESQUEMA),
    );
    expect(resultado.error).toContain('credenciales');
    http.expectNone((r) => r.url.includes('usuarios'));
  });

  it('devuelve el error de la API como dato y recorta resultados enormes', async () => {
    const conError = firstValueFrom(servicio.ejecutar({ recurso: 'ventas' }, ESQUEMA));
    http
      .expectOne((r) => r.url.endsWith('/ventas'))
      .flush({ message: 'column does not exist', hint: 'Prueba otra' }, { status: 400, statusText: 'Bad Request' });
    await expect(conError).resolves.toMatchObject({ error: 'column does not exist Prueba otra' });

    const grande = firstValueFrom(servicio.ejecutar({ recurso: 'ventas' }, ESQUEMA));
    const filas = Array.from({ length: 100 }, () => ({ nota: 'x'.repeat(500) }));
    http
      .expectOne((r) => r.url.endsWith('/ventas'))
      .flush(filas, { headers: { 'Content-Range': '0-99/100' } });
    const resultado = await grande;
    expect(resultado.filas!.length).toBeLessThan(100);
    expect(resultado.truncado).toBe(true);
  });
});
