export interface NombresReales {
  personas: readonly string[];
  /** Nombres de proveedores y razones sociales: muchas incluyen el nombre de una persona. */
  proveedores: readonly string[];
}

export interface Seudonimos {
  /** Cambia los nombres reales por PERSONA_3 o PROVEEDOR_5 antes de enviar el texto a la IA. */
  ocultar(texto: string): string;
  /** Repone los nombres en el JSON que entrega la IA, sin romperlo si un nombre trae comillas. */
  reponerEnJson(json: string): string;
  /** Nombres reales: los que repone el sistema no son inventos del modelo. */
  readonly nombres: string;
}

/** Son cuentas de un cargo, no personas, y sus nombres son palabras que el modelo necesita leer. */
const CUENTA_DE_CARGO = /^(admin|administrador|cajero|bodeguero)$/i;
const SEUDONIMO = /\b(PERSONA|PROVEEDOR)_\d+\b/gi;
const LETRAS_EQUIVALENTES: Record<string, string> = {
  a: '[aá]',
  e: '[eé]',
  i: '[ií]',
  o: '[oó]',
  u: '[uúü]',
  n: '[nñ]',
  ' ': '\\s+',
  // Dentro de un JSON, una comilla del nombre viene escapada.
  '"': '\\\\?"',
};

function clave(texto: string): string {
  return texto
    .toLowerCase()
    .normalize('NFD')
    .replace(/[̀-ͯ\\]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function patronDe(claveNombre: string): string {
  return [...claveNombre]
    .map((letra) => LETRAS_EQUIVALENTES[letra] ?? letra.replace(/[.*+?^${}()|[\]]/, '\\$&'))
    .join('');
}

export function crearSeudonimos({ personas, proveedores }: NombresReales): Seudonimos {
  const seudonimoDe = new Map<string, string>();
  const nombreDe = new Map<string, string>();
  const registrar = (nombres: readonly string[], prefijo: string) => {
    for (const nombre of nombres) {
      const k = clave(nombre);
      if (k && !seudonimoDe.has(k)) {
        const seudonimo = `${prefijo}_${nombreDe.size + 1}`;
        seudonimoDe.set(k, seudonimo);
        nombreDe.set(seudonimo, nombre);
      }
    }
  };

  const conNombre = personas.filter((p) => !CUENTA_DE_CARGO.test(p.trim()));
  registrar(conNombre, 'PERSONA');
  registrar(proveedores, 'PROVEEDOR');

  // Quien pregunta por "Mauricio" debe coincidir con Mauricio Figueroa en los resultados, si no hay otro igual.
  const primerNombre = (p: string) => clave(p).split(' ')[0];
  for (const persona of conNombre) {
    const primero = primerNombre(persona);
    const esUnico = conNombre.filter((p) => primerNombre(p) === primero).length === 1;
    if (primero.length >= 3 && esUnico && !seudonimoDe.has(primero)) {
      seudonimoDe.set(primero, seudonimoDe.get(clave(persona))!);
    }
  }

  // De más largo a más corto: "Mauricio Figueroa" debe ganarle a "Mauricio".
  const alternativas = [...seudonimoDe.keys()].sort((a, b) => b.length - a.length).map(patronDe);
  const patron = new RegExp(`(?<![\\p{L}\\p{N}])(?:${alternativas.join('|')})(?![\\p{L}\\p{N}])`, 'giu');

  return {
    ocultar: (texto) =>
      alternativas.length === 0
        ? texto
        : texto.replace(patron, (hallado) => seudonimoDe.get(clave(hallado)) ?? hallado),
    reponerEnJson: (json) =>
      json.replace(SEUDONIMO, (hallado) => {
        const nombre = nombreDe.get(hallado.toUpperCase());
        return nombre ? JSON.stringify(nombre).slice(1, -1) : hallado;
      }),
    nombres: [...nombreDe.values()].join(' '),
  };
}

/** Seudónimos que quedaron sin reponer porque el modelo escribió uno que no existe. */
export function seudonimosSinReponer(texto: string): string[] {
  return texto.match(SEUDONIMO) ?? [];
}
