import { TestBed } from '@angular/core/testing';
import { Observable, firstValueFrom, of, throwError } from 'rxjs';
import { describe, expect, it, vi } from 'vitest';
import {
  ConsumoDiarioArticuloApi,
  MovimientoConsumoApi,
  StockApiService,
} from '../../../core/api/stock-api.service';
import {
  OrquestadorIaService,
  RespuestaOrquestadorIA,
  SinProveedoresIAError,
} from '../../../core/ia/orquestador-ia.service';
import { MensajesIA } from '../../../core/ia/proveedores-ia.config';
import { ArticuloPredictivo } from '../models/prediccion.model';
import { PrediccionStockService, calcularPrediccionArticulo } from './prediccion-stock.service';
import { PredictiveCacheService } from './predictive-cache.service';

describe('PrediccionStockService (H4.5 T07)', () => {
  let servicio: PrediccionStockService;
  let stockApiRespuesta: () => Observable<ConsumoDiarioArticuloApi[]>;
  let orquestadorRespuesta: () => Observable<RespuestaOrquestadorIA>;
  let cacheContenido: unknown = null;
  let cacheGuardadoClave: string | null = null;
  let cacheGuardadoValor: unknown = null;
  let ultimosMensajes: MensajesIA | null = null;

  const articuloApto: ArticuloPredictivo = {
    id: 'art-harina-1',
    articulo: 'Harina Panadera 000',
    tipo: 'materia_prima',
    sucursalId: 1,
    sucursal: 'Nury Providencia',
    stockActual: 20,
    stockMinimo: 18,
    unidad: 'kg',
    diasHistorial: 45,
    consumoDiarioBase: 5,
  };

  const articuloNuevo: ArticuloPredictivo = {
    id: 'art-matcha-1',
    articulo: 'Té Matcha Japonés',
    tipo: 'materia_prima',
    sucursalId: 1,
    sucursal: 'Nury Providencia',
    stockActual: 2,
    stockMinimo: 1,
    unidad: 'kg',
    diasHistorial: 10,
    consumoDiarioBase: 0.2,
  };

  let movimientosRespuesta: () => Observable<MovimientoConsumoApi[]>;

  const fakeStockApi = {
    listarConsumoDiarioArticulos: (_sucursalId: number | null) => stockApiRespuesta(),
    listarMovimientosConsumo: (_sucursalId: number | null, _desde: Date) => movimientosRespuesta(),
  };

  const fakeOrquestador = {
    solicitar: (mensajes: MensajesIA) => {
      ultimosMensajes = mensajes;
      return orquestadorRespuesta();
    },
  };

  const fakeCache = {
    construirClave: (suc: number | string, fecha: string, ids: readonly string[]) =>
      `${suc}|${fecha}|${ids.join(',')}`,
    obtener: (_clave: string) => cacheContenido,
    guardar: (clave: string, _suc: number | string, val: unknown) => {
      cacheGuardadoClave = clave;
      cacheGuardadoValor = val;
    },
    invalidarSucursal: () => {},
  };

  beforeEach(() => {
    cacheContenido = null;
    cacheGuardadoClave = null;
    cacheGuardadoValor = null;
    ultimosMensajes = null;
    movimientosRespuesta = () => of([]);

    TestBed.configureTestingModule({
      providers: [
        PrediccionStockService,
        { provide: StockApiService, useValue: fakeStockApi },
        { provide: OrquestadorIaService, useValue: fakeOrquestador },
        { provide: PredictiveCacheService, useValue: fakeCache },
      ],
    });

    servicio = TestBed.inject(PrediccionStockService);
  });

  describe('cargarArticulos()', () => {
    it('mapea correctamente las filas de v_consumo_diario_articulos calculando consumo diario efectivo', async () => {
      const filaMock: ConsumoDiarioArticuloApi = {
        tipo: 'materia_prima',
        articulo_id: 10,
        nombre: 'Leche Entera',
        unidad: 'l',
        activo: true,
        sucursal_id: 1,
        sucursal: 'Nury Providencia',
        stock_actual: 30,
        stock_minimo: 20,
        dias_con_historial: 15,
        total_vendido_28d: 45,
        total_merma_28d: 0,
        consumo_total_28d: 45,
        consumo_diario_promedio: 1.607,
      };

      stockApiRespuesta = () => of([filaMock]);

      const articulos = await firstValueFrom(servicio.cargarArticulos(1));
      expect(articulos).toHaveLength(1);
      const art = articulos[0];
      expect(art.id).toBe('art-materia_prima-10-1');
      expect(art.articulo).toBe('Leche Entera');
      expect(art.diasHistorial).toBe(15);
      // 45 consumidos / 15 días reales = 3.0 l/día (no 45 / 28)
      expect(art.consumoDiarioBase).toBe(3);
    });

    it('no muestra datos de ejemplo si la API responde error o está offline', async () => {
      stockApiRespuesta = () => throwError(() => new Error('Red caída'));

      const articulos = await firstValueFrom(servicio.cargarArticulos(1));
      expect(articulos).toEqual([]);
    });

    const filaMadura: ConsumoDiarioArticuloApi = {
      tipo: 'materia_prima',
      articulo_id: 10,
      nombre: 'Leche Entera',
      unidad: 'l',
      activo: true,
      sucursal_id: 1,
      sucursal: 'Nury Providencia',
      stock_actual: 30,
      stock_minimo: 20,
      dias_con_historial: 40,
      total_vendido_28d: 280,
      total_merma_28d: 0,
      consumo_total_28d: 280,
      consumo_diario_promedio: 10,
    };

    /** Lunes a viernes, 20 días operativos con 10 l diarios y un pico de 200 l. */
    function movimientosDeLeche(): MovimientoConsumoApi[] {
      const filas: MovimientoConsumoApi[] = [];
      for (let semana = 0; semana < 4; semana++) {
        for (let dia = 0; dia < 5; dia++) {
          filas.push({
            tipo_articulo: 'materia_prima',
            articulo_id: 10,
            sucursal_id: 1,
            tipo_movimiento: 'venta',
            cantidad: semana === 2 && dia === 2 ? -200 : -10,
            fecha: new Date(Date.UTC(2026, 9, 5 + semana * 7 + dia, 15)).toISOString(),
          });
        }
      }
      return filas;
    }

    it('con 28 días de historial usa la serie operativa sin atípicos, no el promedio de 28 días corridos', async () => {
      stockApiRespuesta = () => of([filaMadura]);
      movimientosRespuesta = () => of(movimientosDeLeche());

      const [leche] = await firstValueFrom(servicio.cargarArticulos(1));

      expect(leche.serieConsumo).toHaveLength(20);
      expect(leche.consumoDiarioBase).toBe(10);
    });

    it('sigue funcionando con el promedio de la vista si no puede leer los movimientos', async () => {
      stockApiRespuesta = () => of([filaMadura]);
      movimientosRespuesta = () => throwError(() => new Error('Sin permiso'));

      const [leche] = await firstValueFrom(servicio.cargarArticulos(1));

      expect(leche.serieConsumo).toBeUndefined();
      expect(leche.consumoDiarioBase).toBe(10);
    });

    it('no usa la serie en artículos con menos de 28 días', async () => {
      stockApiRespuesta = () => of([{ ...filaMadura, dias_con_historial: 15, consumo_total_28d: 45 }]);
      movimientosRespuesta = () => of(movimientosDeLeche());

      const [leche] = await firstValueFrom(servicio.cargarArticulos(1));

      expect(leche.serieConsumo).toBeUndefined();
      expect(leche.consumoDiarioBase).toBe(3);
    });
  });

  describe('generarSugerencias()', () => {
    it('resuelve localmente sin llamar a la IA cuando todos los artículos tienen < 28 días', async () => {
      let orquestadorLlamado = false;
      orquestadorRespuesta = () => {
        orquestadorLlamado = true;
        return of({ proveedorId: 'gemini', modelo: 'flash', contenido: '{}', intentos: [] });
      };

      const res = await firstValueFrom(servicio.generarSugerencias([articuloNuevo]));
      expect(res.origen).toBe('datos-insuficientes-local');
      expect(orquestadorLlamado).toBe(false);
      expect(res.predicciones).toHaveLength(1);
      expect(res.predicciones[0].estado).toBe('datos-insuficientes');
      expect(res.predicciones[0].justificacion).toBe('datos insuficientes para predecir');
      expect(res.madurez.requiereAvisoMadurez).toBe(true);
    });

    it('retorna predicción desde caché, sin llamar a la IA, conservando las cifras del algoritmo', async () => {
      cacheContenido = { predicciones: [{ articuloId: 'art-harina-1', justificacion: 'Cache hit.' }] };

      let orquestadorLlamado = false;
      orquestadorRespuesta = () => {
        orquestadorLlamado = true;
        return of({ proveedorId: 'gemini', modelo: 'flash', contenido: '{}', intentos: [] });
      };

      const res = await firstValueFrom(servicio.generarSugerencias([articuloApto]));
      expect(res.origen).toBe('cache');
      expect(orquestadorLlamado).toBe(false);
      expect(res.predicciones[0]).toMatchObject({
        articuloId: 'art-harina-1',
        justificacion: 'Cache hit.',
        tasaDiariaEstimada: 5,
        diasHastaMinimo: 0.4,
        cantidadSugerida: 3,
      });
    });

    it('la clave de caché cambia si cambia el stock, para no reutilizar textos con datos antiguos', async () => {
      orquestadorRespuesta = () => of({ proveedorId: 'g', modelo: 'm', contenido: 'no json', intentos: [] });
      const claves: string[] = [];
      const original = fakeCache.obtener;
      fakeCache.obtener = (clave: string) => {
        claves.push(clave);
        return null;
      };

      await firstValueFrom(servicio.generarSugerencias([articuloApto]));
      await firstValueFrom(servicio.generarSugerencias([{ ...articuloApto, stockActual: 25 }]));
      fakeCache.obtener = original;

      expect(claves[0]).not.toBe(claves[1]);
    });

    it('la IA solo aporta el texto: sus cifras se ignoran y se guarda en caché', async () => {
      const respuestaIaMock: RespuestaOrquestadorIA = {
        proveedorId: 'gemini',
        modelo: 'gemini-flash-lite',
        contenido: JSON.stringify({
          predicciones: [
            {
              articuloId: 'art-harina-1',
              // Cifras inventadas por el modelo: deben ignorarse.
              estado: 'estable',
              cantidadSugerida: 999,
              tasaDiariaEstimada: 999,
              justificacion: 'Consumo regular; conviene reponer hoy.',
            },
          ],
        }),
        intentos: [],
      };
      orquestadorRespuesta = () => of(respuestaIaMock);

      const res = await firstValueFrom(servicio.generarSugerencias([articuloApto, articuloNuevo]));

      expect(res.origen).toBe('ia');
      expect(res.proveedorUsado).toContain('gemini-flash-lite');
      expect(cacheGuardadoClave).not.toBeNull();
      expect(cacheGuardadoValor).not.toBeNull();
      expect(res.predicciones).toHaveLength(2);
      expect(res.predicciones[0]).toMatchObject({
        articuloId: 'art-harina-1',
        estado: 'comprar-hoy',
        tasaDiariaEstimada: 5,
        diasHastaMinimo: 0.4,
        cantidadSugerida: 3,
        justificacion: 'Consumo regular; conviene reponer hoy.',
      });
      expect(res.predicciones[1].estado).toBe('datos-insuficientes');
    });

    it('envía a la IA el cálculo ya hecho, solo de los artículos aptos', async () => {
      orquestadorRespuesta = () =>
        of({
          proveedorId: 'g',
          modelo: 'm',
          contenido: JSON.stringify({ predicciones: [{ articuloId: 'art-harina-1', justificacion: 'ok' }] }),
          intentos: [],
        });

      await firstValueFrom(servicio.generarSugerencias([articuloApto, articuloNuevo]));

      const entrada = JSON.parse(ultimosMensajes!.usuario);
      expect(entrada.articulos).toHaveLength(1);
      expect(entrada.articulos[0].calculo).toMatchObject({
        estado: 'comprar-hoy',
        cantidadSugerida: 3,
        diasHastaMinimo: 0,
      });
    });

    it('envía a la IA solo los artículos de compra hoy o pronto, con los de hoy primero', async () => {
      const pronto = { ...articuloApto, id: 'art-pronto', stockActual: 33 };
      const suficiente = { ...articuloApto, id: 'art-suficiente', stockActual: 500 };
      orquestadorRespuesta = () =>
        of({ proveedorId: 'g', modelo: 'm', contenido: JSON.stringify({ predicciones: [] }), intentos: [] });

      await firstValueFrom(servicio.generarSugerencias([suficiente, pronto, articuloApto]));

      const entrada = JSON.parse(ultimosMensajes!.usuario);
      expect(entrada.articulos.map((a: { calculo: { estado: string } }) => a.calculo.estado)).toEqual([
        'comprar-hoy',
        'proximo-pedido',
      ]);
    });

    it('no llama a la IA si no hay nada urgente y conserva el texto del algoritmo', async () => {
      const suficiente = { ...articuloApto, stockActual: 500 };
      orquestadorRespuesta = () => throwError(() => new Error('No debería llamarse'));

      const res = await firstValueFrom(servicio.generarSugerencias([suficiente]));

      expect(ultimosMensajes).toBeNull();
      expect(res.origen).toBe('respaldo-local');
      expect(res.predicciones[0].justificacion).toContain('Stock suficiente');
    });

    it('marca solo los artículos interpretados por la IA y registra los textos descartados', async () => {
      const pronto = { ...articuloApto, id: 'art-pronto', stockActual: 33 };
      const suficiente = { ...articuloApto, id: 'art-suficiente', stockActual: 500 };
      const aviso = vi.spyOn(console, 'warn').mockImplementation(() => undefined);
      orquestadorRespuesta = () =>
        of({
          proveedorId: 'g',
          modelo: 'm',
          contenido: JSON.stringify({
            predicciones: [
              { articuloId: articuloApto.id, justificacion: 'Hay que comprar hoy.' },
              { articuloId: pronto.id, justificacion: 'Se usan 12345 al día.' },
            ],
          }),
          intentos: [],
        });

      const res = await firstValueFrom(servicio.generarSugerencias([articuloApto, pronto, suficiente]));

      expect(res.predicciones.map((p) => p.interpretadaPorIa)).toEqual([true, undefined, undefined]);
      expect(aviso.mock.calls[0][1]).toEqual([expect.objectContaining({ articuloId: pronto.id })]);
    });

    it('envía como máximo 30 artículos a la IA', async () => {
      const urgentes = Array.from({ length: 35 }, (_, i) => ({ ...articuloApto, id: `art-${i}` }));
      orquestadorRespuesta = () =>
        of({ proveedorId: 'g', modelo: 'm', contenido: JSON.stringify({ predicciones: [] }), intentos: [] });

      const res = await firstValueFrom(servicio.generarSugerencias(urgentes));

      expect(JSON.parse(ultimosMensajes!.usuario).articulos).toHaveLength(30);
      expect(res.predicciones).toHaveLength(35);
    });

    it('conserva la justificación del algoritmo si la IA escribe cifras sin respaldo', async () => {
      orquestadorRespuesta = () =>
        of({
          proveedorId: 'g',
          modelo: 'm',
          contenido: JSON.stringify({ predicciones: [{ articuloId: 'art-harina-1', justificacion: 'Compra 777 kg.' }] }),
          intentos: [],
        });

      const res = await firstValueFrom(servicio.generarSugerencias([articuloApto]));

      expect(res.origen).toBe('respaldo-local');
      expect(res.predicciones[0].justificacion).toContain('Comprar hoy');
      expect(res.predicciones[0].justificacion).not.toContain('777');
    });

    it('activa el cálculo del algoritmo si la IA devuelve JSON corrupto', async () => {
      orquestadorRespuesta = () =>
        of({ proveedorId: 'gemini', modelo: 'flash', contenido: 'Texto no JSON', intentos: [] });

      const res = await firstValueFrom(servicio.generarSugerencias([articuloApto]));
      expect(res.origen).toBe('respaldo-local');
      expect(res.predicciones[0].estado).toBe('comprar-hoy');
      expect(cacheGuardadoClave).toBeNull();
    });

    it('activa el cálculo del algoritmo si se agotan los proveedores', async () => {
      orquestadorRespuesta = () => throwError(() => new SinProveedoresIAError('agotados', []));

      const res = await firstValueFrom(servicio.generarSugerencias([articuloApto]));
      expect(res.origen).toBe('respaldo-local');
      expect(res.predicciones[0].cantidadSugerida).toBeGreaterThan(0);
    });

    it('sin IA, con IA o desde caché entrega las mismas cifras', async () => {
      const cifras = (p: Record<string, unknown>) => {
        const { justificacion: _j, interpretadaPorIa: _ia, ...resto } = p;
        return resto;
      };
      const fecha = new Date(2026, 10, 5, 12);

      orquestadorRespuesta = () => throwError(() => new SinProveedoresIAError('agotados', []));
      const sinIa = await firstValueFrom(servicio.generarSugerencias([articuloApto], fecha));

      orquestadorRespuesta = () =>
        of({
          proveedorId: 'g',
          modelo: 'm',
          contenido: JSON.stringify({ predicciones: [{ articuloId: 'art-harina-1', justificacion: 'ok' }] }),
          intentos: [],
        });
      const conIa = await firstValueFrom(servicio.generarSugerencias([articuloApto], fecha));

      expect(cifras({ ...conIa.predicciones[0] })).toEqual(cifras({ ...sinIa.predicciones[0] }));
    });
  });
});

describe('calcularPrediccionArticulo', () => {
  const base: ArticuloPredictivo = {
    id: 'a',
    articulo: 'Leche',
    tipo: 'materia_prima',
    sucursalId: 1,
    sucursal: 'S',
    stockActual: 30,
    stockMinimo: 10,
    unidad: 'l',
    diasHistorial: 40,
    consumoDiarioBase: 5,
  };

  it('clasifica por cobertura con los umbrales de 1,5 y 4 días', () => {
    expect(calcularPrediccionArticulo({ ...base, stockActual: 15 }, '2026-11-05')).toMatchObject({
      estado: 'comprar-hoy',
      diasHastaMinimo: 1,
      fechaRecomendadaPedido: '2026-11-05',
    });
    expect(calcularPrediccionArticulo({ ...base, stockActual: 25 }, '2026-11-05')).toMatchObject({
      estado: 'proximo-pedido',
      diasHastaMinimo: 3,
      fechaRecomendadaPedido: '2026-11-06',
    });
    expect(calcularPrediccionArticulo({ ...base, stockActual: 40 }, '2026-11-05').estado).toBe('estable');
  });

  it('con stock negativo y sin consumo calculado sugiere comprar hoy, sin textos con null', () => {
    const prediccion = calcularPrediccionArticulo(
      { ...base, tipo: 'producto', unidad: 'un', stockActual: -4, stockMinimo: 0, consumoDiarioBase: 0 },
      '2026-11-05',
    );
    expect(prediccion).toMatchObject({
      estado: 'comprar-hoy',
      cantidadSugerida: 4,
      fechaRecomendadaPedido: '2026-11-05',
      tasaDiariaEstimada: null,
    });
    expect(prediccion.justificacion).toContain('regularizar la diferencia');
    expect(prediccion.justificacion).not.toContain('null');
  });

  it('no predice con menos de 28 días y explica el caso sin consumo', () => {
    expect(calcularPrediccionArticulo({ ...base, diasHistorial: 27 }, '2026-11-05')).toMatchObject({
      estado: 'datos-insuficientes',
      tasaDiariaEstimada: null,
      justificacion: 'datos insuficientes para predecir',
    });
    const sinConsumo = calcularPrediccionArticulo({ ...base, consumoDiarioBase: 0 }, '2026-11-05');
    expect(sinConsumo.estado).toBe('estable');
    expect(sinConsumo.justificacion).toContain('Sin consumo en los últimos');
  });
});
