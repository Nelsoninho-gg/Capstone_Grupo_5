import { describe, expect, it } from 'vitest';
import { crearSeudonimos, seudonimosSinReponer } from './seudonimos-asistente';

const seudonimos = crearSeudonimos({
  personas: ['Bodeguero', 'Cajero', 'Nelson', 'Nelson2', 'Mauricio Figueroa', 'Sebastián', 'Ana Díaz', 'Ana Soto'],
  proveedores: [
    'COMERCIALIZADORA JAVIER GONZÁLEZ E.I.R.L.',
    "VIVANCO'S  SPA",
    'Lácteos "Sur" S.A.',
    'comercializadora javier gonzález e.i.r.l.',
  ],
});
const { ocultar } = seudonimos;

describe('crearSeudonimos', () => {
  it('oculta personas y proveedores en cualquier parte del texto, sin importar mayúsculas ni acentos', () => {
    const texto = ocultar(
      '{"cajero":"Nelson","otro":"mauricio figueroa","emisor":"comercializadora javier gonzalez e.i.r.l."} sebastian',
    );

    expect(texto).not.toMatch(/nelson|mauricio|figueroa|javier|sebasti/i);
    expect(texto).toContain('"cajero":"PERSONA_');
    expect(texto).toContain('"emisor":"PROVEEDOR_');
  });

  it('distingue nombres parecidos y no toca palabras que solo los contienen', () => {
    expect(ocultar('Nelson, Nelson2 y Nelsonia')).toBe('PERSONA_1, PERSONA_2 y Nelsonia');
  });

  it('un nombre de pila apunta a la persona si no hay otra igual; si la hay, no adivina', () => {
    expect(ocultar('¿Cuánto vendió Mauricio?')).toBe(`¿Cuánto vendió ${ocultar('Mauricio Figueroa')}?`);
    expect(ocultar('¿Cuánto vendió Ana?')).toBe('¿Cuánto vendió Ana?');
    expect(ocultar('Ana Díaz')).not.toBe(ocultar('Ana Soto'));
  });

  it('deja las cuentas de un cargo y los roles, que no son personas', () => {
    const texto = '{"nombre":"Cajero","rol":"bodeguero","otro":"cajero"}';

    expect(ocultar(texto)).toBe(texto);
  });

  it('oculta nombres con espacios dobles o con comillas ya escapadas en JSON', () => {
    expect(ocultar("VIVANCO'S SPA")).toMatch(/^PROVEEDOR_\d+$/);
    expect(ocultar(JSON.stringify({ emisor: 'Lácteos "Sur" S.A.' }))).toMatch(/^\{"emisor":"PROVEEDOR_\d+"\}$/);
  });

  it('un mismo proveedor escrito igual en dos fuentes tiene un solo seudónimo', () => {
    expect(seudonimos.nombres.match(/javier/gi)).toHaveLength(1);
  });

  it('repone los nombres de vuelta, y el JSON sigue siendo válido', () => {
    const proveedor = ocultar('Lácteos "Sur" S.A.');
    const persona = ocultar('Nelson');
    const json = JSON.stringify({ respuesta: `${proveedor} y ${persona} con ${persona.toLowerCase()}` });

    expect(JSON.parse(seudonimos.reponerEnJson(json)).respuesta).toBe('Lácteos "Sur" S.A. y Nelson con Nelson');
  });

  it('avisa de un seudónimo que no existe y no lo confunde con un id', () => {
    const texto = JSON.parse(seudonimos.reponerEnJson(JSON.stringify({ r: 'PERSONA_999 y el proveedor 5' }))).r;

    expect(texto).toBe('PERSONA_999 y el proveedor 5');
    expect(seudonimosSinReponer(texto)).toEqual(['PERSONA_999']);
    expect(seudonimosSinReponer('Nelson y el proveedor 5')).toEqual([]);
  });

  it('sin nombres, no cambia nada', () => {
    expect(crearSeudonimos({ personas: [], proveedores: [] }).ocultar('Hola')).toBe('Hola');
  });
});
