import { TurnoReporte } from './reportes.model';

const DIAS = ['dom', 'lun', 'mar', 'mié', 'jue', 'vie', 'sáb'];

interface Momento {
  fecha: string;
  dia: string;
  hora: string;
}

/** "2026-10-20T23:00:00" (hora de Chile, sin zona) → partes para mostrar, sin pasar por UTC. */
function momento(valor: string): Momento | null {
  const partes = /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})/.exec(valor);
  if (!partes) return null;
  const [, anio, mes, dia, hora, minuto] = partes;
  const semana = new Date(Number(anio), Number(mes) - 1, Number(dia)).getDay();
  return { fecha: `${dia}-${mes}`, dia: DIAS[semana], hora: `${hora}:${minuto}` };
}

/**
 * Horario de un turno real (H4.3 T03): "mar 20-10 · 09:00 a 17:00", "mar 20-10 23:00 a
 * mié 21-10 02:00" si cruza la medianoche, o "mar 20-10 · desde 12:00 (abierto)".
 */
export function horarioTurno(turno: Pick<TurnoReporte, 'inicio' | 'fin'>): string {
  const inicio = turno.inicio ? momento(turno.inicio) : null;
  if (!inicio) return '';
  const fin = turno.fin ? momento(turno.fin) : null;
  if (!fin) return `${inicio.dia} ${inicio.fecha} · desde ${inicio.hora} (abierto)`;
  if (fin.fecha === inicio.fecha)
    return `${inicio.dia} ${inicio.fecha} · ${inicio.hora} a ${fin.hora}`;
  return `${inicio.dia} ${inicio.fecha} ${inicio.hora} a ${fin.dia} ${fin.fecha} ${fin.hora}`;
}

/** Nombre corto del turno para el botón del desplegable: "Ana · mar 20-10 · 09:00 a 17:00". */
export function etiquetaTurno(turno: TurnoReporte): string {
  return turno.turnoId === null
    ? 'Sin turno registrado'
    : `${turno.cajero} · ${horarioTurno(turno)}`;
}
