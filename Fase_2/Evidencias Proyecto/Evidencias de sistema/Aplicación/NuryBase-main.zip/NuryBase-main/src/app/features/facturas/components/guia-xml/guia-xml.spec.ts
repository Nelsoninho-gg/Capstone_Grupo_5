import { ComponentFixture, TestBed } from '@angular/core/testing';
import { GuiaXml } from './guia-xml';

describe('GuiaXml', () => {
  let fixture: ComponentFixture<GuiaXml>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [GuiaXml] }).compileComponents();
    fixture = TestBed.createComponent(GuiaXml);
    fixture.detectChanges();
  });

  it('numbers the steps from the SII to Nury and shows the screenshots with a description', () => {
    const pasos = Array.from(fixture.nativeElement.querySelectorAll('.guia-paso')) as HTMLElement[];
    expect(pasos.map((paso) => paso.querySelector('.guia-numero')?.textContent?.trim())).toEqual(
      ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11'],
    );
    expect(pasos[5].textContent).toContain('«Archivo Respaldo»');
    expect(fixture.nativeElement.querySelectorAll('ol')[1].getAttribute('start')).toBe('8');

    const imagenes = Array.from(fixture.nativeElement.querySelectorAll('.guia-paso img')) as HTMLImageElement[];
    expect(imagenes.length).toBe(6);
    for (const imagen of imagenes) {
      expect(imagen.getAttribute('src')).toMatch(/^ayuda\/factura-xml\/\d\d-[a-z-]+\.webp$/);
      expect(imagen.alt).not.toBe('');
    }
  });

  it('links to the received documents of the SII in a new tab', () => {
    const enlace = fixture.nativeElement.querySelector('a') as HTMLAnchorElement;
    expect(enlace.href).toBe('https://www1.sii.cl/cgi-bin/Portal001/mipeLaunchPage.cgi?OPCION=1&TIPO=4');
    expect(enlace.target).toBe('_blank');
    expect(enlace.rel).toContain('noopener');
  });

  it('takes the focus and closes with the button or Escape', () => {
    const cerrar = vi.fn();
    fixture.componentInstance.cerrar.subscribe(cerrar);
    const boton = fixture.nativeElement.querySelector('.modal-close') as HTMLButtonElement;
    expect(document.activeElement).toBe(boton);

    boton.click();
    fixture.nativeElement
      .querySelector('[role="dialog"]')
      .dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));

    expect(cerrar).toHaveBeenCalledTimes(2);
  });
});
