import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpErrorResponse } from '@angular/common/http';
import { Subject, of, throwError } from 'rxjs';
import { AlmuerzosApiService, fechaHoyChile } from '../../../../core/api/almuerzos-api.service';
import { ProductosApiService } from '../../../../core/api/productos-api.service';
import { RecetasApiService } from '../../../../core/api/recetas-api.service';
import { SucursalesApiService } from '../../../../core/api/sucursales-api.service';
import { UsuariosApiService } from '../../../../core/api/usuarios-api.service';
import { User } from '../../../auth/models/auth.model';
import { AuthService } from '../../../auth/services/auth.service';
import { AlmuerzoEmpleados } from './almuerzo-empleados';

describe('AlmuerzoEmpleados', () => {
  let fixture: ComponentFixture<AlmuerzoEmpleados>;
  let usuarioActual: Partial<User> = {};
  let listarEmpleados = vi.fn();
  let empleadosConAlmuerzo = vi.fn();
  let registrar = vi.fn();

  const producto = (id: number, nombre: string, codigo_barras: string | null = null) => ({
    id,
    nombre,
    categoria: null,
    precio_compra: null,
    precio_venta: 1000,
    codigo_barras,
    activo: true,
    creado_en: '2026-10-01T00:00:00',
  });

  async function crear(): Promise<void> {
    await TestBed.configureTestingModule({
      imports: [AlmuerzoEmpleados],
      providers: [
        {
          provide: SucursalesApiService,
          useValue: {
            listarActivas: () =>
              of([
                { id: 1, nombre: 'Nury Providencia' },
                { id: 2, nombre: 'Nury Ñuñoa' },
              ]),
          },
        },
        { provide: UsuariosApiService, useValue: { listarEmpleados } },
        {
          provide: ProductosApiService,
          useValue: {
            listar: () =>
              of([
                producto(1, 'Coca-Cola 350', '7801234567890'),
                producto(2, 'Menú del día'),
              ]),
          },
        },
        { provide: RecetasApiService, useValue: { listarIdsProductosConReceta: () => of([2]) } },
        { provide: AlmuerzosApiService, useValue: { empleadosConAlmuerzo, registrar } },
        { provide: AuthService, useValue: { currentUser: () => usuarioActual } },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(AlmuerzoEmpleados);
    fixture.detectChanges();
    await fixture.whenStable();
  }

  const elemento = (): HTMLElement => fixture.nativeElement;
  const boton = (texto: string): HTMLButtonElement =>
    [...elemento().querySelectorAll('button')].find((b) => b.textContent?.trim() === texto)!;
  const elegir = (etiqueta: string, valor: string): void => {
    const select = elemento().querySelector<HTMLSelectElement>(`select[aria-label="${etiqueta}"]`)!;
    select.value = valor;
    select.dispatchEvent(new Event('change'));
    fixture.detectChanges();
  };
  const buscar = (texto: string): HTMLInputElement => {
    const input = elemento().querySelector<HTMLInputElement>('#buscar-producto-almuerzo')!;
    input.dispatchEvent(new Event('focus'));
    input.value = texto;
    input.dispatchEvent(new Event('input'));
    fixture.detectChanges();
    return input;
  };
  const agregar = (nombre: string): void => {
    buscar(nombre);
    const opcion = [...elemento().querySelectorAll('[role="option"]')].find((o) =>
      o.textContent?.includes(nombre),
    )!;
    opcion.dispatchEvent(new MouseEvent('mousedown'));
    fixture.detectChanges();
  };

  beforeEach(() => {
    usuarioActual = { rol: 'cajero', sucursalId: 1, nombre: 'Camila Rojas' };
    listarEmpleados = vi.fn(() =>
      of([
        { id: 7, nombre: 'Ana Pérez' },
        { id: 8, nombre: 'Luis Soto' },
      ]),
    );
    empleadosConAlmuerzo = vi.fn(() => of([]));
    registrar = vi.fn(() => of(31));
  });

  /** Lleva el formulario hasta la confirmación con Ana, un menú y dos bebidas. */
  const hastaConfirmacion = (): void => {
    elegir('Empleado que almuerza', '7');
    agregar('Menú del día');
    agregar('Coca-Cola 350');
    agregar('Coca-Cola 350');
    boton('Revisar almuerzo').click();
    fixture.detectChanges();
  };

  it('el cajero solo ve su sucursal y queda elegida', async () => {
    await crear();
    const opciones = elemento().querySelectorAll('select[aria-label="Sucursal del almuerzo"] option');
    expect([...opciones].map((o) => o.textContent?.trim())).toEqual([
      'Selecciona una sucursal',
      'Nury Providencia',
    ]);
    expect(
      elemento().querySelector<HTMLSelectElement>('select[aria-label="Sucursal del almuerzo"]')!
        .value,
    ).toBe('1');
  });

  it('el administrador puede elegir entre todas las sucursales', async () => {
    usuarioActual = { rol: 'admin', nombre: 'Admin' };
    await crear();
    const opciones = elemento().querySelectorAll('select[aria-label="Sucursal del almuerzo"] option');
    expect(opciones.length).toBe(3);
  });

  it('lista los empleados para elegir quién almuerza', async () => {
    await crear();
    const opciones = elemento().querySelectorAll('select[aria-label="Empleado que almuerza"] option');
    expect([...opciones].map((o) => o.textContent?.trim())).toEqual([
      'Selecciona el empleado',
      'Ana Pérez',
      'Luis Soto',
    ]);
  });

  it('agrega productos, suma cantidades y permite quitarlos', async () => {
    await crear();
    agregar('Menú del día');
    agregar('Coca-Cola 350');
    agregar('Coca-Cola 350');

    const lineas = elemento().querySelectorAll('.lunch-lines li');
    expect(lineas.length).toBe(2);
    expect(lineas[0].textContent).toContain('Descuenta ingredientes según receta');
    expect(lineas[1].textContent).toContain('Descuenta unidades del producto');
    expect(lineas[1].querySelector('.qty')?.textContent?.trim()).toBe('2');

    (lineas[1].querySelector('button[aria-label="Disminuir"]') as HTMLButtonElement).click();
    fixture.detectChanges();
    expect(elemento().querySelectorAll('.lunch-lines .qty')[1].textContent?.trim()).toBe('1');

    (elemento().querySelector('button[aria-label="Quitar Menú del día"]') as HTMLButtonElement).click();
    fixture.detectChanges();
    expect(elemento().querySelectorAll('.lunch-lines li').length).toBe(1);
  });

  it('un código de barras exacto agrega el producto con Enter', async () => {
    await crear();
    const input = buscar('7801234567890');
    input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter' }));
    fixture.detectChanges();
    expect(elemento().querySelector('.lunch-lines')?.textContent).toContain('Coca-Cola 350');
  });

  it('no avanza a la confirmación sin empleado ni productos', async () => {
    await crear();
    boton('Revisar almuerzo').click();
    fixture.detectChanges();

    expect(elemento().textContent).toContain('Selecciona el empleado.');
    expect(elemento().querySelector('.lunch-empty.invalid')).not.toBeNull();
    expect(boton('Confirmar almuerzo')).toBeUndefined();
  });

  it('muestra la confirmación sin paso de pago y permite volver', async () => {
    await crear();
    elegir('Empleado que almuerza', '7');
    agregar('Menú del día');
    boton('Revisar almuerzo').click();
    fixture.detectChanges();

    const texto = elemento().textContent ?? '';
    expect(texto).toContain('Ana Pérez');
    expect(texto).toContain('Nury Providencia');
    expect(texto).toContain('Camila Rojas');
    expect(texto).toContain('No se solicita medio de pago');
    expect(texto).not.toMatch(/efectivo|débito|crédito|transferencia/i);
    expect(elemento().querySelectorAll('.lunch-table tbody tr').length).toBe(1);

    boton('Volver').click();
    fixture.detectChanges();
    expect(elemento().querySelectorAll('.lunch-lines li').length).toBe(1);
  });

  it('al confirmar registra el almuerzo sin datos de pago (H2.13 T05)', async () => {
    await crear();
    hastaConfirmacion();
    boton('Confirmar almuerzo').click();
    fixture.detectChanges();

    expect(registrar).toHaveBeenCalledWith({
      p_sucursal_id: 1,
      p_empleado_id: 7,
      p_items: [
        { producto_id: 2, cantidad: 1 },
        { producto_id: 1, cantidad: 2 },
      ],
    });
  });

  it('informa el registro, deja el formulario listo y marca al empleado (H2.13 T05)', async () => {
    await crear();
    let avisos = 0;
    fixture.componentInstance.registrado.subscribe(() => avisos++);
    hastaConfirmacion();
    boton('Confirmar almuerzo').click();
    fixture.detectChanges();

    expect(elemento().querySelector('.success-feedback')?.textContent?.trim()).toBe(
      'Almuerzo de Ana Pérez registrado sin cobro: 3 productos descontados del stock de Nury Providencia.',
    );
    expect(avisos).toBe(1);
    expect(elemento().querySelector('.lunch-empty')).not.toBeNull();
    expect(
      elemento().querySelector<HTMLSelectElement>('select[aria-label="Empleado que almuerza"]')!
        .value,
    ).toBe('');
    const ana = [
      ...elemento().querySelectorAll<HTMLOptionElement>(
        'select[aria-label="Empleado que almuerza"] option',
      ),
    ].find((o) => o.textContent?.includes('Ana Pérez'))!;
    expect(ana.disabled).toBe(true);
  });

  it('mientras registra no permite confirmar dos veces (H2.13 T05)', async () => {
    const respuesta = new Subject<number>();
    registrar.mockReturnValue(respuesta);
    await crear();
    hastaConfirmacion();
    boton('Confirmar almuerzo').click();
    fixture.detectChanges();

    const enviando = boton('Registrando…');
    expect(enviando.disabled).toBe(true);
    expect(boton('Volver').disabled).toBe(true);
    enviando.click();
    expect(registrar).toHaveBeenCalledTimes(1);

    respuesta.next(31);
    respuesta.complete();
    fixture.detectChanges();
    expect(elemento().querySelector('.success-feedback')).not.toBeNull();
  });

  it('si la base lo rechaza muestra el motivo y conserva el almuerzo en pantalla (H2.13 T05)', async () => {
    registrar.mockReturnValue(
      throwError(
        () =>
          new HttpErrorResponse({
            status: 409,
            error: {
              code: '23505',
              message:
                'Ana Pérez ya registró su almuerzo hoy (a las 13:05 en Nury Providencia, lo registró Luis Soto). Solo se permite un almuerzo por día',
            },
          }),
      ),
    );
    await crear();
    let avisos = 0;
    fixture.componentInstance.registrado.subscribe(() => avisos++);
    hastaConfirmacion();
    boton('Confirmar almuerzo').click();
    fixture.detectChanges();

    expect(elemento().querySelector('.error-feedback')?.textContent).toContain(
      'Ana Pérez ya registró su almuerzo hoy (a las 13:05 en Nury Providencia, lo registró Luis Soto).',
    );
    expect(elemento().querySelector('.error-feedback')?.textContent).toContain('el stock no cambió');
    expect(elemento().querySelectorAll('.lunch-table tbody tr').length).toBe(2);
    expect(boton('Confirmar almuerzo').disabled).toBe(true);
    expect(avisos).toBe(0);
  });

  it('si se cae la conexión permite reintentar con los mismos datos (H2.13 T05)', async () => {
    registrar.mockReturnValueOnce(throwError(() => new HttpErrorResponse({ status: 0 })));
    await crear();
    hastaConfirmacion();
    boton('Confirmar almuerzo').click();
    fixture.detectChanges();

    expect(elemento().querySelector('.error-feedback')?.textContent).toContain(
      'no sabemos si el almuerzo alcanzó a registrarse',
    );
    boton('Confirmar almuerzo').click();
    fixture.detectChanges();
    expect(registrar).toHaveBeenCalledTimes(2);
    expect(elemento().querySelector('.success-feedback')).not.toBeNull();
  });

  it('marca a quien ya almorzó hoy y no permite elegirlo (H2.13 T04)', async () => {
    empleadosConAlmuerzo.mockReturnValue(of([8]));
    await crear();

    expect(empleadosConAlmuerzo).toHaveBeenCalledWith(fechaHoyChile());
    const opciones = [
      ...elemento().querySelectorAll<HTMLOptionElement>(
        'select[aria-label="Empleado que almuerza"] option',
      ),
    ];
    const luis = opciones.find((o) => o.textContent?.includes('Luis Soto'))!;
    const ana = opciones.find((o) => o.textContent?.includes('Ana Pérez'))!;
    expect(luis.disabled).toBe(true);
    expect(luis.textContent).toContain('ya almorzó hoy');
    expect(ana.disabled).toBe(false);
  });

  it('si el empleado ya almorzó hoy informa el motivo y no avanza (H2.13 T04)', async () => {
    empleadosConAlmuerzo.mockReturnValue(of([7]));
    await crear();
    elegir('Empleado que almuerza', '7');
    agregar('Menú del día');
    boton('Revisar almuerzo').click();
    fixture.detectChanges();

    expect(elemento().textContent).toContain(
      'Ana Pérez ya registró su almuerzo hoy. Solo se permite un almuerzo por día.',
    );
    expect(boton('Confirmar almuerzo')).toBeUndefined();
  });

  it('sin productos informa que debe haber al menos uno (H2.13 T04)', async () => {
    await crear();
    elegir('Empleado que almuerza', '7');
    boton('Revisar almuerzo').click();
    fixture.detectChanges();

    expect(elemento().textContent).toContain('El almuerzo debe tener al menos un producto.');
    expect(boton('Confirmar almuerzo')).toBeUndefined();
  });

  describe('varios empleados a la vez', () => {
    const opcionEmpleado = (nombre: string): HTMLOptionElement =>
      [
        ...elemento().querySelectorAll<HTMLOptionElement>(
          'select[aria-label="Empleado que almuerza"] option',
        ),
      ].find((o) => o.textContent?.includes(nombre))!;

    /** Ana con menú y bebida; Luis solo con el menú (se quita la bebida que quedó). */
    const armarDos = (): void => {
      elegir('Empleado que almuerza', '7');
      agregar('Menú del día');
      agregar('Coca-Cola 350');
      boton('Agregar otro empleado').click();
      fixture.detectChanges();
      elegir('Empleado que almuerza', '8');
      (elemento().querySelector('button[aria-label="Quitar Coca-Cola 350"]') as HTMLButtonElement).click();
      fixture.detectChanges();
    };

    it('agrega al empleado a la lista y mantiene los productos para el siguiente', async () => {
      await crear();
      elegir('Empleado que almuerza', '7');
      agregar('Menú del día');
      boton('Agregar otro empleado').click();
      fixture.detectChanges();

      expect(elemento().querySelector('.lunch-queue')?.textContent).toContain('Ana Pérez');
      expect(elemento().querySelector('.lunch-queue')?.textContent).toContain('1 × Menú del día');
      expect(elemento().querySelector('.list-feedback')?.textContent).toContain(
        'Ana Pérez quedó en la lista',
      );
      expect(
        elemento().querySelector<HTMLSelectElement>('select[aria-label="Empleado que almuerza"]')!
          .value,
      ).toBe('');
      expect(opcionEmpleado('Ana Pérez').disabled).toBe(true);
      expect(opcionEmpleado('Ana Pérez').textContent).toContain('en la lista');
      expect(elemento().querySelectorAll('.lunch-lines li').length).toBe(1);
    });

    it('no agrega a la lista sin empleado o sin productos', async () => {
      await crear();
      boton('Agregar otro empleado').click();
      fixture.detectChanges();

      expect(elemento().textContent).toContain('Selecciona el empleado.');
      expect(elemento().querySelector('.lunch-queue')).toBeNull();
    });

    it('registra a cada empleado con sus propios productos', async () => {
      await crear();
      let avisos = 0;
      fixture.componentInstance.registrado.subscribe(() => avisos++);
      armarDos();
      boton('Revisar 2 almuerzos').click();
      fixture.detectChanges();

      expect(elemento().querySelector('.lunch-summary')?.textContent).toContain('2 empleados');
      expect(elemento().querySelectorAll('.lunch-table tbody tr').length).toBe(3);
      boton('Confirmar 2 almuerzos').click();
      fixture.detectChanges();

      expect(registrar).toHaveBeenCalledTimes(2);
      expect(registrar).toHaveBeenNthCalledWith(1, {
        p_sucursal_id: 1,
        p_empleado_id: 7,
        p_items: [
          { producto_id: 2, cantidad: 1 },
          { producto_id: 1, cantidad: 1 },
        ],
      });
      expect(registrar).toHaveBeenNthCalledWith(2, {
        p_sucursal_id: 1,
        p_empleado_id: 8,
        p_items: [{ producto_id: 2, cantidad: 1 }],
      });
      expect(elemento().querySelector('.success-feedback')?.textContent?.trim()).toBe(
        '2 almuerzos registrados sin cobro (Ana Pérez y Luis Soto): 3 productos descontados del stock de Nury Providencia.',
      );
      expect(avisos).toBe(1);
      expect(elemento().querySelector('.lunch-queue')).toBeNull();
      expect(opcionEmpleado('Ana Pérez').textContent).toContain('ya almorzó hoy');
      expect(opcionEmpleado('Luis Soto').textContent).toContain('ya almorzó hoy');
    });

    it('si uno es rechazado registra a los demás y deja al rechazado con su motivo', async () => {
      registrar.mockImplementation((payload: { p_empleado_id: number }) =>
        payload.p_empleado_id === 8
          ? throwError(
              () =>
                new HttpErrorResponse({
                  status: 409,
                  error: { code: '23505', message: 'Luis Soto ya registró su almuerzo hoy' },
                }),
            )
          : of(31),
      );
      await crear();
      let avisos = 0;
      fixture.componentInstance.registrado.subscribe(() => avisos++);
      armarDos();
      boton('Revisar 2 almuerzos').click();
      fixture.detectChanges();
      boton('Confirmar 2 almuerzos').click();
      fixture.detectChanges();

      expect(registrar).toHaveBeenCalledTimes(2);
      expect(elemento().querySelector('.success-feedback')?.textContent).toContain(
        'Almuerzo de Ana Pérez registrado sin cobro',
      );
      expect(elemento().querySelector('.error-feedback')?.textContent).toContain(
        'Luis Soto: Luis Soto ya registró su almuerzo hoy.',
      );
      expect(avisos).toBe(1);
      // Solo queda Luis, marcado como que ya almorzó: no se puede volver a confirmar.
      const filas = elemento().querySelectorAll('.lunch-table tbody tr');
      expect(filas.length).toBe(1);
      expect(filas[0].textContent).toContain('Ya almorzó hoy');
      expect(boton('Confirmar almuerzo').disabled).toBe(true);
    });

    it('revisa la lista aunque queden productos sin empleado elegido', async () => {
      await crear();
      elegir('Empleado que almuerza', '7');
      agregar('Menú del día');
      boton('Agregar otro empleado').click();
      fixture.detectChanges();
      boton('Revisar almuerzo').click();
      fixture.detectChanges();

      expect(elemento().querySelectorAll('.lunch-table tbody tr').length).toBe(1);
      boton('Volver').click();
      fixture.detectChanges();
      expect(elemento().textContent).not.toContain('Selecciona el empleado.');
      expect(elemento().querySelector('.lunch-queue')?.textContent).toContain('Ana Pérez');
    });

    it('permite editar y quitar almuerzos de la lista', async () => {
      await crear();
      armarDos();
      boton('Agregar otro empleado').click();
      fixture.detectChanges();
      expect(elemento().querySelectorAll('.lunch-queue li').length).toBe(2);

      (elemento().querySelector('button[aria-label="Editar almuerzo de Ana Pérez"]') as HTMLButtonElement).click();
      fixture.detectChanges();
      expect(
        elemento().querySelector<HTMLSelectElement>('select[aria-label="Empleado que almuerza"]')!
          .value,
      ).toBe('7');
      expect(elemento().querySelectorAll('.lunch-lines li').length).toBe(2);
      expect(elemento().querySelectorAll('.lunch-queue li').length).toBe(1);
      // Con un empleado en edición no se puede editar otro, para no perder lo armado.
      expect(
        (elemento().querySelector('button[aria-label="Editar almuerzo de Luis Soto"]') as HTMLButtonElement)
          .disabled,
      ).toBe(true);

      (elemento().querySelector('button[aria-label="Quitar a Luis Soto de la lista"]') as HTMLButtonElement).click();
      fixture.detectChanges();
      expect(elemento().querySelector('.lunch-queue')).toBeNull();
      expect(opcionEmpleado('Luis Soto').disabled).toBe(false);
    });
  });

  it('si falla la carga muestra el error y permite reintentar', async () => {
    listarEmpleados = vi.fn(() => throwError(() => new Error('sin red')));
    await crear();
    expect(elemento().textContent).toContain('No pudimos cargar los datos');

    listarEmpleados.mockReturnValue(of([{ id: 7, nombre: 'Ana Pérez' }]));
    boton('Reintentar').click();
    fixture.detectChanges();
    expect(elemento().querySelector('select[aria-label="Empleado que almuerza"]')).not.toBeNull();
  });
});
