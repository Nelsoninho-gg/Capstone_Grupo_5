import {
  Component,
  DOCUMENT,
  DestroyRef,
  ElementRef,
  HostListener,
  OnInit,
  computed,
  effect,
  inject,
  linkedSignal,
  signal,
  viewChild,
} from '@angular/core';
import { takeUntilDestroyed, toObservable, toSignal } from '@angular/core/rxjs-interop';
import { ActivatedRoute, Router } from '@angular/router';
import {
  EMPTY,
  Subscription,
  catchError,
  distinctUntilChanged,
  exhaustMap,
  finalize,
  fromEvent,
  map,
  of,
  startWith,
  switchMap,
  timer,
} from 'rxjs';
import { VersionInventarioApi } from '../../../../core/api/stock-api.service';
import { SucursalesApiService } from '../../../../core/api/sucursales-api.service';
import { ConexionService } from '../../../../core/services/conexion.service';
import { AuthService } from '../../../auth/services/auth.service';
import {
  AjusteInventario,
  PreseleccionAjuste,
} from '../../components/ajuste-inventario/ajuste-inventario';
import { AlmuerzoEmpleados } from '../../components/almuerzo-empleados/almuerzo-empleados';
import { ConsultaAlmuerzos } from '../../components/consulta-almuerzos/consulta-almuerzos';
import { ListaCompras } from '../../components/lista-compras/lista-compras';
import { PanelPredictivo } from '../../components/panel-predictivo/panel-predictivo';
import { ArticuloPredictivo, contarPredicciones } from '../../models/prediccion.model';
import { PrediccionStockService } from '../../services/prediccion-stock.service';
import { ReporteMermas } from '../../components/reporte-mermas/reporte-mermas';
import { MovimientosArticulo } from '../../components/movimientos-articulo/movimientos-articulo';
import { ArticuloMovimientos } from '../../models/movimientos.model';
import {
  CRITERIOS_SIN_FILTRO,
  ConteoEstados,
  CriteriosExistencias,
  EstadoStock,
  ExistenciaStock,
  FiltroEstado,
  FiltroTipo,
  TipoArticulo,
  calcularEstadoStock,
  contarEstados,
  faltanteParaMinimo,
  filtrarExistencias,
  tieneDescuadre,
  validarMinimo,
  valorizarExistencias,
} from '../../models/inventario.model';
import { interpretarFalloMinimo } from '../../models/fallo-minimo';
import { InventarioService, sucursalesAutorizadas } from '../../services/inventario.service';

type EstadoCarga = 'cargando' | 'listo' | 'error';
type EstadoConexion = 'en-linea' | 'desconectado';
/** Tras reconectar: "pendiente" es que la nueva consulta falló y siguen los datos anteriores. */
type EstadoSincronizacion = 'al-dia' | 'actualizando' | 'pendiente';
type Vista = 'existencias' | 'compras' | 'mermas' | 'predicciones' | 'almuerzos';

/**
 * Cada cuánto el panel pregunta si el inventario cambió (H3.2 T06: los cambios confirmados
 * deben verse en 2 segundos o menos, sin recargar).
 */
export const INTERVALO_REVISION_MS = 2000;
const VISTAS: readonly Vista[] = ['existencias', 'compras', 'mermas', 'predicciones', 'almuerzos'];

/**
 * Pestaña pedida en la URL (?vista=compras o ?vista=mermas); cualquier otro valor abre Existencias. El antiguo
 * ?vista=catalogo también: los ingredientes pasaron al Maestro de Productos.
 */
export function vistaDesdeUrl(valor: string | null | undefined): Vista {
  return VISTAS.find((vista) => vista === valor) ?? 'existencias';
}
type FiltroAplicado = 'texto' | 'estado' | 'tipo' | 'sucursal';

const TODAS_LAS_SUCURSALES = 'todas';

const ETIQUETAS_ESTADO: Record<EstadoStock, string> = {
  agotado: 'Agotado',
  critico: 'Crítico',
  estable: 'Estable',
};

const OPCIONES_ESTADO: { valor: Exclude<FiltroEstado, 'todos'>; etiqueta: string }[] = [
  { valor: 'alertas', etiqueta: 'Con alerta' },
  { valor: 'agotado', etiqueta: 'Agotados' },
  { valor: 'descuadre', etiqueta: 'Con descuadre' },
  { valor: 'critico', etiqueta: 'Críticos' },
  { valor: 'estable', etiqueta: 'Estables' },
];

const OPCIONES_TIPO: { valor: TipoArticulo; etiqueta: string }[] = [
  { valor: 'producto', etiqueta: 'Productos' },
  { valor: 'materia_prima', etiqueta: 'Materias primas' },
];

const formatoCantidad = new Intl.NumberFormat('es-CL', { maximumFractionDigits: 3 });
const formatoHora = new Intl.DateTimeFormat('es-CL', {
  hour: '2-digit',
  minute: '2-digit',
  hourCycle: 'h23',
});

/**
 * Panel principal de Inventario (H3.4) con estados y mínimos de stock (H3.5)
 * y descuentos manuales con su reporte de mermas (H3.6).
 * La pestaña de almuerzos registra el consumo interno de empleados sin cobro (H2.13).
 * Si se pierde la conexión avisa que los datos pueden estar desactualizados y, al
 * reconectar, vuelve a consultar las existencias (H3.4 T07).
 * Las existencias son reales (H3.4 T03) y el mínimo (H3.5 T05) y el ajuste guardan en la
 * base. El tiempo real (H3.4 T06) se conecta sobre estos mismos estados.
 */
@Component({
  selector: 'app-inventario',
  imports: [
    AjusteInventario,
    ListaCompras,
    PanelPredictivo,
    ReporteMermas,
    AlmuerzoEmpleados,
    ConsultaAlmuerzos,
    MovimientosArticulo,
  ],
  templateUrl: './inventario.html',
  styleUrls: ['../../styles/inventario-base.css', './inventario.css'],
})
export class Inventario implements OnInit {
  private readonly inventarioService = inject(InventarioService);
  private readonly conexionService = inject(ConexionService);
  private readonly authService = inject(AuthService);
  private readonly prediccionService = inject(PrediccionStockService);
  private readonly ruta = inject(ActivatedRoute, { optional: true });
  private readonly router = inject(Router);
  private consultaEnCurso?: Subscription;
  /** Última versión del inventario vista por la revisión periódica (H3.2 T06). */
  private ultimaVersion: VersionInventarioApi | null = null;

  /** El cajero ve el inventario de su sucursal, pero no el sugerido de compra («Por comprar»). */
  protected readonly esCajero = computed(() => this.authService.currentUser()?.rol === 'cajero');

  /** H4.5 T09: Solo el administrador puede ver la pestaña y alertas de sugerencias de compra. */
  protected readonly esAdmin = computed(() => this.authService.currentUser()?.rol === 'admin');

  protected readonly sinSucursalAsignada = computed(
    () => sucursalesAutorizadas(this.authService.currentUser()) === 'ninguna',
  );

  /** Qué sucursales consulta el usuario (H3.4 T08): todas para el admin, la suya para el resto. */
  protected readonly alcanceConsulta = computed(() => {
    const usuario = this.authService.currentUser();
    const alcance = sucursalesAutorizadas(usuario);
    if (alcance === null) return 'en todas las sucursales';
    if (alcance === 'ninguna') return 'de tu sucursal';
    return `de ${usuario?.sucursalNombre || 'tu sucursal'}`;
  });

  protected readonly existencias = signal<ExistenciaStock[]>([]);
  protected readonly estado = signal<EstadoCarga>('cargando');
  protected readonly conexion = computed<EstadoConexion>(() =>
    this.conexionService.enLinea() ? 'en-linea' : 'desconectado',
  );
  protected readonly sincronizacion = signal<EstadoSincronizacion>('al-dia');
  /** Los últimos datos siguen visibles, pero atenuados, mientras no estén confirmados. */
  protected readonly datosDesactualizados = computed(
    () => this.conexion() === 'desconectado' || this.sincronizacion() !== 'al-dia',
  );
  protected readonly textoConexion = computed(() => {
    if (this.conexion() === 'desconectado') return 'Sin conexión';
    if (this.sincronizacion() === 'actualizando') return 'Actualizando...';
    return this.sincronizacion() === 'pendiente' ? 'Datos sin actualizar' : 'En línea';
  });
  protected readonly ultimaActualizacion = signal<Date | null>(null);

  protected readonly busqueda = signal('');
  protected readonly filtroTipo = signal<FiltroTipo>('todos');
  protected readonly filtroSucursal = signal(TODAS_LAS_SUCURSALES);
  protected readonly filtroEstado = signal<FiltroEstado>('todos');

  protected readonly existenciaEnEdicion = signal<ExistenciaStock | null>(null);
  protected readonly minimoTexto = signal('');
  protected readonly minimoTocado = signal(false);
  protected readonly guardandoMinimo = signal(false);
  protected readonly errorEdicion = signal<string | null>(null);
  protected readonly mensajeExito = signal<string | null>(null);

  /**
   * La pestaña viaja en la URL para que al recargar se mantenga la pestaña elegida.
   */
  protected readonly vista = signal<Vista>(
    vistaDesdeUrl(this.ruta?.snapshot.queryParamMap.get('vista')),
  );
  protected readonly ajusteAbierto = signal(false);
  /** Artículo y sucursal cuyo historial de movimientos está abierto (H3.2 T01). */
  protected readonly movimientosDe = signal<ArticuloMovimientos | null>(null);
  /** Artículo elegido desde una fila; null cuando el ajuste se abre desde el botón general. */
  protected readonly existenciaParaAjuste = signal<ExistenciaStock | null>(null);
  /** Aumenta con cada ajuste confirmado o reconexión para que el reporte de mermas vuelva a consultar. */
  protected readonly versionMermas = signal(0);
  /** Aumenta cuando cambia el stock, un mínimo o hay movimientos: la lista de compras se recalcula. */
  protected readonly versionCompras = signal(0);
  /** Cambia con cada almuerzo registrado para refrescar la consulta del administrador (H2.13 T07). */
  protected readonly versionAlmuerzos = signal(0);

  /** Sucursales activas que el usuario puede ver, aunque todavía no tengan stock registrado. */
  private readonly sucursalesActivas = toSignal(
    inject(SucursalesApiService)
      .listarActivas()
      .pipe(catchError(() => of([]))),
    { initialValue: [] },
  );

  protected readonly sucursales = computed(() => {
    const alcance = sucursalesAutorizadas(this.authService.currentUser());
    const porId = new Map<number, string>();
    for (const sucursal of this.sucursalesActivas()) {
      if (alcance === null || sucursal.id === alcance) porId.set(sucursal.id, sucursal.nombre);
    }
    // También las que tienen stock aunque estén inactivas, para no esconder su historial.
    for (const existencia of this.existencias()) {
      porId.set(existencia.sucursalId, existencia.sucursal);
    }
    return [...porId]
      .map(([id, nombre]) => ({ id, nombre }))
      .sort((a, b) => a.nombre.localeCompare(b.nombre, 'es'));
  });

  /** Sucursal elegida en el filtro, para abrir el ajuste y el reporte en el mismo contexto. */
  protected readonly sucursalSeleccionadaId = computed(() => {
    const sucursal = this.filtroSucursal();
    return sucursal === TODAS_LAS_SUCURSALES ? null : Number(sucursal);
  });

  /** Solo admin ve sugerencias de compra; a los demás roles no se les pide nada. */
  private readonly articulosPredictivos = toSignal(
    toObservable(this.sucursalSeleccionadaId).pipe(
      switchMap((sucursalId) =>
        this.esAdmin()
          ? this.prediccionService.cargarArticulos(sucursalId)
          : of<ArticuloPredictivo[]>([]),
      ),
    ),
    { initialValue: [] as ArticuloPredictivo[] },
  );

  protected readonly conteoPredictivo = computed(() =>
    contarPredicciones(this.articulosPredictivos()),
  );

  protected readonly totalComprarHoyPredictivo = computed(
    () => this.conteoPredictivo()['comprar-hoy'],
  );

  protected readonly alertaCompraPredictiva = computed(
    () => this.esAdmin() && this.totalComprarHoyPredictivo() > 0,
  );

  private readonly criterios = computed<CriteriosExistencias>(() => ({
    texto: this.busqueda(),
    tipo: this.filtroTipo(),
    estado: this.filtroEstado(),
    sucursalId: this.sucursalSeleccionadaId(),
  }));

  protected readonly existenciasFiltradas = computed(() =>
    filtrarExistencias(this.existencias(), this.criterios()),
  );

  /** La tabla muestra 10 filas por página, como el maestro de productos. */
  protected readonly tamanoPagina = 10;
  /**
   * Vuelve a la página 1 al cambiar un filtro, pero no con la recarga automática de las
   * existencias (cada pocos segundos), para no sacar al usuario de la página que mira.
   */
  protected readonly paginaElegida = linkedSignal({
    source: this.criterios,
    computation: () => 1,
  });
  protected readonly totalPaginas = computed(() =>
    Math.max(1, Math.ceil(this.existenciasFiltradas().length / this.tamanoPagina)),
  );
  /** Si una recarga deja menos filas, la página elegida se ajusta a la última que existe. */
  protected readonly paginaActual = computed(() =>
    Math.min(this.paginaElegida(), this.totalPaginas()),
  );
  protected readonly existenciasPagina = computed(() => {
    const inicio = (this.paginaActual() - 1) * this.tamanoPagina;
    return this.existenciasFiltradas().slice(inicio, inicio + this.tamanoPagina);
  });

  protected cambiarPagina(desplazamiento: number): void {
    this.paginaElegida.set(
      Math.max(1, Math.min(this.paginaActual() + desplazamiento, this.totalPaginas())),
    );
  }

  /**
   * Las alertas corresponden a la sucursal consultada y no dependen del tipo ni de la
   * búsqueda: filtrar no debe esconder que hay artículos agotados.
   */
  private readonly resumenSucursal = computed(() =>
    contarEstados(
      filtrarExistencias(this.existencias(), {
        ...CRITERIOS_SIN_FILTRO,
        sucursalId: this.sucursalSeleccionadaId(),
      }),
    ),
  );

  /** Inventario valorizado a costo de la sucursal elegida (o de todas); solo lo ve el admin. */
  protected readonly valorizado = computed(() =>
    valorizarExistencias(
      filtrarExistencias(this.existencias(), {
        ...CRITERIOS_SIN_FILTRO,
        sucursalId: this.sucursalSeleccionadaId(),
      }),
    ),
  );

  protected formatearClp(valor: number): string {
    return new Intl.NumberFormat('es-CL', {
      style: 'currency',
      currency: 'CLP',
      maximumFractionDigits: 0,
    }).format(valor);
  }

  /**
   * Cada filtro cuenta con los demás aplicados: las tarjetas y las opciones anticipan
   * cuántos registros quedan al elegirlas.
   */
  protected readonly conteoPorEstado = computed(() =>
    contarEstados(filtrarExistencias(this.existencias(), { ...this.criterios(), estado: 'todos' })),
  );

  protected readonly conteoPorTipo = computed(() => {
    const conteo: Record<FiltroTipo, number> = { todos: 0, producto: 0, materia_prima: 0 };
    const criterios = { ...this.criterios(), tipo: 'todos' as const };
    for (const existencia of filtrarExistencias(this.existencias(), criterios)) {
      conteo.todos++;
      conteo[existencia.tipo]++;
    }
    return conteo;
  });

  protected readonly opcionesEstado = OPCIONES_ESTADO;
  protected readonly opcionesTipo = OPCIONES_TIPO;

  protected readonly tarjetasEstado: { estado: EstadoStock; etiqueta: string; icono: string }[] = [
    { estado: 'agotado', etiqueta: 'Agotados', icono: '✕' },
    { estado: 'critico', etiqueta: 'Críticos', icono: '!' },
    { estado: 'estable', etiqueta: 'Estables', icono: '✓' },
  ];

  protected readonly totalAlertas = computed(() => this.resumenSucursal().alertas);

  /** El aviso toma el color del caso más grave: rojo si hay agotados, ámbar si solo hay críticos. */
  protected readonly gravedadAlerta = computed<EstadoStock>(() =>
    this.resumenSucursal().agotado ? 'agotado' : 'critico',
  );

  protected readonly textoAlertas = computed(() => {
    const { agotado, critico } = this.resumenSucursal();
    const partes = [
      agotado ? `${agotado} ${agotado === 1 ? 'artículo agotado' : 'artículos agotados'}` : '',
      critico ? `${critico} en estado crítico` : '',
    ].filter(Boolean);
    const sucursal = this.sucursales().find((s) => s.id === this.sucursalSeleccionadaId());
    return `${partes.join(' y ')}${sucursal ? ` en ${sucursal.nombre}` : ''}.`;
  });

  protected readonly textoDescuadres = computed(() => {
    const total = this.resumenSucursal().descuadre;
    if (!total) return null;
    // La explicación larga va en el title del aviso, para no recargarlo.
    return `${total} ${total === 1 ? 'artículo' : 'artículos'} con stock negativo`;
  });

  /** Filtros en uso, en el orden de la barra, para mostrarlos y quitarlos de a uno. */
  protected readonly filtrosAplicados = computed(() => {
    const aplicados: { filtro: FiltroAplicado; etiqueta: string }[] = [];
    const texto = this.busqueda().trim();
    if (texto) aplicados.push({ filtro: 'texto', etiqueta: `“${texto}”` });
    const estado = OPCIONES_ESTADO.find((opcion) => opcion.valor === this.filtroEstado());
    if (estado) aplicados.push({ filtro: 'estado', etiqueta: estado.etiqueta });
    const tipo = OPCIONES_TIPO.find((opcion) => opcion.valor === this.filtroTipo());
    if (tipo) aplicados.push({ filtro: 'tipo', etiqueta: tipo.etiqueta });
    const sucursal = this.sucursales().find((s) => s.id === this.sucursalSeleccionadaId());
    if (sucursal) aplicados.push({ filtro: 'sucursal', etiqueta: sucursal.nombre });
    return aplicados;
  });

  protected readonly validacionMinimo = computed(() =>
    validarMinimo(this.minimoTexto(), this.existenciaEnEdicion()?.tipo ?? 'materia_prima'),
  );

  /** El error se muestra recién al salir del campo o al intentar guardar. */
  protected readonly errorMinimoVisible = computed(() => {
    const validacion = this.validacionMinimo();
    return this.minimoTocado() && 'error' in validacion ? validacion.error : null;
  });

  /** Cómo quedaría el artículo con el mínimo que se está escribiendo. */
  protected readonly estadoConNuevoMinimo = computed(() => {
    const existencia = this.existenciaEnEdicion();
    const validacion = this.validacionMinimo();
    return existencia && 'valor' in validacion
      ? calcularEstadoStock(existencia.cantidad, validacion.valor)
      : null;
  });

  private readonly minimoInput = viewChild<ElementRef<HTMLInputElement>>('minimoInput');

  constructor() {
    // Al abrir el modal, el valor queda seleccionado para escribir el nuevo mínimo de inmediato.
    effect(() => this.minimoInput()?.nativeElement.select());

    this.conexionService.alReconectar
      .pipe(takeUntilDestroyed())
      .subscribe(() => this.recuperarAlReconectar());

    // H3.2 T06: mientras la pestaña está visible, cada 2 s se pregunta una versión liviana del
    // inventario y solo si cambió se recargan las existencias (con sus estados y alertas).
    // Oculta, no consulta; al volver a verla revisa de inmediato.
    const documento = inject(DOCUMENT);
    fromEvent(documento, 'visibilitychange')
      .pipe(
        startWith(null),
        map(() => documento.visibilityState !== 'hidden'),
        distinctUntilChanged(),
        switchMap((visible) => (visible ? timer(0, INTERVALO_REVISION_MS) : EMPTY)),
        exhaustMap(() =>
          this.inventarioService.versionInventario().pipe(catchError(() => of(null))),
        ),
        takeUntilDestroyed(),
      )
      .subscribe((version) => this.alRecibirVersion(version));
    inject(DestroyRef).onDestroy(() => this.consultaEnCurso?.unsubscribe());
  }

  ngOnInit(): void {
    if (!this.puedeVer(this.vista())) {
      this.cambiarVista('existencias');
    }
    this.cargarExistencias();
  }

  protected abrirMovimientos(existencia: ExistenciaStock): void {
    this.movimientosDe.set({
      tipo: existencia.tipo,
      id: existencia.articuloId,
      nombre: existencia.articulo,
      unidad: existencia.unidad,
      sucursalId: existencia.sucursalId,
      sucursal: existencia.sucursal,
    });
  }

  /** Sugerencias de compra: solo admin. Por comprar: todos menos el cajero. */
  private puedeVer(vista: Vista): boolean {
    if (vista === 'predicciones') return this.esAdmin();
    if (vista === 'compras') return !this.esCajero();
    return true;
  }

  protected cambiarVista(vista: Vista): void {
    if (!this.puedeVer(vista)) {
      return;
    }
    this.vista.set(vista);
    if (!this.ruta) return;
    void this.router.navigate([], {
      relativeTo: this.ruta,
      queryParams: { vista: vista === 'existencias' ? null : vista },
      queryParamsHandling: 'merge',
      replaceUrl: true,
    });
  }

  protected cargarExistencias(): void {
    this.estado.set('cargando');
    this.sincronizacion.set('al-dia');
    this.consultarExistencias(() => this.estado.set('error'));
  }

  /** El almuerzo descontó stock (H2.13 T05): las existencias se actualizan para verlo al volver. */
  protected alRegistrarAlmuerzo(): void {
    this.versionAlmuerzos.update((version) => version + 1);
    this.versionCompras.update((version) => version + 1);
    if (this.estado() === 'listo') {
      this.actualizarExistencias();
    } else {
      this.cargarExistencias();
    }
  }

  /** Vuelve a consultar sin ocultar los últimos datos recibidos. */
  protected actualizarExistencias(): void {
    this.sincronizacion.set('actualizando');
    this.consultarExistencias(() => this.sincronizacion.set('pendiente'));
  }

  /** Una consulta nueva reemplaza a la anterior para que una respuesta vieja no pise a la nueva. */
  private consultarExistencias(alFallar: () => void): void {
    this.consultaEnCurso?.unsubscribe();
    this.consultaEnCurso = this.inventarioService.listarExistencias().subscribe({
      next: (existencias) => {
        this.existencias.set(existencias);
        this.ultimaActualizacion.set(new Date());
        this.estado.set('listo');
        this.sincronizacion.set('al-dia');
      },
      error: alFallar,
    });
  }

  /**
   * Compara con la versión anterior: si cambió el stock o un mínimo, recarga las existencias
   * sin ocultar los datos; si hay movimientos nuevos, también el reporte de mermas. La primera
   * versión solo queda como referencia (las existencias se acaban de cargar).
   */
  private alRecibirVersion(version: VersionInventarioApi | null): void {
    if (!version) return; // sin conexión: lo informa ConexionService y se recupera al volver
    const anterior = this.ultimaVersion;
    this.ultimaVersion = version;
    if (!anterior) return;
    if (version.stock !== anterior.stock || version.movimientos !== anterior.movimientos) {
      this.versionCompras.update((numero) => numero + 1);
    }
    if (version.stock !== anterior.stock && this.estado() === 'listo') {
      this.actualizarExistencias();
    }
    if (version.movimientos !== anterior.movimientos) {
      this.versionMermas.update((numero) => numero + 1);
    }
  }

  /** Lo ocurrido durante el corte no llegó: se consultan de nuevo existencias y mermas. */
  private recuperarAlReconectar(): void {
    this.versionMermas.update((version) => version + 1);
    this.versionCompras.update((version) => version + 1);
    if (this.estado() === 'listo') {
      this.actualizarExistencias();
    } else {
      this.cargarExistencias();
    }
  }

  protected estadoDe(existencia: ExistenciaStock): EstadoStock {
    return calcularEstadoStock(existencia.cantidad, existencia.stockMinimo);
  }

  protected esDescuadre(existencia: ExistenciaStock): boolean {
    return tieneDescuadre(existencia);
  }

  /** Solo los artículos con alerta muestran cuánto falta para llegar al mínimo. */
  protected textoFaltante(existencia: ExistenciaStock): string | null {
    const faltante = faltanteParaMinimo(existencia);
    // Con mínimo 0 el faltante solo repetiría el stock negativo, que ya marca el descuadre.
    if (this.estadoDe(existencia) === 'estable' || !existencia.stockMinimo || !faltante) {
      return null;
    }
    return `Faltan ${this.formatearCantidad(faltante)} ${existencia.unidad} para el mínimo`;
  }

  protected conteoDeEstado(conteo: ConteoEstados, filtro: FiltroEstado): number {
    return filtro === 'todos' ? conteo.total : conteo[filtro];
  }

  protected etiquetaEstado(estado: EstadoStock): string {
    return ETIQUETAS_ESTADO[estado];
  }

  protected actualizarBusqueda(event: Event): void {
    this.busqueda.set((event.target as HTMLInputElement).value);
  }

  protected actualizarFiltroTipo(event: Event): void {
    this.filtroTipo.set((event.target as HTMLSelectElement).value as FiltroTipo);
  }

  protected actualizarFiltroSucursal(event: Event): void {
    this.filtroSucursal.set((event.target as HTMLSelectElement).value);
  }

  protected actualizarFiltroEstado(event: Event): void {
    this.filtroEstado.set((event.target as HTMLSelectElement).value as FiltroEstado);
  }

  /** Las tarjetas del resumen funcionan como acceso rápido al filtro de estado. */
  protected alternarFiltroEstado(estado: FiltroEstado): void {
    this.filtroEstado.update((actual) => (actual === estado ? 'todos' : estado));
  }

  /**
   * El aviso cuenta las alertas de toda la sucursal, así que al pedir verlas se quitan el
   * tipo y la búsqueda: la lista muestra exactamente los artículos que el aviso anunció.
   */
  protected verDesdeAviso(estado: 'alertas' | 'descuadre'): void {
    this.busqueda.set('');
    this.filtroTipo.set('todos');
    this.filtroEstado.set(estado);
  }

  /** El acceso del aviso solo se oculta cuando la lista ya muestra todo lo que anuncia. */
  protected mostrandoDesdeAviso(estado: 'alertas' | 'descuadre'): boolean {
    return (
      this.filtroEstado() === estado && this.filtroTipo() === 'todos' && !this.busqueda().trim()
    );
  }

  protected quitarFiltro(filtro: FiltroAplicado): void {
    switch (filtro) {
      case 'texto':
        this.busqueda.set('');
        break;
      case 'estado':
        this.filtroEstado.set('todos');
        break;
      case 'tipo':
        this.filtroTipo.set('todos');
        break;
      case 'sucursal':
        this.filtroSucursal.set(TODAS_LAS_SUCURSALES);
        break;
    }
  }

  protected limpiarFiltros(): void {
    this.busqueda.set('');
    this.filtroTipo.set('todos');
    this.filtroSucursal.set(TODAS_LAS_SUCURSALES);
    this.filtroEstado.set('todos');
  }

  protected abrirEdicionMinimo(existencia: ExistenciaStock): void {
    this.existenciaEnEdicion.set(existencia);
    this.minimoTexto.set(String(existencia.stockMinimo).replace('.', ','));
    this.minimoTocado.set(false);
    this.errorEdicion.set(null);
    this.mensajeExito.set(null);
  }

  @HostListener('document:keydown.escape')
  protected cerrarEdicionMinimo(): void {
    if (this.guardandoMinimo()) return;
    this.existenciaEnEdicion.set(null);
  }

  protected actualizarMinimoTexto(event: Event): void {
    this.minimoTexto.set((event.target as HTMLInputElement).value);
  }

  protected guardarMinimo(): void {
    const existencia = this.existenciaEnEdicion();
    const validacion = this.validacionMinimo();
    this.minimoTocado.set(true);
    if (!existencia || this.guardandoMinimo() || !('valor' in validacion)) return;

    this.errorEdicion.set(null);
    this.guardandoMinimo.set(true);
    this.inventarioService
      .actualizarMinimo(existencia, validacion.valor)
      .pipe(finalize(() => this.guardandoMinimo.set(false)))
      .subscribe({
        next: (actualizada) => {
          this.existencias.update((existencias) =>
            existencias.map((actual) => (actual.id === actualizada.id ? actualizada : actual)),
          );
          this.mensajeExito.set(
            `Mínimo de ${actualizada.articulo} en ${actualizada.sucursal} actualizado a ` +
              `${this.formatearCantidad(actualizada.stockMinimo)} ${actualizada.unidad}.`,
          );
          this.existenciaEnEdicion.set(null);
        },
        error: (error: unknown) => {
          const fallo = interpretarFalloMinimo(error);
          this.errorEdicion.set(fallo.mensaje);
          if (fallo.actualizarStock) this.actualizarExistencias();
        },
      });
  }

  protected abrirAjuste(existencia: ExistenciaStock | null = null): void {
    this.existenciaParaAjuste.set(existencia);
    this.mensajeExito.set(null);
    this.ajusteAbierto.set(true);
  }

  protected cerrarAjuste(): void {
    this.ajusteAbierto.set(false);
  }

  /**
   * Datos con los que se abre el ajuste real: desde una fila, el artículo y su sucursal;
   * desde el botón general, la sucursal elegida en el filtro del panel.
   */
  protected readonly preseleccionAjuste = computed<PreseleccionAjuste>(() => {
    const existencia = this.existenciaParaAjuste();
    if (existencia) {
      return {
        tipo: existencia.tipo === 'producto' ? 'producto' : 'ingrediente',
        sucursalId: existencia.sucursalId,
        nombre: existencia.articulo,
      };
    }
    return { tipo: 'producto', sucursalId: this.sucursalSeleccionadaId(), nombre: null };
  });

  /** El ajuste ya quedó en la base: se informa y se vuelven a consultar existencias y mermas. */
  protected registrarAjuste(mensaje: string): void {
    this.ajusteAbierto.set(false);
    this.mensajeExito.set(mensaje);
    this.versionMermas.update((version) => version + 1);
    this.versionCompras.update((version) => version + 1);
    this.actualizarExistencias();
  }

  protected etiquetaTipo(tipo: TipoArticulo): string {
    return tipo === 'producto' ? 'Producto' : 'Materia prima';
  }

  protected formatearCantidad(cantidad: number): string {
    return formatoCantidad.format(cantidad);
  }

  protected formatearHora(fecha: Date): string {
    return formatoHora.format(fecha);
  }
}
