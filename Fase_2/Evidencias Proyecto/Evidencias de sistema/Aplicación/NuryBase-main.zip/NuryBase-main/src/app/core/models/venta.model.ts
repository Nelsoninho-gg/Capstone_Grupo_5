import { MedioPago, TipoPromocion, TipoVenta } from './comun.model';
import { Sucursal } from './sucursal.model';
import { Usuario } from './usuario.model';
import { Producto } from './producto.model';

/**
 * Promoción programada (H5.2). Rige sola entre `inicio` (incluido) y `termino` (no incluido),
 * en una sucursal o en todas. Tabla `promociones`.
 */
export interface Promocion {
    id: number;
    nombre: string;
    tipo: TipoPromocion;
    /** Porcentaje (hasta 100) o monto en pesos; siempre mayor que 0. */
    valor_descuento: number;
    /** null = todas las sucursales. */
    sucursal_id: number | null;
    inicio: string | Date;
    termino: string | Date;
    prioridad: number;
    combinable_con_otras: boolean;
    activa: boolean;
    creado_por?: number | null;
    creado_en?: string | Date;

    // Relaciones opcionales
    sucursal?: Sucursal | null;
    productos?: PromocionProducto[];
}

/** Producto que forma la promoción, con sus unidades (ej. 1 sándwich + 1 café). */
export interface PromocionProducto {
    promocion_id: number;
    producto_id: number;
    /** Entero mayor que 0. */
    cantidad: number;

    // Relaciones opcionales
    producto?: Producto;
}

export interface AlertaMargen {
    id: number;
    promocion_id?: number | null;
    producto_id: number;
    costo_receta: number;
    precio_aplicado: number;
    venta_id?: number | null;
    creado_en?: string | Date;

    // Relaciones opcionales
    promocion?: Promocion | null;
    producto?: Producto;
}

export interface Venta {
    id: number;
    sucursal_id: number;
    cajero_id?: number | null;
    fecha_venta: string | Date;
    medio_pago?: MedioPago | string | null;
    total: number;
    anulada: boolean;
    anulada_en?: string | Date | null;
    anulada_por?: number | null;
    anulada_motivo?: string | null;
    tipo_venta: TipoVenta;
    empleado_id?: number | null;
    descuento_porcentaje: number;
    descuento_monto: number;
    codigo_venta: string;
    /** true en ventas a empleado (con descuento). Calculada por la base. */
    venta_especial: boolean;
    creado_en?: string | Date;

    // Relaciones opcionales
    sucursal?: Sucursal;
    cajero?: Usuario | null;
    empleado?: Usuario | null;
    detalles?: DetalleVenta[];
}

export interface DetalleVenta {
    id: number;
    venta_id: number;
    producto_id: number;
    /** Promoción aplicada a la línea (H5.2). */
    promocion_id?: number | null;
    cantidad: number;
    /** Precio original del producto al vender. */
    precio_lista: number;
    /** Precio final cobrado por unidad. */
    precio_unitario: number;
    subtotal?: number;
    /** Descuento por unidad de la promoción (precio_lista − precio_unitario); 0 sin promoción (H5.2 T07). */
    descuento_unitario?: number;
    /** Costo por unidad al vender (receta o último costo de compra); null si no hay costo (H5.2 T07). */
    costo_unitario?: number | null;
    /** Margen que se dejó de ganar por la promoción: descuento_unitario × cantidad (H5.2 T07). */
    margen_sacrificado?: number;

    // Relaciones opcionales
    producto?: Producto;
    promocion?: Promocion | null;
}
