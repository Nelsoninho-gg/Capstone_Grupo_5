import { describe, expect, it } from 'vitest';
import { TASA_IVA, desglosarIva, netoSinIva } from './iva';

describe('IVA incluido en el total', () => {
  it('el IVA es el 19% del neto, no del total', () => {
    expect(TASA_IVA).toBe(0.19);
    expect(Math.round(netoSinIva(1800))).toBe(1513);
    // El neto más su 19% vuelve al total.
    expect(Math.round(netoSinIva(1800) * 1.19)).toBe(1800);
  });

  it('desglosa un total en neto e IVA que suman exactamente el total', () => {
    expect(desglosarIva(1800)).toEqual({ neto: 1513, iva: 287 });
    expect(desglosarIva(1190)).toEqual({ neto: 1000, iva: 190 });
    expect(desglosarIva(1440)).toEqual({ neto: 1210, iva: 230 });
    expect(desglosarIva(0)).toEqual({ neto: 0, iva: 0 });
    for (const total of [1, 99, 2600, 14300, 929120]) {
      const { neto, iva } = desglosarIva(total);
      expect(neto + iva).toBe(total);
    }
  });
});
