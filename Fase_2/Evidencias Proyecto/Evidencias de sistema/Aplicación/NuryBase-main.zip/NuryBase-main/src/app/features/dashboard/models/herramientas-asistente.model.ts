import { formatearFechaChile } from '../../inventario/models/prediccion-ia.contract';
import { parsearFechaServidor } from '../../../shared/utils/fecha-servidor';
import { PROPORCION_NETA, costoUnitario } from './dashboard.model';

/** Cálculos del chat: la IA elige la herramienta e interpreta, pero nunca hace estas cuentas. */

export interface LlamadaHerramienta {
  nombre: string;
  parametros?: Record<string, unknown>;
}

export interface ResultadoHerramienta {
  herramienta: string;
  parametros?: Record<string, unknown>;
  datos?: unknown;
  error?: string;
}

export interface AgregacionFilas {
  suma?: string[];
  promedio?: string[];
  contar?: boolean;
  agrupar_por?: string;
}

export const DESCRIPCION_HERRAMIENTAS = `- margen_producto: margen de ganancia de un producto. Parámetros: nombre (texto, busca coincidencias) o producto_id.
- ventas_periodo: total vendido, cantidad de ventas, ticket promedio, anuladas, ventas a clientes y a empleados, y por medio de pago con cantidad y monto. Si cantidad_ventas de un medio viene null, no se pudo calcular: no la afirmes. Parámetros: desde y hasta (YYYY-MM-DD, ambos incluidos), sucursal_ids (lista opcional; sin ella, toda la red).
- auditoria_usuarios: historial de cambios de rol y de estado activo de los usuarios, con su nombre, del más reciente al más antiguo. Parámetros: usuario (texto, opcional), campo ("rol" o "activo", opcional), limite.
- stock_articulo: stock actual y mínimo de un artículo, con una fila por cada sucursal donde está registrado. Nombra todas las sucursales que vengan; si viene una sola, el artículo solo está registrado ahí. Parámetros: nombre (texto, busca coincidencias), sucursal_id (opcional).
- receta_producto: ingredientes, cantidades y costo de la receta de un producto. Parámetros: nombre (texto, busca coincidencias) o producto_id.
- ranking_productos: productos con unidades, monto y ganancia (sí incluye ventas a empleados). Parámetros: desde, hasta, sucursal_ids (opcional), orden ("unidades", "monto", "ganancia" o "menos_vendidos"), limite.
- ranking_cajeros: turnos, ventas y total por cajero, de mayor a menor. Parámetros: desde, hasta, sucursal_ids (opcional).
- analisis_dashboard: totales, cierre estimado, variación, familias, horarios, ventas por día de la semana (lunes a domingo, con el día de mayor venta) y productos comprados juntos con soporte, confianza y lift. Los totales y la ganancia (kpis) sí incluyen ventas a empleados; productos, familias, combos, horarios y días de la semana no cuentan ventas a empleados. Con periodo "1d" entrega lo vendido hoy y proyeccion con el estado del cierre. Parámetros: periodo ("1d" hoy, con proyección de cierre basada en días anteriores del mismo día de la semana; "7d" semana actual; "30d" mes actual; "90d" trimestre actual), sucursal_id (opcional). Si el estado de proyeccion no es "disponible", todavía no se puede proyectar: dilo con su mensaje y no inventes una cifra de cierre.
- prediccion_stock: consumo diario depurado de atípicos, cobertura, estado y compra sugerida. Parámetros: sucursal_id (opcional), articulo (texto, opcional).
- por_comprar: artículos cuyo stock no cubre mínimo más consumo. Parámetros: dias (opcional, 1 por defecto), sucursal_id (opcional).
- facturas_ingresadas: facturas ingresadas con su emisor, folio, fecha de emisión, montos, sucursal y fecha de ingreso. Para preguntas de facturas y su emisor usa esta y no consultar sobre facturas_compra, donde el proveedor puede venir vacío. Trae la suma de las facturas encontradas: si preguntan cuánto se compró, responde con suma_monto_total. Parámetros: emisor (texto opcional, busca coincidencias), desde y hasta (YYYY-MM-DD, opcionales, sobre la fecha de emisión), limite.
- consultar: lectura general de cualquier tabla o vista (proveedores, turnos, almuerzos, ventas). Parámetros:
  recurso: nombre de la tabla o vista.
  select: columnas separadas por coma, sin *. Para traer datos de otra tabla usa la llave foránea marcada con -> en el esquema, con la forma tabla!columna(campos). Ejemplo: "anulada_por,usuarios!anulada_por(nombre)".
  filtros: objeto {columna: condición}. Condiciones: eq.x, neq.x, gt.x, gte.x, lt.x, lte.x, ilike.*texto*, in.(1,2), is.null. Para comparar texto usa siempre ilike, porque eq. distingue mayúsculas. Para dos condiciones sobre una columna usa una lista. Ejemplo: {"anulada":"eq.true","fecha_venta":["gte.2026-10-01","lt.2026-11-01"]}.
  orden: "columna.desc". limite: cantidad de filas.
  agregar: para que el sistema calcule, por ejemplo {"contar":true,"agrupar_por":"usuarios.nombre"} o {"suma":["monto_total"]}. agrupar_por acepta un campo traído de otra tabla. El resultado ya viene de mayor a menor: no uses orden con agregar.
  Si piden un total, una suma o un conteo, usa agregar: nunca respondas con la lista de filas.
  En ventas, las anuladas se excluyen salvo que filtres por anulada.
  Si una consulta falla, lee el error, corrígela y reintenta antes de rendirte.`;

function numero(valor: unknown): number {
  const convertido = Number(valor);
  return Number.isFinite(convertido) ? convertido : 0;
}

/** Lee `usuarios.nombre` en una fila con la tabla embebida, o una columna directa. */
function valorEnRuta(fila: Record<string, unknown>, ruta: string): unknown {
  return ruta
    .split('.')
    .reduce<unknown>((actual, parte) => (actual as Record<string, unknown> | null | undefined)?.[parte], fila);
}

function redondear1(valor: number): number {
  return Math.round(valor * 10) / 10;
}

/** Margen = precio neto de IVA menos costo, con la misma regla de costo del dashboard. */
export function calcularMargenProducto(
  producto: { id: number; nombre: string; precio_venta: unknown; precio_compra: unknown; activo?: boolean },
  costoReceta: number | undefined,
) {
  const precio = numero(producto.precio_venta);
  const neto = Math.round(precio * PROPORCION_NETA);
  const costo = costoUnitario(costoReceta, producto.precio_compra);
  const margen = costo === null ? null : Math.round(precio * PROPORCION_NETA - costo);
  return {
    producto_id: producto.id,
    producto: producto.nombre,
    activo: producto.activo,
    precio_venta: precio,
    precio_neto: neto,
    iva: precio - neto,
    costo,
    fuente_costo: costo === null ? null : costoReceta ? 'receta' : 'precio_compra',
    margen_por_unidad: margen,
    margen_porcentaje: margen === null || precio <= 0 ? null : redondear1((margen / precio) * 100),
    nota: costo === null ? 'Sin costo registrado: no se puede calcular el margen.' : undefined,
  };
}

/** Ventas por medio de pago, contando solo los días pedidos en hora de Chile. */
export function contarPorMedioPago(
  ventas: readonly Record<string, unknown>[],
  desde: string,
  hasta: string,
): Map<string, number> {
  const conteo = new Map<string, number>();
  for (const venta of ventas) {
    const dia = formatearFechaChile(parsearFechaServidor(String(venta['fecha_venta'])));
    if (dia >= desde && dia <= hasta) {
      const medio = String(venta['medio_pago'] ?? '').trim() || 'sin_medio';
      conteo.set(medio, (conteo.get(medio) ?? 0) + 1);
    }
  }
  return conteo;
}

/**
 * Totales de red sobre las filas de fn_reporte_ventas_sucursal. La cantidad por medio de pago se
 * entrega solo si cuadra con el reporte: es preferible no darla a dar una distinta.
 */
export function resumirVentasPeriodo(
  filas: readonly Record<string, unknown>[],
  ventasPorMedio: ReadonlyMap<string, number> | null = null,
) {
  const sumar = (campo: string) => filas.reduce((suma, f) => suma + numero(f[campo]), 0);
  const ventas = sumar('ventas');
  const total = sumar('total');
  const montos: Record<string, number> = {};
  for (const fila of filas) {
    for (const [medio, monto] of Object.entries((fila['medios_pago'] ?? {}) as Record<string, unknown>)) {
      montos[medio] = (montos[medio] ?? 0) + numero(monto);
    }
  }
  const cuadra = ventasPorMedio !== null && [...ventasPorMedio.values()].reduce((a, b) => a + b, 0) === ventas;
  return {
    monto_total_clp: total,
    cantidad_ventas: ventas,
    ticket_promedio_clp: ventas > 0 ? Math.round(total / ventas) : 0,
    cantidad_anuladas: sumar('anuladas'),
    monto_anuladas_clp: sumar('total_anuladas'),
    cantidad_ventas_a_clientes: sumar('ventas_normales'),
    monto_ventas_a_clientes_clp: sumar('total_normales'),
    cantidad_ventas_a_empleados: sumar('ventas_empleado'),
    monto_ventas_a_empleados_clp: sumar('total_empleado'),
    nota: 'El total y la cantidad de ventas ya excluyen las anuladas.',
    por_medio_de_pago: Object.entries(montos)
      .sort(([, a], [, b]) => b - a)
      .map(([medio, monto_clp]) => ({
        medio,
        cantidad_ventas: cuadra ? (ventasPorMedio.get(medio) ?? 0) : null,
        monto_clp,
      })),
    por_sucursal: filas
      .filter((f) => numero(f['ventas']) > 0)
      .map((f) => ({ sucursal: f['sucursal'], cantidad_ventas: numero(f['ventas']), monto_clp: numero(f['total']) })),
  };
}

export type OrdenRanking = 'unidades' | 'monto' | 'ganancia' | 'menos_vendidos';

/** Une por producto las filas de fn_reporte_productos_sucursal y calcula su ganancia limpia. */
export function calcularRankingProductos(
  filas: readonly Record<string, unknown>[],
  costoDe: (productoId: number) => number | null,
  orden: OrdenRanking = 'unidades',
  limite = 10,
) {
  const productos = new Map<number, { producto: string; categoria: unknown; unidades: number; monto: number }>();
  for (const fila of filas) {
    const id = numero(fila['producto_id']);
    const previo = productos.get(id);
    productos.set(id, {
      producto: String(fila['producto']),
      categoria: fila['categoria'],
      unidades: (previo?.unidades ?? 0) + numero(fila['unidades']),
      monto: (previo?.monto ?? 0) + numero(fila['monto']),
    });
  }

  const conGanancia = [...productos.entries()]
    .filter(([, p]) => p.unidades > 0)
    .map(([id, p]) => {
      const costo = costoDe(id);
      return {
        ...p,
        monto: Math.round(p.monto),
        ganancia_limpia: costo === null ? null : Math.round(p.monto * PROPORCION_NETA - costo * p.unidades),
      };
    });

  const criterios: Record<OrdenRanking, (a: (typeof conGanancia)[number], b: (typeof conGanancia)[number]) => number> = {
    unidades: (a, b) => b.unidades - a.unidades,
    monto: (a, b) => b.monto - a.monto,
    ganancia: (a, b) => (b.ganancia_limpia ?? -Infinity) - (a.ganancia_limpia ?? -Infinity),
    menos_vendidos: (a, b) => a.unidades - b.unidades,
  };
  return {
    productos_con_ventas: conGanancia.length,
    orden,
    productos: conGanancia.sort(criterios[orden] ?? criterios.unidades).slice(0, limite),
  };
}

/** Suma, promedia o cuenta filas, opcionalmente agrupadas, para que el modelo no haga las cuentas. */
export function agregarFilas(
  filas: readonly Record<string, unknown>[],
  agregar: AgregacionFilas,
  grupoSinValor = 'sin dato',
) {
  const grupos = new Map<string, Record<string, unknown>[]>();
  for (const fila of filas) {
    const clave = agregar.agrupar_por ? String(valorEnRuta(fila, agregar.agrupar_por) ?? grupoSinValor) : 'total';
    grupos.set(clave, [...(grupos.get(clave) ?? []), fila]);
  }

  const filas_agregadas = [...grupos.entries()].map(([grupo, filasGrupo]) => {
    const resultado: Record<string, unknown> = agregar.agrupar_por ? { [agregar.agrupar_por]: grupo } : {};
    if (agregar.contar) {
      resultado['filas'] = filasGrupo.length;
    }
    const sumar = (columna: string) => filasGrupo.reduce((suma, f) => suma + numero(f[columna]), 0);
    for (const columna of agregar.suma ?? []) {
      resultado[`suma_${columna}`] = sumar(columna);
    }
    for (const columna of agregar.promedio ?? []) {
      resultado[`promedio_${columna}`] = Math.round((sumar(columna) / filasGrupo.length) * 100) / 100;
    }
    return resultado;
  });

  // De mayor a menor por la primera métrica pedida, para responder "cuál tiene más".
  const metrica = agregar.contar
    ? 'filas'
    : agregar.suma?.[0]
      ? `suma_${agregar.suma[0]}`
      : agregar.promedio?.[0]
        ? `promedio_${agregar.promedio[0]}`
        : null;
  return metrica
    ? filas_agregadas.sort((a, b) => numero(b[metrica]) - numero(a[metrica]))
    : filas_agregadas;
}

/** Lo máximo que entrega fn_listar_ingresos_factura: con esa cantidad pueden existir más. */
export const MAX_FACTURAS_LEIDAS = 500;
const MAX_FACTURAS_RESULTADO = 30;

/** "Coca-Cola" y "coca cola" son el mismo emisor: el texto del SII y el de la pregunta no se escriben igual. */
function claveEmisor(texto: unknown): string {
  return String(texto ?? '')
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .replace(/[\s.-]+/g, '');
}

/** Facturas del reporte, con el emisor que dice la propia factura. `facturas_compra` no siempre lo tiene. */
export function listarFacturasIngresadas(
  filas: readonly Record<string, unknown>[],
  filtro: { emisor?: string; desde?: string; hasta?: string; limite?: number },
) {
  const buscado = claveEmisor(filtro.emisor);
  const facturas = filas
    .filter((f) => {
      const fecha = String(f['fecha_emision'] ?? '').slice(0, 10);
      return (
        (!buscado || [f['proveedor'], f['razon_social_emisor']].some((e) => claveEmisor(e).includes(buscado))) &&
        (!filtro.desde || fecha >= filtro.desde) &&
        (!filtro.hasta || fecha <= filtro.hasta)
      );
    })
    .map((f) => ({
      // Como texto: un folio es un identificador y no debe mostrarse con separador de miles.
      folio: String(f['folio']),
      emisor: f['proveedor'] || f['razon_social_emisor'] || null,
      fecha_emision: f['fecha_emision'],
      monto_total: f['monto_total'],
      monto_neto: f['monto_neto'],
      sucursal: f['sucursal'],
      ingresada_en: f['ingresada_en'],
    }));

  const truncado = filas.length >= MAX_FACTURAS_LEIDAS;
  if (facturas.length === 0) {
    const deEmisor = filtro.emisor?.trim() ? ` de ${filtro.emisor.trim()}` : '';
    const enFechas = filtro.desde || filtro.hasta ? ' en esas fechas' : '';
    return { facturas_encontradas: 0, resultado: `No hay facturas ingresadas${deEmisor}${enFechas}.`, truncado };
  }
  return {
    facturas_encontradas: facturas.length,
    // Suma todas las encontradas, aunque `limite` muestre menos.
    suma_monto_total: facturas.reduce((suma, f) => suma + numero(f.monto_total), 0),
    suma_monto_neto: facturas.reduce((suma, f) => suma + numero(f.monto_neto), 0),
    truncado,
    facturas: facturas.slice(0, filtro.limite && filtro.limite > 0 ? filtro.limite : MAX_FACTURAS_RESULTADO),
  };
}

export interface PeriodoEspecial {
  nombre: string;
  desde: string;
  hasta: string;
  conRegistros: boolean;
}

const PERIODOS_ESPECIALES: readonly { nombre: string; inicio: string; fin: (anio: number) => string }[] = [
  { nombre: 'Fiestas Patrias', inicio: '09-18', fin: () => '09-19' },
  { nombre: 'Navidad', inicio: '12-25', fin: () => '12-25' },
  { nombre: 'Vacaciones de verano', inicio: '01-01', fin: (anio) => `02-${new Date(Date.UTC(anio, 2, 0)).getUTCDate()}` },
  { nombre: 'Vacaciones de invierno', inicio: '07-01', fin: () => '07-31' },
];

/**
 * Última ocurrencia ya terminada o en curso de cada período y si hay registros de ella.
 * Lo calcula el código porque el modelo, al comparar fechas por su cuenta, se equivocaba.
 */
export function periodosEspeciales(primeraVenta: string, hoy: string): PeriodoEspecial[] {
  const anioActual = Number(hoy.slice(0, 4));
  return PERIODOS_ESPECIALES.map(({ nombre, inicio, fin }) => {
    const anio = `${anioActual}-${inicio}` <= hoy ? anioActual : anioActual - 1;
    const hasta = `${anio}-${fin(anio)}`;
    return { nombre, desde: `${anio}-${inicio}`, hasta, conRegistros: hasta >= primeraVenta };
  });
}

const FECHA_CON_HORA = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/;
const formatoFechaHoraChile = new Intl.DateTimeFormat('sv-SE', {
  timeZone: 'America/Santiago',
  dateStyle: 'short',
  timeStyle: 'short',
});

/**
 * Convierte fechas de servidor (con zona explícita o sin zona en UTC) a hora de Chile para mostrar
 * en el chat sin correr días por la noche.
 */
export function fechasEnHoraChile(datos: unknown): unknown {
  if (typeof datos === 'string' && FECHA_CON_HORA.test(datos)) {
    const instante = parsearFechaServidor(datos);
    return Number.isNaN(instante.getTime()) ? datos : formatoFechaHoraChile.format(instante);
  }
  if (Array.isArray(datos)) {
    return datos.map(fechasEnHoraChile);
  }
  if (typeof datos === 'object' && datos !== null) {
    return Object.fromEntries(Object.entries(datos).map(([clave, valor]) => [clave, fechasEnHoraChile(valor)]));
  }
  return datos;
}

/** Datos calculados con sus etiquetas: se muestran tal cual, sin pasar por la redacción del modelo. */
export interface BloqueDatos {
  titulo: string;
  lineas: string[];
}

const MAX_LINEAS_BLOQUE = 25;
const MAX_BLOQUES = 5;

const TITULOS: Record<string, string> = {
  margen_producto: 'Margen del producto',
  ventas_periodo: 'Ventas',
  auditoria_usuarios: 'Cambios de usuarios',
  stock_articulo: 'Stock',
  receta_producto: 'Receta',
  ranking_productos: 'Productos',
  ranking_cajeros: 'Cajeros',
  analisis_dashboard: 'Análisis del negocio',
  prediccion_stock: 'Sugerencias de compra',
  por_comprar: 'Por comprar',
  facturas_ingresadas: 'Facturas ingresadas',
  consultar: 'Datos consultados',
};

const ETIQUETAS: Record<string, string> = {
  monto_total_clp: 'Total vendido',
  cantidad_ventas: 'Cantidad de ventas',
  cantidad_ventas_a_clientes: 'Ventas a clientes',
  cantidad_ventas_a_empleados: 'Ventas a empleados',
  cantidad_anuladas: 'Ventas anuladas',
  monto_anuladas_clp: 'Monto anulado',
  monto_ventas_a_clientes_clp: 'Monto de ventas a clientes',
  monto_ventas_a_empleados_clp: 'Monto de ventas a empleados',
  medio: 'Medio de pago',
  filas: 'Cantidad',
  truncado: 'Resultado incompleto',
  frecuenciaTexto: 'Frecuencia',
  acompanamiento: 'Acompañamiento',
  esRecomendable: 'Alcanza para recomendar una promoción',
  fecha_emision: 'Fecha de emisión',
  ingresada_en: 'Fecha de ingreso',
  suma_monto_total: 'Suma de los montos totales',
  suma_monto_neto: 'Suma de los montos netos',
  ventas_por_dia_semana: 'Ventas por día de la semana',
  es_dia_mayor_venta: 'Día de mayor venta',
  promedio_venta_diaria_clp: 'Promedio diario',
  dia: 'Día',
};

const CAMPO_OCULTO = /(^|_)id$|[a-z]Id$|^(diaNumero|tono|orden|lift|soportePct|confianzaPct|nota_para_ia|periodo|consejoPractico|explicacionSimple)$/;
const CAMPO_MONTO = /clp|monto|total|costo|precio|margen_por_unidad|ganancia|neto|ticket_?promedio|(^|_)iva$/i;
const CAMPO_PORCENTAJE = /porcentaje|pct$/i;

const formatoPesos = new Intl.NumberFormat('es-CL', {
  style: 'currency',
  currency: 'CLP',
  maximumFractionDigits: 0,
});
const formatoNumero = new Intl.NumberFormat('es-CL', { maximumFractionDigits: 2 });

const MONTO_MARCADO =
  /\$\s?(\d{4,}(?:[.,]\d{1,2})?)(?![.,]?\d)(?:\s+(?:pesos(?:\s+chilenos)?|CLP)\b)?|\b(\d{4,}(?:[.,]\d{1,2})?)\s+(?:pesos(?:\s+chilenos)?|CLP)\b/gi;
/** Un número suelto que no es parte de otro, ni un porcentaje, ni lleva una unidad que lo delate como cantidad. */
const NUMERO_SUELTO =
  /(?<![\d$.,-])\d{4,}(?:[.,]\d{1,2})?(?![.,]?\d|-\d|\s*%|\s+(?:unidades|ventas|boletas|tickets|facturas|productos|art[ií]culos|d[ií]as|kg|gr?|ml|lt?)\b)/gi;
const TOLERANCIA_MONTO = 0.5;

/** Números de los resultados, separados en montos y el resto según el nombre de su campo. */
function numerosPorTipo(datos: unknown, clave: string, montos: number[], otros: number[]): void {
  if (Array.isArray(datos)) {
    datos.forEach((dato) => numerosPorTipo(dato, clave, montos, otros));
  } else if (typeof datos === 'object' && datos !== null) {
    Object.entries(datos).forEach(([campo, valor]) => numerosPorTipo(valor, campo, montos, otros));
  } else if ((typeof datos === 'number' || typeof datos === 'string') && datos !== '' && Number.isFinite(Number(datos))) {
    (CAMPO_MONTO.test(clave) && !CAMPO_PORCENTAJE.test(clave) ? montos : otros).push(Number(datos));
  }
}

/**
 * Escribe los montos con formato chileno: el formato lo pone el código, no el modelo.
 * "461820 pesos" y "$461820" siempre se convierten. Un número suelto ("promedio de 51313") solo si
 * los resultados lo traen en un campo de monto y en ningún otro: ante la duda queda como está.
 */
export function montosEnPesos(texto: string, resultados: readonly ResultadoHerramienta[] = []): string {
  const montos: number[] = [];
  const otros: number[] = [];
  numerosPorTipo(resultados.map((r) => r.datos), '', montos, otros);
  const esta = (lista: readonly number[], valor: number) => lista.some((n) => Math.abs(n - valor) < TOLERANCIA_MONTO);
  const leer = (token: string) => Number(token.replace(',', '.'));

  return texto
    .replace(MONTO_MARCADO, (_, conSigno?: string, conPalabra?: string) => formatoPesos.format(leer(conSigno ?? conPalabra ?? '')))
    .replace(NUMERO_SUELTO, (token) => {
      const valor = leer(token);
      const esAnio = Number.isInteger(valor) && valor >= 1900 && valor <= 2100;
      return !esAnio && esta(montos, valor) && !esta(otros, valor) ? formatoPesos.format(valor) : token;
    });
}

function etiquetaDe(clave: string): string {
  if (ETIQUETAS[clave]) return ETIQUETAS[clave];
  const texto = (clave.split('.').pop() ?? clave)
    .replace(/_clp$|Clp$/, '')
    .replace(/([a-z])([A-Z])/g, '$1 $2')
    .replace(/_/g, ' ')
    .toLowerCase();
  return texto.charAt(0).toUpperCase() + texto.slice(1);
}

function textoFecha(valor: string): string {
  const [, fecha, hora] = valor.match(/^(\d{4}-\d{2}-\d{2})( \d{2}:\d{2})?$/) ?? [];
  return fecha ? `${fecha.split('-').reverse().join('-')}${hora ?? ''}` : valor;
}

function valorDe(clave: string, valor: unknown): string | null {
  if (typeof valor === 'boolean') return valor ? 'Sí' : 'No';
  if (typeof valor === 'string' && !(CAMPO_MONTO.test(clave) && Number.isFinite(Number(valor)))) {
    return valor.trim() ? textoFecha(valor) : null;
  }
  const cifra = Number(valor);
  if ((typeof valor !== 'number' && typeof valor !== 'string') || !Number.isFinite(cifra)) return null;
  if (CAMPO_PORCENTAJE.test(clave)) return `${formatoNumero.format(cifra)}%`;
  return CAMPO_MONTO.test(clave) ? formatoPesos.format(cifra) : formatoNumero.format(cifra);
}

function camposDe(fila: unknown): string[] {
  if (typeof fila !== 'object' || fila === null) {
    return [String(fila)];
  }
  return Object.entries(fila).flatMap(([clave, valor]) => {
    const texto = CAMPO_OCULTO.test(clave) || (clave === 'truncado' && !valor) || (clave === 'es_dia_mayor_venta' && !valor) ? null : valorDe(clave, valor);
    return texto === null ? [] : [`${etiquetaDe(clave)}: ${texto}`];
  });
}

function lineasDe(datos: unknown): string[] {
  const unaPorFila = (filas: unknown[]) => filas.map((fila) => camposDe(fila).join(' · ')).filter(Boolean);
  if (Array.isArray(datos)) {
    return datos.length === 1 ? lineasDe(datos[0]) : unaPorFila(datos);
  }
  if (typeof datos !== 'object' || datos === null) {
    return camposDe(datos);
  }
  const listas = Object.entries(datos).filter((par): par is [string, unknown[]] => Array.isArray(par[1]) && par[1].length > 0);
  return [
    ...camposDe(datos),
    ...listas.flatMap(([clave, lista]) => [...(clave === 'filas' ? [] : [`${etiquetaDe(clave)}:`]), ...unaPorFila(lista)]),
  ];
}

export function construirBloquesDatos(resultados: readonly ResultadoHerramienta[]): BloqueDatos[] {
  return resultados
    .filter((r) => r.datos !== undefined && r.datos !== null)
    .flatMap((r) => {
      const lineas = lineasDe(r.datos);
      if (lineas.length === 0) return [];
      const { desde, hasta } = r.parametros ?? {};
      const rango = typeof desde === 'string' && typeof hasta === 'string' ? ` (${textoFecha(desde)} a ${textoFecha(hasta)})` : '';
      const resto = lineas.length - MAX_LINEAS_BLOQUE;
      return [
        {
          titulo: `${TITULOS[r.herramienta] ?? etiquetaDe(r.herramienta)}${rango}`,
          lineas: resto > 0 ? [...lineas.slice(0, MAX_LINEAS_BLOQUE), `y ${resto} más`] : lineas,
        },
      ];
    })
    .slice(-MAX_BLOQUES);
}
