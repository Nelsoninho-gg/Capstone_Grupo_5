import { describe, expect, it } from 'vitest';
import { environment } from '../../../environments/environment';
import {
  extraerTextoRespuestaIA,
  limpiarMarkdownJson,
  prepararPeticionIA,
} from './adaptadores-proveedor-ia';
import {
  MensajesIA,
  PROVEEDORES_IA_NURY,
  ProveedorIAConfig,
} from './proveedores-ia.config';

describe('adaptadores-proveedor-ia (H4.5 T06)', () => {
  const mensajesPrueba: MensajesIA = {
    sistema: 'Eres un asistente experto.',
    usuario: '{"pregunta": "hola"}',
  };

  describe('Formato Gemini', () => {
    const configGemini: ProveedorIAConfig = {
      id: 'gemini-test',
      formato: 'gemini',
      modelo: 'gemini-2.0-flash',
      baseUrl: `${environment.apiUrl}/ia/gemini/v1beta`,
      autenticacion: 'sesion-nury',
    };

    it('construye la URL y la estructura de cuerpo nativa de Gemini con modo JSON', () => {
      const peticion = prepararPeticionIA(configGemini, mensajesPrueba, 'token-123');

      expect(peticion.url).toBe(
        `${environment.apiUrl}/ia/gemini/v1beta/models/gemini-2.0-flash:generateContent`,
      );
      expect(peticion.headers['Content-Type']).toBe('application/json');
      expect(peticion.headers['Authorization']).toBe('Bearer token-123');

      const body = peticion.body as any;
      expect(body.systemInstruction.parts[0].text).toBe(mensajesPrueba.sistema);
      expect(body.contents[0].role).toBe('user');
      expect(body.contents[0].parts[0].text).toBe(mensajesPrueba.usuario);
      expect(body.generationConfig.responseMimeType).toBe('application/json');
      expect(body.generationConfig.temperature).toBe(0);
    });

    it('extrae el texto de la respuesta de Gemini', () => {
      const respuestaValida = {
        candidates: [
          {
            content: {
              parts: [{ text: '{"predicciones": []}' }],
            },
          },
        ],
      };
      const texto = extraerTextoRespuestaIA(configGemini, respuestaValida);
      expect(texto).toBe('{"predicciones": []}');
    });

    it('ignora el razonamiento (thought) que Gemma entrega antes de la respuesta', () => {
      const respuesta = {
        candidates: [
          {
            content: {
              parts: [
                { text: '*   Input: analizar', thought: true },
                { text: '{"r":' },
                { text: '"ok"}' },
              ],
            },
          },
        ],
      };
      expect(extraerTextoRespuestaIA(configGemini, respuesta)).toBe('{"r":"ok"}');
    });

    it('lanza error si Gemma solo entrega razonamiento', () => {
      const respuesta = { candidates: [{ content: { parts: [{ text: 'pensando', thought: true }] } }] };
      expect(() => extraerTextoRespuestaIA(configGemini, respuesta)).toThrow('Respuesta de Gemini vacía');
    });

    it('remueve delimitadores de código markdown (```json ... ```) si el modelo los incluye', () => {
      const respuestaConFences = {
        candidates: [
          {
            content: {
              parts: [{ text: '```json\n{"predicciones": []}\n```' }],
            },
          },
        ],
      };
      const texto = extraerTextoRespuestaIA(configGemini, respuestaConFences);
      expect(texto).toBe('{"predicciones": []}');
    });

    it('lanza error si la respuesta de Gemini viene sin contenido o vacía', () => {
      expect(() => extraerTextoRespuestaIA(configGemini, {})).toThrow();
      expect(() =>
        extraerTextoRespuestaIA(configGemini, { candidates: [] }),
      ).toThrow('Respuesta de Gemini vacía');
      expect(() =>
        extraerTextoRespuestaIA(configGemini, {
          candidates: [{ content: { parts: [{ text: '   ' }] } }],
        }),
      ).toThrow('Respuesta de Gemini vacía');
    });
  });

  describe('Formato OpenAI compatible', () => {
    const configOpenRouter: ProveedorIAConfig = {
      id: 'openrouter-test',
      formato: 'openai-compatible',
      modelo: 'nvidia/nemotron-3.5-super-vl:free',
      baseUrl: `${environment.apiUrl}/ia/openrouter/api/v1`,
      autenticacion: 'sesion-nury',
    };

    it('construye la URL chat/completions y el cuerpo en modo json_object', () => {
      const peticion = prepararPeticionIA(configOpenRouter, mensajesPrueba, 'jwt-nury');

      expect(peticion.url).toBe(
        `${environment.apiUrl}/ia/openrouter/api/v1/chat/completions`,
      );
      expect(peticion.headers['Authorization']).toBe('Bearer jwt-nury');

      const body = peticion.body as any;
      expect(body.model).toBe('nvidia/nemotron-3.5-super-vl:free');
      expect(body.response_format).toEqual({ type: 'json_object' });
      expect(body.temperature).toBe(0);
      expect(body.messages).toEqual([
        { role: 'system', content: mensajesPrueba.sistema },
        { role: 'user', content: mensajesPrueba.usuario },
      ]);
    });

    it('extrae el texto de la respuesta compatible con OpenAI', () => {
      const respuestaValida = {
        choices: [
          {
            message: {
              content: '{"ok": true}',
            },
          },
        ],
      };
      const texto = extraerTextoRespuestaIA(configOpenRouter, respuestaValida);
      expect(texto).toBe('{"ok": true}');
    });

    it('remueve delimitadores de código markdown de respuestas OpenAI compatibles', () => {
      const respuestaConFences = {
        choices: [
          {
            message: {
              content: '```json\n{"ok": true}\n```',
            },
          },
        ],
      };
      const texto = extraerTextoRespuestaIA(configOpenRouter, respuestaConFences);
      expect(texto).toBe('{"ok": true}');
    });

    it('limpiarMarkdownJson limpia cadenas con o sin etiqueta json y conserva texto puro', () => {
      expect(limpiarMarkdownJson('```json\n{"a": 1}\n```')).toBe('{"a": 1}');
      expect(limpiarMarkdownJson('```\n{"b": 2}\n```')).toBe('{"b": 2}');
      expect(limpiarMarkdownJson('{"c": 3}')).toBe('{"c": 3}');
    });

    it('lanza error si la respuesta de OpenAI compatible viene sin choices o vacía', () => {
      expect(() => extraerTextoRespuestaIA(configOpenRouter, null)).toThrow();
      expect(() =>
        extraerTextoRespuestaIA(configOpenRouter, { choices: [] }),
      ).toThrow('Respuesta de proveedor OpenAI vacía');
      expect(() =>
        extraerTextoRespuestaIA(configOpenRouter, {
          choices: [{ message: { content: '' } }],
        }),
      ).toThrow('Respuesta de proveedor OpenAI vacía');
    });
  });

  describe('Seguridad de tokens y credenciales', () => {
    it('REGLA CRÍTICA: rechaza enviar el JWT de sesión si la baseUrl es externa a environment.apiUrl', () => {
      const configExternaInsegura: ProveedorIAConfig = {
        id: 'gemini-externo',
        formato: 'gemini',
        modelo: 'gemini-2.0-flash',
        baseUrl: 'https://generativelanguage.googleapis.com/v1beta',
        autenticacion: 'sesion-nury',
      };

      expect(() =>
        prepararPeticionIA(configExternaInsegura, mensajesPrueba, 'mi-jwt-secreto'),
      ).toThrow(/El JWT de sesión solo puede viajar a/);
    });

    it('con autenticacion sesion-nury exige un token activo y no permite llamadas anónimas', () => {
      const configNury: ProveedorIAConfig = {
        id: 'gemini-nury',
        formato: 'gemini',
        modelo: 'gemini-2.0-flash',
        baseUrl: `${environment.apiUrl}/ia/gemini/v1beta`,
        autenticacion: 'sesion-nury',
      };

      expect(() => prepararPeticionIA(configNury, mensajesPrueba, null)).toThrow(
        /requiere una sesión activa con token JWT/,
      );
      expect(() => prepararPeticionIA(configNury, mensajesPrueba, '   ')).toThrow(
        /requiere una sesión activa con token JWT/,
      );
    });

    it('con autenticacion api-key para Gemini usa cabecera x-goog-api-key y no filtra el JWT', () => {
      const configApiKey: ProveedorIAConfig = {
        id: 'gemini-key',
        formato: 'gemini',
        modelo: 'gemini-2.0-flash',
        baseUrl: 'https://generativelanguage.googleapis.com/v1beta',
        autenticacion: 'api-key',
        apiKey: 'AIzaSyPrueba123',
      };

      const peticion = prepararPeticionIA(configApiKey, mensajesPrueba, 'jwt-no-enviar');
      expect(peticion.headers['x-goog-api-key']).toBe('AIzaSyPrueba123');
      expect(peticion.headers['Authorization']).toBeUndefined();
      expect(peticion.url).not.toContain('key=');
    });

    it('con autenticacion api-key para OpenAI compatible usa Bearer <apiKey> y no el JWT', () => {
      const configApiKey: ProveedorIAConfig = {
        id: 'openrouter-key',
        formato: 'openai-compatible',
        modelo: 'nvidia/nemotron-3.5-super-vl:free',
        baseUrl: 'https://openrouter.ai/api/v1',
        autenticacion: 'api-key',
        apiKey: 'sk-or-prueba-999',
      };

      const peticion = prepararPeticionIA(configApiKey, mensajesPrueba, 'jwt-no-enviar');
      expect(peticion.headers['Authorization']).toBe('Bearer sk-or-prueba-999');
    });

    it('no agrega cabecera de autorización si no hay token de sesión ni apiKey', () => {
      const configSinAuth: ProveedorIAConfig = {
        id: 'local-test',
        formato: 'openai-compatible',
        modelo: 'qwen',
        baseUrl: 'http://localhost:11434/v1',
        autenticacion: 'api-key',
      };

      const peticion = prepararPeticionIA(configSinAuth, mensajesPrueba, null);
      expect(peticion.headers['Authorization']).toBeUndefined();
    });

    it('PROVEEDORES_IA_NURY respeta el orden acordado, con identificadores distintos', () => {
      expect(PROVEEDORES_IA_NURY.map((p) => p.modelo)).toEqual([
        'gemini-3.5-flash-lite',
        'gemini-3.1-flash-lite',
        'gemma-4-26b-a4b-it',
        'nvidia/nemotron-3.5-super-vl:free',
      ]);
      expect(new Set(PROVEEDORES_IA_NURY.map((p) => p.id)).size).toBe(4);
    });

    it('PROVEEDORES_IA_NURY apunta exclusivamente a environment.apiUrl y no incluye API keys en código', () => {
      for (const p of PROVEEDORES_IA_NURY) {
        expect(p.baseUrl.startsWith(environment.apiUrl)).toBe(true);
        expect(p.autenticacion).toBe('sesion-nury');
        expect(p.apiKey).toBeUndefined();
      }
    });
  });
});
