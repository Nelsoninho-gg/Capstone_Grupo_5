import {
  MovimientoArticulo,
  etiquetaMovimiento,
  filtrarMovimientos,
  origenMovimiento,
} from './movimientos.model';

describe('movimientos.model', () => {
  const base: MovimientoArticulo = {
    id: 1,
    tipo: 'venta',
    ventaId: 67,
    referenciaTipo: 'venta',
    referenciaId: 67,
    cantidad: -2,
    unidad: 'un',
    stockResultante: 3,
    sucursalId: 1,
    sucursal: 'Providencia',
    fecha: new Date('2026-10-22T16:53:52Z'),
    nota: null,
  };
  const anulacion = { ...base, id: 2, tipo: 'anulacion_venta' as const, cantidad: 2 };
  const compra = {
    ...base,
    id: 3,
    tipo: 'compra' as const,
    ventaId: null,
    referenciaTipo: 'factura_compra',
    referenciaId: 12,
  };
  const ajuste = {
    ...base,
    id: 4,
    tipo: 'ajuste' as const,
    ventaId: null,
    referenciaTipo: 'ajuste_manual',
    referenciaId: null,
  };
  const merma = { ...ajuste, id: 5, tipo: 'merma' as const };
  const almuerzo = {
    ...base,
    id: 6,
    tipo: 'consumo_interno' as const,
    ventaId: null,
    referenciaTipo: 'almuerzo_empleado',
    referenciaId: 9,
  };

  it('describes where each movement came from', () => {
    expect(origenMovimiento(base)).toBe('Venta #67');
    expect(origenMovimiento(anulacion)).toBe('Anulación de la venta #67');
    expect(origenMovimiento(compra)).toBe('Factura #12');
    expect(origenMovimiento(ajuste)).toBe('Ajuste manual');
    expect(origenMovimiento(merma)).toBe('Merma registrada');
    expect(origenMovimiento(almuerzo)).toBe('Almuerzo de empleado #9');
  });

  it('filters by type, grouping adjustments and losses', () => {
    const todos = [base, anulacion, compra, ajuste, merma];
    expect(filtrarMovimientos(todos, 'todos')).toHaveLength(5);
    expect(filtrarMovimientos(todos, 'venta').map((m) => m.id)).toEqual([1]);
    expect(filtrarMovimientos(todos, 'anulacion_venta').map((m) => m.id)).toEqual([2]);
    expect(filtrarMovimientos(todos, 'ajustes').map((m) => m.id)).toEqual([4, 5]);
  });

  it('keeps employee lunches out of sales and adjustments (H2.13 T06)', () => {
    const todos = [base, ajuste, merma, almuerzo];
    expect(filtrarMovimientos(todos, 'todos').map((m) => m.id)).toContain(6);
    expect(filtrarMovimientos(todos, 'venta').map((m) => m.id)).toEqual([1]);
    expect(filtrarMovimientos(todos, 'ajustes').map((m) => m.id)).toEqual([4, 5]);
  });

  it('labels each type in Spanish', () => {
    expect(etiquetaMovimiento('anulacion_venta')).toBe('Anulación');
    expect(etiquetaMovimiento('merma')).toBe('Merma');
    expect(etiquetaMovimiento('consumo_interno')).toBe('Consumo interno');
  });
});
