import { HttpErrorResponse } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Subject, of, throwError } from 'rxjs';
import { ArticuloPorComprar } from '../../models/compras.model';
import { InventarioService } from '../../services/inventario.service';
import { ListaCompras } from './lista-compras';

const leche: ArticuloPorComprar = {
  id: 'materia_prima-3-1',
  articuloId: 3,
  articulo: 'Leche entera',
  tipo: 'materia_prima',
  unidad: 'L',
  sucursalId: 1,
  sucursal: 'Nury Providencia',
  stock: 1.5,
  minimo: 4,
  vendido: 15.75,
  consumoDiario: 2.25,
  objetivo: 6.25,
  sugerido: 4.75,
};
const bebida: ArticuloPorComprar = {
  ...leche,
  id: 'producto-8-2',
  articuloId: 8,
  articulo: 'Chaparrita',
  tipo: 'producto',
  unidad: 'un',
  sucursalId: 2,
  sucursal: 'Nury Ñuñoa',
  stock: 0,
  minimo: 6,
  vendido: 21,
  consumoDiario: 3,
  objetivo: 9,
  sugerido: 9,
};
const pan: ArticuloPorComprar = {
  ...leche,
  id: 'materia_prima-1-1',
  articuloId: 1,
  articulo: 'Pan amasado',
  unidad: 'kg',
  stock: 11,
  minimo: 10,
  vendido: 17.5,
  consumoDiario: 2.5,
  objetivo: 12.5,
  sugerido: 1.5,
};
const sucursales = [
  { id: 1, nombre: 'Nury Providencia' },
  { id: 2, nombre: 'Nury Ñuñoa' },
];

describe('ListaCompras', () => {
  let fixture: ComponentFixture<ListaCompras>;
  const service = { listarPorComprar: vi.fn() };

  async function render(opciones: { sucursalInicial?: string; lista?: typeof sucursales } = {}) {
    await TestBed.configureTestingModule({
      imports: [ListaCompras],
      providers: [{ provide: InventarioService, useValue: service }],
    }).compileComponents();
    fixture = TestBed.createComponent(ListaCompras);
    fixture.componentRef.setInput('sucursales', opciones.lista ?? sucursales);
    if (opciones.sucursalInicial) {
      fixture.componentRef.setInput('sucursalInicial', opciones.sucursalInicial);
    }
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
  }

  function element(): HTMLElement {
    return fixture.nativeElement as HTMLElement;
  }
  function filas(): HTMLTableRowElement[] {
    return Array.from(element().querySelectorAll('tbody tr'));
  }
  function cambiar(etiqueta: string, valor: string): void {
    const select = element().querySelector<HTMLSelectElement>(`select[aria-label="${etiqueta}"]`)!;
    select.value = valor;
    select.dispatchEvent(new Event('change'));
    fixture.detectChanges();
  }
  function boton(texto: string): HTMLButtonElement {
    return Array.from(element().querySelectorAll('button')).find((b) =>
      b.textContent?.includes(texto),
    )!;
  }

  beforeEach(() => service.listarPorComprar.mockReset());

  it('lists what to buy with the suggested amount, the reason and a summary', async () => {
    service.listarPorComprar.mockReturnValue(of([leche, bebida, pan]));
    await render();

    expect(service.listarPorComprar).toHaveBeenCalledWith(null, 7);
    expect(filas().map((fila) => fila.cells[0].textContent?.trim())).toEqual([
      'Leche entera Materia prima',
      'Chaparrita Producto',
      'Pan amasado Materia prima',
    ]);
    const [primera, segunda, tercera] = filas();
    expect(primera.querySelector('[data-label="Comprar"]')?.textContent?.trim()).toBe('4,75 L');
    // Se muestra lo vendido en el periodo, no el promedio diario.
    expect(primera.querySelector('[data-label="Vendido (7 días)"]')?.textContent?.trim()).toBe(
      '15,75 L',
    );
    expect(segunda.querySelector('[data-label="Vendido (7 días)"]')?.textContent?.trim()).toBe(
      '21 un',
    );
    expect(element().querySelector('thead')?.textContent).not.toContain('Consumo diario');
    expect(primera.textContent).toContain('Bajo el mínimo');
    expect(segunda.querySelector('[data-label="Comprar"]')?.textContent?.trim()).toBe('9 un');
    expect(segunda.textContent).toContain('Agotado');
    expect(tercera.textContent).toContain('No alcanza para mañana');

    const resumen = Array.from(element().querySelectorAll('.summary-card')).map(
      (tarjeta) =>
        `${tarjeta.querySelector('strong')?.textContent} ${tarjeta.querySelector('span')?.textContent}`,
    );
    expect(resumen).toEqual(['1 Agotados', '1 Bajo el mínimo', '1 No alcanzan para mañana']);
    expect(element().querySelector('.record-count')?.textContent?.trim()).toBe('3 artículos');
  });

  it('shows the branch column only when every branch is listed', async () => {
    service.listarPorComprar.mockReturnValue(of([leche, bebida]));
    await render();
    expect(element().querySelector('th')?.parentElement?.textContent).toContain('Sucursal');

    service.listarPorComprar.mockReturnValue(of([leche]));
    cambiar('Sucursal de la lista de compras', '1');
    await fixture.whenStable();
    fixture.detectChanges();
    expect(service.listarPorComprar).toHaveBeenLastCalledWith(1, 7);
    expect(element().querySelector('thead')?.textContent).not.toContain('Sucursal');
  });

  it('opens in the branch chosen in the stock panel', async () => {
    service.listarPorComprar.mockReturnValue(of([]));
    await render({ sucursalInicial: '2' });
    expect(service.listarPorComprar).toHaveBeenCalledWith(2, 7);
  });

  it('recalculates with the chosen sales period and names the column after it', async () => {
    service.listarPorComprar.mockReturnValue(of([leche]));
    await render();

    cambiar('Periodo de ventas', '1');
    await fixture.whenStable();
    fixture.detectChanges();
    expect(service.listarPorComprar).toHaveBeenLastCalledWith(null, 1);
    expect(element().querySelector('thead')?.textContent).toContain('Vendido (último día)');
    cambiar('Periodo de ventas', '30');
    await fixture.whenStable();
    expect(service.listarPorComprar).toHaveBeenLastCalledWith(null, 30);
  });

  it('says there is nothing to buy and disables the download', async () => {
    service.listarPorComprar.mockReturnValue(of([]));
    await render();

    expect(element().textContent).toContain('No hay nada por comprar.');
    expect(boton('Descargar Excel').disabled).toBe(true);
    expect(boton('CSV').disabled).toBe(true);
  });

  it('keeps the previous list while it refreshes after a stock change', async () => {
    const respuesta = new Subject<ArticuloPorComprar[]>();
    service.listarPorComprar.mockReturnValue(of([leche]));
    await render();

    service.listarPorComprar.mockReturnValue(respuesta);
    fixture.componentRef.setInput('version', 1);
    fixture.detectChanges();
    expect(filas()).toHaveLength(1);
    expect(element().querySelector('.skeleton')).toBeNull();

    respuesta.next([leche, bebida]);
    respuesta.complete();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(filas()).toHaveLength(2);
  });

  it('keeps the last list with a notice when a refresh fails', async () => {
    service.listarPorComprar.mockReturnValue(of([leche]));
    await render();

    service.listarPorComprar.mockReturnValue(throwError(() => new Error('sin red')));
    fixture.componentRef.setInput('version', 1);
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(filas()).toHaveLength(1);
    expect(element().textContent).toContain('No se pudo actualizar la lista');
  });

  it('offers a retry when the first load fails', async () => {
    service.listarPorComprar.mockReturnValueOnce(throwError(() => new Error('sin red')));
    await render();
    expect(element().textContent).toContain('No pudimos cargar la lista de compras');

    service.listarPorComprar.mockReturnValue(of([leche]));
    boton('Reintentar').click();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(filas()).toHaveLength(1);
  });

  it('explains when the role cannot read the list', async () => {
    service.listarPorComprar.mockReturnValue(
      throwError(() => new HttpErrorResponse({ status: 403 })),
    );
    await render();
    expect(element().textContent).toContain('Tu rol no tiene permiso para ver la lista de compras');
  });

  /** Captura el archivo y el nombre de la descarga sin que el navegador descargue nada. */
  function interceptarDescarga() {
    const descarga: { archivo?: Blob; nombre: string } = { nombre: '' };
    const espias = [
      vi.spyOn(URL, 'createObjectURL').mockImplementation((blob) => {
        descarga.archivo = blob as Blob;
        return 'blob:planilla';
      }),
      vi.spyOn(URL, 'revokeObjectURL').mockImplementation(() => undefined),
      vi.spyOn(HTMLAnchorElement.prototype, 'click').mockImplementation(function (
        this: HTMLAnchorElement,
      ) {
        descarga.nombre = this.download;
      }),
    ];
    return { descarga, restaurar: () => espias.forEach((espia) => espia.mockRestore()) };
  }

  it('downloads the visible list as an Excel workbook', async () => {
    service.listarPorComprar.mockReturnValue(of([leche, bebida]));
    await render();
    const { descarga, restaurar } = interceptarDescarga();

    boton('Descargar Excel').click();

    expect(descarga.nombre).toMatch(/^por-comprar_\d{4}-\d{2}-\d{2}\.xlsx$/);
    expect(descarga.archivo!.type).toBe(
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    );
    const bytes = new Uint8Array(await descarga.archivo!.arrayBuffer());
    expect([...bytes.slice(0, 4)]).toEqual([0x50, 0x4b, 0x03, 0x04]); // ZIP ("PK")
    const contenido = new TextDecoder().decode(bytes);
    expect(contenido).toContain('Leche entera');
    expect(contenido).toContain('Chaparrita');
    expect(URL.revokeObjectURL).toHaveBeenCalledWith('blob:planilla');
    expect(element().querySelector('a[download]')).toBeNull();
    restaurar();
  });

  it('also downloads it as CSV', async () => {
    service.listarPorComprar.mockReturnValue(of([leche, bebida]));
    await render();
    const { descarga, restaurar } = interceptarDescarga();

    boton('CSV').click();

    expect(descarga.nombre).toMatch(/^por-comprar_\d{4}-\d{2}-\d{2}\.csv$/);
    // BOM de UTF-8 al inicio, para que Excel lea bien las tildes.
    const bytes = new Uint8Array(await descarga.archivo!.arrayBuffer());
    expect([...bytes.slice(0, 3)]).toEqual([0xef, 0xbb, 0xbf]);
    const lineas = (await descarga.archivo!.text()).replace(/^\uFEFF/, '').split('\r\n');
    expect(lineas[0]).toBe(
      'Sucursal;Artículo;Tipo;Unidad;Stock actual;Mínimo;Vendido (7 días);Comprar;Motivo',
    );
    expect(lineas[1]).toBe(
      'Nury Providencia;Leche entera;Materia prima;L;1,5;4;15,75;4,75;Bajo el mínimo',
    );
    expect(lineas).toHaveLength(3);
    restaurar();
  });
});
