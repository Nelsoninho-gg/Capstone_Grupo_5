import { Component, signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { Desplegable } from './desplegable';

@Component({
  imports: [Desplegable],
  template: `<app-desplegable
    etiqueta="Ordenar por"
    prefijo="Ordenar por"
    [opciones]="opciones"
    [(valor)]="valor"
  />`,
})
class Anfitrion {
  opciones = [
    { valor: 'monto', etiqueta: 'Monto facturado' },
    { valor: 'unidades', etiqueta: 'Unidades vendidas' },
  ];
  valor = signal('monto');
}

describe('Desplegable', () => {
  function render() {
    const fixture = TestBed.createComponent(Anfitrion);
    fixture.detectChanges();
    const element = fixture.nativeElement as HTMLElement;
    const boton = () => element.querySelector<HTMLButtonElement>('.picker-button')!;
    const opciones = () =>
      Array.from(element.querySelectorAll<HTMLButtonElement>('[role="option"]'));
    const abrir = () => {
      boton().click();
      fixture.detectChanges();
    };
    return { fixture, element, boton, opciones, abrir };
  }

  it('shows the chosen option with its prefix and marks it in the list', () => {
    const { boton, opciones, abrir } = render();
    expect(boton().getAttribute('aria-label')).toBe('Ordenar por');
    expect(boton().textContent).toContain('Ordenar por: monto facturado');
    abrir();
    expect(opciones().map((o) => o.textContent?.trim())).toEqual([
      'Monto facturado',
      'Unidades vendidas',
    ]);
    expect(opciones()[0].getAttribute('aria-selected')).toBe('true');
  });

  it('chooses an option, updates the value and closes', () => {
    const { fixture, element, boton, opciones, abrir } = render();
    abrir();
    opciones()[1].click();
    fixture.detectChanges();
    expect(fixture.componentInstance.valor()).toBe('unidades');
    expect(boton().textContent).toContain('Ordenar por: unidades vendidas');
    expect(element.querySelector('[role="listbox"]')).toBeNull();
  });

  it('closes with Escape or a click outside', () => {
    const { fixture, element, abrir } = render();
    abrir();
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape' }));
    fixture.detectChanges();
    expect(element.querySelector('[role="listbox"]')).toBeNull();
    abrir();
    document.body.click();
    fixture.detectChanges();
    expect(element.querySelector('[role="listbox"]')).toBeNull();
  });
});
