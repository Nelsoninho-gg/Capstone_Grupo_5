import { describe, expect, it } from 'vitest';
import {
  MovimientoConsumo,
  claveSerieConsumo,
  construirSeriesOperativas,
  PuntoConsumoDiario,
  calcularCuartiles,
  calcularMediaYDesviacion,
  construirPayloadHistoricoIA,
  depurarSerieConsumo,
} from './analisis-historico.model';
import { ArticuloPredictivo } from './prediccion.model';

describe('analisis-historico.model (H4.5 T04)', () => {
  const serieBaseNormal: PuntoConsumoDiario[] = Array.from({ length: 28 }, (_, i) => ({
    fecha: `2026-10-${String(i + 1).padStart(2, '0')}`,
    cantidad: i % 2 === 0 ? 10 : 12, // Promedio base esperado: 11
  }));

  it('calcula correctamente media, desviación estándar y cuartiles en una serie uniforme', () => {
    const valores = [10, 12, 10, 12, 10, 12, 10, 12];
    const stats = calcularMediaYDesviacion(valores);
    expect(stats.media).toBe(11);
    expect(stats.desviacion).toBe(1);

    const cuartiles = calcularCuartiles(valores);
    expect(cuartiles.mediana).toBe(11);
    expect(cuartiles.q1).toBe(10);
    expect(cuartiles.q3).toBe(12);
    expect(cuartiles.iqr).toBe(2);
  });

  it('detecta y atenúa un pico estadístico extremo (outlier) sin contaminar el promedio base', () => {
    const serieConOutlier: PuntoConsumoDiario[] = [
      ...serieBaseNormal,
      { fecha: '2026-10-29', cantidad: 120 }, // Pico extremo no etiquetado (6x-10x lo normal)
    ];

    const resultado = depurarSerieConsumo(serieConOutlier, 'atenuar');

    expect(resultado.picosDetectados).toHaveLength(1);
    expect(resultado.picosDetectados[0]).toMatchObject({
      fecha: '2026-10-29',
      cantidadOriginal: 120,
      cantidadTratada: 11,
      motivo: 'anomalia-estadistica',
    });

    // El promedio crudo estaría inflado (~14.76), pero el promedio limpio se mantiene en 11
    expect(resultado.promedioCrudo).toBeGreaterThan(14);
    expect(resultado.promedioBaseLimpio).toBe(11);
    expect(resultado.serieDepurada).toHaveLength(29);
    expect(resultado.serieDepurada[28].cantidad).toBe(11);
  });

  it('detecta y excluye picos originados por promociones y eventos puntuales en sede universitaria', () => {
    const serieConEventos: PuntoConsumoDiario[] = [
      ...serieBaseNormal,
      {
        fecha: '2026-10-29',
        cantidad: 45,
        esPromocion: true,
        nota: 'Promo 2x1 Capuccino',
      },
      {
        fecha: '2026-10-30',
        cantidad: 60,
        esEventoEspecial: true,
        nota: 'Feria bienvenida universitaria',
      },
    ];

    const resultado = depurarSerieConsumo(serieConEventos, 'excluir');

    expect(resultado.picosDetectados).toHaveLength(2);
    expect(resultado.picosDetectados[0].motivo).toBe('promocion');
    expect(resultado.picosDetectados[0].cantidadTratada).toBeNull();
    expect(resultado.picosDetectados[1].motivo).toBe('evento-puntual');
    expect(resultado.picosDetectados[1].detalle).toBe('Feria bienvenida universitaria');

    // Al excluir los 2 días de pico, quedan los 28 días normales con promedio 11
    expect(resultado.serieDepurada).toHaveLength(28);
    expect(resultado.promedioBaseLimpio).toBe(11);
  });

  it('maneja series vacías sin errores', () => {
    const vacio = depurarSerieConsumo([]);
    expect(vacio.serieDepurada).toEqual([]);
    expect(vacio.picosDetectados).toEqual([]);
    expect(vacio.promedioBaseLimpio).toBe(0);
    expect(vacio.promedioCrudo).toBe(0);
  });

  it('estructura el PayloadHistoricoIA separando consumo base limpio y picos aislados', () => {
    const articulo: ArticuloPredictivo = {
      id: 'pred-leche-prov',
      articulo: 'Leche Entera Fresca',
      tipo: 'materia_prima',
      sucursalId: 1,
      sucursal: 'Nury Providencia',
      stockActual: 25,
      stockMinimo: 20,
      unidad: 'l',
      diasHistorial: 30,
      consumoDiarioBase: 11,
    };

    const serie: PuntoConsumoDiario[] = [
      ...serieBaseNormal,
      {
        fecha: '2026-10-29',
        cantidad: 55,
        esPromocion: true,
        nota: 'Día del Café',
      },
      {
        fecha: '2026-10-30',
        cantidad: 95,
      },
    ];

    const payload = construirPayloadHistoricoIA(articulo, serie, 'atenuar');

    expect(payload.articuloId).toBe('pred-leche-prov');
    expect(payload.aptoParaPredecir).toBe(true);
    expect(payload.metricasConsumo.promedioDiarioBase).toBe(11);
    expect(payload.metricasConsumo.promedioDiarioSinFiltrar).toBeGreaterThan(15);
    expect(payload.metricasConsumo.diasNormalesContabilizados).toBe(28);
    expect(payload.metricasConsumo.totalPicosAislados).toBe(2);
    expect(payload.picosAislados).toEqual([
      {
        fecha: '2026-10-29',
        cantidad: 55,
        motivo: 'promocion',
        nota: 'Día del Café',
      },
      expect.objectContaining({
        fecha: '2026-10-30',
        cantidad: 95,
        motivo: 'anomalia-estadistica',
      }),
    ]);
  });

  it('marca aptoParaPredecir en false si el artículo no alcanza las 4 semanas (28 días)', () => {
    const articuloNuevo: ArticuloPredictivo = {
      id: 'pred-matcha',
      articulo: 'Té Matcha Japonés',
      tipo: 'materia_prima',
      sucursalId: 1,
      sucursal: 'Nury Providencia',
      stockActual: 2,
      stockMinimo: 1,
      unidad: 'kg',
      diasHistorial: 10,
      consumoDiarioBase: 0.2,
    };

    const serieCorta = serieBaseNormal.slice(0, 10);
    const payload = construirPayloadHistoricoIA(articuloNuevo, serieCorta);

    expect(payload.diasHistorial).toBe(10);
    expect(payload.aptoParaPredecir).toBe(false);
  });
});

describe('construirSeriesOperativas', () => {
  const mov = (fecha: string, cantidad: number, articuloId = 1, tipo = 'venta', sucursalId = 1): MovimientoConsumo => ({
    tipo_articulo: 'materia_prima',
    articulo_id: articuloId,
    sucursal_id: sucursalId,
    tipo_movimiento: tipo,
    cantidad,
    fecha,
  });

  it('suma el consumo neto del día en hora de Chile, con venta, anulación y merma', () => {
    const series = construirSeriesOperativas([
      mov('2026-10-05T15:00:00+00:00', -5),
      mov('2026-10-05T16:00:00+00:00', 2, 1, 'anulacion_venta'),
      mov('2026-10-05T17:00:00+00:00', -1, 1, 'merma'),
      mov('2026-10-05T18:00:00+00:00', 50, 1, 'ingreso_factura'),
      // 01:00 UTC del día 6 sigue siendo el día 5 en Chile
      mov('2026-10-06T01:00:00+00:00', -1),
    ]);
    expect(series.get(claveSerieConsumo('materia_prima', 1, 1))).toEqual([{ fecha: '2026-10-05', cantidad: 5 }]);
  });

  it('un día sin actividad de la sucursal no entra; un día con ventas de otro artículo cuenta como cero', () => {
    const series = construirSeriesOperativas([
      mov('2026-10-05T15:00:00+00:00', -4, 1), // lunes
      mov('2026-10-06T15:00:00+00:00', -9, 2), // martes: solo se vendió otro artículo
      mov('2026-10-12T15:00:00+00:00', -4, 1), // lunes siguiente: la semana cerrada no aparece
    ]);
    expect(series.get(claveSerieConsumo('materia_prima', 1, 1))).toEqual([
      { fecha: '2026-10-05', cantidad: 4 },
      { fecha: '2026-10-06', cantidad: 0 },
      { fecha: '2026-10-12', cantidad: 4 },
    ]);
  });

  it('los días cerrados no bajan el promedio ni generan atípicos', () => {
    // Lunes a viernes durante 4 semanas, sin ventas el fin de semana.
    const movimientos: MovimientoConsumo[] = [];
    for (let semana = 0; semana < 4; semana++) {
      for (let dia = 0; dia < 5; dia++) {
        const fecha = new Date(Date.UTC(2026, 9, 5 + semana * 7 + dia, 15));
        movimientos.push(mov(fecha.toISOString(), -10));
      }
    }
    const serie = construirSeriesOperativas(movimientos).get(claveSerieConsumo('materia_prima', 1, 1))!;
    const depuracion = depurarSerieConsumo(serie);

    expect(serie).toHaveLength(20);
    expect(depuracion.promedioBaseLimpio).toBe(10);
    expect(depuracion.picosDetectados).toEqual([]);
  });

  it('no mezcla sucursales', () => {
    const series = construirSeriesOperativas([
      mov('2026-10-05T15:00:00+00:00', -4, 1, 'venta', 1),
      mov('2026-10-06T15:00:00+00:00', -4, 1, 'venta', 2),
    ]);
    expect(series.get(claveSerieConsumo('materia_prima', 1, 1))).toEqual([{ fecha: '2026-10-05', cantidad: 4 }]);
    expect(series.get(claveSerieConsumo('materia_prima', 1, 2))).toEqual([{ fecha: '2026-10-06', cantidad: 4 }]);
  });

  it('es determinista: los mismos movimientos entregan la misma serie', () => {
    const movimientos = [mov('2026-10-05T15:00:00+00:00', -4)];
    expect(construirSeriesOperativas(movimientos)).toEqual(construirSeriesOperativas(movimientos));
  });
});

describe('depurarSerieConsumo con días mayormente en cero', () => {
  it('no descarta ventas normales cuando hay menos de 4 días con venta', () => {
    const serie = [0, 0, 0, 0, 3, 0, 0, 2].map((cantidad, i) => ({
      fecha: `2026-10-${10 + i}`,
      cantidad,
    }));
    const depuracion = depurarSerieConsumo(serie);
    expect(depuracion.picosDetectados).toEqual([]);
    expect(depuracion.promedioBaseLimpio).toBe(0.63);
  });

  it('no descarta ventas normales cuando hay 4 o más días con venta de magnitud similar', () => {
    const serie = [0, 0, 2, 0, 3, 0, 2, 0, 3, 0].map((cantidad, i) => ({
      fecha: `2026-10-${10 + i}`,
      cantidad,
    }));
    const depuracion = depurarSerieConsumo(serie);
    expect(depuracion.picosDetectados).toEqual([]);
    expect(depuracion.promedioBaseLimpio).toBe(1);
  });

  it('detecta un pico midiendo solo contra los días con venta (mínimo 4) y lo atenúa a la mediana de esos días', () => {
    const ventas = [0, 0, 2, 0, 3, 0, 2, 0, 3, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0];
    const serie = ventas.map((cantidad, i) => ({ fecha: `2026-10-${10 + i}`, cantidad }));
    const depuracion = depurarSerieConsumo(serie);
    expect(depuracion.picosDetectados).toEqual([
      expect.objectContaining({
        cantidadOriginal: 100,
        cantidadTratada: 3,
        motivo: 'anomalia-estadistica',
      }),
    ]);
    expect(depuracion.promedioBaseLimpio).toBe(0.65);

  });
});
