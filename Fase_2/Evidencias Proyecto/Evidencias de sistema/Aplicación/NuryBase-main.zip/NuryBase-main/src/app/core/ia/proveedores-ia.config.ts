import { InjectionToken } from '@angular/core';
import { environment } from '../../../environments/environment';

export type FormatoProveedorIA = 'gemini' | 'openai-compatible';
export type AutenticacionProveedorIA = 'sesion-nury' | 'api-key';

export interface ProveedorIAConfig {
  id: string;
  formato: FormatoProveedorIA;
  modelo: string;
  baseUrl: string;
  autenticacion: AutenticacionProveedorIA;
  apiKey?: string;
  timeoutMs?: number;
}

export interface MensajesIA {
  sistema: string;
  usuario: string;
}

/**
 * Cadena priorizada de modelos con capa gratuita a través del proxy inverso Caddy en api.nury.cl.
 * Caddy guarda las claves y exige una sesión de admin o bodeguero en las rutas /ia/*.
 */
export const PROVEEDORES_IA_NURY: readonly ProveedorIAConfig[] = [
  {
    id: 'gemini-3.5-flash-lite',
    formato: 'gemini',
    modelo: 'gemini-3.5-flash-lite',
    baseUrl: `${environment.apiUrl}/ia/gemini/v1beta`,
    autenticacion: 'sesion-nury',
    timeoutMs: 15000,
  },
  {
    id: 'gemini-3.1-flash-lite',
    formato: 'gemini',
    modelo: 'gemini-3.1-flash-lite',
    baseUrl: `${environment.apiUrl}/ia/gemini/v1beta`,
    autenticacion: 'sesion-nury',
    timeoutMs: 15000,
  },
  {
    id: 'gemma',
    formato: 'gemini',
    // La 26b respondió en 5 s y la 31b en 26 s. Ambas devuelven HTTP 500 con frecuencia.
    modelo: 'gemma-4-26b-a4b-it',
    baseUrl: `${environment.apiUrl}/ia/gemini/v1beta`,
    autenticacion: 'sesion-nury',
    timeoutMs: 20000,
  },
  {
    id: 'nemotron',
    formato: 'openai-compatible',
    modelo: 'nvidia/nemotron-3.5-super-vl:free',
    baseUrl: `${environment.apiUrl}/ia/openrouter/api/v1`,
    autenticacion: 'sesion-nury',
    // Razona antes de responder: 32 s medidos con 5 artículos.
    timeoutMs: 60000,
  },
];

/**
 * Proveedores configurados para el orquestador de IA.
 * Vacío por defecto para que las pruebas nunca llamen a la red; app.config.ts entrega PROVEEDORES_IA_NURY.
 */
export const IA_PROVEEDORES = new InjectionToken<readonly ProveedorIAConfig[]>(
  'IA_PROVEEDORES',
  { providedIn: 'root', factory: () => [] },
);

/**
 * Reloj inyectable para el cálculo de enfriamiento y pruebas de tiempo.
 */
export const IA_RELOJ = new InjectionToken<() => number>(
  'IA_RELOJ',
  { providedIn: 'root', factory: () => () => Date.now() },
);
