import { CommonModule, DecimalPipe } from '@angular/common';
import {
  Component,
  ElementRef,
  HostListener,
  OnDestroy,
  OnInit,
  ViewChild,
  computed,
  inject,
  linkedSignal,
  signal,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../../auth/services/auth.service';
import { AppLoaderService } from '../../../../core/services/app-loader.service';
import { BarcodeScanner } from '../../../../core/services/barcode-scanner';
import { AppIconComponent } from '../../../../shared/components/app-icon/app-icon.component';
import { CoffeeLoader, LoadStatus } from '../../../../shared/components/coffee-loader/coffee-loader';
import { PaymentModalComponent } from '../../components/payment-modal/payment-modal.component';
import { posIconPath } from '../../models/pos-icons';
import { desglosarIva } from '../../../../shared/utils/iva';
import { CartItem, CompletedSale, PosProduct } from '../../models/pos.model';
import { PromocionApi } from '../../../../core/api/promociones-api.service';
import { esCombo, textoDescuento } from '../../../gestion-negocio/models/promocion';
import { DESCUENTO_EMPLEADO_PORCENTAJE, PosService } from '../../services/pos.service';
import { preciosPromocion } from '../../models/promocion-pos';

/** Tarjeta de la grilla del catálogo: una promoción o un producto. */
type ItemCatalogo =
  | { tipo: 'promocion'; clave: string; promocion: PromocionApi }
  | { tipo: 'producto'; clave: string; producto: PosProduct };

@Component({
  selector: 'app-pos-layout',
  standalone: true,
  imports: [CommonModule, FormsModule, PaymentModalComponent, CoffeeLoader, AppIconComponent],
  templateUrl: './pos-layout.component.html',
  styleUrl: './pos-layout.component.css',
})



export class PosLayoutComponent implements OnInit, OnDestroy {

  @ViewChild('barcodeVideo') private barcodeVideo?: ElementRef<HTMLVideoElement>;

  readonly posService = inject(PosService);
  readonly authService = inject(AuthService);
  private readonly barcodeScanner = inject(BarcodeScanner);
  private readonly router = inject(Router, { optional: true });

  readonly categories = this.posService.categories;
  readonly catalog = this.posService.catalog;
  readonly cart = this.posService.cart;
  readonly total = this.posService.total;
  /** Neto = total ÷ 1,19; el IVA es la diferencia, así ambos suman el total. */
  protected readonly desglosarIva = desglosarIva;
  readonly subtotal = this.posService.subtotal;
  readonly descuento = this.posService.descuento;
  // Promociones vigentes de la sucursal (H5.2 T05). El descuento no se edita aquí.
  readonly promocionesVigentes = this.posService.promocionesVigentes;
  readonly promocionesStatus = this.posService.promocionesStatus;
  readonly promocionesAplicadas = this.posService.promocionesAplicadas;
  readonly descuentoPromociones = this.posService.descuentoPromociones;
  /** Aplicadas que dejaron de estar vigentes desde que se agregaron: la venta se rechazaría. */
  readonly promocionesVencidas = computed(() => {
    if (this.promocionesStatus() !== 'ready') return [];
    const vigentes = new Set(this.promocionesVigentes().map((p) => p.id));
    return this.promocionesAplicadas()
      .filter((a) => !vigentes.has(a.promocion.id))
      .map((a) => a.promocion.nombre);
  });
  readonly comandaVacia = computed(
    () => this.cart().length === 0 && this.promocionesAplicadas().length === 0,
  );
  readonly descuentoEmpleadoPorcentaje = DESCUENTO_EMPLEADO_PORCENTAJE;
  readonly ventaEmpleado = this.posService.ventaEmpleado;
  readonly empleados = this.posService.empleados;
  readonly empleadosStatus = this.posService.empleadosStatus;
  readonly empleadoSeleccionado = this.posService.empleadoSeleccionado;
  readonly faltaEmpleado = this.posService.faltaEmpleado;
  readonly totalItemsCount = this.posService.totalItemsCount;
  readonly currentUser = this.authService.currentUser;

  readonly selectedCategoryId = signal<string>('');
  /** Filtro «Promociones»: la grilla muestra solo las tarjetas de promoción. */
  readonly soloEnPromocion = signal(false);
  /** Si las promociones terminan, el filtro se apaga solo en vez de dejar la grilla vacía. */
  readonly filtroPromocion = computed(
    () => this.soloEnPromocion() && this.promocionesVigentes().length > 0,
  );
  readonly searchQuery = signal<string>('');
  readonly quickBarcodeInput = signal<string>('');
  readonly barcodeFeedback = signal<string | null>(null);
  readonly isScannerOpen = signal(false);
  readonly scannerError = signal<string | null>(null);
  readonly scannerFeedback = signal<string | null>(null);
  private barcodeFeedbackTimer?: ReturnType<typeof setTimeout>;
  readonly isRegisterOpen = this.posService.isRegisterOpen;

  // Control del modal de pago (H2.4)
  readonly isPaymentModalOpen = signal<boolean>(false);
  readonly lastCompletedSale = signal<CompletedSale | null>(null);

  // Comanda como modal en celulares (en escritorio siempre está visible a la derecha)
  readonly isCartSheetOpen = signal<boolean>(false);

  // Carga del catálogo con la taza de café. Si ya hay productos (se volvió al
  // POS), se refresca en segundo plano sin mostrar la taza.
  readonly catalogLoaderStatus = computed<LoadStatus>(() =>
    this.catalog().length > 0 ? 'ready' : this.posService.catalogStatus(),
  );
  // Recién iniciada la sesión, el catálogo se suma a la taza de pantalla
  // completa (una sola taza y un solo soplido); si no, se muestra sobre el catálogo.
  readonly usesAppLoader: boolean;

  // Reloj digital en vivo
  readonly currentTime = signal<string>(new Date().toLocaleTimeString('es-CL'));
  private readonly timerId: ReturnType<typeof setInterval>;
  /** Las promociones empiezan y terminan solas: se revisan cada minuto, sin recargar. */
  private readonly promocionesTimerId: ReturnType<typeof setInterval>;

  constructor() {
    this.usesAppLoader = inject(AppLoaderService).join(this.catalogLoaderStatus, () =>
      this.reloadCatalog(),
    );
    this.timerId = setInterval(() => {
      this.currentTime.set(new Date().toLocaleTimeString('es-CL'));
    }, 1000);
    this.promocionesTimerId = setInterval(() => this.posService.recargarPromociones(), 60_000);
  }

  reloadCatalog(): void {
    this.posService.cargarCatalogoDesdeApi();
  }

  ngOnInit(): void {
    this.reloadCatalog();
    this.sincronizarTurno();
    const sucursalId = this.currentUser()?.sucursalId;
    if (sucursalId) this.posService.cargarPromociones(sucursalId);
  }

  /** Productos de la promoción, como "1 × Sándwich + 1 × Café". */
  productosDePromocion(promocion: PromocionApi): string {
    return promocion.productos
      .map((linea) => `${linea.cantidad} × ${linea.producto?.nombre ?? 'Producto'}`)
      .join(' + ');
  }

  descuentoDePromocion(promocion: PromocionApi): string {
    return textoDescuento(promocion.tipo, promocion.valor_descuento);
  }

  /** "−20 %" o "−$1.000", para la tarjeta del producto. */
  descuentoCorto(promocion: PromocionApi): string {
    const valor = Number(promocion.valor_descuento);
    return promocion.tipo === 'porcentaje'
      ? `−${valor.toLocaleString('es-CL')} %`
      : `−${this.formatClp(valor)}`;
  }

  /** Promoción de un solo producto que rige para este producto, con su precio rebajado. */
  rebajaDe(producto: PosProduct): { promocion: PromocionApi; precio: number } | undefined {
    return this.posService.promocionDeProducto().get(producto.id);
  }

  /** Promociones vigentes que incluyen el producto. */
  promocionesDe(producto: PosProduct): PromocionApi[] {
    return this.posService.promocionesPorProducto().get(producto.id) ?? [];
  }

  /** Precio normal y precio con descuento de una aplicación de la promoción; null si no se puede aplicar. */
  precioPromocion(promocion: PromocionApi): { lista: number; final: number } | null {
    const precios = preciosPromocion(promocion, this.posService.catalogoPorId());
    if (!precios) return null;
    return precios.reduce(
      (suma, p) => ({
        lista: suma.lista + p.precioLista * p.cantidad,
        final: suma.final + p.precioUnitario * p.cantidad,
      }),
      { lista: 0, final: 0 },
    );
  }

  alternarFiltroPromocion(): void {
    this.soloEnPromocion.set(!this.filtroPromocion());
  }

  /** Agrega a la comanda todos los productos de la promoción con su descuento. */
  agregarPromocion(promocion: PromocionApi): void {
    if (!this.isRegisterOpen()) return;
    if (!this.posService.sePuedeAplicar(promocion)) {
      this.showBarcodeFeedback(`❌ «${promocion.nombre}» tiene productos que no están en el catálogo.`);
      return;
    }
    this.posService.aplicarPromocion(promocion);
    this.showBarcodeFeedback(
      `Promoción «${promocion.nombre}» agregada: ${this.productosDePromocion(promocion)}`,
    );
  }

  /** Líneas de la comanda que aporta una promoción aplicada. */
  lineasDe(promocionId: number): CartItem[] {
    return this.posService.lineasPromocion().filter((item) => item.promocion?.id === promocionId);
  }

  descuentoDe(promocionId: number): number {
    return this.lineasDe(promocionId).reduce(
      (suma, item) => suma + item.producto.precioVenta * item.cantidad - item.subtotal,
      0,
    );
  }

  sincronizarTurno(): void {
    this.posService.sincronizarTurno().subscribe({ error: () => {} });
  }

  ngOnDestroy(): void {
    if (this.timerId) {
      clearInterval(this.timerId);
    }
    clearInterval(this.promocionesTimerId);
    this.barcodeScanner.stop();
    clearTimeout(this.barcodeFeedbackTimer);
  }

  // Catálogo filtrado por categoría y búsqueda de texto (H2.2)
  readonly filteredCatalog = computed<PosProduct[]>(() => {
    let list = this.catalog().filter((p) => p.activo);
    const catId = this.selectedCategoryId();
    const query = this.normalizeSearch(this.searchQuery());

    if (catId !== '') {
      list = list.filter((p) => this.posService.categoryGroupOf(p) === catId);
    }

    // La categoría original también se busca: al unificar pestañas, escribir
    // "empanada" sigue encontrando todo lo de "ALIMENTOS - EMPANADAS".
    if (query) {
      list = list.filter((p) =>
        [p.nombre, p.codigoInterno, p.codigoBarras, p.descripcion, p.categoriaNombre].some((value) =>
          this.normalizeSearch(value).includes(query),
        ),
      );
    }

    return list;
  });

  /**
   * Promociones vigentes con la misma categoría y búsqueda que los productos: entra si alguno
   * de sus productos es de la categoría, y se busca por su nombre o el de sus productos.
   */
  readonly promocionesFiltradas = computed<PromocionApi[]>(() => {
    const catId = this.selectedCategoryId();
    const query = this.normalizeSearch(this.searchQuery());
    const catalogo = this.posService.catalogoPorId();
    return this.promocionesVigentes().filter((promocion) => {
      if (
        catId !== '' &&
        !promocion.productos.some((linea) => {
          const producto = catalogo.get(linea.producto_id);
          return producto && this.posService.categoryGroupOf(producto) === catId;
        })
      ) {
        return false;
      }
      return (
        !query ||
        [promocion.nombre, ...promocion.productos.map((linea) => linea.producto?.nombre ?? '')].some(
          (valor) => this.normalizeSearch(valor).includes(query),
        )
      );
    });
  });

  /**
   * La grilla: primero las tarjetas de los combos y luego los productos (con el filtro, solo los
   * combos y los productos rebajados). Una promoción de un solo producto va en su tarjeta.
   */
  readonly itemsCatalogo = computed<ItemCatalogo[]>(() => [
    ...this.promocionesFiltradas()
      .filter(esCombo)
      .map(
        (promocion): ItemCatalogo => ({ tipo: 'promocion', clave: `promo-${promocion.id}`, promocion }),
      ),
    ...(this.filtroPromocion()
      ? this.filteredCatalog().filter((p) => this.posService.promocionDeProducto().has(p.id))
      : this.filteredCatalog()
    ).map(
      (producto): ItemCatalogo => ({ tipo: 'producto', clave: `prod-${producto.id}`, producto }),
    ),
  ]);

  readonly catalogPageSize = 12;
  readonly catalogPage = linkedSignal({
    source: this.itemsCatalogo,
    computation: () => 1,
  });
  readonly catalogTotalPages = computed(() =>
    Math.max(1, Math.ceil(this.itemsCatalogo().length / this.catalogPageSize)),
  );
  readonly paginatedCatalog = computed(() => {
    const start = (this.catalogPage() - 1) * this.catalogPageSize;
    return this.itemsCatalogo().slice(start, start + this.catalogPageSize);
  });

  changeCatalogPage(offset: number): void {
    this.catalogPage.update((page) =>
      Math.max(1, Math.min(page + offset, this.catalogTotalPages())),
    );
  }

  selectCategory(catId: string): void {
    this.selectedCategoryId.set(catId);
  }

  private normalizeSearch(value: string): string {
    return value
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .trim()
      .toLowerCase();
  }

  getCategoryCount(catId: string): number {
    return this.catalog().filter(
      (p) => p.activo && (catId === '' || this.posService.categoryGroupOf(p) === catId),
    ).length;
  }

  addProduct(product: PosProduct): void {
    if (!this.isRegisterOpen()) return;
    this.posService.addToCart(product);
  }

  // Entrada rápida por escáner de código de barras o código interno (H2.1 & H2.3)
  onBarcodeScan(): void {
    if (!this.isRegisterOpen()) {
      this.showBarcodeFeedback('❌ La caja está cerrada. Ábrela para registrar productos.');
      return;
    }
    const code = this.quickBarcodeInput().trim();
    if (!code) return;

    const added = this.posService.addByCode(code);
    if (added) {
      const item = this.cart().find(({ producto }) =>
        producto.codigoInterno.toLowerCase() === code.toLowerCase() ||
        producto.codigoBarras === code,
      );
      this.showBarcodeFeedback(
        `✅ ${item?.producto.nombre ?? code.toUpperCase()} agregado al carrito. ` +
        `Código ${code.toUpperCase()}. Cantidad en carrito: ${item?.cantidad ?? 1}.`,
      );
      this.quickBarcodeInput.set('');
    } else {
      this.showBarcodeFeedback(`❌ Código ${code.toUpperCase()} no encontrado en catálogo.`);
    }
  }

  private showBarcodeFeedback(message: string): void {
    if (this.isScannerOpen()) this.scannerFeedback.set(message);
    this.barcodeFeedback.set(message);
    clearTimeout(this.barcodeFeedbackTimer);
    this.barcodeFeedbackTimer = setTimeout(() => {
      this.barcodeFeedback.set(null);
    }, 2500);
  }

  onVentaEmpleadoChange(event: Event): void {
    this.posService.setVentaEmpleado((event.target as HTMLInputElement).checked);
  }

  onEmpleadoChange(event: Event): void {
    const value = (event.target as HTMLSelectElement).value;
    this.posService.seleccionarEmpleado(value ? Number(value) : null);
  }

  openPayment(): void {
    if (this.isRegisterOpen() && this.total() > 0 && !this.faltaEmpleado()) {
      this.isCartSheetOpen.set(false);
      this.isPaymentModalOpen.set(true);
    }
  }

  // En celular la comanda vive oculta y se abre como modal desde el botón flotante.
  openCartSheet(): void {
    this.isCartSheetOpen.set(true);
  }

  @HostListener('document:keydown.escape')
  closeCartSheet(): void {
    this.isCartSheetOpen.set(false);
  }

  goToCaja(): void {
    this.router?.navigate(['/caja']);
  }

  openBarcodeScanner(): void {
    if (this.isScannerOpen()) return;
    if (!this.isRegisterOpen()) {
      this.barcodeFeedback.set('❌ La caja está cerrada. Ábrela para registrar productos.');
      return;
    }

    this.scannerError.set(null);
    this.scannerFeedback.set(null);
    this.isScannerOpen.set(true);

    // The video element is created by the @if block on the next change-detection pass.
    setTimeout(() => void this.startBarcodeScanner(), 0);
  }

  closeBarcodeScanner(): void {
    this.barcodeScanner.stop();
    this.isScannerOpen.set(false);
  }

  private async startBarcodeScanner(): Promise<void> {
    const videoElement = this.barcodeVideo?.nativeElement;
    if (!videoElement || !this.isScannerOpen()) return;

    try {
      await this.barcodeScanner.start(
        videoElement,
        (code) => {
          if (!this.isScannerOpen()) return;
          this.quickBarcodeInput.set(code);
          this.onBarcodeScan();
        },
        (error) => {
          if (!this.isScannerOpen()) return;
          console.error('No se pudo iniciar la cámara para escanear', error);
          this.scannerError.set(this.getScannerErrorMessage(error));
        },
      );
    } catch {
      // The user-facing message is set by the error callback above.
    }
  }

  private getScannerErrorMessage(error: unknown): string {
    if (error instanceof DOMException && error.name === 'NotAllowedError') {
      return 'Debes permitir el acceso a la cámara para escanear.';
    }
    if (error instanceof DOMException && error.name === 'NotFoundError') {
      return 'No se encontró una cámara disponible en este dispositivo.';
    }
    return 'No fue posible iniciar la cámara. Verifica los permisos y que estés usando HTTPS.';
  }

  closePayment(): void {
    this.isPaymentModalOpen.set(false);
  }

  onSaleFinished(sale: CompletedSale): void {
    this.lastCompletedSale.set(sale);
  }

  readonly iconPath = posIconPath;

  formatClp(amount: number): string {
    return new Intl.NumberFormat('es-CL', {
      style: 'currency',
      currency: 'CLP',
      maximumFractionDigits: 0,
    }).format(amount);
  }
}
