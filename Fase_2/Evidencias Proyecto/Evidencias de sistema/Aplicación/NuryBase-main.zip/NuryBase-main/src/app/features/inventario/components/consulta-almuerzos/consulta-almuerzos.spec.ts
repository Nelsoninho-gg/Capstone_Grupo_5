import { HttpErrorResponse } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { of, throwError } from 'rxjs';
import {
  AlmuerzoConsultaApi,
  AlmuerzosApiService,
  FiltroAlmuerzos,
} from '../../../../core/api/almuerzos-api.service';
import { SucursalesApiService } from '../../../../core/api/sucursales-api.service';
import { UsuariosApiService } from '../../../../core/api/usuarios-api.service';
import { ConsultaAlmuerzos, almuerzoConsultado } from './consulta-almuerzos';

function fila(
  id: number,
  empleado: string,
  detalle: [string, number][],
  fecha = '2026-10-29',
): AlmuerzoConsultaApi {
  return {
    id,
    fecha,
    creado_en: `${fecha}T16:05:00`,
    sucursal_id: 1,
    empleado_id: id * 10,
    sucursal: { nombre: 'Nury Providencia' },
    empleado: { nombre: empleado },
    cajero: { nombre: 'Camila Rojas' },
    detalle: detalle.map(([nombre, cantidad]) => ({ cantidad, producto: { nombre } })),
  };
}

describe('almuerzoConsultado', () => {
  it('describes the lunch with its products and total units', () => {
    const almuerzo = almuerzoConsultado(fila(1, 'Pedro Soto', [['Menú del día', 1], ['Jugo', 2]]));

    expect(almuerzo.empleado).toBe('Pedro Soto');
    expect(almuerzo.cajero).toBe('Camila Rojas');
    expect(almuerzo.productos).toEqual([
      { nombre: 'Menú del día', cantidad: 1 },
      { nombre: 'Jugo', cantidad: 2 },
    ]);
    expect(almuerzo.unidades).toBe(3);
    // creado_en llega en UTC sin zona.
    expect(almuerzo.registradoEn.toISOString()).toBe('2026-10-29T16:05:00.000Z');
  });

  it('reads PostgREST numerics sent as text and tolerates missing relations', () => {
    const almuerzo = almuerzoConsultado({
      ...fila(2, 'x', []),
      empleado: null,
      cajero: null,
      detalle: [{ cantidad: '1.000', producto: null }],
    });

    expect(almuerzo.empleado).toBe('Usuario #20');
    expect(almuerzo.cajero).toBe('—');
    expect(almuerzo.productos).toEqual([{ nombre: 'Producto eliminado', cantidad: 1 }]);
  });
});

describe('ConsultaAlmuerzos', () => {
  let fixture: ComponentFixture<ConsultaAlmuerzos>;
  const almuerzosApi = { listar: vi.fn() };
  const sucursalesApi = {
    listarActivas: vi.fn(() =>
      of([
        { id: 1, nombre: 'Nury Providencia' },
        { id: 2, nombre: 'Nury Ñuñoa' },
      ]),
    ),
  };
  const usuariosApi = {
    listarEmpleados: vi.fn(() =>
      of([
        { id: 10, nombre: 'Pedro Soto' },
        { id: 20, nombre: 'Ana Díaz' },
      ]),
    ),
  };

  async function render(): Promise<void> {
    await TestBed.configureTestingModule({
      imports: [ConsultaAlmuerzos],
      providers: [
        { provide: AlmuerzosApiService, useValue: almuerzosApi },
        { provide: SucursalesApiService, useValue: sucursalesApi },
        { provide: UsuariosApiService, useValue: usuariosApi },
      ],
    }).compileComponents();
    fixture = TestBed.createComponent(ConsultaAlmuerzos);
    await estable();
  }

  async function estable(): Promise<void> {
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
  }

  function element(): HTMLElement {
    return fixture.nativeElement as HTMLElement;
  }
  async function cambiar(selector: string, valor: string): Promise<void> {
    const control = element().querySelector(selector) as HTMLSelectElement | HTMLInputElement;
    control.value = valor;
    control.dispatchEvent(new Event('change'));
    await estable();
  }
  function texto(selector: string): string {
    return (element().querySelector(selector)?.textContent ?? '').replace(/\s+/g, ' ').trim();
  }
  function ultimaConsulta(): FiltroAlmuerzos {
    return almuerzosApi.listar.mock.lastCall?.[0];
  }

  beforeEach(() => {
    vi.useFakeTimers({ toFake: ['Date'] });
    // 30/10/2026 a mediodía en Chile.
    vi.setSystemTime(new Date('2026-10-30T15:00:00Z'));
    almuerzosApi.listar.mockReset();
    almuerzosApi.listar.mockReturnValue(of([]));
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('queries the last 7 days of every branch and employee by default', async () => {
    await render();

    expect(ultimaConsulta()).toEqual({
      sucursalId: null,
      empleadoId: null,
      desde: '2026-10-24',
      hasta: '2026-10-30',
    });
  });

  it('filters by branch, employee and period', async () => {
    await render();

    await cambiar('select[aria-label="Sucursal de los almuerzos"]', '2');
    await cambiar('select[aria-label="Empleado de los almuerzos"]', '20');
    await cambiar('select[aria-label="Periodo de los almuerzos"]', 'mes');

    expect(ultimaConsulta()).toEqual({
      sucursalId: 2,
      empleadoId: 20,
      desde: '2026-10-01',
      hasta: '2026-10-30',
    });
  });

  it('uses a custom range and rejects one that ends before it starts', async () => {
    await render();
    await cambiar('select[aria-label="Periodo de los almuerzos"]', 'personalizado');
    await cambiar('input[aria-label="Fecha inicial"]', '2026-10-05');
    await cambiar('input[aria-label="Fecha final"]', '2026-10-12');

    expect(ultimaConsulta()).toEqual(
      expect.objectContaining({ desde: '2026-10-05', hasta: '2026-10-12' }),
    );

    const consultas = almuerzosApi.listar.mock.calls.length;
    await cambiar('input[aria-label="Fecha inicial"]', '2026-10-20');

    expect(texto('.range-error')).toBe('La fecha inicial no puede ser posterior a la final.');
    expect(almuerzosApi.listar).toHaveBeenCalledTimes(consultas);
  });

  it('lists each lunch with employee, products, cashier and branch, without amounts', async () => {
    almuerzosApi.listar.mockReturnValue(
      of([
        fila(1, 'Pedro Soto', [['Menú del día', 1], ['Jugo', 2]]),
        fila(2, 'Ana Díaz', [['Menú del día', 1]], '2026-10-28'),
      ]),
    );
    await render();

    const filas = Array.from(element().querySelectorAll('tbody tr'));
    expect(filas).toHaveLength(2);
    expect(filas[0].textContent).toContain('29-10-2026');
    expect(filas[0].textContent).toContain('Pedro Soto');
    expect(filas[0].textContent).toContain('1 × Menú del día');
    expect(filas[0].textContent).toContain('2 × Jugo');
    expect(filas[0].textContent).toContain('Camila Rojas');
    expect(filas[0].textContent).toContain('Nury Providencia');
    expect(texto('.record-count')).toBe('2 almuerzos');
    const tarjetas = Array.from(element().querySelectorAll('.totals .total-card')).map((card) => [
      card.querySelector('.total-name')?.textContent?.trim(),
      card.querySelector('.total-quantity')?.textContent?.replace(/\s+/g, ' ').trim(),
    ]);
    expect(tarjetas).toEqual([
      ['Almuerzos', '2'],
      ['Empleados', '2'],
      ['Productos consumidos', '4 un'],
    ]);
    expect(element().textContent).not.toContain('$');
  });

  it('says when there are no lunches in the period', async () => {
    await render();

    expect(texto('.report-message')).toContain('No hay almuerzos registrados del 24-10-2026 al 30-10-2026.');
  });

  it('reports a connection error and retries', async () => {
    almuerzosApi.listar.mockReturnValue(throwError(() => new HttpErrorResponse({ status: 0 })));
    await render();

    expect(texto('.report-message.error')).toContain('No pudimos cargar los almuerzos');

    almuerzosApi.listar.mockReturnValue(of([fila(1, 'Pedro Soto', [['Menú del día', 1]])]));
    (element().querySelector('.report-message.error button') as HTMLButtonElement).click();
    await estable();

    expect(element().querySelectorAll('tbody tr')).toHaveLength(1);
  });

  it('explains when the role cannot read lunches', async () => {
    almuerzosApi.listar.mockReturnValue(throwError(() => new HttpErrorResponse({ status: 403 })));
    await render();

    expect(texto('.report-message.error')).toContain('no tiene permiso para consultar los almuerzos');
  });

  it('queries again when a new lunch is registered', async () => {
    await render();
    const consultas = almuerzosApi.listar.mock.calls.length;

    fixture.componentRef.setInput('version', 1);
    await estable();

    expect(almuerzosApi.listar).toHaveBeenCalledTimes(consultas + 1);
  });
});
