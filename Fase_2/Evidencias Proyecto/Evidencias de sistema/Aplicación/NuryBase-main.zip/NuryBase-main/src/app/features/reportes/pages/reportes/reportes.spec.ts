import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute, Router, convertToParamMap } from '@angular/router';
import { Subject, of, throwError } from 'rxjs';
import { SucursalesApiService } from '../../../../core/api/sucursales-api.service';
import {
  cajeroDePrueba,
  productoDePrueba,
  resumenDePrueba,
  turnoDePrueba,
} from '../../models/datos-prueba';
import { ReportesService } from '../../services/reportes.service';
import { Reportes, vistaReporteDesdeUrl } from './reportes';

describe('Reportes', () => {
  let fixture: ComponentFixture<Reportes>;
  const reportes = {
    resumenPorSucursal: vi.fn(),
    productosPorSucursal: vi.fn(),
    rendimientoCajeros: vi.fn(),
    promocionesPorDia: vi.fn(),
    promocionesPorProducto: vi.fn(),
    cuadraturaVentasStock: vi.fn(),
    turnosReporte: vi.fn(),
    costoActualProductos: vi.fn(),
  };
  const sucursalesApi = {
    listarActivas: vi.fn(() => of([{ id: 1, nombre: 'Nury Providencia', activo: true }])),
  };
  const router = { navigate: vi.fn().mockResolvedValue(true) };

  function datosReales() {
    reportes.resumenPorSucursal.mockImplementation((filtro) =>
      of([resumenDePrueba(filtro.hasta <= '2026-11-01' ? { total: 40000, ventas: 8 } : {})]),
    );
    reportes.productosPorSucursal.mockReturnValue(of([productoDePrueba()]));
    reportes.rendimientoCajeros.mockReturnValue(of([cajeroDePrueba()]));
    reportes.cuadraturaVentasStock.mockReturnValue(of([]));
    reportes.costoActualProductos.mockReturnValue(of([]));
    reportes.turnosReporte.mockReturnValue(
      of([turnoDePrueba(), turnoDePrueba({ turnoId: null, cajero: 'Sin turno registrado' })]),
    );
  }

  async function render(vista: string | null = null) {
    await TestBed.configureTestingModule({
      imports: [Reportes],
      providers: [
        { provide: ReportesService, useValue: reportes },
        { provide: SucursalesApiService, useValue: sucursalesApi },
        { provide: Router, useValue: router },
        {
          provide: ActivatedRoute,
          useValue: { snapshot: { queryParamMap: convertToParamMap(vista ? { vista } : {}) } },
        },
      ],
    }).compileComponents();
    fixture = TestBed.createComponent(Reportes);
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
  }
  const element = () => fixture.nativeElement as HTMLElement;
  const click = (selector: string) => {
    element().querySelector<HTMLButtonElement>(selector)!.click();
    fixture.detectChanges();
  };

  beforeEach(() => {
    vi.useFakeTimers({ toFake: ['Date'] });
    vi.setSystemTime(new Date(2026, 10, 4, 12));
    Object.values(reportes).forEach((fn) => fn.mockReset());
    router.navigate.mockClear();
  });
  afterEach(() => vi.useRealTimers());

  // Primera prueba del grupo: paga la compilación inicial del componente. Sola tarda ~800 ms,
  // pero con la suite completa en paralelo supera los 5000 ms por defecto de Vitest.
  it('asks the current week and the same days of the previous week with every branch', async () => {
    datosReales();
    await render();
    expect(reportes.resumenPorSucursal.mock.calls).toEqual([
      [{ sucursales: [], desde: '2026-11-02', hasta: '2026-11-04' }],
      [{ sucursales: [], desde: '2026-10-26', hasta: '2026-10-28' }],
    ]);
    expect(reportes.rendimientoCajeros).toHaveBeenCalledTimes(2);
    expect(element().querySelector('.page-header p')?.textContent).toContain('comparado con');
  }, 15_000);

  it('shows the totals with their change and the highlights', async () => {
    datosReales();
    await render();
    const tarjetas = Array.from(element().querySelectorAll('.kpi'));
    expect(tarjetas[0].textContent).toContain('$50.000');
    expect(tarjetas[0].textContent).toContain('▲ 25 % vs período anterior');
    // H4.2: junto al total, el mismo indicador del período anterior.
    expect(tarjetas[0].querySelector('.kpi-previous')?.textContent).toBe(
      'Semana anterior: $40.000',
    );
    expect(tarjetas[1].querySelector('.kpi-previous')?.textContent).toBe('Semana anterior: 8');
    expect(tarjetas[3].querySelector('.trend')?.className).toContain('neutral');
    const destacados = element().querySelector('.highlights')?.textContent ?? '';
    expect(destacados).toContain('Nury Providencia');
    expect(destacados).toContain('Café americano');
    expect(destacados).toContain('Camila Rojas');
  });

  it('switches between branches, products and cashiers keeping the tab in the URL', async () => {
    datosReales();
    await render();
    expect(element().querySelector('app-reporte-sucursales')).not.toBeNull();

    click('#tab-productos');
    expect(element().querySelector('app-reporte-productos')).not.toBeNull();
    expect(router.navigate).toHaveBeenLastCalledWith(
      [],
      expect.objectContaining({ queryParams: { vista: 'productos' }, replaceUrl: true }),
    );
    click('#tab-cajeros');
    expect(element().querySelector('app-reporte-cajeros')).not.toBeNull();

    // Un destacado lleva a su pestaña.
    (element().querySelectorAll('.highlight')[0] as HTMLButtonElement).click();
    fixture.detectChanges();
    expect(element().querySelector('app-reporte-sucursales')).not.toBeNull();
  });

  it('opens the Promociones tab with the same branches and period (H5.2 T08)', async () => {
    datosReales();
    reportes.promocionesPorDia.mockReturnValue(of([]));
    reportes.promocionesPorProducto.mockReturnValue(of([]));
    await render();

    click('#tab-promociones');
    await fixture.whenStable();
    fixture.detectChanges();

    expect(element().querySelector('app-reporte-promociones')).not.toBeNull();
    expect(reportes.promocionesPorDia).toHaveBeenCalledWith(
      expect.objectContaining({ desde: '2026-11-02', hasta: '2026-11-04' }),
    );
    expect(vistaReporteDesdeUrl('promociones')).toBe('promociones');
  });

  it('shows the reconciliation with the stock in the branches tab', async () => {
    datosReales();
    reportes.cuadraturaVentasStock.mockReturnValue(
      of([
        {
          sucursalId: 1,
          sucursal: 'Nury Providencia',
          tipo: 'producto',
          articuloId: 4,
          articulo: 'Chaparrita',
          unidad: 'un',
          esperado: 3,
          registrado: 4,
          diferencia: 1,
          cuadra: false,
        },
      ]),
    );
    await render();
    expect(reportes.cuadraturaVentasStock).toHaveBeenCalledWith({
      sucursales: [],
      desde: '2026-11-02',
      hasta: '2026-11-04',
    });
    expect(element().querySelector('app-cuadratura-stock')?.textContent).toContain(
      '1 artículo no cuadra',
    );
  });

  it('keeps the report visible when the reconciliation fails', async () => {
    datosReales();
    reportes.cuadraturaVentasStock.mockReturnValue(throwError(() => new Error('sin función')));
    await render();
    expect(element().querySelector('.kpi')?.textContent).toContain('$50.000');
    expect(element().querySelector('app-cuadratura-stock')?.textContent).toContain(
      'No se pudo revisar la cuadratura',
    );
  });

  it('opens the tab asked in the URL', async () => {
    datosReales();
    await render('cajeros');
    expect(element().querySelector('#tab-cajeros')?.getAttribute('aria-selected')).toBe('true');
    expect(vistaReporteDesdeUrl('otra')).toBe('sucursales');
  });

  it('asks again with the chosen branches and keeps the last data while it loads', async () => {
    datosReales();
    await render();
    const respuesta = new Subject<ReturnType<typeof resumenDePrueba>[]>();
    reportes.resumenPorSucursal.mockReturnValue(respuesta);

    click('[aria-label="Sucursales del reporte"]');
    const providencia = Array.from(element().querySelectorAll('.option'))
      .find((o) => o.textContent?.trim() === 'Nury Providencia')!
      .querySelector('input')!;
    providencia.click();
    fixture.detectChanges();
    expect(reportes.resumenPorSucursal).toHaveBeenLastCalledWith(
      expect.objectContaining({ sucursales: [1] }),
    );
    expect(element().querySelector('.content')?.classList).toContain('updating');
    expect(element().querySelector('.kpi')?.textContent).toContain('$50.000');
  });

  it('says "Sin ventas en este período" and what happened in the previous one', async () => {
    reportes.resumenPorSucursal.mockImplementation((filtro) =>
      of([
        filtro.hasta <= '2026-11-01'
          ? resumenDePrueba({ total: 40000, ventas: 8 })
          : resumenDePrueba({
              ventas: 0,
              total: 0,
              ticketPromedio: 0,
              mediosPago: {},
              anuladas: { ventas: 0, total: 0 },
            }),
      ]),
    );
    reportes.productosPorSucursal.mockReturnValue(of([]));
    reportes.rendimientoCajeros.mockReturnValue(of([]));
    reportes.cuadraturaVentasStock.mockReturnValue(of([]));
    await render();

    const mensaje = element().querySelector('.no-sales')?.textContent ?? '';
    expect(mensaje).toContain('Sin ventas en este período');
    expect(mensaje).toContain('Semana anterior: 8 ventas por $40.000.');
    expect(element().querySelector('.kpis')).toBeNull();
    expect(element().querySelector('[role="tablist"]')).toBeNull();
  });

  it('shows only the chosen shift, without comparison, and resets it with the filters (H4.3 T03)', async () => {
    datosReales();
    await render('cajeros');
    expect(reportes.turnosReporte).toHaveBeenLastCalledWith({
      sucursales: [],
      desde: '2026-11-02',
      hasta: '2026-11-04',
    });
    expect(element().querySelector('app-reporte-cajeros thead')?.textContent).toContain(
      'semana anterior',
    );

    reportes.rendimientoCajeros.mockReturnValue(of([cajeroDePrueba({ ventas: 4, total: 18000 })]));
    click('[aria-label="Turno del reporte de cajeros"]');
    const opciones = Array.from(
      element().querySelectorAll<HTMLButtonElement>('#shift-options .option'),
    );
    expect(opciones.map((o) => o.querySelector('strong')?.textContent?.trim())).toEqual([
      'Todos los turnos',
      'Camila Rojas · mar 03-11 · 09:00 a 17:00',
      'Sin turno registrado',
    ]);
    opciones[1].click();
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();

    expect(reportes.rendimientoCajeros).toHaveBeenLastCalledWith(
      { sucursales: [], desde: '2026-11-02', hasta: '2026-11-04' },
      7,
    );
    const tabla = element().querySelector('app-reporte-cajeros table')!;
    expect(tabla.textContent).toContain('$18.000');
    expect(tabla.querySelector('thead')?.textContent).not.toContain('semana anterior');
    expect(element().querySelector('.shift-note')).not.toBeNull();
    // Las tarjetas de arriba siguen siendo del período completo.
    expect(element().querySelector('.kpi')?.textContent).toContain('$50.000');

    // Al cambiar el período vuelve a "Todos los turnos".
    click('[aria-label="Período del reporte"]');
    Array.from(element().querySelectorAll<HTMLButtonElement>('#period-options .option'))
      .find((o) => o.textContent?.trim() === 'Mes')!
      .click();
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(
      element().querySelector('[aria-label="Turno del reporte de cajeros"]')?.textContent,
    ).toContain('Todos los turnos');
    expect(element().querySelector('.shift-note')).toBeNull();
  });

  it('compares a month with the same days of the previous month', async () => {
    datosReales();
    await render();
    click('[aria-label="Período del reporte"]');
    Array.from(element().querySelectorAll<HTMLButtonElement>('#period-options .option'))
      .find((o) => o.textContent?.trim() === 'Mes')!
      .click();
    fixture.detectChanges();
    expect(reportes.resumenPorSucursal.mock.calls.slice(-2)).toEqual([
      [{ sucursales: [], desde: '2026-11-01', hasta: '2026-11-04' }],
      [{ sucursales: [], desde: '2026-10-01', hasta: '2026-10-04' }],
    ]);
    expect(element().querySelector('.kpi-previous')?.textContent).toContain('Mes anterior');
  });

  it('explains when the role cannot see the reports', async () => {
    reportes.resumenPorSucursal.mockReturnValue(
      throwError(() => new HttpErrorResponse({ status: 403 })),
    );
    reportes.productosPorSucursal.mockReturnValue(of([]));
    reportes.rendimientoCajeros.mockReturnValue(of([]));
    reportes.cuadraturaVentasStock.mockReturnValue(of([]));
    await render();
    expect(element().textContent).toContain('Tu rol no tiene permiso para ver los reportes.');
  });

  it('offers a retry when the first load fails', async () => {
    reportes.resumenPorSucursal.mockReturnValue(throwError(() => new Error('sin red')));
    reportes.productosPorSucursal.mockReturnValue(of([]));
    reportes.rendimientoCajeros.mockReturnValue(of([]));
    reportes.cuadraturaVentasStock.mockReturnValue(of([]));
    await render();
    expect(element().textContent).toContain('No pudimos cargar los reportes.');

    datosReales();
    click('.retry-button');
    await fixture.whenStable();
    fixture.detectChanges();
    expect(element().querySelector('.kpi')?.textContent).toContain('$50.000');
  });
});
