/**
 * Sucursal que recibe la factura según su dirección. Primero se compara la dirección de
 * despacho (dónde se entregó la mercadería) y, si no coincide ninguna, la del receptor, con
 * la dirección registrada de cada sucursal.
 *
 * Coinciden cuando comparten el número y una palabra del nombre de la calle. Se toleran
 * abreviaturas («Av.»), mayúsculas, tildes y las letras que algunos proveedores pierden
 * («ESPA  A» por «ESPAÑA»). Solo se miran las palabras antes del número de cada tramo, para
 * que la comuna («Valparaíso 1680») no pase por calle. Pueden coincidir varias sucursales
 * en la misma dirección (dos locales en un mismo campus): entonces se devuelven todas.
 */

import { normalizar } from './asociacion-lineas';
import { FacturaXml } from './lector-dte';
import { SucursalIngreso } from './permiso-ingreso';

export interface SucursalDetectada {
  /** Sucursales con esa dirección; más de una si comparten dirección. */
  ids: number[];
  origen: 'despacho' | 'receptor';
  /** La dirección de la factura que coincidió, para mostrarla. */
  direccion: string;
}

/** Palabras que no identifican una calle. */
const GENERICAS = new Set([
  'av', 'avda', 'avenida', 'calle', 'pasaje', 'psje', 'pje', 'camino', 'los', 'las', 'el', 'la',
  'de', 'del', 'nro', 'num', 'numero', 'local', 'oficina', 'depto',
]);
/** Mínimo de letras para aceptar una palabra cortada: «espa» → «españa». */
const MINIMO_PREFIJO = 4;

export function detectarSucursal(
  factura: Pick<FacturaXml, 'direccion_despacho' | 'direccion_receptor'>,
  sucursales: SucursalIngreso[],
): SucursalDetectada | null {
  const origenes = [
    ['despacho', factura.direccion_despacho],
    ['receptor', factura.direccion_receptor],
  ] as const;
  for (const [origen, direccion] of origenes) {
    if (!direccion) continue;
    const calles = tramos(direccion);
    const candidatas = sucursales.filter(
      (sucursal) => sucursal.direccion && tramos(sucursal.direccion).some((propia) => calles.some((otra) => coinciden(propia, otra))),
    );
    if (candidatas.length > 0) return { ids: candidatas.map((sucursal) => sucursal.id), origen, direccion };
  }
  return null;
}

interface Tramo {
  numero: string;
  palabras: string[];
}

/** «Los Placeres401, Valpara  so 1680» → [placeres 401] y [valpara 1680]. */
function tramos(direccion: string): Tramo[] {
  return normalizar(direccion)
    .split(/[,;]/)
    .map((tramo) => {
      const palabras = tramo
        .replace(/(\d)([a-z])/g, '$1 $2')
        .replace(/([a-z])(\d)/g, '$1 $2')
        .split(/[^a-z0-9]+/)
        .filter(Boolean);
      const indice = palabras.findIndex((palabra) => /^\d+$/.test(palabra));
      if (indice < 0) return null;
      const calle = palabras.slice(0, indice).filter((palabra) => palabra.length >= 3 && !GENERICAS.has(palabra));
      return { numero: String(Number(palabras[indice])), palabras: calle };
    })
    .filter((tramo): tramo is Tramo => tramo !== null && tramo.palabras.length > 0);
}

function coinciden(a: Tramo, b: Tramo): boolean {
  return a.numero === b.numero && a.palabras.some((palabra) => b.palabras.some((otra) => mismaPalabra(palabra, otra)));
}

function mismaPalabra(a: string, b: string): boolean {
  if (a === b) return true;
  if (Math.min(a.length, b.length) < MINIMO_PREFIJO) return false;
  return a.startsWith(b) || b.startsWith(a);
}
