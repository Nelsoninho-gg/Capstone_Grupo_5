import {
  PromocionesPeriodo,
  agruparPeriodos,
  porcentaje,
  promocionesProducto,
  totalPromociones,
} from './reporte-promociones.model';

const dia = (desde: string, vendido: number, conDescuento: number, margen: number): PromocionesPeriodo => ({
  desde,
  hasta: desde,
  vendido,
  vendidoConDescuento: conDescuento,
  precioListaConDescuento: conDescuento + margen,
  unidadesConDescuento: conDescuento ? 2 : 0,
  ventasConPromocion: conDescuento ? 1 : 0,
  margenSacrificado: margen,
});

// Domingo 1 a jueves 5 de noviembre de 2026.
const dias = [
  dia('2026-11-01', 1000, 0, 0),
  dia('2026-11-02', 6500, 4500, 1000),
  dia('2026-11-03', 0, 0, 0),
  dia('2026-11-04', 4500, 4500, 1000),
  dia('2026-11-05', 2000, 0, 0),
];

describe('reporte de promociones (H5.2 T08)', () => {
  it('keeps one row per day', () => {
    expect(agruparPeriodos(dias, 'dia')).toHaveLength(5);
  });

  it('groups by week from Monday to Sunday', () => {
    const semanas = agruparPeriodos(dias, 'semana');
    expect(semanas.map((s) => [s.desde, s.hasta, s.vendidoConDescuento, s.margenSacrificado])).toEqual([
      ['2026-11-01', '2026-11-01', 0, 0],
      ['2026-11-02', '2026-11-05', 9000, 2000],
    ]);
    expect(semanas[1].ventasConPromocion).toBe(2);
  });

  it('groups by month and totals the whole period', () => {
    expect(agruparPeriodos(dias, 'mes')).toHaveLength(1);
    const total = totalPromociones(dias)!;
    expect([total.desde, total.hasta, total.vendido, total.vendidoConDescuento, total.margenSacrificado]).toEqual([
      '2026-11-01',
      '2026-11-05',
      14000,
      9000,
      2000,
    ]);
    expect(totalPromociones([])).toBeNull();
  });

  it('does not change the days it receives', () => {
    agruparPeriodos(dias, 'semana');
    expect(dias[1].vendido).toBe(6500);
  });

  it('computes shares without dividing by zero', () => {
    expect(porcentaje(4500, 6500)).toBeCloseTo(69.23, 2);
    expect(porcentaje(0, 0)).toBe(0);
  });

  it('reads PostgREST numbers and the promotion names of a product', () => {
    const producto = promocionesProducto({
      producto_id: 3,
      producto: 'Sándwich',
      categoria: null,
      unidades: '2',
      vendido: '5728.00',
      unidades_con_descuento: '2',
      vendido_con_descuento: '5728.00',
      precio_lista_con_descuento: '7000.00',
      margen_sacrificado: '1272.00',
      margen_con_descuento: null,
      promociones: 'Combo, Fin de semana',
    });
    expect(producto.vendido).toBe(5728);
    expect(producto.margenConDescuento).toBeNull();
    expect(producto.promociones).toEqual(['Combo', 'Fin de semana']);
  });
});
