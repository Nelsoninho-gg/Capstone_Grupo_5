import { Component, computed, input } from '@angular/core';
import {
  etiquetaMedio,
  mediosPresentes,
  proporcion,
  variacion,
} from '../../models/reporte-ventas.model';
import { ResumenSucursal } from '../../models/reportes.model';
import { formatoClp, formatoNumero, textoVariacion, tonoVariacion } from '../../models/formato';

/** Color fijo por medio de pago, para que una sucursal y otra se lean igual. */
const COLORES_MEDIO: Record<string, string> = {
  efectivo: '#4A6FC0',
  debito: '#7a9a63',
  credito: '#8fa1cb',
  sodexo: '#b9822b',
  edenred: '#e2b85c',
  transferencia: '#6f8597',
  sin_medio: '#c0c3c9',
};

/**
 * Pestaña Sucursales del dashboard (H4.1): cada sucursal por separado para compararlas, con
 * su variación contra el período anterior, medios de pago y detalle (normales, empleados y
 * anuladas aparte).
 */
@Component({
  selector: 'app-reporte-sucursales',
  templateUrl: './reporte-sucursales.html',
  styleUrls: ['../../styles/reportes-base.css', './reporte-sucursales.css'],
})
export class ReporteSucursales {
  readonly resumen = input.required<ResumenSucursal[]>();
  readonly resumenAnterior = input<ResumenSucursal[]>([]);
  /** "Semana anterior", "Mes anterior"... (H4.2). */
  readonly etiquetaAnterior = input('Período anterior');

  protected readonly maximoTotal = computed(() =>
    Math.max(0, ...this.resumen().map((fila) => fila.total)),
  );
  protected readonly medios = computed(() => mediosPresentes(this.resumen()));
  protected readonly hayVentas = computed(() => this.resumen().some((fila) => fila.ventas > 0));

  protected variacionDe(fila: ResumenSucursal): number | null {
    return variacion(fila.total, this.totalAnterior(fila));
  }

  /** Total de la misma sucursal en el período anterior (0 si no vendió). */
  protected totalAnterior(fila: ResumenSucursal): number {
    return this.resumenAnterior().find((r) => r.sucursalId === fila.sucursalId)?.total ?? 0;
  }

  protected anchoBarra(valor: number): number {
    return proporcion(valor, this.maximoTotal());
  }

  /** Porcentaje del total de la sucursal pagado con ese medio. */
  protected parteMedio(fila: ResumenSucursal, medio: string): number {
    return proporcion(fila.mediosPago[medio] ?? 0, fila.total);
  }

  protected colorMedio(medio: string): string {
    return COLORES_MEDIO[medio] ?? '#9aa09a';
  }

  protected readonly etiquetaMedio = etiquetaMedio;
  protected readonly textoVariacion = textoVariacion;
  protected readonly tonoVariacion = tonoVariacion;
  protected clp(valor: number): string {
    return formatoClp.format(valor);
  }
  protected numero(valor: number): string {
    return formatoNumero.format(valor);
  }
}
