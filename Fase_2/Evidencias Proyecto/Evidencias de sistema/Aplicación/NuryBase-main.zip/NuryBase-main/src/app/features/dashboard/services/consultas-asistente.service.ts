import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, catchError, forkJoin, map, of, shareReplay, tap } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { fechasEnHoraChile } from '../models/herramientas-asistente.model';
import { NombresReales } from '../models/seudonimos-asistente';

export interface ConsultaAsistente {
  /** Tabla o vista (`ventas`) o reporte (`rpc/fn_reporte_ventas_sucursal`). */
  recurso: string;
  select?: string;
  /** Filtros PostgREST por columna o parámetros `p_*` de un reporte. Una lista aplica varios (rango de fechas). */
  filtros?: Record<string, string | string[]>;
  orden?: string;
  limite?: number;
}

export interface ResultadoConsulta {
  consulta: ConsultaAsistente;
  filas?: unknown[];
  /** Total de filas que existen, cuando PostgREST lo informa. */
  total?: number | null;
  truncado?: boolean;
  error?: string;
}

export type EsquemaBase = ReadonlyMap<string, readonly string[]>;

/** PostgREST describe las llaves foráneas como: Note: This is a Foreign Key to `usuarios.id`. */
const LLAVE_FORANEA = /Foreign Key to `(\w+)\.\w+`/;

const TABLAS_BLOQUEADAS = new Set(['ventas_idempotencia']);
/** Disponible solo como recurso directo, porque ahí se le aplica el filtro de `ejecutar`. */
const TABLA_AUDITORIA = 'auditoria_usuarios';
// `direccion` sola es la de la sucursal, que es pública. `xml_nombre` suele llevar el RUT del emisor.
const COLUMNA_BLOQUEADA = /password|identificador_acceso|xml_original|xml_nombre|sha256|clave|(^|_)rut(_|$)|telefono|email|direccion_/i;
const REPORTES_PERMITIDOS = new Set([
  'fn_reporte_ventas_sucursal',
  'fn_reporte_productos_sucursal',
  'fn_reporte_cajeros',
  'fn_articulos_por_comprar',
  'fn_versiones_receta',
  'fn_listar_empleados',
  'fn_listar_ingresos_factura',
]);
const LIMITE_POR_DEFECTO = 100;
const LIMITE_MAXIMO = 500;
const LIMITE_LECTURA_COMPLETA = 5000;
const MAX_CARACTERES_RESULTADO = 12000;

function contieneNombreBloqueado(texto: string): boolean {
  const nombres = texto.match(/[A-Za-z_]\w*/g) ?? [];
  return nombres.some((n) => TABLAS_BLOQUEADAS.has(n.toLowerCase()) || COLUMNA_BLOQUEADA.test(n));
}

const LETRAS_CON_ACENTO: Record<string, string> = {
  a: '[aáAÁ]',
  e: '[eéEÉ]',
  i: '[iíIÍ]',
  o: '[oóOÓ]',
  u: '[uúüUÚÜ]',
  n: '[nñNÑ]',
};

/**
 * "coca cola" debe encontrar `Coca-cola zero`, y "azucar", `Azúcar`: el catálogo no escribe los nombres
 * de una sola forma. Con imatch cada letra admite solo sus variantes, y "pan" no encuentra "pin".
 */
export function busquedaTolerante(valor: string): string {
  if (!valor.startsWith('ilike.')) return valor;
  const texto = valor
    .slice(6)
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[\s.-]+/g, ' ');
  const patron = [...texto]
    .map((c) => {
      if (c === '*' || c === '%') return '.*';
      if (c === '_') return '.';
      if (c === ' ') return '[\\s.-]*';
      return LETRAS_CON_ACENTO[c] ?? c.replace(/[\\^$|?+(){}[\]]/, '\\$&');
    })
    .join('');
  return `imatch.${/^[*%]/.test(texto) ? '' : '^'}${patron}${/[*%]$/.test(texto) ? '' : '$'}`;
}

/** `productos.nombre`: filtra una tabla embebida en `select`. La auditoría solo se lee directa. */
function esFiltroEmbebido(filtro: string, recurso: string): boolean {
  return /^[a-z_]+\.[a-z_]+$/.test(filtro) && !filtro.startsWith(`${TABLA_AUDITORIA}.`) && recurso !== TABLA_AUDITORIA;
}

/**
 * Filtro entre lo que pide el modelo de IA y la base. Devuelve el motivo del rechazo o null.
 * El `*` se rechaza porque, dentro de un embed como `usuarios(*)`, traería credenciales.
 */
export function validarConsultaAsistente(
  consulta: ConsultaAsistente,
  esquema: EsquemaBase,
): string | null {
  const recurso = String(consulta.recurso ?? '');
  const filtros = Object.keys(consulta.filtros ?? {});

  if (recurso.startsWith('rpc/')) {
    if (!REPORTES_PERMITIDOS.has(recurso.slice(4))) {
      return `Reporte no permitido: ${recurso}`;
    }
    return filtros.every((f) => /^p_\w+$/.test(f)) ? null : 'Un reporte solo acepta parámetros p_*';
  }

  const columnas = esquema.get(recurso);
  if (!columnas || TABLAS_BLOQUEADAS.has(recurso)) {
    return `Recurso no disponible: ${recurso}. Disponibles: ${[...esquema.keys()].join(', ')}`;
  }
  if (consulta.select?.includes('*')) {
    return 'Indica las columnas en select; no se permite *';
  }
  if (contieneNombreBloqueado(`${consulta.select ?? ''} ${consulta.orden ?? ''}`)) {
    return 'La consulta pide credenciales, datos de acceso o RUT y datos de contacto, que no están disponibles en el chat';
  }
  if (recurso !== TABLA_AUDITORIA && consulta.select?.includes(TABLA_AUDITORIA)) {
    return `Consulta ${TABLA_AUDITORIA} directamente, no embebida en otro recurso`;
  }
  const invalido = filtros.find(
    (f) => !(columnas.includes(f) || esFiltroEmbebido(f, recurso)) || contieneNombreBloqueado(f),
  );
  return invalido
    ? `Filtro no disponible: ${invalido}. Columnas de ${recurso}: ${columnas.join(', ')}`
    : null;
}

/**
 * Lecturas de la base para el asistente, siempre con la sesión del usuario.
 * Solo usa GET: PostgREST lo ejecuta en una transacción de solo lectura, así que ni un modelo
 * engañado por el texto de una fila puede modificar datos, incluso si el filtro fallara.
 */
@Injectable({ providedIn: 'root' })
export class ConsultasAsistenteService {
  private readonly http = inject(HttpClient);
  private esquemaEnCache: Observable<EsquemaBase> | null = null;
  private readonly tablaRelacionada = new Map<string, string>();

  esquema(): Observable<EsquemaBase> {
    this.esquemaEnCache ??= this.http
      .get<{
        definitions?: Record<string, { properties?: Record<string, { description?: string }> }>;
      }>(
        `${environment.apiUrl}/`,
        { headers: { Accept: 'application/openapi+json' } },
      )
      .pipe(
        map(
          (openApi) =>
            new Map(
              Object.entries(openApi.definitions ?? {})
                .filter(([tabla]) => !TABLAS_BLOQUEADAS.has(tabla))
                .map(([tabla, definicion]) => {
                  for (const [columna, propiedad] of Object.entries(definicion.properties ?? {})) {
                    const destino = propiedad.description?.match(LLAVE_FORANEA)?.[1];
                    if (destino) this.tablaRelacionada.set(`${tabla}.${columna}`, destino);
                  }
                  return [
                    tabla,
                    Object.keys(definicion.properties ?? {}).filter((c) => !COLUMNA_BLOQUEADA.test(c)),
                  ];
                }),
            ),
        ),
        // Un error no queda guardado: la siguiente pregunta vuelve a intentar.
        tap({ error: () => (this.esquemaEnCache = null) }),
        shareReplay(1),
      );
    return this.esquemaEnCache;
  }

  /** Esquema para el modelo, con cada llave foránea indicada: `ventas(id, anulada_por->usuarios)`. */
  describirEsquema(esquema: EsquemaBase): string {
    return [...esquema.entries()]
      .map(([tabla, columnas]) => {
        const lista = columnas.map((c) => {
          const destino = this.tablaRelacionada.get(`${tabla}.${c}`);
          return destino ? `${c}->${destino}` : c;
        });
        return `${tabla}(${lista.join(', ')})`;
      })
      .join('\n');
  }

  /** Desde cuándo hay ventas registradas, en hora de Chile. Sin ese dato, null. */
  primeraVenta(esquema: EsquemaBase): Observable<string | null> {
    return this.ejecutar({ recurso: 'ventas', select: 'fecha_venta', orden: 'fecha_venta.asc', limite: 1 }, esquema).pipe(
      map((resultado) => {
        const fecha = (resultado.filas?.[0] as { fecha_venta?: string } | undefined)?.fecha_venta;
        return fecha ? String(fechasEnHoraChile(fecha)).slice(0, 10) : null;
      }),
    );
  }

  /** Falla si no puede leerlos: sin la lista completa, un nombre saldría sin ocultar hacia la IA. */
  nombresReales(esquema: EsquemaBase): Observable<NombresReales> {
    const leer = (recurso: string, columna: string) =>
      this.ejecutar({ recurso, select: columna }, esquema, true).pipe(
        map((resultado) => {
          if (resultado.error || resultado.truncado) {
            throw new Error(`No se pudieron leer los nombres de ${recurso}: ${resultado.error ?? 'lectura incompleta'}`);
          }
          return ((resultado.filas ?? []) as Record<string, string | null>[]).flatMap((fila) => fila[columna] ?? []);
        }),
      );
    return forkJoin({
      personas: leer('usuarios', 'nombre'),
      proveedores: forkJoin([leer('proveedores', 'nombre'), leer('facturas_xml_pendientes', 'razon_social_emisor')]).pipe(
        map((listas) => listas.flat()),
      ),
    });
  }

  /**
   * Nunca falla: un error vuelve como dato para que el modelo corrija o lo informe.
   * Con `completo` no recorta filas, porque los resultados van a un cálculo y no al modelo.
   */
  ejecutar(
    consulta: ConsultaAsistente,
    esquema: EsquemaBase,
    completo = false,
  ): Observable<ResultadoConsulta> {
    const rechazo = validarConsultaAsistente(consulta, esquema);
    if (rechazo) {
      return of({ consulta, error: rechazo });
    }

    const esReporte = consulta.recurso.startsWith('rpc/');
    const limite = completo
      ? Math.min(Number(consulta.limite) || LIMITE_LECTURA_COMPLETA, LIMITE_LECTURA_COMPLETA)
      : Math.min(Number(consulta.limite) || LIMITE_POR_DEFECTO, LIMITE_MAXIMO);
    const filtros = Object.fromEntries(
      Object.entries(consulta.filtros ?? {}).map(([columna, condicion]) => [
        columna,
        Array.isArray(condicion) ? condicion.map(busquedaTolerante) : busquedaTolerante(condicion),
      ]),
    );
    let params = new HttpParams({ fromObject: filtros }).set('limit', limite);
    const select = consulta.select ?? (esReporte ? null : esquema.get(consulta.recurso)?.join(','));
    if (select) {
      params = params.set('select', select);
    }
    if (consulta.orden) {
      params = params.set('order', consulta.orden);
    }
    if (consulta.recurso === TABLA_AUDITORIA) {
      // Esas filas guardan el usuario de acceso en valor_anterior y valor_nuevo.
      params = params.append('campo_modificado', 'neq.identificador_acceso');
    }

    return this.http
      .get<unknown[]>(`${environment.apiUrl}/${consulta.recurso}`, {
        params,
        observe: 'response',
        headers: { Prefer: 'count=exact' },
      })
      .pipe(
        map((respuesta) => {
          const total = Number(respuesta.headers.get('Content-Range')?.split('/')[1]);
          const cuerpo = sinColumnasBloqueadas(respuesta.body ?? []) as unknown[];
          const filas = completo ? cuerpo : recortarFilas(cuerpo);
          return {
            consulta,
            filas,
            total: Number.isFinite(total) ? total : null,
            // Un reporte que devuelve un solo JSON cuenta como una fila: si viene vacío, no falta nada.
            truncado:
              !(completo && cuerpo.length === 0) &&
              filas.length < (Number.isFinite(total) ? total : (respuesta.body ?? []).length),
          };
        }),
        catchError((error: HttpErrorResponse) =>
          of({
            consulta,
            error: [error.error?.message ?? `Error HTTP ${error.status}`, error.error?.hint]
              .filter(Boolean)
              .join(' '),
          }),
        ),
      );
  }
}

/** Los reportes eligen sus propias columnas (`rut_emisor` en las facturas): el filtro de `select` no los alcanza. */
function sinColumnasBloqueadas(datos: unknown): unknown {
  if (Array.isArray(datos)) {
    return datos.map(sinColumnasBloqueadas);
  }
  if (typeof datos === 'object' && datos !== null) {
    return Object.fromEntries(
      Object.entries(datos)
        .filter(([columna]) => !COLUMNA_BLOQUEADA.test(columna))
        .map(([columna, valor]) => [columna, sinColumnasBloqueadas(valor)]),
    );
  }
  return datos;
}

function recortarFilas(filas: readonly unknown[]): unknown[] {
  const recortadas: unknown[] = [];
  let caracteres = 0;
  for (const fila of filas) {
    caracteres += JSON.stringify(fila).length;
    if (caracteres > MAX_CARACTERES_RESULTADO) break;
    recortadas.push(fila);
  }
  return recortadas;
}
