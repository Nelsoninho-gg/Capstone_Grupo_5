import { HttpErrorResponse } from '@angular/common/http';
import { interpretarFalloAlmuerzo } from './fallo-almuerzo';

const errorHttp = (status: number, body: object | null = null) =>
  new HttpErrorResponse({ status, error: body });

describe('interpretarFalloAlmuerzo', () => {
  it('shows the database reason when the employee already had lunch today', () => {
    const fallo = interpretarFalloAlmuerzo(
      errorHttp(409, {
        code: '23505',
        message:
          'Ana Pérez ya registró su almuerzo hoy (a las 13:05 en Nury Providencia, lo registró Camila Rojas). Solo se permite un almuerzo por día',
      }),
    );
    expect(fallo.tipo).toBe('ya-almorzo');
    expect(fallo.mensaje).toBe(
      'Ana Pérez ya registró su almuerzo hoy (a las 13:05 en Nury Providencia, lo registró Camila Rojas). ' +
        'Solo se permite un almuerzo por día. El almuerzo no se registró y el stock no cambió.',
    );
  });

  it('shows the database reason for invalid data', () => {
    const fallo = interpretarFalloAlmuerzo(
      errorHttp(400, { code: '22023', message: 'El almuerzo no tiene productos: agrega al menos uno' }),
    );
    expect(fallo).toEqual({
      tipo: 'datos-invalidos',
      mensaje:
        'El almuerzo no tiene productos: agrega al menos uno. El almuerzo no se registró y el stock no cambió.',
    });
  });

  it('explains a branch the cashier cannot use', () => {
    const fallo = interpretarFalloAlmuerzo(
      errorHttp(403, { code: '42501', message: 'Solo puedes registrar almuerzos en tu sucursal' }),
    );
    expect(fallo.tipo).toBe('permisos');
    expect(fallo.mensaje).toContain('Solo puedes registrar almuerzos en tu sucursal.');
  });

  it('tells the user that retrying after a lost connection is safe', () => {
    const fallo = interpretarFalloAlmuerzo(errorHttp(0));
    expect(fallo.tipo).toBe('conexion');
    expect(fallo.mensaje).toContain('no se descontará dos veces');
  });

  it('handles an expired session, a missing function and unknown errors', () => {
    expect(interpretarFalloAlmuerzo(errorHttp(401)).tipo).toBe('sesion');
    expect(interpretarFalloAlmuerzo(errorHttp(404, { code: 'PGRST202' })).tipo).toBe('no-disponible');
    expect(interpretarFalloAlmuerzo(errorHttp(500, { code: 'XX000' })).tipo).toBe('servidor');
    expect(interpretarFalloAlmuerzo(new Error('boom')).tipo).toBe('servidor');
  });
});
