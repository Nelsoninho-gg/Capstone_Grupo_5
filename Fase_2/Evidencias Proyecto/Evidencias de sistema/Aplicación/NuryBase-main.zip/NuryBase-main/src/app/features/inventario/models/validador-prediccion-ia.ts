import { cifrasNoVerificadas, nombresNoVerificados } from '../../../core/ia/verificador-cifras';
import { ArticuloEntradaPrediccionIA } from './prediccion-ia.contract';

const MAX_CARACTERES_JUSTIFICACION = 200;

export interface ErrorValidacionPrediccionIA {
  articuloId?: string;
  campo: string;
  mensaje: string;
}

export type ResultadoValidacionPrediccionIA =
  | { exito: true; justificaciones: Map<string, string>; errores: ErrorValidacionPrediccionIA[] }
  | { exito: false; errores: ErrorValidacionPrediccionIA[] };

/**
 * Valida la interpretación del modelo de IA (H4.5 T07). El modelo solo aporta texto: lo inválido se
 * descarta por artículo y ese artículo conserva la justificación del algoritmo. Una justificación
 * con cifras o nombres que no vienen de los cálculos también se descarta.
 */
export function validarInterpretacionIA(
  crudo: unknown,
  articulos: readonly ArticuloEntradaPrediccionIA[],
): ResultadoValidacionPrediccionIA {
  let objeto: unknown = crudo;
  if (typeof crudo === 'string') {
    try {
      objeto = JSON.parse(crudo.trim());
    } catch {
      return {
        exito: false,
        errores: [{ campo: 'json', mensaje: 'El texto devuelto no es un JSON válido.' }],
      };
    }
  }

  const lista = (objeto as { predicciones?: unknown } | null)?.predicciones;
  if (!Array.isArray(lista)) {
    return {
      exito: false,
      errores: [{ campo: 'predicciones', mensaje: 'Falta el arreglo "predicciones".' }],
    };
  }

  const entradaPorId = new Map(articulos.map((a) => [a.articuloId, a]));
  const justificaciones = new Map<string, string>();
  const errores: ErrorValidacionPrediccionIA[] = [];

  for (const item of lista) {
    const { articuloId, justificacion } = (item ?? {}) as { articuloId?: unknown; justificacion?: unknown };
    const id = typeof articuloId === 'string' ? articuloId.trim() : '';
    const entrada = entradaPorId.get(id);
    if (!entrada) {
      errores.push({ articuloId: id, campo: 'articuloId', mensaje: `Artículo no solicitado: "${id}".` });
      continue;
    }

    const texto = typeof justificacion === 'string' ? justificacion.trim() : '';
    if (!texto || texto.length > MAX_CARACTERES_JUSTIFICACION) {
      errores.push({
        articuloId: id,
        campo: 'justificacion',
        mensaje: `Debe tener entre 1 y ${MAX_CARACTERES_JUSTIFICACION} caracteres.`,
      });
      continue;
    }

    const sinVerificar = cifrasNoVerificadas(texto, JSON.stringify(entrada));
    if (sinVerificar.length > 0) {
      errores.push({
        articuloId: id,
        campo: 'justificacion',
        mensaje: `Incluye cifras que no vienen de los cálculos: ${sinVerificar.join(', ')}.`,
      });
      continue;
    }

    const nombresInventados = nombresNoVerificados(texto, JSON.stringify(entrada));
    if (nombresInventados.length > 0) {
      errores.push({
        articuloId: id,
        campo: 'justificacion',
        mensaje: `Incluye nombres que no vienen de los cálculos: ${nombresInventados.join(', ')}.`,
      });
      continue;
    }

    justificaciones.set(id, texto);
  }

  return justificaciones.size > 0
    ? { exito: true, justificaciones, errores }
    : { exito: false, errores };
}
