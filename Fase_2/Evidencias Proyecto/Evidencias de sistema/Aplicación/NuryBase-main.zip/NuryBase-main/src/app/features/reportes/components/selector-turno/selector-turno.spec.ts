import { Component, signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { turnoDePrueba } from '../../models/datos-prueba';
import { FiltroTurno, TurnoReporte } from '../../models/reportes.model';
import { SelectorTurno } from './selector-turno';

@Component({
  imports: [SelectorTurno],
  template: `<app-selector-turno [turnos]="turnos()" [(turno)]="turno" />`,
})
class Anfitrion {
  turnos = signal<TurnoReporte[]>([
    turnoDePrueba(),
    turnoDePrueba({
      turnoId: 8,
      cajero: 'Diego Soto',
      sucursal: 'Nury Ñuñoa',
      inicio: '2026-11-03T23:00:00',
      fin: null,
      ventas: 1,
      total: 3500,
      anuladas: 2,
    }),
    turnoDePrueba({
      turnoId: null,
      cajero: 'Sin turno registrado',
      sucursal: null,
      inicio: null,
      fin: null,
    }),
  ]);
  turno = signal<FiltroTurno>(null);
}

describe('SelectorTurno', () => {
  function render() {
    const fixture = TestBed.createComponent(Anfitrion);
    fixture.detectChanges();
    const element = fixture.nativeElement as HTMLElement;
    const boton = () =>
      element.querySelector<HTMLButtonElement>('[aria-label="Turno del reporte de cajeros"]')!;
    const opciones = () =>
      Array.from(element.querySelectorAll<HTMLButtonElement>('#shift-options .option'));
    const abrir = () => {
      boton().click();
      fixture.detectChanges();
    };
    return { fixture, element, boton, opciones, abrir };
  }

  it('lists every real shift with its schedule and figures, and the sales without shift', () => {
    const { boton, opciones, abrir } = render();
    expect(boton().textContent).toContain('Todos los turnos');
    abrir();
    const textos = opciones().map((o) =>
      Array.from(o.querySelectorAll('strong, small'))
        .map((parte) => parte.textContent?.trim())
        .join(' | '),
    );
    expect(textos).toEqual([
      'Todos los turnos',
      'Camila Rojas · mar 03-11 · 09:00 a 17:00 | Nury Providencia · 4 ventas · $18.000',
      'Diego Soto · mar 03-11 · desde 23:00 (abierto) | Nury Ñuñoa · 1 venta · $3.500 · 2 anuladas',
      'Sin turno registrado | 4 ventas · $18.000',
    ]);
    expect(opciones()[0].getAttribute('aria-selected')).toBe('true');
  });

  it('chooses a shift, shows it in the button and closes', () => {
    const { fixture, boton, opciones, abrir, element } = render();
    abrir();
    opciones()[1].click();
    fixture.detectChanges();
    expect(fixture.componentInstance.turno()).toBe(7);
    expect(boton().textContent).toContain('Camila Rojas · mar 03-11 · 09:00 a 17:00');
    expect(element.querySelector('#shift-options')).toBeNull();

    abrir();
    opciones()[3].click();
    fixture.detectChanges();
    expect(fixture.componentInstance.turno()).toBe('sin-turno');
    expect(boton().textContent).toContain('Sin turno registrado');
  });

  it('closes with Escape or a click outside, and says when there are no shifts', () => {
    const { fixture, element, abrir } = render();
    abrir();
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape' }));
    fixture.detectChanges();
    expect(element.querySelector('#shift-options')).toBeNull();

    fixture.componentInstance.turnos.set([]);
    abrir();
    expect(element.querySelector('.empty')?.textContent).toContain('No hay turnos registrados');
    document.body.click();
    fixture.detectChanges();
    expect(element.querySelector('#shift-options')).toBeNull();
  });
});
