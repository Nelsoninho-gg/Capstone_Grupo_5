const TOLERANCIA = 0.5;
const MINIMO_NUMERO_SUELTO = 10;
/**
 * Fechas y horas: sus números no son cifras del negocio y no deben validar otras por coincidencia.
 * Incluye listas y rangos de días ("5, 6 y 7 de octubre"); la marca de atrás evita que "$15 y 19 de mayo"
 * o "12,5 y 19 de mayo" escondan un monto o un decimal como si fueran días.
 */
const FECHAS_Y_HORAS =
  /\d{4}-\d{2}-\d{2}(T[\d:.+-]*)?|\b\d{1,2}:\d{2}(:\d{2})?\b|(?<![$\d.,]|\$\s)\b\d{1,2}(?:(?:,?\s+(?:y|al?|hasta)\s+(?:el\s+)?|,\s+)\d{1,2})*\s+de\s+(enero|febrero|marzo|abril|mayo|junio|julio|agosto|septiembre|octubre|noviembre|diciembre)\b/gi;

/** Lee un número en formato chileno ($1.482 o 1,5) o con punto decimal (1482.50). */
function leerNumero(token: string): number {
  const texto = token.replace(/[^\d.,]/g, '').replace(/[.,]+$/, '');
  const ultimoPunto = texto.lastIndexOf('.');
  const ultimaComa = texto.lastIndexOf(',');

  if (ultimoPunto >= 0 && ultimaComa >= 0) {
    return ultimaComa > ultimoPunto
      ? Number(texto.replace(/\./g, '').replace(',', '.'))
      : Number(texto.replace(/,/g, ''));
  }
  if (ultimaComa >= 0) {
    const partes = texto.split(',');
    return partes.length === 2 && partes[1].length <= 2
      ? Number(texto.replace(',', '.'))
      : Number(texto.replace(/,/g, ''));
  }
  if (ultimoPunto >= 0) {
    const partes = texto.split('.');
    return partes.length > 2 || (partes[1].length === 3 && partes[0] !== '0')
      ? Number(texto.replace(/\./g, ''))
      : Number(texto);
  }
  return Number(texto);
}

function esAnio(valor: number): boolean {
  return Number.isInteger(valor) && valor >= 1900 && valor <= 2100;
}

/**
 * Cifras de `texto` que no aparecen en `fuentes`. Evita que un modelo de IA muestre números
 * calculados por él: montos y porcentajes siempre se revisan, y los números sueltos desde 10.
 * shortcut: no revisa números menores a 10 ni comprueba que una cifra real se use con el significado
 * correcto; lo segundo requeriría interpretar el texto.
 */
export function cifrasNoVerificadas(texto: string, fuentes: string): string[] {
  const conocidos = (fuentes.replace(FECHAS_Y_HORAS, ' ').match(/\d[\d.,]*/g) ?? []).flatMap((token) => {
    const limpio = token.replace(/[.,]+$/, '');
    return [leerNumero(limpio), Number(limpio)].filter(Number.isFinite);
  });

  return (texto.replace(FECHAS_Y_HORAS, ' ').match(/\$\s?\d[\d.,]*|\d[\d.,]*\s?%|\d[\d.,]*/g) ?? [])
    .map((token) => token.trim().replace(/[.,]+$/, ''))
    .filter((token) => {
      const valor = leerNumero(token);
      const esMontoOPorcentaje = token.startsWith('$') || token.endsWith('%');
      if (!esMontoOPorcentaje && (valor < MINIMO_NUMERO_SUELTO || esAnio(valor))) {
        return false;
      }
      return valor !== 0 && !conocidos.some((c) => Math.abs(c - valor) < TOLERANCIA);
    });
}

function sinAcentos(texto: string): string {
  return texto
    .toLowerCase()
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '');
}

const PALABRAS_DE_CALENDARIO =
  /^(enero|febrero|marzo|abril|mayo|junio|julio|agosto|septiembre|octubre|noviembre|diciembre|lunes|martes|miercoles|jueves|viernes|sabado|domingo)$/;

/**
 * Palabras con mayúscula inicial en medio de una oración (nombres propios) que no aparecen en
 * `fuentes`. Evita mostrar personas o productos inventados por el modelo.
 * shortcut: no revisa la primera palabra de cada oración, que siempre lleva mayúscula.
 */
export function nombresNoVerificados(texto: string, fuentes: string): string[] {
  const conocidas = new Set(sinAcentos(fuentes).match(/[a-zñ]+/g) ?? []);
  const sospechosos = new Set<string>();

  for (const oracion of texto.split(/[.!?\n]+/)) {
    const palabras = oracion.match(/[\p{L}]+/gu) ?? [];
    for (const palabra of palabras.slice(1)) {
      const esNombre = /^\p{Lu}\p{Ll}+$/u.test(palabra);
      const normalizada = sinAcentos(palabra);
      if (esNombre && !PALABRAS_DE_CALENDARIO.test(normalizada) && !conocidas.has(normalizada)) {
        sospechosos.add(palabra);
      }
    }
  }
  return [...sospechosos];
}
