import {
  ARTICULOS_PREDICTIVOS_DEMO,
  ArticuloPredictivo,
  UMBRAL_DIAS_HISTORIAL,
  calcularConsumoDiarioEfectivo,
  cantidadSugeridaCompra,
  contarPredicciones,
  diasFaltantesParaUmbral,
  diasHastaMinimo,
  evaluarEstadoPredictivo,
  evaluarMadurezDatos,
  filtrarPredicciones,
  obtenerEstimacionPreliminar,
  tieneHistorialSuficiente,
  diasEnteros,
  textoDiasOperacion,
} from './prediccion.model';

describe('días enteros', () => {
  it('muestra los días enteros y hacia abajo', () => {
    expect(textoDiasOperacion(3.4)).toBe('3 días de operación');
    expect(textoDiasOperacion(1.9)).toBe('1 día de operación');
    expect(textoDiasOperacion(0.4)).toBe('menos de 1 día de operación');
    expect(textoDiasOperacion(0)).toBe('menos de 1 día de operación');
    expect(textoDiasOperacion(400)).toBe('más de 1 año de operación');
  });

  it('redondea hacia abajo y conserva la ausencia de dato', () => {
    expect(diasEnteros(3.9)).toBe(3);
    expect(diasEnteros(0.4)).toBe(0);
    expect(diasEnteros(null)).toBeNull();
  });
});

function crearArticulo(parcial: Partial<ArticuloPredictivo> = {}): ArticuloPredictivo {
  return {
    id: 'test-1',
    articulo: 'Harina Test',
    tipo: 'materia_prima',
    sucursalId: 1,
    sucursal: 'Nury Providencia',
    stockActual: 40,
    stockMinimo: 20,
    unidad: 'kg',
    diasHistorial: 45,
    consumoDiarioBase: 5,
    ...parcial,
  };
}

describe('prediccion.model (H4.5 T01, T03 y T08)', () => {
  it('verifica el umbral mínimo de 4 semanas (28 días) de historial', () => {
    expect(UMBRAL_DIAS_HISTORIAL).toBe(28);
    expect(tieneHistorialSuficiente(27)).toBe(false);
    expect(tieneHistorialSuficiente(28)).toBe(true);
    expect(tieneHistorialSuficiente(60)).toBe(true);
  });

  it('clasifica como datos-insuficientes cuando tiene menos de 28 días de historial sin importar el stock', () => {
    const nuevo = crearArticulo({ diasHistorial: 14, stockActual: 1, stockMinimo: 20 });
    expect(evaluarEstadoPredictivo(nuevo)).toBe('datos-insuficientes');
    expect(cantidadSugeridaCompra(nuevo)).toBe(0);
  });

  it('calcula los días hasta el mínimo y clasifica comprar-hoy cuando alcanza para 1,5 días o menos', () => {
    // (35 - 25) / 9.5 = 1.052 -> 1.1 días
    const cobertura = diasHastaMinimo(35, 25, 9.5);
    expect(cobertura).toBe(1.1);

    const harina = crearArticulo({
      stockActual: 35,
      stockMinimo: 25,
      consumoDiarioBase: 9.5,
    });
    expect(evaluarEstadoPredictivo(harina)).toBe('comprar-hoy');
  });

  it('con stock negativo o bajo el mínimo sugiere comprar, aunque no haya consumo calculado', () => {
    const base = {
      id: 'x',
      articulo: 'Empanada',
      tipo: 'producto' as const,
      sucursalId: 1,
      sucursal: 'S',
      stockMinimo: 0,
      unidad: 'un',
      diasHistorial: 40,
      consumoDiarioBase: 0,
    };

    expect(evaluarEstadoPredictivo({ ...base, stockActual: -4 })).toBe('comprar-hoy');
    expect(cantidadSugeridaCompra({ ...base, stockActual: -4 })).toBe(4);
    expect(evaluarEstadoPredictivo({ ...base, stockActual: 1, stockMinimo: 3 })).toBe('comprar-hoy');
    expect(cantidadSugeridaCompra({ ...base, stockActual: 1, stockMinimo: 3 })).toBe(2);
    // Sin consumo y justo en el mínimo no hay urgencia.
    expect(evaluarEstadoPredictivo({ ...base, stockActual: 0 })).toBe('estable');
    expect(cantidadSugeridaCompra({ ...base, stockActual: 0 })).toBe(0);
  });

  it('clasifica como proximo-pedido cuando quedan entre 1,6 y 4 días sobre el mínimo', () => {
    // (35 - 20) / 5 = 3 días de cobertura
    const cafe = crearArticulo({
      stockActual: 35,
      stockMinimo: 20,
      consumoDiarioBase: 5,
    });
    expect(evaluarEstadoPredictivo(cafe)).toBe('proximo-pedido');
  });

  it('clasifica como estable cuando quedan más de 4 días sobre el mínimo', () => {
    // (60 - 20) / 4 = 10 días
    const azucar = crearArticulo({
      stockActual: 60,
      stockMinimo: 20,
      consumoDiarioBase: 4,
    });
    expect(evaluarEstadoPredictivo(azucar)).toBe('estable');
  });

  it('calcula cantidad sugerida diaria por defecto (1 día) y redondea enteros para productos y decimal para materias primas', () => {
    const insumo = crearArticulo({
      tipo: 'materia_prima',
      stockActual: 21,
      stockMinimo: 20,
      consumoDiarioBase: 4.25,
    });
    // stockMeta (1 día) = 20 + 4.25 * 1 = 24.25 -> faltante = 3.25 -> 3.3
    expect(cantidadSugeridaCompra(insumo)).toBe(3.3);
    // Para 7 días si se especifica: stockMeta = 20 + 4.25 * 7 = 49.75 -> faltante = 28.75 -> 28.8
    expect(cantidadSugeridaCompra(insumo, 7)).toBe(28.8);

    const producto = crearArticulo({
      tipo: 'producto',
      stockActual: 6,
      stockMinimo: 5,
      consumoDiarioBase: 2.3,
    });
    // stockMeta (1 día) = 5 + 2.3 * 1 = 7.3 -> faltante = 1.3 -> ceil = 2
    expect(cantidadSugeridaCompra(producto)).toBe(2);
    // Para 7 días: stockMeta = 5 + 2.3 * 7 = 21.1 -> faltante = 15.1 -> ceil = 16
    expect(cantidadSugeridaCompra(producto, 7)).toBe(16);
  });

  it('cuenta y filtra predicciones por sucursal, urgencia, texto y tipo de artículo', () => {
    const conteo = contarPredicciones(ARTICULOS_PREDICTIVOS_DEMO);
    expect(conteo.total).toBe(ARTICULOS_PREDICTIVOS_DEMO.length);
    expect(conteo['comprar-hoy']).toBeGreaterThan(0);
    expect(conteo['datos-insuficientes']).toBeGreaterThan(0);

    const soloInsuficientes = filtrarPredicciones(
      ARTICULOS_PREDICTIVOS_DEMO,
      null,
      'datos-insuficientes',
      '',
    );
    expect(soloInsuficientes.every((i) => i.diasHistorial < 28)).toBe(true);

    const porTexto = filtrarPredicciones(ARTICULOS_PREDICTIVOS_DEMO, 1, 'todos', 'harina');
    expect(porTexto).toHaveLength(1);
    expect(porTexto[0].articulo).toContain('Harina');

    const soloProductos = filtrarPredicciones(
      ARTICULOS_PREDICTIVOS_DEMO,
      null,
      'todos',
      '',
      'producto',
    );
    expect(soloProductos.length).toBeGreaterThan(0);
    expect(soloProductos.every((i) => i.tipo === 'producto')).toBe(true);

    const soloMateriasPrimas = filtrarPredicciones(
      ARTICULOS_PREDICTIVOS_DEMO,
      null,
      'todos',
      '',
      'materia_prima',
    );
    expect(soloMateriasPrimas.length).toBeGreaterThan(0);
    expect(soloMateriasPrimas.every((i) => i.tipo === 'materia_prima')).toBe(true);
  });

  it('calcula días faltantes para el umbral de 28 días', () => {
    expect(diasFaltantesParaUmbral(0)).toBe(28);
    expect(diasFaltantesParaUmbral(10)).toBe(18);
    expect(diasFaltantesParaUmbral(27)).toBe(1);
    expect(diasFaltantesParaUmbral(28)).toBe(0);
    expect(diasFaltantesParaUmbral(45)).toBe(0);
  });

  it('calcula consumo diario efectivo dividiendo por días reales cuando es menor a 28 días', () => {
    // 50 unidades consumidas en 10 días = 5.0/día (no 50/28)
    expect(calcularConsumoDiarioEfectivo(50, 10)).toBe(5);
    // 140 unidades consumidas en 28 días o más = 5.0/día
    expect(calcularConsumoDiarioEfectivo(140, 28)).toBe(5);
    expect(calcularConsumoDiarioEfectivo(0, 10)).toBe(0);
  });

  it('entrega estimación preliminar desde el minuto 1 (< 28 días) con días faltantes y compra sugerida', () => {
    const articuloNuevo = crearArticulo({
      diasHistorial: 12,
      stockActual: 10,
      stockMinimo: 8,
      consumoDiarioBase: 4,
    });
    const est = obtenerEstimacionPreliminar(articuloNuevo);
    expect(est.esPreliminar).toBe(true);
    expect(est.diasRegistrados).toBe(12);
    expect(est.diasFaltantes).toBe(16);
    expect(est.consumoDiarioEstimado).toBe(4);
    // (10 - 8) / 4 = 0.5 días -> comprar-hoy
    expect(est.diasCoberturaEstimados).toBe(0.5);
    expect(est.urgenciaPreliminar).toBe('comprar-hoy');
    // stockMeta (1 d) = 8 + 4 = 12 -> faltante = 2
    expect(est.compraSugeridaPreliminar).toBe(2);
    expect(est.leyendaPeriodo).toContain('últimos 12 días');
    expect(est.leyendaPeriodo).toContain('faltan 16 días');
  });

  it('evalúa madurez estadística global indicando si requiere aviso de madurez', () => {
    const resumen = evaluarMadurezDatos(ARTICULOS_PREDICTIVOS_DEMO);
    expect(resumen.totalArticulos).toBe(ARTICULOS_PREDICTIVOS_DEMO.length);
    expect(resumen.articulosEnFasePreliminar).toBeGreaterThan(0);
    expect(resumen.requiereAvisoMadurez).toBe(true);
    expect(resumen.mensajeAdvertencia).toContain('Información preliminar');

    const listaMadura = [
      crearArticulo({ id: 'a1', diasHistorial: 30 }),
      crearArticulo({ id: 'a2', diasHistorial: 40 }),
    ];
    const resumenMaduro = evaluarMadurezDatos(listaMadura);
    expect(resumenMaduro.articulosEnFasePreliminar).toBe(0);
    expect(resumenMaduro.requiereAvisoMadurez).toBe(false);
    expect(resumenMaduro.diasFaltantes).toBe(0);
  });
});
