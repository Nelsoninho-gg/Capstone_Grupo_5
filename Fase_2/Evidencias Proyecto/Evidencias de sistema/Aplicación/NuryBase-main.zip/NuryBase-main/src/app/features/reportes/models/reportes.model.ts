/** Resumen de ventas de una sucursal en el período (H4.1 T02). */
export interface ResumenSucursal {
  /** null = ventas sin sucursal ("Sin sucursal"). */
  sucursalId: number | null;
  sucursal: string;
  ventas: number;
  total: number;
  ticketPromedio: number;
  normales: { ventas: number; total: number };
  empleado: { ventas: number; total: number };
  /** Total por medio de pago de las ventas válidas. */
  mediosPago: Record<string, number>;
  /** Anuladas aparte: no suman al total. */
  anuladas: { ventas: number; total: number };
}

/** Unidades y monto de un producto en una sucursal (H4.1 T03). */
export interface ProductoVendido {
  sucursalId: number | null;
  sucursal: string;
  productoId: number;
  producto: string;
  categoria: string | null;
  conReceta: boolean;
  unidades: number;
  ventas: number;
  montoBruto: number;
  /** Parte del descuento de empleado que le corresponde (se reparte por subtotal). */
  descuento: number;
  monto: number;
}

/** Sucursales elegidas (vacío = todas) y período en días de Chile, AAAA-MM-DD. */
export interface FiltroReporte {
  sucursales: number[];
  desde: string;
  hasta: string;
}

/** Desempeño de un cajero en el período (H4.3 T02). */
export interface RendimientoCajero {
  /** null = ventas sin cajero atribuido ("Sin cajero"). */
  cajeroId: number | null;
  cajero: string;
  sucursales: string;
  turnos: number;
  ventas: number;
  total: number;
  ventaPromedio: number;
  /** Unidades de productos vendidas (sin anuladas). */
  productos: number;
  /** Anuladas aparte: no cuentan en las métricas. */
  anuladas: { ventas: number; total: number };
}

/**
 * Costo actual de un producto (H4.4 T03): por su receta vigente, por su último precio de
 * compra o sin costo (no se supone 0).
 */
export interface CostoProducto {
  productoId: number;
  origen: 'receta' | 'compra' | 'sin_costo';
  costoUnitario: number | null;
  ingredientes: number;
  /** Ingredientes de la receta sin costo: el costo de la receta queda incompleto. */
  ingredientesSinCosto: number;
}

/**
 * Turno elegido en la pestaña Cajeros (H4.3 T03): null = todo el período; un id = ese turno
 * real; 'sin-turno' = solo las ventas del período que no quedaron en ningún turno.
 */
export type FiltroTurno = number | 'sin-turno' | null;

/** Un turno real del período con sus cifras (H4.3 T03); turnoId null = ventas sin turno. */
export interface TurnoReporte {
  turnoId: number | null;
  cajeroId: number | null;
  cajero: string;
  sucursalId: number | null;
  sucursal: string | null;
  /** Hora de Chile, AAAA-MM-DDTHH:MM:SS. */
  inicio: string | null;
  /** null = turno abierto. */
  fin: string | null;
  ventas: number;
  total: number;
  anuladas: number;
}

/**
 * Cuadratura de un artículo (H4.1 T04): lo que las ventas del período debieron descontar contra
 * lo que registró movimientos_stock para esas ventas.
 */
export interface CuadraturaArticulo {
  sucursalId: number | null;
  sucursal: string;
  tipo: 'materia_prima' | 'producto';
  articuloId: number;
  articulo: string;
  unidad: string;
  esperado: number;
  registrado: number;
  /** registrado − esperado: positivo = el kardex descontó de más. */
  diferencia: number;
  cuadra: boolean;
}
