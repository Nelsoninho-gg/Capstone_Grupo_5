import { describe, expect, it } from 'vitest';
import { parsearFechaServidor } from './fecha-servidor';

describe('parsearFechaServidor', () => {
  const esperado = new Date('2026-11-16T22:08:30.000Z');

  it('interpreta fechas sin zona horaria como UTC', () => {
    expect(parsearFechaServidor('2026-11-16T22:08:30')).toEqual(esperado);
  });

  it('respeta offsets explícitos de PostgREST y PostgreSQL', () => {
    expect(parsearFechaServidor('2026-11-16T22:08:30Z')).toEqual(esperado);
    expect(parsearFechaServidor('2026-11-16T19:08:30-03:00')).toEqual(esperado);
    expect(parsearFechaServidor('2026-11-16T19:08:30-0300')).toEqual(esperado);
    expect(parsearFechaServidor('2026-11-16T19:08:30-03')).toEqual(esperado);
  });
});
