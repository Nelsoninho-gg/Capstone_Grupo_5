import { Injectable, inject } from '@angular/core';
import { Observable, map } from 'rxjs';
import {
  CostoProductoApi,
  CuadraturaArticuloApi,
  ProductoVendidoSucursalApi,
  RendimientoCajeroApi,
  ReportesApiService,
  ResumenVentasSucursalApi,
  TurnoReporteApi,
} from '../../../core/api/reportes-api.service';
import {
  CostoProducto,
  CuadraturaArticulo,
  FiltroReporte,
  FiltroTurno,
  ProductoVendido,
  RendimientoCajero,
  ResumenSucursal,
  TurnoReporte,
} from '../models/reportes.model';
import {
  PromocionesPeriodo,
  PromocionesProducto,
  promocionesDia,
  promocionesProducto,
} from '../models/reporte-promociones.model';

/** Reportes de ventas por sucursal (H4.1) y por cajero (H4.3): convierte las filas de la API al modelo de la pantalla. */
@Injectable({ providedIn: 'root' })
export class ReportesService {
  private readonly api = inject(ReportesApiService);

  resumenPorSucursal(filtro: FiltroReporte): Observable<ResumenSucursal[]> {
    return this.api.resumenVentasSucursal(filtro).pipe(map((filas) => filas.map(resumen)));
  }

  productosPorSucursal(filtro: FiltroReporte): Observable<ProductoVendido[]> {
    return this.api.productosVendidosSucursal(filtro).pipe(map((filas) => filas.map(producto)));
  }

  /** Con `turno` (H4.3 T03) solo cuentan las ventas de ese turno o, con 'sin-turno', las sin turno. */
  rendimientoCajeros(
    filtro: FiltroReporte,
    turno: FiltroTurno = null,
  ): Observable<RendimientoCajero[]> {
    const filas$ =
      turno === null
        ? this.api.rendimientoCajeros(filtro)
        : this.api.rendimientoCajeros(filtro, turno === 'sin-turno' ? 0 : turno);
    return filas$.pipe(map((filas) => filas.map(cajero)));
  }

  /** H5.2 T08: lo vendido con promoción y el margen sacrificado, día por día. */
  promocionesPorDia(filtro: FiltroReporte): Observable<PromocionesPeriodo[]> {
    return this.api.promocionesPorDia(filtro).pipe(map((filas) => filas.map(promocionesDia)));
  }

  /** H5.2 T08: lo vendido con promoción y el margen sacrificado, por producto. */
  promocionesPorProducto(filtro: FiltroReporte): Observable<PromocionesProducto[]> {
    return this.api
      .promocionesPorProducto(filtro)
      .pipe(map((filas) => filas.map(promocionesProducto)));
  }

  costoActualProductos(): Observable<CostoProducto[]> {
    return this.api.costoActualProductos().pipe(map((filas) => filas.map(costo)));
  }

  turnosReporte(filtro: FiltroReporte): Observable<TurnoReporte[]> {
    return this.api.turnosReporte(filtro).pipe(map((filas) => filas.map(turno)));
  }

  cuadraturaVentasStock(filtro: FiltroReporte): Observable<CuadraturaArticulo[]> {
    return this.api.cuadraturaVentasStock(filtro).pipe(map((filas) => filas.map(cuadratura)));
  }
}

function costo(fila: CostoProductoApi): CostoProducto {
  return {
    productoId: fila.producto_id,
    origen: fila.origen,
    costoUnitario: fila.costo_unitario === null ? null : Number(fila.costo_unitario),
    ingredientes: Number(fila.ingredientes),
    ingredientesSinCosto: Number(fila.ingredientes_sin_costo),
  };
}

function turno(fila: TurnoReporteApi): TurnoReporte {
  return {
    turnoId: fila.turno_id,
    cajeroId: fila.cajero_id,
    cajero: fila.cajero,
    sucursalId: fila.sucursal_id,
    sucursal: fila.sucursal,
    inicio: fila.inicio,
    fin: fila.fin,
    ventas: Number(fila.ventas),
    total: Number(fila.total),
    anuladas: Number(fila.anuladas),
  };
}

function cuadratura(fila: CuadraturaArticuloApi): CuadraturaArticulo {
  return {
    sucursalId: fila.sucursal_id,
    sucursal: fila.sucursal,
    tipo: fila.tipo,
    articuloId: fila.articulo_id,
    articulo: fila.articulo,
    unidad: fila.unidad,
    esperado: Number(fila.esperado),
    registrado: Number(fila.registrado),
    diferencia: Number(fila.diferencia),
    cuadra: fila.cuadra,
  };
}

function cajero(fila: RendimientoCajeroApi): RendimientoCajero {
  return {
    cajeroId: fila.cajero_id,
    cajero: fila.cajero,
    sucursales: fila.sucursales,
    turnos: Number(fila.turnos),
    ventas: Number(fila.ventas),
    total: Number(fila.total),
    ventaPromedio: Number(fila.venta_promedio),
    productos: Number(fila.productos),
    anuladas: { ventas: Number(fila.anuladas), total: Number(fila.total_anuladas) },
  };
}

function resumen(fila: ResumenVentasSucursalApi): ResumenSucursal {
  return {
    sucursalId: fila.sucursal_id,
    sucursal: fila.sucursal,
    ventas: Number(fila.ventas),
    total: Number(fila.total),
    ticketPromedio: Number(fila.ticket_promedio),
    normales: { ventas: Number(fila.ventas_normales), total: Number(fila.total_normales) },
    empleado: { ventas: Number(fila.ventas_empleado), total: Number(fila.total_empleado) },
    mediosPago: Object.fromEntries(
      Object.entries(fila.medios_pago ?? {}).map(([medio, monto]) => [medio, Number(monto)]),
    ),
    anuladas: { ventas: Number(fila.anuladas), total: Number(fila.total_anuladas) },
  };
}

function producto(fila: ProductoVendidoSucursalApi): ProductoVendido {
  return {
    sucursalId: fila.sucursal_id,
    sucursal: fila.sucursal,
    productoId: fila.producto_id,
    producto: fila.producto,
    categoria: fila.categoria,
    conReceta: fila.con_receta,
    unidades: Number(fila.unidades),
    ventas: Number(fila.ventas),
    montoBruto: Number(fila.monto_bruto),
    descuento: Number(fila.descuento),
    monto: Number(fila.monto),
  };
}
