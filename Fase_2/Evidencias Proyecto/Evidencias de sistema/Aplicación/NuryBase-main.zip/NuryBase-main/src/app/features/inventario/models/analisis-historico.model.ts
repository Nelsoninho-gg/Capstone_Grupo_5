import { TipoArticulo } from './inventario.model';
import {
  ArticuloPredictivo,
  UMBRAL_DIAS_HISTORIAL,
  tieneHistorialSuficiente,
} from './prediccion.model';

export type MotivoPicoConsumo = 'promocion' | 'evento-puntual' | 'anomalia-estadistica';

export type EstrategiaTratamientoPicos = 'excluir' | 'atenuar';

export interface PuntoConsumoDiario {
  /** Fecha en formato ISO YYYY-MM-DD */
  fecha: string;
  /** Cantidad consumida en el día */
  cantidad: number;
  /** Indica si el consumo ocurrió durante una promoción activa */
  esPromocion?: boolean;
  /** Indica si hubo un evento puntual aislado en la sede universitaria */
  esEventoEspecial?: boolean;
  /** Explicación opcional del evento o promoción */
  nota?: string;
}

export interface PicoConsumoDetectado {
  fecha: string;
  cantidadOriginal: number;
  /** Cantidad asignada tras el tratamiento (null si la estrategia fue 'excluir') */
  cantidadTratada: number | null;
  motivo: MotivoPicoConsumo;
  detalle: string;
}

export interface ResultadoDepuracionSerie {
  serieOriginal: readonly PuntoConsumoDiario[];
  serieDepurada: PuntoConsumoDiario[];
  picosDetectados: PicoConsumoDetectado[];
  promedioCrudo: number;
  promedioBaseLimpio: number;
  desviacionEstandarBase: number;
  umbralCorteSuperior: number;
}

export interface PayloadHistoricoIA {
  articuloId: string;
  nombre: string;
  tipo: TipoArticulo;
  sucursalId: number;
  sucursal: string;
  unidad: string;
  stockActual: number;
  stockMinimo: number;
  diasHistorial: number;
  aptoParaPredecir: boolean;
  metricasConsumo: {
    promedioDiarioBase: number;
    promedioDiarioSinFiltrar: number;
    desviacionEstandar: number;
    diasNormalesContabilizados: number;
    totalPicosAislados: number;
  };
  picosAislados: {
    fecha: string;
    cantidad: number;
    motivo: MotivoPicoConsumo;
    nota: string;
  }[];
}

function redondear2(valor: number): number {
  return Math.round(valor * 100) / 100;
}

/**
 * Calcula media aritmética y desviación estándar poblacional de una lista numérica.
 */
export function calcularMediaYDesviacion(valores: readonly number[]): {
  media: number;
  desviacion: number;
} {
  const validos = valores.filter((v) => Number.isFinite(v) && v >= 0);
  if (validos.length === 0) {
    return { media: 0, desviacion: 0 };
  }
  const suma = validos.reduce((acc, v) => acc + v, 0);
  const media = suma / validos.length;
  const varianza =
    validos.reduce((acc, v) => acc + (v - media) ** 2, 0) / validos.length;
  return {
    media: redondear2(media),
    desviacion: redondear2(Math.sqrt(varianza)),
  };
}

/**
 * Calcula mediana y rango intercuartílico (IQR) para detección robusta frente a valores extremos.
 */
export function calcularCuartiles(valores: readonly number[]): {
  mediana: number;
  q1: number;
  q3: number;
  iqr: number;
} {
  const ordenados = valores
    .filter((v) => Number.isFinite(v) && v >= 0)
    .slice()
    .sort((a, b) => a - b);

  if (ordenados.length === 0) {
    return { mediana: 0, q1: 0, q3: 0, iqr: 0 };
  }

  const percentil = (p: number): number => {
    const pos = (ordenados.length - 1) * p;
    const base = Math.floor(pos);
    const resto = pos - base;
    const siguiente = ordenados[base + 1] ?? ordenados[base];
    return ordenados[base] + resto * (siguiente - ordenados[base]);
  };

  const q1 = percentil(0.25);
  const mediana = percentil(0.5);
  const q3 = percentil(0.75);
  return {
    mediana: redondear2(mediana),
    q1: redondear2(q1),
    q3: redondear2(q3),
    iqr: redondear2(q3 - q1),
  };
}

/**
 * H4.5 T04: Depura una serie histórica de consumo diario identificando picos por promociones,
 * eventos puntuales o anomalías estadísticas (outliers) para no contaminar el patrón base.
 *
 * @param serie Serie histórica de puntos diarios de consumo.
 * @param estrategia 'atenuar' reemplaza el pico por el promedio base normal; 'excluir' omite el día.
 * @param factorSigma Múltiplo de desviaciones estándar sobre la media para marcar anomalía (por defecto 2).
 */
export function depurarSerieConsumo(
  serie: readonly PuntoConsumoDiario[],
  estrategia: EstrategiaTratamientoPicos = 'atenuar',
  factorSigma = 2,
): ResultadoDepuracionSerie {
  const puntosValidos = serie.filter(
    (p) => Number.isFinite(p.cantidad) && p.cantidad >= 0,
  );

  if (puntosValidos.length === 0) {
    return {
      serieOriginal: serie,
      serieDepurada: [],
      picosDetectados: [],
      promedioCrudo: 0,
      promedioBaseLimpio: 0,
      desviacionEstandarBase: 0,
      umbralCorteSuperior: 0,
    };
  }

  const cantidadesCrudas = puntosValidos.map((p) => p.cantidad);
  const { media: promedioCrudo } = calcularMediaYDesviacion(cantidadesCrudas);

  // 1. Separar puntos sin etiquetas de evento/promoción para estimar la línea base preliminar
  const sinEtiquetaEspecial = puntosValidos
    .filter((p) => !p.esPromocion && !p.esEventoEspecial)
    .map((p) => p.cantidad);

  const muestraReferencia =
    sinEtiquetaEspecial.length > 0 ? sinEtiquetaEspecial : cantidadesCrudas;

  const diasCero = muestraReferencia.filter((v) => v === 0).length;
  const esIntermitente = diasCero > muestraReferencia.length / 2;
  const diasConVenta = muestraReferencia.filter((v) => v > 0);
  const cuartilesVentas =
    esIntermitente && diasConVenta.length >= 4 ? calcularCuartiles(diasConVenta) : null;

  const { mediana, q3, iqr } = calcularCuartiles(muestraReferencia);
  const { media: mediaRef, desviacion: desvRef } =
    calcularMediaYDesviacion(muestraReferencia);

  // Umbral robusto combinando criterio IQR (Tukey) y criterio Sigma
  const cotaSigma = desvRef > 0 ? mediaRef + factorSigma * desvRef : mediaRef * 1.8;
  // Con la mayoría de los días en cero el IQR y la mediana son 0: solo sirve la regla sigma.
  const cotaIqr = iqr > 0 ? q3 + 1.5 * iqr : mediana > 0 ? mediana * 1.8 : cotaSigma;
  const umbralCorteSuperior = redondear2(
    // Propuesta B (demanda intermitente): si más de la mitad de los días son cero,
    // el corte estadístico se calcula solo entre los días con venta (mínimo 4 días).
    esIntermitente
      ? cuartilesVentas
        ? Math.max(cuartilesVentas.q3 + 1.5 * cuartilesVentas.iqr, cuartilesVentas.mediana * 1.8)
        : 0
      : Math.max(mediana * 1.35, Math.min(cotaIqr, cotaSigma)),
  );

  // 2. Identificar qué días son normales y cuáles son picos
  const normales: number[] = [];
  for (const punto of puntosValidos) {
    const esPicoEtiquetado = Boolean(punto.esPromocion || punto.esEventoEspecial);
    const esPicoEstadistico =
      umbralCorteSuperior > 0 && punto.cantidad > umbralCorteSuperior;
    if (!esPicoEtiquetado && !esPicoEstadistico) {
      normales.push(punto.cantidad);
    }
  }

  const baseParaPromedio = normales.length > 0 ? normales : [mediana];
  const { media: promedioBasePreliminar, desviacion: desviacionBase } =
    calcularMediaYDesviacion(baseParaPromedio);

  // 3. Construir la serie depurada y el registro de picos
  const serieDepurada: PuntoConsumoDiario[] = [];
  const picosDetectados: PicoConsumoDetectado[] = [];

  for (const punto of puntosValidos) {
    let motivo: MotivoPicoConsumo | null = null;
    let detalle = '';

    if (punto.esPromocion) {
      motivo = 'promocion';
      detalle = punto.nota?.trim() || 'Promoción puntual activa';
    } else if (punto.esEventoEspecial) {
      motivo = 'evento-puntual';
      detalle = punto.nota?.trim() || 'Evento especial aislado en sede';
    } else if (umbralCorteSuperior > 0 && punto.cantidad > umbralCorteSuperior) {
      motivo = 'anomalia-estadistica';
      detalle =
        punto.nota?.trim() ||
        `Consumo atípico (${punto.cantidad} supera el umbral normal de ${umbralCorteSuperior})`;
    }

    if (motivo !== null) {
      if (estrategia === 'excluir') {
        picosDetectados.push({
          fecha: punto.fecha,
          cantidadOriginal: punto.cantidad,
          cantidadTratada: null,
          motivo,
          detalle,
        });
      } else {
        const cantidadAtenuada = redondear2(
          cuartilesVentas ? cuartilesVentas.mediana : promedioBasePreliminar,
        );
        picosDetectados.push({
          fecha: punto.fecha,
          cantidadOriginal: punto.cantidad,
          cantidadTratada: cantidadAtenuada,
          motivo,
          detalle,
        });
        serieDepurada.push({
          ...punto,
          cantidad: cantidadAtenuada,
        });
      }
    } else {
      serieDepurada.push({ ...punto });
    }
  }

  const { media: promedioBaseLimpio } =
    serieDepurada.length > 0
      ? calcularMediaYDesviacion(serieDepurada.map((p) => p.cantidad))
      : { media: promedioBasePreliminar };

  return {
    serieOriginal: puntosValidos,
    serieDepurada,
    picosDetectados,
    promedioCrudo,
    promedioBaseLimpio,
    desviacionEstandarBase: desviacionBase,
    umbralCorteSuperior,
  };
}

/** Movimiento de consumo tal como lo entrega v_movimientos_articulos. */
export interface MovimientoConsumo {
  tipo_articulo: TipoArticulo;
  articulo_id: number;
  sucursal_id: number;
  tipo_movimiento: string;
  cantidad: number | string;
  fecha: string;
}

const MOVIMIENTOS_DE_CONSUMO = new Set(['venta', 'anulacion_venta', 'merma']);

export function claveSerieConsumo(tipo: TipoArticulo, articuloId: number, sucursalId: number): string {
  return `${tipo}-${articuloId}-${sucursalId}`;
}

function diaChile(fecha: string): string {
  return new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Santiago' }).format(new Date(fecha));
}

/**
 * Arma la serie de consumo neto por artículo y sucursal, solo con días operativos: aquellos en que
 * la sucursal registró ventas. Las cafeterías están en universidades, así que fines de semana,
 * feriados y vacaciones sin actividad no entran como ceros que bajarían el promedio. Si la sucursal
 * vendió ese día y el artículo no, sí cuenta como cero.
 */
export function construirSeriesOperativas(
  movimientos: readonly MovimientoConsumo[],
): Map<string, PuntoConsumoDiario[]> {
  const diasPorSucursal = new Map<number, Set<string>>();
  const consumoPorArticulo = new Map<string, { sucursalId: number; dias: Map<string, number> }>();

  for (const movimiento of movimientos) {
    if (!MOVIMIENTOS_DE_CONSUMO.has(movimiento.tipo_movimiento)) continue;
    const dia = diaChile(movimiento.fecha);

    if (movimiento.tipo_movimiento === 'venta') {
      const dias = diasPorSucursal.get(movimiento.sucursal_id) ?? new Set<string>();
      diasPorSucursal.set(movimiento.sucursal_id, dias.add(dia));
    }

    const clave = claveSerieConsumo(movimiento.tipo_articulo, movimiento.articulo_id, movimiento.sucursal_id);
    const articulo = consumoPorArticulo.get(clave) ?? { sucursalId: movimiento.sucursal_id, dias: new Map() };
    // Ventas y mermas restan stock (negativo) y una anulación lo repone (positivo).
    articulo.dias.set(dia, (articulo.dias.get(dia) ?? 0) - Number(movimiento.cantidad));
    consumoPorArticulo.set(clave, articulo);
  }

  const series = new Map<string, PuntoConsumoDiario[]>();
  for (const [clave, { sucursalId, dias }] of consumoPorArticulo) {
    const operativos = [...(diasPorSucursal.get(sucursalId) ?? [])].sort();
    series.set(
      clave,
      operativos.map((fecha) => ({ fecha, cantidad: Math.max(0, redondear2(dias.get(fecha) ?? 0)) })),
    );
  }
  return series;
}

/**
 * H4.5 T04: Construye el payload compacto y depurado que se envía al orquestador de IA,
 * separando el patrón de consumo diario normal de los picos aislados.
 */
export function construirPayloadHistoricoIA(
  articulo: ArticuloPredictivo,
  serie: readonly PuntoConsumoDiario[],
  estrategia: EstrategiaTratamientoPicos = 'atenuar',
): PayloadHistoricoIA {
  const depuracion = depurarSerieConsumo(serie, estrategia);
  const diasEfectivos = Math.max(articulo.diasHistorial, serie.length);
  const apto = tieneHistorialSuficiente(diasEfectivos, UMBRAL_DIAS_HISTORIAL);

  const promedioFinal =
    serie.length > 0 ? depuracion.promedioBaseLimpio : articulo.consumoDiarioBase;
  const promedioSinFiltrar =
    serie.length > 0 ? depuracion.promedioCrudo : articulo.consumoDiarioBase;

  return {
    articuloId: articulo.id,
    nombre: articulo.articulo,
    tipo: articulo.tipo,
    sucursalId: articulo.sucursalId,
    sucursal: articulo.sucursal,
    unidad: articulo.unidad,
    stockActual: articulo.stockActual,
    stockMinimo: articulo.stockMinimo,
    diasHistorial: diasEfectivos,
    aptoParaPredecir: apto,
    metricasConsumo: {
      promedioDiarioBase: promedioFinal,
      promedioDiarioSinFiltrar: promedioSinFiltrar,
      desviacionEstandar: depuracion.desviacionEstandarBase,
      diasNormalesContabilizados:
        depuracion.serieOriginal.length - depuracion.picosDetectados.length,
      totalPicosAislados: depuracion.picosDetectados.length,
    },
    picosAislados: depuracion.picosDetectados.map((p) => ({
      fecha: p.fecha,
      cantidad: p.cantidadOriginal,
      motivo: p.motivo,
      nota: p.detalle,
    })),
  };
}
