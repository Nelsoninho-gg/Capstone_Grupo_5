import { inject } from '@angular/core';
import { Routes } from '@angular/router';
import { authGuard, roleGuard } from './core/guards/auth.guard';
import { PosService } from './features/pos/services/pos.service';

export const routes: Routes = [
  {
    path: '',
    // Con el turno abierto, volver a la raíz retoma el POS en vez de pedir iniciar turno.
    redirectTo: () => (inject(PosService).isRegisterOpen() ? 'pos' : 'caja'),
    pathMatch: 'full',
  },
  {
    path: 'login',
    loadChildren: () => import('./features/auth/auth.routes').then((m) => m.AUTH_ROUTES),
  },
  {
    path: '',
    canActivate: [authGuard],
    loadComponent: () => import('./layout/main-layout/main-layout').then((m) => m.MainLayout),
    children: [
      {
        path: 'dashboard',
        canActivate: [roleGuard],
        data: { allowedRoles: ['admin'] },
        loadComponent: () =>
          import('./features/dashboard/pages/dashboard/dashboard').then((m) => m.Dashboard),
      },
      {
        // Reportes de ventas (H4.1), por cajero (H4.3) y por producto (H4.4): solo administrador.
        path: 'reportes',
        canActivate: [roleGuard],
        data: { allowedRoles: ['admin'] },
        loadComponent: () =>
          import('./features/reportes/pages/reportes/reportes').then((m) => m.Reportes),
      },
      {
        path: 'pos',
        canActivate: [roleGuard],
        data: { allowedRoles: ['admin', 'cajero'] },
        loadChildren: () => import('./features/pos/pos.routes').then((m) => m.POS_ROUTES),
      },
      {
        path: 'caja',
        canActivate: [roleGuard],
        data: { allowedRoles: ['admin', 'cajero'] },
        loadChildren: () => import('./features/caja/caja.routes').then((m) => m.CAJA_ROUTES),
      },
      {
        path: 'product-master',
        canActivate: [roleGuard],
        // El bodeguero entra para administrar Ingredientes y ver los productos sin editarlos.
        data: { allowedRoles: ['admin', 'cajero', 'bodeguero'] },
        loadChildren: () =>
          import('./features/products/products.routes').then((m) => m.PRODUCTS_ROUTES),
      },
      {
        // Los ingredientes se administran en la pestaña Ingredientes del Maestro de Productos.
        // Se mantiene la ruta para que los enlaces guardados sigan funcionando.
        path: 'inventario/ingredientes',
        redirectTo: '/product-master?vista=ingredientes',
      },
      {
        // Fuera de /inventario: el menú marca «Inventario» en cualquier ruta que empiece así.
        path: 'facturas',
        canActivate: [roleGuard],
        data: { allowedRoles: ['admin', 'bodeguero'] },
        loadChildren: () =>
          import('./features/facturas/facturas.routes').then((m) => m.FACTURAS_ROUTES),
      },
      {
        path: 'inventario',
        canActivate: [roleGuard],
        // El cajero entra solo a la pestaña de almuerzo de empleados (H2.13).
        data: { allowedRoles: ['admin', 'bodeguero', 'cajero'] },
        loadComponent: () =>
          import('./features/inventario/pages/inventario/inventario').then(
            (m) => m.Inventario,
          ),
      },
      {
        path: 'gestion-negocio/sucursales',
        canActivate: [roleGuard],
        data: { allowedRoles: ['admin'] },
        loadComponent: () =>
          import('./features/gestion-negocio/pages/sucursales/sucursales').then(
            (m) => m.Sucursales,
          ),
      },
      {
        // Solo el administrador crea y programa promociones; el cajero las aplica en la venta (H5.2).
        path: 'gestion-negocio/promociones',
        canActivate: [roleGuard],
        data: { allowedRoles: ['admin'] },
        loadComponent: () =>
          import('./features/gestion-negocio/pages/promociones/promociones').then(
            (m) => m.Promociones,
          ),
      },
      {
        path: 'gestion-negocio',
        canActivate: [roleGuard],
        data: { allowedRoles: ['admin'] },
        loadComponent: () =>
          import('./features/gestion-negocio/pages/gestion-negocio/gestion-negocio').then(
            (m) => m.GestionNegocio,
          ),
      },
      {
        path: 'anulacion-venta',
        canActivate: [roleGuard],
        data: { allowedRoles: ['admin', 'cajero'] },
        loadComponent: () =>
          import('./features/anulacion-venta/pages/anulacion-venta/anulacion-venta').then(
            (m) => m.AnulacionVenta,
          ),
      },
      {
        path: 'sin-acceso',
        loadComponent: () =>
          import('./shared/pages/access-denied/access-denied').then((m) => m.AccessDenied),
      },
    ],
  },
  {
    path: '**',
    redirectTo: 'caja',
  },
];
