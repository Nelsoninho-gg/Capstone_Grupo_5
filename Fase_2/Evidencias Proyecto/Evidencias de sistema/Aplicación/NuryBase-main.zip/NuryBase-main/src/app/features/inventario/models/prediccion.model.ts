import type { PuntoConsumoDiario } from './analisis-historico.model';
import { TipoArticulo } from './inventario.model';

/** Umbral mínimo exigido por H4.5 (4 semanas = 28 días) para poder estimar consumo. */
export const UMBRAL_SEMANAS_HISTORIAL = 4;
export const UMBRAL_DIAS_HISTORIAL = UMBRAL_SEMANAS_HISTORIAL * 7;

export type EstadoPrediccion =
  | 'comprar-hoy'
  | 'proximo-pedido'
  | 'estable'
  | 'datos-insuficientes';

export type FiltroUrgenciaPrediccion = 'todos' | EstadoPrediccion;

export type FiltroTipoPrediccion = 'todos' | TipoArticulo;

export interface ArticuloPredictivo {
  id: string;
  articulo: string;
  tipo: TipoArticulo;
  sucursalId: number;
  sucursal: string;
  stockActual: number;
  stockMinimo: number;
  unidad: string;
  /** Días con registros de uso. Si es menor a 28 días se muestra "Datos insuficientes". */
  diasHistorial: number;
  /** Consumo diario promedio normal, en días operativos y sin atípicos cuando hay serie. */
  consumoDiarioBase: number;
  /** Consumo por día operativo de los últimos 28 días; solo con historial suficiente. */
  serieConsumo?: readonly PuntoConsumoDiario[];
}

export interface ResumenPredicciones {
  'comprar-hoy': number;
  'proximo-pedido': number;
  estable: number;
  'datos-insuficientes': number;
  total: number;
}

export interface EstimacionPreliminarArticulo {
  esPreliminar: boolean;
  diasRegistrados: number;
  diasFaltantes: number;
  consumoDiarioEstimado: number;
  diasCoberturaEstimados: number | null;
  compraSugeridaPreliminar: number;
  urgenciaPreliminar: 'comprar-hoy' | 'proximo-pedido' | 'estable';
  leyendaPeriodo: string;
}

export interface ResumenMadurezDatos {
  diasRegistradosMax: number;
  diasRegistradosMin: number;
  diasFaltantes: number;
  porcentajeCompletado: number;
  articulosEnFasePreliminar: number;
  totalArticulos: number;
  requiereAvisoMadurez: boolean;
  tipoAvisoMadurez: 'sucursal-temprana' | 'articulos-nuevos' | 'consolidado';
  mensajeAdvertencia: string;
}

export const ETIQUETAS_ESTADO_PREDICCION: Record<EstadoPrediccion, string> = {
  'comprar-hoy': 'Sugerido comprar hoy',
  'proximo-pedido': 'Sugerido comprar pronto',
  estable: 'Stock suficiente',
  'datos-insuficientes': 'Datos insuficientes para sugerir',
};

/**
 * H4.5 T03: Verifica si el artículo cumple las 4 semanas (28 días) mínimas de historial.
 */
export function tieneHistorialSuficiente(
  diasHistorial: number,
  umbralDias: number = UMBRAL_DIAS_HISTORIAL,
): boolean {
  return Number.isFinite(diasHistorial) && diasHistorial >= umbralDias;
}

/**
 * Calcula los días faltantes para alcanzar el umbral mínimo de 28 días.
 */
export function diasFaltantesParaUmbral(
  diasHistorial: number,
  umbralDias: number = UMBRAL_DIAS_HISTORIAL,
): number {
  if (!Number.isFinite(diasHistorial) || diasHistorial <= 0) {
    return umbralDias;
  }
  return Math.max(0, umbralDias - Math.floor(diasHistorial));
}

/**
 * Calcula el consumo promedio diario efectivo adaptado a los días registrados reales.
 * Si lleva menos de 28 días (minuto 1), divide por los días que realmente lleva de registro
 * para no diluir artificialmente el consumo inicial.
 */
export function calcularConsumoDiarioEfectivo(
  consumoTotalPeriodo: number,
  diasHistorial: number,
  umbralDias: number = UMBRAL_DIAS_HISTORIAL,
): number {
  if (!Number.isFinite(consumoTotalPeriodo) || consumoTotalPeriodo <= 0) {
    return 0;
  }
  const diasValidos = Number.isFinite(diasHistorial) && diasHistorial > 0 ? diasHistorial : 1;
  const divisor = diasValidos >= umbralDias ? umbralDias : diasValidos;
  return Math.round((consumoTotalPeriodo / divisor) * 100) / 100;
}

/**
 * Entrega la estimación preliminar de un artículo desde el minuto 1 (< 28 días),
 * permitiendo a la UI mostrar datos de los últimos X días y advertir cuántos faltan.
 */
export function obtenerEstimacionPreliminar(
  articulo: ArticuloPredictivo,
  diasObjetivo = 1,
): EstimacionPreliminarArticulo {
  const diasFaltantes = diasFaltantesParaUmbral(articulo.diasHistorial);
  const esPreliminar = !tieneHistorialSuficiente(articulo.diasHistorial);
  const consumo = articulo.consumoDiarioBase > 0 ? articulo.consumoDiarioBase : 0;
  const diasCobertura = diasHastaMinimo(articulo.stockActual, articulo.stockMinimo, consumo);

  let urgenciaPreliminar: 'comprar-hoy' | 'proximo-pedido' | 'estable' = 'estable';
  if (articulo.stockActual <= articulo.stockMinimo || (diasCobertura !== null && diasCobertura <= 1.5)) {
    urgenciaPreliminar = 'comprar-hoy';
  } else if (diasCobertura !== null && diasCobertura <= 4) {
    urgenciaPreliminar = 'proximo-pedido';
  }

  let compraSugeridaPreliminar = 0;
  if (consumo > 0) {
    const stockMeta = articulo.stockMinimo + consumo * diasObjetivo;
    const faltante = stockMeta - articulo.stockActual;
    if (faltante > 0) {
      compraSugeridaPreliminar =
        articulo.tipo === 'producto'
          ? Math.ceil(faltante)
          : Math.round(faltante * 10) / 10;
    }
  }

  const leyendaPeriodo = esPreliminar
    ? articulo.diasHistorial <= 0
      ? 'Sin registros de consumo todavía'
      : `Datos de los últimos ${articulo.diasHistorial} días (faltan ${diasFaltantes} días para cumplir 28)`
    : `Historial consolidado (${articulo.diasHistorial} días)`;

  return {
    esPreliminar,
    diasRegistrados: Math.max(0, articulo.diasHistorial),
    diasFaltantes,
    consumoDiarioEstimado: consumo,
    diasCoberturaEstimados: diasCobertura,
    compraSugeridaPreliminar,
    urgenciaPreliminar,
    leyendaPeriodo,
  };
}

/**
 * Evalúa la madurez estadística global de una lista de artículos para alimentar
 * banners informativos en Dashboard y en Panel Predictivo.
 */
export function evaluarMadurezDatos(
  lista: readonly ArticuloPredictivo[],
  umbralDias: number = UMBRAL_DIAS_HISTORIAL,
): ResumenMadurezDatos {
  if (lista.length === 0) {
    return {
      diasRegistradosMax: 0,
      diasRegistradosMin: 0,
      diasFaltantes: umbralDias,
      porcentajeCompletado: 0,
      articulosEnFasePreliminar: 0,
      totalArticulos: 0,
      requiereAvisoMadurez: false,
      tipoAvisoMadurez: 'consolidado',
      mensajeAdvertencia: '',
    };
  }

  const diasArray = lista.map((i) => Math.max(0, i.diasHistorial));
  const preliminares = lista.filter((i) => !tieneHistorialSuficiente(i.diasHistorial, umbralDias));
  const cantidadPreliminares = preliminares.length;

  if (cantidadPreliminares === 0) {
    const diasMax = Math.max(...diasArray);
    const diasMin = Math.min(...diasArray);
    return {
      diasRegistradosMax: diasMax,
      diasRegistradosMin: diasMin,
      diasFaltantes: 0,
      porcentajeCompletado: 100,
      articulosEnFasePreliminar: 0,
      totalArticulos: lista.length,
      requiereAvisoMadurez: false,
      tipoAvisoMadurez: 'consolidado',
      mensajeAdvertencia: 'Historial maduro consolidado (supera las 4 semanas de registros continuos).',
    };
  }

  const diasPreliminares = preliminares.map((p) => p.diasHistorial);
  const diasPreliminarMax = Math.max(...diasPreliminares);
  const diasPreliminarMin = Math.min(...diasPreliminares);
  const todaSucursalEsPreliminar = cantidadPreliminares === lista.length;

  if (todaSucursalEsPreliminar) {
    const diasFaltantes = Math.max(0, umbralDias - diasPreliminarMax);
    const porcentaje = Math.min(100, Math.round((diasPreliminarMax / umbralDias) * 100));
    return {
      diasRegistradosMax: diasPreliminarMax,
      diasRegistradosMin: diasPreliminarMin,
      diasFaltantes,
      porcentajeCompletado: porcentaje,
      articulosEnFasePreliminar: cantidadPreliminares,
      totalArticulos: lista.length,
      requiereAvisoMadurez: true,
      tipoAvisoMadurez: 'sucursal-temprana',
      mensajeAdvertencia: `Información preliminar: los datos de uso y horarios reflejan los registros de los últimos ${diasPreliminarMax} días. Aún no hay registros suficientes para sacar conclusiones definitivas (faltan ${diasFaltantes} días para cumplir las 4 semanas de 28 días).`,
    };
  }

  // Catálogo mixto: la sucursal es madura, pero se incorporaron artículos nuevos
  const nombreEjemplo = preliminares[0].articulo;
  const diasEjemplo = preliminares[0].diasHistorial;
  const faltantesEjemplo = Math.max(0, umbralDias - diasEjemplo);

  return {
    diasRegistradosMax: diasPreliminarMax,
    diasRegistradosMin: diasPreliminarMin,
    diasFaltantes: faltantesEjemplo,
    porcentajeCompletado: Math.min(100, Math.round((diasPreliminarMax / umbralDias) * 100)),
    articulosEnFasePreliminar: cantidadPreliminares,
    totalArticulos: lista.length,
    requiereAvisoMadurez: true,
    tipoAvisoMadurez: 'articulos-nuevos',
    mensajeAdvertencia: `Información preliminar: hay ${cantidadPreliminares} artículo(s) con menos de 28 días de registro (ej. ${nombreEjemplo} con ${diasEjemplo} días; faltan ${faltantesEjemplo} días para las 4 semanas de 28 días). Su proyección se calcula con su consumo registrado mientras el resto del catálogo opera con historial maduro.`,
  };
}

/**
 * Días estimados hasta que el stock actual baje del stock mínimo configurado.
 */
const formatoCantidadStock = new Intl.NumberFormat('es-CL', { maximumFractionDigits: 1 });

export function formatearCantidadStock(valor: number): string {
  return formatoCantidadStock.format(valor);
}

/** Más de un año de cobertura no aporta precisión para decidir una compra. */
export function textoDiasOperacion(dias: number): string {
  if (dias > 365) return 'más de 1 año de operación';
  if (dias < 1) return 'menos de 1 día de operación';
  const enteros = Math.floor(dias);
  return `${enteros} ${enteros === 1 ? 'día' : 'días'} de operación`;
}

/** Hacia abajo, para no prometer un día que no alcanza. Los umbrales siguen usando el valor exacto. */
export function diasEnteros(dias: number | null): number | null {
  return dias === null ? null : Math.floor(dias);
}

export function diasHastaMinimo(
  stockActual: number,
  stockMinimo: number,
  consumoDiarioBase: number,
): number | null {
  if (!Number.isFinite(consumoDiarioBase) || consumoDiarioBase <= 0) {
    return null;
  }
  const margenDisponible = stockActual - stockMinimo;
  if (margenDisponible <= 0) {
    return 0;
  }
  return Math.round((margenDisponible / consumoDiarioBase) * 10) / 10;
}

/**
 * Clasifica el estado del artículo de forma directa:
 * - Menos de 28 días de historial -> 'datos-insuficientes'
 * - Alcanza para 1,5 días o menos sobre el mínimo -> 'comprar-hoy'
 * - Alcanza para 4 días o menos sobre el mínimo -> 'proximo-pedido'
 * - Más de 4 días sobre el mínimo -> 'estable'
 */
export function evaluarEstadoPredictivo(articulo: ArticuloPredictivo): EstadoPrediccion {
  if (!tieneHistorialSuficiente(articulo.diasHistorial)) {
    return 'datos-insuficientes';
  }
  // Bajo el mínimo hay que comprar aunque no haya consumo calculado. Incluye el stock negativo,
  // que está permitido: la venta se realiza aunque el stock registrado no alcance.
  if (articulo.stockActual < articulo.stockMinimo) {
    return 'comprar-hoy';
  }
  const cobertura = diasHastaMinimo(
    articulo.stockActual,
    articulo.stockMinimo,
    articulo.consumoDiarioBase,
  );
  if (cobertura === null) {
    return 'estable';
  }
  if (articulo.stockActual <= articulo.stockMinimo || cobertura <= 1.5) {
    return 'comprar-hoy';
  }
  if (cobertura <= 4) {
    return 'proximo-pedido';
  }
  return 'estable';
}

/**
 * Cantidad sugerida de compra diaria (1 día por defecto sobre el stock mínimo).
 * En cafeterías universitarias los espacios son reducidos y las compras se realizan de forma diaria.
 */
export function cantidadSugeridaCompra(
  articulo: ArticuloPredictivo,
  diasObjetivo = 1,
): number {
  if (!tieneHistorialSuficiente(articulo.diasHistorial)) {
    return 0;
  }
  const stockMeta = articulo.stockMinimo + Math.max(0, articulo.consumoDiarioBase) * diasObjetivo;
  const faltante = stockMeta - articulo.stockActual;
  if (faltante <= 0) {
    return 0;
  }
  return articulo.tipo === 'producto'
    ? Math.ceil(faltante)
    : Math.round(faltante * 10) / 10;
}

export function contarPredicciones(lista: readonly ArticuloPredictivo[]): ResumenPredicciones {
  const conteo: ResumenPredicciones = {
    'comprar-hoy': 0,
    'proximo-pedido': 0,
    estable: 0,
    'datos-insuficientes': 0,
    total: lista.length,
  };
  for (const item of lista) {
    conteo[evaluarEstadoPredictivo(item)]++;
  }
  return conteo;
}

export function filtrarPredicciones(
  lista: readonly ArticuloPredictivo[],
  sucursalId: number | null,
  urgencia: FiltroUrgenciaPrediccion,
  busqueda: string,
  tipo: FiltroTipoPrediccion = 'todos',
): ArticuloPredictivo[] {
  const termino = busqueda.trim().toLowerCase();
  return lista.filter((item) => {
    if (sucursalId !== null && item.sucursalId !== sucursalId) {
      return false;
    }
    if (tipo !== 'todos' && item.tipo !== tipo) {
      return false;
    }
    if (urgencia !== 'todos' && evaluarEstadoPredictivo(item) !== urgencia) {
      return false;
    }
    if (
      termino &&
      !item.articulo.toLowerCase().includes(termino) &&
      !item.sucursal.toLowerCase().includes(termino)
    ) {
      return false;
    }
    return true;
  });
}

export const ARTICULOS_PREDICTIVOS_DEMO: readonly ArticuloPredictivo[] = [
  {
    id: 'pred-harina-prov',
    articulo: 'Harina Panadera 000',
    tipo: 'materia_prima',
    sucursalId: 1,
    sucursal: 'Nury Providencia (Equipo de desarrollo)',
    stockActual: 32,
    stockMinimo: 25,
    unidad: 'kg',
    diasHistorial: 64,
    consumoDiarioBase: 9.5,
  },
  {
    id: 'pred-leche-prov',
    articulo: 'Leche Entera Fresca',
    tipo: 'materia_prima',
    sucursalId: 1,
    sucursal: 'Nury Providencia (Equipo de desarrollo)',
    stockActual: 28,
    stockMinimo: 20,
    unidad: 'l',
    diasHistorial: 58,
    consumoDiarioBase: 11,
  },
  {
    id: 'pred-cafe-prov',
    articulo: 'Café en Grano Selección',
    tipo: 'materia_prima',
    sucursalId: 1,
    sucursal: 'Nury Providencia (Equipo de desarrollo)',
    stockActual: 7.5,
    stockMinimo: 4,
    unidad: 'kg',
    diasHistorial: 90,
    consumoDiarioBase: 1.2,
  },
  {
    id: 'pred-mantequilla-condes',
    articulo: 'Mantequilla sin Sal Bloques',
    tipo: 'materia_prima',
    sucursalId: 2,
    sucursal: 'Nury Las Condes',
    stockActual: 12.5,
    stockMinimo: 6,
    unidad: 'kg',
    diasHistorial: 45,
    consumoDiarioBase: 2.2,
  },
  {
    id: 'pred-matcha-prov',
    articulo: 'Té Matcha Japonés (Nuevo)',
    tipo: 'materia_prima',
    sucursalId: 1,
    sucursal: 'Nury Providencia (Equipo de desarrollo)',
    stockActual: 1.4,
    stockMinimo: 0.8,
    unidad: 'kg',
    diasHistorial: 12,
    consumoDiarioBase: 0.15,
  },
  {
    id: 'pred-croissant-vegano',
    articulo: 'Croissant Vegano (Nuevo)',
    tipo: 'producto',
    sucursalId: 2,
    sucursal: 'Nury Las Condes',
    stockActual: 16,
    stockMinimo: 8,
    unidad: 'un',
    diasHistorial: 19,
    consumoDiarioBase: 4,
  },
  {
    id: 'pred-azucar-prov',
    articulo: 'Azúcar Flor',
    tipo: 'materia_prima',
    sucursalId: 1,
    sucursal: 'Nury Providencia (Equipo de desarrollo)',
    stockActual: 46,
    stockMinimo: 15,
    unidad: 'kg',
    diasHistorial: 82,
    consumoDiarioBase: 2.4,
  },
  {
    id: 'pred-choco-nunoa',
    articulo: 'Chocolate Cobertura 70%',
    tipo: 'materia_prima',
    sucursalId: 3,
    sucursal: 'Nury Ñuñoa',
    stockActual: 24,
    stockMinimo: 8,
    unidad: 'kg',
    diasHistorial: 70,
    consumoDiarioBase: 1.5,
  },
];
