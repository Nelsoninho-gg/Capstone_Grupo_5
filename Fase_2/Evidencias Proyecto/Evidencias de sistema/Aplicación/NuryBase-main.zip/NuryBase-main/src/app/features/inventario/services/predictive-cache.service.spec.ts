import { TestBed } from '@angular/core/testing';
import { IA_RELOJ } from '../../../core/ia/proveedores-ia.config';
import { SalidaPrediccionIA } from '../models/prediccion-ia.contract';
import { PredictiveCacheService, TTL_CACHE_PREDICCION_DEFAULT_MS } from './predictive-cache.service';

describe('PredictiveCacheService (H4.5 T07)', () => {
  let servicio: PredictiveCacheService;
  let tiempoVirtual: number;

  const mockPrediccion: SalidaPrediccionIA = {
    predicciones: [
      {
        articuloId: 'art-harina',
        estado: 'comprar-hoy',
        tasaDiariaEstimada: 5,
        diasHastaMinimo: 1,
        fechaRecomendadaPedido: '2026-11-05',
        cantidadSugerida: 3,
        justificacion: 'Consumo proyecta quiebre.',
      },
    ],
  };

  beforeEach(() => {
    tiempoVirtual = 1_700_000_000_000;
    TestBed.configureTestingModule({
      providers: [
        PredictiveCacheService,
        { provide: IA_RELOJ, useValue: () => tiempoVirtual },
      ],
    });
    servicio = TestBed.inject(PredictiveCacheService);
  });

  it('guarda y recupera un elemento antes de vencer su TTL', () => {
    const clave = servicio.construirClave(1, '2026-11-05', ['art-harina']);
    servicio.guardar(clave, 1, mockPrediccion);

    expect(servicio.tamano()).toBe(1);
    const obtenido = servicio.obtener(clave);
    expect(obtenido).not.toBeNull();
    expect(obtenido?.predicciones[0].articuloId).toBe('art-harina');
  });

  it('retorna null y purga la entrada una vez expirado el TTL', () => {
    const clave = servicio.construirClave(1, '2026-11-05', ['art-harina']);
    servicio.guardar(clave, 1, mockPrediccion, 10_000); // 10s TTL

    // Avanzar tiempo más allá del TTL
    tiempoVirtual += 11_000;
    expect(servicio.obtener(clave)).toBeNull();
    expect(servicio.tamano()).toBe(0);
  });

  it('invalida selectivamente las entradas de una sucursal sin afectar a las demás', () => {
    const claveSuc1 = servicio.construirClave(1, '2026-11-05', ['art-harina']);
    const claveSuc2 = servicio.construirClave(2, '2026-11-05', ['art-leche']);

    servicio.guardar(claveSuc1, 1, mockPrediccion);
    servicio.guardar(claveSuc2, 2, mockPrediccion);
    expect(servicio.tamano()).toBe(2);

    servicio.invalidarSucursal(1);
    expect(servicio.obtener(claveSuc1)).toBeNull();
    expect(servicio.obtener(claveSuc2)).not.toBeNull();
    expect(servicio.tamano()).toBe(1);
  });

  it('garantiza inmutabilidad devolviendo copias para evitar mutaciones externas', () => {
    const clave = servicio.construirClave(1, '2026-11-05', ['art-harina']);
    servicio.guardar(clave, 1, mockPrediccion);

    const obtenido1 = servicio.obtener(clave)!;
    obtenido1.predicciones[0].cantidadSugerida = 999;

    const obtenido2 = servicio.obtener(clave)!;
    expect(obtenido2.predicciones[0].cantidadSugerida).toBe(3);
  });

  it('limpia todas las entradas al invocar limpiar()', () => {
    servicio.guardar('k1', 1, mockPrediccion);
    servicio.guardar('k2', 2, mockPrediccion);
    expect(servicio.tamano()).toBe(2);

    servicio.limpiar();
    expect(servicio.tamano()).toBe(0);
  });
});
