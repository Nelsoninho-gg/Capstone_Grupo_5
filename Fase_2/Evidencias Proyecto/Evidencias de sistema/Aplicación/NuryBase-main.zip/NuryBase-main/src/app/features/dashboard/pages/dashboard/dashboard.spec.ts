import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { Subject, of, throwError } from 'rxjs';
import { vi } from 'vitest';
import { SucursalesApiService } from '../../../../core/api/sucursales-api.service';
import { VentaDashboardApi } from '../../../../core/api/ventas-api.service';
import { OrquestadorIaService } from '../../../../core/ia/orquestador-ia.service';
import { PrediccionStockService } from '../../../inventario/services/prediccion-stock.service';
import { PeriodoDashboard, TIEMPO_LIMITE_CONSULTA_MS, construirEscenario } from '../../models/dashboard.model';
import { AsistenteDashboardService, MensajeChatbot } from '../../services/asistente-dashboard.service';
import { ConsultasAsistenteService } from '../../services/consultas-asistente.service';
import { DashboardDatosService, DatosDashboard } from '../../services/dashboard-datos.service';
import { CLAVE_METRICA_DIAS_SEMANA, Dashboard } from './dashboard';

const AHORA = new Date();

function venta(total: number, fecha: Date = AHORA): VentaDashboardApi {
  return {
    id: total,
    fecha_venta: fecha.toISOString().slice(0, 19),
    total,
    detalle_venta: [
      {
        producto_id: 1,
        cantidad: 1,
        subtotal: total,
        productos: { nombre: 'Café', categoria: 'BEBESTIBLES - CAFÉ', precio_compra: 100 },
      },
      {
        producto_id: 2,
        cantidad: 1,
        subtotal: 0,
        productos: { nombre: 'Medialuna', categoria: 'ALIMENTOS - PASTEL', precio_compra: 100 },
      },
    ],
  };
}

function datosDe(periodo: PeriodoDashboard, sucursalId: number | null): DatosDashboard {
  const ventas = periodo === '30d' ? [venta(3000), venta(2000)] : [venta(1000)];
  return {
    escenario: construirEscenario(ventas, new Map(), periodo, AHORA),
    diasHistorial: sucursalId === 1 ? 60 : 14,
    catalogo: [{ nombre: 'Frappé', tipo: 'producto', categoria: 'Bebidas', activo: false }],
    insumosUrgentes: [],
  };
}

describe('Dashboard Ejecutivo (H4.5)', () => {
  let fixture: ComponentFixture<Dashboard>;
  let cargar: ReturnType<typeof vi.fn>;

  async function crear(): Promise<void> {
    await TestBed.configureTestingModule({
      imports: [Dashboard],
      providers: [
        provideRouter([]),
        { provide: DashboardDatosService, useValue: { cargar } },
        {
          provide: SucursalesApiService,
          useValue: { listarActivas: () => of([{ id: 1, nombre: 'Nury Real' }]) },
        },
        {
          provide: PrediccionStockService,
          useValue: {
            cargarArticulos: () => of([]),
            generarSugerencias: () => of({ origen: 'datos-insuficientes-local', predicciones: [] }),
          },
        },
        {
          provide: ConsultasAsistenteService,
          useValue: {
            esquema: () => of(new Map()),
            describirEsquema: () => '',
            ejecutar: () => of({}),
            nombresReales: () => of({ personas: [], proveedores: [] }),
            primeraVenta: () => of(null),
          },
        },
        {
          provide: OrquestadorIaService,
          useValue: { solicitar: () => throwError(() => new Error('Sin IA en pruebas')) },
        },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(Dashboard);
    fixture.detectChanges();
    await fixture.whenStable();
    fixture.detectChanges();
  }

  function abrirPestana(indice: number): void {
    (fixture.nativeElement as HTMLElement)
      .querySelectorAll<HTMLButtonElement>('.view-tabs button')
      [indice].click();
    fixture.detectChanges();
  }

  beforeEach(async () => {
    localStorage.removeItem(CLAVE_METRICA_DIAS_SEMANA);
    cargar = vi.fn((periodo: PeriodoDashboard, sucursalId: number | null) =>
      of(datosDe(periodo, sucursalId)),
    );
    await crear();
  });

  it('renderiza los KPIs, el asistente, la proyección, los productos comprados juntos y el resumen de compras', () => {
    const el = fixture.nativeElement as HTMLElement;
    expect(el.querySelector('h1')?.textContent).toContain('Dashboard Ejecutivo');
    expect(el.querySelectorAll('.kpi-card')).toHaveLength(2);
    expect(el.querySelector('.floating-assistant-launcher')).not.toBeNull();
    expect(el.querySelector('.proj-acumulado')?.textContent).toContain('$');
    expect(el.querySelector('.proj-tramo')).not.toBeNull();
    abrirPestana(1);
    expect(el.querySelectorAll('.mining-rule-card').length).toBeGreaterThan(0);
    abrirPestana(2);
    expect(el.querySelector('app-panel-predictivo')).not.toBeNull();
  });

  it('muestra las ventas reales y las sucursales que entrega la API', () => {
    const el = fixture.nativeElement as HTMLElement;
    expect(el.querySelector('.kpi-amount')?.textContent).toContain('5.000');
    const opciones = Array.from(el.querySelectorAll('select[aria-label="Filtrar dashboard por sucursal"] option'));
    expect(opciones.map((o) => o.textContent?.trim())).toEqual(['Todas las sucursales', 'Nury Real']);
  });

  it('abre y cierra el asistente deslizable tipo chat (estilo comanda off-canvas) y bloquea el scroll de fondo', () => {
    const el = fixture.nativeElement as HTMLElement;
    expect(el.querySelector('.assistant-drawer')).toBeNull();
    expect(el.querySelector('.assistant-backdrop')).toBeNull();
    expect(document.body.classList.contains('assistant-drawer-open')).toBe(false);

    // Abrir desde botón de cabecera
    const botonAbrir = el.querySelector<HTMLButtonElement>('.floating-assistant-launcher')!;
    botonAbrir.click();
    fixture.detectChanges();

    const drawer = el.querySelector('.assistant-drawer');
    expect(drawer).not.toBeNull();
    expect(drawer?.classList.contains('open')).toBe(true);
    expect(el.querySelector('.assistant-backdrop')).not.toBeNull();
    expect(document.body.classList.contains('assistant-drawer-open')).toBe(true);

    // Cerrar desde botón ✕
    const botonCerrar = el.querySelector<HTMLButtonElement>('.btn-close-assistant')!;
    botonCerrar.click();
    fixture.detectChanges();

    expect(el.querySelector('.assistant-drawer')).toBeNull();
    expect(el.querySelector('.assistant-backdrop')).toBeNull();
    expect(document.body.classList.contains('assistant-drawer-open')).toBe(false);

    // Abrir de nuevo y cerrar con Escape
    botonAbrir.click();
    fixture.detectChanges();
    expect(el.querySelector('.assistant-drawer')).not.toBeNull();
    expect(document.body.classList.contains('assistant-drawer-open')).toBe(true);

    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape' }));
    fixture.detectChanges();
    expect(el.querySelector('.assistant-drawer')).toBeNull();
    expect(document.body.classList.contains('assistant-drawer-open')).toBe(false);
  });

  it('envía al asistente la pregunta frecuente elegida, sin respuestas fijas de ejemplo', () => {
    const el = fixture.nativeElement as HTMLElement;
    el.querySelector<HTMLButtonElement>('.floating-assistant-launcher')!.click();
    fixture.detectChanges();

    const chips = el.querySelectorAll<HTMLButtonElement>('.question-chip');
    expect(chips).toHaveLength(5);
    expect(el.querySelector('.chat-user-bubble')).toBeNull();

    chips[1].click();
    fixture.detectChanges();
    expect(el.querySelector('.chat-user-bubble')?.textContent).toContain(
      '¿Qué es lo que más se vende?',
    );
  });

  it('mientras carga otro período muestra el esqueleto en vez de las cifras anteriores', async () => {
    const pendiente = new Subject<DatosDashboard>();
    cargar.mockReturnValueOnce(pendiente);
    const el = fixture.nativeElement as HTMLElement;
    el.querySelectorAll<HTMLButtonElement>('.period-Quick-tabs button')[3].click();
    fixture.detectChanges();

    expect(el.querySelectorAll('.esqueleto-grid')).toHaveLength(2);
    expect(el.querySelector('.kpi-amount')).toBeNull();
    expect(el.querySelector('.esqueleto-grid')!.getAttribute('aria-hidden')).toBe('true');
    expect(el.querySelector('.data-loading')?.textContent).toContain('Cargando datos del negocio');
    // Mientras carga no debe decir «Actualizado justo ahora».
    expect(el.querySelector('.refresh-text')?.textContent?.trim()).toBe('Cargando…');

    pendiente.next(datosDe('90d', null));
    pendiente.complete();
    await fixture.whenStable();
    fixture.detectChanges();

    expect(el.querySelector('.esqueleto-grid')).toBeNull();
    expect(el.querySelector('.kpi-amount')).not.toBeNull();
  });

  it('muestra desde cuándo están los datos y se puede actualizar a mano', async () => {
    const el = fixture.nativeElement as HTMLElement;
    expect(el.querySelector('.refresh-text')?.textContent?.trim()).toBe('Actualizado justo ahora');

    el.querySelector<HTMLButtonElement>('.refresh-button')!.click();
    await fixture.whenStable();
    fixture.detectChanges();

    expect(cargar).toHaveBeenCalledTimes(2);
    expect(cargar).toHaveBeenLastCalledWith('30d', null);
    // Un refresco manual no debe tapar la pantalla con el estado de carga.
    expect(el.querySelector('.data-loading')).toBeNull();
    expect(el.querySelector('.refresh-text')?.textContent?.trim()).toBe('Actualizado justo ahora');
  });

  it('solo se refresca solo en el período Hoy', async () => {
    const el = fixture.nativeElement as HTMLElement;
    const instancia = fixture.componentInstance as unknown as { refrescarSiCorresponde(): void };

    // Período por defecto (Este mes): no se refresca solo, son consultas pesadas.
    instancia.refrescarSiCorresponde();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(cargar).toHaveBeenCalledTimes(1);

    el.querySelectorAll<HTMLButtonElement>('.period-Quick-tabs button')[0].click();
    await fixture.whenStable();
    fixture.detectChanges();
    const trasCambiarAHoy = cargar.mock.calls.length;

    instancia.refrescarSiCorresponde();
    await fixture.whenStable();
    fixture.detectChanges();
    expect(cargar).toHaveBeenCalledTimes(trasCambiarAHoy + 1);
    expect(cargar).toHaveBeenLastCalledWith('1d', null);
  });

  it('vuelve a consultar los datos al cambiar el período', async () => {
    const el = fixture.nativeElement as HTMLElement;
    const montoInicial = el.querySelector('.kpi-amount')?.textContent;
    el.querySelectorAll<HTMLButtonElement>('.period-Quick-tabs button')[1].click(); // Esta semana
    await fixture.whenStable();
    fixture.detectChanges();

    expect(cargar).toHaveBeenLastCalledWith('7d', null);
    expect(el.querySelector('.kpi-amount')?.textContent).not.toBe(montoInicial);
  });

  it('carga el período "Hoy" desde el primer botón de períodos', async () => {
    const el = fixture.nativeElement as HTMLElement;
    const botones = el.querySelectorAll<HTMLButtonElement>('.period-Quick-tabs button');
    expect(Array.from(botones).map((b) => b.textContent?.trim())).toEqual([
      'Hoy',
      'Esta semana',
      'Este mes',
      'Trimestre',
    ]);

    botones[0].click();
    await fixture.whenStable();
    fixture.detectChanges();

    expect(cargar).toHaveBeenLastCalledWith('1d', null);
    expect(botones[0].getAttribute('aria-pressed')).toBe('true');
    expect(botones[1].getAttribute('aria-pressed')).toBe('false');
  });

  it('con historial insuficiente muestra el mensaje y no una cifra de cierre inventada', async () => {
    const el = fixture.nativeElement as HTMLElement;
    el.querySelectorAll<HTMLButtonElement>('.period-Quick-tabs button')[0].click();
    await fixture.whenStable();
    fixture.detectChanges();

    const aviso = el.querySelector('.proj-nota-pendiente');
    expect(aviso?.textContent).toContain('Falta historial para proyectar el cierre');
    expect(aviso?.textContent).toContain(
      'Aún no hay días suficientes para proyectar el cierre de hoy',
    );

    expect(el.querySelector('.proj-estimado')?.textContent?.trim()).toBe('—');
    expect(el.querySelector('.proj-cierre')?.textContent).not.toContain('$');
    expect(el.querySelector('.proj-barra')).toBeNull();
    expect(el.querySelector('.proj-tramo.estimado')).toBeNull();
  });

  it('con proyección disponible muestra la cifra de cierre estimado', async () => {
    TestBed.resetTestingModule();
    const diasPrevios = [7, 14, 21].map(
      (dias) => new Date(AHORA.getFullYear(), AHORA.getMonth(), AHORA.getDate() - dias),
    );
    const ventasConHistorial = [
      ...diasPrevios.flatMap((dia) => [
        venta(1000, new Date(dia.getFullYear(), dia.getMonth(), dia.getDate(), 0, 0)),
        venta(3000, new Date(dia.getFullYear(), dia.getMonth(), dia.getDate(), 23, 59)),
      ]),
      venta(2000),
    ];
    cargar = vi.fn((periodo: PeriodoDashboard, sucursalId: number | null) =>
      of(
        periodo === '1d'
          ? {
              ...datosDe('1d', sucursalId),
              escenario: construirEscenario(ventasConHistorial, new Map(), '1d', AHORA),
            }
          : datosDe(periodo, sucursalId),
      ),
    );
    await crear();

    const el = fixture.nativeElement as HTMLElement;
    el.querySelectorAll<HTMLButtonElement>('.period-Quick-tabs button')[0].click();
    await fixture.whenStable();
    fixture.detectChanges();

    expect(el.querySelector('.proj-nota-pendiente')).toBeNull();
    expect(el.querySelector('.proj-barra')).not.toBeNull();
    const estimado = el.querySelector('.proj-estimado');
    expect(estimado?.textContent).toContain('$');
    expect(estimado?.textContent).not.toContain('—');
  });

  it('muestra el banner de madurez temprana (< 28 días) en la cabecera del Dashboard', () => {
    const el = fixture.nativeElement as HTMLElement;
    const banner = el.querySelector('.maturity-notice-banner');
    expect(banner).not.toBeNull();
    expect(banner?.textContent).toContain('Modo de estimación temprana activo (< 28 días)');
    expect(banner?.textContent).toContain('28 días');
  });

  it('adapta el banner de madurez al cambiar de sucursal en el selector', async () => {
    const el = fixture.nativeElement as HTMLElement;
    const selectSucursal = el.querySelector<HTMLSelectElement>('select[aria-label="Filtrar dashboard por sucursal"]');
    expect(selectSucursal).not.toBeNull();

    // Sucursal con 60 días de historial
    selectSucursal!.value = '1';
    selectSucursal!.dispatchEvent(new Event('change'));
    await fixture.whenStable();
    fixture.detectChanges();

    expect(cargar).toHaveBeenLastCalledWith('30d', 1);
    expect(el.querySelector('.maturity-notice-banner')).toBeNull();
  });

  it('permite enviar preguntas libres desde la barra de entrada del asistente y recibe respuesta', () => {
    const el = fixture.nativeElement as HTMLElement;
    const botonAbrir = el.querySelector<HTMLButtonElement>('.floating-assistant-launcher')!;
    botonAbrir.click();
    fixture.detectChanges();

    const input = el.querySelector<HTMLInputElement>('.assistant-input-control');
    const sendBtn = el.querySelector<HTMLButtonElement>('.btn-send-assistant');
    expect(input).not.toBeNull();
    expect(sendBtn).not.toBeNull();
    expect(sendBtn?.disabled).toBe(true);

    input!.value = '¿Qué productos están inactivos?';
    input!.dispatchEvent(new Event('input'));
    fixture.detectChanges();
    expect(sendBtn?.disabled).toBe(false);

    sendBtn!.click();
    fixture.detectChanges();

    const bubbles = el.querySelectorAll('.chat-user-bubble');
    expect(Array.from(bubbles).some((b) => b.textContent?.includes('¿Qué productos están inactivos?'))).toBe(true);
    expect(el.textContent).toContain('Artículos pausados o descontinuados');
    expect(el.textContent).toContain('Respuesta automática sin IA');
  });

  it('conserva la conversación al salir del dashboard y volver', () => {
    const el = fixture.nativeElement as HTMLElement;
    el.querySelector<HTMLButtonElement>('.floating-assistant-launcher')!.click();
    fixture.detectChanges();
    el.querySelectorAll<HTMLButtonElement>('.question-chip')[0].click();
    fixture.detectChanges();

    fixture.destroy();
    fixture = TestBed.createComponent(Dashboard);
    fixture.detectChanges();

    const nuevo = fixture.nativeElement as HTMLElement;
    nuevo.querySelector<HTMLButtonElement>('.floating-assistant-launcher')!.click();
    fixture.detectChanges();
    expect(nuevo.querySelector('.chat-user-bubble')?.textContent).toContain('¿Qué necesito comprar con urgencia?');
  });

  it.each([
    [
      {
        origen: 'ia',
        datosCalculados: [
          { titulo: 'Ventas (01-10-2026 a 31-10-2026)', lineas: ['y'] },
          { titulo: 'Facturas ingresadas', lineas: ['y'] },
          { titulo: 'Facturas ingresadas', lineas: ['z'] },
        ],
      },
      /^Generada por IA con: Ventas \(01-10-2026 a 31-10-2026\), Facturas ingresadas$/,
    ],
    [{ origen: 'ia', datosCalculados: [] }, /^Generada por IA, sin consultar datos de tu negocio$/],
    [{ origen: 'sin-verificar' }, /no se pudo comprobar/],
    [{ origen: 'respaldo-local' }, /no se pudo conectar/],
  ] as const)('el pie del mensaje indica de dónde sale la respuesta: %o', (mensaje, esperado) => {
    TestBed.inject(AsistenteDashboardService).mensajes.set([
      { id: 'a', autor: 'asistente', texto: 'Hola', hora: '10:00', tipoRespuesta: 'texto', ...mensaje } as MensajeChatbot,
    ]);
    (fixture.nativeElement as HTMLElement).querySelector<HTMLButtonElement>('.floating-assistant-launcher')!.click();
    fixture.detectChanges();

    const pie = (fixture.nativeElement as HTMLElement).querySelector('.answer-origin');
    expect(pie?.textContent?.replace(/\s+/g, ' ').trim()).toMatch(esperado);
  });

  it.each([
    ['ia', 'origen-ia'],
    ['algoritmo', 'origen-sistema'],
    ['respaldo-local', 'origen-sistema'],
    ['sin-verificar', 'origen-sin-verificar'],
  ] as const)('la insignia marca el origen %s con %s', (origen, clase) => {
    TestBed.inject(AsistenteDashboardService).mensajes.set([
      { id: 'a', autor: 'asistente', texto: 'Hola', hora: '10:00', tipoRespuesta: 'texto', origen } as MensajeChatbot,
    ]);
    const el = fixture.nativeElement as HTMLElement;
    el.querySelector<HTMLButtonElement>('.floating-assistant-launcher')!.click();
    fixture.detectChanges();

    const marcas = el.querySelectorAll('.bot-msg .bot-badge .badge-origen');
    expect(marcas).toHaveLength(1);
    expect(marcas[0].classList).toContain(clase);
  });

  it('usa íconos Lucide y no emojis en avisos y en el chat', () => {
    const el = fixture.nativeElement as HTMLElement;
    el.querySelector<HTMLButtonElement>('.floating-assistant-launcher')!.click();
    fixture.detectChanges();

    expect(el.querySelector('.btn-send-assistant app-icon svg')).not.toBeNull();
    expect(el.querySelector('.assistant-disclaimer app-icon svg')).not.toBeNull();
    expect(el.textContent).not.toMatch(/[\u{1F300}-\u{1FAFF}\u2139\u23F1\u26A0\u27A4]/u);
  });

  it('Nueva conversación limpia el chat y solo se habilita si hay mensajes', () => {
    const el = fixture.nativeElement as HTMLElement;
    el.querySelector<HTMLButtonElement>('.floating-assistant-launcher')!.click();
    fixture.detectChanges();
    const boton = () => el.querySelector<HTMLButtonElement>('.btn-new-conversation')!;
    expect(boton().disabled).toBe(true);

    el.querySelectorAll<HTMLButtonElement>('.question-chip')[0].click();
    fixture.detectChanges();
    expect(boton().disabled).toBe(false);

    boton().click();
    fixture.detectChanges();
    expect(el.querySelector('.chat-user-bubble')).toBeNull();
    expect(TestBed.inject(AsistenteDashboardService).mensajes()).toEqual([]);
  });

  it('muestra el movimiento por horario en columnas y marca el horario punta', () => {
    const el = fixture.nativeElement as HTMLElement;
    const lista = el.querySelector('[aria-label="Ventas promedio por día en cada horario"]')!;
    expect(lista.querySelectorAll('.columna')).toHaveLength(6);
    const punta = lista.querySelector('.columna.peak')!;
    expect(punta.getAttribute('aria-label')).toMatch(/: 2 ventas por día, horario punta$/);
    expect(punta.querySelector<HTMLElement>('.columna-barra')!.style.height).toBe('100%');
  });

  it('muestra las ventas por día de la semana con el monto y destaca el día con más venta', () => {
    const el = fixture.nativeElement as HTMLElement;
    const lista = el.querySelector('[aria-label="Total vendido en cada día de la semana"]')!;
    expect(lista.querySelectorAll('.columna')).toHaveLength(7);
    const mayor = lista.querySelectorAll('.columna.peak');
    expect(mayor).toHaveLength(1);
    expect(mayor[0].getAttribute('aria-label')).toMatch(/2 ventas en el período, el día con más venta$/);
    expect(mayor[0].querySelector('.columna-valor')?.textContent).toContain('$');
    // Dice cuántas veces cayó el día en el período, porque la suma depende de eso.
    expect(mayor[0].getAttribute('aria-label')).toMatch(/: \$[\d.]+ en \d+ \p{L}+, /u);
    expect(mayor[0].querySelector('.columna-veces')?.textContent).toMatch(/^\d+ \p{L}+$/u);
    expect(lista.parentElement!.textContent).toContain('Bajo cada día, cuántas veces cayó en el período.');
    expect(lista.parentElement!.textContent).toContain('Total vendido de cada día de la semana, sumando todo el período, con IVA incluido.');
  });

  it('cambia la tarjeta por día de la semana a ganancia limpia', () => {
    const el = fixture.nativeElement as HTMLElement;
    const grupo = el.querySelector('[aria-label="Ver por total vendido o ganancia limpia"]')!;
    const [total, ganancia] = Array.from(grupo.querySelectorAll<HTMLButtonElement>('button'));
    expect(total.getAttribute('aria-pressed')).toBe('true');

    ganancia.click();
    fixture.detectChanges();

    expect(ganancia.getAttribute('aria-pressed')).toBe('true');
    expect(el.querySelector('[aria-label="Total vendido en cada día de la semana"]')).toBeNull();
    const lista = el.querySelector('[aria-label="Ganancia limpia en cada día de la semana"]')!;
    expect(lista.querySelectorAll('.columna')).toHaveLength(7);
    expect(lista.parentElement!.textContent).toContain('los productos sin costo no suman');
  });

  it('recuerda la métrica elegida en la tarjeta por día al volver a abrir el dashboard', () => {
    const el = fixture.nativeElement as HTMLElement;
    el.querySelectorAll<HTMLButtonElement>('[aria-label="Ver por total vendido o ganancia limpia"] button')[1].click();
    expect(localStorage.getItem(CLAVE_METRICA_DIAS_SEMANA)).toBe('ganancia');

    fixture.destroy();
    fixture = TestBed.createComponent(Dashboard);
    fixture.detectChanges();

    const nuevo = fixture.nativeElement as HTMLElement;
    expect(nuevo.querySelector('[aria-label="Ganancia limpia en cada día de la semana"]')).not.toBeNull();
    const [total, ganancia] = Array.from(
      nuevo.querySelectorAll<HTMLButtonElement>('[aria-label="Ver por total vendido o ganancia limpia"] button'),
    );
    expect(ganancia.getAttribute('aria-pressed')).toBe('true');
    expect(total.getAttribute('aria-pressed')).toBe('false');
  });

  it('marca como «Poco frecuente» un combo que no alcanza para recomendar una promoción', () => {
    abrirPestana(1);
    const el = fixture.nativeElement as HTMLElement;
    const combo = el.querySelector('.mining-rule-card')!;
    expect(combo.querySelector('.badge-poco-frecuente')?.textContent).toBe('Poco frecuente');
    expect(combo.textContent).toContain('Todavía es poco frecuente: se compraron juntos solo 2 veces en el período.');
    // La tarjeta explica el criterio y avisa que ninguno alcanza.
    const criterio = el.querySelector('.combos-criterio')!.textContent!;
    expect(criterio).toContain('Ningún combo alcanza todavía para recomendar una promoción.');
    expect(criterio).toContain('al menos 5 boletas y en el 1% del total');
  });

  it('en el período Hoy no muestra la tarjeta por día de la semana', async () => {
    const el = fixture.nativeElement as HTMLElement;
    el.querySelector<HTMLButtonElement>('.period-Quick-tabs button')!.click();
    await fixture.whenStable();
    fixture.detectChanges();

    expect(el.querySelector('[aria-label="Ver por total vendido o ganancia limpia"]')).toBeNull();
    expect(el.querySelector('[aria-label="Ventas promedio por día en cada horario"]')).not.toBeNull();
  });

  it('muestra la respuesta de la IA en partes, frase y lista, sin recuadro de consejo', () => {
    TestBed.inject(AsistenteDashboardService).mensajes.set([
      {
        id: 'a',
        autor: 'asistente',
        texto: 'El viernes es el día más fuerte.',
        hora: '10:00',
        origen: 'ia',
        tipoRespuesta: 'card',
        tituloCard: 'Ventas por día',
        puntosCard: ['Viernes: 90 ventas', 'Lunes: 40 ventas'],
        // Una conversación guardada antes del cambio aún puede traerlo: no se muestra.
        consejoCard: 'Refuerza el turno del viernes.',
      } as MensajeChatbot,
    ]);
    const el = fixture.nativeElement as HTMLElement;
    el.querySelector<HTMLButtonElement>('.floating-assistant-launcher')!.click();
    fixture.detectChanges();

    const respuesta = el.querySelector('.bot-card-answer')!;
    expect(respuesta.querySelector('.answer-lead')?.textContent).toBe('El viernes es el día más fuerte.');
    expect(respuesta.querySelector('.answer-title')?.textContent).toBe('Ventas por día');
    expect(Array.from(respuesta.querySelectorAll('.answer-list li')).map((li) => li.textContent)).toEqual([
      'Viernes: 90 ventas',
      'Lunes: 40 ventas',
    ]);
    expect(respuesta.textContent).not.toContain('Refuerza el turno del viernes.');
  });

  it("identifica al asistente con el logo de Nury's en vez de la palabra IA", () => {
    const el = fixture.nativeElement as HTMLElement;
    el.querySelector<HTMLButtonElement>('.floating-assistant-launcher')!.click();
    fixture.detectChanges();

    const insignias = Array.from(el.querySelectorAll('.bot-badge'));
    expect(insignias.length).toBeGreaterThan(0);
    for (const insignia of insignias) {
      expect(insignia.querySelector('img.logo-nurys')?.getAttribute('src')).toBe('logo-nurys.svg');
      expect(insignia.textContent?.trim()).toBe('');
    }
    expect(el.querySelector('.assistant-avatar img.logo-nurys')).not.toBeNull();
  });

  it('abre el ranking de un producto destacado en el panel lateral: gráfico y debajo el top', () => {
    const el = fixture.nativeElement as HTMLElement;
    abrirPestana(1);
    el.querySelector<HTMLButtonElement>('.fila-boton')!.click();
    fixture.detectChanges();

    const panel = el.querySelector('[aria-labelledby="ranking-drawer-title"]')!;
    const barras = panel.querySelectorAll('.columna').length;
    expect(barras).toBeGreaterThan(0);
    expect(barras).toBeLessThanOrEqual(5);
    expect(panel.querySelectorAll('.ranking li').length).toBe(barras);
    // El gráfico va antes que la lista.
    expect(
      panel.querySelector('.columnas')!.compareDocumentPosition(panel.querySelector('.ranking')!) &
        Node.DOCUMENT_POSITION_FOLLOWING,
    ).toBeTruthy();

    panel.querySelector<HTMLButtonElement>('.btn-close-assistant')!.click();
    fixture.detectChanges();
    expect(el.querySelector('[aria-labelledby="ranking-drawer-title"]')).toBeNull();
  });

  it('explica los productos comprados juntos sin términos técnicos', () => {
    const el = fixture.nativeElement as HTMLElement;
    abrirPestana(1);
    const detalle = el.querySelector('.mining-rule-card .fila-detalle')!;
    const parrafos = Array.from(detalle.querySelectorAll('p')).map((p) => p.textContent!.trim());
    // Solo dos frases: cuántas boletas del producto llevan el otro, y cuándo y qué hacer.
    expect(parrafos).toHaveLength(2);
    expect(parrafos[0]).toMatch(/^De las \d+ boletas que llevan .+, \d+ también llevan .+\.$/);
    // La venta de prueba usa la hora actual: la franja cambia según cuándo corra la prueba.
    expect(parrafos[1]).toMatch(/^Se compran juntos sobre todo (en|a|al) .+, desde las \d{2}:\d{2} hrs\./);
    expect(detalle.textContent).not.toMatch(/soporte|confianza|lift|esperable|Contando todas/i);
    // El porcentaje del resumen dice de qué total sale.
    expect(el.querySelector('.mining-rule-card .fila-monto')?.textContent).toBe("100% de las boletas con Café");
  });

  it('muestra una pestaña a la vez y carga las compras solo al abrirla', () => {
    const el = fixture.nativeElement as HTMLElement;
    const pestanas = el.querySelectorAll<HTMLElement>('.view-tabs button');
    expect(pestanas).toHaveLength(3);
    expect(pestanas[0].getAttribute('aria-selected')).toBe('true');
    expect(el.querySelector('#panel-ventas')).not.toBeNull();
    expect(el.querySelector('app-panel-predictivo')).toBeNull();

    abrirPestana(2);
    expect(pestanas[2].getAttribute('aria-selected')).toBe('true');
    expect(el.querySelector('#panel-ventas')).toBeNull();
    expect(el.querySelector('#panel-compras app-panel-predictivo')).not.toBeNull();
  });

  it('avisa en la pestaña Compras solo si hay artículos bajo el mínimo', async () => {
    const el = () => fixture.nativeElement as HTMLElement;
    expect(el().querySelector('.tab-aviso')).toBeNull();

    TestBed.resetTestingModule();
    cargar = vi.fn(() =>
      of({
        ...datosDe('30d', null),
        insumosUrgentes: [
          { articulo: 'Leche', sucursal: 'Nury Real', stock: 1, minimo: 5, sugerido: 4 },
        ],
      }),
    );
    await crear();
    expect(el().querySelector('#tab-compras .tab-aviso')).not.toBeNull();
  });

  it('cambia las cifras de la proyección al elegir total vendido', () => {
    const el = fixture.nativeElement as HTMLElement;
    el.querySelectorAll<HTMLButtonElement>('.metric-switch button')[1].click();
    fixture.detectChanges();
    expect(el.querySelector('.proj-acumulado')?.textContent).toContain('5.000');
  });

  it('marca en rojo solo las variaciones negativas', async () => {
    TestBed.resetTestingModule();
    const base = datosDe('30d', null);
    const [ingresos, ganancia, cierre] = base.escenario.kpis;
    cargar = vi.fn(() =>
      of({
        ...base,
        escenario: {
          ...base.escenario,
          kpis: [{ ...ingresos, variacionPct: -50 }, { ...ganancia, variacionPct: 20 }, cierre],
        },
      }),
    );
    await crear();
    const deltas = (fixture.nativeElement as HTMLElement).querySelectorAll('.kpi-delta');
    expect(deltas[0].classList.contains('negativo')).toBe(true);
    expect(deltas[1].classList.contains('negativo')).toBe(false);
  });

  it('avisa el error y deja los montos en cero si la API falla, sin datos de ejemplo', async () => {
    TestBed.resetTestingModule();
    cargar = vi.fn(() => throwError(() => new Error('Red caída')));
    await crear();

    const el = fixture.nativeElement as HTMLElement;
    expect(el.textContent).toContain('No se pudieron cargar los datos del negocio');
    expect(el.querySelector('.kpi-amount')?.textContent).toContain('0');
    expect(el.querySelector('.kpi-amount')?.textContent).not.toContain('19.450.000');
  });

  it('corta la carga a los 30 s si no hay respuesta, muestra el aviso y permite reintentar con Actualizar', async () => {
    vi.useFakeTimers();
    try {
      TestBed.resetTestingModule();
      const pendiente = new Subject<DatosDashboard>();
      cargar = vi.fn(() => pendiente.asObservable());
      await TestBed.configureTestingModule({
        imports: [Dashboard],
        providers: [
          provideRouter([]),
          { provide: DashboardDatosService, useValue: { cargar } },
          {
            provide: SucursalesApiService,
            useValue: { listarActivas: () => of([{ id: 1, nombre: 'Nury Real' }]) },
          },
          {
            provide: PrediccionStockService,
            useValue: {
              cargarArticulos: () => of([]),
              generarSugerencias: () => of({ origen: 'datos-insuficientes-local', predicciones: [] }),
            },
          },
          {
            provide: ConsultasAsistenteService,
            useValue: {
              esquema: () => of(new Map()),
              describirEsquema: () => '',
              ejecutar: () => of({}),
              nombresReales: () => of({ personas: [], proveedores: [] }),
              primeraVenta: () => of(null),
            },
          },
          {
            provide: OrquestadorIaService,
            useValue: { solicitar: () => throwError(() => new Error('Sin IA en pruebas')) },
          },
        ],
      }).compileComponents();

      fixture = TestBed.createComponent(Dashboard);
      fixture.detectChanges();
      const el = fixture.nativeElement as HTMLElement;
      expect(el.querySelector('.esqueleto-grid')).not.toBeNull();

      vi.advanceTimersByTime(TIEMPO_LIMITE_CONSULTA_MS);
      fixture.detectChanges();

      expect(el.querySelector('.esqueleto-grid')).toBeNull();
      expect(el.textContent).toContain('No se pudieron cargar los datos del negocio');
      expect(el.textContent).toContain('Usa «Actualizar» o cambia el período para reintentar');

      cargar.mockReturnValueOnce(of(datosDe('30d', null)));
      el.querySelector<HTMLButtonElement>('.refresh-button')!.click();
      fixture.detectChanges();

      expect(cargar).toHaveBeenCalledTimes(2);
      expect(el.textContent).not.toContain('No se pudieron cargar los datos del negocio');
      expect(el.querySelector('.kpi-amount')?.textContent).toContain('5.000');
    } finally {
      vi.useRealTimers();
    }
  });

  it('muestra la nota «Sin contar ventas a empleados.» en las tarjetas del análisis de clientes', () => {
    const el = fixture.nativeElement as HTMLElement;
    const notasVentas = Array.from(el.querySelectorAll('#panel-ventas .columnas-nota')).map((n) => n.textContent ?? '');
    expect(notasVentas).toHaveLength(3);
    expect(notasVentas.every((texto) => texto.includes('Sin contar ventas a empleados.'))).toBe(true);

    abrirPestana(1);
    const notasProductos = Array.from(el.querySelectorAll('#panel-productos .columnas-nota')).map((n) => n.textContent ?? '');
    expect(notasProductos).toHaveLength(2);
    expect(notasProductos.every((texto) => texto.includes('Sin contar ventas a empleados.'))).toBe(true);
  });
});
