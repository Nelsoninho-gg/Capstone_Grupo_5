import { TestBed } from '@angular/core/testing';
import { resumenDePrueba } from '../../models/datos-prueba';
import { ReporteSucursales } from './reporte-sucursales';

describe('ReporteSucursales', () => {
  function render(resumen = [resumenDePrueba()], anterior = [resumenDePrueba({ total: 40000 })]) {
    const fixture = TestBed.createComponent(ReporteSucursales);
    fixture.componentRef.setInput('resumen', resumen);
    fixture.componentRef.setInput('resumenAnterior', anterior);
    fixture.detectChanges();
    return fixture.nativeElement as HTMLElement;
  }

  it('shows every branch separately with its change against the previous period', () => {
    const element = render(
      [
        resumenDePrueba(),
        resumenDePrueba({ sucursalId: 2, sucursal: 'Nury Ñuñoa', total: 20000, ventas: 4 }),
        resumenDePrueba({ sucursalId: null, sucursal: 'Sin sucursal', total: 800, ventas: 1 }),
      ],
      [resumenDePrueba({ total: 40000 })],
    );
    const filas = Array.from(element.querySelectorAll('.data-table tbody tr'));
    expect(filas.map((f) => f.querySelector('.row-name')?.textContent?.trim())).toEqual([
      'Nury Providencia',
      'Nury Ñuñoa',
      'Sin sucursal',
    ]);
    expect(filas[0].querySelector('[data-label="Período anterior"]')?.textContent).toContain(
      '▲ 25 %',
    );
    expect(filas[1].querySelector('[data-label="Período anterior"]')?.textContent).toContain(
      'Sin datos antes',
    );
    expect(filas[2].classList).toContain('no-branch');
    expect(element.querySelectorAll('.bars li')).toHaveLength(3);
  });

  it('shows normal, employee and voided sales apart', () => {
    const fila = render().querySelector('.data-table tbody tr')!;
    expect(fila.querySelector('[data-label="Normales"]')?.textContent).toMatch(/9 · \$47\.000/);
    expect(fila.querySelector('[data-label="Empleados"]')?.textContent).toMatch(/1 · \$3\.000/);
    expect(fila.querySelector('[data-label="Anuladas"]')?.textContent).toMatch(/1 · \$4\.000/);
  });

  it('draws the payment methods per branch, or says there were no sales', () => {
    expect(
      Array.from(render().querySelectorAll('.legend li')).map((li) => li.textContent?.trim()),
    ).toEqual(['Efectivo', 'Débito']);
    const sinVentas = render([resumenDePrueba({ ventas: 0, total: 0, mediosPago: {} })], []);
    expect(sinVentas.textContent).toContain('Sin ventas en el período.');
  });

  it('marks a branch without sales in the period and names the compared period', () => {
    const fixture = TestBed.createComponent(ReporteSucursales);
    fixture.componentRef.setInput('resumen', [
      resumenDePrueba(),
      resumenDePrueba({
        sucursalId: 2,
        sucursal: 'Nury Vitacura',
        ventas: 0,
        total: 0,
        mediosPago: {},
      }),
    ]);
    fixture.componentRef.setInput('resumenAnterior', [
      resumenDePrueba({ sucursalId: 2, total: 12000 }),
    ]);
    fixture.componentRef.setInput('etiquetaAnterior', 'Semana anterior');
    fixture.detectChanges();
    const element = fixture.nativeElement as HTMLElement;
    const vitacura = element.querySelectorAll('.data-table tbody tr')[1];

    expect(vitacura.textContent).toContain('Sin ventas en este período');
    expect(vitacura.querySelector('[data-label="Semana anterior"]')?.textContent).toContain(
      '$12.000',
    );
    expect(element.querySelector('thead')?.textContent).toContain('Semana anterior');
    expect(element.querySelectorAll('.bars li')[1].textContent).toContain(
      'Sin ventas en este período',
    );
  });
});
