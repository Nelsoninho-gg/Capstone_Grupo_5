import { Component, computed, input, signal } from '@angular/core';
import {
  OrdenProductos,
  ProductoAgrupado,
  agruparProductos,
  normalizar,
  ordenarProductos,
  proporcion,
  variacion,
} from '../../models/reporte-ventas.model';
import { CostoProducto, ProductoVendido } from '../../models/reportes.model';
import { Desplegable } from '../desplegable/desplegable';
import {
  MargenProducto,
  UMBRALES_MARGEN,
  altoMargenBajoVolumen,
  altoVolumenBajoMargen,
  margenDe,
  resumenMargen,
} from '../../models/margen.model';
import { formatoClp, formatoNumero, textoVariacion, tonoVariacion } from '../../models/formato';

const TODAS = 'todas';
type OrdenProducto = OrdenProductos | 'margen' | 'margenPct';
export type EstadoCostos = 'cargando' | 'error' | 'listo';
/** Cuántos productos se muestran antes de "Ver todos". */
const LIMITE_INICIAL = 20;

/**
 * Pestaña Productos del dashboard: unidades vendidas y monto por separado (H4.4: mezclar ambas
 * cosas esconde cuál importa más), con búsqueda, categoría, orden y variación del monto contra
 * el período anterior. Con el costo actual de cada producto (H4.4 T03) muestra el margen en $
 * y %, avisa los productos sin costo o con receta incompleta (T04) y destaca los de alto
 * volumen y bajo margen o negativo, y los de alto margen y volumen casi nulo (T05).
 */
@Component({
  selector: 'app-reporte-productos',
  imports: [Desplegable],
  templateUrl: './reporte-productos.html',
  styleUrls: ['../../styles/reportes-base.css', './reporte-productos.css'],
})
export class ReporteProductos {
  readonly productos = input.required<ProductoVendido[]>();
  readonly productosAnterior = input<ProductoVendido[]>([]);
  /** "Semana anterior", "Mes anterior"... (H4.2). */
  readonly etiquetaAnterior = input('Período anterior');
  /** Costo actual de los productos (H4.4); vacío mientras carga o si falló. */
  readonly costos = input<CostoProducto[]>([]);
  readonly estadoCostos = input<EstadoCostos>('listo');

  protected readonly busqueda = signal('');
  protected readonly categoria = signal(TODAS);
  protected readonly orden = signal<OrdenProducto>('monto');
  protected readonly umbrales = UMBRALES_MARGEN;
  protected readonly verTodos = signal(false);

  protected readonly opcionesOrden: { valor: OrdenProducto; etiqueta: string }[] = [
    { valor: 'monto', etiqueta: 'Monto facturado' },
    { valor: 'unidades', etiqueta: 'Unidades vendidas' },
    { valor: 'ventas', etiqueta: 'Número de ventas' },
    { valor: 'margen', etiqueta: 'Margen en pesos' },
    { valor: 'margenPct', etiqueta: 'Margen en porcentaje' },
  ];

  private readonly agrupados = computed(() => agruparProductos(this.productos()));
  private readonly costosPorId = computed(
    () => new Map(this.costos().map((costo) => [costo.productoId, costo])),
  );
  /** El margen se muestra cuando llegaron los costos. */
  protected readonly conMargen = computed(() => this.estadoCostos() === 'listo');
  private readonly margenes = computed(() => {
    const costos = this.costosPorId();
    return new Map(
      this.agrupados().map((p) => [p.productoId, margenDe(p, costos.get(p.productoId))]),
    );
  });
  private readonly anteriores = computed(
    () => new Map(agruparProductos(this.productosAnterior()).map((p) => [p.productoId, p])),
  );

  protected readonly categorias = computed(() =>
    [...new Set(this.agrupados().map((p) => p.categoria ?? 'Sin categoría'))].sort((a, b) =>
      a.localeCompare(b, 'es'),
    ),
  );

  protected readonly opcionesCategoria = computed(() => [
    { valor: TODAS, etiqueta: 'Todas las categorías' },
    ...this.categorias().map((categoria) => ({ valor: categoria, etiqueta: categoria })),
  ]);

  protected readonly filtrados = computed(() => {
    const texto = normalizar(this.busqueda());
    const categoria = this.categoria();
    const orden = this.orden();
    const elegidos = this.agrupados().filter(
      (p) =>
        (!texto || normalizar(p.producto).includes(texto)) &&
        (categoria === TODAS || (p.categoria ?? 'Sin categoría') === categoria),
    );
    if (orden !== 'margen' && orden !== 'margenPct') return ordenarProductos(elegidos, orden);
    // Por margen: de mayor a menor; los sin costo al final.
    const valor = (p: ProductoAgrupado) => this.margenDe(p)[orden] ?? -Infinity;
    return [...elegidos].sort(
      (a, b) =>
        (valor(b) === valor(a) ? 0 : valor(b) > valor(a) ? 1 : -1) ||
        a.producto.localeCompare(b.producto, 'es'),
    );
  });

  protected readonly visibles = computed(() =>
    this.verTodos() ? this.filtrados() : this.filtrados().slice(0, LIMITE_INICIAL),
  );
  protected readonly ocultos = computed(() => this.filtrados().length - this.visibles().length);

  protected readonly totalMonto = computed(() =>
    this.filtrados().reduce((total, p) => total + p.monto, 0),
  );
  protected readonly totalUnidades = computed(() =>
    this.filtrados().reduce((total, p) => total + p.unidades, 0),
  );
  private readonly maximo = computed(() =>
    Math.max(0, ...this.filtrados().map((p) => this.valorBarra(p))),
  );

  /** Margen de los productos filtrados (solo los que tienen costo). */
  protected readonly resumen = computed(() => resumenMargen(this.filtrados(), this.costosPorId()));
  /** H4.4 T05: alto volumen y bajo margen, entre todos los productos del período. */
  protected readonly bajoMargen = computed(() =>
    this.conMargen() ? altoVolumenBajoMargen(this.agrupados(), this.costosPorId()) : [],
  );
  /** H4.4 T05: alto margen y volumen casi nulo, candidatos a promocionar más. */
  protected readonly paraPromocionar = computed(() =>
    this.conMargen() ? altoMargenBajoVolumen(this.agrupados(), this.costosPorId()) : [],
  );

  protected actualizarBusqueda(event: Event): void {
    this.busqueda.set((event.target as HTMLInputElement).value);
  }

  protected ordenarPor(orden: OrdenProducto): void {
    this.orden.set(orden);
  }

  protected ancho(producto: ProductoAgrupado): number {
    return proporcion(this.valorBarra(producto), this.maximo());
  }

  /** La barra sigue al orden elegido; por margen, solo lo positivo. */
  private valorBarra(producto: ProductoAgrupado): number {
    const orden = this.orden();
    if (orden === 'margen' || orden === 'margenPct') {
      return Math.max(0, this.margenDe(producto)[orden] ?? 0);
    }
    return producto[orden];
  }

  protected margenDe(producto: ProductoAgrupado): MargenProducto {
    return this.margenes().get(producto.productoId) ?? margenDe(producto, undefined);
  }

  /** Margen negativo en rojo, bajo el umbral en ámbar. */
  protected tonoMargen(margen: MargenProducto): string {
    if (margen.margenPct === null) return '';
    if (margen.margenPct < 0) return 'negative';
    return margen.margenPct < this.umbrales.margenBajo ? 'low' : '';
  }

  /** "-$3.000" en vez de "$-3.000" para los márgenes negativos. */
  protected clpMargen(valor: number): string {
    return valor < 0 ? `-${formatoClp.format(-valor)}` : formatoClp.format(valor);
  }

  protected porcentaje(valor: number | null): string {
    return valor === null ? '—' : `${formatoNumero.format(valor)} %`;
  }

  /** Participación del producto en el monto de los productos filtrados. */
  protected participacion(producto: ProductoAgrupado): string {
    const total = this.totalMonto();
    return total ? `${formatoNumero.format((producto.monto / total) * 100)} %` : '—';
  }

  protected variacionDe(producto: ProductoAgrupado): number | null {
    return variacion(producto.monto, this.montoAnterior(producto));
  }

  protected montoAnterior(producto: ProductoAgrupado): number {
    return this.anteriores().get(producto.productoId)?.monto ?? 0;
  }

  protected readonly textoVariacion = textoVariacion;
  protected readonly tonoVariacion = tonoVariacion;
  protected clp(valor: number): string {
    return formatoClp.format(valor);
  }
  protected numero(valor: number): string {
    return formatoNumero.format(valor);
  }
}
