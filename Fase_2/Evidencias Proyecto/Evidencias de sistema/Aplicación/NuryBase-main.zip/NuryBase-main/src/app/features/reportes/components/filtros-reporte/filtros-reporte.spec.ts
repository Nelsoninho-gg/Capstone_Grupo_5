import { Component, signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { SeleccionPeriodo } from '../../models/periodo.model';
import { FiltrosReporte } from './filtros-reporte';

@Component({
  imports: [FiltrosReporte],
  template: `<app-filtros-reporte
    [sucursales]="sucursales"
    hoy="2026-11-04"
    [(seleccionadas)]="seleccionadas"
    [(periodo)]="periodo"
  />`,
})
class Anfitrion {
  sucursales = [
    { id: 1, nombre: 'Providencia' },
    { id: 2, nombre: 'Ñuñoa' },
    { id: 3, nombre: 'Vitacura' },
  ];
  seleccionadas = signal<number[]>([]);
  periodo = signal<SeleccionPeriodo>({ tipo: 'semana', referencia: '2026-11-04' });
}

describe('FiltrosReporte', () => {
  function render() {
    const fixture = TestBed.createComponent(Anfitrion);
    fixture.detectChanges();
    const element = fixture.nativeElement as HTMLElement;
    const desplegable = () =>
      element.querySelector<HTMLButtonElement>('[aria-label="Sucursales del reporte"]')!;
    const abrir = () => {
      desplegable().click();
      fixture.detectChanges();
    };
    const marcar = (texto: string) => {
      const opcion = Array.from(element.querySelectorAll('.option')).find(
        (o) => o.textContent?.trim() === texto,
      )!;
      const casilla = opcion.querySelector('input')!;
      casilla.click();
      fixture.detectChanges();
    };
    return { fixture, element, desplegable, abrir, marcar, host: fixture.componentInstance };
  }

  it('picks several branches from a dropdown and goes back to all', () => {
    const { host, element, desplegable, abrir, marcar } = render();
    expect(desplegable().textContent).toContain('Todas las sucursales');
    expect(element.querySelector('.picker-panel')).toBeNull();

    abrir();
    expect(desplegable().getAttribute('aria-expanded')).toBe('true');
    marcar('Providencia');
    expect(host.seleccionadas()).toEqual([1]);
    expect(desplegable().textContent).toContain('Providencia');

    marcar('Vitacura');
    expect(host.seleccionadas()).toEqual([1, 3]);
    expect(desplegable().textContent).toContain('2 sucursales');

    marcar('Todas las sucursales');
    expect(host.seleccionadas()).toEqual([]);
  });

  it('opens one dropdown at a time', () => {
    const { element, abrir, fixture } = render();
    abrir();
    element.querySelector<HTMLButtonElement>('[aria-label="Período del reporte"]')!.click();
    fixture.detectChanges();
    expect(element.querySelector('#branch-options')).toBeNull();
    expect(element.querySelector('#period-options')).not.toBeNull();
  });

  it('closes the dropdown with a click outside or Escape', () => {
    const { element, abrir, fixture } = render();
    abrir();
    document.body.click();
    fixture.detectChanges();
    expect(element.querySelector('.picker-panel')).toBeNull();

    abrir();
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape' }));
    fixture.detectChanges();
    expect(element.querySelector('.picker-panel')).toBeNull();
  });

  it('changes the period from a dropdown like the branches one and asks two dates for a range', () => {
    const { host, element, fixture } = render();
    const boton = () =>
      element.querySelector<HTMLButtonElement>('[aria-label="Período del reporte"]')!;
    const elegir = (texto: string) => {
      boton().click();
      fixture.detectChanges();
      Array.from(element.querySelectorAll<HTMLButtonElement>('#period-options .option'))
        .find((o) => o.textContent?.trim() === texto)!
        .click();
      fixture.detectChanges();
    };
    expect(boton().textContent).toContain('Semana');

    elegir('Mes');
    expect(host.periodo().tipo).toBe('mes');
    expect(boton().textContent).toContain('Mes');
    expect(element.querySelector('#period-options')).toBeNull();
    expect(element.querySelector('.date-control')?.textContent).toContain('Mes de');

    // La opción elegida queda marcada al abrir de nuevo.
    boton().click();
    fixture.detectChanges();
    expect(element.querySelector('#period-options .selected')?.textContent?.trim()).toBe('Mes');
    boton().click();
    fixture.detectChanges();

    elegir('Rango personalizado');
    const [desde, hasta] = Array.from(
      element.querySelectorAll<HTMLInputElement>('input[type="date"]'),
    );
    desde.value = '2026-10-01';
    desde.dispatchEvent(new Event('change'));
    hasta.value = '2026-10-15';
    hasta.dispatchEvent(new Event('change'));
    fixture.detectChanges();
    expect(host.periodo()).toEqual({
      tipo: 'rango',
      referencia: '2026-11-04',
      desde: '2026-10-01',
      hasta: '2026-10-15',
    });
  });
});
