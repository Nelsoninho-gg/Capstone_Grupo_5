/** Formatos compartidos por el dashboard de Reportes. */
export const formatoClp = new Intl.NumberFormat('es-CL', {
  style: 'currency',
  currency: 'CLP',
  maximumFractionDigits: 0,
});

export const formatoNumero = new Intl.NumberFormat('es-CL', { maximumFractionDigits: 1 });

/** "▲ 12,5 % vs período anterior"; corto: "▲ 12,5 %". */
export function textoVariacion(valor: number | null, corto = false): string {
  if (valor === null) return corto ? 'Sin datos antes' : 'Sin datos del período anterior';
  if (valor === 0) return corto ? 'Igual' : 'Igual que el período anterior';
  const texto = `${valor > 0 ? '▲' : '▼'} ${formatoNumero.format(Math.abs(valor))} %`;
  return corto ? texto : `${texto} vs período anterior`;
}

/** Subir es bueno salvo cuando `menosEsMejor` (por ejemplo, en las anuladas). */
export function tonoVariacion(valor: number | null, menosEsMejor = false): string {
  if (valor === null || valor === 0) return 'neutral';
  return valor > 0 !== menosEsMejor ? 'positiva' : 'negativa';
}
