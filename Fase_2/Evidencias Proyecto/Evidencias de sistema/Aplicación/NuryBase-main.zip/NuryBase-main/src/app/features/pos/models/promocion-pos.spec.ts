import { PromocionApi } from '../../../core/api/promociones-api.service';
import { PosProduct } from './pos.model';
import { descuentoPorPromociones, lineasDePromocion, preciosPromocion } from './promocion-pos';

const producto = (id: number, nombre: string, precioVenta: number): PosProduct => ({
  id,
  nombre,
  categoriaId: 'x',
  categoriaNombre: 'x',
  codigoInterno: `NUR-${id}`,
  codigoBarras: '',
  precioVenta,
  icono: '',
  descripcion: '',
  activo: true,
});

const catalogo = new Map(
  [
    producto(1, 'Sándwich', 3500),
    producto(2, 'Café', 2000),
    producto(3, 'Jugo', 1500),
    producto(11, 'A', 1000),
    producto(12, 'B', 1000),
    producto(13, 'C', 1000),
  ].map((p) => [p.id, p] as const),
);

const promocion = (
  tipo: PromocionApi['tipo'],
  valor: number,
  productos: [number, number][],
): PromocionApi => ({
  id: 9,
  nombre: 'Promo',
  tipo,
  valor_descuento: String(valor),
  inicio: '',
  termino: '',
  activa: true,
  creado_en: '',
  sucursales: [],
  productos: productos.map(([producto_id, cantidad]) => ({ producto_id, cantidad, producto: null })),
});

const unitarios = (p: PromocionApi) =>
  preciosPromocion(p, catalogo)!.map((linea) => [linea.producto.id, linea.precioUnitario]);

// Mismos casos que database/tests/promociones_venta.sql: el POS muestra lo que cobra la base.
describe('preciosPromocion (H5.2 T05)', () => {
  it('spreads a fixed amount by list price: sándwich + café $1.000 off', () => {
    expect(unitarios(promocion('monto_fijo', 1000, [[1, 1], [2, 1]]))).toEqual([
      [1, 2864],
      [2, 1636],
    ]);
  });

  it('applies a percentage to each unit, rounded to pesos', () => {
    expect(unitarios(promocion('porcentaje', 20, [[2, 1]]))).toEqual([[2, 1600]]);
    expect(unitarios(promocion('porcentaje', 15, [[3, 1]]))).toEqual([[3, 1275]]);
  });

  it('gives the rounding remainder to the priciest single product so the amount is exact', () => {
    const precios = preciosPromocion(promocion('monto_fijo', 1000, [[11, 1], [12, 1], [13, 1]]), catalogo)!;
    expect(precios.map((p) => p.precioUnitario)).toEqual([666, 667, 667]);
    expect(precios.reduce((suma, p) => suma + (p.precioLista - p.precioUnitario), 0)).toBe(1000);
  });

  it('never goes below $0 when the amount exceeds the price', () => {
    expect(unitarios(promocion('monto_fijo', 5000, [[3, 1]]))).toEqual([[3, 0]]);
  });

  it('cannot be applied if a product is not in the POS catalog', () => {
    expect(preciosPromocion(promocion('porcentaje', 10, [[1, 1], [99, 1]]), catalogo)).toBeNull();
  });

  it('builds the cart lines for a promotion applied twice', () => {
    const lineas = lineasDePromocion(
      { promocion: promocion('monto_fijo', 1000, [[1, 1], [2, 1]]), veces: 2 },
      catalogo,
    );
    expect(lineas.map((l) => [l.producto.nombre, l.cantidad, l.subtotal, l.promocion?.id])).toEqual([
      ['Sándwich', 2, 5728, 9],
      ['Café', 2, 3272, 9],
    ]);
    expect(descuentoPorPromociones(lineas)).toBe(2000);
  });
});
