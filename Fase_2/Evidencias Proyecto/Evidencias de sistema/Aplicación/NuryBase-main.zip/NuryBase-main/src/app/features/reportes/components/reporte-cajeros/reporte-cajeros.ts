import { Component, computed, input, model, signal } from '@angular/core';
import { proporcion, variacion } from '../../models/reporte-ventas.model';
import { FiltroTurno, RendimientoCajero, TurnoReporte } from '../../models/reportes.model';
import { Desplegable } from '../desplegable/desplegable';
import { SelectorTurno } from '../selector-turno/selector-turno';
import { formatoClp, formatoNumero, textoVariacion, tonoVariacion } from '../../models/formato';

export type MetricaCajero = 'total' | 'ventas' | 'ventaPromedio' | 'productos';

/**
 * Pestaña Cajeros del dashboard (H4.3): total vendido, ventas, venta promedio y productos por
 * cajero, ordenables por cualquiera de ellas y comparados con su propio período anterior. Las
 * anuladas no cuentan en las métricas y se muestran aparte para revisar su frecuencia.
 * Con un turno elegido (H4.3 T03) las cifras son solo de ese turno y no se comparan con el
 * período anterior, porque no hay un turno equivalente.
 */
@Component({
  selector: 'app-reporte-cajeros',
  imports: [SelectorTurno, Desplegable],
  templateUrl: './reporte-cajeros.html',
  styleUrls: ['../../styles/reportes-base.css', './reporte-cajeros.css'],
})
export class ReporteCajeros {
  readonly cajeros = input.required<RendimientoCajero[]>();
  readonly cajerosAnterior = input<RendimientoCajero[]>([]);
  /** "Semana anterior", "Mes anterior"... (H4.2). */
  readonly etiquetaAnterior = input('Período anterior');
  /** Turnos del período para el desplegable (H4.3 T03). */
  readonly turnos = input<TurnoReporte[]>([]);
  readonly turno = model<FiltroTurno>(null);
  /** Mientras llegan las cifras del turno elegido. */
  readonly cargando = input(false);

  protected readonly comparar = computed(() => this.turno() === null);

  protected readonly metrica = signal<MetricaCajero>('total');
  protected readonly metricas: { valor: MetricaCajero; etiqueta: string }[] = [
    { valor: 'total', etiqueta: 'Total vendido' },
    { valor: 'ventas', etiqueta: 'Número de ventas' },
    { valor: 'ventaPromedio', etiqueta: 'Venta promedio' },
    { valor: 'productos', etiqueta: 'Productos vendidos' },
  ];

  private readonly anteriores = computed(
    () => new Map(this.cajerosAnterior().map((c) => [c.cajeroId, c])),
  );

  protected readonly ordenados = computed(() => {
    const metrica = this.metrica();
    return [...this.cajeros()].sort(
      (a, b) => b[metrica] - a[metrica] || a.cajero.localeCompare(b.cajero, 'es'),
    );
  });
  private readonly maximo = computed(() =>
    Math.max(0, ...this.cajeros().map((c) => c[this.metrica()])),
  );
  protected readonly etiquetaMetrica = computed(
    () => this.metricas.find((m) => m.valor === this.metrica())!.etiqueta,
  );

  /** Cajeros con anulaciones, de la mayor frecuencia a la menor. */
  protected readonly conAnulaciones = computed(() =>
    this.cajeros()
      .filter((c) => c.anuladas.ventas > 0)
      .sort(
        (a, b) => this.frecuencia(b) - this.frecuencia(a) || b.anuladas.ventas - a.anuladas.ventas,
      ),
  );

  protected ordenarPor(metrica: MetricaCajero): void {
    this.metrica.set(metrica);
  }

  protected ancho(cajero: RendimientoCajero): number {
    return proporcion(cajero[this.metrica()], this.maximo());
  }

  /** Variación de la métrica elegida contra el período anterior del mismo cajero. */
  protected variacionDe(cajero: RendimientoCajero): number | null {
    return variacion(cajero[this.metrica()], this.anteriorDe(cajero));
  }

  /** La métrica elegida del mismo cajero en el período anterior (0 si no vendió). */
  protected anteriorDe(cajero: RendimientoCajero): number {
    return this.anteriores().get(cajero.cajeroId)?.[this.metrica()] ?? 0;
  }

  /** Anuladas sobre el total de ventas registradas (válidas + anuladas), en %. */
  protected frecuencia(cajero: RendimientoCajero): number {
    const registradas = cajero.ventas + cajero.anuladas.ventas;
    return registradas ? (cajero.anuladas.ventas / registradas) * 100 : 0;
  }

  protected formatoMetrica(valor: number): string {
    return this.metrica() === 'total' || this.metrica() === 'ventaPromedio'
      ? this.clp(valor)
      : this.numero(valor);
  }

  protected readonly textoVariacion = textoVariacion;
  protected readonly tonoVariacion = tonoVariacion;
  protected clp(valor: number): string {
    return formatoClp.format(valor);
  }
  protected numero(valor: number): string {
    return formatoNumero.format(valor);
  }
}
