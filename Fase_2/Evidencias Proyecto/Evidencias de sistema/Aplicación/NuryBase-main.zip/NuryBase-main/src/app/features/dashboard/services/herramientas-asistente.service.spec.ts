import { TestBed } from '@angular/core/testing';
import { Subject, firstValueFrom, of, throwError } from 'rxjs';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { SucursalesApiService } from '../../../core/api/sucursales-api.service';
import { ArticuloPredictivo } from '../../inventario/models/prediccion.model';
import { PrediccionStockService } from '../../inventario/services/prediccion-stock.service';
import { ProyeccionCierre, TIEMPO_LIMITE_CONSULTA_MS, construirEscenario } from '../models/dashboard.model';
import { VentaDashboardApi } from '../../../core/api/ventas-api.service';
import { ConsultaAsistente, ConsultasAsistenteService, EsquemaBase } from './consultas-asistente.service';
import { DashboardDatosService } from './dashboard-datos.service';
import { HerramientasAsistenteService } from './herramientas-asistente.service';

const ESQUEMA: EsquemaBase = new Map();

describe('HerramientasAsistenteService', () => {
  let servicio: HerramientasAsistenteService;
  let filasPor: Record<string, unknown>;
  const ejecutar = vi.fn((consulta: ConsultaAsistente, _esquema: EsquemaBase, _completo?: boolean) => {
    const respuesta = filasPor[consulta.recurso];
    return of(
      respuesta && typeof respuesta === 'object' && 'error' in (respuesta as object)
        ? { consulta, ...(respuesta as object) }
        : respuesta && typeof respuesta === 'object' && 'truncado' in (respuesta as object)
          ? { consulta, ...(respuesta as object) }
          : { consulta, filas: (respuesta ?? []) as unknown[], total: ((respuesta ?? []) as unknown[]).length, truncado: false },
    );
  });
  const cargarDashboard = vi.fn();
  const cargarArticulos = vi.fn();

  beforeEach(() => {
    ejecutar.mockClear();
    filasPor = {};
    TestBed.configureTestingModule({
      providers: [
        { provide: ConsultasAsistenteService, useValue: { ejecutar } },
        { provide: SucursalesApiService, useValue: { listar: () => of([{ id: 1 }, { id: 2 }]) } },
        { provide: DashboardDatosService, useValue: { cargar: cargarDashboard } },
        { provide: PrediccionStockService, useValue: { cargarArticulos } },
      ],
    });
    servicio = TestBed.inject(HerramientasAsistenteService);
  });

  const correr = (nombre: string, parametros: Record<string, unknown> = {}) =>
    firstValueFrom(servicio.ejecutar({ nombre, parametros }, ESQUEMA));

  it('margen_producto calcula con precio de compra y costo de receta', async () => {
    filasPor['productos'] = [{ id: 1, nombre: 'CHAPARRITA', precio_venta: 3000, precio_compra: 1710, activo: true }];
    filasPor['v_costo_producto'] = [];

    const { datos } = await correr('margen_producto', { nombre: 'chaparrita' });

    expect(ejecutar.mock.calls[0][0].filtros).toEqual({ nombre: 'ilike.*chaparrita*' });
    expect(datos).toEqual([expect.objectContaining({ margen_por_unidad: 811, margen_porcentaje: 27 })]);
  });

  it('margen_producto exige nombre o id', async () => {
    expect((await correr('margen_producto')).error).toContain('nombre o producto_id');
  });

  it('ventas_periodo usa toda la red por defecto y suma en TypeScript', async () => {
    filasPor['rpc/fn_reporte_ventas_sucursal'] = [
      { sucursal: 'A', ventas: 2, total: 1000 },
      { sucursal: 'B', ventas: 2, total: 3000 },
    ];

    const { datos } = await correr('ventas_periodo', { desde: '2026-10-01', hasta: '2026-10-31' });

    const consulta = ejecutar.mock.calls[0][0];
    expect(consulta.filtros).toEqual({ p_desde: '2026-10-01', p_hasta: '2026-10-31', p_sucursales: '{1,2}' });
    expect(ejecutar.mock.calls[0][2]).toBe(true);
    expect(datos).toMatchObject({ monto_total_clp: 4000, cantidad_ventas: 4, ticket_promedio_clp: 1000 });
  });

  it('ventas_periodo cuenta las ventas por medio de pago, sin anuladas y en un rango que cubre a Chile', async () => {
    filasPor['rpc/fn_reporte_ventas_sucursal'] = [
      { sucursal_id: 1, sucursal: 'A', ventas: 2, total: 3000, medios_pago: { efectivo: 1000, debito: 2000 } },
    ];
    filasPor['ventas'] = [
      { fecha_venta: '2026-10-05T15:00:00', medio_pago: 'efectivo' },
      { fecha_venta: '2026-10-06T15:00:00', medio_pago: 'debito' },
    ];

    const { datos } = await correr('ventas_periodo', { desde: '2026-10-01', hasta: '2026-10-31' });

    expect(ejecutar.mock.calls[1][0].filtros).toEqual({
      anulada: 'eq.false',
      sucursal_id: 'in.(1)',
      fecha_venta: ['gte.2026-10-01T00:00:00.000Z', 'lt.2026-11-01T06:00:00.000Z'],
    });
    expect(datos).toMatchObject({
      por_medio_de_pago: [
        { medio: 'debito', cantidad_ventas: 1, monto_clp: 2000 },
        { medio: 'efectivo', cantidad_ventas: 1, monto_clp: 1000 },
      ],
    });
  });

  it('ventas_periodo entrega los totales aunque no pueda contar por medio de pago', async () => {
    filasPor['rpc/fn_reporte_ventas_sucursal'] = [
      { sucursal_id: 1, sucursal: 'A', ventas: 2, total: 3000, medios_pago: { efectivo: 3000 } },
    ];
    filasPor['ventas'] = { filas: [], total: 9000, truncado: true };

    const { datos, error } = await correr('ventas_periodo', { desde: '2026-10-01', hasta: '2026-10-31' });

    expect(error).toBeUndefined();
    expect(datos).toMatchObject({
      monto_total_clp: 3000,
      por_medio_de_pago: [{ medio: 'efectivo', cantidad_ventas: null, monto_clp: 3000 }],
    });
  });

  it('consultar llama por su nombre a las anulaciones sin responsable, solo en ventas anuladas', async () => {
    filasPor['ventas'] = [
      { usuarios: { nombre: 'Ana' } },
      { usuarios: null },
    ];
    const parametros = {
      recurso: 'ventas',
      select: 'anulada_por,usuarios!anulada_por(nombre)',
      agregar: { contar: true, agrupar_por: 'usuarios.nombre' },
    };

    const anuladas = await correr('consultar', { ...parametros, filtros: { anulada: 'eq.true' } });
    expect(anuladas.datos).toContainEqual({ 'usuarios.nombre': 'Antes de registrar al responsable', filas: 1 });

    const vigentes = await correr('consultar', parametros);
    expect(vigentes.datos).toContainEqual({ 'usuarios.nombre': 'sin dato', filas: 1 });
  });

  it('auditoria_usuarios no muestra un id vacío si el usuario ya no está', async () => {
    filasPor['auditoria_usuarios'] = [{ usuario_id: null, realizado_por: null, campo_modificado: 'rol' }];
    filasPor['usuarios'] = [];

    const { datos } = await correr('auditoria_usuarios', {});

    expect(datos).toEqual([expect.objectContaining({ usuario: 'Usuario no disponible' })]);
  });

  it('entrega las fechas de la base en hora de Chile', async () => {
    filasPor['ventas'] = [{ fecha_venta: '2026-10-06T01:32:52' }];

    const { datos } = await correr('consultar', { recurso: 'ventas', select: 'fecha_venta' });

    expect(datos).toMatchObject({ filas: [{ fecha_venta: '2026-10-05 22:32' }] });
  });

  it('respeta las sucursales pedidas y valida las fechas', async () => {
    await correr('ventas_periodo', { desde: '2026-10-01', hasta: '2026-10-31', sucursal_ids: [2, 'x'] });
    expect(ejecutar.mock.calls[0][0].filtros?.['p_sucursales']).toBe('{2}');
    expect((await correr('ventas_periodo', { desde: 'octubre', hasta: '2026-10-31' })).error).toContain('YYYY-MM-DD');
  });

  it('no calcula sobre datos truncados', async () => {
    filasPor['rpc/fn_reporte_ventas_sucursal'] = { filas: [{ total: 1 }], total: 9000, truncado: true };
    const resultado = await correr('ventas_periodo', { desde: '2026-10-01', hasta: '2026-10-31' });
    expect(resultado.error).toContain('acota la consulta');
    expect(resultado.datos).toBeUndefined();
  });

  it('ranking_productos cruza costos de receta y de compra', async () => {
    filasPor['rpc/fn_reporte_productos_sucursal'] = [
      { producto_id: 1, producto: 'Café', unidades: 2, monto: 2000 },
      { producto_id: 2, producto: 'Pan', unidades: 1, monto: 1000 },
    ];
    filasPor['v_costo_producto'] = [{ producto_id: 1, costo_receta: 100 }];
    filasPor['productos'] = [{ id: 2, precio_compra: 200 }];

    const { datos } = (await correr('ranking_productos', { desde: '2026-10-01', hasta: '2026-10-31', orden: 'monto' })) as {
      datos: { productos: unknown[] };
    };
    expect(datos.productos).toEqual([
      expect.objectContaining({ producto: 'Café', ganancia_limpia: 1481 }),
      expect.objectContaining({ producto: 'Pan', ganancia_limpia: 640 }),
    ]);
  });

  it('ranking_cajeros ordena de mayor a menor', async () => {
    filasPor['rpc/fn_reporte_cajeros'] = [{ cajero: 'B', total: 10 }, { cajero: 'A', total: 90 }];
    const { datos } = await correr('ranking_cajeros', { desde: '2026-10-01', hasta: '2026-10-31' });
    expect((datos as { cajero: string }[]).map((c) => c.cajero)).toEqual(['A', 'B']);
  });

  it('por_comprar usa 1 día por defecto', async () => {
    await correr('por_comprar', { sucursal_id: 3 });
    expect(ejecutar.mock.calls[0][0].filtros).toEqual({ p_dias: '1', p_sucursal_id: '3' });
  });

  it('analisis_dashboard reutiliza el cálculo del dashboard', async () => {
    const proyeccion: ProyeccionCierre = {
      estado: 'historial-insuficiente',
      factor: 1,
      ocurrencias: 2,
      minimoOcurrencias: 3,
      mensaje:
        'Aún no hay días suficientes para proyectar el cierre de hoy: se necesitan al menos 3 días anteriores de lunes con ventas y hay 2.',
    };
    cargarDashboard.mockReturnValueOnce(
      of({
        diasHistorial: 40,
        escenario: { kpis: [{ id: 'ingresos' }], lineasNegocio: [], comprasConjuntas: [], productosDestacados: [], productosMasVendidos: [], demandaHoraria: [], demandaPorDiaSemana: [], proyeccion },
      }),
    );
    const { datos } = await correr('analisis_dashboard', { periodo: '7d', sucursal_id: 1 });
    expect(cargarDashboard).toHaveBeenCalledWith('7d', 1);
    expect(datos).toMatchObject({
      dias_de_historial: 40,
      kpis: [{ id: 'ingresos' }],
      ventas_por_dia_semana: [],
      proyeccion,
    });
  });

  it('analisis_dashboard acepta "1d" y entrega el estado de la proyección de cierre', async () => {
    const proyeccion: ProyeccionCierre = {
      estado: 'disponible',
      factor: 2.5,
      ocurrencias: 4,
      minimoOcurrencias: 3,
      mensaje: 'Proyección con 4 días anteriores de lunes: a esta hora se llevaba en promedio el 40 % del día.',
    };
    cargarDashboard.mockReturnValueOnce(
      of({
        diasHistorial: 40,
        escenario: { kpis: [{ id: 'ingresos' }], lineasNegocio: [], comprasConjuntas: [], productosDestacados: [], productosMasVendidos: [], demandaHoraria: [], demandaPorDiaSemana: [], proyeccion },
      }),
    );

    const { datos } = await correr('analisis_dashboard', { periodo: '1d' });

    expect(cargarDashboard).toHaveBeenCalledWith('1d', null);
    expect(datos).toMatchObject({ periodo: '1d', proyeccion });
  });

  it('no entrega el KPI de cierre al modelo cuando la proyección no está disponible', async () => {
    // Escenario real: jueves 12-11-2026 a las 15:00, con venta hoy y solo dos jueves anteriores.
    const venta = (fecha: Date, total: number): VentaDashboardApi => ({
      id: fecha.getTime(),
      fecha_venta: fecha.toISOString().slice(0, 19),
      total,
      detalle_venta: [],
    });
    const escenario = construirEscenario(
      [
        venta(new Date(2026, 9, 29, 10), 400),
        venta(new Date(2026, 10, 5, 10), 400),
        venta(new Date(2026, 10, 12, 10), 50),
      ],
      new Map(),
      '1d',
      new Date(2026, 10, 12, 15, 0),
    );
    cargarDashboard.mockReturnValueOnce(of({ diasHistorial: 40, escenario }));

    const { datos } = await correr('analisis_dashboard', { periodo: '1d' });
    const kpis = (datos as { kpis: { id: string }[] }).kpis;

    expect(escenario.proyeccion.estado).toBe('historial-insuficiente');
    // Si el cierre viajara, el verificador de cifras aceptaría esa cifra como un cálculo real.
    expect(kpis.some((kpi) => kpi.id === 'proyeccion-ia')).toBe(false);
  });

  it('analisis_dashboard vuelve a "30d" si el período pedido no es válido', async () => {
    cargarDashboard.mockReturnValueOnce(
      of({
        diasHistorial: 10,
        escenario: { kpis: [], lineasNegocio: [], comprasConjuntas: [], productosDestacados: [], productosMasVendidos: [], demandaHoraria: [], demandaPorDiaSemana: [] },
      }),
    );

    await correr('analisis_dashboard', { periodo: '2d' });

    expect(cargarDashboard).toHaveBeenCalledWith('30d', null);
  });

  it('prediccion_stock calcula con los algoritmos y filtra por artículo', async () => {
    const leche: ArticuloPredictivo = {
      id: 'art-1',
      articulo: 'Leche',
      tipo: 'materia_prima',
      sucursalId: 1,
      sucursal: 'A',
      stockActual: 8,
      stockMinimo: 1,
      unidad: 'l',
      diasHistorial: 40,
      consumoDiarioBase: 5,
    };
    cargarArticulos.mockReturnValueOnce(of([leche, { ...leche, id: 'art-2', articulo: 'Pan' }]));

    const { datos } = await correr('prediccion_stock', { articulo: 'lech' });

    expect(datos).toEqual([
      expect.objectContaining({ articulo: 'Leche', estado: 'comprar-hoy', dias_hasta_minimo: 1, es_preliminar: false }),
    ]);
  });

  it('auditoria_usuarios entrega nombres, filtra por usuario y campo', async () => {
    filasPor['auditoria_usuarios'] = [
      { usuario_id: 1, accion: 'edicion', campo_modificado: 'rol', valor_anterior: 'cajero', valor_nuevo: 'admin', realizado_por: 2, creado_en: 'x' },
      { usuario_id: 2, accion: 'deshabilitacion', campo_modificado: 'activo', valor_anterior: 'true', valor_nuevo: 'false', realizado_por: null, creado_en: 'y' },
    ];
    filasPor['usuarios'] = [{ id: 1, nombre: 'Nelson' }, { id: 2, nombre: 'Maher' }];

    const { datos } = await correr('auditoria_usuarios', { usuario: 'nelson', campo: 'rol' });

    expect(ejecutar.mock.calls[0][0].filtros).toEqual({ campo_modificado: 'eq.rol' });
    expect(datos).toEqual([
      expect.objectContaining({ usuario: 'Nelson', valor_nuevo: 'admin', realizado_por: 'Maher' }),
    ]);
  });

  it('acepta filtros en lista, como los envía a veces el modelo', async () => {
    await correr('consultar', { recurso: 'ventas', filtros: ['anulada.eq.true', 'total.gte.1', 'total.lte.9'] });
    expect(ejecutar.mock.calls[0][0].filtros).toEqual({ anulada: ['eq.true'], total: ['gte.1', 'lte.9'] });
  });

  it('con agregar y tabla embebida conserva el select del modelo', async () => {
    filasPor['ventas'] = [{ usuarios: { nombre: 'Ana' } }];
    const { datos } = await correr('consultar', {
      recurso: 'ventas',
      select: 'usuarios!anulada_por(nombre)',
      agregar: { contar: true, agrupar_por: 'usuarios.nombre' },
    });
    expect(ejecutar.mock.calls[0][0].select).toBe('usuarios!anulada_por(nombre)');
    expect(datos).toEqual([{ 'usuarios.nombre': 'Ana', filas: 1 }]);
  });

  it('no agrupa todo como "sin dato" si falta traer la tabla relacionada', async () => {
    const resultado = await correr('consultar', {
      recurso: 'ventas',
      select: 'anulada_por',
      agregar: { contar: true, agrupar_por: 'usuarios.nombre' },
    });
    expect(resultado.error).toContain('trae esa tabla en select');
    expect(resultado.datos).toBeUndefined();
  });

  it('avisa cuando no hay filas, para que el modelo no concluya que no hay datos por una mayúscula', async () => {
    filasPor['ventas'] = [];
    const simple = await correr('consultar', { recurso: 'ventas', filtros: { medio_pago: 'eq.Efectivo' } });
    expect(simple.datos).toMatchObject({ nota_para_ia: expect.stringContaining('ilike') });
    const agregado = await correr('consultar', { recurso: 'ventas', agregar: { contar: true } });
    expect(agregado.datos).toMatchObject({ filas: 0, nota_para_ia: expect.stringContaining('ilike') });
  });

  it('al consultar ventas excluye las anuladas, salvo que se pidan', async () => {
    await correr('consultar', { recurso: 'ventas', filtros: { medio_pago: 'ilike.*efectivo*' } });
    expect(ejecutar.mock.calls[0][0].filtros).toEqual({ medio_pago: 'ilike.*efectivo*', anulada: 'eq.false' });

    await correr('consultar', { recurso: 'ventas', filtros: { anulada: 'eq.true' } });
    expect(ejecutar.mock.calls[1][0].filtros).toEqual({ anulada: 'eq.true' });
  });

  it('stock_articulo busca por nombre en las existencias', async () => {
    filasPor['v_existencias_articulos'] = [{ nombre: 'COCA COLA', stock_actual: -3, stock_minimo: 0 }];
    const { datos } = await correr('stock_articulo', { nombre: 'coca cola', sucursal_id: 1 });
    expect(ejecutar.mock.calls[0][0].filtros).toEqual({ nombre: 'ilike.*coca cola*', sucursal_id: 'eq.1' });
    expect(datos).toEqual([expect.objectContaining({ stock_actual: -3 })]);
    expect((await correr('stock_articulo')).error).toContain('nombre');
  });

  it('receta_producto une el producto con sus ingredientes y su costo', async () => {
    filasPor['productos'] = [{ id: 373, nombre: 'EMPANADA', activo: true }];
    filasPor['v_costo_producto'] = [{ producto_id: 373, costo_receta: 138.462 }];
    filasPor['recetas'] = [
      { producto_id: 373, cantidad_necesaria: 200, ingredientes: { nombre: 'Harina' }, unidades_medida: { nombre: 'g' } },
    ];

    const { datos } = await correr('receta_producto', { nombre: 'empanada' });

    expect(datos).toEqual([
      {
        producto: 'EMPANADA',
        activo: true,
        costo_receta: 138.462,
        ingredientes: [{ ingrediente: 'Harina', cantidad: 200, unidad: 'g' }],
      },
    ]);
  });

  it('receta_producto no consulta recetas si no encuentra el producto', async () => {
    const { datos } = await correr('receta_producto', { nombre: 'inventado' });
    expect(datos).toEqual([]);
    expect(ejecutar.mock.calls.some(([c]) => c.recurso === 'recetas')).toBe(false);
  });

  it('con agregar pide solo las columnas del cálculo e ignora un orden sobre la métrica', async () => {
    filasPor['facturas_compra'] = [{ proveedor_id: 1 }, { proveedor_id: 1 }, { proveedor_id: 2 }];

    const { datos } = await correr('consultar', {
      recurso: 'facturas_compra',
      orden: 'contar.desc',
      agregar: { contar: true, agrupar_por: 'proveedor_id' },
    });

    expect(ejecutar.mock.calls[0][0]).toMatchObject({ select: 'proveedor_id' });
    expect(ejecutar.mock.calls[0][0].orden).toBeUndefined();
    expect(datos).toEqual([
      { proveedor_id: '1', filas: 2 },
      { proveedor_id: '2', filas: 1 },
    ]);
  });

  it('consultar devuelve filas y, con agregar, calcula sobre todas', async () => {
    filasPor['ventas'] = [{ total: 10 }, { total: 20 }];

    expect((await correr('consultar', { recurso: 'ventas', select: 'total' })).datos).toMatchObject({
      filas: [{ total: 10 }, { total: 20 }],
    });
    expect(ejecutar.mock.calls[0][2]).toBeUndefined();

    const agregado = await correr('consultar', { recurso: 'ventas', select: 'total', agregar: { suma: ['total'] } });
    expect(agregado.datos).toEqual([{ suma_total: 30 }]);
    expect(ejecutar.mock.calls[1][2]).toBe(true);
  });

  it('devuelve como dato un rechazo del filtro y una herramienta desconocida', async () => {
    filasPor['usuarios'] = { error: 'La consulta pide credenciales' };
    expect((await correr('consultar', { recurso: 'usuarios', select: 'password_hash' })).error).toContain('credenciales');
    expect((await correr('borrar_todo')).error).toContain('desconocida');
  });

  it('facturas_ingresadas lee completo el reporte y filtra por emisor', async () => {
    filasPor['rpc/fn_listar_ingresos_factura'] = [
      { folio: 1, proveedor: null, razon_social_emisor: 'PROVEEDOR DE PRUEBA SPA', fecha_emision: '2026-10-05', monto_total: 1000, monto_neto: 810 },
      { folio: 2, proveedor: null, razon_social_emisor: 'DISTRIBUIDORA DE BEBIDAS LTDA', fecha_emision: '2026-10-06', monto_total: 2000, monto_neto: 1620 },
    ];

    const { datos } = await correr('facturas_ingresadas', { emisor: 'DISTRIBUIDORA DE BEBIDAS' });

    expect(ejecutar.mock.calls[0][0]).toEqual({ recurso: 'rpc/fn_listar_ingresos_factura', filtros: { p_limite: '500' } });
    expect(ejecutar.mock.calls[0][2]).toBe(true);
    expect(datos).toMatchObject({
      facturas_encontradas: 1,
      facturas: [{ folio: '2', emisor: 'DISTRIBUIDORA DE BEBIDAS LTDA', monto_total: 2000 }],
    });
  });

  it('facturas_ingresadas no atribuye una factura a otro emisor: sin coincidencias lo dice', async () => {
    filasPor['rpc/fn_listar_ingresos_factura'] = [
      { folio: 1, proveedor: null, razon_social_emisor: 'PROVEEDOR DE PRUEBA SPA', fecha_emision: '2026-10-05' },
    ];

    const { datos } = await correr('facturas_ingresadas', { emisor: 'DISTRIBUIDORA DE BEBIDAS' });

    expect(datos).toEqual({
      facturas_encontradas: 0,
      resultado: 'No hay facturas ingresadas de DISTRIBUIDORA DE BEBIDAS.',
      truncado: false,
    });
  });

  it('facturas_ingresadas rechaza fechas mal escritas y entrega el error de la lectura', async () => {
    expect((await correr('facturas_ingresadas', { desde: '05-10-2026' })).error).toContain('YYYY-MM-DD');
    expect(ejecutar).not.toHaveBeenCalled();

    filasPor['rpc/fn_listar_ingresos_factura'] = { error: 'sin permiso' };
    expect((await correr('facturas_ingresadas')).error).toBe('sin permiso');
  });

  it('no se cae si un servicio falla', async () => {
    cargarDashboard.mockReturnValueOnce(throwError(() => new Error('Sin API')));
    expect((await correr('analisis_dashboard')).error).toBe('Sin API');
  });

  it('cancela una herramienta a los 30 s si la consulta no responde', async () => {
    vi.useFakeTimers();
    try {
      const pendiente = new Subject();
      cargarDashboard.mockReturnValueOnce(pendiente.asObservable());

      const promesa = correr('analisis_dashboard');
      vi.advanceTimersByTime(TIEMPO_LIMITE_CONSULTA_MS);

      expect(await promesa).toMatchObject({
        herramienta: 'analisis_dashboard',
        error: 'La consulta tardó más de 30 segundos y se canceló.',
      });
    } finally {
      vi.useRealTimers();
    }
  });
});
