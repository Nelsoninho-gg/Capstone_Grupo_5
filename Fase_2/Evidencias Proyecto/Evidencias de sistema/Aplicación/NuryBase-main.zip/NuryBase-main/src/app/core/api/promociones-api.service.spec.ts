import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { firstValueFrom } from 'rxjs';
import { environment } from '../../../environments/environment';
import { PromocionesApiService } from './promociones-api.service';

describe('PromocionesApiService', () => {
  let service: PromocionesApiService;
  let http: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()],
    });
    service = TestBed.inject(PromocionesApiService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  it('lists promotions with their branch and products, latest start first', async () => {
    const result = firstValueFrom(service.listar());

    const request = http.expectOne((req) => req.url === `${environment.apiUrl}/promociones`);
    expect(request.request.method).toBe('GET');
    expect(request.request.params.get('order')).toBe('inicio.desc,id.desc');
    const select = request.request.params.get('select') ?? '';
    expect(select).toContain('sucursales:promocion_sucursales(sucursal_id,sucursal:sucursales(nombre))');
    expect(select).toContain('productos:promocion_productos(producto_id,cantidad');
    request.flush([]);

    await expect(result).resolves.toEqual([]);
  });

  it('asks the server which promotions apply now in the sale branch (H5.2 T04)', () => {
    service.listarVigentes(2).subscribe();

    const request = http.expectOne(
      (req) => req.url === `${environment.apiUrl}/rpc/fn_promociones_vigentes`,
    );
    const params = request.request.params;
    expect(request.request.method).toBe('GET');
    expect(params.get('p_sucursal_id')).toBe('2');
    // La hora la decide la base (now()), no el reloj del equipo.
    expect(params.has('p_momento')).toBe(false);
    expect(params.get('select')).toContain('productos:promocion_productos');
    request.flush([]);
  });

  it('saves a promotion with its products in a single call', async () => {
    const result = firstValueFrom(
      service.guardar(null, {
        nombre: 'Sándwich + café',
        tipo: 'monto_fijo',
        valor_descuento: 1000,
        sucursales: [],
        inicio: '2026-11-07T03:00:00.000Z',
        termino: '2026-11-09T03:00:00.000Z',
        productos: [
          { producto_id: 1, cantidad: 1 },
          { producto_id: 2, cantidad: 2 },
        ],
      }),
    );

    const request = http.expectOne(`${environment.apiUrl}/rpc/fn_guardar_promocion`);
    expect(request.request.method).toBe('POST');
    expect(request.request.body).toEqual({
      p_id: null,
      p_nombre: 'Sándwich + café',
      p_tipo: 'monto_fijo',
      p_valor: 1000,
      p_sucursales: null,
      p_inicio: '2026-11-07T03:00:00.000Z',
      p_termino: '2026-11-09T03:00:00.000Z',
      p_productos: [
        { producto_id: 1, cantidad: 1 },
        { producto_id: 2, cantidad: 2 },
      ],
    });
    request.flush(7);

    await expect(result).resolves.toBe(7);
  });

  it('deactivates a promotion by id', () => {
    service.desactivar(4).subscribe();

    const request = http.expectOne((req) => req.url === `${environment.apiUrl}/promociones`);
    expect(request.request.method).toBe('PATCH');
    expect(request.request.params.get('id')).toBe('eq.4');
    expect(request.request.body).toEqual({ activa: false });
    request.flush(null);
  });

  it('sends the chosen branches, or null for all of them', () => {
    const datos = {
      nombre: 'Café',
      tipo: 'porcentaje' as const,
      valor_descuento: 10,
      sucursales: [1, 3],
      inicio: '2026-11-07T03:00:00.000Z',
      termino: '2026-11-09T03:00:00.000Z',
      productos: [{ producto_id: 2, cantidad: 1 }],
    };
    service.guardar(4, datos).subscribe();

    const request = http.expectOne(`${environment.apiUrl}/rpc/fn_guardar_promocion`);
    expect(request.request.body).toEqual(
      expect.objectContaining({ p_id: 4, p_sucursales: [1, 3] }),
    );
    request.flush(4);
  });
});
