import { NgTemplateOutlet } from '@angular/common';
import {
  Component,
  ElementRef,
  HostListener,
  computed,
  inject,
  input,
  model,
  signal,
} from '@angular/core';
import { formatoClp, formatoNumero } from '../../models/formato';
import { FiltroTurno, TurnoReporte } from '../../models/reportes.model';
import { etiquetaTurno, horarioTurno } from '../../models/turno.model';

/**
 * Desplegable de turnos de la pestaña Cajeros (H4.3 T03), con el mismo diseño que los filtros
 * de sucursales y período: todo el período, un turno real (cajero, sucursal y horario) o solo
 * las ventas sin turno registrado.
 */
@Component({
  selector: 'app-selector-turno',
  imports: [NgTemplateOutlet],
  templateUrl: './selector-turno.html',
  styleUrl: './selector-turno.css',
})
export class SelectorTurno {
  private readonly elemento = inject<ElementRef<HTMLElement>>(ElementRef);

  /** Turnos del período; la fila con turnoId null junta las ventas sin turno. */
  readonly turnos = input.required<TurnoReporte[]>();
  readonly turno = model<FiltroTurno>(null);

  protected readonly abierto = signal(false);
  protected readonly reales = computed(() => this.turnos().filter((t) => t.turnoId !== null));
  protected readonly sinTurno = computed(
    () => this.turnos().find((t) => t.turnoId === null) ?? null,
  );

  protected readonly texto = computed(() => {
    const elegido = this.turno();
    if (elegido === null) return 'Todos los turnos';
    if (elegido === 'sin-turno') return 'Sin turno registrado';
    const turno = this.reales().find((t) => t.turnoId === elegido);
    return turno ? etiquetaTurno(turno) : 'Turno elegido';
  });

  protected alternar(): void {
    this.abierto.update((abierto) => !abierto);
  }

  protected elegir(turno: FiltroTurno): void {
    this.turno.set(turno);
    this.abierto.set(false);
  }

  @HostListener('document:click', ['$event'])
  protected cerrarAlHacerClicFuera(event: MouseEvent): void {
    if (this.abierto() && !this.elemento.nativeElement.contains(event.target as Node)) {
      this.abierto.set(false);
    }
  }

  @HostListener('document:keydown.escape')
  protected cerrarConEscape(): void {
    this.abierto.set(false);
  }

  /** "Providencia · 4 ventas · $12.000" (y las anuladas, si hubo). */
  protected detalle(turno: TurnoReporte): string {
    const partes = [
      `${formatoNumero.format(turno.ventas)} ${turno.ventas === 1 ? 'venta' : 'ventas'}`,
      formatoClp.format(turno.total),
    ];
    if (turno.sucursal) partes.unshift(turno.sucursal);
    if (turno.anuladas) {
      partes.push(
        `${formatoNumero.format(turno.anuladas)} ${turno.anuladas === 1 ? 'anulada' : 'anuladas'}`,
      );
    }
    return partes.join(' · ');
  }

  protected readonly horario = horarioTurno;
}
