import { HttpErrorResponse } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { of, throwError } from 'rxjs';
import { ProductosApiService } from '../../../../core/api/productos-api.service';
import { PromocionApi, PromocionesApiService } from '../../../../core/api/promociones-api.service';
import { SucursalesApiService } from '../../../../core/api/sucursales-api.service';
import { Promociones } from './promociones';

describe('Promociones', () => {
  let fixture: ComponentFixture<Promociones>;
  const DIA = 24 * 60 * 60 * 1000;

  const promocion = (
    id: number,
    nombre: string,
    desdeDias: number,
    hastaDias: number,
    extra: Partial<PromocionApi> = {},
  ): PromocionApi => ({
    id,
    nombre,
    tipo: 'monto_fijo',
    valor_descuento: '1000.00',
    inicio: new Date(Date.now() + desdeDias * DIA).toISOString(),
    termino: new Date(Date.now() + hastaDias * DIA).toISOString(),
    activa: true,
    creado_en: '2026-11-01T12:00:00',
    sucursales: [{ sucursal_id: 1, sucursal: { nombre: 'Nury Providencia' } }],
    productos: [
      { producto_id: 1, cantidad: 1, producto: { nombre: 'Sándwich' } },
      { producto_id: 2, cantidad: 1, producto: { nombre: 'Café' } },
    ],
    ...extra,
  });

  let listar = vi.fn();
  let guardarApi = vi.fn();
  let desactivarApi = vi.fn();

  async function crear(): Promise<void> {
    await TestBed.configureTestingModule({
      imports: [Promociones],
      providers: [
        provideRouter([]),
        { provide: PromocionesApiService, useValue: { listar, guardar: guardarApi, desactivar: desactivarApi } },
        {
          provide: SucursalesApiService,
          useValue: {
            listarActivas: () =>
              of([
                { id: 1, nombre: 'Nury Providencia' },
                { id: 2, nombre: 'Nury Ñuñoa' },
              ]),
          },
        },
        {
          provide: ProductosApiService,
          useValue: {
            listar: () =>
              of([
                { id: 1, nombre: 'Sándwich' },
                { id: 2, nombre: 'Café' },
                { id: 3, nombre: 'Jugo' },
              ]),
          },
        },
      ],
    }).compileComponents();
    fixture = TestBed.createComponent(Promociones);
    fixture.detectChanges();
    await fixture.whenStable();
  }

  const elemento = (): HTMLElement => fixture.nativeElement;
  const boton = (texto: string): HTMLButtonElement =>
    [...elemento().querySelectorAll('button')].find((b) => b.textContent?.trim().includes(texto))!;
  const texto = (selector: string): string =>
    (elemento().querySelector(selector)?.textContent ?? '').replace(/\s+/g, ' ').trim();
  function escribir(selector: string, valor: string): void {
    const control = elemento().querySelector(selector) as HTMLInputElement | HTMLSelectElement;
    control.value = valor;
    control.dispatchEvent(new Event(control.tagName === 'SELECT' ? 'change' : 'input'));
    control.dispatchEvent(new Event('blur'));
    fixture.detectChanges();
  }
  function agregar(nombre: string): void {
    const input = elemento().querySelector<HTMLInputElement>('#buscar-producto-promocion')!;
    input.dispatchEvent(new Event('focus'));
    input.value = nombre;
    input.dispatchEvent(new Event('input'));
    fixture.detectChanges();
    const opcion = [...elemento().querySelectorAll('[role="option"]')].find((o) =>
      o.textContent?.includes(nombre),
    )!;
    opcion.dispatchEvent(new MouseEvent('mousedown'));
    fixture.detectChanges();
  }
  function marcar(selector: string): void {
    elemento().querySelector<HTMLInputElement>(selector)!.click();
    fixture.detectChanges();
  }
  function casillaSucursal(nombre: string): HTMLInputElement {
    const fila = [...elemento().querySelectorAll('.branch-options label')].find((label) =>
      label.textContent?.includes(nombre),
    )!;
    return fila.querySelector('input')!;
  }
  function marcarSucursal(nombre: string): void {
    casillaSucursal(nombre).click();
    fixture.detectChanges();
  }
  function guardar(): void {
    elemento().querySelector('form')!.dispatchEvent(new Event('submit'));
    fixture.detectChanges();
  }
  function errores(): string[] {
    return [...elemento().querySelectorAll('.promo-modal small')].map((s) =>
      (s.textContent ?? '').trim(),
    );
  }

  beforeEach(() => {
    listar = vi.fn(() =>
      of([
        promocion(1, 'Fin de semana', 2, 4),
        promocion(2, 'Happy hour', -1, 1, {
          tipo: 'porcentaje',
          valor_descuento: '20',
          sucursales: [],
        }),
        promocion(3, 'Octubre', -30, -10),
        promocion(4, 'Apagada', -1, 3, { activa: false }),
      ]),
    );
    guardarApi = vi.fn(() => of(5));
    desactivarApi = vi.fn(() => of(undefined));
  });

  it('lists each promotion with its state, window, branch and products', async () => {
    await crear();

    const filas = [...elemento().querySelectorAll('.promotions-table tbody tr')];
    expect(filas).toHaveLength(4);
    const estados = filas.map((fila) => fila.querySelector('.promo-state')?.textContent?.trim());
    expect(estados).toEqual(['Programada', 'Vigente', 'Terminada', 'Desactivada']);
    expect(filas[0].textContent).toContain('1 × Sándwich + 1 × Café');
    expect(filas[0].textContent).toContain('Nury Providencia');
    expect(filas[0].textContent).toContain('Desde');
    expect(filas[0].textContent).toContain('Hasta');
    expect(filas[1].textContent).toContain('20 % de descuento');
    expect(filas[1].textContent).toContain('Todas las sucursales');
    expect(texto('.state-summary')).toContain('1 vigentes');
    expect(texto('.state-summary')).toContain('1 programadas');
  });

  it('offers to deactivate only scheduled or current promotions', async () => {
    await crear();

    const filas = [...elemento().querySelectorAll('.promotions-table tbody tr')];
    const puede = filas.map((fila) => !!fila.querySelector('.deactivate-button'));
    expect(puede).toEqual([true, true, false, false]);
  });

  it('asks for confirmation and deactivates the promotion', async () => {
    await crear();
    boton('Desactivar').click();
    fixture.detectChanges();

    expect(texto('[role="alertdialog"]')).toContain('¿Quieres desactivar Fin de semana');
    const confirmar = [...elemento().querySelectorAll('.confirm-modal .danger-button')][0] as HTMLButtonElement;
    confirmar.click();
    fixture.detectChanges();

    expect(desactivarApi).toHaveBeenCalledWith(1);
    expect(elemento().querySelector('[role="alertdialog"]')).toBeNull();
    expect(texto('.success-feedback')).toContain('La promoción «Fin de semana» se desactivó.');
    expect(listar).toHaveBeenCalledTimes(2);
  });

  it('keeps the confirmation open with the error when deactivating fails', async () => {
    desactivarApi = vi.fn(() => throwError(() => new HttpErrorResponse({ status: 0 })));
    await crear();
    boton('Desactivar').click();
    fixture.detectChanges();
    (elemento().querySelector('.confirm-modal .danger-button') as HTMLButtonElement).click();
    fixture.detectChanges();

    expect(elemento().querySelector('[role="alertdialog"]')).not.toBeNull();
    expect(texto('.confirm-modal [role="alert"]')).toContain('No pudimos desactivar la promoción');
    expect(listar).toHaveBeenCalledTimes(1);
  });

  it('shows the field errors when saving an empty form', async () => {
    await crear();
    boton('Crear promoción').click();
    fixture.detectChanges();
    guardar();

    // Sin combo, el nombre sale del producto: el error es el de productos.
    expect(errores()).toEqual([
      'Ingresa el valor del descuento.',
      'Indica la fecha y hora de inicio.',
      'Indica la fecha y hora de término.',
      'Agrega al menos un producto.',
    ]);
    expect(elemento().querySelector('.promo-modal')).not.toBeNull();
  });

  it('rejects an end before the start and a percentage above 100', async () => {
    await crear();
    boton('Crear promoción').click();
    fixture.detectChanges();
    escribir('input[formControlName="nombre"]', '20% café');
    escribir('input[formControlName="valor"]', '120');
    escribir('input[formControlName="inicio"]', '2026-11-08T00:00');
    escribir('input[formControlName="termino"]', '2026-11-07T00:00');
    agregar('Café');
    guardar();

    expect(errores()).toEqual([
      'El porcentaje no puede ser mayor a 100.',
      'El término debe ser posterior al inicio.',
    ]);
  });

  it('allows a fixed amount above 100 and rejects zero', async () => {
    await crear();
    boton('Crear promoción').click();
    fixture.detectChanges();
    escribir('select[formControlName="tipo"]', 'monto_fijo');
    escribir('input[formControlName="valor"]', '0');
    guardar();
    expect(errores()).toContain('El descuento debe ser mayor que 0.');

    escribir('input[formControlName="valor"]', '1500');
    expect(errores()).not.toContain('El descuento debe ser mayor que 0.');
    expect(errores()).not.toContain('El porcentaje no puede ser mayor a 100.');
  });

  it('builds a combo with quantities and saves it with its products', async () => {
    await crear();
    boton('Crear promoción').click();
    fixture.detectChanges();
    escribir('input[formControlName="nombre"]', 'Sándwich + café');
    escribir('select[formControlName="tipo"]', 'monto_fijo');
    escribir('input[formControlName="valor"]', '1000');
    marcar('input[formControlName="todasLasSucursales"]');
    marcarSucursal('Nury Ñuñoa');
    escribir('input[formControlName="inicio"]', '2026-11-07T00:00');
    escribir('input[formControlName="termino"]', '2026-11-09T00:00');
    marcar('#promo-es-combo');
    agregar('Sándwich');
    agregar('Café');
    (elemento().querySelectorAll('.promo-lines button[aria-label="Aumentar"]')[1] as HTMLButtonElement).click();
    fixture.detectChanges();

    expect([...elemento().querySelectorAll('.promo-lines .qty')].map((q) => q.textContent?.trim())).toEqual([
      '1',
      '2',
    ]);
    // Un producto ya elegido no vuelve a ofrecerse.
    const input = elemento().querySelector<HTMLInputElement>('#buscar-producto-promocion')!;
    input.dispatchEvent(new Event('focus'));
    fixture.detectChanges();
    expect([...elemento().querySelectorAll('[role="option"]')].map((o) => o.textContent?.trim())).toEqual([
      'Jugo',
    ]);

    guardar();
    expect(errores()).toEqual([]);
    expect(elemento().querySelector('.promo-modal')).toBeNull();
    expect(guardarApi).toHaveBeenCalledWith(null, {
      nombre: 'Sándwich + café',
      tipo: 'monto_fijo',
      valor_descuento: 1000,
      sucursales: [2],
      // Hora de Chile (verano, UTC−3), sea cual sea la zona del equipo.
      inicio: '2026-11-07T03:00:00.000Z',
      termino: '2026-11-09T03:00:00.000Z',
      productos: [
        { producto_id: 1, cantidad: 1 },
        { producto_id: 2, cantidad: 2 },
      ],
    });
    expect(texto('.success-feedback')).toContain('La promoción «Sándwich + café» se guardó.');
    expect(listar).toHaveBeenCalledTimes(2);
  });

  it('keeps a single product when it is not a combo, and asks a combo for more than one', async () => {
    await crear();
    boton('Crear promoción').click();
    fixture.detectChanges();
    const nombre = elemento().querySelector<HTMLInputElement>('input[formControlName="nombre"]')!;
    escribir('input[formControlName="valor"]', '20');
    escribir('input[formControlName="inicio"]', '2026-11-07T00:00');
    escribir('input[formControlName="termino"]', '2026-11-09T00:00');
    agregar('Sándwich');
    agregar('Café');

    expect(texto('.promo-lines')).toBe('Café ×');
    expect(elemento().querySelector('.promo-lines .stepper')).toBeNull();
    // Sin combo, el nombre es el del producto y queda bloqueado.
    expect([nombre.value, nombre.disabled]).toEqual(['Café', true]);

    marcar('#promo-es-combo');
    expect(nombre.disabled).toBe(false);
    guardar();
    expect(errores()).toEqual(['Un combo lleva más de un producto: agrega otro o sube las unidades.']);

    escribir('input[formControlName="nombre"]', 'Otro nombre');
    marcar('#promo-es-combo');
    expect([nombre.value, nombre.disabled]).toEqual(['Café', true]);
    guardar();
    expect(guardarApi).toHaveBeenCalledWith(
      null,
      expect.objectContaining({ nombre: 'Café', productos: [{ producto_id: 2, cantidad: 1 }] }),
    );
  });

  it('does not save while the form has errors', async () => {
    await crear();
    boton('Crear promoción').click();
    fixture.detectChanges();
    guardar();

    expect(guardarApi).not.toHaveBeenCalled();
  });

  it('saves the changes of an edited promotion for all branches', async () => {
    await crear();
    (elemento().querySelector('button[aria-label="Editar Happy hour"]') as HTMLButtonElement).click();
    fixture.detectChanges();
    escribir('input[formControlName="valor"]', '25');
    guardar();

    expect(guardarApi).toHaveBeenCalledWith(
      2,
      expect.objectContaining({ tipo: 'porcentaje', valor_descuento: 25, sucursales: [] }),
    );
    expect(texto('.success-feedback')).toContain('La promoción «Happy hour» se actualizó.');
  });

  it('shows the reason from the database and keeps the form open when saving fails', async () => {
    guardarApi = vi.fn(() =>
      throwError(
        () =>
          new HttpErrorResponse({
            status: 400,
            error: { message: 'Estos productos no existen o están inactivos: Café.' },
          }),
      ),
    );
    await crear();
    (elemento().querySelector('button[aria-label="Editar Happy hour"]') as HTMLButtonElement).click();
    fixture.detectChanges();
    guardar();

    expect(elemento().querySelector('.promo-modal')).not.toBeNull();
    expect(texto('.promo-modal [role="alert"]')).toBe(
      'Estos productos no existen o están inactivos: Café.',
    );
    expect(listar).toHaveBeenCalledTimes(1);
  });

  it('opens the edit form with the promotion data', async () => {
    await crear();
    (elemento().querySelector('button[aria-label="Editar Happy hour"]') as HTMLButtonElement).click();
    fixture.detectChanges();

    expect(texto('#promo-form-title')).toBe('Editar promoción');
    expect(elemento().querySelector<HTMLInputElement>('input[formControlName="nombre"]')!.value).toBe(
      'Happy hour',
    );
    expect(elemento().querySelector<HTMLSelectElement>('select[formControlName="tipo"]')!.value).toBe(
      'porcentaje',
    );
    expect(
      elemento().querySelector<HTMLInputElement>('input[formControlName="todasLasSucursales"]')!.checked,
    ).toBe(true);
    expect(elemento().querySelectorAll('.promo-lines li')).toHaveLength(2);
  });

  it('applies to all branches by default, with each branch locked and checked', async () => {
    await crear();
    boton('Crear promoción').click();
    fixture.detectChanges();

    const todas = elemento().querySelector<HTMLInputElement>(
      'input[formControlName="todasLasSucursales"]',
    )!;
    expect(todas.checked).toBe(true);
    expect([casillaSucursal('Nury Providencia'), casillaSucursal('Nury Ñuñoa')].map((c) => [c.checked, c.disabled])).toEqual([
      [true, true],
      [true, true],
    ]);
    expect(texto('.branch-field .help-text')).toBe('Rige también en las sucursales que se abran después.');
  });

  it('asks for at least one branch and saves several chosen branches', async () => {
    await crear();
    boton('Crear promoción').click();
    fixture.detectChanges();
    escribir('input[formControlName="valor"]', '15');
    escribir('input[formControlName="inicio"]', '2026-11-07T00:00');
    escribir('input[formControlName="termino"]', '2026-11-09T00:00');
    agregar('Café');
    marcar('input[formControlName="todasLasSucursales"]');
    guardar();

    expect(errores()).toEqual(['Elige al menos una sucursal.']);
    expect(guardarApi).not.toHaveBeenCalled();
    expect(texto('.branch-button')).toBe('Elige las sucursales');

    marcarSucursal('Nury Ñuñoa');
    expect(texto('.branch-button')).toBe('Nury Ñuñoa');
    marcarSucursal('Nury Providencia');
    expect(texto('.branch-button')).toBe('2 sucursales');
    expect(errores()).toEqual([]);
    expect(texto('.branch-field .help-text')).toBe('Rige solo en las sucursales marcadas.');
    guardar();

    expect(guardarApi).toHaveBeenCalledWith(
      null,
      expect.objectContaining({ nombre: 'Café', sucursales: [1, 2] }),
    );
  });

  it('opens a branch promotion with only its branches checked and lists them', async () => {
    listar = vi.fn(() =>
      of([
        promocion(7, 'Dos locales', -1, 2, {
          sucursales: [
            { sucursal_id: 2, sucursal: { nombre: 'Nury Ñuñoa' } },
            { sucursal_id: 1, sucursal: { nombre: 'Nury Providencia' } },
          ],
        }),
        promocion(8, 'Solo Ñuñoa', -1, 2, {
          sucursales: [{ sucursal_id: 2, sucursal: { nombre: 'Nury Ñuñoa' } }],
        }),
      ]),
    );
    await crear();

    const filas = [...elemento().querySelectorAll('.promotions-table tbody tr')];
    expect(filas[0].textContent).toContain('Nury Ñuñoa, Nury Providencia');

    (elemento().querySelector('button[aria-label="Editar Solo Ñuñoa"]') as HTMLButtonElement).click();
    fixture.detectChanges();
    expect(
      elemento().querySelector<HTMLInputElement>('input[formControlName="todasLasSucursales"]')!.checked,
    ).toBe(false);
    expect(casillaSucursal('Nury Providencia').checked).toBe(false);
    expect(casillaSucursal('Nury Ñuñoa').checked).toBe(true);

    marcarSucursal('Nury Ñuñoa');
    marcarSucursal('Nury Providencia');
    guardar();
    expect(guardarApi).toHaveBeenCalledWith(8, expect.objectContaining({ sucursales: [1] }));
  });

  it('shows an error with retry when loading fails', async () => {
    listar = vi.fn(() => throwError(() => new Error('sin red')));
    await crear();
    expect(texto('.error-row')).toContain('No pudimos cargar las promociones');

    listar.mockReturnValue(of([]));
    boton('Reintentar').click();
    fixture.detectChanges();
    expect(texto('.empty-row')).toContain('No hay promociones');
  });
});
