import { signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { Observable, Subject, firstValueFrom, of, throwError } from 'rxjs';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import {
  OrquestadorIaService,
  RespuestaOrquestadorIA,
  SinProveedoresIAError,
} from '../../../core/ia/orquestador-ia.service';
import { MensajesIA } from '../../../core/ia/proveedores-ia.config';
import { AuthService } from '../../auth/services/auth.service';
import { ProyeccionCierre, TIEMPO_LIMITE_CONSULTA_MS, calcularMadurezDashboard } from '../models/dashboard.model';
import {
  AsistenteDashboardService,
  ContextoEjecutivoAsistente,
  INSTRUCCION_RECOMENDACION,
  interpretarSalidaAsistente,
  pantallasInexistentes,
  pideRecomendacion,
} from './asistente-dashboard.service';
import { montosEnPesos } from '../models/herramientas-asistente.model';
import { ConsultasAsistenteService } from './consultas-asistente.service';
import { HerramientasAsistenteService } from './herramientas-asistente.service';

describe('AsistenteDashboardService (H4.5 T11)', () => {
  let sesion = '';
  let servicio: AsistenteDashboardService;
  let orquestadorRespuesta: () => Observable<RespuestaOrquestadorIA>;
  let ultimaLlamadaMensajes: MensajesIA | null = null;
  let llamadasIa = 0;
  const usuario = signal<{ id: number } | null>({ id: 1 });

  const mockContexto: ContextoEjecutivoAsistente = {
    sucursalId: 1,
    sucursales: [{ id: 1, nombre: 'Nury Providencia' }],
    sucursalNombre: 'Nury Providencia',
    periodo: '30d',
    ventasTotalesClp: 19450000,
    gananciaLimpiaClp: 6320000,
    demandaPorDiaSemana: [],
    demandaHoraria: [
      { franja: '08:00', etiqueta: 'Entrada clases', ticketsPromedio: 61, intensidadPct: 94, esHoraPunta: true },
      { franja: '13:00', etiqueta: 'Almuerzo', ticketsPromedio: 53, intensidadPct: 82, esHoraPunta: true },
    ],
    madurez: calcularMadurezDashboard(14), // Faltan 14 días para 28
    catalogo: [
      { nombre: 'Capuccino', tipo: 'producto', categoria: 'Cafetería', activo: true },
      { nombre: 'Frappé Dulce de Leche', tipo: 'producto', categoria: 'Bebidas', activo: false },
    ],
    insumosUrgentes: [
      { articulo: 'Harina Panadera 000', stock: 22, minimo: 25, sugerido: 8 },
      { articulo: 'Leche Entera', stock: 18, minimo: 20, sugerido: 5 },
    ],
    productosMasVendidos: [
      { producto: 'Capuccino', unidades: 40, ventasClp: 80000, gananciaLimpiaClp: 30000 },
      { producto: 'Medialuna', unidades: 20, ventasClp: 20000, gananciaLimpiaClp: null },
    ],
    lineasNegocio: [],
    datosDisponibles: true,
  };

  const fakeOrquestador = {
    solicitar: (mensajes: MensajesIA) => {
      ultimaLlamadaMensajes = mensajes;
      llamadasIa++;
      return orquestadorRespuesta();
    },
  };

  const esquema = vi.fn(() => of(new Map([['productos', ['id', 'nombre', 'precio_venta']]])));
  const describirEsquema = () => 'productos(id, nombre, precio_venta)';
  const primeraVenta = vi.fn(() => of<string | null>('2026-09-01'));
  const nombresReales = vi.fn(() => of({ personas: ['Ana Díaz'], proveedores: ['Lacteos Sur SpA'] }));
  const ejecutarHerramienta = vi.fn((llamada: { nombre: string; parametros?: Record<string, unknown> }) =>
    of({ herramienta: llamada.nombre, parametros: llamada.parametros, datos: { margen_por_unidad: 720, margen_porcentaje: 24 } }),
  );

  function respuestaIa(contenido: string): RespuestaOrquestadorIA {
    return { proveedorId: 'gemini', modelo: 'gemini-flash-lite', contenido, intentos: [] };
  }

  function salidas(...lista: string[]): void {
    orquestadorRespuesta = () => of(respuestaIa(lista.shift()!));
  }

  beforeEach(() => {
    ultimaLlamadaMensajes = null;
    llamadasIa = 0;
    usuario.set({ id: 1 });
    sesion = 'token-de-la-sesion-1';
    sessionStorage.clear();
    esquema.mockClear();
    nombresReales.mockClear();
    ejecutarHerramienta.mockClear();
    vi.spyOn(console, 'warn').mockImplementation(() => {});
    TestBed.configureTestingModule({
      providers: [
        AsistenteDashboardService,
        { provide: OrquestadorIaService, useValue: fakeOrquestador },
        { provide: ConsultasAsistenteService, useValue: { esquema, describirEsquema, nombresReales, primeraVenta } },
        { provide: HerramientasAsistenteService, useValue: { ejecutar: ejecutarHerramienta } },
        { provide: AuthService, useValue: { currentUser: usuario, getToken: () => (usuario() ? sesion : null) } },
      ],
    });

    servicio = TestBed.inject(AsistenteDashboardService);
  });

  describe('Nombres ocultos para la IA', () => {
    it('no envía nombres reales a la IA y muestra al usuario los reales', async () => {
      ejecutarHerramienta.mockImplementationOnce((llamada) =>
        of({
          herramienta: llamada.nombre,
          parametros: llamada.parametros,
          datos: [{ cajero: 'Ana Díaz', proveedor: 'Lacteos Sur SpA', total: 1500 }],
        }) as never,
      );
      salidas(
        '{"herramientas":[{"nombre":"ranking_cajeros"}]}',
        '{"respuesta":"PERSONA_1 vendió $1.500 con PROVEEDOR_2."}',
      );

      const res = await firstValueFrom(
        servicio.consultar('¿Cuánto vendió Ana Díaz?', mockContexto, [
          { autor: 'asistente', texto: 'Antes hablamos de Lacteos Sur SpA', datosCalculados: [] },
        ]),
      );

      expect(ultimaLlamadaMensajes!.usuario).not.toMatch(/Ana|Díaz|Lacteos/);
      expect(ultimaLlamadaMensajes!.usuario).toContain('"cajero":"PERSONA_1"');
      expect(ultimaLlamadaMensajes!.sistema).toContain('PERSONA_3 o PROVEEDOR_5');
      expect(res.origen).toBe('ia');
      expect(res.texto).toBe('Ana Díaz vendió $1.500 con Lacteos Sur SpA.');
      expect(JSON.stringify(res.datosCalculados)).toContain('Ana Díaz');
    });

    it('la herramienta recibe el nombre real aunque el modelo use el seudónimo', async () => {
      salidas(
        '{"herramientas":[{"nombre":"auditoria_usuarios","parametros":{"usuario":"PERSONA_1"}}]}',
        '{"respuesta":"Listo"}',
      );

      await firstValueFrom(servicio.consultar('Cambios de esa persona', mockContexto));

      expect(ejecutarHerramienta.mock.calls[0][0].parametros).toEqual({ usuario: 'Ana Díaz' });
      expect(ultimaLlamadaMensajes!.usuario).not.toContain('Ana Díaz');
    });

    it('el emisor llega a la herramienta como nombre real, completo o parcial', async () => {
      nombresReales.mockImplementation(() =>
        of({ personas: [], proveedores: ['DISTRIBUIDORA DE BEBIDAS LTDA', 'PROVEEDOR DE PRUEBA SPA'] }),
      );
      try {
        salidas(
          '{"herramientas":[{"nombre":"facturas_ingresadas","parametros":{"emisor":"PROVEEDOR_1"}}]}',
          '{"respuesta":"Listo"}',
          '{"herramientas":[{"nombre":"facturas_ingresadas","parametros":{"emisor":"DISTRIBUIDORA DE BEBIDAS"}}]}',
          '{"respuesta":"Listo"}',
        );

        await firstValueFrom(servicio.consultar('Facturas de DISTRIBUIDORA DE BEBIDAS LTDA', mockContexto));
        expect(ultimaLlamadaMensajes!.usuario).not.toContain('DISTRIBUIDORA');
        expect(ejecutarHerramienta.mock.calls[0][0].parametros).toEqual({ emisor: 'DISTRIBUIDORA DE BEBIDAS LTDA' });

        await firstValueFrom(servicio.consultar('Facturas de DISTRIBUIDORA DE BEBIDAS', mockContexto));
        expect(ejecutarHerramienta.mock.calls[1][0].parametros).toEqual({ emisor: 'DISTRIBUIDORA DE BEBIDAS' });
      } finally {
        nombresReales.mockImplementation(() => of({ personas: ['Ana Díaz'], proveedores: ['Lacteos Sur SpA'] }));
      }
    });

    it('un seudónimo que no existe no llega al usuario: pide corregir', async () => {
      salidas(
        '{"herramientas":[{"nombre":"ranking_cajeros"}]}',
        '{"respuesta":"Lidera PERSONA_9."}',
        '{"respuesta":"Lidera PERSONA_1."}',
      );

      const res = await firstValueFrom(servicio.consultar('¿Quién vendió más?', mockContexto));

      expect(ultimaLlamadaMensajes!.usuario).toContain('PERSONA_9');
      expect(res.texto).toBe('Lidera Ana Díaz.');
    });

    it('si la IA insiste en un nombre inventado sin datos, no dice que falló la conexión', async () => {
      salidas('{"respuesta":"Lidera Rodrigo Valenzuela."}', '{"respuesta":"Lidera Rodrigo Valenzuela."}');

      const res = await firstValueFrom(servicio.consultar('¿Quién vendió más?', mockContexto));

      expect(res.origen).toBe('sin-verificar');
      expect(res.texto).toContain('no pude comprobar');
      expect(res.texto).not.toMatch(/conectar|Rodrigo/);
    });

    it('si no puede leer los nombres, no consulta a la IA', async () => {
      nombresReales.mockImplementationOnce(() => throwError(() => new Error('sin permiso')));

      const res = await firstValueFrom(servicio.consultar('cuanto se ha vendido', mockContexto));

      expect(llamadasIa).toBe(0);
      expect(res.origen).toBe('respaldo-local');
    });
  });

  describe('La IA interpreta y los algoritmos calculan', () => {
    it('prohíbe calcular y entrega herramientas, esquema y fecha, con la pantalla solo como referencia', async () => {
      salidas('{"respuesta":"Listo"}');

      const res = await firstValueFrom(servicio.consultar('¿Cómo vamos este mes?', mockContexto));
      expect(res.texto).toBe('Listo');
      expect(res.origen).toBe('ia');

      const sistema = ultimaLlamadaMensajes!.sistema;
      expect(sistema).toContain('Tú no calculas');
      expect(sistema).toContain('stock negativo está permitido');
      expect(sistema).toContain('margen_producto');
      expect(sistema).toContain('productos(id, nombre, precio_venta)');
      expect(sistema).toContain('1: Nury Providencia');
      expect(sistema).not.toContain('undefined');
      // Los montos del dashboard ya no acotan lo que sabe el modelo.
      expect(sistema).not.toContain('$19.450.000');
      expect(ultimaLlamadaMensajes!.usuario).toContain('¿Cómo vamos este mes?');
    });

    it('indica desde cuándo hay ventas y, sin ese dato, no lo menciona', async () => {
      salidas('{"respuesta":"Listo"}', '{"respuesta":"Listo"}');

      await firstValueFrom(servicio.consultar('Hola', mockContexto));
      expect(ultimaLlamadaMensajes!.sistema).toContain('ventas registradas desde 2026-09-01');

      primeraVenta.mockImplementationOnce(() => of(null));
      await firstValueFrom(servicio.consultar('Hola', mockContexto));
      expect(ultimaLlamadaMensajes!.sistema).not.toContain('ventas registradas desde');
    });

    it('entrega los períodos como hechos ya calculados y no pide comparar fechas', async () => {
      vi.useFakeTimers({ toFake: ['Date'] });
      vi.setSystemTime(new Date('2026-11-06T15:00:00Z'));
      try {
        primeraVenta.mockImplementationOnce(() => of('2026-09-05'));
        salidas('{"respuesta":"Listo"}', '{"respuesta":"Listo"}');

        await firstValueFrom(servicio.consultar('Hola', mockContexto));
        const sistema = ultimaLlamadaMensajes!.sistema;
        expect(sistema).toContain(
          'Fiestas Patrias: 2026-09-18 a 2026-09-19, CON registros: pide los datos de esas fechas con una herramienta',
        );
        expect(sistema).toContain('Navidad: 2025-12-25, SIN registros');
        expect(sistema).toContain('Vacaciones de verano: 2026-01-01 a 2026-02-28, SIN registros');
        expect(sistema).toContain('Vacaciones de invierno: 2026-07-01 a 2026-07-31, SIN registros');
        expect(sistema).toContain('idea general y no un dato de su negocio');
        expect(sistema).toContain('En una idea general no uses números');
        expect(sistema).not.toContain('compáralo');
        expect(sistema).not.toContain('Navidad: 25 de diciembre');

        primeraVenta.mockImplementationOnce(() => of(null));
        await firstValueFrom(servicio.consultar('Hola', mockContexto));
        expect(ultimaLlamadaMensajes!.sistema).not.toMatch(/Fiestas Patrias|CON registros|SIN registros/);
        expect(ultimaLlamadaMensajes!.sistema).toContain('En una idea general no uses números');
      } finally {
        vi.useRealTimers();
      }
    });

    it('acepta una lista de días en la respuesta de la IA', async () => {
      salidas(
        '{"herramientas":[{"nombre":"margen_producto"}]}',
        '{"respuesta":"El 18 y 19 de septiembre te dejó $720."}',
      );

      const res = await firstValueFrom(servicio.consultar('¿Fiestas Patrias?', mockContexto));

      expect(res.origen).toBe('ia');
      expect(llamadasIa).toBe(2);
    });

    it('rechaza llamar neto a un monto de venta y explica que incluye IVA', async () => {
      salidas(
        '{"herramientas":[{"nombre":"margen_producto"}]}',
        '{"respuesta":"Tus ventas netas fueron $720."}',
        '{"respuesta":"Tus ventas fueron $720."}',
      );

      const res = await firstValueFrom(servicio.consultar('¿Cuánto vendí?', mockContexto));

      expect(llamadasIa).toBe(3);
      expect(ultimaLlamadaMensajes!.usuario).toContain('"ventas netas"');
      expect(ultimaLlamadaMensajes!.usuario).toContain('incluyen IVA');
      expect(ultimaLlamadaMensajes!.usuario).not.toContain('no salen de ninguna herramienta');
      expect(res.texto).toBe('Tus ventas fueron $720.');
      expect(res.origen).toBe('ia');
    });

    it('si además hay una cifra sin respaldo, la corrección explica ambas cosas', async () => {
      salidas(
        '{"herramientas":[{"nombre":"margen_producto"}]}',
        '{"respuesta":"Tus ingresos netos fueron $999."}',
        '{"respuesta":"Te deja $720."}',
      );

      await firstValueFrom(servicio.consultar('¿Cuánto vendí?', mockContexto));

      expect(ultimaLlamadaMensajes!.usuario).toContain('no salen de ninguna herramienta: $999');
      expect(ultimaLlamadaMensajes!.usuario).toContain('"ingresos netos"');
    });

    it('muestra los datos calculados si insiste en llamar neta a una venta', async () => {
      salidas(
        '{"herramientas":[{"nombre":"margen_producto"}]}',
        '{"respuesta":"La recaudación neta fue $720."}',
        '{"respuesta":"La venta neta fue $720."}',
      );

      const res = await firstValueFrom(servicio.consultar('¿Cuánto vendí?', mockContexto));

      expect(res.origen).toBe('algoritmo');
      expect(res.texto).not.toContain('neta');
    });

    it('permite el monto neto de una factura', async () => {
      salidas(
        '{"herramientas":[{"nombre":"margen_producto"}]}',
        '{"respuesta":"La factura tiene un monto neto de $720."}',
      );

      const res = await firstValueFrom(servicio.consultar('¿Y la factura?', mockContexto));

      expect(llamadasIa).toBe(2);
      expect(res.origen).toBe('ia');
    });

    it('ejecuta la herramienta que pide el modelo y le devuelve el cálculo', async () => {
      const llamada = { nombre: 'margen_producto', parametros: { nombre: 'chaparrita' } };
      salidas(JSON.stringify({ herramientas: [llamada] }), '{"respuesta":"Te deja $720 por unidad (24%)."}');

      const res = await firstValueFrom(servicio.consultar('¿Margen de la chaparrita?', mockContexto));

      expect(ejecutarHerramienta).toHaveBeenCalledTimes(1);
      expect(ejecutarHerramienta.mock.calls[0][0]).toEqual(llamada);
      expect(ultimaLlamadaMensajes!.usuario).toContain('RESULTADOS DE LAS HERRAMIENTAS');
      expect(ultimaLlamadaMensajes!.usuario).toContain('"margen_por_unidad":720');
      expect(res.texto).toBe('Te deja $720 por unidad (24%).');
      expect(res.origen).toBe('ia');
    });

    it('recibe el estado de la proyección de hoy y responde sin inventar el cierre', async () => {
      const proyeccion: ProyeccionCierre = {
        estado: 'historial-insuficiente',
        factor: 1,
        ocurrencias: 2,
        minimoOcurrencias: 3,
        mensaje:
          'Aún no hay días suficientes para proyectar el cierre de hoy: se necesitan al menos 3 días anteriores de lunes con ventas y hay 2.',
      };
      ejecutarHerramienta.mockImplementationOnce((llamada) =>
        of({
          herramienta: llamada.nombre,
          parametros: llamada.parametros,
          datos: {
            periodo: '1d',
            kpis: [
              {
                id: 'ingresos',
                titulo: 'Total vendido (hoy)',
                montoClp: 125000,
                variacionPct: null,
                subtitulo: 'Ventas realizadas hoy: 9',
                tono: 'positivo',
              },
            ],
            proyeccion,
          },
        }) as never,
      );
      salidas(
        '{"herramientas":[{"nombre":"analisis_dashboard","parametros":{"periodo":"1d"}}]}',
        '{"respuesta":"Aún no hay días suficientes para proyectar el cierre de hoy."}',
      );

      const res = await firstValueFrom(servicio.consultar('¿Cuánto llevamos hoy?', mockContexto));

      expect(ejecutarHerramienta.mock.calls[0][0]).toEqual({
        nombre: 'analisis_dashboard',
        parametros: { periodo: '1d' },
      });
      expect(ultimaLlamadaMensajes!.usuario).toContain('"proyeccion":{"estado":"historial-insuficiente"');
      expect(res.origen).toBe('ia');
      expect(res.texto).toBe('Aún no hay días suficientes para proyectar el cierre de hoy.');
    });

    it('rechaza cifras que no salen de las herramientas y pide corregir', async () => {
      salidas(
        '{"herramientas":[{"nombre":"margen_producto"}]}',
        '{"respuesta":"Te deja $999."}',
        '{"respuesta":"Te deja $720."}',
      );

      const res = await firstValueFrom(servicio.consultar('¿Margen?', mockContexto));

      expect(llamadasIa).toBe(3);
      expect(ultimaLlamadaMensajes!.usuario).toContain('$999');
      expect(res.texto).toBe('Te deja $720.');
      expect(res.origen).toBe('ia');
    });

    it('muestra los datos calculados si el modelo insiste en cifras sin respaldo', async () => {
      salidas(
        '{"herramientas":[{"nombre":"margen_producto"}]}',
        '{"respuesta":"Te deja $999."}',
        '{"respuesta":"Te deja $888."}',
      );

      const res = await firstValueFrom(servicio.consultar('¿Margen?', mockContexto));

      expect(res.origen).toBe('algoritmo');
      expect(res.texto).not.toContain('$888');
      expect(res.datosCalculados?.flatMap((b) => b.lineas)).toContain('Margen por unidad: $720');
    });

    it('obliga a pedir herramientas si responde cifras sin consultar', async () => {
      salidas('{"respuesta":"Vendiste $7.300"}', '{"herramientas":[{"nombre":"margen_producto"}]}', '{"respuesta":"Son $720"}');

      const res = await firstValueFrom(servicio.consultar('¿Cuánto vendí?', mockContexto));

      expect(ejecutarHerramienta).toHaveBeenCalledTimes(1);
      expect(res.texto).toBe('Son $720');
    });

    it('rechaza nombres que no salen de los resultados, como personas inventadas', async () => {
      salidas(
        '{"herramientas":[{"nombre":"margen_producto"}]}',
        '{"respuesta":"Almorzaron Juan Pérez y María González."}',
        '{"respuesta":"Sin datos de almuerzos."}',
      );

      const res = await firstValueFrom(servicio.consultar('¿Quién almorzó?', mockContexto));

      expect(ultimaLlamadaMensajes!.usuario).toContain('Juan');
      expect(res.texto).toBe('Sin datos de almuerzos.');
    });

    it('no repite una herramienta con los mismos parámetros y pide responder', async () => {
      const pedido = '{"herramientas":[{"nombre":"margen_producto","parametros":{"nombre":"cafe"}}]}';
      salidas(pedido, pedido, '{"respuesta":"Listo"}');

      const res = await firstValueFrom(servicio.consultar('¿Margen?', mockContexto));

      expect(ejecutarHerramienta).toHaveBeenCalledTimes(1);
      expect(ultimaLlamadaMensajes!.usuario).toContain('Ya tienes los resultados');
      expect(res.texto).toBe('Listo');
    });

    it('acepta cifras de la pregunta, del historial y de la guía del sistema', async () => {
      salidas('{"respuesta":"Sí, los $1.500 que dijiste y los $3.000 de antes. Billetes desde $1.000."}');

      const res = await firstValueFrom(
        servicio.consultar('¿Es correcto $1.500?', mockContexto, [{ autor: 'asistente', texto: 'Vendiste $3.000' }]),
      );
      expect(res.origen).toBe('ia');
    });

    it('limita las herramientas por ronda', async () => {
      const herramientas = Array.from({ length: 9 }, (_, i) => ({ nombre: 'margen_producto', parametros: { i } }));
      salidas(JSON.stringify({ herramientas }), '{"respuesta":"ok"}');

      await firstValueFrom(servicio.consultar('x', mockContexto));
      expect(ejecutarHerramienta).toHaveBeenCalledTimes(5);
    });

    it('limita las rondas aunque el modelo siga pidiendo herramientas', async () => {
      let pedido = 0;
      orquestadorRespuesta = () =>
        of(respuestaIa(JSON.stringify({ herramientas: [{ nombre: 'margen_producto', parametros: { pedido: pedido++ } }] })));

      const res = await firstValueFrom(servicio.consultar('cuanto se ha vendido', mockContexto));

      expect(llamadasIa).toBe(5);
      expect(ejecutarHerramienta).toHaveBeenCalledTimes(4);
      expect(ultimaLlamadaMensajes!.usuario).toContain('Ya no puedes pedir más herramientas');
      expect(res.origen).toBe('algoritmo');
    });

    it('envía la conversación previa para entender preguntas de seguimiento', async () => {
      salidas('{"respuesta":"ok"}');

      await firstValueFrom(
        servicio.consultar('¿y el de ayer?', mockContexto, [
          { autor: 'usuario', texto: '¿Cuánto vendí hoy?' },
          { autor: 'asistente', texto: 'Vendiste $2.000' },
        ]),
      );
      expect(ultimaLlamadaMensajes!.usuario).toContain('Usuario: ¿Cuánto vendí hoy?');
      expect(ultimaLlamadaMensajes!.usuario).toContain('Asistente: Vendiste $2.000');
      expect(ultimaLlamadaMensajes!.usuario).toContain('PREGUNTA ACTUAL: ¿y el de ayer?');
    });

    it('pide recomendaciones al modelo solo cuando la pregunta las pide', async () => {
      salidas('{"respuesta":"ok"}');
      await firstValueFrom(servicio.consultar('¿Cuánto vendimos este mes y qué me recomiendas?', mockContexto, []));
      expect(ultimaLlamadaMensajes!.usuario).toContain(INSTRUCCION_RECOMENDACION);
      expect(ultimaLlamadaMensajes!.sistema).toContain('Recomienda solo si después de la pregunta aparece la línea EL USUARIO PIDE RECOMENDACIONES');

      salidas('{"respuesta":"ok"}');
      await firstValueFrom(servicio.consultar('¿Cuánto vendimos este mes?', mockContexto, []));
      expect(ultimaLlamadaMensajes!.usuario).not.toContain('EL USUARIO PIDE RECOMENDACIONES');
    });

    it('la recomendación va en la respuesta y la lista, no en un campo aparte', async () => {
      salidas(
        '{"respuesta":"Vendiste $2.000. Conviene reponer café antes del viernes.","puntos":["Café: $2.000","Reponer café antes del viernes"],"consejo":"Sube precios."}',
      );
      const res = await firstValueFrom(servicio.consultar('¿Qué me recomiendas?', mockContexto, []));
      expect(res).not.toHaveProperty('consejoCard');
      expect(JSON.stringify(res)).not.toContain('Sube precios');
    });

    it.each([
      ['¿Qué me recomiendas?', true],
      ['Dame un consejo para vender más', true],
      ['¿Qué debería hacer con el stock?', true],
      ['¿Qué me sugieres?', true],
      ['¿Cómo puedo aumentar las ventas?', true],
      ['¿Cuánto vendí hoy?', false],
      ['¿Qué producto se vende más?', false],
      ['¿Qué necesito comprar con urgencia?', false],
    ])('pideRecomendacion(%s) es %s', (pregunta, esperado) => {
      expect(pideRecomendacion(pregunta)).toBe(esperado);
    });

    it('la conversación previa lleva primero lo que el usuario leyó, con su lista', async () => {
      salidas('{"respuesta":"ok"}');

      await firstValueFrom(
        servicio.consultar('¿Dónde es eso?', mockContexto, [
          {
            autor: 'asistente',
            texto: 'El desempeño por sucursal está en Reportes.',
            puntosCard: ['Pestaña Sucursales'],
            datosCalculados: [{ titulo: 'Cajeros', lineas: ['Total: $2.000'] }],
          },
        ]),
      );
      expect(ultimaLlamadaMensajes!.usuario).toContain(
        'Asistente: El desempeño por sucursal está en Reportes. · Pestaña Sucursales · Cajeros · Total: $2.000',
      );
    });
  });

  describe('Salidas defectuosas del modelo', () => {
    it.each([
      ['JSON cortado', '{"herramientas": [{"nombre": "marg'],
      ['objeto sin respuesta ni herramientas', '{"otra":1}'],
      ['lista vacía', '{"herramientas":[]}'],
      ['respuesta que no es texto', '{"respuesta":{"a":1}}'],
    ])('pide corregir ante %s, sin mostrarlo al usuario', async (_caso, defectuosa) => {
      salidas(defectuosa, '{"respuesta":"Corregido"}');

      const res = await firstValueFrom(servicio.consultar('x', mockContexto));

      expect(llamadasIa).toBe(2);
      expect(ultimaLlamadaMensajes!.usuario).toContain('no tenía el formato');
      expect(res.texto).toBe('Corregido');
    });

    it('interpreta la salida del modelo', () => {
      expect(interpretarSalidaAsistente('{"respuesta":" Hola "}').respuesta).toBe('Hola');
      expect(interpretarSalidaAsistente('Texto suelto').respuesta).toBe('Texto suelto');
      expect(interpretarSalidaAsistente('{"herramientas":[{"nombre":"a"},{"x":1}]}').herramientas).toEqual([{ nombre: 'a' }]);
      // Variantes reales de los modelos
      expect(
        interpretarSalidaAsistente('{"herramientas":[{"herramienta":"a","parametros":{"p":1}}]}').herramientas,
      ).toEqual([{ nombre: 'a', parametros: { p: 1 } }]);
      expect(
        interpretarSalidaAsistente('{"herramientas":[{"herramienta":"a","recurso":"ventas"}]}').herramientas,
      ).toEqual([{ nombre: 'a', parametros: { recurso: 'ventas' } }]);
      expect(
        interpretarSalidaAsistente('{"herramientas":[{"herramientas":[{"nombre":"a"}]}]}').herramientas,
      ).toEqual([{ nombre: 'a' }]);
      expect(interpretarSalidaAsistente('{"otra":1}').respuesta).toBeUndefined();
      expect(interpretarSalidaAsistente('null').respuesta).toBeUndefined();
      expect(interpretarSalidaAsistente('{"cortado":').respuesta).toBeUndefined();
    });

    it('separa la respuesta en frase y lista, limpia el Markdown y descarta el consejo', () => {
      const partes = interpretarSalidaAsistente(
        '{"respuesta":"**Viernes** lidera.","titulo":"## Por día","puntos":["Viernes: 90"," ",7,"Lunes: 40"],"consejo":"Revisa el módulo de ventas."}',
      );
      expect(partes).toMatchObject({
        respuesta: 'Viernes lidera.',
        titulo: 'Por día',
        puntos: ['Viernes: 90', 'Lunes: 40'],
      });
      // El modelo usaba el consejo para indicar pantallas que no existen: ya no se lee.
      expect(partes).not.toHaveProperty('consejo');
      // Una lista escrita dentro del texto también se muestra como lista.
      expect(interpretarSalidaAsistente('{"respuesta":"Faltan dos:\\n- Leche\\n- Harina"}')).toMatchObject({
        respuesta: 'Faltan dos:',
        puntos: ['Leche', 'Harina'],
      });
      expect(interpretarSalidaAsistente('Faltan dos:\n1. Leche\n2) Harina').puntos).toEqual(['Leche', 'Harina']);
      // Texto después de la lista: no se reordena, se deja en párrafos.
      const mixto = interpretarSalidaAsistente('Faltan dos:\n- Leche\n- Harina\nPide hoy.');
      expect(mixto.puntos).toBeUndefined();
      expect(mixto.respuesta).toBe('Faltan dos:\n- Leche\n- Harina\nPide hoy.');
      // Sin frase principal no hay respuesta, aunque vengan puntos.
      const sinFrase = interpretarSalidaAsistente('{"puntos":["a","b"]}');
      expect(sinFrase.respuesta).toBeUndefined();
      expect(sinFrase.puntos).toBeUndefined();
    });

    it('entrega la respuesta estructurada como tarjeta y pide ese formato al modelo', async () => {
      salidas(
        '{"herramientas":[{"nombre":"margen_producto"}]}',
        '{"respuesta":"El margen es de $720 por unidad.","titulo":"Detalle","puntos":["Margen por unidad: $720","Margen: 24%"],"consejo":"Mantén el precio."}',
      );

      const res = await firstValueFrom(servicio.consultar('¿Margen del café?', mockContexto));

      expect(res).toMatchObject({
        origen: 'ia',
        tipoRespuesta: 'card',
        texto: 'El margen es de $720 por unidad.',
        tituloCard: 'Detalle',
        puntosCard: ['Margen por unidad: $720', 'Margen: 24%'],
      });
      expect(res).not.toHaveProperty('consejoCard');
      expect(ultimaLlamadaMensajes!.sistema).toContain('"puntos":["dato 1","dato 2"]}');
      expect(ultimaLlamadaMensajes!.sistema).not.toContain('"consejo"');
      expect(ultimaLlamadaMensajes!.sistema).toContain('MENÚ COMPLETO: Dashboard, Reportes');
      expect(ultimaLlamadaMensajes!.sistema).not.toContain('en texto plano');
    });

    it('una respuesta de una sola frase sigue como texto simple', async () => {
      salidas('{"respuesta":"Listo"}');
      const res = await firstValueFrom(servicio.consultar('Hola', mockContexto));
      expect(res.tipoRespuesta).toBe('texto');
      expect(res.puntosCard).toBeUndefined();
    });

    it('escribe en pesos los montos que el modelo entrega sin formato', async () => {
      ejecutarHerramienta.mockImplementationOnce((llamada) =>
        of({
          herramienta: llamada.nombre,
          parametros: llamada.parametros,
          datos: [{ cajero: 'Caja 1', total: 461820, ticket_promedio: 51313.33 }],
        }) as never,
      );
      salidas(
        '{"herramientas":[{"nombre":"ranking_cajeros"}]}',
        '{"respuesta":"Se vendieron 461820 pesos.","puntos":["Promedio: $51313 por venta","Total: 461820 CLP"]}',
      );

      const res = await firstValueFrom(servicio.consultar('¿Cuánto vendió la caja?', mockContexto));

      expect(res.origen).toBe('ia');
      expect(res.texto).toBe('Se vendieron $461.820.');
      expect(res.puntosCard).toEqual(['Promedio: $51.313 por venta', 'Total: $461.820']);
    });

    it('montosEnPesos no toca años, cantidades ni montos ya formateados', () => {
      expect(montosEnPesos('En 2026 vendió 1500 unidades por $461.820.')).toBe('En 2026 vendió 1500 unidades por $461.820.');
      expect(montosEnPesos('Folio 45210, total $ 12500,5 y 3000 pesos chilenos.')).toBe('Folio 45210, total $12.501 y $3.000.');
      // Un número ambiguo no se adivina.
      expect(montosEnPesos('$12345.678')).toBe('$12345.678');
    });

    it('montosEnPesos formatea un número suelto solo si los resultados lo traen como monto', () => {
      const resultados = [
        {
          herramienta: 'consultar',
          datos: [{ cajero: 'Caja 1', tickets: 1500, total_vendido: '461820.00', ticket_promedio: 51313.33, folio: '45210', costo: 1500 }],
        },
      ];
      // 1500 es a la vez un costo y una cantidad de tickets: ante la duda no se toca.
      expect(montosEnPesos('Vendió 461820 en 1500 tickets, promedio de 51313, folio 45210 y costo 1500.', resultados)).toBe(
        'Vendió $461.820 en 1500 tickets, promedio de $51.313, folio 45210 y costo 1500.',
      );
      expect(montosEnPesos('Vendió 461820 en 2026.')).toBe('Vendió 461820 en 2026.');
    });

    it('pantallasInexistentes detecta módulos y pestañas que no están en el menú', () => {
      expect(pantallasInexistentes('Revísalo en el módulo de ventas si necesitas filtrar por local.')).toEqual(['módulo de ventas']);
      expect(pantallasInexistentes('Está en la sección "Clientes" o en la pestaña Finanzas.')).toHaveLength(2);
      // Pantallas y pestañas reales, con cualquier forma de nombrarlas.
      expect(
        pantallasInexistentes(
          'Ve al módulo de Reportes, pestaña Cajeros. En el módulo de inventario abre la pestaña «Por comprar» o la pestaña Ventas del Dashboard, y la sección de Administración.',
        ),
      ).toEqual([]);
      // Negar una pantalla o hablar en general no es inventarla.
      expect(pantallasInexistentes('No existe un módulo de ventas: usa Reportes.')).toEqual([]);
      expect(pantallasInexistentes('Es un módulo exclusivo para facturas; mira la sección anterior.')).toEqual([]);
    });

    it('rechaza una respuesta que manda a una pantalla que no existe y pide corregirla', async () => {
      salidas(
        '{"respuesta":"Puedes verlo en el módulo de ventas."}',
        '{"respuesta":"Puedes verlo en Reportes, en la pestaña Sucursales."}',
      );

      const res = await firstValueFrom(servicio.consultar('¿Dónde veo el desempeño por sucursal?', mockContexto));

      expect(llamadasIa).toBe(2);
      expect(ultimaLlamadaMensajes!.usuario).toContain('"módulo de ventas", que no existe en el sistema');
      expect(res.texto).toBe('Puedes verlo en Reportes, en la pestaña Sucursales.');
    });

    it('rechaza una cifra inventada aunque venga en la lista', async () => {
      salidas(
        '{"herramientas":[{"nombre":"margen_producto"}]}',
        '{"respuesta":"El margen es de $720.","puntos":["Margen: $720","Costo: $9.999"]}',
        '{"respuesta":"El margen es de $720.","puntos":["Margen: $720","Sube el precio a $5.555."]}',
      );

      const res = await firstValueFrom(servicio.consultar('¿Margen del café?', mockContexto));

      expect(llamadasIa).toBe(3);
      expect(ultimaLlamadaMensajes!.usuario).toContain('$9.999');
      expect(res.origen).toBe('algoritmo');
      expect(JSON.stringify(res)).not.toMatch(/9\.999|5\.555/);
    });
  });

  describe('Cuando la IA falla', () => {
    it('informa el motivo de cada proveedor', async () => {
      orquestadorRespuesta = () =>
        throwError(
          () =>
            new SinProveedoresIAError('agotados', [
              { proveedorId: 'gemini-3.5', modelo: 'm', exitoso: false, codigoEstado: 503, duracionMs: 1 },
              { proveedorId: 'gemma', modelo: 'm', exitoso: false, error: 'Respuesta vacía', duracionMs: 1 },
            ]),
        );

      const aviso = vi.spyOn(console, 'warn').mockImplementation(() => undefined);
      const res = await firstValueFrom(servicio.consultar('cuanto se ha vendido', mockContexto));

      expect(res.origen).toBe('respaldo-local');
      expect(aviso.mock.lastCall?.[1]).toBe('gemini-3.5: HTTP 503; gemma: Respuesta vacía');
      expect(JSON.stringify(res)).not.toContain('HTTP 503');
    });

    it('explica cuando todos los proveedores están en espera', async () => {
      orquestadorRespuesta = () => throwError(() => new SinProveedoresIAError('agotados', []));
      const aviso = vi.spyOn(console, 'warn').mockImplementation(() => undefined);
      await firstValueFrom(servicio.consultar('hola', mockContexto));
      expect(aviso.mock.lastCall?.[1]).toContain('agotados');
    });

    it('conserva los datos ya calculados si la IA cae a mitad de la conversación', async () => {
      const aviso = vi.spyOn(console, 'warn').mockImplementation(() => undefined);
      const lista = [of(respuestaIa('{"herramientas":[{"nombre":"margen_producto"}]}')), throwError(() => new Error('Caída'))];
      orquestadorRespuesta = () => lista.shift()!;

      const res = await firstValueFrom(servicio.consultar('¿Margen?', mockContexto));

      expect(res.origen).toBe('algoritmo');
      expect(res.datosCalculados?.flatMap((b) => b.lineas)).toContain('Margen por unidad: $720');
      expect(aviso.mock.lastCall?.[1]).toBe('Caída');
    });

    it('usa el respaldo local si no puede leer el esquema de la base', async () => {
      esquema.mockReturnValueOnce(throwError(() => new Error('Sin API')));
      const res = await firstValueFrom(servicio.consultar('cuanto se ha vendido', mockContexto));
      expect(res.origen).toBe('respaldo-local');
      expect(llamadasIa).toBe(0);
    });
  });

  describe('Respaldo local (sin IA)', () => {
    beforeEach(() => {
      orquestadorRespuesta = () => throwError(() => new SinProveedoresIAError('sin-conexion', []));
    });

    const preguntar = (texto: string, contexto = mockContexto) =>
      firstValueFrom(servicio.consultar(texto, contexto));

    it('responde el margen de un producto del catálogo con el mismo algoritmo', async () => {
      const res = await preguntar('¿Qué margen me deja el capuccino?');
      expect(ejecutarHerramienta).toHaveBeenCalledWith(
        { nombre: 'margen_producto', parametros: { nombre: 'Capuccino' } },
        expect.anything(),
      );
      expect(res.tipoRespuesta).toBe('card');
      expect(res.puntosCard).toContain('Margen por unidad: $720');
    });

    it('no responde un resumen sin relación si no reconoce el producto del margen', async () => {
      const res = await preguntar('¿Qué margen me deja el producto inventado?');
      expect(res.texto).toContain('No pude');
      expect(res.texto).not.toContain('$19.450.000');
    });

    it('dice que no puede responder si no entiende la pregunta', async () => {
      const res = await preguntar('¿Quién fundó la cafetería?');
      expect(res.texto).toContain('No pude');
      expect(res.texto).not.toContain('$19.450.000');
    });

    it('responde sobre artículos inactivos', async () => {
      const res = await preguntar('¿Qué productos están inactivos y por qué no salen en el POS?');
      expect(res.tipoRespuesta).toBe('card');
      expect(res.tituloCard).toContain('Artículos pausados o descontinuados');
      expect(res.puntosCard).toEqual(['Frappé Dulce de Leche (Producto)']);
      expect(res).not.toHaveProperty('consejoCard');
    });

    it('no confunde palabras que contienen "pos" u "hora"', async () => {
      expect((await preguntar('¿Es posible mejorar?')).tituloCard).toBeUndefined();
      expect((await preguntar('¿Qué hago ahora?')).tituloCard).toBeUndefined();
    });

    it('responde sobre compras urgentes advirtiendo los días registrados', async () => {
      const res = await preguntar('¿Qué insumos necesito comprar hoy?');
      expect(res.texto).toContain('últimos 14 días');
      expect(res.puntosCard?.some((p) => p.includes('Harina Panadera 000'))).toBe(true);
    });

    it('orienta sobre la carga de facturas XML', async () => {
      const res = await preguntar('¿Cómo cargo una factura XML del SII?');
      // El texto nombra el menú y el botón, no una ruta.
      expect(res.texto).toContain('entra a Facturas en el menú lateral y presiona «Cargar factura»');
      expect(JSON.stringify(res)).not.toContain('/facturas');
      expect(res).not.toHaveProperty('consejoCard');
    });

    it('responde sobre el día con más venta en pesos, el mismo que destaca la tarjeta', async () => {
      const ceros = { gananciaTotalClp: 0, promedioGananciaDiariaClp: 0, vecesEnPeriodo: 4 };
      const conDias: ContextoEjecutivoAsistente = {
        ...mockContexto,
        demandaPorDiaSemana: [
          // El lunes tiene más boletas, pero el viernes suma más plata en el período.
          { dia: 'Lunes', diaNumero: 1, cantidadVentas: 90, montoTotalClp: 200000, promedioVentaDiariaClp: 50000, esDiaMayorVenta: false, ...ceros },
          { dia: 'Viernes', diaNumero: 5, cantidadVentas: 50, montoTotalClp: 450000, promedioVentaDiariaClp: 112500, esDiaMayorVenta: true, ...ceros },
        ],
      };
      const res = await preguntar('¿Cuál es el día de mayor volumen de ventas?', conDias);
      expect(res.texto).toContain('el día con más venta es el Viernes, con $450.000 vendidos en el período (50 ventas)');
      expect(res.puntosCard).toContain('Viernes: $450.000 en 50 ventas, el día con más venta');
      expect(res.tituloCard).toBe('Total vendido por día de la semana');
    });

    it('responde sobre los horarios punta', async () => {
      const res = await preguntar('¿Cuáles son los horarios punta?');
      expect(res.puntosCard?.some((p) => p.includes('08:00 hrs'))).toBe(true);
    });

    it('responde cuánto se ha vendido con las cifras del contexto', async () => {
      const res = await preguntar('cuanto se ha vendido');
      expect(res.texto).toContain('$19.450.000');
      expect(res.puntosCard?.some((p) => p.includes('$6.320.000'))).toBe(true);
      expect((await preguntar('¿Qué es lo que más se vende?')).puntosCard?.some((p) => p.includes('Capuccino'))).toBe(true);
    });

    it.each(['¿Cuánto llevamos vendido hoy?', '¿Cómo van las ventas de hoy?'])(
      'detecta preguntas por el día en curso y usa el período "1d": %s',
      async (pregunta) => {
        const proyeccion: ProyeccionCierre = {
          estado: 'historial-insuficiente',
          factor: 1,
          ocurrencias: 2,
          minimoOcurrencias: 3,
          mensaje:
            'Aún no hay días suficientes para proyectar el cierre de hoy: se necesitan al menos 3 días anteriores de lunes con ventas y hay 2.',
        };
        ejecutarHerramienta.mockImplementationOnce(() =>
          of({
            herramienta: 'analisis_dashboard',
            parametros: { periodo: '1d', sucursal_id: 1 },
            datos: {
              periodo: '1d',
              kpis: [
                {
                  id: 'ingresos',
                  titulo: 'Total vendido (hoy)',
                  montoClp: 125000,
                  variacionPct: null,
                  subtitulo: 'Ventas realizadas hoy: 9',
                  tono: 'positivo',
                },
                {
                  id: 'proyeccion-ia',
                  titulo: 'Con cuánto cerraremos hoy',
                  montoClp: 500000,
                  variacionPct: null,
                  subtitulo: 'Ganancia limpia estimada si seguimos al ritmo actual',
                  tono: 'proyeccion',
                },
              ],
              proyeccion,
            },
          }) as never,
        );

        const res = await preguntar(pregunta);
        const respuesta = JSON.stringify(res);

        expect(ejecutarHerramienta.mock.calls[0][0]).toEqual({
          nombre: 'analisis_dashboard',
          parametros: { periodo: '1d', sucursal_id: 1 },
        });
        expect(res.tipoRespuesta).toBe('card');
        expect(res.texto).toContain('$125.000');
        expect(res.texto).toContain('Aún no hay días suficientes para proyectar el cierre');
        expect(res.puntosCard).toContain('Total vendido (hoy): $125.000');
        // Sin historial suficiente no se muestra ninguna cifra de cierre.
        expect(respuesta).not.toContain('$500.000');
        expect(respuesta).not.toContain('Con cuánto cerraremos hoy');
      },
    );

    it('muestra el cierre calculado cuando la proyección está disponible', async () => {
      const proyeccion: ProyeccionCierre = {
        estado: 'disponible',
        factor: 2.4,
        ocurrencias: 4,
        minimoOcurrencias: 3,
        mensaje: 'Proyección con 4 días anteriores de lunes: a esta hora se llevaba en promedio el 40 % del día.',
      };
      ejecutarHerramienta.mockImplementationOnce(() =>
        of({
          herramienta: 'analisis_dashboard',
          parametros: { periodo: '1d', sucursal_id: 1 },
          datos: {
            periodo: '1d',
            kpis: [
              {
                id: 'ingresos',
                titulo: 'Total vendido (hoy)',
                montoClp: 125000,
                variacionPct: null,
                subtitulo: 'Ventas realizadas hoy: 9',
                tono: 'positivo',
              },
              {
                id: 'proyeccion-ia',
                titulo: 'Con cuánto cerraremos hoy',
                montoClp: 300000,
                variacionPct: null,
                subtitulo: 'Ganancia limpia estimada si seguimos al ritmo actual',
                tono: 'proyeccion',
              },
            ],
            proyeccion,
          },
        }) as never,
      );

      const res = await preguntar('¿Cómo van las ventas de hoy?');

      expect(res.puntosCard).toContain(
        'Con cuánto cerraremos hoy: $300.000 (Ganancia limpia estimada si seguimos al ritmo actual)',
      );
      expect(res.texto).toContain('Proyección con 4 días anteriores de lunes');
    });

    it('no entrega cifras si tampoco se pudieron cargar los datos', async () => {
      const res = await preguntar('cuanto se ha vendido', { ...mockContexto, datosDisponibles: false });
      expect(res.tipoRespuesta).toBe('texto');
      expect(res.texto).toContain('No pude cargar los datos');
      expect(res.texto).not.toContain('$');
    });
  });

  describe('Conversación persistente', () => {
    it('acumula mensajes y envía el historial en la siguiente pregunta', () => {
      salidas('{"respuesta":"Primera"}', '{"respuesta":"Segunda"}');

      servicio.enviar('Hola', mockContexto);
      expect(servicio.mensajes().map((m) => m.texto)).toEqual(['Hola', 'Primera']);
      expect(servicio.consultando()).toBe(false);

      servicio.enviar('Sigo', mockContexto);
      expect(ultimaLlamadaMensajes!.usuario).toContain('Usuario: Hola');
      expect(servicio.mensajes()).toHaveLength(4);
    });

    it('ignora textos vacíos y preguntas mientras hay otra en curso', () => {
      const pendiente = new Subject<RespuestaOrquestadorIA>();
      orquestadorRespuesta = () => pendiente;

      servicio.enviar('   ', mockContexto);
      expect(servicio.mensajes()).toEqual([]);

      servicio.enviar('Hola', mockContexto);
      servicio.enviar('Otra', mockContexto);
      expect(servicio.consultando()).toBe(true);
      expect(servicio.mensajes()).toHaveLength(1);
    });

    it('Nueva conversación limpia los mensajes y descarta la respuesta en curso', () => {
      const pendiente = new Subject<RespuestaOrquestadorIA>();
      orquestadorRespuesta = () => pendiente;
      servicio.enviar('Hola', mockContexto);

      servicio.nuevaConversacion();
      pendiente.next(respuestaIa('{"respuesta":"Tarde"}'));

      expect(servicio.mensajes()).toEqual([]);
      expect(servicio.consultando()).toBe(false);
    });

    it('borra el chat al cerrar sesión o cambiar de usuario', () => {
      salidas('{"respuesta":"Dato"}', '{"respuesta":"Dato"}');
      servicio.enviar('Hola', mockContexto);
      TestBed.tick();
      expect(servicio.mensajes()).toHaveLength(2);

      usuario.set(null);
      TestBed.tick();
      expect(servicio.mensajes()).toEqual([]);

      servicio.enviar('Hola', mockContexto);
      usuario.set({ id: 2 });
      TestBed.tick();
      expect(servicio.mensajes()).toEqual([]);
    });

    describe('al recargar la página', () => {
      const recargar = () => TestBed.runInInjectionContext(() => new AsistenteDashboardService());

      function conversar(): void {
        salidas('{"respuesta":"Dato"}');
        servicio.enviar('Hola', mockContexto);
        TestBed.tick();
      }

      it('conserva la conversación con sus datos calculados', () => {
        ejecutarHerramienta.mockClear();
        salidas('{"herramientas":[{"nombre":"margen_producto"}]}', '{"respuesta":"Te deja $720."}');
        servicio.enviar('¿Margen?', mockContexto);
        TestBed.tick();

        const recargado = recargar();

        expect(recargado.mensajes()).toEqual(servicio.mensajes());
        expect(recargado.mensajes()[1].datosCalculados).not.toEqual([]);
      });

      it('si la respuesta no alcanzó a llegar, avisa que hay que volver a preguntar', () => {
        orquestadorRespuesta = () => new Subject<RespuestaOrquestadorIA>();
        servicio.enviar('Hola', mockContexto);
        TestBed.tick();

        const recargado = recargar();

        expect(recargado.consultando()).toBe(false);
        expect(recargado.mensajes().map((m) => m.autor)).toEqual(['usuario', 'asistente']);
        expect(recargado.mensajes()[1].texto).toContain('Vuelve a hacer la pregunta');
      });

      it('Nueva conversación también borra lo guardado', () => {
        conversar();

        servicio.nuevaConversacion();
        TestBed.tick();

        expect(recargar().mensajes()).toEqual([]);
      });

      it('cerrar sesión borra lo guardado', () => {
        conversar();

        usuario.set(null);
        TestBed.tick();
        expect(sessionStorage.length).toBe(0);
      });

      it('no recupera la conversación en otra sesión, aunque sea del mismo usuario', () => {
        conversar();

        sesion = 'token-de-la-sesion-2';

        expect(recargar().mensajes()).toEqual([]);
      });

      it('ignora lo guardado si está dañado', () => {
        sessionStorage.setItem('nurybase.asistente.conversacion', '{no es json');

        expect(recargar().mensajes()).toEqual([]);
      });
    });

    describe('tiempo límite de 30 s', () => {
      it('si el esquema no responde a los 30 s, termina con un mensaje y consultando() vuelve a false', () => {
        vi.useFakeTimers();
        try {
          esquema.mockReturnValueOnce(new Subject());

          servicio.enviar('¿Cuánto vendimos hoy?', mockContexto);
          expect(servicio.consultando()).toBe(true);

          vi.advanceTimersByTime(TIEMPO_LIMITE_CONSULTA_MS);

          expect(servicio.consultando()).toBe(false);
          expect(servicio.mensajes()).toHaveLength(2);
          expect(servicio.mensajes()[1].autor).toBe('asistente');
          expect(servicio.mensajes()[1].origen).toBe('respaldo-local');
          expect(servicio.mensajes()[1].texto).toContain('No pude');
        } finally {
          vi.useRealTimers();
        }
      });

      it('si nombresReales no responde a los 30 s, termina con un mensaje y consultando() vuelve a false', () => {
        vi.useFakeTimers();
        try {
          nombresReales.mockReturnValueOnce(new Subject());

          servicio.enviar('Hola', mockContexto);
          expect(servicio.consultando()).toBe(true);

          vi.advanceTimersByTime(TIEMPO_LIMITE_CONSULTA_MS);

          expect(servicio.consultando()).toBe(false);
          expect(servicio.mensajes()).toHaveLength(2);
          expect(servicio.mensajes()[1].autor).toBe('asistente');
          expect(servicio.mensajes()[1].origen).toBe('respaldo-local');
        } finally {
          vi.useRealTimers();
        }
      });

      it('si el respaldo local espera a la API sin respuesta, corta a los 30 s', () => {
        vi.useFakeTimers();
        try {
          orquestadorRespuesta = () => throwError(() => new SinProveedoresIAError('sin-conexion', []));
          ejecutarHerramienta.mockReturnValueOnce(new Subject() as never);

          servicio.enviar('¿Qué margen me deja el capuccino?', mockContexto);
          expect(servicio.consultando()).toBe(true);

          vi.advanceTimersByTime(TIEMPO_LIMITE_CONSULTA_MS);

          expect(servicio.consultando()).toBe(false);
          expect(servicio.mensajes()).toHaveLength(2);
          expect(servicio.mensajes()[1].origen).toBe('respaldo-local');
          expect(servicio.mensajes()[1].texto).toContain('No pude');
        } finally {
          vi.useRealTimers();
        }
      });
    });
  });
});
