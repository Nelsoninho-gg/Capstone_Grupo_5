import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { firstValueFrom } from 'rxjs';
import { environment } from '../../../environments/environment';
import { AlmuerzosApiService, fechaHoyChile } from './almuerzos-api.service';

describe('AlmuerzosApiService', () => {
  let service: AlmuerzosApiService;
  let http: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()],
    });
    service = TestBed.inject(AlmuerzosApiService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  it('registers the lunch through the RPC without payment data and returns its id', async () => {
    const payload = {
      p_sucursal_id: 1,
      p_empleado_id: 7,
      p_items: [
        { producto_id: 2, cantidad: 1 },
        { producto_id: 5, cantidad: 1 },
      ],
    };
    const result = firstValueFrom(service.registrar(payload));

    const request = http.expectOne(`${environment.apiUrl}/rpc/fn_registrar_almuerzo_empleado`);
    expect(request.request.method).toBe('POST');
    expect(request.request.body).toEqual(payload);
    expect(request.request.body).not.toHaveProperty('p_medio_pago');
    request.flush(12);

    await expect(result).resolves.toBe(12);
  });

  it('lists the employees who already had lunch on a given day', async () => {
    const result = firstValueFrom(service.empleadosConAlmuerzo('2026-10-22'));

    const request = http.expectOne((req) => req.url === `${environment.apiUrl}/almuerzos_empleado`);
    expect(request.request.method).toBe('GET');
    expect(request.request.params.get('fecha')).toBe('eq.2026-10-22');
    expect(request.request.params.get('select')).toBe('empleado_id');
    request.flush([{ empleado_id: 7 }, { empleado_id: 9 }]);

    await expect(result).resolves.toEqual([7, 9]);
  });

  it('lists lunches by branch, employee and period with their detail (H2.13 T07)', async () => {
    const result = firstValueFrom(
      service.listar({ sucursalId: 2, empleadoId: 7, desde: '2026-10-01', hasta: '2026-10-31' }),
    );

    const request = http.expectOne((req) => req.url === `${environment.apiUrl}/almuerzos_empleado`);
    expect(request.request.method).toBe('GET');
    expect(request.request.params.getAll('fecha')).toEqual(['gte.2026-10-01', 'lte.2026-10-31']);
    expect(request.request.params.get('sucursal_id')).toBe('eq.2');
    expect(request.request.params.get('empleado_id')).toBe('eq.7');
    expect(request.request.params.get('order')).toBe('fecha.desc,id.desc');
    expect(request.request.params.get('select')).toContain('almuerzos_empleado_empleado_id_fkey');
    expect(request.request.params.get('select')).toContain('almuerzos_empleado_detalle');
    request.flush([]);

    await expect(result).resolves.toEqual([]);
  });

  it('lists every branch and employee when no filter is chosen', () => {
    service
      .listar({ sucursalId: null, empleadoId: null, desde: '2026-10-30', hasta: '2026-10-30' })
      .subscribe();

    const request = http.expectOne((req) => req.url === `${environment.apiUrl}/almuerzos_empleado`);
    expect(request.request.params.has('sucursal_id')).toBe(false);
    expect(request.request.params.has('empleado_id')).toBe(false);
    request.flush([]);
  });

  it('uses the Chilean date, not the UTC one', () => {
    // 22/10 a las 23:30 en Chile (UTC-3) ya es 23/10 en UTC.
    expect(fechaHoyChile(new Date('2026-10-23T02:30:00Z'))).toBe('2026-10-22');
    expect(fechaHoyChile(new Date('2026-10-23T03:30:00Z'))).toBe('2026-10-23');
  });
});
