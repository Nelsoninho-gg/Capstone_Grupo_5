import { TASA_IVA } from '../../../shared/utils/iva';
import { parsearFechaServidor } from '../../../shared/utils/fecha-servidor';
import { VentaDashboardApi } from '../../../core/api/ventas-api.service';

export type PeriodoDashboard = '1d' | '7d' | '30d' | '90d';
export type MetricaGrafico = 'ganancia' | 'ingresos';

/** Tiempo máximo de espera para las consultas del dashboard y del chat antes de avisar y dejar reintentar. */
export const TIEMPO_LIMITE_CONSULTA_MS = 30_000;

export interface KpiFinanciero {
  id: string;
  titulo: string;
  montoClp: number;
  /** Null cuando no hay ventas previas con las que comparar. */
  variacionPct: number | null;
  subtitulo: string;
  tono: 'positivo' | 'proyeccion';
}

export interface PuntoSerieTemporal {
  etiqueta: string;
  realClp: number | null;
  proyectadoClp: number | null;
}

export interface ResumenLineaNegocio {
  nombre: string;
  ventasClp: number;
  costoIngredientesClp: number;
  gananciaLimpiaClp: number;
  porcentajeGanancia: number;
  explicacionSimple: string;
}

export interface CompraConjuntaFrecuente {
  id: string;
  productoPrincipal: string;
  acompanamiento: string;
  horarioFrecuente: string;
  frecuenciaTexto: string;
  aparicionTexto: string;
  /** "el 27% del total" o "menos del 1% del total": nunca "el 0%". */
  soporteTexto: string;
  consejoPractico: string;
  /** Porcentaje del total de boletas que incluye ambos productos. */
  soportePct: number;
  /** Porcentaje de las boletas del principal que incluye el acompañamiento. */
  confianzaPct: number;
  /** Mayor que 1: se compran juntos más de lo esperable por azar. */
  lift: number;
  /** Alcanza el umbral (MIN_BOLETAS_RECOMENDACION y MIN_PORCENTAJE_RECOMENDACION) para recomendar una acción. */
  esRecomendable: boolean;
}

export interface ResumenProductoDestacado {
  producto: string;
  categoriaResumen: 'estrella' | 'margen-bajo' | 'baja-rotacion';
  tituloResumen: string;
  unidadesVendidas: number;
  /** Null cuando el producto no tiene costo registrado. */
  gananciaLimpiaClp: number | null;
  explicacionDueno: string;
  /** Top 5 de la categoría; el primero es el producto destacado. */
  ranking: readonly ProductoVendido[];
}

export interface BloqueDemandaHoraria {
  franja: string;
  etiqueta: string;
  ticketsPromedio: number;
  intensidadPct: number;
  esHoraPunta: boolean;
}

export interface ProductoVendido {
  producto: string;
  unidades: number;
  ventasClp: number;
  gananciaLimpiaClp: number | null;
}

export interface DemandaDiaSemana {
  dia: string;
  diaNumero: number;
  cantidadVentas: number;
  montoTotalClp: number;
  promedioVentaDiariaClp: number;
  /** Cuántas veces cayó este día de la semana en el período, hasta hoy (un mes puede tener dos lunes y un viernes). */
  vecesEnPeriodo: number;
  /** Solo suma productos con costo registrado. */
  gananciaTotalClp: number;
  promedioGananciaDiariaClp: number;
  /** El día con más venta en pesos sumando todo el período: el mismo criterio de la tarjeta y del chat. */
  esDiaMayorVenta: boolean;
}

export interface EscenarioDashboard {
  kpis: readonly KpiFinanciero[];
  serieGanancias: readonly PuntoSerieTemporal[];
  serieIngresos: readonly PuntoSerieTemporal[];
  lineasNegocio: readonly ResumenLineaNegocio[];
  comprasConjuntas: readonly CompraConjuntaFrecuente[];
  productosDestacados: readonly ResumenProductoDestacado[];
  demandaHoraria: readonly BloqueDemandaHoraria[];
  demandaPorDiaSemana: readonly DemandaDiaSemana[];
  /** Estado de la proyección de cierre; en "Hoy" puede no estar disponible por falta de historial. */
  proyeccion: ProyeccionCierre;
  productosMasVendidos: readonly ProductoVendido[];
}

export const PREGUNTAS_RAPIDAS: readonly string[] = [
  '¿Qué necesito comprar con urgencia?',
  '¿Qué es lo que más se vende?',
  '¿Qué es lo que menos se vende?',
  '¿Qué me está dejando más ganancia?',
  '¿En qué horario vendemos más?',
];

const DIA_MS = 24 * 60 * 60 * 1000;
// El IVA es el 19% del neto: neto = total ÷ 1,19 (antes se usaba × 0,81, que descontaba IVA de más).
export const PROPORCION_NETA = 1 / (1 + TASA_IVA);
const MAX_LINEAS_NEGOCIO = 5;
const MAX_PRODUCTOS_RANKING = 10;
const MAX_COMBOS = 3;
const MIN_REPETICIONES_COMBO = 2;
/**
 * Umbral para tratar un combo como recomendación (promoción o ubicación juntos).
 * Bajo esto se muestra igual, pero como dato para observar: con pocas boletas la afinidad puede ser casualidad.
 */
export const MIN_BOLETAS_RECOMENDACION = 5;
export const MIN_PORCENTAJE_RECOMENDACION = 1;

const FRANJAS_HORARIAS: readonly { franja: string; etiqueta: string; hastaMinuto: number }[] = [
  { franja: '08:00', etiqueta: 'Mañana', hastaMinuto: 630 },
  { franja: '10:30', etiqueta: 'Media mañana', hastaMinuto: 780 },
  { franja: '13:00', etiqueta: 'Almuerzo', hastaMinuto: 960 },
  { franja: '16:00', etiqueta: 'Tarde', hastaMinuto: 1110 },
  { franja: '18:30', etiqueta: 'Vespertino', hastaMinuto: 1230 },
  { franja: '20:30', etiqueta: 'Cierre', hastaMinuto: 1440 },
];

const TITULOS_PERIODO: Record<PeriodoDashboard, { total: string; cierre: string; detalle: string }> = {
  '1d': {
    total: 'Total vendido (hoy)',
    cierre: 'Con cuánto cerraremos hoy',
    detalle: 'hoy',
  },
  '7d': {
    total: 'Total vendido (esta semana)',
    cierre: 'Cierre estimado de esta semana',
    detalle: 'esta semana',
  },
  '30d': {
    total: 'Total vendido (este mes)',
    cierre: 'Con cuánto cerraremos este mes',
    detalle: 'este mes',
  },
  '90d': {
    total: 'Total vendido (este trimestre)',
    cierre: 'Con cuánto cerraremos el trimestre',
    detalle: 'este trimestre',
  },
};

export interface RangoPeriodo {
  inicio: Date;
  fin: Date;
  /** Inicio del tramo anterior, de igual duración a lo transcurrido del período. */
  inicioPrevio: Date;
  /** Fin exclusivo del tramo anterior. En el resto de los períodos coincide con `inicio`. */
  finPrevio: Date;
  diasTranscurridos: number;
  diasTotales: number;
}

/** Día en curso, semana lunes a domingo, mes y trimestre calendario, en la hora local del navegador. */
export function calcularRangoPeriodo(periodo: PeriodoDashboard, ahora: Date): RangoPeriodo {
  const anio = ahora.getFullYear();
  const mes = ahora.getMonth();
  const dia = ahora.getDate();
  let inicio: Date;
  let fin: Date;
  if (periodo === '1d') {
    inicio = new Date(anio, mes, dia);
    fin = new Date(anio, mes, dia + 1);
  } else if (periodo === '7d') {
    const lunes = dia - ((ahora.getDay() + 6) % 7);
    inicio = new Date(anio, mes, lunes);
    fin = new Date(anio, mes, lunes + 7);
  } else if (periodo === '30d') {
    inicio = new Date(anio, mes, 1);
    fin = new Date(anio, mes + 1, 1);
  } else {
    const inicioTrimestre = mes - (mes % 3);
    inicio = new Date(anio, inicioTrimestre, 1);
    fin = new Date(anio, inicioTrimestre + 3, 1);
  }
  const transcurrido = ahora.getTime() - inicio.getTime();
  // "Hoy" se compara contra ayer a la misma hora; el resto, contra el tramo anterior completo.
  const inicioPrevio =
    periodo === '1d' ? new Date(anio, mes, dia - 1) : new Date(inicio.getTime() - transcurrido);
  // Hora local, no milisegundos: en el cambio de hora oficial de Chile el día tiene 23 o 25 horas.
  const finPrevio =
    periodo === '1d'
      ? new Date(
          anio,
          mes,
          dia - 1,
          ahora.getHours(),
          ahora.getMinutes(),
          ahora.getSeconds(),
          ahora.getMilliseconds(),
        )
      : inicio;
  return {
    inicio,
    fin,
    inicioPrevio,
    finPrevio,
    diasTranscurridos: Math.max(1, Math.ceil(transcurrido / DIA_MS)),
    diasTotales: Math.round((fin.getTime() - inicio.getTime()) / DIA_MS),
  };
}

/** `ventas.fecha_venta` puede traer zona (`TIMESTAMPTZ`) o venir sin zona en UTC. */
function fechaDeVenta(venta: VentaDashboardApi): Date {
  return parsearFechaServidor(venta.fecha_venta);
}

interface LineaCalculada {
  productoId: number;
  producto: string;
  familia: string;
  unidades: number;
  montoClp: number;
  /** Null cuando no se conoce el costo: esa línea no suma a la ganancia. */
  costoClp: number | null;
  gananciaClp: number | null;
}

/** Costo de receta si existe; si no, precio de compra. Null si el producto no tiene costo registrado. */
export function costoUnitario(costoReceta: number | undefined, precioCompra: unknown): number | null {
  const costo = costoReceta || Number(precioCompra) || 0;
  return costo > 0 ? costo : null;
}

/**
 * Cuánto multiplicar lo acumulado para estimar el cierre, contando solo días operativos: los días
 * de la semana en que hubo ventas. Así una sede sin sábados no proyecta ventas en sábado.
 */
function calcularFactorCierre(rango: RangoPeriodo, ventas: readonly Date[], ahora: Date): number {
  const diasSemana = new Set(ventas.map((f) => f.getDay()));
  const esOperativo = (dia: Date) => diasSemana.size === 0 || diasSemana.has(dia.getDay());
  let totales = 0;
  let transcurridos = 0;
  for (let i = 0; i < rango.diasTotales; i++) {
    const dia = new Date(rango.inicio.getFullYear(), rango.inicio.getMonth(), rango.inicio.getDate() + i);
    if (esOperativo(dia)) {
      totales++;
      if (dia <= ahora) transcurridos++;
    }
  }
  return transcurridos > 0 ? totales / transcurridos : 1;
}

/** Mínimo de días anteriores del mismo día de la semana para poder proyectar el cierre de hoy. */
export const MINIMO_OCURRENCIAS_PROYECCION = 3;

/** Ventana de historial que se descarga para proyectar el cierre del día en curso. */
export const DIAS_HISTORIAL_PROYECCION = 28;

const NOMBRES_DIA = [
  'domingo',
  'lunes',
  'martes',
  'miércoles',
  'jueves',
  'viernes',
  'sábado',
] as const;

export type EstadoProyeccionCierre =
  | 'disponible'
  | 'historial-insuficiente'
  | 'sin-ventas-a-esta-hora'
  | 'sin-ventas-hoy';

/** Proyección del cierre del día en curso. `factor` vale 1 cuando no se puede proyectar. */
export interface ProyeccionCierre {
  estado: EstadoProyeccionCierre;
  factor: number;
  ocurrencias: number;
  minimoOcurrencias: number;
  /** Texto listo para mostrar: cifras del cálculo, nunca inventadas por la IA. */
  mensaje: string;
}

/**
 * Proyecta el cierre de hoy combinando lo vendido a esta hora con la misma hora de los días
 * anteriores del mismo día de la semana. Sin al menos MINIMO_OCURRENCIAS_PROYECCION días con
 * ventas no proyecta: lo informa explícitamente en vez de inventar una cifra.
 */
export function calcularProyeccionCierre(
  ventasAnteriores: readonly { fecha: Date; total: number }[],
  ahora: Date,
): ProyeccionCierre {
  const diaSemana = ahora.getDay();
  const nombreDia = NOMBRES_DIA[diaSemana];
  const inicioHoy = new Date(ahora.getFullYear(), ahora.getMonth(), ahora.getDate());
  const minutosAhora = ahora.getHours() * 60 + ahora.getMinutes();

  const porDia = new Map<string, { dia: Date; total: number; hastaAhora: number }>();
  for (const venta of ventasAnteriores) {
    if (venta.fecha >= inicioHoy) continue;
    const clave = `${venta.fecha.getFullYear()}-${venta.fecha.getMonth()}-${venta.fecha.getDate()}`;
    const dia = porDia.get(clave) ?? {
      dia: new Date(venta.fecha.getFullYear(), venta.fecha.getMonth(), venta.fecha.getDate()),
      total: 0,
      hastaAhora: 0,
    };
    dia.total += venta.total;
    if (venta.fecha.getHours() * 60 + venta.fecha.getMinutes() <= minutosAhora) {
      dia.hastaAhora += venta.total;
    }
    porDia.set(clave, dia);
  }

  const fracciones = [...porDia.values()]
    .filter((dia) => dia.dia.getDay() === diaSemana && dia.total > 0)
    .map((dia) => dia.hastaAhora / dia.total);

  if (fracciones.length < MINIMO_OCURRENCIAS_PROYECCION) {
    return {
      estado: 'historial-insuficiente',
      factor: 1,
      ocurrencias: fracciones.length,
      minimoOcurrencias: MINIMO_OCURRENCIAS_PROYECCION,
      mensaje:
        `Aún no hay días suficientes para proyectar el cierre de hoy: se necesitan al menos ` +
        `${MINIMO_OCURRENCIAS_PROYECCION} días anteriores de ${nombreDia} con ventas y hay ` +
        `${fracciones.length}.`,
    };
  }

  const promedio = fracciones.reduce((suma, valor) => suma + valor, 0) / fracciones.length;
  if (promedio <= 0) {
    return {
      estado: 'sin-ventas-a-esta-hora',
      factor: 1,
      ocurrencias: fracciones.length,
      minimoOcurrencias: MINIMO_OCURRENCIAS_PROYECCION,
      mensaje:
        `Los ${fracciones.length} días anteriores de ${nombreDia} no tuvieron ventas a esta ` +
        `hora, así que todavía no se puede proyectar el cierre de hoy.`,
    };
  }

  const porcentaje = Math.round(promedio * 100);
  const porcentajeTexto = porcentaje < 1 ? 'menos del 1' : `${porcentaje}`;
  // Techo de seguridad: un porcentaje muy pequeño del día no debe inflar la proyección sin límite.
  const factor = Math.min(1 / promedio, 100);
  return {
    estado: 'disponible',
    factor,
    ocurrencias: fracciones.length,
    minimoOcurrencias: MINIMO_OCURRENCIAS_PROYECCION,
    mensaje:
      `Proyección con ${fracciones.length} días anteriores de ${nombreDia}: a esta hora se ` +
      `llevaba en promedio el ${porcentajeTexto} % del día.`,
  };
}

/** Reparte el total cobrado entre las líneas, para respetar descuentos de la venta. */
function calcularLineas(
  venta: VentaDashboardApi,
  costosReceta: ReadonlyMap<number, number>,
): LineaCalculada[] {
  const sumaSubtotales = venta.detalle_venta.reduce((suma, d) => suma + Number(d.subtotal), 0);
  const factor = sumaSubtotales > 0 ? Number(venta.total) / sumaSubtotales : 0;

  return venta.detalle_venta.map((d) => {
    const unidades = Number(d.cantidad);
    const montoClp = Number(d.subtotal) * factor;
    const costo = costoUnitario(costosReceta.get(d.producto_id), d.productos?.precio_compra);
    const costoClp = costo === null ? null : costo * unidades;
    return {
      productoId: d.producto_id,
      producto: d.productos?.nombre ?? `Producto ${d.producto_id}`,
      familia: d.productos?.categoria?.split(' - ')[0]?.trim() || 'Sin categoría',
      unidades,
      montoClp,
      costoClp,
      gananciaClp: costoClp === null ? null : montoClp * PROPORCION_NETA - costoClp,
    };
  });
}

function variacion(actual: number, previo: number): number | null {
  return previo > 0 ? Math.round(((actual - previo) / previo) * 1000) / 10 : null;
}

function sumarGanancia(lineas: readonly LineaCalculada[]): number {
  return lineas.reduce((suma, l) => suma + (l.gananciaClp ?? 0), 0);
}

function sumarMonto(lineas: readonly LineaCalculada[]): number {
  return lineas.reduce((suma, l) => suma + l.montoClp, 0);
}

/** Posición del tramo del gráfico al que pertenece la fecha, y sus etiquetas hasta `ahora`. */
function tramosDelGrafico(
  periodo: PeriodoDashboard,
  inicio: Date,
  ahora: Date,
): { etiquetas: string[]; indice: (fecha: Date) => number } {
  const indice = (fecha: Date): number => {
    if (periodo === '1d') {
      return indiceFranja(fecha);
    }
    if (periodo === '7d') {
      return Math.floor((fecha.getTime() - inicio.getTime()) / DIA_MS);
    }
    if (periodo === '30d') {
      return Math.floor((fecha.getDate() - 1) / 7);
    }
    return fecha.getMonth() - inicio.getMonth();
  };
  const dias = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];
  const etiquetas = Array.from({ length: indice(ahora) + 1 }, (_, i) => {
    if (periodo === '1d') return FRANJAS_HORARIAS[i].etiqueta;
    if (periodo === '7d') return dias[i];
    if (periodo === '30d') return `Sem ${i + 1}`;
    return new Date(inicio.getFullYear(), inicio.getMonth() + i, 1).toLocaleDateString('es-CL', {
      month: 'short',
    });
  });
  return { etiquetas, indice };
}

/** Serie acumulada: la línea real termina en lo vendido y la punteada en el cierre estimado. */
function construirSerie(
  etiquetas: readonly string[],
  valoresPorTramo: readonly number[],
  cierreEstimado: number,
): PuntoSerieTemporal[] {
  let acumulado = 0;
  const puntos: PuntoSerieTemporal[] = etiquetas.map((etiqueta, i) => {
    acumulado += valoresPorTramo[i] ?? 0;
    return {
      etiqueta,
      realClp: Math.round(acumulado),
      proyectadoClp: i === etiquetas.length - 1 ? Math.round(acumulado) : null,
    };
  });
  puntos.push({
    etiqueta: 'Cierre (Est.)',
    realClp: null,
    proyectadoClp: Math.round(cierreEstimado),
  });
  return puntos;
}

/** Lo que muestra la tarjeta de proyección: lo acumulado, el cierre y cuánto aportó cada tramo. */
export interface TramoProyeccion {
  etiqueta: string;
  valorClp: number;
  alturaPct: number;
  estimado: boolean;
}

export interface VistaProyeccion {
  acumuladoClp: number;
  cierreClp: number;
  avancePct: number;
  tramos: TramoProyeccion[];
}

/** No recalcula el cierre: solo reparte en tramos la serie acumulada que ya calculó el algoritmo. */
export function construirVistaProyeccion(serie: readonly PuntoSerieTemporal[]): VistaProyeccion {
  const reales = serie.filter((p) => p.realClp !== null);
  const acumuladoClp = reales.at(-1)?.realClp ?? 0;
  const cierreClp = serie.at(-1)?.proyectadoClp ?? acumuladoClp;
  const valores = reales.map((p, i) => ({
    etiqueta: p.etiqueta,
    valorClp: (p.realClp ?? 0) - (reales[i - 1]?.realClp ?? 0),
    estimado: false,
  }));
  if (cierreClp > acumuladoClp) {
    valores.push({ etiqueta: 'Proyección', valorClp: cierreClp - acumuladoClp, estimado: true });
  }
  const maximo = Math.max(1, ...valores.map((t) => t.valorClp));
  return {
    acumuladoClp,
    cierreClp,
    avancePct: cierreClp > 0 ? Math.min(100, Math.max(0, Math.round((acumuladoClp / cierreClp) * 100))) : 0,
    tramos: valores.map((t) => ({ ...t, alturaPct: (Math.max(0, t.valorClp) / maximo) * 100 })),
  };
}

function construirLineasNegocio(lineas: readonly LineaCalculada[]): ResumenLineaNegocio[] {
  const familias = new Map<string, LineaCalculada[]>();
  for (const linea of lineas) {
    familias.set(linea.familia, [...(familias.get(linea.familia) ?? []), linea]);
  }
  return [...familias.entries()]
    .map(([nombre, grupo]) => {
      const conCosto = grupo.filter((l) => l.costoClp !== null);
      const ventasConCosto = sumarMonto(conCosto);
      const ganancia = sumarGanancia(conCosto);
      const porcentaje = ventasConCosto > 0 ? Math.round((ganancia / ventasConCosto) * 100) : 0;
      return {
        nombre,
        ventasClp: Math.round(sumarMonto(grupo)),
        costoIngredientesClp: Math.round(conCosto.reduce((s, l) => s + (l.costoClp ?? 0), 0)),
        gananciaLimpiaClp: Math.round(ganancia),
        porcentajeGanancia: Math.min(100, Math.max(0, porcentaje)),
        explicacionSimple:
          conCosto.length > 0
            ? `De cada $1.000 vendidos con costo registrado, quedan $${porcentaje * 10} de ganancia limpia.`
            : 'Estos productos no tienen costo registrado; no se puede calcular su ganancia.',
      };
    })
    .sort((a, b) => b.ventasClp - a.ventasClp)
    .slice(0, MAX_LINEAS_NEGOCIO);
}

function indiceFranja(fecha: Date): number {
  const minuto = fecha.getHours() * 60 + fecha.getMinutes();
  return FRANJAS_HORARIAS.findIndex((f) => minuto < f.hastaMinuto);
}

function construirDemandaHoraria(fechas: readonly Date[]): BloqueDemandaHoraria[] {
  const tickets = FRANJAS_HORARIAS.map(() => 0);
  for (const fecha of fechas) {
    tickets[indiceFranja(fecha)]++;
  }
  const diasConVentas = Math.max(1, new Set(fechas.map((f) => f.toDateString())).size);
  const maximo = Math.max(...tickets, 1);
  return FRANJAS_HORARIAS.map((f, i) => ({
    franja: f.franja,
    etiqueta: f.etiqueta,
    ticketsPromedio: Math.round((tickets[i] / diasConVentas) * 10) / 10,
    intensidadPct: Math.round((tickets[i] / maximo) * 100),
    esHoraPunta: tickets[i] > 0 && tickets[i] >= maximo * 0.8,
  }));
}

export const DIAS_SEMANA_ORDEN: readonly { diaNumero: number; dia: string; jsDay: number }[] = [
  { diaNumero: 1, dia: 'Lunes', jsDay: 1 },
  { diaNumero: 2, dia: 'Martes', jsDay: 2 },
  { diaNumero: 3, dia: 'Miércoles', jsDay: 3 },
  { diaNumero: 4, dia: 'Jueves', jsDay: 4 },
  { diaNumero: 5, dia: 'Viernes', jsDay: 5 },
  { diaNumero: 6, dia: 'Sábado', jsDay: 6 },
  { diaNumero: 7, dia: 'Domingo', jsDay: 0 },
];

function contarOcurrenciasDia(rango: RangoPeriodo, ahora: Date): Map<number, number> {
  const conteo = new Map<number, number>();
  const limite = ahora < rango.fin ? ahora : rango.fin;
  const cursor = new Date(rango.inicio.getFullYear(), rango.inicio.getMonth(), rango.inicio.getDate());
  while (cursor <= limite) {
    const jsDay = cursor.getDay();
    conteo.set(jsDay, (conteo.get(jsDay) ?? 0) + 1);
    cursor.setDate(cursor.getDate() + 1);
  }
  return conteo;
}

export function construirDemandaDiaSemana(
  actuales: readonly { fecha: Date; total: number; ganancia?: number }[],
  rango: RangoPeriodo,
  ahora: Date,
): DemandaDiaSemana[] {
  const ocurrencias = contarOcurrenciasDia(rango, ahora);
  const ticketsPorDia = new Map<number, number>();
  const montoPorDia = new Map<number, number>();
  const gananciaPorDia = new Map<number, number>();

  for (const { fecha, total, ganancia = 0 } of actuales) {
    const jsDay = fecha.getDay();
    ticketsPorDia.set(jsDay, (ticketsPorDia.get(jsDay) ?? 0) + 1);
    montoPorDia.set(jsDay, (montoPorDia.get(jsDay) ?? 0) + total);
    gananciaPorDia.set(jsDay, (gananciaPorDia.get(jsDay) ?? 0) + ganancia);
  }

  const dias = DIAS_SEMANA_ORDEN.map((item) => {
    const monto = Math.round(montoPorDia.get(item.jsDay) ?? 0);
    const ganancia = Math.round(gananciaPorDia.get(item.jsDay) ?? 0);
    const veces = Math.max(1, ocurrencias.get(item.jsDay) ?? 1);
    return {
      dia: item.dia,
      diaNumero: item.diaNumero,
      cantidadVentas: ticketsPorDia.get(item.jsDay) ?? 0,
      vecesEnPeriodo: ocurrencias.get(item.jsDay) ?? 0,
      montoTotalClp: monto,
      promedioVentaDiariaClp: Math.round(monto / veces),
      gananciaTotalClp: ganancia,
      promedioGananciaDiariaClp: Math.round(ganancia / veces),
      esDiaMayorVenta: false,
    };
  });
  const maximo = Math.max(0, ...dias.map((d) => d.montoTotalClp));
  // Ante un empate queda marcado el primero de la semana, para destacar siempre un solo día.
  const mayor = dias.find((d) => maximo > 0 && d.montoTotalClp === maximo);
  return dias.map((d) => ({ ...d, esDiaMayorVenta: d === mayor }));
}

export interface ColumnaDiaSemana extends DemandaDiaSemana {
  /** Nombre corto para el eje: "Lun", "Mar"… */
  etiqueta: string;
  /** Suma del período de la métrica elegida (total vendido o ganancia limpia). */
  valorClp: number;
  /** "2 lunes", "1 sábado": para ver que la suma depende de cuántas veces cayó el día. */
  vecesTexto: string;
  alturaPct: number;
  esMayor: boolean;
}

/** "2 lunes", "1 sábado", "3 domingos": los días terminados en "s" no cambian en plural. */
export function textoVecesDia(dia: string, veces: number): string {
  const nombre = dia.toLowerCase();
  return `${veces} ${veces === 1 || nombre.endsWith('s') ? nombre : nombre + 's'}`;
}

/** Columnas de la tarjeta «Ventas por día de la semana»: la altura sigue a la suma del período de la métrica elegida. */
export function construirVistaDiasSemana(
  dias: readonly DemandaDiaSemana[],
  metrica: MetricaGrafico = 'ingresos',
): ColumnaDiaSemana[] {
  const valorDe = (d: DemandaDiaSemana) =>
    metrica === 'ganancia' ? d.gananciaTotalClp : d.montoTotalClp;
  const maximo = Math.max(0, ...dias.map(valorDe));
  const mayor = dias.find((d) => maximo > 0 && valorDe(d) === maximo);
  return dias.map((d) => ({
    ...d,
    valorClp: valorDe(d),
    vecesTexto: textoVecesDia(d.dia, d.vecesEnPeriodo),
    etiqueta: d.dia.slice(0, 3),
    // Una ganancia negativa no tiene altura: se ve su valor, no una barra hacia abajo.
    alturaPct: maximo > 0 ? (Math.max(0, valorDe(d)) / maximo) * 100 : 0,
    esMayor: d === mayor,
  }));
}

function construirProductos(lineas: readonly LineaCalculada[]): ProductoVendido[] {
  const productos = new Map<number, ProductoVendido>();
  for (const l of lineas) {
    const previo = productos.get(l.productoId);
    productos.set(l.productoId, {
      producto: l.producto,
      unidades: (previo?.unidades ?? 0) + l.unidades,
      ventasClp: (previo?.ventasClp ?? 0) + l.montoClp,
      gananciaLimpiaClp:
        l.gananciaClp === null
          ? (previo?.gananciaLimpiaClp ?? null)
          : (previo?.gananciaLimpiaClp ?? 0) + l.gananciaClp,
    });
  }
  return [...productos.values()]
    .map((p) => ({
      ...p,
      ventasClp: Math.round(p.ventasClp),
      gananciaLimpiaClp: p.gananciaLimpiaClp === null ? null : Math.round(p.gananciaLimpiaClp),
    }))
    .sort((a, b) => b.unidades - a.unidades || b.ventasClp - a.ventasClp);
}

function construirDestacados(productos: readonly ProductoVendido[]): ResumenProductoDestacado[] {
  const estrella = productos[0];
  if (!estrella) return [];

  const destacados: ResumenProductoDestacado[] = [
    {
      producto: estrella.producto,
      categoriaResumen: 'estrella',
      tituloResumen: 'El que más se vende',
      unidadesVendidas: estrella.unidades,
      gananciaLimpiaClp: estrella.gananciaLimpiaClp,
      explicacionDueno: 'Es el producto con más unidades vendidas en el período; cuida que no falte.',
      ranking: productos.slice(0, 5),
    },
  ];

  const margen = (p: ProductoVendido) => (p.gananciaLimpiaClp ?? 0) / Math.max(p.ventasClp, 1);
  const porMargen = productos
    .filter((p) => p !== estrella && p.gananciaLimpiaClp !== null)
    .sort((a, b) => margen(a) - margen(b));
  const margenBajo = porMargen[0];
  if (margenBajo) {
    destacados.push({
      producto: margenBajo.producto,
      categoriaResumen: 'margen-bajo',
      tituloResumen: 'El que deja menos ganancia',
      unidadesVendidas: margenBajo.unidades,
      gananciaLimpiaClp: margenBajo.gananciaLimpiaClp,
      explicacionDueno: 'Tiene el margen más bajo entre los productos con costo; revisa su precio o costo.',
      ranking: porMargen.slice(0, 5),
    });
  }

  const porMenosVendido = productos.filter((p) => p !== estrella && p !== margenBajo).reverse();
  const bajaRotacion = porMenosVendido[0];
  if (bajaRotacion) {
    destacados.push({
      producto: bajaRotacion.producto,
      categoriaResumen: 'baja-rotacion',
      tituloResumen: 'El que menos se vende',
      unidadesVendidas: bajaRotacion.unidades,
      gananciaLimpiaClp: bajaRotacion.gananciaLimpiaClp,
      explicacionDueno: 'Es el vendido con menos unidades en el período; prepara o exhibe menos cantidad.',
      ranking: porMenosVendido.slice(0, 5),
    });
  }
  return destacados;
}

/** Cómo se dice cada franja dentro de una frase: «al cierre», no «en la cierre». */
const MOMENTO_FRANJA: Record<string, string> = {
  Mañana: 'en la mañana',
  'Media mañana': 'a media mañana',
  Almuerzo: 'al almuerzo',
  Tarde: 'en la tarde',
  Vespertino: 'en el horario vespertino',
  Cierre: 'al cierre',
};

function maximoComunDivisor(a: number, b: number): number {
  return b === 0 ? a : maximoComunDivisor(b, a % b);
}

/** Hasta "de cada 10" la fracción se entiende de un vistazo; más allá se dice la cantidad real. */
const MAX_DENOMINADOR_FRACCION = 10;

/**
 * "4 de cada 6 boletas" se lee mejor como "2 de cada 3": la fracción se reduce, sin redondear.
 * Si no queda chica ("3 de cada 1100"), se dicen las cantidades: "3 de las 1.100 boletas del período".
 */
export function textoAparicion(veces: number, totalBoletas: number): string {
  if (totalBoletas === veces) return 'todas las boletas del período';
  const divisor = maximoComunDivisor(veces, totalBoletas) || 1;
  const denominador = totalBoletas / divisor;
  return denominador <= MAX_DENOMINADOR_FRACCION
    ? `${veces / divisor} de cada ${denominador} boletas`
    : `${veces.toLocaleString('es-CL')} de las ${totalBoletas.toLocaleString('es-CL')} boletas del período`;
}

/**
 * Por qué un combo no alcanza para recomendar, con el dato que falla: pocas veces juntos, poco peso en el total, o ambos.
 * "Todavía es poco frecuente: se compraron juntos solo 3 veces en el período, menos del 1% de las 1.101 boletas."
 */
export function textoPocoFrecuente(veces: number, totalBoletas: number): string {
  const vecesTexto = `${veces.toLocaleString('es-CL')} ${veces === 1 ? 'vez' : 'veces'}`;
  const pocasVeces = veces < MIN_BOLETAS_RECOMENDACION;
  const pocoPeso = totalBoletas > 0 && (veces / totalBoletas) * 100 < MIN_PORCENTAJE_RECOMENDACION;
  const motivo =
    `se compraron juntos ${pocasVeces ? 'solo ' : ''}${vecesTexto} en el período` +
    (pocoPeso
      ? `, menos del ${MIN_PORCENTAJE_RECOMENDACION}% de las ${totalBoletas.toLocaleString('es-CL')} boletas`
      : '');
  return (
    `Todavía es poco frecuente: ${motivo}. Para recomendar una promoción hacen falta al menos ` +
    `${MIN_BOLETAS_RECOMENDACION} boletas juntos y el ${MIN_PORCENTAJE_RECOMENDACION}% del total.`
  );
}

/** Porcentaje del total sin mostrar "el 0%" cuando el combo sí aparece, aunque sea poco. */
export function textoSoporte(veces: number, totalBoletas: number): string {
  const pct = totalBoletas > 0 ? (veces / totalBoletas) * 100 : 0;
  return veces > 0 && pct < 1 ? 'menos del 1% del total' : `el ${Math.round(pct)}% del total`;
}

function construirCombos(
  ventas: readonly { fecha: Date; lineas: readonly LineaCalculada[] }[],
): CompraConjuntaFrecuente[] {
  const boletasPorProducto = new Map<string, number>();
  const pares = new Map<string, { a: string; b: string; veces: number; franjas: number[] }>();

  for (const { fecha, lineas } of ventas) {
    const nombres = [...new Set(lineas.map((l) => l.producto))].sort();
    for (const nombre of nombres) {
      boletasPorProducto.set(nombre, (boletasPorProducto.get(nombre) ?? 0) + 1);
    }
    nombres.forEach((a, i) => {
      for (const b of nombres.slice(i + 1)) {
        const clave = `${a}|${b}`;
        const par = pares.get(clave) ?? { a, b, veces: 0, franjas: [] };
        par.veces++;
        par.franjas.push(indiceFranja(fecha));
        pares.set(clave, par);
      }
    });
  }

  const totalBoletas = ventas.length;
  const liftDe = (par: { a: string; b: string; veces: number }) =>
    (par.veces * totalBoletas) / ((boletasPorProducto.get(par.a) ?? 1) * (boletasPorProducto.get(par.b) ?? 1));

  const recomendable = (par: { veces: number }) =>
    par.veces >= MIN_BOLETAS_RECOMENDACION && (par.veces / totalBoletas) * 100 >= MIN_PORCENTAJE_RECOMENDACION;

  return [...pares.entries()]
    .filter(([, par]) => par.veces >= MIN_REPETICIONES_COMBO && liftDe(par) >= 1)
    // Primero los que alcanzan para recomendar; dentro de cada grupo, los más repetidos.
    .sort(
      ([, x], [, y]) =>
        Number(recomendable(y)) - Number(recomendable(x)) || y.veces - x.veces || liftDe(y) - liftDe(x),
    )
    .slice(0, MAX_COMBOS)
    .map(([clave, par]) => {
      const [principal, acompanamiento] =
        (boletasPorProducto.get(par.a) ?? 0) >= (boletasPorProducto.get(par.b) ?? 0)
          ? [par.a, par.b]
          : [par.b, par.a];
      const boletasPrincipal = boletasPorProducto.get(principal) ?? 1;
      const franja = par.franjas
        .slice()
        .sort(
          (x, y) =>
            par.franjas.filter((f) => f === y).length - par.franjas.filter((f) => f === x).length,
        )[0];
      return {
        id: clave,
        productoPrincipal: principal,
        acompanamiento,
        horarioFrecuente: `${MOMENTO_FRANJA[FRANJAS_HORARIAS[franja].etiqueta] ?? 'en ese horario'}, desde las ${FRANJAS_HORARIAS[franja].franja} hrs`,
        // Dos totales distintos en el detalle: aquí, solo las boletas del producto principal; en aparicionTexto, todas las del período.
        frecuenciaTexto: `De las ${boletasPrincipal.toLocaleString('es-CL')} boletas que llevan ${principal}, ${par.veces.toLocaleString('es-CL')} también llevan ${acompanamiento}.`,
        aparicionTexto: textoAparicion(par.veces, totalBoletas),
        soporteTexto: textoSoporte(par.veces, totalBoletas),
        consejoPractico: recomendable(par)
          ? 'Tenerlos a mano juntos o armar una promoción puede subir el monto de la boleta.'
          : textoPocoFrecuente(par.veces, totalBoletas),
        esRecomendable: recomendable(par),
        soportePct: Math.round((par.veces / totalBoletas) * 100),
        confianzaPct: Math.round((par.veces / boletasPrincipal) * 100),
        lift: Math.round(liftDe(par) * 100) / 100,
      };
    });
}

/**
 * Convierte las ventas vigentes (período actual y tramo previo) en lo que muestra el dashboard.
 * Ganancia limpia = neto de IVA menos costo, solo en productos con costo registrado.
 * Los mismos datos entregan siempre el mismo resultado.
 */
export function construirEscenario(
  ventas: readonly VentaDashboardApi[],
  costosReceta: ReadonlyMap<number, number>,
  periodo: PeriodoDashboard,
  ahora: Date,
): EscenarioDashboard {
  const rango = calcularRangoPeriodo(periodo, ahora);
  const calculadas = ventas.map((venta) => ({
    fecha: fechaDeVenta(venta),
    lineas: calcularLineas(venta, costosReceta),
    total: Number(venta.total),
    tipoVenta: venta.tipo_venta,
  }));
  const actuales = calculadas.filter((v) => v.fecha >= rango.inicio && v.fecha <= ahora);
  const previas = calculadas.filter((v) => v.fecha >= rango.inicioPrevio && v.fecha < rango.finPrevio);
  // Las ventas a empleados llevan descuento y distorsionan el análisis de clientes, pero sí suman a caja y ganancia.
  const deClientes = actuales.filter((v) => v.tipoVenta !== 'empleado');

  const lineas = actuales.flatMap((v) => v.lineas);
  const lineasClientes = deClientes.flatMap((v) => v.lineas);
  const totalVendido = actuales.reduce((suma, v) => suma + v.total, 0);
  const totalPrevio = previas.reduce((suma, v) => suma + v.total, 0);
  const ganancia = sumarGanancia(lineas);
  const gananciaPrevia = sumarGanancia(previas.flatMap((v) => v.lineas));
  const proyeccionHistorico: ProyeccionCierre =
    periodo === '1d'
      ? calcularProyeccionCierre(
          calculadas
            .filter((v) => v.fecha < rango.inicio)
            .map((v) => ({ fecha: v.fecha, total: v.total })),
          ahora,
        )
      : {
          estado: 'disponible',
          factor: calcularFactorCierre(rango, calculadas.map((v) => v.fecha), ahora),
          ocurrencias: 0,
          minimoOcurrencias: 0,
          mensaje: '',
        };
  // Sin ventas todavía hoy no hay nada que proyectar: cero pesos no es una proyección de cierre.
  const proyeccion: ProyeccionCierre =
    periodo === '1d' && actuales.length === 0
      ? {
          ...proyeccionHistorico,
          estado: 'sin-ventas-hoy',
          factor: 1,
          mensaje:
            'Todavía no hay ventas registradas hoy, así que aún no se puede proyectar el cierre.',
        }
      : proyeccionHistorico;
  const factorCierre = proyeccion.estado === 'disponible' ? proyeccion.factor : 1;
  const titulos = TITULOS_PERIODO[periodo];

  const productos = construirProductos(lineasClientes);
  const sinCosto = new Set(lineas.filter((l) => l.costoClp === null).map((l) => l.productoId)).size;
  const notaCostos = sinCosto > 0 ? ` · Productos sin costo que no suman: ${sinCosto}` : '';

  const { etiquetas, indice } = tramosDelGrafico(periodo, rango.inicio, ahora);
  const ingresosPorTramo = etiquetas.map(() => 0);
  const gananciaPorTramo = etiquetas.map(() => 0);
  for (const venta of actuales) {
    const i = indice(venta.fecha);
    ingresosPorTramo[i] += venta.total;
    gananciaPorTramo[i] += sumarGanancia(venta.lineas);
  }

  return {
    kpis: [
      {
        id: 'ingresos',
        titulo: titulos.total,
        montoClp: Math.round(totalVendido),
        variacionPct: variacion(totalVendido, totalPrevio),
        subtitulo: `Ventas realizadas ${titulos.detalle}: ${actuales.length}`,
        tono: 'positivo',
      },
      {
        id: 'ganancia-neta',
        titulo: 'Ganancia limpia acumulada',
        montoClp: Math.round(ganancia),
        variacionPct: variacion(ganancia, gananciaPrevia),
        subtitulo: `Descontando costo e IVA${notaCostos}`,
        tono: 'positivo',
      },
      // Sin proyección disponible el KPI de cierre no viaja al asistente: si esa cifra llegara al
      // resultado de la herramienta, el verificador de cifras la aceptaría como un cierre calculado.
      ...(proyeccion.estado === 'disponible'
        ? [
            {
              id: 'proyeccion-ia',
              titulo: titulos.cierre,
              montoClp: Math.round(ganancia * factorCierre),
              variacionPct: null,
              subtitulo: 'Ganancia limpia estimada si seguimos al ritmo actual',
              tono: 'proyeccion',
            } satisfies KpiFinanciero,
          ]
        : []),
    ],
    serieGanancias: construirSerie(etiquetas, gananciaPorTramo, ganancia * factorCierre),
    serieIngresos: construirSerie(etiquetas, ingresosPorTramo, totalVendido * factorCierre),
    lineasNegocio: construirLineasNegocio(lineasClientes),
    comprasConjuntas: construirCombos(deClientes),
    productosDestacados: construirDestacados(productos),
    demandaHoraria: construirDemandaHoraria(deClientes.map((v) => v.fecha)),
    demandaPorDiaSemana: construirDemandaDiaSemana(
      deClientes.map((v) => ({ fecha: v.fecha, total: v.total, ganancia: sumarGanancia(v.lineas) })),
      rango,
      ahora,
    ),
    proyeccion,
    productosMasVendidos: productos.slice(0, MAX_PRODUCTOS_RANKING),
  };
}

export interface ItemCatalogoEstado {
  nombre: string;
  tipo: 'producto' | 'materia_prima';
  categoria: string;
  activo: boolean;
}

export interface MadurezDatosDashboard {
  diasRegistrados: number;
  umbralDias: number; // 28
  diasFaltantes: number;
  esPreliminar: boolean;
  mensajeBanner: string;
}

export function calcularMadurezDashboard(
  diasRegistrados: number,
  contextoNombre = 'la red de cafeterías',
): MadurezDatosDashboard {
  const umbralDias = 28;
  const diasValidos = Math.max(0, diasRegistrados);
  const diasFaltantes = Math.max(0, umbralDias - diasValidos);
  const esPreliminar = diasValidos < umbralDias;
  const mensajeBanner = esPreliminar
    ? `Información preliminar en ${contextoNombre}: los datos de ventas, horarios y consumo corresponden a los últimos ${diasValidos} días registrados. Aún no hay registros suficientes para sacar conclusiones definitivas hasta cumplir los ${diasFaltantes} días faltantes para las 4 semanas de ventas (28 días).`
    : `Historial consolidado en ${contextoNombre}: los análisis reflejan un ciclo completo superior a 28 días de ventas (${diasValidos} días registrados).`;

  return {
    diasRegistrados: diasValidos,
    umbralDias,
    diasFaltantes,
    esPreliminar,
    mensajeBanner,
  };
}

/** Texto de "actualizado hace…" del Dashboard; se recalcula con un reloj propio de la pantalla. */
export function textoActualizado(desde: Date | null, ahora: Date): string {
  if (!desde) return 'Sin actualizar';
  const segundos = Math.max(0, Math.floor((ahora.getTime() - desde.getTime()) / 1000));
  if (segundos < 60) return 'Actualizado justo ahora';
  const minutos = Math.floor(segundos / 60);
  if (minutos < 60) return `Actualizado hace ${minutos} ${minutos === 1 ? 'minuto' : 'minutos'}`;
  const horas = Math.floor(minutos / 60);
  return `Actualizado hace ${horas} ${horas === 1 ? 'hora' : 'horas'}`;
}
