import {
  ArticuloPorComprar,
  contarMotivos,
  hojaCompras,
  motivoCompra,
  planillaCompras,
} from './compras.model';

const pan: ArticuloPorComprar = {
  id: 'materia_prima-1-1',
  articuloId: 1,
  articulo: 'Pan amasado',
  tipo: 'materia_prima',
  unidad: 'kg',
  sucursalId: 1,
  sucursal: 'Nury Providencia',
  stock: 6,
  minimo: 10,
  vendido: 17.5,
  consumoDiario: 2.5,
  objetivo: 12.5,
  sugerido: 6.5,
};

describe('motivoCompra', () => {
  it.each([
    ['sin stock', { stock: 0 }, 'agotado'],
    ['en negativo', { stock: -1, minimo: 0 }, 'agotado'],
    ['bajo el mínimo', { stock: 6 }, 'bajo-minimo'],
    ['sobre el mínimo pero sin alcanzar para mañana', { stock: 11 }, 'consumo'],
    ['justo en el mínimo', { stock: 10 }, 'consumo'],
  ] as const)('%s', (_caso, cambio, esperado) => {
    expect(motivoCompra({ ...pan, ...cambio })).toBe(esperado);
  });
});

describe('contarMotivos', () => {
  it('counts each reason and the total', () => {
    expect(contarMotivos([pan, { ...pan, stock: 0 }, { ...pan, stock: 11 }, pan])).toEqual({
      total: 4,
      agotado: 1,
      'bajo-minimo': 2,
      consumo: 1,
    });
  });
});

describe('planillaCompras', () => {
  it('builds a semicolon CSV with decimal comma for Excel', () => {
    const bebida: ArticuloPorComprar = {
      ...pan,
      id: 'producto-4-1',
      articuloId: 4,
      articulo: 'Bebida "Chaparrita"; 500 ml',
      tipo: 'producto',
      unidad: 'un',
      stock: 0,
      minimo: 5,
      vendido: 2,
      consumoDiario: 0.286,
      objetivo: 5.286,
      sugerido: 6,
    };
    expect(planillaCompras([pan, bebida], 7).split('\r\n')).toEqual([
      'Sucursal;Artículo;Tipo;Unidad;Stock actual;Mínimo;Vendido (7 días);Comprar;Motivo',
      'Nury Providencia;Pan amasado;Materia prima;kg;6;10;17,5;6,5;Bajo el mínimo',
      'Nury Providencia;"Bebida ""Chaparrita""; 500 ml";Producto;un;0;5;2;6;Agotado',
    ]);
  });

  it('does not group thousands, so Excel reads them as numbers', () => {
    const linea = planillaCompras([{ ...pan, stock: 1250.5, sugerido: 1500 }], 7).split('\r\n')[1];
    expect(linea).toContain(';1250,5;');
    expect(linea).toContain(';1500;');
  });

  it('leaves only the header when there is nothing to buy', () => {
    expect(planillaCompras([], 1)).toBe(
      'Sucursal;Artículo;Tipo;Unidad;Stock actual;Mínimo;Vendido (último día);Comprar;Motivo',
    );
  });
});

describe('hojaCompras', () => {
  it('keeps the numbers as numbers and highlights the amount to buy', () => {
    const hoja = hojaCompras([pan], 7);
    expect(hoja.nombre).toBe('Por comprar');
    expect(hoja.columnas.map((columna) => columna.titulo)).toEqual([
      'Sucursal',
      'Artículo',
      'Tipo',
      'Unidad',
      'Stock actual',
      'Mínimo',
      'Vendido (7 días)',
      'Comprar',
      'Motivo',
    ]);
    expect(hoja.columnas.find((columna) => columna.destacada)?.titulo).toBe('Comprar');
    expect(hoja.filas).toEqual([
      [
        'Nury Providencia',
        'Pan amasado',
        'Materia prima',
        'kg',
        6,
        10,
        17.5,
        6.5,
        'Bajo el mínimo',
      ],
    ]);
  });
});
