import { Injectable, inject } from '@angular/core';
import { IA_RELOJ } from '../../../core/ia/proveedores-ia.config';
import { SalidaPrediccionIA } from '../models/prediccion-ia.contract';

export const TTL_CACHE_PREDICCION_DEFAULT_MS = 4 * 60 * 60 * 1000; // 4 horas

interface EntradaCache {
  sucursalId: string;
  valor: SalidaPrediccionIA;
  expiraEn: number;
}

/**
 * Servicio de caché con TTL para almacenar predicciones de IA y optimizar el uso de cuotas gratuitas (H4.5 T07).
 */
@Injectable({ providedIn: 'root' })
export class PredictiveCacheService {
  private readonly reloj = inject(IA_RELOJ);
  private readonly entradas = new Map<string, EntradaCache>();

  /**
   * Construye una clave canónica para indexar las predicciones por sucursal, fecha y conjunto de artículos.
   */
  construirClave(
    sucursalId: number | string,
    fechaReferencia: string,
    articulosIds: readonly string[],
  ): string {
    const ordenados = [...articulosIds].sort().join(',');
    return `${sucursalId}|${fechaReferencia}|${ordenados}`;
  }

  /**
   * Obtiene la predicción almacenada si existe y no ha expirado su TTL.
   */
  obtener(clave: string): SalidaPrediccionIA | null {
    const entrada = this.entradas.get(clave);
    if (!entrada) {
      return null;
    }
    const ahora = this.reloj();
    if (ahora >= entrada.expiraEn) {
      this.entradas.delete(clave);
      return null;
    }
    return {
      predicciones: entrada.valor.predicciones.map((p) => ({ ...p })),
    };
  }

  /**
   * Guarda una predicción en caché con TTL en milisegundos (4 horas por defecto).
   */
  guardar(
    clave: string,
    sucursalId: number | string,
    valor: SalidaPrediccionIA,
    ttlMs: number = TTL_CACHE_PREDICCION_DEFAULT_MS,
  ): void {
    const ahora = this.reloj();
    this.entradas.set(clave, {
      sucursalId: String(sucursalId),
      valor: {
        predicciones: valor.predicciones.map((p) => ({ ...p })),
      },
      expiraEn: ahora + ttlMs,
    });
  }

  /**
   * Invalida todas las predicciones de una sucursal específica (útil tras ajustes de stock o ventas masivas).
   */
  invalidarSucursal(sucursalId: number | string): void {
    const idStr = String(sucursalId);
    for (const [clave, entrada] of this.entradas.entries()) {
      if (entrada.sucursalId === idStr) {
        this.entradas.delete(clave);
      }
    }
  }

  /**
   * Elimina todas las entradas de caché.
   */
  limpiar(): void {
    this.entradas.clear();
  }

  /**
   * Cantidad de entradas vigentes (purga las expiradas en la consulta).
   */
  tamano(): number {
    const ahora = this.reloj();
    for (const [clave, entrada] of this.entradas.entries()) {
      if (ahora >= entrada.expiraEn) {
        this.entradas.delete(clave);
      }
    }
    return this.entradas.size;
  }
}
