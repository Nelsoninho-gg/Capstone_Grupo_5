import { Injectable, inject } from '@angular/core';
import { Observable, forkJoin, map, of, throwError } from 'rxjs';
import { RecetasApiService } from '../../../core/api/recetas-api.service';
import {
  AjusteManualApi,
  ArticuloPorComprarApi,
  StockApiService,
  StockIngredienteApi,
  StockProductoApi,
  VersionInventarioApi,
} from '../../../core/api/stock-api.service';
import { User } from '../../auth/models/auth.model';
import { AuthService } from '../../auth/services/auth.service';
import {
  AjusteStock,
  ExistenciaStock,
  FiltroMermas,
  TipoArticulo,
  claveExistencia,
  validarMinimo,
} from '../models/inventario.model';
import { ArticuloPorComprar } from '../models/compras.model';
import { MinimoRechazadoError, MinimoSinFilaError } from '../models/fallo-minimo';

/** Los productos no tienen unidad de medida en la base: se cuentan por unidad. */
const UNIDAD_PRODUCTO = 'un';

/**
 * Existencias reales (H3.4 T03) y mínimos (H3.5 T05) desde stock_sucursal y
 * stock_producto_sucursal, y reporte de mermas (H3.6 T07) desde movimientos_stock.
 * El ajuste del panel ya es real (AjusteInventario).
 */
@Injectable({ providedIn: 'root' })
export class InventarioService {
  private readonly authService = inject(AuthService);
  private readonly stockApi = inject(StockApiService);
  private readonly recetasApi = inject(RecetasApiService);

  /**
   * Existencias registradas de las sucursales autorizadas, ordenadas por sucursal y
   * artículo. Un artículo aparece en una sucursal cuando ya tiene fila de stock (por una
   * compra, un ajuste o una venta); no se completan con ceros los que nunca tuvieron.
   */
  listarExistencias(): Observable<ExistenciaStock[]> {
    const alcance = sucursalesAutorizadas(this.authService.currentUser());
    if (alcance === 'ninguna') return of([]);

    return forkJoin({
      ingredientes: this.stockApi.listarStockIngredientes(alcance),
      productos: this.stockApi.listarStockProductos(alcance),
      conReceta: this.recetasApi.listarIdsProductosConReceta(),
    }).pipe(
      map(({ ingredientes, productos, conReceta }) => {
        // Un producto con receta descuenta sus ingredientes: una fila propia sería un resto viejo.
        const idsConReceta = new Set(conReceta);
        return [
          ...ingredientes.map(existenciaDeIngrediente),
          ...productos
            .filter((fila) => !idsConReceta.has(fila.producto_id))
            .map(existenciaDeProducto),
        ].sort(
          (a, b) =>
            a.sucursal.localeCompare(b.sucursal, 'es') ||
            a.articulo.localeCompare(b.articulo, 'es'),
        );
      }),
    );
  }

  /**
   * Guarda el mínimo de la existencia en su fila de stock (H3.5 T05) y la devuelve con el
   * valor que quedó en la base. Antes de enviarlo revisa el permiso y el valor (H3.5 T03)
   * y falla con MinimoRechazadoError si no cumplen. Falla con MinimoSinFilaError si la
   * fila ya no existe.
   */
  actualizarMinimo(existencia: ExistenciaStock, stockMinimo: number): Observable<ExistenciaStock> {
    if (!puedeEditarMinimo(this.authService.currentUser(), existencia.sucursalId)) {
      return throwError(
        () => new MinimoRechazadoError('Tu usuario no puede cambiar mínimos en esta sucursal.'),
      );
    }
    const validacion = validarMinimo(String(stockMinimo), existencia.tipo);
    if ('error' in validacion) {
      return throwError(() => new MinimoRechazadoError(validacion.error));
    }

    const tipo = existencia.tipo === 'producto' ? 'producto' : 'ingrediente';
    return this.stockApi
      .actualizarMinimo(tipo, existencia.articuloId, existencia.sucursalId, stockMinimo)
      .pipe(
        map((guardado) => {
          if (guardado === null) throw new MinimoSinFilaError();
          return { ...existencia, stockMinimo: guardado };
        }),
      );
  }

  /** Versión liviana del inventario para detectar cambios sin traer las existencias (H3.2 T06). */
  versionInventario(): Observable<VersionInventarioApi> {
    return this.stockApi.versionInventario();
  }

  /**
   * Ajustes manuales y mermas del periodo (H3.6 T07), del más reciente al más antiguo.
   * Quien no es administrador queda limitado a su sucursal aunque el filtro pida otra.
   */
  listarMermas(filtro: FiltroMermas): Observable<AjusteStock[]> {
    const alcance = sucursalesAutorizadas(this.authService.currentUser());
    if (alcance === 'ninguna') return of([]);

    return this.stockApi
      .listarAjustesManuales(
        alcance ?? filtro.sucursalId,
        inicioDelDiaEnUtc(filtro.desde, 0),
        inicioDelDiaEnUtc(filtro.hasta, 1),
        filtro.soloMermas,
      )
      .pipe(map((filas) => filas.map(ajusteManual)));
  }

  /**
   * Artículos críticos para comprar mañana: no cubren mínimo + consumo diario de los últimos
   * `dias` días. Quien no es administrador queda limitado a su sucursal.
   */
  listarPorComprar(sucursalId: number | null, dias: number): Observable<ArticuloPorComprar[]> {
    const alcance = sucursalesAutorizadas(this.authService.currentUser());
    if (alcance === 'ninguna') return of([]);

    return this.stockApi
      .listarPorComprar(alcance ?? sucursalId, dias)
      .pipe(map((filas) => filas.map(articuloPorComprar)));
  }
}

/**
 * Sucursales que puede consultar el usuario: el administrador ve todas (null) y el
 * resto solo la suya. Sin sucursal asignada no ve ninguna hasta que H3.4 T08 defina
 * ese caso. La base todavía no restringe la lectura por sucursal.
 */
export function sucursalesAutorizadas(usuario: User | null): number | null | 'ninguna' {
  if (usuario?.rol === 'admin') return null;
  return usuario?.sucursalId ?? 'ninguna';
}

/**
 * Quién cambia mínimos (H3.5 T03): el administrador en cualquier sucursal; el bodeguero y el
 * cajero solo en la suya. La base también lo exige (GRANT UPDATE en stock_minimo y RLS por
 * sucursal).
 */
export function puedeEditarMinimo(usuario: User | null, sucursalId: number): boolean {
  if (usuario?.rol === 'admin') return true;
  return (
    (usuario?.rol === 'bodeguero' || usuario?.rol === 'cajero') && usuario.sucursalId === sucursalId
  );
}

function existenciaDeIngrediente(fila: StockIngredienteApi): ExistenciaStock {
  return {
    id: claveExistencia('materia_prima', fila.ingrediente_id, fila.sucursal_id),
    articuloId: fila.ingrediente_id,
    articulo: fila.ingredientes.nombre,
    tipo: 'materia_prima',
    cantidad: Number(fila.stock_actual),
    stockMinimo: Number(fila.stock_minimo),
    unidad: fila.ingredientes.unidades_medida?.abreviatura ?? '',
    sucursalId: fila.sucursal_id,
    sucursal: fila.sucursales.nombre,
    // El costo promedio parte en 0 hasta la primera compra: 0 es "sin costo", no gratis.
    costoUnitario: Number(fila.ingredientes.costo_unitario_promedio) || null,
  };
}

function existenciaDeProducto(fila: StockProductoApi): ExistenciaStock {
  return {
    id: claveExistencia('producto', fila.producto_id, fila.sucursal_id),
    articuloId: fila.producto_id,
    articulo: fila.productos.nombre,
    tipo: 'producto',
    cantidad: Number(fila.stock_actual),
    stockMinimo: Number(fila.stock_minimo),
    unidad: UNIDAD_PRODUCTO,
    sucursalId: fila.sucursal_id,
    sucursal: fila.sucursales.nombre,
    costoUnitario: Number(fila.productos.precio_compra) || null,
  };
}

function articuloPorComprar(fila: ArticuloPorComprarApi): ArticuloPorComprar {
  return {
    id: claveExistencia(fila.tipo, fila.articulo_id, fila.sucursal_id),
    articuloId: fila.articulo_id,
    articulo: fila.nombre,
    tipo: fila.tipo,
    unidad: fila.unidad,
    sucursalId: fila.sucursal_id,
    sucursal: fila.sucursal,
    stock: Number(fila.stock_actual),
    minimo: Number(fila.stock_minimo),
    vendido: Number(fila.vendido),
    consumoDiario: Number(fila.consumo_diario),
    objetivo: Number(fila.stock_objetivo),
    sugerido: Number(fila.sugerido),
  };
}

function ajusteManual(fila: AjusteManualApi): AjusteStock {
  const tipo: TipoArticulo = fila.producto_id !== null ? 'producto' : 'materia_prima';
  // La base exige exactamente uno de los dos ids.
  const articuloId = (fila.producto_id ?? fila.ingrediente_id)!;
  return {
    id: fila.id,
    existenciaId: claveExistencia(tipo, articuloId, fila.sucursal_id),
    articulo: fila.productos?.nombre ?? fila.ingredientes?.nombre ?? '',
    tipo,
    clase: fila.tipo_movimiento === 'merma' ? 'merma' : 'ajuste',
    cantidad: Number(fila.cantidad),
    unidad:
      tipo === 'producto'
        ? UNIDAD_PRODUCTO
        : (fila.ingredientes?.unidades_medida?.abreviatura ?? ''),
    motivo: fila.nota ?? '',
    usuario: fila.usuarios?.nombre ?? null,
    sucursalId: fila.sucursal_id,
    sucursal: fila.sucursales.nombre,
    fecha: fechaDeLaBase(fila.creado_en),
  };
}

/** Inicio del día local AAAA-MM-DD (más `dias`) como instante ISO UTC con zona explícita. */
function inicioDelDiaEnUtc(fecha: string, dias: number): string {
  const [anio, mes, dia] = fecha.split('-').map(Number);
  return new Date(anio, mes - 1, dia + dias).toISOString();
}

/** creado_en llega sin zona y está en UTC; si algún día trae zona, se respeta. */
function fechaDeLaBase(texto: string): Date {
  return new Date(/(Z|[+-]\d{2}(:?\d{2})?)$/.test(texto) ? texto : `${texto}Z`);
}
