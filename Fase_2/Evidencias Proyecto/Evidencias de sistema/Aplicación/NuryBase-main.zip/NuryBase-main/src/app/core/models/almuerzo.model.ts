import { Producto } from './producto.model';
import { Sucursal } from './sucursal.model';
import { Usuario } from './usuario.model';

/**
 * Almuerzo diario de un empleado, sin cobro (H2.13). Es consumo interno, no una venta:
 * no tiene medio de pago ni total. Tabla `almuerzos_empleado`.
 */
export interface AlmuerzoEmpleado {
    id: number;
    sucursal_id: number;
    /** Empleado que almuerza. */
    empleado_id: number;
    /** Usuario que registra el almuerzo. */
    cajero_id: number;
    /** Día del almuerzo en hora de Chile (YYYY-MM-DD). */
    fecha: string;
    creado_en?: string | Date;

    // Relaciones opcionales
    sucursal?: Sucursal;
    empleado?: Usuario;
    cajero?: Usuario;
    detalles?: DetalleAlmuerzoEmpleado[];
}

/** Producto consumido en un almuerzo. Tabla `almuerzos_empleado_detalle`. */
export interface DetalleAlmuerzoEmpleado {
    id: number;
    almuerzo_id: number;
    producto_id: number;
    cantidad: number;
    /** Versión de receta con que se descontó el stock; null si es de reventa. */
    receta_version_id?: number | null;

    // Relaciones opcionales
    producto?: Producto;
}
