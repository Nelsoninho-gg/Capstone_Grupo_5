import { TestBed } from '@angular/core/testing';
import { CuadraturaArticulo } from '../../models/reportes.model';
import { CuadraturaStock } from './cuadratura-stock';

describe('CuadraturaStock', () => {
  const queso: CuadraturaArticulo = {
    sucursalId: 1,
    sucursal: 'Nury Providencia',
    tipo: 'materia_prima',
    articuloId: 2,
    articulo: 'Queso',
    unidad: 'g',
    esperado: 60,
    registrado: 60,
    diferencia: 0,
    cuadra: true,
  };
  const bebida: CuadraturaArticulo = {
    ...queso,
    tipo: 'producto',
    articuloId: 4,
    articulo: 'Chaparrita',
    unidad: 'un',
    esperado: 3,
    registrado: 4,
    diferencia: 1,
    cuadra: false,
  };

  function render(
    filas: CuadraturaArticulo[] | null,
    estado: 'cargando' | 'error' | 'listo' = 'listo',
  ) {
    const fixture = TestBed.createComponent(CuadraturaStock);
    fixture.componentRef.setInput('filas', filas);
    fixture.componentRef.setInput('estado', estado);
    fixture.detectChanges();
    return fixture.nativeElement as HTMLElement;
  }

  it('confirms that the sold quantities match the stock movements', () => {
    const element = render([queso]);
    expect(element.querySelector('.status.ok')?.textContent).toContain('Cuadra');
    expect(element.querySelector('.status.ok')?.textContent).toContain('1 artículos revisados');
    expect(element.querySelector('table')).toBeNull();
  });

  it('lists what does not match with expected, recorded and difference', () => {
    const element = render([bebida, queso]);
    expect(element.querySelector('.status.warning')?.textContent).toContain(
      '1 artículo no cuadra de 2 revisados',
    );
    const fila = element.querySelector('tbody tr')!;
    expect(fila.querySelector('.row-name')?.textContent).toContain('Chaparrita');
    expect(fila.querySelector('[data-label="Según las ventas"]')?.textContent?.trim()).toBe('3 un');
    expect(fila.querySelector('[data-label="Según el inventario"]')?.textContent?.trim()).toBe(
      '4 un',
    );
    expect(fila.querySelector('[data-label="Diferencia"]')?.textContent?.trim()).toBe('+1 un');
    expect(element.querySelectorAll('tbody tr')).toHaveLength(1);
  });

  it('says when there is nothing to check, while it loads and when it fails', () => {
    expect(render([]).textContent).toContain('Sin movimientos de venta que revisar');
    expect(render(null, 'cargando').textContent).toContain('Revisando los movimientos de stock');
    expect(render(null, 'error').textContent).toContain('No se pudo revisar la cuadratura');
  });
});
