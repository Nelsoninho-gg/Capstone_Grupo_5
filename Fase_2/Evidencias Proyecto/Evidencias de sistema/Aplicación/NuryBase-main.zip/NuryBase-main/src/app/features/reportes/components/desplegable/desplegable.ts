import {
  Component,
  ElementRef,
  HostListener,
  computed,
  inject,
  input,
  model,
  signal,
} from '@angular/core';

export interface OpcionDesplegable<T extends string = string> {
  valor: T;
  etiqueta: string;
}

let siguienteId = 0;

/**
 * Desplegable de una opción con el diseño de los filtros de Reportes (sucursales, período y
 * turno), en lugar del select del navegador: botón con el texto elegido y una lista con marca.
 * Se usa para ordenar cajeros y productos y para la categoría de productos.
 */
@Component({
  selector: 'app-desplegable',
  templateUrl: './desplegable.html',
  styleUrl: './desplegable.css',
})
export class Desplegable<T extends string = string> {
  private readonly elemento = inject<ElementRef<HTMLElement>>(ElementRef);

  readonly opciones = input.required<readonly OpcionDesplegable<T>[]>();
  readonly valor = model.required<T>();
  /** Nombre del control para lectores de pantalla ("Ordenar productos por"). */
  readonly etiqueta = input.required<string>();
  /** Texto antes de la opción en el botón: "Ordenar por" → "Ordenar por: Monto facturado". */
  readonly prefijo = input('');

  protected readonly idPanel = `dropdown-options-${++siguienteId}`;
  protected readonly abierto = signal(false);

  protected readonly texto = computed(() => {
    const elegida = this.opciones().find((o) => o.valor === this.valor())?.etiqueta ?? '';
    return this.prefijo() ? `${this.prefijo()}: ${elegida.toLowerCase()}` : elegida;
  });

  protected alternar(): void {
    this.abierto.update((abierto) => !abierto);
  }

  protected elegir(valor: T): void {
    this.valor.set(valor);
    this.abierto.set(false);
  }

  @HostListener('document:click', ['$event'])
  protected cerrarAlHacerClicFuera(event: MouseEvent): void {
    if (this.abierto() && !this.elemento.nativeElement.contains(event.target as Node)) {
      this.abierto.set(false);
    }
  }

  @HostListener('document:keydown.escape')
  protected cerrarConEscape(): void {
    this.abierto.set(false);
  }
}
