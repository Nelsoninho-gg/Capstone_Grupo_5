import { PromocionApi } from '../../../core/api/promociones-api.service';
import { TipoPromocion } from '../../../core/models/comun.model';

/**
 * Estado de una promoción en el listado (H5.2 T02). Sale de su ventana de vigencia: nadie la
 * activa ni la termina a mano. "desactivada" es la que el administrador apagó antes de terminar.
 */
export type EstadoPromocion = 'programada' | 'vigente' | 'terminada' | 'desactivada';

export const ETIQUETAS_ESTADO: Record<EstadoPromocion, string> = {
  programada: 'Programada',
  vigente: 'Vigente',
  terminada: 'Terminada',
  desactivada: 'Desactivada',
};

export const TIPOS_PROMOCION: { valor: TipoPromocion; etiqueta: string }[] = [
  { valor: 'porcentaje', etiqueta: 'Porcentaje (%)' },
  { valor: 'monto_fijo', etiqueta: 'Monto fijo ($)' },
];

/** Una promoción terminada sigue como terminada aunque se haya desactivado antes. */
export function estadoPromocion(
  promocion: Pick<PromocionApi, 'activa' | 'inicio' | 'termino'>,
  ahora = new Date(),
): EstadoPromocion {
  const momento = ahora.getTime();
  if (new Date(promocion.termino).getTime() <= momento) return 'terminada';
  if (!promocion.activa) return 'desactivada';
  return new Date(promocion.inicio).getTime() <= momento ? 'vigente' : 'programada';
}

/** Solo se desactiva lo que todavía puede aplicarse: programada o vigente. */
export function sePuedeDesactivar(estado: EstadoPromocion): boolean {
  return estado === 'programada' || estado === 'vigente';
}

const formatoPesos = new Intl.NumberFormat('es-CL', {
  style: 'currency',
  currency: 'CLP',
  maximumFractionDigits: 0,
});
const formatoPorcentaje = new Intl.NumberFormat('es-CL', { maximumFractionDigits: 2 });

/**
 * Zona de las promociones: el administrador programa en hora de Chile, sea cual sea la zona
 * del equipo desde el que entra (H5.2 T04). Incluye el horario de verano.
 */
export const ZONA_CHILE = 'America/Santiago';

const formatoFechaHora = new Intl.DateTimeFormat('es-CL', {
  day: '2-digit',
  month: '2-digit',
  year: 'numeric',
  hour: '2-digit',
  minute: '2-digit',
  hourCycle: 'h23',
  timeZone: ZONA_CHILE,
});

const partesChile = new Intl.DateTimeFormat('en-US', {
  timeZone: ZONA_CHILE,
  hourCycle: 'h23',
  year: 'numeric',
  month: '2-digit',
  day: '2-digit',
  hour: '2-digit',
  minute: '2-digit',
  second: '2-digit',
});

/** Año, mes, día, hora, minuto y segundo de un instante, en hora de Chile. */
function enChile(
  instante: number,
): Record<'year' | 'month' | 'day' | 'hour' | 'minute' | 'second', number> {
  const partes = Object.fromEntries(
    partesChile.formatToParts(new Date(instante)).map((p) => [p.type, Number(p.value)]),
  );
  return partes as Record<'year' | 'month' | 'day' | 'hour' | 'minute' | 'second', number>;
}

/** Diferencia de Chile con UTC en ese instante, en ms (−3 h en verano, −4 h en invierno). */
function desfaseChile(instante: number): number {
  const p = enChile(instante);
  const comoUtc = Date.UTC(p.year, p.month - 1, p.day, p.hour, p.minute, p.second);
  return comoUtc - Math.floor(instante / 1000) * 1000;
}

/** "20 % de descuento" o "$1.000 de descuento". */
export function textoDescuento(tipo: TipoPromocion, valor: number | string): string {
  const numero = Number(valor);
  return tipo === 'porcentaje'
    ? `${formatoPorcentaje.format(numero)} % de descuento`
    : `${formatoPesos.format(numero)} de descuento`;
}

/**
 * Combo: más de una unidad en total (1 sándwich + 1 café, o 2 cafés). Si no, la promoción es de
 * un solo producto y el POS la muestra en la tarjeta de ese producto, no en una tarjeta aparte.
 */
export function esCombo(promocion: { productos: { cantidad: number }[] }): boolean {
  return promocion.productos.reduce((suma, linea) => suma + linea.cantidad, 0) > 1;
}

/** "Todas las sucursales" o sus nombres, como "Providencia, Ñuñoa". */
export function textoSucursales(promocion: Pick<PromocionApi, 'sucursales'>): string {
  if (!promocion.sucursales.length) return 'Todas las sucursales';
  return promocion.sucursales
    .map((fila) => fila.sucursal?.nombre ?? `Sucursal #${fila.sucursal_id}`)
    .sort((a, b) => a.localeCompare(b, 'es'))
    .join(', ');
}

export function formatearFechaHora(fecha: string | Date): string {
  return formatoFechaHora.format(new Date(fecha));
}

/**
 * Valor para un <input type="datetime-local"> (AAAA-MM-DDTHH:mm) en hora de Chile, a partir
 * de la fecha de la base.
 */
export function aFechaHoraChile(fecha: string | Date): string {
  const p = enChile(new Date(fecha).getTime());
  const dos = (n: number) => String(n).padStart(2, '0');
  return `${p.year}-${dos(p.month)}-${dos(p.day)}T${dos(p.hour)}:${dos(p.minute)}`;
}

/**
 * Del <input type="datetime-local">, leído como hora de Chile, a ISO en UTC para la base.
 * "2026-11-07T00:00" → "2026-11-07T03:00:00.000Z" (verano, UTC−3), aunque el equipo esté en
 * otra zona.
 */
export function desdeFechaHoraChile(valor: string): string {
  const [fecha, hora] = valor.split('T');
  const [anio, mes, dia] = fecha.split('-').map(Number);
  const [hh, mm] = hora.split(':').map(Number);
  const comoUtc = Date.UTC(anio, mes - 1, dia, hh, mm);
  // Se corrige dos veces por si el cambio de horario cae entre la estimación y el resultado.
  const estimado = comoUtc - desfaseChile(comoUtc);
  return new Date(comoUtc - desfaseChile(estimado)).toISOString();
}
