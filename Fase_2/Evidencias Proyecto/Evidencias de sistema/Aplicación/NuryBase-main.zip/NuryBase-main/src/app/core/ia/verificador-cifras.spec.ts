import { describe, expect, it } from 'vitest';
import { cifrasNoVerificadas, nombresNoVerificados } from './verificador-cifras';

describe('cifrasNoVerificadas', () => {
  const fuentes = JSON.stringify({ precio: 3000, neto: 2430, margen: 720, pct: 24, ticket: 15366.58, costo: 138.462 });

  it('acepta cifras que están en las fuentes, con formato chileno o redondeadas', () => {
    expect(
      cifrasNoVerificadas('Precio $3.000, neto $2.430: margen de $720 (24%). Ticket $15.367. Costo $138.', fuentes),
    ).toEqual([]);
  });

  it('detecta montos, porcentajes y números grandes calculados por el modelo', () => {
    expect(cifrasNoVerificadas('Deja $721 y un 25%, y vendió 1.500 unidades', fuentes)).toEqual([
      '$721',
      '25%',
      '1.500',
    ]);
  });

  it('no revisa años, números menores a 10, fechas ni horas', () => {
    expect(
      cifrasNoVerificadas('En 2026-10-01 a las 13:00, y el 30 de octubre de 2026, hubo 8 ventas en 3 sedes.', fuentes),
    ).toEqual([]);
  });

  it.each([
    'El 18 y 19 de septiembre fue bueno.',
    'Entre el 18 y el 19 de septiembre fue bueno.',
    'Del 15 al 20 de septiembre fue bueno.',
    'Desde el 15 hasta el 20 de septiembre fue bueno.',
    'El 15, 16 y 17 de octubre fue bueno.',
    'El 15, 16, y 17 de octubre fue bueno.',
    'El 15, 16, 17 de octubre fue bueno.',
  ])('no toma como cifras los días de una lista o rango: %s', (texto) => {
    expect(cifrasNoVerificadas(texto, '')).toEqual([]);
  });

  it('sigue revisando una cifra suelta junto a un mes o a una fecha', () => {
    expect(cifrasNoVerificadas('Fueron 18 ventas de septiembre', '')).toEqual(['18']);
    expect(cifrasNoVerificadas('Fueron 18 ventas y 19 de septiembre', '')).toEqual(['18']);
    expect(cifrasNoVerificadas('Fueron $15 y 19 de septiembre', '')).toEqual(['$15']);
    expect(cifrasNoVerificadas('Fueron $ 15 y 19 de septiembre', '')).toEqual(['$ 15']);
    expect(cifrasNoVerificadas('Fueron 12,5 y 19 de septiembre', '')).toEqual(['12,5']);
  });

  it('una lista de días en las fuentes no valida cifras por coincidencia', () => {
    expect(cifrasNoVerificadas('Hubo 18 ventas', 'Del 18 y 19 de septiembre')).toEqual(['18']);
  });

  it('detecta conteos inventados desde 10, sin aceptarlos por coincidir con una fecha', () => {
    const conFecha = JSON.stringify({ fecha: '2026-10-30T15:00:00+00:00', ventas: 17 });
    expect(cifrasNoVerificadas('Hubo 30 ventas', conFecha)).toEqual(['30']);
    expect(cifrasNoVerificadas('Hubo 17 ventas', conFecha)).toEqual([]);
  });

  it('acepta el cero y entiende decimales con coma', () => {
    expect(cifrasNoVerificadas('Total $0 y un 1,5% de merma', JSON.stringify({ merma: 1.5 }))).toEqual([]);
    expect(cifrasNoVerificadas('Merma de 7,5%', JSON.stringify({ merma: 1.5 }))).toEqual(['7,5%']);
  });

  it('entiende separadores combinados y no confunde el punto final de una oración', () => {
    expect(cifrasNoVerificadas('Total $1.234,50.', JSON.stringify({ t: 1234.5 }))).toEqual([]);
    expect(cifrasNoVerificadas('Total 1,234.50', JSON.stringify({ t: 1234.5 }))).toEqual([]);
    expect(cifrasNoVerificadas('Vendió 300.', JSON.stringify({ t: 300 }))).toEqual([]);
  });

  it('sin fuentes rechaza cualquier monto', () => {
    expect(cifrasNoVerificadas('Vendiste $2.000', '')).toEqual(['$2.000']);
  });
});

describe('nombresNoVerificados', () => {
  const fuentes = JSON.stringify({ empleados: ['Maher', 'Mauricio Figueroa'], producto: 'EMPANADA PINO', sucursal: 'Nury Providencia' });

  it('detecta personas inventadas', () => {
    expect(nombresNoVerificados('Almorzaron: Juan Pérez, María González y Maher.', fuentes)).toEqual([
      'Juan',
      'Pérez',
      'María',
      'González',
    ]);
  });

  it('acepta nombres de las fuentes, sin importar mayúsculas ni acentos', () => {
    expect(nombresNoVerificados('Almorzaron Maher y Mauricio Figueroa, y pidieron Empanada Pino en Nury Providencia.', fuentes)).toEqual([]);
    expect(nombresNoVerificados('Lo pidió Maher', JSON.stringify({ n: 'MAHÉR' }))).toEqual([]);
  });

  it('no revisa la primera palabra de una oración, siglas ni meses', () => {
    expect(nombresNoVerificados('Durante octubre vendió poco. Te sugiero revisar el IVA en Octubre o el Lunes.', fuentes)).toEqual([]);
  });
});
