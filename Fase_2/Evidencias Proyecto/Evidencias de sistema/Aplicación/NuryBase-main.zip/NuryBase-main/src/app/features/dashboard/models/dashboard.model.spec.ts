import { describe, expect, it } from 'vitest';
import { VentaDashboardApi } from '../../../core/api/ventas-api.service';
import {
  calcularMadurezDashboard,
  calcularRangoPeriodo,
  construirEscenario,
  construirVistaDiasSemana,
  construirVistaProyeccion,
  textoActualizado,
  textoAparicion,
  textoPocoFrecuente,
  textoSoporte,
  textoVecesDia,
  type DemandaDiaSemana,
} from './dashboard.model';

// Jueves 12 de noviembre de 2026 a las 15:00, hora local.
const AHORA = new Date(2026, 10, 12, 15, 0);

function linea(productoId: number, nombre: string, subtotal: number, precioCompra: number | null = 100) {
  return {
    producto_id: productoId,
    cantidad: 1,
    subtotal,
    productos: { nombre, categoria: 'BEBESTIBLES - CAFÉ', precio_compra: precioCompra },
  };
}

function venta(
  fecha: Date,
  total: number,
  detalle: VentaDashboardApi['detalle_venta'],
  tipoVenta?: VentaDashboardApi['tipo_venta'],
): VentaDashboardApi {
  return {
    id: fecha.getTime(),
    fecha_venta: fecha.toISOString().slice(0, 19),
    total,
    ...(tipoVenta ? { tipo_venta: tipoVenta } : {}),
    detalle_venta: detalle,
  };
}

describe('Dashboard: rango del período', () => {
  it('usa semana desde el lunes, mes y trimestre calendario', () => {
    const semana = calcularRangoPeriodo('7d', AHORA);
    expect(semana.inicio).toEqual(new Date(2026, 10, 9));
    expect(semana.fin).toEqual(new Date(2026, 10, 16));
    expect(semana.diasTotales).toBe(7);

    expect(calcularRangoPeriodo('30d', AHORA).inicio).toEqual(new Date(2026, 10, 1));
    const trimestre = calcularRangoPeriodo('90d', AHORA);
    expect(trimestre.inicio).toEqual(new Date(2026, 9, 1));
    expect(trimestre.fin).toEqual(new Date(2027, 0, 1));
  });

  it('compara con un tramo previo de la misma duración', () => {
    const rango = calcularRangoPeriodo('7d', AHORA);
    expect(rango.inicio.getTime() - rango.inicioPrevio.getTime()).toBe(
      AHORA.getTime() - rango.inicio.getTime(),
    );
  });
});

describe('Dashboard: construirEscenario', () => {
  const costos = new Map<number, number>();

  it('calcula total, ganancia neta de IVA y cierre estimado', () => {
    const esc = construirEscenario(
      [venta(new Date(2026, 10, 10, 9), 1000, [linea(1, 'Café', 1000, 100)])],
      costos,
      '7d',
      AHORA,
    );
    const [ingresos, ganancia, cierre] = esc.kpis;
    expect(ingresos.montoClp).toBe(1000);
    expect(ingresos.subtitulo).toContain('Ventas realizadas esta semana: 1');
    expect(ganancia.montoClp).toBe(740); // 1000 ÷ 1,19 - 100
    // Solo hubo ventas un martes: la semana tiene un único día operativo y ya transcurrió.
    expect(cierre.montoClp).toBe(740);
  });

  it('respeta el descuento de la venta al repartir el total entre las líneas', () => {
    const esc = construirEscenario(
      [venta(new Date(2026, 10, 10, 9), 700, [linea(1, 'Café', 1000, 100)])],
      costos,
      '7d',
      AHORA,
    );
    expect(esc.kpis[1].montoClp).toBe(488); // 700 ÷ 1,19 - 100
    expect(esc.productosMasVendidos[0].ventasClp).toBe(700);
  });

  it('prioriza el costo de receta y no suma ganancia si el producto no tiene costo', () => {
    const conReceta = construirEscenario(
      [venta(new Date(2026, 10, 10, 9), 1000, [linea(1, 'Café', 1000, 100)])],
      new Map([[1, 300]]),
      '7d',
      AHORA,
    );
    expect(conReceta.kpis[1].montoClp).toBe(540);

    const sinCosto = construirEscenario(
      [venta(new Date(2026, 10, 10, 9), 1000, [linea(1, 'Café', 1000, null)])],
      costos,
      '7d',
      AHORA,
    );
    expect(sinCosto.kpis[1].montoClp).toBe(0);
    expect(sinCosto.kpis[1].subtitulo).toContain('Productos sin costo que no suman: 1');
    expect(sinCosto.productosDestacados[0].gananciaLimpiaClp).toBeNull();
  });

  it('calcula la variación contra el tramo previo y es null si no hay ventas previas', () => {
    const actual = venta(new Date(2026, 10, 10, 9), 1500, [linea(1, 'Café', 1500)]);
    const previa = venta(new Date(2026, 10, 7, 9), 1000, [linea(1, 'Café', 1000)]);

    expect(construirEscenario([previa, actual], costos, '7d', AHORA).kpis[0].variacionPct).toBe(50);
    expect(construirEscenario([actual], costos, '7d', AHORA).kpis[0].variacionPct).toBeNull();
  });

  it('no cuenta en el período las ventas previas ni las futuras', () => {
    const previa = venta(new Date(2026, 10, 7, 9), 1000, [linea(1, 'Café', 1000)]);
    const futura = venta(new Date(2026, 10, 13, 9), 9000, [linea(1, 'Café', 9000)]);
    expect(construirEscenario([previa, futura], costos, '7d', AHORA).kpis[0].montoClp).toBe(0);
  });

  it('acumula la serie por tramo y termina en el cierre estimado', () => {
    const esc = construirEscenario(
      [
        venta(new Date(2026, 10, 9, 9), 1000, [linea(1, 'Café', 1000)]),
        venta(new Date(2026, 10, 11, 9), 500, [linea(1, 'Café', 500)]),
      ],
      costos,
      '7d',
      AHORA,
    );
    expect(esc.serieIngresos.map((p) => p.etiqueta)).toEqual(['Lun', 'Mar', 'Mié', 'Jue', 'Cierre (Est.)']);
    expect(esc.serieIngresos.map((p) => p.realClp)).toEqual([1000, 1000, 1500, 1500, null]);
    expect(esc.serieIngresos[3].proyectadoClp).toBe(1500);
    // Vendió lunes y miércoles, y ambos ya pasaron: no se proyectan ventas en otros días.
    expect(esc.serieIngresos[4].proyectadoClp).toBe(1500);
  });

  it('agrupa por familia, franja horaria y productos comprados juntos', () => {
    const combo = () => [linea(1, 'Café', 1000), linea(2, 'Medialuna', 500)];
    const esc = construirEscenario(
      [
        venta(new Date(2026, 10, 9, 9), 1500, combo()),
        venta(new Date(2026, 10, 10, 9), 1500, combo()),
        venta(new Date(2026, 10, 10, 14), 1000, [linea(1, 'Café', 1000)]),
      ],
      costos,
      '7d',
      AHORA,
    );

    expect(esc.lineasNegocio[0].nombre).toBe('BEBESTIBLES');
    expect(esc.lineasNegocio[0].ventasClp).toBe(4000);

    const manana = esc.demandaHoraria.find((b) => b.franja === '08:00')!;
    expect(manana.esHoraPunta).toBe(true);
    expect(manana.ticketsPromedio).toBe(1);
    expect(esc.demandaHoraria.find((b) => b.franja === '13:00')!.esHoraPunta).toBe(false);

    expect(esc.comprasConjuntas).toHaveLength(1);
    expect(esc.comprasConjuntas[0].productoPrincipal).toBe('Café');
    expect(esc.comprasConjuntas[0].frecuenciaTexto).toBe('De las 3 boletas que llevan Café, 2 también llevan Medialuna.');
    expect(esc.comprasConjuntas[0].aparicionTexto).toBe('2 de cada 3 boletas');
    expect(esc.comprasConjuntas[0].horarioFrecuente).toBe('en la mañana, desde las 08:00 hrs');
    expect(esc.comprasConjuntas[0].soporteTexto).toBe('el 67% del total');
    expect(esc.comprasConjuntas[0]).toMatchObject({ soportePct: 67, confianzaPct: 67, lift: 1 });
    // Solo 2 boletas juntos: se muestra, pero no alcanza para recomendar.
    expect(esc.comprasConjuntas[0].esRecomendable).toBe(false);
    expect(esc.comprasConjuntas[0].consejoPractico).toBe(
      'Todavía es poco frecuente: se compraron juntos solo 2 veces en el período. Para recomendar una promoción hacen falta al menos 5 boletas juntos y el 1% del total.',
    );
  });

  it('proyecta el cierre con días operativos: sin sábado ni domingo no proyecta esos días', () => {
    // Lunes a viernes de la semana anterior y de esta, hasta el jueves de hoy.
    const dias = [
      new Date(2026, 10, 6, 9), // viernes anterior
      new Date(2026, 10, 9, 9),
      new Date(2026, 10, 10, 9),
      new Date(2026, 10, 11, 9),
      new Date(2026, 10, 12, 9),
    ];
    const esc = construirEscenario(
      dias.map((d) => venta(d, 1000, [linea(1, 'Café', 1000, 100)])),
      costos,
      '7d',
      AHORA,
    );
    // 4 de 5 días operativos: $4.000 × 5/4, no × 7/4.
    expect(esc.serieIngresos.at(-1)?.proyectadoClp).toBe(5000);
  });

  it('recomienda un combo con al menos 5 boletas juntos y el 1% del total', () => {
    const conAmbos = () => [linea(1, 'A', 100), linea(2, 'B', 100)];
    const ventas = [
      ...[9, 10, 11, 12, 13].map((h) => venta(new Date(2026, 10, 9, h), 200, conAmbos())),
      venta(new Date(2026, 10, 9, 14), 100, [linea(1, 'A', 100)]),
    ];
    const [combo] = construirEscenario(ventas, costos, '7d', AHORA).comprasConjuntas;
    expect(combo.esRecomendable).toBe(true);
    expect(combo.consejoPractico).toContain('armar una promoción');
  });

  it('no recomienda un combo que no llega al 1% de las boletas, aunque se repita 5 veces', () => {
    const conAmbos = () => [linea(1, 'A', 100), linea(2, 'B', 100)];
    const ventas = [
      ...[9, 10, 11, 12, 13].map((h) => venta(new Date(2026, 10, 9, h), 200, conAmbos())),
      ...Array.from({ length: 595 }, (_, i) =>
        venta(new Date(2026, 10, 10, 9, 0, i), 100, [linea(3, 'C', 100)]),
      ),
    ];
    const [combo] = construirEscenario(ventas, costos, '7d', AHORA).comprasConjuntas;
    expect(combo.aparicionTexto).toBe('5 de las 600 boletas del período');
    expect(combo.soporteTexto).toBe('menos del 1% del total');
    expect(combo.esRecomendable).toBe(false);
    expect(combo.consejoPractico).toContain('se compraron juntos 5 veces en el período, menos del 1% de las 600 boletas.');
  });

  it('explica por qué un combo es poco frecuente con el dato que falla', () => {
    expect(textoPocoFrecuente(3, 1101)).toContain('se compraron juntos solo 3 veces en el período, menos del 1% de las 1.101 boletas.');
    expect(textoPocoFrecuente(1, 4)).toContain('se compraron juntos solo 1 vez en el período.');
    expect(textoPocoFrecuente(7, 1000)).toContain('se compraron juntos 7 veces en el período, menos del 1% de las 1.000 boletas.');
  });

  it('dice cada horario con su artículo dentro de la frase', () => {
    const conAmbos = () => [linea(1, 'A', 100), linea(2, 'B', 100)];
    const horario = (hora: number) =>
      construirEscenario(
        [venta(new Date(2026, 10, 9, hora), 200, conAmbos()), venta(new Date(2026, 10, 10, hora), 200, conAmbos())],
        costos,
        '7d',
        AHORA,
      ).comprasConjuntas[0].horarioFrecuente;
    expect(horario(21)).toBe('al cierre, desde las 20:30 hrs');
    expect(horario(14)).toBe('al almuerzo, desde las 13:00 hrs');
    expect(horario(11)).toBe('a media mañana, desde las 10:30 hrs');
  });

  it('muestra primero los combos que alcanzan para recomendar', () => {
    const ventas = [
      // A + B: 5 boletas juntos, recomendable.
      ...[9, 10, 11, 12, 13].map((h) => venta(new Date(2026, 10, 9, h), 200, [linea(1, 'A', 100), linea(2, 'B', 100)])),
      // C + D: 2 boletas, solo para observar.
      ...[14, 15].map((h) => venta(new Date(2026, 10, 9, h), 200, [linea(3, 'C', 100), linea(4, 'D', 100)])),
    ];
    const combos = construirEscenario(ventas, costos, '7d', AHORA).comprasConjuntas;
    expect(combos.map((c) => [c.productoPrincipal + '+' + c.acompanamiento, c.esRecomendable])).toEqual([
      ['A+B', true],
      ['C+D', false],
    ]);
  });

  it('descarta pares que se compran juntos menos de lo esperable por azar (lift < 1)', () => {
    const conAmbos = () => [linea(1, 'A', 100), linea(2, 'B', 100)];
    const esc = construirEscenario(
      [
        venta(new Date(2026, 10, 9, 9), 200, conAmbos()),
        venta(new Date(2026, 10, 9, 10), 200, conAmbos()),
        venta(new Date(2026, 10, 9, 11), 100, [linea(1, 'A', 100)]),
        venta(new Date(2026, 10, 9, 12), 100, [linea(1, 'A', 100)]),
        venta(new Date(2026, 10, 9, 13), 100, [linea(2, 'B', 100)]),
        venta(new Date(2026, 10, 9, 14), 100, [linea(2, 'B', 100)]),
      ],
      costos,
      '7d',
      AHORA,
    );
    expect(esc.comprasConjuntas).toEqual([]);
  });

  it('entrega siempre el mismo resultado con los mismos datos', () => {
    const ventas = [venta(new Date(2026, 10, 10, 9), 1000, [linea(1, 'Café', 1000)])];
    expect(construirEscenario(ventas, costos, '7d', AHORA)).toEqual(construirEscenario(ventas, costos, '7d', AHORA));
  });

  it('destaca sin repetir productos y queda vacío sin ventas', () => {
    const esc = construirEscenario(
      [
        venta(new Date(2026, 10, 9, 9), 3000, [
          { ...linea(1, 'Café', 1000), cantidad: 5 },
          { ...linea(2, 'Barato', 1000, 900), cantidad: 2 },
          { ...linea(3, 'Raro', 1000), cantidad: 1 },
        ]),
      ],
      costos,
      '7d',
      AHORA,
    );
    expect(esc.productosDestacados.map((p) => [p.producto, p.categoriaResumen])).toEqual([
      ['Café', 'estrella'],
      ['Barato', 'margen-bajo'],
      ['Raro', 'baja-rotacion'],
    ]);
    // Ranking: el primero es el destacado y nunca pasa de 5.
    expect(esc.productosDestacados[0].ranking.map((p) => p.producto)).toEqual(['Café', 'Barato', 'Raro']);
    for (const d of esc.productosDestacados) {
      expect(d.ranking[0].producto).toBe(d.producto);
      expect(d.ranking.length).toBeLessThanOrEqual(5);
    }

    const vacio = construirEscenario([], costos, '30d', AHORA);
    expect(vacio.kpis.map((k) => k.montoClp)).toEqual([0, 0, 0]);
    expect(vacio.productosDestacados).toEqual([]);
    expect(vacio.comprasConjuntas).toEqual([]);
    expect(vacio.lineasNegocio).toEqual([]);
  });

  it('mantiene las ventas a empleados en total y ganancia, pero las excluye del análisis de clientes', () => {
    const normal = venta(
      new Date(2026, 10, 9, 9), // lunes 09:00 (Mañana)
      2000,
      [linea(1, 'Café', 2000, 500), linea(2, 'Queque', 0, 100)],
      'normal',
    );
    const otraNormal = venta(
      new Date(2026, 10, 9, 10), // lunes 10:00 (Mañana)
      2000,
      [linea(1, 'Café', 2000, 500)],
      'normal',
    );
    const empleadoMismo = venta(
      new Date(2026, 10, 10, 14), // martes 14:00 (Almuerzo)
      1400,
      [linea(1, 'Café', 2000, 500), linea(2, 'Queque', 0, 100)],
      'empleado',
    );
    const empleadoSolo = venta(
      new Date(2026, 10, 11, 17), // miércoles 17:00 (Tarde)
      1440,
      [linea(3, 'Helado Crazy Frambuesa', 1800, 1180)],
      'empleado',
    );

    const esc = construirEscenario([normal, otraNormal, empleadoMismo, empleadoSolo], costos, '7d', AHORA);

    // Total vendido y ganancia limpia cuentan todas (normales + empleados).
    const [ingresos, ganancia] = esc.kpis;
    expect(ingresos.montoClp).toBe(6840);
    expect(ingresos.subtitulo).toContain('Ventas realizadas esta semana: 4');
    // Ganancia: (2000 + 2000 + 1400 + 1440) / 1.19 - (600 + 500 + 600 + 1180) = 5747.90 - 2880 = 2868
    expect(ganancia.montoClp).toBe(2868);

    // Ranking y familias solo cuentan ventas a clientes (normales).
    expect(esc.productosMasVendidos.find((p) => p.producto === 'Café')).toMatchObject({
      unidades: 2,
      ventasClp: 4000,
    });
    expect(esc.productosMasVendidos.find((p) => p.producto === 'Helado Crazy Frambuesa')).toBeUndefined();
    expect(esc.lineasNegocio[0].ventasClp).toBe(4000);

    // Producto vendido solo a empleados no aparece en «El que deja menos ganancia».
    const menosGanancia = esc.productosDestacados.find((p) => p.categoriaResumen === 'margen-bajo');
    expect(menosGanancia?.producto).toBe('Queque');
    expect(esc.productosDestacados.some((p) => p.producto === 'Helado Crazy Frambuesa')).toBe(false);

    // Combos, horarios y días de la semana cuentan solo las ventas normales.
    expect(esc.comprasConjuntas).toEqual([]);
    expect(esc.demandaHoraria.find((h) => h.franja === '08:00')?.ticketsPromedio).toBe(2);
    expect(esc.demandaHoraria.find((h) => h.franja === '13:00')?.ticketsPromedio).toBe(0);
    expect(esc.demandaHoraria.find((h) => h.franja === '16:00')?.ticketsPromedio).toBe(0);

    const lunes = esc.demandaPorDiaSemana.find((d) => d.dia === 'Lunes')!;
    const martes = esc.demandaPorDiaSemana.find((d) => d.dia === 'Martes')!;
    const miercoles = esc.demandaPorDiaSemana.find((d) => d.dia === 'Miércoles')!;
    expect(lunes).toMatchObject({ cantidadVentas: 2, montoTotalClp: 4000 });
    expect(martes).toMatchObject({ cantidadVentas: 0, montoTotalClp: 0 });
    expect(miercoles).toMatchObject({ cantidadVentas: 0, montoTotalClp: 0 });
  });
});

describe('Dashboard: madurez de datos', () => {
  it('es preliminar bajo 28 días y nombra la sucursal', () => {
    const preliminar = calcularMadurezDashboard(10, 'Nury ENAC');
    expect(preliminar.esPreliminar).toBe(true);
    expect(preliminar.diasFaltantes).toBe(18);
    expect(preliminar.mensajeBanner).toContain('Nury ENAC');
    expect(calcularMadurezDashboard(28).esPreliminar).toBe(false);
  });
});

describe('Dashboard: vista de la proyección', () => {
  it('reparte el acumulado por tramo y agrega lo que falta como estimado', () => {
    const vista = construirVistaProyeccion([
      { etiqueta: 'oct.', realClp: 100, proyectadoClp: null },
      { etiqueta: 'nov.', realClp: 150, proyectadoClp: 150 },
      { etiqueta: 'Cierre (Est.)', realClp: null, proyectadoClp: 300 },
    ]);
    expect(vista.acumuladoClp).toBe(150);
    expect(vista.cierreClp).toBe(300);
    expect(vista.avancePct).toBe(50);
    expect(vista.tramos.map((t) => [t.etiqueta, t.valorClp, t.estimado])).toEqual([
      ['oct.', 100, false],
      ['nov.', 50, false],
      ['Proyección', 150, true],
    ]);
    expect(vista.tramos[2].alturaPct).toBe(100);
  });

  it('no rompe la barra con pérdidas ni sin ventas', () => {
    const conPerdida = construirVistaProyeccion([
      { etiqueta: 'Sem 1', realClp: -50, proyectadoClp: -50 },
      { etiqueta: 'Cierre (Est.)', realClp: null, proyectadoClp: -200 },
    ]);
    expect(conPerdida.avancePct).toBe(0);
    expect(conPerdida.tramos).toHaveLength(1);
    expect(conPerdida.tramos[0].alturaPct).toBe(0);

    expect(construirVistaProyeccion([])).toEqual({ acumuladoClp: 0, cierreClp: 0, avancePct: 0, tramos: [] });
  });

  it('desglosa los 7 días de la semana y marca el día con mayor volumen de ventas', () => {
    const ventas = [
      venta(new Date(2026, 10, 9, 10), 5000, [linea(1, 'Café', 5000)]),
      venta(new Date(2026, 10, 9, 11), 3000, [linea(1, 'Café', 3000)]),
      venta(new Date(2026, 10, 10, 12), 2000, [linea(1, 'Café', 2000)]),
    ];
    const esc = construirEscenario(ventas, new Map(), '7d', AHORA);

    expect(esc.demandaPorDiaSemana).toHaveLength(7);
    expect(esc.demandaPorDiaSemana.map((d) => d.dia)).toEqual([
      'Lunes',
      'Martes',
      'Miércoles',
      'Jueves',
      'Viernes',
      'Sábado',
      'Domingo',
    ]);

    const lunes = esc.demandaPorDiaSemana.find((d) => d.dia === 'Lunes')!;
    expect(lunes.cantidadVentas).toBe(2);
    expect(lunes.montoTotalClp).toBe(8000);
    expect(lunes.esDiaMayorVenta).toBe(true);

    const martes = esc.demandaPorDiaSemana.find((d) => d.dia === 'Martes')!;
    expect(martes.cantidadVentas).toBe(1);
    expect(martes.montoTotalClp).toBe(2000);
    expect(martes.esDiaMayorVenta).toBe(false);

    const domingo = esc.demandaPorDiaSemana.find((d) => d.dia === 'Domingo')!;
    expect(domingo.cantidadVentas).toBe(0);
    expect(domingo.montoTotalClp).toBe(0);
    expect(domingo.esDiaMayorVenta).toBe(false);
  });

  it('el día con más venta es el que suma más en el período, aunque otro tenga mejor promedio', () => {
    // Noviembre 2026 hasta el jueves 12: dos lunes (2 y 9) y un solo viernes (6).
    const ventas = [
      venta(new Date(2026, 10, 2, 10), 3000, [linea(1, 'Café', 3000)]),
      venta(new Date(2026, 10, 9, 10), 3000, [linea(1, 'Café', 3000)]),
      venta(new Date(2026, 10, 6, 10), 4000, [linea(1, 'Café', 4000)]),
    ];
    const dias = construirEscenario(ventas, new Map(), '30d', AHORA).demandaPorDiaSemana;
    expect(dias.find((d) => d.esDiaMayorVenta)?.dia).toBe('Lunes');
    const columnas = construirVistaDiasSemana(dias);
    expect(columnas[0]).toMatchObject({ valorClp: 6000, alturaPct: 100, esMayor: true, vecesEnPeriodo: 2, vecesTexto: '2 lunes' });
    expect(columnas[4]).toMatchObject({ valorClp: 4000, esMayor: false, vecesEnPeriodo: 1, vecesTexto: '1 viernes' });
    // El 12 es jueves: jueves 5 y 12 cuentan; el sábado 7 cayó una sola vez.
    expect(columnas[3].vecesEnPeriodo).toBe(2);
    expect(columnas[5].vecesTexto).toBe('1 sábado');
  });

  it('marca como día con más venta el de más pesos, no el de más boletas, igual que la tarjeta', () => {
    const ventas = [
      venta(new Date(2026, 10, 9, 10), 1000, [linea(1, 'Café', 1000)]),
      venta(new Date(2026, 10, 9, 11), 1000, [linea(1, 'Café', 1000)]),
      venta(new Date(2026, 10, 10, 12), 8000, [linea(1, 'Café', 8000)]),
    ];
    const dias = construirEscenario(ventas, new Map(), '7d', AHORA).demandaPorDiaSemana;
    expect(dias.filter((d) => d.esDiaMayorVenta).map((d) => d.dia)).toEqual(['Martes']);
  });

  it('arma las columnas por día con la altura según el promedio vendido y marca el mayor monto', () => {
    const ventas = [
      venta(new Date(2026, 10, 9, 10), 1000, [linea(1, 'Café', 1000)]),
      venta(new Date(2026, 10, 9, 11), 1000, [linea(1, 'Café', 1000)]),
      venta(new Date(2026, 10, 10, 12), 8000, [linea(1, 'Café', 8000)]),
    ];
    const columnas = construirVistaDiasSemana(construirEscenario(ventas, new Map(), '7d', AHORA).demandaPorDiaSemana);

    expect(columnas.map((c) => c.etiqueta)).toEqual(['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom']);
    // El lunes tiene más boletas, pero el martes vendió más plata: la columna sigue al monto.
    expect(columnas[0]).toMatchObject({ valorClp: 2000, alturaPct: 25, esMayor: false });
    expect(columnas[1]).toMatchObject({ valorClp: 8000, alturaPct: 100, esMayor: true });
    expect(columnas[6]).toMatchObject({ alturaPct: 0, esMayor: false });
  });

  it('con ganancia limpia la altura y el día destacado siguen a la ganancia del período, y una pérdida no tiene barra', () => {
    const dia = (n: number, venta: number, ganancia: number): DemandaDiaSemana => ({
      dia: ['Lunes', 'Martes', 'Miércoles'][n - 1],
      diaNumero: n,
      cantidadVentas: 1,
      vecesEnPeriodo: 1,
      montoTotalClp: venta,
      promedioVentaDiariaClp: venta,
      gananciaTotalClp: ganancia,
      promedioGananciaDiariaClp: ganancia,
      esDiaMayorVenta: false,
    });
    const dias = [dia(1, 9000, 1000), dia(2, 4000, 2000), dia(3, 3000, -500)];

    expect(construirVistaDiasSemana(dias, 'ingresos').find((c) => c.esMayor)?.dia).toBe('Lunes');
    const ganancia = construirVistaDiasSemana(dias, 'ganancia');
    expect(ganancia.map((c) => [c.valorClp, c.alturaPct, c.esMayor])).toEqual([
      [1000, 50, false],
      [2000, 100, true],
      [-500, 0, false],
    ]);
  });

  it('suma la ganancia limpia de cada día y su promedio', () => {
    const ventas = [
      venta(new Date(2026, 10, 9, 10), 1000, [linea(1, 'Café', 1000, 400)]),
      venta(new Date(2026, 10, 9, 11), 1000, [linea(1, 'Café', 1000, 400)]),
    ];
    const lunes = construirEscenario(ventas, new Map(), '7d', AHORA).demandaPorDiaSemana[0];
    // Neto ($1.000 ÷ 1,19 = $840) menos costo $400 = $440 por boleta; el lunes ocurrió una vez en la semana.
    expect(lunes).toMatchObject({ gananciaTotalClp: 881, promedioGananciaDiariaClp: 881 });
  });

  it('sin ventas no marca ningún día ni divide por cero', () => {
    const columnas = construirVistaDiasSemana(construirEscenario([], new Map(), '7d', AHORA).demandaPorDiaSemana);
    expect(columnas.every((c) => c.alturaPct === 0 && !c.esMayor)).toBe(true);
  });
});

describe('Dashboard: veces que cae cada día en el período', () => {
  it('escribe el día en singular o plural', () => {
    expect(textoVecesDia('Lunes', 2)).toBe('2 lunes');
    expect(textoVecesDia('Miércoles', 1)).toBe('1 miércoles');
    expect(textoVecesDia('Sábado', 1)).toBe('1 sábado');
    expect(textoVecesDia('Sábado', 3)).toBe('3 sábados');
    expect(textoVecesDia('Domingo', 0)).toBe('0 domingos');
  });
});

describe('Dashboard: texto de aparición de los combos', () => {
  it('reduce la fracción sin redondear', () => {
    expect(textoAparicion(4, 6)).toBe('2 de cada 3 boletas');
    expect(textoAparicion(25, 100)).toBe('1 de cada 4 boletas');
    expect(textoAparicion(2, 3)).toBe('2 de cada 3 boletas');
  });

  it('si la fracción no queda chica dice las cantidades reales del período', () => {
    expect(textoAparicion(3, 1100)).toBe('3 de las 1.100 boletas del período');
    expect(textoAparicion(67, 100)).toBe('67 de las 100 boletas del período');
  });

  it('cuando están en todas las boletas lo dice en palabras', () => {
    expect(textoAparicion(2, 2)).toBe('todas las boletas del período');
  });

  it('nunca muestra "el 0%" para un combo que sí aparece', () => {
    expect(textoSoporte(3, 1100)).toBe('menos del 1% del total');
    expect(textoSoporte(1, 4)).toBe('el 25% del total');
    expect(textoSoporte(2, 2)).toBe('el 100% del total');
  });
});

describe('Dashboard: texto de última actualización', () => {
  const base = new Date(2026, 10, 12, 15, 0, 0);
  const hace = (segundos: number) => new Date(base.getTime() + segundos * 1000);

  it('dice "justo ahora" durante el primer minuto', () => {
    expect(textoActualizado(base, base)).toBe('Actualizado justo ahora');
    expect(textoActualizado(base, hace(59))).toBe('Actualizado justo ahora');
  });

  it('cuenta minutos y horas en singular y plural', () => {
    expect(textoActualizado(base, hace(60))).toBe('Actualizado hace 1 minuto');
    expect(textoActualizado(base, hace(5 * 60))).toBe('Actualizado hace 5 minutos');
    expect(textoActualizado(base, hace(59 * 60))).toBe('Actualizado hace 59 minutos');
    expect(textoActualizado(base, hace(60 * 60))).toBe('Actualizado hace 1 hora');
    expect(textoActualizado(base, hace(3 * 60 * 60))).toBe('Actualizado hace 3 horas');
  });

  it('avisa cuando nunca se ha cargado', () => {
    expect(textoActualizado(null, base)).toBe('Sin actualizar');
  });
});

describe('Dashboard: período Hoy y proyección del cierre', () => {
  function ventaEn(fecha: Date, total: number): VentaDashboardApi {
    return venta(fecha, total, [linea(1, 'Café', total)]);
  }

  it('abre el día en curso y compara contra ayer a la misma hora', () => {
    const rango = calcularRangoPeriodo('1d', AHORA);
    expect(rango.inicio).toEqual(new Date(2026, 10, 12));
    expect(rango.fin).toEqual(new Date(2026, 10, 13));
    expect(rango.diasTotales).toBe(1);
    expect(rango.diasTranscurridos).toBe(1);
    expect(rango.inicioPrevio).toEqual(new Date(2026, 10, 11));
    expect(rango.finPrevio).toEqual(new Date(2026, 10, 11, 15, 0));
  });

  it('proyecta el cierre con los jueves anteriores a la misma hora', () => {
    const ventas = [
      // Jueves anteriores: a las 15:00 se llevaba el 25 % del día (100 de 400).
      ventaEn(new Date(2026, 9, 22, 10), 100),
      ventaEn(new Date(2026, 9, 22, 18), 300),
      ventaEn(new Date(2026, 9, 29, 10), 100),
      ventaEn(new Date(2026, 9, 29, 18), 300),
      ventaEn(new Date(2026, 10, 5, 10), 100),
      ventaEn(new Date(2026, 10, 5, 18), 300),
      // Hoy: lo vendido hasta ahora.
      ventaEn(new Date(2026, 10, 12, 10), 50),
    ];

    const esc = construirEscenario(ventas, new Map(), '1d', AHORA);

    expect(esc.proyeccion.estado).toBe('disponible');
    expect(esc.proyeccion.ocurrencias).toBe(3);
    expect(esc.proyeccion.factor).toBe(4);
    expect(esc.proyeccion.mensaje).toContain('3 días anteriores de jueves');
    expect(esc.kpis.find((k) => k.id === 'ingresos')?.titulo).toBe('Total vendido (hoy)');
  });

  it('no proyecta si no hay días suficientes del mismo día de la semana', () => {
    const ventas = [
      ventaEn(new Date(2026, 9, 29, 10), 100),
      ventaEn(new Date(2026, 10, 5, 10), 100),
      // Un miércoles no cuenta para el jueves.
      ventaEn(new Date(2026, 10, 4, 10), 100),
      // Ya hay una venta hoy: el caso es falta de historial, no día sin movimiento.
      ventaEn(new Date(2026, 10, 12, 10), 50),
    ];

    const esc = construirEscenario(ventas, new Map(), '1d', AHORA);

    expect(esc.proyeccion.estado).toBe('historial-insuficiente');
    expect(esc.proyeccion.factor).toBe(1);
    expect(esc.proyeccion.ocurrencias).toBe(2);
    expect(esc.proyeccion.mensaje).toContain('Aún no hay días suficientes');
    // Sin proyección el KPI de cierre no se expone: la IA no debe recibir una cifra que parezca un cierre.
    expect(esc.kpis.find((k) => k.id === 'proyeccion-ia')).toBeUndefined();
  });

  it('no proyecta si los días anteriores no tuvieron ventas a esta hora', () => {
    const ventas = [
      ventaEn(new Date(2026, 9, 22, 18), 300),
      ventaEn(new Date(2026, 9, 29, 18), 300),
      ventaEn(new Date(2026, 10, 5, 18), 300),
      ventaEn(new Date(2026, 10, 12, 10), 50),
    ];

    const esc = construirEscenario(ventas, new Map(), '1d', AHORA);

    expect(esc.proyeccion.estado).toBe('sin-ventas-a-esta-hora');
  });

  it('usa las franjas horarias del local como tramos del gráfico de hoy', () => {
    const esc = construirEscenario(
      [ventaEn(new Date(2026, 10, 12, 9), 100)],
      new Map(),
      '1d',
      AHORA,
    );
    const etiquetas = esc.serieIngresos.map((p) => p.etiqueta);
    // A las 15:00 ya transcurrieron Mañana, Media mañana y Almuerzo.
    expect(etiquetas.slice(0, 3)).toEqual(['Mañana', 'Media mañana', 'Almuerzo']);
    expect(etiquetas.at(-1)).toBe('Cierre (Est.)');
  });

  it('mantiene la proyección por días operativos en los demás períodos', () => {
    const esc = construirEscenario(
      [ventaEn(new Date(2026, 10, 10, 12), 2000)],
      new Map(),
      '30d',
      AHORA,
    );
    expect(esc.proyeccion.estado).toBe('disponible');
    expect(esc.proyeccion.factor).toBeGreaterThan(1);
  });

  it('con el día sin ventas no proyecta cero pesos como si fuera un cierre', () => {
    const ventas = [
      ventaEn(new Date(2026, 9, 29, 10), 400),
      ventaEn(new Date(2026, 10, 5, 10), 400),
      ventaEn(new Date(2026, 10, 6, 10), 400),
    ];

    const esc = construirEscenario(ventas, new Map(), '1d', AHORA);

    expect(esc.proyeccion.estado).toBe('sin-ventas-hoy');
    expect(esc.proyeccion.factor).toBe(1);
    expect(esc.proyeccion.mensaje).toContain('Todavía no hay ventas registradas hoy');
    expect(esc.kpis.find((k) => k.id === 'proyeccion-ia')).toBeUndefined();
  });

  it('descarta días anteriores sin ventas al contar ocurrencias', () => {
    const ventas = [
      ventaEn(new Date(2026, 9, 22, 10), 400),
      // Día con total 0: no sirve como referencia.
      ventaEn(new Date(2026, 9, 29, 10), 0),
      ventaEn(new Date(2026, 10, 5, 10), 400),
      ventaEn(new Date(2026, 10, 12, 10), 50),
    ];

    const esc = construirEscenario(ventas, new Map(), '1d', AHORA);

    expect(esc.proyeccion.ocurrencias).toBe(2);
    expect(esc.proyeccion.estado).toBe('historial-insuficiente');
  });

  it('limita la proyección a 100 veces lo vendido y no muestra "0 %"', () => {
    // Cada jueves anterior: 1 de 1000 antes de las 15:00 → fracción 0,001.
    const ventas = [
      ventaEn(new Date(2026, 9, 22, 9), 1),
      ventaEn(new Date(2026, 9, 22, 18), 999),
      ventaEn(new Date(2026, 9, 29, 9), 1),
      ventaEn(new Date(2026, 9, 29, 18), 999),
      ventaEn(new Date(2026, 10, 5, 9), 1),
      ventaEn(new Date(2026, 10, 5, 18), 999),
      ventaEn(new Date(2026, 10, 12, 10), 10),
    ];

    const esc = construirEscenario(ventas, new Map(), '1d', AHORA);

    expect(esc.proyeccion.estado).toBe('disponible');
    expect(esc.proyeccion.factor).toBe(100);
    expect(esc.proyeccion.mensaje).toContain('menos del 1 %');
  });

  it('ubica la venta en la franja que empieza a esa hora exacta', () => {
    const tramo = (hora: number, minuto: number) =>
      construirEscenario(
        [ventaEn(new Date(2026, 10, 12, hora, minuto), 100)],
        new Map(),
        '1d',
        AHORA,
      ).serieIngresos.map((p) => p.realClp ?? 0);

    // 12:59 todavía es "Media mañana"; 13:00 ya es "Almuerzo".
    expect(tramo(12, 59).slice(0, 3)).toEqual([0, 100, 100]);
    expect(tramo(13, 0).slice(0, 3)).toEqual([0, 0, 100]);
  });

  it('respeta fechas con zona horaria explícita (TIMESTAMPTZ)', () => {
    const ventaConZona: VentaDashboardApi = {
      id: 99,
      fecha_venta: '2026-11-12T11:30:00-03:00',
      total: 2500,
      detalle_venta: [linea(1, 'Café', 2500)],
    };
    const esc = construirEscenario([ventaConZona], new Map(), '1d', AHORA);
    expect(esc.kpis.find((k) => k.id === 'ingresos')?.montoClp).toBe(2500);
  });
});
