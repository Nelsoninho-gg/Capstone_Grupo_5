import { TIPO_XLSX, crc32, crearXlsx, letraColumna } from './xlsx';

/** Lee el ZIP sin compresión que arma crearXlsx: nombre → contenido (y valida el CRC). */
function leerZip(bytes: Uint8Array): Map<string, string> {
  const vista = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const decodificador = new TextDecoder();
  const archivos = new Map<string, string>();
  let posicion = 0;
  while (vista.getUint32(posicion, true) === 0x04034b50) {
    expect(vista.getUint16(posicion + 8, true)).toBe(0); // sin compresión
    const crc = vista.getUint32(posicion + 14, true);
    const tamano = vista.getUint32(posicion + 18, true);
    const largoNombre = vista.getUint16(posicion + 26, true);
    const nombre = decodificador.decode(bytes.subarray(posicion + 30, posicion + 30 + largoNombre));
    const datos = bytes.subarray(posicion + 30 + largoNombre, posicion + 30 + largoNombre + tamano);
    expect(crc32(datos)).toBe(crc);
    archivos.set(nombre, decodificador.decode(datos));
    posicion += 30 + largoNombre + tamano;
  }
  // Después de los archivos viene el directorio central y, al final, su cierre.
  expect(vista.getUint32(posicion, true)).toBe(0x02014b50);
  const fin = bytes.length - 22;
  expect(vista.getUint32(fin, true)).toBe(0x06054b50);
  expect(vista.getUint16(fin + 10, true)).toBe(archivos.size);
  expect(vista.getUint32(fin + 16, true)).toBe(posicion);
  return archivos;
}

describe('crearXlsx', () => {
  const hoja = {
    nombre: 'Por comprar',
    columnas: [
      { titulo: 'Artículo', ancho: 30 },
      { titulo: 'Stock', ancho: 10 },
      { titulo: 'Comprar', ancho: 10, destacada: true },
    ],
    filas: [
      ['Pan <amasado> & "queso"', 6, 6.5],
      ['Chaparrita', -1, 9],
      ['Sin stock', null, 0],
    ],
  };

  it('packs the parts of a workbook in a valid ZIP', () => {
    const archivos = leerZip(crearXlsx(hoja));
    expect([...archivos.keys()]).toEqual([
      '[Content_Types].xml',
      '_rels/.rels',
      'xl/workbook.xml',
      'xl/_rels/workbook.xml.rels',
      'xl/styles.xml',
      'xl/worksheets/sheet1.xml',
    ]);
    expect(archivos.get('xl/workbook.xml')).toContain('<sheet name="Por comprar"');
    expect(archivos.get('xl/workbook.xml')).toContain("'Por comprar'!$A$1:$C$4");
  });

  it('writes text as inline strings and numbers as numbers', () => {
    const xml = leerZip(crearXlsx(hoja)).get('xl/worksheets/sheet1.xml')!;
    expect(xml).toContain(
      '<c r="A1" s="1" t="inlineStr"><is><t xml:space="preserve">Artículo</t></is></c>',
    );
    expect(xml).toContain('Pan &lt;amasado&gt; &amp; &quot;queso&quot;');
    expect(xml).toContain('<c r="B2"><v>6</v></c>');
    expect(xml).toContain('<c r="C2" s="2"><v>6.5</v></c>');
    expect(xml).toContain('<c r="B3"><v>-1</v></c>');
    // Una celda vacía no se escribe; el 0 sí.
    expect(xml).toContain(
      '<row r="4"><c r="A4" t="inlineStr"><is><t xml:space="preserve">Sin stock</t></is></c><c r="C4" s="2"><v>0</v></c></row>',
    );
  });

  it('freezes the header, filters it and sets the column widths', () => {
    const xml = leerZip(crearXlsx(hoja)).get('xl/worksheets/sheet1.xml')!;
    expect(xml).toContain('state="frozen"');
    expect(xml).toContain('<autoFilter ref="A1:C4"/>');
    expect(xml).toContain('<col min="1" max="1" width="30" customWidth="1"/>');
  });

  it('cleans sheet names that Excel would reject', () => {
    const archivos = leerZip(
      crearXlsx({ ...hoja, nombre: 'Compras 30/10: [Ñuñoa] y otra sucursal larga' }),
    );
    expect(archivos.get('xl/workbook.xml')).toContain(
      '<sheet name="Compras 30 10   Ñuñoa  y otra s"',
    );
  });

  it('exposes the Excel media type', () => {
    expect(TIPO_XLSX).toBe('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  });
});

describe('letraColumna', () => {
  it.each([
    [0, 'A'],
    [8, 'I'],
    [25, 'Z'],
    [26, 'AA'],
    [701, 'ZZ'],
    [702, 'AAA'],
  ])('%i → %s', (indice, letras) => {
    expect(letraColumna(indice)).toBe(letras);
  });
});

describe('crc32', () => {
  it('matches the standard ZIP checksum', () => {
    expect(crc32(new TextEncoder().encode('123456789'))).toBe(0xcbf43926);
    expect(crc32(new Uint8Array())).toBe(0);
  });
});
