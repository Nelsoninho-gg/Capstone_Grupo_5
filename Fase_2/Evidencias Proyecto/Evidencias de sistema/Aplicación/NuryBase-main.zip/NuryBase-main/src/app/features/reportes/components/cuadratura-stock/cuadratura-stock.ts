import { Component, computed, input } from '@angular/core';
import { CuadraturaArticulo } from '../../models/reportes.model';
import { formatoNumero } from '../../models/formato';

export type EstadoCuadratura = 'cargando' | 'error' | 'listo';

/**
 * Aviso de cuadratura con el inventario (H4.1 T04): confirma que las cantidades vendidas del
 * período coinciden con los movimientos de venta de movimientos_stock, o lista los artículos
 * que no cuadran, con lo esperado, lo registrado y la diferencia.
 */
@Component({
  selector: 'app-cuadratura-stock',
  templateUrl: './cuadratura-stock.html',
  styleUrls: ['../../styles/reportes-base.css', './cuadratura-stock.css'],
})
export class CuadraturaStock {
  readonly filas = input<CuadraturaArticulo[] | null>(null);
  readonly estado = input<EstadoCuadratura>('cargando');

  protected readonly diferencias = computed(() => (this.filas() ?? []).filter((f) => !f.cuadra));
  protected readonly revisados = computed(() => (this.filas() ?? []).length);

  protected cantidad(fila: CuadraturaArticulo, valor: number): string {
    return `${formatoNumero.format(valor)} ${fila.unidad}`;
  }

  protected diferencia(fila: CuadraturaArticulo): string {
    const signo = fila.diferencia > 0 ? '+' : '−';
    return `${signo}${formatoNumero.format(Math.abs(fila.diferencia))} ${fila.unidad}`;
  }

  protected numero(valor: number): string {
    return formatoNumero.format(valor);
  }
}
