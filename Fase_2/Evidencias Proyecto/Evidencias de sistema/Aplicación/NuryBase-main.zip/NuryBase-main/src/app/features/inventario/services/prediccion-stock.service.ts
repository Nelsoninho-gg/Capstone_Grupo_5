import { Injectable, inject } from '@angular/core';
import { Observable, catchError, forkJoin, map, of } from 'rxjs';
import { ConsumoDiarioArticuloApi, StockApiService } from '../../../core/api/stock-api.service';
import { OrquestadorIaService } from '../../../core/ia/orquestador-ia.service';
import {
  PuntoConsumoDiario,
  claveSerieConsumo,
  construirPayloadHistoricoIA,
  construirSeriesOperativas,
  depurarSerieConsumo,
} from '../models/analisis-historico.model';
import {
  MENSAJE_DATOS_INSUFICIENTES,
  PrediccionArticuloIA,
  construirEntradaPrediccionIA,
  construirMensajesPrediccionIA,
  formatearFechaChile,
} from '../models/prediccion-ia.contract';
import {
  ArticuloPredictivo,
  ResumenMadurezDatos,
  calcularConsumoDiarioEfectivo,
  cantidadSugeridaCompra,
  diasEnteros,
  diasHastaMinimo,
  evaluarEstadoPredictivo,
  evaluarMadurezDatos,
  tieneHistorialSuficiente,
  formatearCantidadStock,
  textoDiasOperacion,
} from '../models/prediccion.model';
import { validarInterpretacionIA } from '../models/validador-prediccion-ia';
import { PredictiveCacheService } from './predictive-cache.service';

export type OrigenPrediccion =
  | 'ia'
  | 'cache'
  | 'respaldo-local'
  | 'datos-insuficientes-local';

export interface ResultadoPrediccionStock {
  origen: OrigenPrediccion;
  proveedorUsado?: string;
  fechaReferencia: string;
  sucursalId: number | null;
  predicciones: PrediccionArticuloIA[];
  madurez: ResumenMadurezDatos;
}

const DIAS_VENTANA_CONSUMO = 28;
// Con 361 artículos en una sola petición fallaron los 4 modelos; el resto conserva el texto del algoritmo.
const MAX_ARTICULOS_IA = 30;
const DIA_MS = 24 * 60 * 60 * 1000;

function sumarDiasAFechaIso(fechaIso: string, dias: number): string {
  const [anio, mes, dia] = fechaIso.split('-').map(Number);
  return formatearFechaChile(new Date(anio, mes - 1, dia + dias));
}

/**
 * Cálculo determinista de un artículo: mismos datos, mismo resultado. La IA nunca cambia estas
 * cifras; solo redacta la interpretación.
 */
export function calcularPrediccionArticulo(
  a: ArticuloPredictivo,
  fechaReferenciaStr: string,
): PrediccionArticuloIA {
  if (!tieneHistorialSuficiente(a.diasHistorial)) {
    return {
      articuloId: a.id,
      estado: 'datos-insuficientes',
      tasaDiariaEstimada: null,
      diasHastaMinimo: null,
      fechaRecomendadaPedido: null,
      cantidadSugerida: 0,
      justificacion: MENSAJE_DATOS_INSUFICIENTES,
    };
  }

  const estado = evaluarEstadoPredictivo(a);
  const tasa = a.consumoDiarioBase > 0 ? a.consumoDiarioBase : null;
  const cobertura = diasHastaMinimo(a.stockActual, a.stockMinimo, a.consumoDiarioBase);
  const cantidad = cantidadSugeridaCompra(a);

  let fechaRecomendada: string | null = estado === 'comprar-hoy' ? fechaReferenciaStr : null;
  if (cobertura !== null) {
    const diasEspera = Math.max(0, Math.floor(cobertura - 1.5));
    fechaRecomendada = sumarDiasAFechaIso(fechaReferenciaStr, diasEspera);
  }

  const cant = (valor: number) => `${formatearCantidadStock(valor)} ${a.unidad}`;
  const stock = cant(a.stockActual);
  const minimo = cant(a.stockMinimo);
  const sugerencia = cantidad > 0 ? ` Se sugiere comprar ${cant(cantidad)}.` : '';

  let justificacion = '';
  if (estado === 'comprar-hoy' && tasa === null) {
    justificacion = `El stock (${stock}) está bajo el mínimo (${minimo}) y no hay consumo reciente para estimar más.${sugerencia}${a.stockActual < 0 ? ' Conviene regularizar la diferencia con el stock físico.' : ''}`;
  } else if (estado === 'comprar-hoy' && a.stockActual < a.stockMinimo) {
    justificacion = `Comprar hoy: se usan ${cant(tasa ?? 0)} al día y el stock (${stock}) ya está bajo el mínimo (${minimo}).${sugerencia}`;
  } else if (estado === 'comprar-hoy') {
    justificacion = `Comprar hoy: se usan ${cant(tasa ?? 0)} al día y el stock (${stock}) llega al mínimo (${minimo}) en ${textoDiasOperacion(cobertura ?? 0)}.${sugerencia}`;
  } else if (estado === 'proximo-pedido') {
    const fecha = fechaRecomendada ? ` Conviene programar la compra para el ${fechaRecomendada.split('-').reverse().join('-')}.` : '';
    justificacion = `Comprar pronto: se usan ${cant(tasa ?? 0)} al día y el stock (${stock}) alcanza para ${textoDiasOperacion(cobertura ?? 0)} antes de llegar al mínimo (${minimo}).${fecha}${sugerencia}`;
  } else {
    justificacion =
      cobertura === null
        ? `Sin consumo en los últimos ${DIAS_VENTANA_CONSUMO} días. Hay ${stock} en stock, así que no hace falta comprar.`
        : `Stock suficiente: hay ${stock}, que alcanzan para ${textoDiasOperacion(cobertura)} antes de llegar al mínimo (${minimo}). No hace falta comprar.`;
  }

  return {
    articuloId: a.id,
    estado,
    tasaDiariaEstimada: tasa,
    diasHastaMinimo: cobertura,
    fechaRecomendadaPedido: fechaRecomendada,
    cantidadSugerida: cantidad,
    justificacion,
  };
}

/**
 * Servicio unificado de predicción y sugerencias de compra para inventario (H4.5 T07).
 * Los algoritmos calculan siempre todas las cifras. La IA recibe ese resultado y solo redacta su
 * interpretación; si falla, se muestra la justificación del algoritmo.
 */
@Injectable({ providedIn: 'root' })
export class PrediccionStockService {
  private readonly stockApi = inject(StockApiService);
  private readonly orquestadorIa = inject(OrquestadorIaService);
  private readonly cache = inject(PredictiveCacheService);

  /**
   * Carga los artículos desde v_consumo_diario_articulos y calcula su consumo con la serie diaria.
   * Si la consulta falla, no se muestran artículos: nunca se reemplazan por datos de ejemplo.
   */
  cargarArticulos(
    sucursalId: number | null = null,
    ahora: Date = new Date(),
  ): Observable<ArticuloPredictivo[]> {
    const desde = new Date(ahora.getTime() - DIAS_VENTANA_CONSUMO * DIA_MS);
    return forkJoin({
      filas: this.stockApi.listarConsumoDiarioArticulos(sucursalId),
      // Sin movimientos sigue funcionando con el promedio de la vista.
      movimientos: this.stockApi.listarMovimientosConsumo(sucursalId, desde).pipe(catchError(() => of([]))),
    }).pipe(
      map(({ filas, movimientos }) => {
        const series = construirSeriesOperativas(movimientos);
        return filas.map((f) => this.mapearFilaApiAArticulo(f, series));
      }),
      catchError(() => of([])),
    );
  }

  /**
   * 1. Los algoritmos calculan todos los artículos.
   * 2. Con menos de 28 días no se gasta cuota de IA (H4.5 T03).
   * 3. Solo se interpretan los de compra hoy o pronto: se revisa la caché y luego se pide a la IA.
   */
  generarSugerencias(
    articulos: readonly ArticuloPredictivo[],
    fechaReferencia: Date = new Date(),
  ): Observable<ResultadoPrediccionStock> {
    const fechaRefStr = formatearFechaChile(fechaReferencia);
    const madurez = evaluarMadurezDatos(articulos);
    const sucursalId = articulos[0]?.sucursalId ?? null;
    const calculadas = articulos.map((a) => calcularPrediccionArticulo(a, fechaRefStr));

    const resultado = (origen: OrigenPrediccion, predicciones = calculadas, proveedorUsado?: string) => ({
      origen,
      proveedorUsado,
      fechaReferencia: fechaRefStr,
      sucursalId,
      predicciones,
      madurez,
    });

    const articulosAptos = articulos.filter((a) => tieneHistorialSuficiente(a.diasHistorial));
    if (articulosAptos.length === 0) {
      return of(resultado('datos-insuficientes-local'));
    }

    const comprarHoy = articulosAptos.filter((a) => evaluarEstadoPredictivo(a) === 'comprar-hoy');
    const comprarPronto = articulosAptos.filter((a) => evaluarEstadoPredictivo(a) === 'proximo-pedido');
    const articulosIa = [...comprarHoy, ...comprarPronto].slice(0, MAX_ARTICULOS_IA);
    if (articulosIa.length === 0) {
      return of(resultado('respaldo-local'));
    }

    const combinar = (justificaciones: ReadonlyMap<string, string>) =>
      calculadas.map((p) => {
        const texto = justificaciones.get(p.articuloId);
        return texto ? { ...p, justificacion: texto, interpretadaPorIa: true } : p;
      });

    // La clave incluye las cifras: si cambia el stock, no se reutiliza un texto con datos antiguos.
    const todosMismaSucursal = articulos.every((a) => a.sucursalId === sucursalId);
    const sucursalClave = todosMismaSucursal && sucursalId !== null ? sucursalId : 'global';
    const claveCache = this.cache.construirClave(
      sucursalClave,
      fechaRefStr,
      articulosIa.map((a) => `${a.id}:${a.stockActual}:${a.stockMinimo}:${a.consumoDiarioBase}`),
    );
    const enCache = this.cache.obtener(claveCache);
    if (enCache) {
      return of(
        resultado('cache', combinar(new Map(enCache.predicciones.map((p) => [p.articuloId, p.justificacion])))),
      );
    }

    const calculoPorId = new Map(calculadas.map((p) => [p.articuloId, p]));
    const entradaIa = construirEntradaPrediccionIA(
      articulosIa.map((a) => {
        const { articuloId: _id, justificacion: _texto, ...calculo } = calculoPorId.get(a.id)!;
        return {
          ...construirPayloadHistoricoIA(a, a.serieConsumo ?? []),
          calculo: { ...calculo, diasHastaMinimo: diasEnteros(calculo.diasHastaMinimo) },
        };
      }),
      fechaReferencia,
    );

    return this.orquestadorIa.solicitar(construirMensajesPrediccionIA(entradaIa)).pipe(
      map((respuestaIa) => {
        const validacion = validarInterpretacionIA(respuestaIa.contenido, entradaIa.articulos);
        if (validacion.errores.length > 0) {
          console.warn('[Predicción] Textos de la IA descartados:', validacion.errores);
        }
        if (!validacion.exito) {
          return resultado('respaldo-local');
        }
        const predicciones = combinar(validacion.justificaciones);
        this.cache.guardar(claveCache, sucursalClave, {
          predicciones: predicciones.filter((p) => validacion.justificaciones.has(p.articuloId)),
        });
        return resultado('ia', predicciones, `${respuestaIa.proveedorId} (${respuestaIa.modelo})`);
      }),
      catchError(() => of(resultado('respaldo-local'))),
    );
  }

  private mapearFilaApiAArticulo(
    f: ConsumoDiarioArticuloApi,
    series: ReadonlyMap<string, PuntoConsumoDiario[]>,
  ): ArticuloPredictivo {
    const consumoTotal = Number(f.consumo_total_28d ?? 0);
    const diasHist = Number(f.dias_con_historial ?? 0);
    const serie = tieneHistorialSuficiente(diasHist)
      ? series.get(claveSerieConsumo(f.tipo, f.articulo_id, f.sucursal_id))
      : undefined;

    return {
      id: `art-${f.tipo}-${f.articulo_id}-${f.sucursal_id}`,
      articulo: f.nombre,
      tipo: f.tipo,
      sucursalId: f.sucursal_id,
      sucursal: f.sucursal,
      stockActual: Number(f.stock_actual ?? 0),
      stockMinimo: Number(f.stock_minimo ?? 0),
      unidad: f.unidad ?? '',
      diasHistorial: diasHist,
      consumoDiarioBase: serie?.length
        ? depurarSerieConsumo(serie).promedioBaseLimpio
        : calcularConsumoDiarioEfectivo(consumoTotal, diasHist),
      serieConsumo: serie,
    };
  }
}
