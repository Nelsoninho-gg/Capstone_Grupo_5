import { TestBed } from '@angular/core/testing';
import { cajeroDePrueba } from '../../models/datos-prueba';
import { ReporteCajeros } from './reporte-cajeros';

describe('ReporteCajeros', () => {
  const camila = cajeroDePrueba();
  const diego = cajeroDePrueba({
    cajeroId: 2,
    cajero: 'Diego Soto',
    ventas: 20,
    total: 40000,
    ventaPromedio: 2000,
    productos: 30,
    anuladas: { ventas: 5, total: 10000 },
  });
  const sinCajero = cajeroDePrueba({
    cajeroId: null,
    cajero: 'Sin cajero',
    ventas: 1,
    total: 800,
    ventaPromedio: 800,
    productos: 1,
  });

  function render(
    cajeros = [camila, diego, sinCajero],
    anteriores = [cajeroDePrueba({ total: 40000 })],
  ) {
    const fixture = TestBed.createComponent(ReporteCajeros);
    fixture.componentRef.setInput('cajeros', cajeros);
    fixture.componentRef.setInput('cajerosAnterior', anteriores);
    fixture.detectChanges();
    const element = fixture.nativeElement as HTMLElement;
    const nombres = () =>
      Array.from(element.querySelectorAll('tbody tr')).map((f) =>
        f.querySelector('.row-name')?.firstChild?.textContent?.trim(),
      );
    const ordenar = (valor: string) => {
      element.querySelector<HTMLButtonElement>('[aria-label="Ordenar cajeros por"]')!.click();
      fixture.detectChanges();
      element.querySelector<HTMLButtonElement>(`[role="option"][data-value="${valor}"]`)!.click();
      fixture.detectChanges();
    };
    return { element, nombres, ordenar };
  }

  it('shows the four metrics per cashier sorted by total sold', () => {
    const { element, nombres } = render();
    expect(nombres()).toEqual(['Camila Rojas', 'Diego Soto', 'Sin cajero']);
    const fila = element.querySelector('tbody tr')!;
    expect(fila.querySelector('[data-label="Total vendido"]')?.textContent?.trim()).toBe('$50.000');
    expect(fila.querySelector('[data-label="Ventas"]')?.textContent?.trim()).toBe('10');
    expect(fila.querySelector('[data-label="Venta promedio"]')?.textContent?.trim()).toBe('$5.000');
    expect(fila.querySelector('[data-label="Productos"]')?.textContent?.trim()).toBe('25');
  });

  it('sorts by any metric and compares each cashier with their own previous period', () => {
    const { element, nombres, ordenar } = render();
    expect(
      element.querySelector('tbody tr [data-label="Período anterior"]')?.textContent,
    ).toContain('▲ 25 %');
    expect(
      element.querySelector('tbody tr [data-label="Período anterior"]')?.textContent,
    ).toContain('$40.000');

    ordenar('ventas');
    expect(nombres()).toEqual(['Diego Soto', 'Camila Rojas', 'Sin cajero']);
    ordenar('ventaPromedio');
    expect(nombres()[0]).toBe('Camila Rojas');
    expect(element.querySelector('thead')?.textContent).toContain(
      'Venta promedio · período anterior',
    );
  });

  it('lists voided sales apart with how often each cashier voids', () => {
    const { element } = render();
    const anulaciones = Array.from(element.querySelectorAll('.voids li'));
    expect(anulaciones).toHaveLength(1);
    expect(anulaciones[0].textContent).toContain('Diego Soto');
    expect(anulaciones[0].textContent).toMatch(/5 anuladas · \$10\.000/);
    expect(anulaciones[0].textContent).toContain('20 % de sus ventas');
    expect(render([camila], []).element.textContent).toContain(
      'Ninguna venta anulada en el período.',
    );
  });
});
