import {
  PromocionesDiaApi,
  PromocionesProductoApi,
} from '../../../core/api/reportes-api.service';

/**
 * Efecto de las promociones en las ventas (H5.2 T08). "Con descuento" es lo vendido en líneas
 * con promoción (precio final); "margen sacrificado" es lo que la promoción dejó de ganar
 * (precio original − precio final). El 30% de venta a empleado no es una promoción.
 */
export interface PromocionesPeriodo {
  /** Primer día del período (AAAA-MM-DD, hora de Chile). */
  desde: string;
  hasta: string;
  vendido: number;
  vendidoConDescuento: number;
  precioListaConDescuento: number;
  unidadesConDescuento: number;
  ventasConPromocion: number;
  margenSacrificado: number;
}

export interface PromocionesProducto {
  productoId: number;
  producto: string;
  categoria: string | null;
  unidades: number;
  vendido: number;
  unidadesConDescuento: number;
  vendidoConDescuento: number;
  precioListaConDescuento: number;
  margenSacrificado: number;
  /** Margen ganado en lo vendido con promoción; null si no hay costo registrado. */
  margenConDescuento: number | null;
  promociones: string[];
}

export type AgrupacionPeriodo = 'dia' | 'semana' | 'mes';

export function promocionesDia(fila: PromocionesDiaApi): PromocionesPeriodo {
  return {
    desde: fila.dia,
    hasta: fila.dia,
    vendido: Number(fila.vendido),
    vendidoConDescuento: Number(fila.vendido_con_descuento),
    precioListaConDescuento: Number(fila.precio_lista_con_descuento),
    unidadesConDescuento: Number(fila.unidades_con_descuento),
    ventasConPromocion: Number(fila.ventas_con_promocion),
    margenSacrificado: Number(fila.margen_sacrificado),
  };
}

export function promocionesProducto(fila: PromocionesProductoApi): PromocionesProducto {
  return {
    productoId: fila.producto_id,
    producto: fila.producto,
    categoria: fila.categoria,
    unidades: Number(fila.unidades),
    vendido: Number(fila.vendido),
    unidadesConDescuento: Number(fila.unidades_con_descuento),
    vendidoConDescuento: Number(fila.vendido_con_descuento),
    precioListaConDescuento: Number(fila.precio_lista_con_descuento),
    margenSacrificado: Number(fila.margen_sacrificado),
    margenConDescuento: fila.margen_con_descuento === null ? null : Number(fila.margen_con_descuento),
    promociones: fila.promociones ? fila.promociones.split(', ') : [],
  };
}

/** Lunes de la semana del día (AAAA-MM-DD), sin depender de la zona del navegador. */
function lunesDe(dia: string): string {
  const [anio, mes, numero] = dia.split('-').map(Number);
  const fecha = new Date(Date.UTC(anio, mes - 1, numero));
  fecha.setUTCDate(fecha.getUTCDate() - ((fecha.getUTCDay() + 6) % 7));
  return fecha.toISOString().slice(0, 10);
}

function claveDe(dia: string, agrupacion: AgrupacionPeriodo): string {
  if (agrupacion === 'semana') return lunesDe(dia);
  if (agrupacion === 'mes') return dia.slice(0, 7);
  return dia;
}

/** Junta los días por semana (lunes a domingo) o por mes, dentro del período consultado. */
export function agruparPeriodos(
  dias: readonly PromocionesPeriodo[],
  agrupacion: AgrupacionPeriodo,
): PromocionesPeriodo[] {
  const grupos = new Map<string, PromocionesPeriodo>();
  for (const dia of [...dias].sort((a, b) => a.desde.localeCompare(b.desde))) {
    const clave = claveDe(dia.desde, agrupacion);
    const grupo = grupos.get(clave);
    if (!grupo) {
      grupos.set(clave, { ...dia });
      continue;
    }
    grupo.hasta = dia.hasta;
    grupo.vendido += dia.vendido;
    grupo.vendidoConDescuento += dia.vendidoConDescuento;
    grupo.precioListaConDescuento += dia.precioListaConDescuento;
    grupo.unidadesConDescuento += dia.unidadesConDescuento;
    grupo.ventasConPromocion += dia.ventasConPromocion;
    grupo.margenSacrificado += dia.margenSacrificado;
  }
  return [...grupos.values()];
}

/** Totales del período completo; null si no hay días. */
export function totalPromociones(dias: readonly PromocionesPeriodo[]): PromocionesPeriodo | null {
  if (!dias.length) return null;
  const [total] = agruparPeriodos(
    dias.map((dia) => ({ ...dia, desde: dias[0].desde })),
    'dia',
  );
  return { ...total, hasta: dias[dias.length - 1].hasta };
}

/** Porcentaje de `parte` sobre `total` (0 si no hay total). */
export function porcentaje(parte: number, total: number): number {
  return total > 0 ? (parte / total) * 100 : 0;
}
