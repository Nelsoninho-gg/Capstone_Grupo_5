-- =====================================================================
-- Migración: TIMESTAMP (sin zona, en UTC) -> TIMESTAMPTZ y TimeZone = 'America/Santiago'
--
-- ANTES DE APLICAR EN PRODUCCIÓN:
--   1) Tomar respaldo completo (pg_dump) de la base.
--   2) Ejecutar primero database/migrations/20261116_timestamptz_chile.ENSAYO.sql
--      (termina en ROLLBACK) y comprobar que las 3 últimas ventas muestren -03.
--   3) Aplicar este archivo con ON_ERROR_STOP=1:
--      docker exec -i nury-postgres sh -c 'psql -v ON_ERROR_STOP=1 -U "${POSTGRES_USER:-postgres}" -d "${POSTGRES_DB:-postgres}"' < database/migrations/20261116_timestamptz_chile.sql
--   4) Reiniciar PostgREST para que sus conexiones tomen el nuevo TimeZone:
--      docker restart nury-postgrest
-- =====================================================================

BEGIN;

CREATE TEMP TABLE _tz_owners (
    obj_kind   TEXT NOT NULL,
    obj_name   TEXT NOT NULL,
    owner_name TEXT NOT NULL
) ON COMMIT DROP;

INSERT INTO _tz_owners (obj_kind, obj_name, owner_name)
SELECT 'VIEW', format('public.%I', c.relname), pg_get_userbyid(c.relowner)
  FROM pg_class c
  JOIN pg_namespace n ON n.oid = c.relnamespace
 WHERE n.nspname = 'public'
   AND c.relkind = 'v'
   AND c.relname IN (
       'v_articulos',
       'v_existencias_articulos',
       'v_estado_stock',
       'v_consumo_diario_articulos',
       'v_movimientos_articulos'
   );

INSERT INTO _tz_owners (obj_kind, obj_name, owner_name)
SELECT 'FUNCTION', 'public.fn_versiones_receta(integer)', pg_get_userbyid(p.proowner)
  FROM pg_proc p
 WHERE p.oid = 'public.fn_versiones_receta(integer)'::regprocedure;

DROP VIEW public.v_estado_stock;
DROP VIEW public.v_consumo_diario_articulos;
DROP VIEW public.v_movimientos_articulos;
DROP VIEW public.v_existencias_articulos;
DROP VIEW public.v_articulos;
DROP FUNCTION public.fn_versiones_receta(integer);

ALTER TABLE public.alertas_margen
    ALTER COLUMN creado_en TYPE TIMESTAMPTZ USING creado_en AT TIME ZONE 'UTC';

ALTER TABLE public.almuerzos_empleado
    ALTER COLUMN creado_en TYPE TIMESTAMPTZ USING creado_en AT TIME ZONE 'UTC';

ALTER TABLE public.auditoria_usuarios
    ALTER COLUMN creado_en TYPE TIMESTAMPTZ USING creado_en AT TIME ZONE 'UTC';

ALTER TABLE public.facturas_compra
    ALTER COLUMN fecha_registro TYPE TIMESTAMPTZ USING fecha_registro AT TIME ZONE 'UTC',
    ALTER COLUMN creado_en      TYPE TIMESTAMPTZ USING creado_en      AT TIME ZONE 'UTC';

ALTER TABLE public.facturas_xml_pendientes
    ALTER COLUMN confirmado_en TYPE TIMESTAMPTZ USING confirmado_en AT TIME ZONE 'UTC',
    ALTER COLUMN creado_en     TYPE TIMESTAMPTZ USING creado_en     AT TIME ZONE 'UTC';

ALTER TABLE public.ingredientes
    ALTER COLUMN creado_en      TYPE TIMESTAMPTZ USING creado_en      AT TIME ZONE 'UTC',
    ALTER COLUMN actualizado_en TYPE TIMESTAMPTZ USING actualizado_en AT TIME ZONE 'UTC';

ALTER TABLE public.intentos_factura_duplicada
    ALTER COLUMN creado_en TYPE TIMESTAMPTZ USING creado_en AT TIME ZONE 'UTC';

ALTER TABLE public.productos
    ALTER COLUMN creado_en TYPE TIMESTAMPTZ USING creado_en AT TIME ZONE 'UTC';

ALTER TABLE public.promociones
    ALTER COLUMN creado_en TYPE TIMESTAMPTZ USING creado_en AT TIME ZONE 'UTC';

ALTER TABLE public.proveedores
    ALTER COLUMN creado_en TYPE TIMESTAMPTZ USING creado_en AT TIME ZONE 'UTC';

ALTER TABLE public.recetas_version
    ALTER COLUMN vigente_desde TYPE TIMESTAMPTZ USING vigente_desde AT TIME ZONE 'UTC';

ALTER TABLE public.stock_producto_sucursal
    ALTER COLUMN actualizado_en TYPE TIMESTAMPTZ USING actualizado_en AT TIME ZONE 'UTC';

ALTER TABLE public.stock_sucursal
    ALTER COLUMN actualizado_en TYPE TIMESTAMPTZ USING actualizado_en AT TIME ZONE 'UTC';

ALTER TABLE public.sucursales
    ALTER COLUMN creado_en TYPE TIMESTAMPTZ USING creado_en AT TIME ZONE 'UTC';

ALTER TABLE public.turnos
    ALTER COLUMN hora_inicio TYPE TIMESTAMPTZ USING hora_inicio AT TIME ZONE 'UTC',
    ALTER COLUMN hora_fin    TYPE TIMESTAMPTZ USING hora_fin    AT TIME ZONE 'UTC',
    ALTER COLUMN creado_en   TYPE TIMESTAMPTZ USING creado_en   AT TIME ZONE 'UTC';

ALTER TABLE public.usuarios
    ALTER COLUMN creado_en      TYPE TIMESTAMPTZ USING creado_en      AT TIME ZONE 'UTC',
    ALTER COLUMN actualizado_en TYPE TIMESTAMPTZ USING actualizado_en AT TIME ZONE 'UTC';

ALTER TABLE public.ventas
    ALTER COLUMN fecha_venta TYPE TIMESTAMPTZ USING fecha_venta AT TIME ZONE 'UTC',
    ALTER COLUMN anulada_en  TYPE TIMESTAMPTZ USING anulada_en  AT TIME ZONE 'UTC',
    ALTER COLUMN creado_en   TYPE TIMESTAMPTZ USING creado_en   AT TIME ZONE 'UTC';

CREATE VIEW public.v_articulos AS
SELECT 'materia_prima'::VARCHAR(20)  AS tipo,
       i.id                          AS articulo_id,
       i.nombre,
       i.unidad_id,
       um.abreviatura                AS unidad,
       um.nombre                     AS unidad_nombre,
       i.codigo_barras,
       i.activo,
       i.creado_en
  FROM public.ingredientes i
  JOIN public.unidades_medida um ON um.id = i.unidad_id
UNION ALL
SELECT 'producto'::VARCHAR(20),
       p.id,
       p.nombre,
       NULL::INTEGER,
       'un'::VARCHAR(10),
       'Unidad'::VARCHAR(40),
       p.codigo_barras,
       p.activo,
       p.creado_en
  FROM public.productos p
 WHERE NOT EXISTS (SELECT 1 FROM public.recetas r WHERE r.producto_id = p.id);

COMMENT ON VIEW public.v_articulos IS
    'Artículos de bodega (H3.3 T02): materias primas (ingredientes) y productos normales (productos sin receta). Los productos se cuentan por unidad.';
COMMENT ON COLUMN public.v_articulos.tipo IS 'materia_prima | producto';
COMMENT ON COLUMN public.v_articulos.articulo_id IS 'ingredientes.id o productos.id según tipo';
COMMENT ON COLUMN public.v_articulos.unidad_id IS 'Unidad de la materia prima; NULL en productos (siempre "un")';

REVOKE ALL ON public.v_articulos FROM PUBLIC;
GRANT SELECT ON public.v_articulos TO nury_admin, nury_bodeguero;

CREATE VIEW public.v_existencias_articulos AS
SELECT 'materia_prima'::character varying(20) AS tipo,
       s.ingrediente_id AS articulo_id,
       i.nombre,
       um.abreviatura AS unidad,
       i.activo,
       s.sucursal_id,
       su.nombre AS sucursal,
       s.stock_actual,
       s.stock_minimo,
       s.actualizado_en
  FROM public.stock_sucursal s
  JOIN public.ingredientes i ON i.id = s.ingrediente_id
  JOIN public.unidades_medida um ON um.id = i.unidad_id
  JOIN public.sucursales su ON su.id = s.sucursal_id
 WHERE (SELECT public.fn_sucursal_restringida()) IS NULL
    OR s.sucursal_id = (SELECT public.fn_sucursal_restringida())
UNION ALL
SELECT 'producto'::character varying(20) AS tipo,
       s.producto_id AS articulo_id,
       p.nombre,
       'un'::character varying(10) AS unidad,
       p.activo,
       s.sucursal_id,
       su.nombre AS sucursal,
       s.stock_actual,
       s.stock_minimo,
       s.actualizado_en
  FROM public.stock_producto_sucursal s
  JOIN public.productos p ON p.id = s.producto_id
  JOIN public.sucursales su ON su.id = s.sucursal_id
 WHERE NOT EXISTS (
           SELECT 1
             FROM public.recetas r
            WHERE r.producto_id = s.producto_id
       )
   AND (
           (SELECT public.fn_sucursal_restringida()) IS NULL
           OR s.sucursal_id = (SELECT public.fn_sucursal_restringida())
       );

COMMENT ON VIEW public.v_existencias_articulos IS
    'Existencias de cada artículo de bodega (materia prima o producto sin receta) en cada sucursal (H3.3 T02).';

REVOKE ALL ON public.v_existencias_articulos FROM PUBLIC;
GRANT SELECT ON public.v_existencias_articulos TO nury_admin, nury_bodeguero;

CREATE VIEW public.v_estado_stock
WITH (security_invoker = true) AS
SELECT e.tipo,
       e.articulo_id,
       e.nombre,
       e.unidad,
       e.sucursal_id,
       e.sucursal,
       e.stock_actual,
       e.stock_minimo,
       public.fn_estado_stock(e.stock_actual, e.stock_minimo) AS estado,
       GREATEST(e.stock_minimo - e.stock_actual, 0)           AS cantidad_a_reponer
  FROM public.v_existencias_articulos e
 WHERE e.activo;

COMMENT ON VIEW public.v_estado_stock IS
    'H3.5 T04: estado (agotado, critico, estable) de cada artículo activo por sucursal. Reemplaza a v_ingredientes_bajo_stock.';

REVOKE ALL ON public.v_estado_stock FROM PUBLIC;
GRANT SELECT ON public.v_estado_stock TO nury_admin, nury_bodeguero;

CREATE VIEW public.v_consumo_diario_articulos AS
WITH historial AS (
    SELECT CASE WHEN m.ingrediente_id IS NOT NULL THEN 'materia_prima' ELSE 'producto' END AS h_tipo,
           COALESCE(m.ingrediente_id, m.producto_id) AS h_articulo_id,
           m.sucursal_id                             AS h_sucursal_id,
           min(m.creado_en)                          AS primer_movimiento
      FROM public.movimientos_stock m
     GROUP BY 1, 2, 3
), consumo_28d AS (
    SELECT CASE WHEN m.ingrediente_id IS NOT NULL THEN 'materia_prima' ELSE 'producto' END AS c_tipo,
           COALESCE(m.ingrediente_id, m.producto_id) AS c_articulo_id,
           m.sucursal_id                             AS c_sucursal_id,
           -sum(CASE WHEN m.tipo_movimiento IN ('venta', 'anulacion_venta') THEN m.cantidad ELSE 0 END) AS vendido,
           -sum(CASE WHEN m.tipo_movimiento = 'merma' THEN m.cantidad ELSE 0 END)                      AS merma
      FROM public.movimientos_stock m
     WHERE m.tipo_movimiento IN ('venta', 'anulacion_venta', 'merma')
       AND m.creado_en >= now() - INTERVAL '28 days'
     GROUP BY 1, 2, 3
)
SELECT e.tipo,
       e.articulo_id,
       e.nombre,
       e.unidad,
       e.activo,
       e.sucursal_id,
       e.sucursal,
       e.stock_actual,
       e.stock_minimo,
       COALESCE(greatest(CURRENT_DATE - h.primer_movimiento::date, 0), 0) AS dias_con_historial,
       greatest(COALESCE(c.vendido, 0), 0)                                 AS total_vendido_28d,
       greatest(COALESCE(c.merma, 0), 0)                                   AS total_merma_28d,
       greatest(COALESCE(c.vendido, 0) + COALESCE(c.merma, 0), 0)         AS consumo_total_28d,
       round(greatest(COALESCE(c.vendido, 0) + COALESCE(c.merma, 0), 0) / 28.0, 3) AS consumo_diario_promedio
  FROM public.v_existencias_articulos e
  LEFT JOIN historial h
         ON h.h_tipo = e.tipo
        AND h.h_articulo_id = e.articulo_id
        AND h.h_sucursal_id = e.sucursal_id
  LEFT JOIN consumo_28d c
         ON c.c_tipo = e.tipo
        AND c.c_articulo_id = e.articulo_id
        AND c.c_sucursal_id = e.sucursal_id
 WHERE e.activo;

COMMENT ON VIEW public.v_consumo_diario_articulos IS
    'Consumo promedio diario de las últimas 4 semanas (28 días) por artículo y sucursal para cálculo de sugerencias de compra (H4.5 T02).';

REVOKE ALL ON public.v_consumo_diario_articulos FROM PUBLIC;
GRANT SELECT ON public.v_consumo_diario_articulos TO nury_admin, nury_bodeguero;

CREATE VIEW public.v_movimientos_articulos AS
SELECT m.id AS movimiento_id,
       m.tipo_movimiento,
       CASE
           WHEN m.referencia_tipo::text = 'venta'::text THEN m.referencia_id
           ELSE NULL::integer
       END AS venta_id,
       m.referencia_tipo,
       m.referencia_id,
       CASE
           WHEN m.ingrediente_id IS NOT NULL THEN 'materia_prima'::text
           ELSE 'producto'::text
       END::character varying(20) AS tipo_articulo,
       COALESCE(m.ingrediente_id, m.producto_id) AS articulo_id,
       COALESCE(a.nombre, p.nombre) AS articulo,
       COALESCE(a.unidad, 'un'::character varying)::character varying(10) AS unidad,
       m.cantidad,
       m.stock_resultante,
       m.sucursal_id,
       s.nombre AS sucursal,
       m.creado_en AS fecha,
       m.nota
  FROM public.movimientos_stock m
  LEFT JOIN public.v_articulos a
         ON (a.tipo::text = 'materia_prima'::text AND a.articulo_id = m.ingrediente_id)
         OR (a.tipo::text = 'producto'::text      AND a.articulo_id = m.producto_id)
  LEFT JOIN public.productos p ON p.id = m.producto_id
  JOIN public.sucursales s ON s.id = m.sucursal_id
 WHERE (SELECT public.fn_sucursal_restringida()) IS NULL
    OR m.sucursal_id = (SELECT public.fn_sucursal_restringida());

COMMENT ON VIEW public.v_movimientos_articulos IS
    'Kardex con el catálogo de H3.3 (H3.2 T01): venta, artículo, cantidad, unidad, fecha y sucursal de cada movimiento.';
COMMENT ON COLUMN public.v_movimientos_articulos.venta_id IS 'Venta que originó el movimiento (venta o anulacion_venta); NULL en compras y ajustes';
COMMENT ON COLUMN public.v_movimientos_articulos.unidad IS 'Unidad del artículo (fija desde H3.3); "un" en productos';

REVOKE ALL ON public.v_movimientos_articulos FROM PUBLIC;
GRANT SELECT ON public.v_movimientos_articulos TO nury_admin, nury_bodeguero, nury_cajero;

CREATE FUNCTION public.fn_versiones_receta(p_producto_id INTEGER)
RETURNS TABLE (numero INTEGER, vigente_desde TIMESTAMPTZ, creada_por VARCHAR, insumos INTEGER, cambios JSONB)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $function$
    WITH versiones AS (
        SELECT v.*, lag(v.id) OVER (ORDER BY v.numero) AS anterior_id
          FROM public.recetas_version v
         WHERE v.producto_id = p_producto_id
    )
    SELECT v.numero,
           v.vigente_desde,
           u.nombre::VARCHAR,
           (SELECT count(*)::INTEGER FROM public.recetas_version_detalle d WHERE d.version_id = v.id),
           CASE WHEN v.anterior_id IS NOT NULL THEN COALESCE((
               SELECT jsonb_agg(jsonb_build_object(
                          'tipo', c.tipo, 'ingrediente', i.nombre, 'unidad', um.abreviatura,
                          'antes', c.antes, 'despues', c.despues) ORDER BY i.nombre)
                 FROM (
                     SELECT COALESCE(n.ingrediente_id, a.ingrediente_id) AS ingrediente_id,
                            COALESCE(n.unidad_id, a.unidad_id) AS unidad_id,
                            CASE WHEN a.ingrediente_id IS NULL THEN 'agregado'
                                 WHEN n.ingrediente_id IS NULL THEN 'quitado'
                                 ELSE 'modificado' END AS tipo,
                            a.cantidad_necesaria AS antes,
                            n.cantidad_necesaria AS despues
                       FROM (SELECT * FROM public.recetas_version_detalle WHERE version_id = v.id) n
                       FULL JOIN (SELECT * FROM public.recetas_version_detalle WHERE version_id = v.anterior_id) a
                         ON a.ingrediente_id = n.ingrediente_id
                      WHERE a.ingrediente_id IS NULL OR n.ingrediente_id IS NULL
                         OR a.cantidad_necesaria <> n.cantidad_necesaria OR a.unidad_id <> n.unidad_id
                 ) c
                 JOIN public.ingredientes i ON i.id = c.ingrediente_id
                 LEFT JOIN public.unidades_medida um ON um.id = c.unidad_id
           ), '[]'::JSONB) END
      FROM versiones v
      LEFT JOIN public.usuarios u ON u.id = v.creada_por
     ORDER BY v.numero DESC;
$function$;

REVOKE ALL ON FUNCTION public.fn_versiones_receta(integer) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.fn_versiones_receta(integer) TO nury_admin, nury_cajero;

DO $$
DECLARE
    rec RECORD;
BEGIN
    FOR rec IN SELECT obj_kind, obj_name, owner_name FROM _tz_owners LOOP
        EXECUTE format('ALTER %s %s OWNER TO %I', rec.obj_kind, rec.obj_name, rec.owner_name);
    END LOOP;
END;
$$;

CREATE OR REPLACE FUNCTION public.fn_anular_venta(p_venta_id INTEGER, p_motivo TEXT)
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
    actor_id INTEGER := public.fn_usuario_actual_id();
    actor_rol TEXT;
    venta public.ventas%ROWTYPE;
BEGIN
    IF actor_id IS NULL THEN
        RAISE EXCEPTION 'La sesión no identifica a un usuario autorizado' USING ERRCODE = '42501';
    END IF;
    SELECT rol INTO actor_rol FROM public.usuarios WHERE id = actor_id;
    IF p_motivo IS NULL OR length(btrim(p_motivo)) < 5 OR length(btrim(p_motivo)) > 250 THEN
        RAISE EXCEPTION 'El motivo debe tener entre 5 y 250 caracteres' USING ERRCODE = '22023';
    END IF;

    SELECT * INTO venta FROM public.ventas WHERE id = p_venta_id FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'La venta no existe o ya estaba anulada.' USING ERRCODE = '22023';
    END IF;
    IF actor_rol = 'cajero' AND venta.cajero_id IS DISTINCT FROM actor_id THEN
        RAISE EXCEPTION 'Solo puedes anular tus propias ventas' USING ERRCODE = '42501';
    END IF;
    IF venta.anulada THEN
        RAISE EXCEPTION 'La venta no existe o ya estaba anulada.' USING ERRCODE = '22023';
    END IF;

    UPDATE public.ventas
       SET anulada = TRUE, anulada_por = actor_id,
           anulada_en = clock_timestamp(), anulada_motivo = btrim(p_motivo)
     WHERE id = p_venta_id;

    PERFORM public.fn_reponer_stock_anulacion(p_venta_id, p_motivo);

    RETURN p_venta_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.fn_validar_anulacion_cajero()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = pg_catalog, public, pg_temp
AS $function$
DECLARE
    v_cajero_id INTEGER;
BEGIN
    IF current_user <> 'nury_cajero' THEN
        RETURN NEW;
    END IF;

    v_cajero_id := public.fn_cajero_sesion_id();
    IF v_cajero_id IS NULL OR OLD.cajero_id IS DISTINCT FROM v_cajero_id THEN
        RAISE EXCEPTION 'Solo puedes anular tus propias ventas.' USING ERRCODE = '42501';
    END IF;
    IF OLD.anulada THEN
        RAISE EXCEPTION 'La venta ya estaba anulada.' USING ERRCODE = '22023';
    END IF;
    IF NEW.anulada IS DISTINCT FROM TRUE THEN
        RAISE EXCEPTION 'El cajero solo puede anular ventas vigentes.' USING ERRCODE = '42501';
    END IF;
    IF NEW.anulada_motivo IS NULL
       OR char_length(btrim(NEW.anulada_motivo)) NOT BETWEEN 5 AND 250 THEN
        RAISE EXCEPTION 'El motivo debe tener entre 5 y 250 caracteres.' USING ERRCODE = '22023';
    END IF;
    IF (to_jsonb(NEW) - ARRAY['anulada', 'anulada_en', 'anulada_por', 'anulada_motivo'])
       IS DISTINCT FROM
       (to_jsonb(OLD) - ARRAY['anulada', 'anulada_en', 'anulada_por', 'anulada_motivo']) THEN
        RAISE EXCEPTION 'La anulación no puede modificar otros datos de la venta.'
            USING ERRCODE = '42501';
    END IF;

    NEW.anulada_por := v_cajero_id;
    NEW.anulada_en := clock_timestamp();
    NEW.anulada_motivo := btrim(NEW.anulada_motivo);
    RETURN NEW;
END;
$function$;

CREATE OR REPLACE FUNCTION public.fn_registrar_almuerzo_empleado(
    p_sucursal_id INTEGER,
    p_empleado_id INTEGER,
    p_items       JSONB
)
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $function$
DECLARE
    v_actor_id    INTEGER := public.fn_usuario_actual_id();
    v_actor       RECORD;
    v_fecha       DATE := (now() AT TIME ZONE 'America/Santiago')::date;
    v_empleado    TEXT;
    v_previo      RECORD;
    v_almuerzo_id INTEGER;
    item          JSONB;
    v_producto_id INTEGER;
    v_cantidad    NUMERIC;
    v_vistos      INTEGER[] := '{}';
    linea         RECORD;
BEGIN
    IF v_actor_id IS NULL THEN
        RAISE EXCEPTION 'La sesión no identifica a un usuario autorizado' USING ERRCODE = '42501';
    END IF;

    SELECT rol, sucursal_id INTO v_actor FROM public.usuarios WHERE id = v_actor_id;

    IF NOT EXISTS (SELECT 1 FROM public.sucursales WHERE id = p_sucursal_id AND activo) THEN
        RAISE EXCEPTION 'La sucursal no existe o está deshabilitada' USING ERRCODE = '22023';
    END IF;

    IF v_actor.rol = 'cajero' AND v_actor.sucursal_id IS DISTINCT FROM p_sucursal_id THEN
        RAISE EXCEPTION 'Solo puedes registrar almuerzos en tu sucursal' USING ERRCODE = '42501';
    END IF;

    IF p_empleado_id IS NULL THEN
        RAISE EXCEPTION 'Debes indicar el empleado que almuerza' USING ERRCODE = '22023';
    END IF;

    SELECT nombre INTO v_empleado FROM public.usuarios WHERE id = p_empleado_id AND activo;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'El empleado no existe o está deshabilitado' USING ERRCODE = '22023';
    END IF;

    IF p_items IS NULL OR jsonb_typeof(p_items) <> 'array' OR jsonb_array_length(p_items) = 0 THEN
        RAISE EXCEPTION 'El almuerzo no tiene productos: agrega al menos uno' USING ERRCODE = '22023';
    END IF;

    SELECT a.creado_en, s.nombre AS sucursal, u.nombre AS cajero INTO v_previo
      FROM public.almuerzos_empleado a
      JOIN public.sucursales s ON s.id = a.sucursal_id
      JOIN public.usuarios u ON u.id = a.cajero_id
     WHERE a.empleado_id = p_empleado_id AND a.fecha = v_fecha;
    IF FOUND THEN
        RAISE EXCEPTION '% ya registró su almuerzo hoy (a las % en %, lo registró %). Solo se permite un almuerzo por día',
            v_empleado, to_char(v_previo.creado_en AT TIME ZONE 'America/Santiago', 'HH24:MI'),
            v_previo.sucursal, v_previo.cajero
            USING ERRCODE = '23505';
    END IF;

    BEGIN
        INSERT INTO public.almuerzos_empleado (sucursal_id, empleado_id, cajero_id, fecha)
        VALUES (p_sucursal_id, p_empleado_id, v_actor_id, v_fecha)
        RETURNING id INTO v_almuerzo_id;
    EXCEPTION
        WHEN unique_violation THEN
            RAISE EXCEPTION '% ya registró su almuerzo hoy. Solo se permite un almuerzo por día', v_empleado
                USING ERRCODE = '23505';
    END;

    FOR item IN SELECT * FROM jsonb_array_elements(p_items)
    LOOP
        IF jsonb_typeof(item->'producto_id') <> 'number'
           OR (item->>'producto_id') !~ '^[0-9]{1,9}$' THEN
            RAISE EXCEPTION 'Producto no válido: %', item->'producto_id' USING ERRCODE = '22023';
        END IF;
        v_producto_id := (item->>'producto_id')::INTEGER;

        IF jsonb_typeof(item->'cantidad') <> 'number' OR (item->>'cantidad')::NUMERIC <= 0 THEN
            RAISE EXCEPTION 'La cantidad debe ser mayor que 0' USING ERRCODE = '22023';
        END IF;
        v_cantidad := (item->>'cantidad')::NUMERIC;
        IF v_cantidad <> trunc(v_cantidad) THEN
            RAISE EXCEPTION 'La cantidad debe ser un número entero' USING ERRCODE = '22023';
        END IF;

        IF v_producto_id = ANY (v_vistos) THEN
            RAISE EXCEPTION 'El producto % está repetido en el almuerzo', v_producto_id USING ERRCODE = '22023';
        END IF;
        v_vistos := v_vistos || v_producto_id;

        IF NOT EXISTS (SELECT 1 FROM public.productos WHERE id = v_producto_id AND activo) THEN
            RAISE EXCEPTION 'Producto no encontrado o inactivo: %', v_producto_id USING ERRCODE = '22023';
        END IF;

        INSERT INTO public.almuerzos_empleado_detalle (almuerzo_id, producto_id, cantidad)
        VALUES (v_almuerzo_id, v_producto_id, v_cantidad)
        RETURNING producto_id, cantidad, receta_version_id INTO linea;

        PERFORM public.fn_descontar_stock_producto(
            linea.producto_id, p_sucursal_id, linea.cantidad, linea.receta_version_id,
            'consumo_interno', 'almuerzo_empleado', v_almuerzo_id);
    END LOOP;

    RETURN v_almuerzo_id;
END;
$function$;

CREATE OR REPLACE FUNCTION public.fn_reporte_cajeros(
    p_sucursales INTEGER[],
    p_desde      DATE,
    p_hasta      DATE,
    p_turno      INTEGER DEFAULT NULL
)
RETURNS TABLE (
    cajero_id      INTEGER,
    cajero         VARCHAR,
    sucursales     VARCHAR,
    turnos         INTEGER,
    ventas         INTEGER,
    total          NUMERIC,
    venta_promedio NUMERIC,
    productos      NUMERIC,
    anuladas       INTEGER,
    total_anuladas NUMERIC
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $function$
DECLARE
    v_desde TIMESTAMPTZ;
    v_hasta TIMESTAMPTZ;
BEGIN
    IF p_desde IS NULL OR p_hasta IS NULL THEN
        RAISE EXCEPTION 'Indica la fecha inicial y la final del período' USING ERRCODE = '22023';
    END IF;
    IF p_desde > p_hasta THEN
        RAISE EXCEPTION 'La fecha inicial no puede ser posterior a la final' USING ERRCODE = '22023';
    END IF;
    IF p_hasta - p_desde > 366 THEN
        RAISE EXCEPTION 'El período no puede superar un año' USING ERRCODE = '22023';
    END IF;
    IF p_turno < 0 THEN
        RAISE EXCEPTION 'El turno indicado no es válido' USING ERRCODE = '22023';
    END IF;

    v_desde := p_desde::timestamp AT TIME ZONE 'America/Santiago';
    v_hasta := (p_hasta + 1)::timestamp AT TIME ZONE 'America/Santiago';

    RETURN QUERY
    WITH del_periodo AS (
        SELECT v.id AS v_id, v.cajero_id AS v_cajero, v.sucursal_id AS v_sucursal,
               v.turno_id AS v_turno, v.total AS v_total, v.anulada AS v_anulada
          FROM public.ventas v
         WHERE CASE
                   WHEN p_turno > 0 THEN v.turno_id = p_turno
                   ELSE v.fecha_venta >= v_desde
                    AND v.fecha_venta <  v_hasta
                    AND (p_sucursales IS NULL OR v.sucursal_id = ANY (p_sucursales) OR v.sucursal_id IS NULL)
                    AND (p_turno IS NULL OR v.turno_id IS NULL)
               END
    ), unidades AS (
        SELECT d.venta_id AS u_venta, sum(d.cantidad) AS u_cantidad
          FROM public.detalle_venta d
         WHERE d.venta_id IN (SELECT dp.v_id FROM del_periodo dp WHERE NOT dp.v_anulada)
         GROUP BY d.venta_id
    )
    SELECT dp.v_cajero,
           COALESCE(u.nombre, 'Sin cajero')::varchar,
           COALESCE(string_agg(DISTINCT s.nombre, ', '), 'Sin sucursal')::varchar,
           count(DISTINCT dp.v_turno)::int,
           count(*) FILTER (WHERE NOT dp.v_anulada)::int,
           COALESCE(sum(dp.v_total) FILTER (WHERE NOT dp.v_anulada), 0),
           CASE WHEN count(*) FILTER (WHERE NOT dp.v_anulada) = 0 THEN 0
                ELSE round(sum(dp.v_total) FILTER (WHERE NOT dp.v_anulada)
                           / count(*) FILTER (WHERE NOT dp.v_anulada), 2) END,
           COALESCE(sum(un.u_cantidad), 0),
           count(*) FILTER (WHERE dp.v_anulada)::int,
           COALESCE(sum(dp.v_total) FILTER (WHERE dp.v_anulada), 0)
      FROM del_periodo dp
      LEFT JOIN public.usuarios u   ON u.id = dp.v_cajero
      LEFT JOIN public.sucursales s ON s.id = dp.v_sucursal
      LEFT JOIN unidades un         ON un.u_venta = dp.v_id
     GROUP BY dp.v_cajero, u.nombre
     ORDER BY dp.v_cajero IS NULL, COALESCE(sum(dp.v_total) FILTER (WHERE NOT dp.v_anulada), 0) DESC, u.nombre;
END;
$function$;

CREATE OR REPLACE FUNCTION public.fn_turnos_reporte(
    p_sucursales INTEGER[],
    p_desde      DATE,
    p_hasta      DATE
)
RETURNS TABLE (
    turno_id    INTEGER,
    cajero_id   INTEGER,
    cajero      VARCHAR,
    sucursal_id INTEGER,
    sucursal    VARCHAR,
    inicio      TIMESTAMP,
    fin         TIMESTAMP,
    ventas      INTEGER,
    total       NUMERIC,
    anuladas    INTEGER
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $function$
DECLARE
    v_desde TIMESTAMPTZ;
    v_hasta TIMESTAMPTZ;
BEGIN
    IF p_desde IS NULL OR p_hasta IS NULL THEN
        RAISE EXCEPTION 'Indica la fecha inicial y la final del período' USING ERRCODE = '22023';
    END IF;
    IF p_desde > p_hasta THEN
        RAISE EXCEPTION 'La fecha inicial no puede ser posterior a la final' USING ERRCODE = '22023';
    END IF;
    IF p_hasta - p_desde > 366 THEN
        RAISE EXCEPTION 'El período no puede superar un año' USING ERRCODE = '22023';
    END IF;

    v_desde := p_desde::timestamp AT TIME ZONE 'America/Santiago';
    v_hasta := (p_hasta + 1)::timestamp AT TIME ZONE 'America/Santiago';

    RETURN QUERY
    WITH del_periodo AS (
        SELECT t.id AS t_id
          FROM public.turnos t
         WHERE (p_sucursales IS NULL OR t.sucursal_id = ANY (p_sucursales))
           AND (   (t.hora_inicio >= v_desde AND t.hora_inicio < v_hasta)
                OR EXISTS (SELECT 1 FROM public.ventas v
                            WHERE v.turno_id = t.id
                              AND v.fecha_venta >= v_desde AND v.fecha_venta < v_hasta))
    ), por_turno AS (
        SELECT t.id AS r_turno, t.usuario_id AS r_cajero, u.nombre::varchar AS r_nombre,
               t.sucursal_id AS r_sucursal, s.nombre::varchar AS r_sucursal_nombre,
               (t.hora_inicio AT TIME ZONE 'America/Santiago') AS r_inicio,
               (t.hora_fin    AT TIME ZONE 'America/Santiago') AS r_fin,
               count(v.id) FILTER (WHERE NOT v.anulada)::int AS r_ventas,
               COALESCE(sum(v.total) FILTER (WHERE NOT v.anulada), 0) AS r_total,
               count(v.id) FILTER (WHERE v.anulada)::int AS r_anuladas
          FROM del_periodo dp
          JOIN public.turnos t          ON t.id = dp.t_id
          LEFT JOIN public.usuarios u   ON u.id = t.usuario_id
          LEFT JOIN public.sucursales s ON s.id = t.sucursal_id
          LEFT JOIN public.ventas v     ON v.turno_id = t.id
         GROUP BY t.id, u.nombre, s.nombre
    ), sin_turno AS (
        SELECT count(*) FILTER (WHERE NOT v.anulada)::int AS n_ventas,
               COALESCE(sum(v.total) FILTER (WHERE NOT v.anulada), 0) AS n_total,
               count(*) FILTER (WHERE v.anulada)::int AS n_anuladas
          FROM public.ventas v
         WHERE v.turno_id IS NULL
           AND v.fecha_venta >= v_desde AND v.fecha_venta < v_hasta
           AND (p_sucursales IS NULL OR v.sucursal_id = ANY (p_sucursales) OR v.sucursal_id IS NULL)
    )
    SELECT x.* FROM (
        SELECT pt.r_turno, pt.r_cajero, pt.r_nombre, pt.r_sucursal, pt.r_sucursal_nombre,
               pt.r_inicio, pt.r_fin, pt.r_ventas, pt.r_total, pt.r_anuladas
          FROM por_turno pt
        UNION ALL
        SELECT NULL::int, NULL::int, 'Sin turno registrado'::varchar, NULL::int, NULL::varchar,
               NULL::timestamp, NULL::timestamp, st.n_ventas, st.n_total, st.n_anuladas
          FROM sin_turno st
         WHERE st.n_ventas + st.n_anuladas > 0
    ) x
    ORDER BY x.r_turno IS NULL, x.r_inicio DESC, x.r_turno DESC;
END;
$function$;

CREATE OR REPLACE FUNCTION public.fn_reporte_productos_sucursal(
    p_sucursales INTEGER[],
    p_desde      DATE,
    p_hasta      DATE
)
RETURNS TABLE (
    sucursal_id INTEGER,
    sucursal    VARCHAR,
    producto_id INTEGER,
    producto    VARCHAR,
    categoria   VARCHAR,
    con_receta  BOOLEAN,
    unidades    NUMERIC,
    ventas      INTEGER,
    monto_bruto NUMERIC,
    descuento   NUMERIC,
    monto       NUMERIC
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $function$
DECLARE
    v_desde TIMESTAMPTZ;
    v_hasta TIMESTAMPTZ;
BEGIN
    IF p_desde IS NULL OR p_hasta IS NULL THEN
        RAISE EXCEPTION 'Indica la fecha inicial y la final del período' USING ERRCODE = '22023';
    END IF;
    IF p_desde > p_hasta THEN
        RAISE EXCEPTION 'La fecha inicial no puede ser posterior a la final' USING ERRCODE = '22023';
    END IF;
    IF p_hasta - p_desde > 366 THEN
        RAISE EXCEPTION 'El período no puede superar un año' USING ERRCODE = '22023';
    END IF;

    v_desde := p_desde::timestamp AT TIME ZONE 'America/Santiago';
    v_hasta := (p_hasta + 1)::timestamp AT TIME ZONE 'America/Santiago';

    RETURN QUERY
    WITH lineas AS (
        SELECT v.id AS l_venta, v.sucursal_id AS l_sucursal, v.descuento_monto AS l_desc_venta,
               d.producto_id AS l_producto, d.cantidad AS l_cantidad, d.subtotal AS l_subtotal,
               sum(d.subtotal) OVER (PARTITION BY v.id) AS l_subtotal_venta
          FROM public.ventas v
          JOIN public.detalle_venta d ON d.venta_id = v.id
         WHERE NOT v.anulada
           AND v.fecha_venta >= v_desde
           AND v.fecha_venta <  v_hasta
           AND (p_sucursales IS NULL OR v.sucursal_id = ANY (p_sucursales) OR v.sucursal_id IS NULL)
    ), con_descuento AS (
        SELECT l.*,
               CASE WHEN l.l_desc_venta > 0 AND l.l_subtotal_venta > 0
                    THEN l.l_desc_venta * l.l_subtotal / l.l_subtotal_venta
                    ELSE 0 END AS l_descuento
          FROM lineas l
    )
    SELECT c.l_sucursal,
           COALESCE(s.nombre, 'Sin sucursal')::varchar,
           c.l_producto,
           p.nombre::varchar,
           p.categoria::varchar,
           EXISTS (SELECT 1 FROM public.recetas r WHERE r.producto_id = c.l_producto),
           sum(c.l_cantidad),
           count(DISTINCT c.l_venta)::int,
           sum(c.l_subtotal),
           round(sum(c.l_descuento), 2),
           round(sum(c.l_subtotal - c.l_descuento), 2)
      FROM con_descuento c
      JOIN public.productos p ON p.id = c.l_producto
      LEFT JOIN public.sucursales s ON s.id = c.l_sucursal
     GROUP BY c.l_sucursal, s.nombre, c.l_producto, p.nombre, p.categoria
     ORDER BY c.l_sucursal IS NULL, s.nombre, sum(c.l_subtotal - c.l_descuento) DESC, p.nombre;
END;
$function$;

CREATE OR REPLACE FUNCTION public.fn_reporte_ventas_sucursal(
    p_sucursales INTEGER[],
    p_desde      DATE,
    p_hasta      DATE
)
RETURNS TABLE (
    sucursal_id     INTEGER,
    sucursal        VARCHAR,
    ventas          INTEGER,
    total           NUMERIC,
    ticket_promedio NUMERIC,
    ventas_normales INTEGER,
    total_normales  NUMERIC,
    ventas_empleado INTEGER,
    total_empleado  NUMERIC,
    medios_pago     JSONB,
    anuladas        INTEGER,
    total_anuladas  NUMERIC
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $function$
DECLARE
    v_desde TIMESTAMPTZ;
    v_hasta TIMESTAMPTZ;
BEGIN
    IF p_desde IS NULL OR p_hasta IS NULL THEN
        RAISE EXCEPTION 'Indica la fecha inicial y la final del período' USING ERRCODE = '22023';
    END IF;
    IF p_desde > p_hasta THEN
        RAISE EXCEPTION 'La fecha inicial no puede ser posterior a la final' USING ERRCODE = '22023';
    END IF;
    IF p_hasta - p_desde > 366 THEN
        RAISE EXCEPTION 'El período no puede superar un año' USING ERRCODE = '22023';
    END IF;

    v_desde := p_desde::timestamp AT TIME ZONE 'America/Santiago';
    v_hasta := (p_hasta + 1)::timestamp AT TIME ZONE 'America/Santiago';

    RETURN QUERY
    WITH del_periodo AS (
        SELECT v.sucursal_id AS v_sucursal_id, v.total AS v_total, v.anulada AS v_anulada,
               v.tipo_venta AS v_tipo, COALESCE(NULLIF(btrim(v.medio_pago), ''), 'sin_medio') AS v_medio
          FROM public.ventas v
         WHERE v.fecha_venta >= v_desde
           AND v.fecha_venta <  v_hasta
           AND (p_sucursales IS NULL OR v.sucursal_id = ANY (p_sucursales) OR v.sucursal_id IS NULL)
    ), por_sucursal AS (
        SELECT d.v_sucursal_id AS s_id,
               count(*) FILTER (WHERE NOT d.v_anulada)::int                              AS s_ventas,
               COALESCE(sum(d.v_total) FILTER (WHERE NOT d.v_anulada), 0)                AS s_total,
               count(*) FILTER (WHERE NOT d.v_anulada AND d.v_tipo = 'normal')::int      AS s_normales,
               COALESCE(sum(d.v_total) FILTER (WHERE NOT d.v_anulada AND d.v_tipo = 'normal'), 0) AS s_total_normales,
               count(*) FILTER (WHERE NOT d.v_anulada AND d.v_tipo = 'empleado')::int    AS s_empleado,
               COALESCE(sum(d.v_total) FILTER (WHERE NOT d.v_anulada AND d.v_tipo = 'empleado'), 0) AS s_total_empleado,
               count(*) FILTER (WHERE d.v_anulada)::int                                  AS s_anuladas,
               COALESCE(sum(d.v_total) FILTER (WHERE d.v_anulada), 0)                    AS s_total_anuladas
          FROM del_periodo d
         GROUP BY d.v_sucursal_id
    ), por_medio AS (
        SELECT m.s_id, jsonb_object_agg(m.medio, m.monto ORDER BY m.medio) AS s_medios
          FROM (SELECT d.v_sucursal_id AS s_id, d.v_medio AS medio, sum(d.v_total) AS monto
                  FROM del_periodo d
                 WHERE NOT d.v_anulada
                 GROUP BY 1, 2) m
         GROUP BY m.s_id
    ), sucursales_pedidas AS (
        SELECT s.id AS s_id, s.nombre::varchar AS s_nombre
          FROM public.sucursales s
         WHERE (p_sucursales IS NULL AND s.activo) OR s.id = ANY (p_sucursales)
        UNION
        SELECT s.id, s.nombre::varchar
          FROM public.sucursales s
          JOIN por_sucursal ps ON ps.s_id = s.id
    ), filas AS (
        SELECT sp.s_id, sp.s_nombre FROM sucursales_pedidas sp
        UNION ALL
        SELECT NULL::int, 'Sin sucursal'::varchar
         WHERE EXISTS (SELECT 1 FROM por_sucursal ps WHERE ps.s_id IS NULL)
    )
    SELECT f.s_id,
           f.s_nombre,
           COALESCE(ps.s_ventas, 0),
           COALESCE(ps.s_total, 0),
           CASE WHEN COALESCE(ps.s_ventas, 0) = 0 THEN 0 ELSE round(ps.s_total / ps.s_ventas, 2) END,
           COALESCE(ps.s_normales, 0),
           COALESCE(ps.s_total_normales, 0),
           COALESCE(ps.s_empleado, 0),
           COALESCE(ps.s_total_empleado, 0),
           COALESCE(pm.s_medios, '{}'::jsonb),
           COALESCE(ps.s_anuladas, 0),
           COALESCE(ps.s_total_anuladas, 0)
      FROM filas f
      LEFT JOIN por_sucursal ps ON ps.s_id IS NOT DISTINCT FROM f.s_id
      LEFT JOIN por_medio pm   ON pm.s_id IS NOT DISTINCT FROM f.s_id
     ORDER BY f.s_id IS NULL, f.s_nombre;
END;
$function$;

CREATE OR REPLACE FUNCTION public.fn_cuadratura_ventas_stock(
    p_sucursales INTEGER[],
    p_desde      DATE,
    p_hasta      DATE
)
RETURNS TABLE (
    sucursal_id INTEGER,
    sucursal    VARCHAR,
    tipo        VARCHAR,
    articulo_id INTEGER,
    articulo    VARCHAR,
    unidad      VARCHAR,
    esperado    NUMERIC,
    registrado  NUMERIC,
    diferencia  NUMERIC,
    cuadra      BOOLEAN
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $function$
DECLARE
    v_desde TIMESTAMPTZ;
    v_hasta TIMESTAMPTZ;
BEGIN
    IF p_desde IS NULL OR p_hasta IS NULL THEN
        RAISE EXCEPTION 'Indica la fecha inicial y la final del período' USING ERRCODE = '22023';
    END IF;
    IF p_desde > p_hasta THEN
        RAISE EXCEPTION 'La fecha inicial no puede ser posterior a la final' USING ERRCODE = '22023';
    END IF;
    IF p_hasta - p_desde > 366 THEN
        RAISE EXCEPTION 'El período no puede superar un año' USING ERRCODE = '22023';
    END IF;

    v_desde := p_desde::timestamp AT TIME ZONE 'America/Santiago';
    v_hasta := (p_hasta + 1)::timestamp AT TIME ZONE 'America/Santiago';

    RETURN QUERY
    WITH del_periodo AS (
        SELECT v.id AS v_id, v.sucursal_id AS v_sucursal, v.anulada AS v_anulada
          FROM public.ventas v
         WHERE v.fecha_venta >= v_desde
           AND v.fecha_venta <  v_hasta
           AND (p_sucursales IS NULL OR v.sucursal_id = ANY (p_sucursales) OR v.sucursal_id IS NULL)
    ), esperado AS (
        SELECT dp.v_sucursal AS e_sucursal, 'producto'::varchar AS e_tipo, d.producto_id AS e_id,
               sum(d.cantidad) AS e_cantidad
          FROM del_periodo dp
          JOIN public.detalle_venta d ON d.venta_id = dp.v_id
         WHERE NOT dp.v_anulada AND d.receta_version_id IS NULL
         GROUP BY 1, 2, 3
        UNION ALL
        SELECT dp.v_sucursal, 'materia_prima'::varchar, rvd.ingrediente_id,
               sum(rvd.cantidad_necesaria * d.cantidad)
          FROM del_periodo dp
          JOIN public.detalle_venta d ON d.venta_id = dp.v_id
          JOIN public.recetas_version_detalle rvd ON rvd.version_id = d.receta_version_id
         WHERE NOT dp.v_anulada
         GROUP BY 1, 2, 3
    ), esperado_total AS (
        SELECT e.e_sucursal, e.e_tipo, e.e_id, sum(e.e_cantidad) AS e_cantidad
          FROM esperado e
         GROUP BY 1, 2, 3
    ), registrado AS (
        SELECT m.sucursal_id AS r_sucursal,
               CASE WHEN m.ingrediente_id IS NOT NULL THEN 'materia_prima' ELSE 'producto' END::varchar AS r_tipo,
               COALESCE(m.ingrediente_id, m.producto_id) AS r_id,
               -sum(m.cantidad) AS r_cantidad
          FROM public.movimientos_stock m
          JOIN del_periodo dp ON dp.v_id = m.referencia_id
         WHERE m.referencia_tipo = 'venta'
           AND m.tipo_movimiento IN ('venta', 'anulacion_venta')
         GROUP BY 1, 2, 3
    ), cruce AS (
        SELECT COALESCE(e.e_sucursal, r.r_sucursal) AS c_sucursal,
               COALESCE(e.e_tipo, r.r_tipo) AS c_tipo,
               COALESCE(e.e_id, r.r_id) AS c_id,
               round(COALESCE(e.e_cantidad, 0), 3) AS c_esperado,
               round(COALESCE(r.r_cantidad, 0), 3) AS c_registrado
          FROM esperado_total e
          FULL JOIN registrado r
            ON r.r_sucursal IS NOT DISTINCT FROM e.e_sucursal
           AND r.r_tipo = e.e_tipo
           AND r.r_id = e.e_id
    )
    SELECT c.c_sucursal,
           COALESCE(s.nombre, 'Sin sucursal')::varchar,
           c.c_tipo,
           c.c_id,
           COALESCE(i.nombre, p.nombre)::varchar,
           CASE WHEN c.c_tipo = 'materia_prima' THEN um.abreviatura ELSE 'un' END::varchar,
           c.c_esperado,
           c.c_registrado,
           c.c_registrado - c.c_esperado,
           c.c_registrado = c.c_esperado
      FROM cruce c
      LEFT JOIN public.sucursales s ON s.id = c.c_sucursal
      LEFT JOIN public.ingredientes i ON c.c_tipo = 'materia_prima' AND i.id = c.c_id
      LEFT JOIN public.unidades_medida um ON um.id = i.unidad_id
      LEFT JOIN public.productos p ON c.c_tipo = 'producto' AND p.id = c.c_id
     WHERE NOT (c.c_esperado = 0 AND c.c_registrado = 0)
     ORDER BY c.c_registrado = c.c_esperado, c.c_sucursal IS NULL, s.nombre, COALESCE(i.nombre, p.nombre);
END;
$function$;

CREATE OR REPLACE FUNCTION public.fn_reporte_promociones_periodo(
    p_sucursales INTEGER[],
    p_desde      DATE,
    p_hasta      DATE
)
RETURNS TABLE (
    dia                        DATE,
    vendido                    NUMERIC,
    vendido_con_descuento      NUMERIC,
    precio_lista_con_descuento NUMERIC,
    unidades_con_descuento     NUMERIC,
    ventas_con_promocion       INTEGER,
    margen_sacrificado         NUMERIC
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $function$
DECLARE
    v_desde TIMESTAMPTZ;
    v_hasta TIMESTAMPTZ;
BEGIN
    IF p_desde IS NULL OR p_hasta IS NULL THEN
        RAISE EXCEPTION 'Indica la fecha inicial y la final del período' USING ERRCODE = '22023';
    END IF;
    IF p_desde > p_hasta THEN
        RAISE EXCEPTION 'La fecha inicial no puede ser posterior a la final' USING ERRCODE = '22023';
    END IF;
    IF p_hasta - p_desde > 366 THEN
        RAISE EXCEPTION 'El período no puede superar un año' USING ERRCODE = '22023';
    END IF;

    v_desde := p_desde::timestamp AT TIME ZONE 'America/Santiago';
    v_hasta := (p_hasta + 1)::timestamp AT TIME ZONE 'America/Santiago';

    RETURN QUERY
    WITH lineas AS (
        SELECT (v.fecha_venta AT TIME ZONE 'America/Santiago')::date AS l_dia,
               v.id AS l_venta, d.promocion_id AS l_promocion, d.cantidad AS l_cantidad,
               d.subtotal AS l_subtotal, d.precio_lista AS l_lista, d.margen_sacrificado AS l_margen
          FROM public.ventas v
          JOIN public.detalle_venta d ON d.venta_id = v.id
         WHERE NOT v.anulada
           AND v.fecha_venta >= v_desde
           AND v.fecha_venta <  v_hasta
           AND (p_sucursales IS NULL OR v.sucursal_id = ANY (p_sucursales))
    ), dias AS (
        SELECT g::date AS d_dia FROM generate_series(p_desde, p_hasta, interval '1 day') g
    )
    SELECT d.d_dia,
           COALESCE(sum(l.l_subtotal), 0),
           COALESCE(sum(l.l_subtotal) FILTER (WHERE l.l_promocion IS NOT NULL), 0),
           COALESCE(sum(l.l_lista * l.l_cantidad) FILTER (WHERE l.l_promocion IS NOT NULL), 0),
           COALESCE(sum(l.l_cantidad) FILTER (WHERE l.l_promocion IS NOT NULL), 0),
           (count(DISTINCT l.l_venta) FILTER (WHERE l.l_promocion IS NOT NULL))::int,
           COALESCE(sum(l.l_margen), 0)
      FROM dias d
      LEFT JOIN lineas l ON l.l_dia = d.d_dia
     GROUP BY d.d_dia
     ORDER BY d.d_dia;
END;
$function$;

CREATE OR REPLACE FUNCTION public.fn_reporte_promociones_producto(
    p_sucursales INTEGER[],
    p_desde      DATE,
    p_hasta      DATE
)
RETURNS TABLE (
    producto_id                INTEGER,
    producto                   VARCHAR,
    categoria                  VARCHAR,
    unidades                   NUMERIC,
    vendido                    NUMERIC,
    unidades_con_descuento     NUMERIC,
    vendido_con_descuento      NUMERIC,
    precio_lista_con_descuento NUMERIC,
    margen_sacrificado         NUMERIC,
    margen_con_descuento       NUMERIC,
    promociones                TEXT
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public, pg_temp
AS $function$
DECLARE
    v_desde TIMESTAMPTZ;
    v_hasta TIMESTAMPTZ;
BEGIN
    IF p_desde IS NULL OR p_hasta IS NULL THEN
        RAISE EXCEPTION 'Indica la fecha inicial y la final del período' USING ERRCODE = '22023';
    END IF;
    IF p_desde > p_hasta THEN
        RAISE EXCEPTION 'La fecha inicial no puede ser posterior a la final' USING ERRCODE = '22023';
    END IF;
    IF p_hasta - p_desde > 366 THEN
        RAISE EXCEPTION 'El período no puede superar un año' USING ERRCODE = '22023';
    END IF;

    v_desde := p_desde::timestamp AT TIME ZONE 'America/Santiago';
    v_hasta := (p_hasta + 1)::timestamp AT TIME ZONE 'America/Santiago';

    RETURN QUERY
    SELECT d.producto_id,
           p.nombre::varchar,
           p.categoria::varchar,
           sum(d.cantidad),
           sum(d.subtotal),
           COALESCE(sum(d.cantidad) FILTER (WHERE d.promocion_id IS NOT NULL), 0),
           COALESCE(sum(d.subtotal) FILTER (WHERE d.promocion_id IS NOT NULL), 0),
           COALESCE(sum(d.precio_lista * d.cantidad) FILTER (WHERE d.promocion_id IS NOT NULL), 0),
           sum(d.margen_sacrificado),
           sum((d.precio_unitario - d.costo_unitario) * d.cantidad)
               FILTER (WHERE d.promocion_id IS NOT NULL AND d.costo_unitario IS NOT NULL),
           string_agg(DISTINCT pr.nombre, ', ')
      FROM public.ventas v
      JOIN public.detalle_venta d ON d.venta_id = v.id
      JOIN public.productos p ON p.id = d.producto_id
      LEFT JOIN public.promociones pr ON pr.id = d.promocion_id
     WHERE NOT v.anulada
       AND v.fecha_venta >= v_desde
       AND v.fecha_venta <  v_hasta
       AND (p_sucursales IS NULL OR v.sucursal_id = ANY (p_sucursales))
     GROUP BY d.producto_id, p.nombre, p.categoria
     ORDER BY sum(d.margen_sacrificado) DESC, sum(d.subtotal) DESC, p.nombre;
END;
$function$;

COMMIT;

-- Fijar TimeZone de la base en hora de Chile (no puede ir dentro de BEGIN/COMMIT).
SELECT format('ALTER DATABASE %I SET TimeZone TO %L;', current_database(), 'America/Santiago') \gexec

NOTIFY pgrst, 'reload schema';
