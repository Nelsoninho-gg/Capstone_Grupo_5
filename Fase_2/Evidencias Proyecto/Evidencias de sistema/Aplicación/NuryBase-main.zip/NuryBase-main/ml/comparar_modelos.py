"""Guerra de modelos para el consumo diario de cada articulo en NuryBase.

Uso: python ml/comparar_modelos.py <carpeta_datos> <carpeta_salida>
La carpeta de datos debe traer movimientos.json y consumo.json. Solo lee archivos locales.
Los modelos calculan; la IA del sistema solo interpreta. Aqui no se llama a ninguna IA ni API.
"""
import argparse
import json
import math
from pathlib import Path

import lightgbm as lgb
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression

SEMILLA = 42
VENTANA = 28  # dias de la referencia actual y minimo de historial para el primer pronostico
HORIZONTES = (1, 7)
MOVIMIENTOS_CONSUMO = ["venta", "anulacion_venta", "merma"]  # los mismos que construirSeriesOperativas
ALFA = BETA = 0.1  # valores habituales de Croston y TSB; fijos, no se ajustan contra la prueba
UMBRAL_ADI = 1.32  # Syntetos-Boylan: sobre esto la demanda es intermitente
UMBRAL_CV2 = 0.49
# Conservadores y fijados antes de medir; no se ajustan contra el conjunto de prueba.
PARAMS_LGBM = dict(n_estimators=200, learning_rate=0.03, num_leaves=7, min_child_samples=50,
                   subsample=0.8, subsample_freq=1, colsample_bytree=0.8, reg_lambda=1.0,
                   random_state=SEMILLA, deterministic=True, force_col_wise=True, n_jobs=4, verbose=-1)
# Criterio fijado antes de medir: "claramente mejor" en la suma de 7 dias, con y sin QA.
MEJORA_MINIMA = 0.05
HOLGURA_SESGO = 5.0  # puntos porcentuales de sesgo absoluto que se toleran sobre la referencia
REFERENCIA = "ref_28_iqr"
# De mas simple a mas compleja: si dos cumplen el criterio, gana la primera.
ORDEN_SIMPLICIDAD = ["ref_28_sin_filtro", "prop_a_sin_filtro", "prop_b_umbral_ventas", "ingenuo_dds",
                     "sba", "tsb", "lineal_sin_filtro", "lineal_iqr", "lgbm_sin_filtro", "lgbm_iqr"]


def r2(x):
    return math.floor(x * 100 + 0.5) / 100  # igual que Math.round(x * 100) / 100 de la app


def suma(valores):
    # sum() de Python compensa el redondeo y a veces cambia el segundo decimal frente al reduce de JavaScript.
    total = 0.0
    for v in valores:
        total += v
    return total


def percentil(ordenados, p):
    pos = (len(ordenados) - 1) * p
    base = math.floor(pos)
    siguiente = ordenados[base + 1] if base + 1 < len(ordenados) else ordenados[base]
    return ordenados[base] + (pos - base) * (siguiente - ordenados[base])


def depurar(serie):
    """Replica depurarSerieConsumo con estrategia 'atenuar' y factorSigma 2. Devuelve base, serie y picos."""
    serie = [float(v) for v in serie]
    orden = sorted(serie)
    mediana, q1, q3 = r2(percentil(orden, 0.5)), percentil(orden, 0.25), percentil(orden, 0.75)
    iqr, q3 = r2(q3 - q1), r2(q3)
    media = suma(serie) / len(serie)
    desv = r2(math.sqrt(suma((v - media) ** 2 for v in serie) / len(serie)))
    media = r2(media)
    cota_sigma = media + 2 * desv if desv > 0 else media * 1.8
    cota_iqr = q3 + 1.5 * iqr if iqr > 0 else (mediana * 1.8 if mediana > 0 else cota_sigma)
    umbral = r2(max(mediana * 1.35, min(cota_iqr, cota_sigma)))
    normales = [v for v in serie if not (umbral > 0 and v > umbral)]
    base = r2(suma(normales or [mediana]) / len(normales or [mediana]))
    limpia = [base if umbral > 0 and v > umbral else v for v in serie]
    return r2(suma(limpia) / len(limpia)), limpia, len(serie) - len(normales)


def promedio_intermitente(serie, modo):
    """Propuesta para depurarSerieConsumo cuando mas de la mitad de los dias son cero."""
    serie = np.asarray(serie, float)
    if (serie == 0).mean() <= 0.5:
        return depurar(serie)[0]
    ventas = serie[serie > 0]
    if modo == "a" or len(ventas) < 4:
        return float(serie.mean())
    # B: el atipico se mide contra los dias con venta; los ceros siguen contando como cero.
    q1, med, q3 = np.percentile(ventas, [25, 50, 75])
    corte = max(q3 + 1.5 * (q3 - q1), med * 1.8)
    return float(np.where(serie > corte, med, serie).mean())


def croston_sba(y):
    z = p = None
    q = 1
    for v in y:
        if v > 0:
            z, p = (v, q) if z is None else (z + ALFA * (v - z), p + ALFA * (q - p))
            q = 1
        else:
            q += 1
    return 0.0 if z is None else (1 - ALFA / 2) * z / p


def tsb(y):
    z = b = None
    for i, v in enumerate(y):
        if z is None:
            if v > 0:
                z, b = v, 1 / (i + 1)
        else:
            b += BETA * ((v > 0) - b)
            if v > 0:
                z += ALFA * (v - z)
    return 0.0 if z is None else z * b


def clase_demanda(y):
    ventas = y[y > 0]
    if len(ventas) == 0:
        return "sin_ventas"
    adi = len(y) / len(ventas)
    cv2 = ventas.var() / ventas.mean() ** 2
    return {(False, False): "suave", (False, True): "erratica",
            (True, False): "intermitente", (True, True): "irregular"}[(adi >= UMBRAL_ADI, cv2 >= UMBRAL_CV2)]


def filas(Yf, dds, o):
    """Variables de la fila cuyo ultimo dato conocido es el dia o. Solo mira Yf[:, :o + 1]."""
    hist = Yf[:, : o + 1]
    # Cada fila se divide por el promedio de su propio pasado: asi conviven unidades, gramos y kilos.
    escala = hist.mean(1)
    escala[escala == 0] = 1
    # shortcut: asume que el proximo dia operativo es el dia siguiente; con dias cerrados, pasar un calendario.
    dds_objetivo = (dds[o] + 1) % 7
    mismo_dds = np.where(dds[: o + 1] == dds_objetivo)[0][-1]
    ventana = hist[:, -VENTANA:]
    dias_sin_venta = np.where(hist.max(1) > 0, (hist[:, ::-1] > 0).argmax(1), VENTANA)
    X = np.column_stack([np.full(len(hist), dds_objetivo), hist[:, -1] / escala, hist[:, mismo_dds] / escala,
                         hist[:, -7:].mean(1) / escala, ventana.mean(1) / escala, (ventana == 0).mean(1),
                         np.minimum(dias_sin_venta, VENTANA)])
    return X, escala


def global_ml(Yf, dds, t, h, tipo):
    """Un modelo para todos los articulos; toda etiqueta de entrenamiento termina a mas tardar en t."""
    Xs, ys = [], []
    for o in range(6, t - h + 1):
        assert o + h <= t, "fuga: etiqueta de entrenamiento posterior al origen"
        X, escala = filas(Yf, dds, o)
        Xs.append(X)
        ys.append(Yf[:, o + 1: o + h + 1].sum(1) / escala)
    X, y = np.vstack(Xs), np.concatenate(ys)
    Xt, escala_t = filas(Yf, dds, t)
    if tipo == "lineal":
        unos = np.eye(7)
        modelo = LinearRegression(fit_intercept=False)
        modelo.fit(np.column_stack([unos[X[:, 0].astype(int)], X[:, 1:]]), y)
        pred = modelo.predict(np.column_stack([unos[Xt[:, 0].astype(int)], Xt[:, 1:]]))
    else:
        pred = lgb.LGBMRegressor(**PARAMS_LGBM).fit(X, y, categorical_feature=[0]).predict(Xt)
    return np.maximum(pred, 0) * escala_t


def pronosticar(Y, dds, fechas, t):
    """Pronosticos con origen t. Todo sale de Yp: el futuro no llega a ningun modelo."""
    Yp, dds = Y[:, : t + 1], dds[: t + 1]
    ventana = Yp[:, fechas[: t + 1] > fechas[t] - np.timedelta64(VENTANA, "D")]
    depuradas = [depurar(y) for y in ventana]
    ref = np.array([d[0] for d in depuradas])
    crudo = ventana.mean(1)
    sba = np.array([croston_sba(y) for y in Yp])
    tasa_tsb = np.array([tsb(y) for y in Yp])
    intermit = np.array([clase_demanda(y) in ("intermitente", "irregular", "sin_ventas") for y in Yp])
    tasas = {
        REFERENCIA: ref, "ref_28_sin_filtro": crudo, "cero": np.zeros(len(Yp)),
        "sba": np.where(intermit, sba, ref), "tsb": np.where(intermit, tasa_tsb, ref),
        "prop_a_sin_filtro": np.array([promedio_intermitente(y, "a") for y in ventana]),
        "prop_b_umbral_ventas": np.array([promedio_intermitente(y, "b") for y in ventana]),
    }
    salida = {h: {m: v * h for m, v in tasas.items()} for h in HORIZONTES}
    salida[1]["ingenuo_dds"] = Yp[:, np.where(dds == (dds[-1] + 1) % 7)[0][-1]]
    salida[7]["ingenuo_dds"] = Yp[:, -7:].sum(1)
    Yf = np.array([depurar(y)[1] for y in Yp])  # filtro calculado solo con el entrenamiento de este origen
    for h in HORIZONTES:
        for tipo in ("lineal", "lgbm"):
            salida[h][f"{tipo}_sin_filtro"] = global_ml(Yp.copy(), dds, t, h, tipo)
            salida[h][f"{tipo}_iqr"] = global_ml(Yf, dds, t, h, tipo)
    diagnostico = dict(con_venta=(ventana.max(1) > 0).sum(), base_cero=((ref == 0) & (ventana.max(1) > 0)).sum(),
                       suma_base=ref.sum(), suma_cruda=crudo.sum(), picos=sum(d[2] for d in depuradas),
                       dias_venta=(ventana > 0).sum(), cero_mayoria=((ventana == 0).mean(1) > 0.5).sum())
    return salida, diagnostico


def autopruebas(Y, dds, fechas):
    # Vectores comprobados contra la funcion TypeScript real de la app.
    assert depurar([0, 0, 0, 0, 3, 0, 0, 2]) == VECTOR_A
    assert depurar([1, 2, 3, 2, 100, 2, 1, 3]) == VECTOR_B
    assert abs(croston_sba([0, 0, 2, 0, 2]) - 0.95 * 2 / 2.9) < 1e-9
    assert depurar([0] * 28)[0] == 0
    # Sin fuga: si se altera todo lo posterior al origen, ningun pronostico cambia.
    t = 35
    base, _ = pronosticar(Y, dds, fechas, t)
    alterada = Y.copy()
    alterada[:, t + 1:] = 1e9
    otra, _ = pronosticar(alterada, dds, fechas, t)
    for h in HORIZONTES:
        for modelo in base[h]:
            assert np.array_equal(base[h][modelo], otra[h][modelo]), f"fuga de futuro en {modelo} h={h}"
    # La prueba no es vacia: si se altera el pasado, los modelos con datos si cambian.
    alterada = Y.copy()
    alterada[:, t] += 5
    otra, _ = pronosticar(alterada, dds, fechas, t)
    for modelo in ("ref_28_sin_filtro", "ingenuo_dds", "lineal_sin_filtro", "lgbm_sin_filtro", "sba"):
        assert not np.array_equal(base[7][modelo], otra[7][modelo]), f"prueba vacia en {modelo}"


VECTOR_A = (0.0, [0.0] * 8, 2)  # dos ventas en ocho dias: ambas se marcan atipicas y la base queda en 0
VECTOR_B = (2.0, [1.0, 2.0, 3.0, 2.0, 2.0, 2.0, 1.0, 3.0], 1)


def cargar(carpeta):
    movimientos = pd.DataFrame(json.loads((carpeta / "movimientos.json").read_text(encoding="utf-8")))
    consumo = pd.DataFrame(json.loads((carpeta / "consumo.json").read_text(encoding="utf-8")))
    local = pd.to_datetime(movimientos.fecha, utc=True, format="ISO8601").dt.tz_convert("America/Santiago")
    movimientos["local"] = local
    movimientos["dia"] = local.dt.tz_localize(None).dt.normalize()
    return movimientos, consumo


def perfil_datos(m, consumo, Y, articulos, dias):
    """Imprime lo que permite juzgar si los datos parecen operacion real."""
    v = m[m.tipo_movimiento == "venta"]
    print("== DATOS ==")
    print(f"movimientos: {len(m)}; consumo: {len(consumo)}; desde {m.fecha.min()[:10]} hasta {m.fecha.max()[:10]} (UTC)")
    print(m.groupby("tipo_movimiento").cantidad.agg(["size", "min", "max"]).to_string())
    print("movimientos por sucursal:", m.sucursal_id.value_counts().to_dict())
    grandes = m[(m.tipo_movimiento == "ajuste") & (m.cantidad.abs() > 1000)]
    print(f"ajustes de carga masiva (no consumo): {len(grandes)} en dias", sorted(grandes.dia.dt.strftime('%Y-%m-%d').unique()))
    print(f"dias operativos: {len(dias)} de {dias[0].date()} a {dias[-1].date()}; "
          f"consecutivos: {(dias[-1] - dias[0]).days + 1 == len(dias)}")
    print(f"ventas: {v.venta_id.nunique()}; lineas: {len(v)}; articulos con venta: {len(Y)}")
    manual = v.fecha.str.contains(r"\.\d")
    print(f"lineas con hora en segundo exacto :00: {(v.local.dt.second == 0).sum()}; con microsegundos (a mano): "
          f"{manual.sum()} en {v[manual].venta_id.nunique()} ventas")
    sembradas = v[~manual & (v.tipo_articulo == "producto")]
    print("reparto de cantidad en productos sembrados:", sembradas.cantidad.value_counts(normalize=True).round(3).head(4).to_dict())
    horas = v.local.dt.hour.value_counts(normalize=True).sort_index()
    print("porcentaje de lineas por hora:", (horas * 100).round(1).to_dict())
    uni = v.drop_duplicates("venta_id")
    print("ventas promedio por dia de la semana (0=lunes):",
          uni.groupby([uni.dia, uni.dia.dt.day_of_week]).size().groupby(level=1).mean().round(1).to_dict())
    feriados = ["2026-09-18", "2026-09-19", "2026-10-12", "2026-10-31", "2026-11-01"]
    print("ventas en feriados legales:", uni[uni.dia.isin(pd.to_datetime(feriados))].groupby("dia").size().rename(lambda d: str(d.date())).to_dict())
    p = Y[articulos.unidad.eq("un").values]
    s = pd.DataFrame(p.T)
    print(f"por articulo (un): dias en cero mediana {(p == 0).mean(1).mean() * 100:.1f}%; venta diaria mediana "
          f"{np.median(p.mean(1)):.2f}; varianza/media mediana {np.median(p.var(1) / p.mean(1)):.2f}; autocorrelacion mediana "
          f"rezago 1 {s.apply(lambda c: c.autocorr(1)).median():.3f}, rezago 7 {s.apply(lambda c: c.autocorr(7)).median():.3f}")
    print("stock_actual en consumo.json:", consumo.stock_actual.value_counts().head(3).to_dict(),
          "stock_minimo:", consumo.stock_minimo.value_counts().head(3).to_dict())
    print("articulos marcados QA:", int(articulos.qa.sum()), "de ellos por nombre:", int(articulos.qa_nombre.sum()),
          "nombres:", articulos[articulos.qa_nombre].articulo.tolist())
    print("unidades:", articulos.unidad.value_counts().to_dict())


def estado(margen, tasa):
    """Replica evaluarEstadoPredictivo y diasHastaMinimo con historial suficiente."""
    if margen < 0:
        return "comprar-hoy"
    if tasa <= 0:
        return "estable"
    cobertura = 0 if margen == 0 else math.floor(margen / tasa * 10 + 0.5) / 10
    return "comprar-hoy" if cobertura <= 1.5 else "proximo-pedido" if cobertura <= 4 else "estable"


def ic95(dif):
    rng = np.random.default_rng(SEMILLA)  # misma semilla: todos los modelos usan el mismo remuestreo de articulos
    return np.percentile(dif[rng.integers(0, len(dif), (5000, len(dif)))].mean(1), [2.5, 97.5])


def metricas(F, A, escala, escala2, grupos, un):
    """Una fila por modelo y grupo. MAE, WAPE y sesgo solo en articulos por unidad: no se suman gramos con unidades."""
    filas_csv = []
    mase_art = {m: np.abs(p - A).mean(0) / escala for m, p in F.items()}
    rmsse_art = {m: np.sqrt(((p - A) ** 2).mean(0)) / escala2 for m, p in F.items()}
    for modelo, pred in F.items():
        error = pred - A
        for nombre, g in grupos.items():
            if not g.any():
                continue
            mu, suma_real = g & un, A[:, g & un].sum()
            dif = (mase_art[modelo] - mase_art[REFERENCIA])[g]
            dif2 = (rmsse_art[modelo] - rmsse_art[REFERENCIA])[g]
            lo, hi = ic95(dif) if modelo != REFERENCIA else (np.nan, np.nan)
            lo2, hi2 = ic95(dif2) if modelo != REFERENCIA else (np.nan, np.nan)
            filas_csv.append(dict(
                modelo=modelo, grupo=nombre, articulos=int(g.sum()),
                mae=np.abs(error[:, mu]).mean(), wape_pct=100 * np.abs(error[:, mu]).sum() / suma_real,
                sesgo_pct=100 * error[:, mu].sum() / suma_real,
                mase_media=mase_art[modelo][g].mean(), mase_mediana=np.median(mase_art[modelo][g]),
                dif_mase=dif.mean(), ic95_inf=lo, ic95_sup=hi,
                pct_articulos_mejor=100 * (dif < 0).mean(), pct_articulos_peor=100 * (dif > 0).mean(),
                rmsse_media=rmsse_art[modelo][g].mean(), rmsse_ic95_inf=lo2, rmsse_ic95_sup=hi2))
    return filas_csv, mase_art


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("datos", type=Path)
    parser.add_argument("salida", type=Path)
    args = parser.parse_args()
    args.salida.mkdir(parents=True, exist_ok=True)

    m, consumo = cargar(args.datos)
    ventas = m[m.tipo_movimiento == "venta"]
    sucursales = ventas.sucursal_id.unique()
    # shortcut: el modelo global se entrena con una sucursal; con mas sucursales con ventas hay que repetir por cada una.
    if len(sucursales) != 1:
        raise SystemExit(f"Se esperaba una sucursal con ventas y hay {len(sucursales)}: adaptar el script.")
    sucursal = int(sucursales[0])
    dias = pd.DatetimeIndex(sorted(ventas.dia.unique()))
    if (dias[-1] - dias[0]).days + 1 != len(dias):
        print("AVISO: hay dias sin ventas; revisar el shortcut de dia siguiente en filas().")
    cons = m[m.tipo_movimiento.isin(MOVIMIENTOS_CONSUMO) & (m.sucursal_id == sucursal)]
    tabla = -cons.pivot_table(index=["tipo_articulo", "articulo_id"], columns="dia", values="cantidad", aggfunc="sum")
    tabla = tabla.reindex(columns=dias).fillna(0).clip(lower=0).round(2)
    Y = tabla.to_numpy(float)
    fechas = dias.to_numpy()
    dds = dias.day_of_week.to_numpy()

    nombres = cons.groupby(["tipo_articulo", "articulo_id"]).agg(articulo=("articulo", "first"), unidad=("unidad", "first"))
    articulos = nombres.reindex(tabla.index).reset_index()
    articulos["qa_nombre"] = articulos.articulo.str.contains(r"(?i)\bqa\b|test|prueba")
    # Las lineas con microsegundos no vienen de la carga masiva: son ventas hechas a mano durante las pruebas.
    claves_manual = ventas[ventas.fecha.str.contains(r"\.\d")].set_index(["tipo_articulo", "articulo_id"]).index
    articulos["qa"] = articulos.qa_nombre | tabla.index.isin(claves_manual)
    perfil_datos(m, consumo, Y, articulos, dias)

    autopruebas(Y, dds, fechas)
    print("\nverificacion sin fuga de futuro y replica del calculo: OK")

    T = Y.shape[1] - 1
    origen_ini = VENTANA - 1
    preds = {h: {} for h in HORIZONTES}
    diag = []
    for t in range(origen_ini, T + 1):
        salida, d = pronosticar(Y, dds, fechas, t)
        diag.append(d)
        for h in HORIZONTES:
            for modelo, v in salida[h].items():
                preds[h].setdefault(modelo, {})[t] = v

    print(f"\n== CALCULO ACTUAL (depurarSerieConsumo), {len(diag)} origenes ==")
    total = {k: sum(d[k] for d in diag) for k in diag[0]}
    print(f"casos articulo-origen con venta en la ventana: {total['con_venta']}; con mayoria de dias en cero: "
          f"{total['cero_mayoria']}; con base en 0 pese a tener ventas: {total['base_cero']}")
    print(f"dias con venta marcados atipicos: {total['picos']} de {total['dias_venta']} "
          f"({100 * total['picos'] / total['dias_venta']:.1f}%); base depurada frente a promedio crudo: "
          f"{100 * (total['suma_base'] / total['suma_cruda'] - 1):.1f}%")

    # Clase fija con los primeros 28 dias: agrupar con todo el periodo seria mirar el futuro.
    clases = np.array([clase_demanda(y) for y in Y[:, :VENTANA]])
    print("\n== CLASES DE DEMANDA ==")
    print("primeros 28 dias:", pd.Series(clases).value_counts().to_dict())
    clases_61 = np.array([clase_demanda(y) for y in Y])
    print("61 dias completos:", pd.Series(clases_61).value_counts().to_dict(), "cambian de clase:", int((clases != clases_61).sum()))
    frecuente = np.isin(clases, ["suave", "erratica"])
    qa = articulos.qa.to_numpy()
    grupos = dict(todos=np.ones(len(Y), bool), sin_qa=~qa, solo_qa=qa, frecuentes=frecuente, intermitentes=~frecuente)
    un = articulos.unidad.eq("un").to_numpy()

    registros, mase_art = [], {}
    for h in HORIZONTES:
        origenes = range(origen_ini, T - h + 1)
        A = np.array([Y[:, t + 1: t + h + 1].sum(1) for t in origenes])
        F = {modelo: np.array([por_t[t] for t in origenes]) for modelo, por_t in preds[h].items()}
        # Escala MASE: ingenuo de 7 dias dentro de los primeros 28 dias. Sin ventas ahi, el articulo no entra.
        S = np.cumsum(np.c_[np.zeros(len(Y)), Y[:, :VENTANA]], axis=1)
        sumas = S[:, h:] - S[:, :-h]
        escala = np.abs(sumas[:, 7:] - sumas[:, :-7]).mean(1)
        escala2 = np.sqrt(((sumas[:, 7:] - sumas[:, :-7]) ** 2).mean(1))
        # shortcut: un articulo sin ventas en los primeros 28 dias no tiene escala; hoy no hay ninguno, con datos reales filtrarlos.
        assert (escala > 0).all(), "articulos sin escala MASE: filtrarlos antes de agregar"
        print(f"\nh={h}: {len(origenes)} origenes")
        filas_h, mase_art[h] = metricas(F, A, escala, escala2, grupos, un)
        registros += [dict(horizonte=h, **f) for f in filas_h]

    r = pd.DataFrame(registros).round(4)
    r.to_csv(args.salida / "resultados.csv", index=False)
    pd.set_option("display.width", 250, "display.max_columns", 30, "display.max_rows", 500)
    for (h, grupo), g in r.groupby(["horizonte", "grupo"], sort=False):
        print(f"\n== h={h} grupo={grupo} articulos={g.articulos.iloc[0]} ==")
        print(g.drop(columns=["horizonte", "grupo", "articulos"]).sort_values("mase_media").to_string(index=False))

    print("\n== CRITERIO ==")
    print(f"A (h=7, en todos y sin_qa): IC95 de la diferencia de MASE bajo 0, mejora >= {MEJORA_MINIMA:.0%}, "
          f"sesgo absoluto no peor que la referencia + {HOLGURA_SESGO} puntos.")
    print("B (h=1, regla escrita antes de medir): MASE no claramente peor. C (h=1, agregada al ver que 'cero' gana B): RMSSE no claramente peor.")
    def fila(modelo, h, grupo):
        return r[(r.modelo == modelo) & (r.horizonte == h) & (r.grupo == grupo)].iloc[0]
    cumplen_abc, cumplen_ac = [], []
    for modelo in ORDEN_SIMPLICIDAD:
        crit_a = True
        for grupo in ("todos", "sin_qa"):
            x, ref = fila(modelo, 7, grupo), fila(REFERENCIA, 7, grupo)
            crit_a &= bool(x.ic95_sup < 0 and 1 - x.mase_media / ref.mase_media >= MEJORA_MINIMA
                           and abs(x.sesgo_pct) <= abs(ref.sesgo_pct) + HOLGURA_SESGO)
        crit_b, crit_c = bool(fila(modelo, 1, "todos").ic95_inf <= 0), bool(fila(modelo, 1, "todos").rmsse_ic95_inf <= 0)
        x, ref = fila(modelo, 7, "todos"), fila(REFERENCIA, 7, "todos")
        print(f"{modelo:24s} mejora h7 {100 * (1 - x.mase_media / ref.mase_media):6.1f}%  IC95 [{x.ic95_inf:+.3f}, {x.ic95_sup:+.3f}]  "
              f"sesgo {x.sesgo_pct:+.1f}%  A={crit_a} B={crit_b} C={crit_c}")
        if crit_a and crit_b and crit_c:
            cumplen_abc.append(modelo)
        if crit_a and crit_c:
            cumplen_ac.append(modelo)
    print("GANADOR con A y B y C:", cumplen_abc[0] if cumplen_abc else f"ninguno; se mantiene {REFERENCIA}")
    print("GANADOR con A y C:", cumplen_ac[0] if cumplen_ac else f"ninguno; se mantiene {REFERENCIA}")
    print("cumplen A y C:", cumplen_ac)

    print("\n== EMPATE: cada modelo frente al promedio de 28 dias sin filtro, h=7 (diferencia de MASE; negativo favorece al modelo) ==")
    for modelo in ("lgbm_sin_filtro", "prop_b_umbral_ventas", "lineal_sin_filtro", "tsb"):
        for nombre in ("todos", "sin_qa"):
            g = grupos[nombre]
            d = (mase_art[7][modelo] - mase_art[7]["ref_28_sin_filtro"])[g]
            lo, hi = ic95(d)
            print(f"{modelo:24s} {nombre:7s} dif {d.mean():+.4f}  IC95 [{lo:+.4f}, {hi:+.4f}]  mejor en {100 * (d < 0).mean():.1f}% de los articulos")

    print("\n== DECISION DE COMPRA, con la tasa de cada modelo en el ultimo origen (h=7 / 7) ==")
    llaves = consumo[consumo.sucursal_id == sucursal].set_index(["tipo", "articulo_id"])
    llaves = llaves.reindex(tabla.index.rename(["tipo", "articulo_id"]))
    margen_real = (llaves.stock_actual - llaves.stock_minimo).to_numpy(float)
    tasas = {modelo: preds[7][modelo][T] / 7 for modelo in preds[7]}
    escenarios = {"stock real": margen_real, **{f"margen {k}": np.full(len(Y), float(k)) for k in (1, 2, 3, 5, 10)}}
    decisiones = []
    for nombre, margen in escenarios.items():
        base = [estado(a, b) for a, b in zip(margen, tasas[REFERENCIA])]
        fila_d = dict(escenario=nombre, **{e: base.count(e) for e in ("comprar-hoy", "proximo-pedido", "estable")})
        for modelo in ("ref_28_sin_filtro", "prop_b_umbral_ventas", "ingenuo_dds", "sba", "tsb", "lineal_sin_filtro", "lgbm_sin_filtro"):
            fila_d[modelo] = sum(a != estado(c, d) for a, c, d in zip(base, margen, tasas[modelo]))
        decisiones.append(fila_d)
    print("(columnas de modelo: articulos que cambian de estado frente a la referencia)")
    print(pd.DataFrame(decisiones).to_string(index=False))
    print(f"\nCSV: {args.salida / 'resultados.csv'}")


if __name__ == "__main__":
    main()
