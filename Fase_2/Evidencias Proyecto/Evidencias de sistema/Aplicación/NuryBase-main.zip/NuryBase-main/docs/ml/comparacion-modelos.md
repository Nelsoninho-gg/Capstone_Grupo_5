# Comparación de modelos para pronosticar el consumo diario

Medición sobre **datos de desarrollo**, no sobre operación real de una cafetería. Sirve para probar el método y para encontrar un defecto en el cálculo actual. No sirve para afirmar cuál modelo funcionará mejor con ventas reales.

## Resumen

- **Machine learning no ganó.** LightGBM quedó primero en la tabla, pero su ventaja sobre un promedio simple de 28 días no se distingue de cero.
- **El promedio actual sí se puede mejorar, y sin machine learning.** Su filtro de atípicos descarta ventas normales en productos de poca venta. Pronostica 66% menos de lo que se vendió.
- **Recomendación:** no adoptar LightGBM. Corregir el filtro para productos intermitentes (propuesta A, abajo) y volver a medir cuando haya ventas reales.
- **Hay una advertencia sobre el criterio:** con la regla tal como se escribió antes de medir, ningún modelo gana. Se explica en [Quién ganó](#quién-ganó).

## Qué datos había y sus límites

Se usaron dos exportaciones: 6.001 movimientos de inventario y 362 filas de consumo. Las ventas van del 5 de septiembre al 4 de noviembre de 2026: 61 días, 1.941 ventas y 357 artículos vendidos.

**Los datos parecen sembrados, no operación real:**

| Señal | Lo que se encontró | Lo que se esperaría en una cafetería real |
|---|---|---|
| Hora exacta | 4.839 de 4.877 líneas de venta caen en el segundo :00 | Segundos variados |
| Reparto por hora | Plano: entre 6,3% y 8,0% por hora, de 8 a 21 h | Un pico claro a la hora de almuerzo |
| Día de la semana | Domingo es el más alto (39,7 ventas) y miércoles el más bajo (26,4) | Fin de semana bajo o cerrado, por estar en una sede universitaria |
| Feriados | Hubo ventas en los cinco feriados legales del período, por ejemplo 51 el 19 de septiembre | Local cerrado |
| Cantidad por línea | 1, 2 o 3 unidades, casi un tercio cada una | Mayoría de una unidad |
| Relación con días anteriores | Autocorrelación mediana de -0,03 con el día anterior y con la semana anterior | Algo de relación entre un día y otro |

Si las ventas de cada artículo son casi independientes de un día a otro, ningún modelo puede aprender mucho más que el promedio. Eso limita lo que esta comparación puede demostrar.

**Otros límites:**

- **Una sola sucursal con ventas.** La otra sucursal del archivo tiene un solo movimiento, que además no cuenta como consumo. No se pudo comparar entre sucursales.
- **Todos los días fueron operativos.** Los 61 días son consecutivos, así que la regla de ignorar los días sin actividad no se puso a prueba.
- **Todos los artículos son intermitentes.** Tienen una mediana de 80,1% de días en cero. Según la clasificación por ADI y CV² de los primeros 28 días, 348 son intermitentes, 9 son irregulares y **ninguno es frecuente**. La comparación entre frecuentes e intermitentes que se pedía **no se pudo hacer**.
- **Artículos de prueba.** Se esperaban nombres con "QA", "PRUEBA" o "TEST", pero en esta exportación solo uno lo cumple, un insumo. Por eso también se marcaron como prueba los artículos con ventas hechas a mano: 38 líneas en 29 ventas, reconocibles porque su hora trae microsegundos. Esta segunda marca es una deducción, no un dato registrado. En total son 16 artículos.
- **Unidades mezcladas.** Hay 354 artículos en unidades, 2 en gramos y 1 en kilos. MAE, WAPE y sesgo se calculan solo con los artículos en unidades. MASE usa todos, porque no depende de la unidad.
- **No hay mermas registradas.** El consumo interno (6 movimientos) no se cuenta, igual que en la aplicación.
- **El stock es artificial.** Los ajustes masivos de carga (722 movimientos) no son consumo y quedaron fuera. En la exportación, 361 de 362 filas tienen stock 10 y casi todos los mínimos son 0.

## Qué modelos se compararon y por qué

Todos usan las mismas ventas pasadas y producen cifras por cálculo. La IA del sistema sigue solo interpretando.

| Modelo | Qué hace | Por qué está | Ventajas | Desventajas |
|---|---|---|---|---|
| **Promedio actual** (`ref_28_iqr`) | Promedio de 28 días con el filtro de atípicos de la aplicación | Es la referencia que hay que superar | Ya está hecho, es simple y se explica fácil | Ignora el día de la semana; el filtro falla con poca venta |
| **Promedio sin filtro** (`ref_28_sin_filtro`) | El mismo promedio, sin filtro | Mide si el filtro ayuda o estorba, porque un pico puede ser demanda real | Es lo más simple posible | Un error de digitación sube el promedio durante 28 días |
| **Ingenuo** (`ingenuo_dds`) | Repite el mismo día de la semana anterior; para 7 días, suma la última semana | Control: si un modelo no le gana, no aporta | No necesita cálculo ni entrenamiento | Copia todo el ruido de una sola semana |
| **Regresión lineal** (`lineal_*`) | Combina día de la semana, venta de ayer, venta del mismo día de la semana pasada, promedios de 7 y 28 días, porcentaje de días en cero y días desde la última venta | Es el modelo estadístico más simple que usa esas variables | Liviana, necesita pocos datos y se puede explicar | Solo capta relaciones en línea recta; puede dar negativos, que se llevan a cero |
| **LightGBM global** (`lgbm_*`) | Árboles de decisión con las mismas variables; un solo modelo para todos los artículos | Capta combinaciones que la regresión no ve | Aprovecha lo aprendido en todos los artículos | Pide más datos, se explica peor y agrega una dependencia que mantener |
| **Croston/SBA** (`sba`) y **TSB** (`tsb`) | Métodos para demanda intermitente: estiman por separado cuánto se vende y cada cuánto | Son los métodos clásicos para productos con muchos días en cero | Diseñados justo para este caso | Dan una tasa plana, sin día de la semana |
| **Siempre cero** (`cero`) | Pronostica cero | Control agregado para detectar métricas engañosas | Revela si una métrica premia no vender nada | Inútil para comprar |

La regresión y LightGBM dividen cada fila por el promedio pasado de ese artículo. Así un artículo en gramos no domina el modelo. Los hiperparámetros de LightGBM son conservadores y se fijaron antes de medir: 200 árboles, 7 hojas y mínimo de 50 casos por hoja.

## Cómo se midió

- **Validación temporal (walk-forward).** Cada día se pronostica solo con lo anterior y luego se avanza un día. Hubo 33 puntos de partida para 1 día y 27 para la suma de 7 días, que es lo que importa para comprar.
- **Sin mirar el futuro.** El script altera todas las ventas posteriores a un punto de partida y comprueba con `assert` que ningún pronóstico cambia. También comprueba que alterar el pasado sí los cambia, para asegurar que la prueba no es vacía.
- **La referencia replica la aplicación.** Aparte del script, se comparó la réplica en Python con la función TypeScript real en 4.888 series, sin diferencias.
- **Filtro con datos de entrenamiento.** Los modelos con filtro lo calculan solo con lo conocido en cada punto de partida.
- **Comparación contra la referencia.** Se usa un intervalo de confianza del 95% con bootstrap pareado por artículo, semilla fija y 5.000 repeticiones. El script se ejecutó dos veces y produjo el mismo CSV.

**Cómo leer las métricas:**

- **MAE:** error promedio, en unidades.
- **WAPE:** error total como porcentaje de lo vendido.
- **Sesgo:** cuánto se pronostica de más (+) o de menos (-) en total.
- **MASE:** error comparado con el ingenuo en los primeros 28 días. Menor es mejor.
- **RMSSE:** como MASE, pero castiga más los errores grandes.

## Resultados

### Suma de los próximos 7 días, todos los artículos (357)

Un intervalo completamente bajo cero significa que el modelo es mejor que el promedio actual.

| Modelo | MAE | WAPE | Sesgo | MASE | Diferencia de MASE (IC 95%) | Artículos en que mejora |
|---|---:|---:|---:|---:|---|---:|
| LightGBM sin filtro | 2,36 | 72,1% | -0,5% | 1,006 | [-0,260; -0,136] | 72,8% |
| Propuesta B | 2,43 | 74,1% | -11,1% | 1,021 | [-0,246; -0,126] | 71,4% |
| Promedio sin filtro y propuesta A | 2,44 | 74,6% | -7,9% | 1,023 | [-0,244; -0,123] | 70,3% |
| Regresión sin filtro | 2,56 | 78,2% | +8,4% | 1,080 | [-0,182; -0,064] | 62,5% |
| TSB | 2,59 | 79,2% | -2,3% | 1,088 | [-0,174; -0,060] | 59,9% |
| LightGBM con filtro | 2,63 | 80,1% | -30,3% | 1,122 | [-0,112; -0,042] | 69,5% |
| Croston/SBA | 2,74 | 83,5% | +18,4% | 1,159 | [-0,092; +0,019] | 64,1% |
| **Promedio actual (referencia)** | **2,79** | **85,2%** | **-66,2%** | **1,197** | | |
| Ingenuo | 3,06 | 93,3% | -6,6% | 1,304 | [+0,059; +0,155] | 34,2% |
| Regresión con filtro | 3,21 | 98,0% | +2,3% | 1,333 | [+0,065; +0,219] | 43,1% |
| Siempre cero | 3,28 | 100,0% | -100,0% | 1,393 | [+0,169; +0,226] | 15,4% |

El filtro empeora a los tres enfoques en que se probó: el promedio, la regresión y LightGBM.

### Suma de 7 días, sin artículos de prueba (341) y solo de prueba (16)

| Modelo | Sesgo sin prueba | MASE sin prueba | Diferencia de MASE sin prueba (IC 95%) | MASE solo prueba |
|---|---:|---:|---|---:|
| LightGBM sin filtro | +2,0% | 0,945 | [-0,260; -0,132] | 2,311 |
| Propuesta B | -8,8% | 0,955 | [-0,253; -0,127] | 2,421 |
| Promedio sin filtro y propuesta A | -5,4% | 0,958 | [-0,249; -0,123] | 2,411 |
| Regresión sin filtro | +10,7% | 1,018 | [-0,182; -0,058] | 2,387 |
| TSB | +0,4% | 1,024 | [-0,180; -0,059] | 2,458 |
| **Promedio actual** | **-65,1%** | **1,133** | | **2,560** |

Quitar los artículos de prueba no cambia el orden de los primeros modelos. El grupo de prueba es pequeño, así que su MASE alto se debe leer con cuidado.

### Un día, todos los artículos (357)

| Modelo | Sesgo | MASE | RMSSE |
|---|---:|---:|---:|
| Siempre cero | -100,0% | **0,772** | 0,918 |
| Promedio actual | -64,8% | 0,914 | 0,887 |
| LightGBM con filtro | -25,7% | 1,131 | 0,917 |
| Propuesta B | -9,8% | 1,152 | 0,859 |
| Promedio sin filtro y propuesta A | -5,9% | 1,169 | 0,860 |
| TSB | -0,3% | 1,201 | 0,869 |
| LightGBM sin filtro | +1,1% | 1,220 | 0,860 |
| Croston/SBA | +17,4% | 1,262 | 0,873 |
| Regresión sin filtro | +12,2% | 1,270 | 0,863 |
| Ingenuo | -4,3% | 1,275 | 1,166 |
| Regresión con filtro | +5,1% | 1,312 | 0,944 |

**En un solo día, MASE premia no vender nada:** "siempre cero" gana, y le gana al promedio actual en 99,2% de los artículos. Ocurre porque 80% de los días son cero. Por lo mismo, el promedio actual se ve bien aquí solo porque subestima.

## Quién ganó

**Criterio, escrito en el script antes de medir.** Un modelo supera claramente a la referencia si cumple, con y sin artículos de prueba, en la suma de 7 días:

- el intervalo de la diferencia de MASE queda completo bajo cero;
- mejora al menos 5% (este umbral es una interpretación propia de "claramente");
- su sesgo absoluto no supera al de la referencia en más de 5 puntos.

Además, en un día no debe ser claramente peor.

**Resultado con esa regla: ninguno gana y se mantiene el promedio actual.** Todos fallan solo en la condición de un día, que es la misma métrica que gana "siempre cero".

**Ajuste hecho después de ver los resultados.** Como esa condición no sirve con tantos ceros, se agregó la misma revisión con RMSSE, que no premia pronosticar cero. La decisión queda a la vista para que se pueda objetar. Con ese cambio:

- Seis modelos cumplen: promedio sin filtro, propuesta A, propuesta B, TSB, regresión sin filtro y LightGBM sin filtro.
- **Gana el promedio de 28 días sin filtro por ser el más simple.** Mejora 14,5% frente al actual.
- LightGBM mejora 16,0%, pero frente al promedio sin filtro la diferencia es -0,017, con intervalo [-0,042; +0,007]. Es un **empate**, y si empatan gana el más simple.
- La regresión y TSB son claramente peores que el promedio sin filtro.

El intervalo solo remuestrea artículos y no corrige por comparar muchos modelos. Con 33 días, además, no captura lo que cambia a lo largo de un año.

## El defecto del cálculo actual

El comentario del código dice que, con mayoría de días en cero, el IQR es 0 y solo sirve la regla sigma. Eso cubre solo parte del problema. Si más de una cuarta parte de los días tiene venta, el tercer cuartil ya no es cero y el corte queda muy bajo, así que las ventas normales se marcan como atípicas.

Por ejemplo, con dos ventas en ocho días (3 y 2 unidades), ambas se marcan atípicas y el consumo base queda en 0.

Lo medido en los 34 puntos de partida:

- Se marcó como atípico el **51,9% de los días con venta** (34.271 de 65.973).
- En **2.672 de 12.133 casos** (22%), el consumo base quedó en 0 pese a haber ventas.
- El consumo base quedó **68,2% bajo el promedio sin filtrar**.

## Propuesta para productos intermitentes en `depurarSerieConsumo`

No se modificó el código de la aplicación.

**Propuesta A, la recomendada.** Si más de la mitad de los días de la serie son cero, no aplicar el corte estadístico. Los días etiquetados como promoción o evento siguen tratándose igual.

**Propuesta B, medida como alternativa.** En esas mismas series, calcular el corte solo con los días que tuvieron venta (`Q3 + 1,5 × IQR`, con mínimo de `1,8 × mediana`) y reemplazar el pico por la mediana de esos días. Con menos de 4 días de venta no se filtra.

| | Promedio actual | Propuesta A | Propuesta B |
|---|---:|---:|---:|
| Sesgo, 7 días | -66,2% | -7,9% | -11,1% |
| MASE, 7 días | 1,197 | 1,023 | 1,021 |
| MAE, 7 días | 2,79 | 2,44 | 2,43 |

A y B empatan: la diferencia de MASE es -0,003, con intervalo [-0,007; +0,001]. Se recomienda A por ser más simple y tener menos sesgo.

**Cuidados con la propuesta A:**

- En estos datos es idéntica al promedio sin filtro, porque todos los artículos son intermitentes. Su efecto de conservar el filtro en productos frecuentes **no se pudo medir**.
- Un error de digitación grande en un producto intermitente subiría su promedio durante 28 días. La propuesta B protege contra eso en teoría, pero aquí no se vio una ventaja, ni siquiera en los artículos de prueba (MASE de 2,421 contra 2,411). Conviene revisarlo con datos reales.
- Cambiarla obliga a actualizar las pruebas de `analisis-historico.model.spec.ts` que dependan de este comportamiento. Además, la IA recibiría menos picos en lo que se le envía.

## Qué decisión de compra cambiaría

Se comparó el estado de cada artículo (comprar hoy, comprar pronto, estable) con la tasa de cada modelo en el último día, usando la regla de cobertura de la aplicación.

**Con el stock de la exportación casi no cambia nada, pero no es una prueba válida,** porque ese stock es artificial. Por eso también se simuló un stock igual al mínimo más un margen fijo para todos los artículos. Esas filas son hipotéticas.

| Escenario | Promedio actual: comprar hoy / pronto / estable | Sin filtro | Propuesta B | Ingenuo | SBA | TSB | Regresión | LightGBM |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| Stock de la exportación | 1 / 0 / 356 | 2 | 1 | 2 | 2 | 1 | 1 | 1 |
| Margen de 1 | 13 / 89 / 255 | 239 | 232 | 210 | 268 | 236 | 281 | 276 |
| Margen de 2 | 1 / 21 / 335 | 125 | 111 | 134 | 146 | 136 | 192 | 158 |
| Margen de 3 | 1 / 7 / 349 | 28 | 19 | 57 | 27 | 33 | 25 | 26 |
| Margen de 5 | 1 / 0 / 356 | 3 | 2 | 12 | 2 | 4 | 2 | 6 |

Las columnas de modelo indican cuántos de los 357 artículos cambian de estado frente al promedio actual. Con poco margen, corregir el filtro cambiaría la decisión en muchos artículos, porque hoy se estima un consumo demasiado bajo y se avisa tarde. No se midió si esos cambios evitarían quiebres de stock.

## Qué se recomienda

1. **No adoptar LightGBM ni otro modelo complejo por ahora.** No le gana al promedio simple y agregaría un proceso que mantener.
2. **Corregir el filtro con la propuesta A,** si el equipo lo aprueba. Es un cambio pequeño y el defecto no depende de que los datos sean sembrados: ocurre en cualquier serie con muchos días en cero. El tamaño del efecto sí puede ser distinto con ventas reales.
3. **Mantener este script** para repetir la medición cuando existan ventas reales.

## Qué haría falta para volver a medir

- **Ventas reales del punto de venta,** sin la carga sembrada, y con los artículos de prueba identificados.
- **Varias sucursales.** El script se detiene con un aviso si hay más de una con ventas, porque habría que entrenarlo por cada una.
- **Días cerrados.** Si hay fines de semana sin actividad, hay que darle un calendario al script, que hoy asume que el próximo día operativo es el siguiente. El script avisa cuando encuentra días sin ventas.
- **Artículos nuevos.** Un artículo sin ventas en los primeros 28 días detiene el script hasta filtrarlo.
- **Stock real,** para medir qué decisiones cambian de verdad.

**Período académico: no se incluyó, porque no se puede aprender con estos datos.** Los 61 días caen dentro de un mismo semestre, sin ningún cambio de período. Una variable que no cambia no enseña nada, y agregarla sería inventar el efecto.

Como estimación propia, hace falta al menos un año académico completo para ver una vez cada inicio, término y vacación. Para aprender en un año y comprobar en otro, se necesitan unos dos años.

## Cómo reproducirlo

```bash
python -m venv <carpeta_fuera_del_repositorio>
<carpeta_fuera_del_repositorio>/Scripts/python -m pip install -r ml/requirements.txt
<carpeta_fuera_del_repositorio>/Scripts/python ml/comparar_modelos.py <carpeta_datos> <carpeta_salida>
```

La carpeta de datos debe contener `movimientos.json` y `consumo.json`. Son datos sensibles y no van en el repositorio. El script no llama a ninguna API ni servicio externo, imprime los resultados y escribe `resultados.csv` en la carpeta de salida. Se ejecutó con Python 3.13.13 y tarda menos de un minuto.
