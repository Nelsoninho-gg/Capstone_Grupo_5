# Registro y Bitácora de Pruebas Unitarias — NuryBase

Este documento mantiene el inventario y resultado real de las pruebas ejecutadas. Debe actualizarse cada vez que una IA o participante cree o ejecute pruebas.

## Resumen de última ejecución

- **Fecha:** 16 de noviembre de 2026
- **Rama:** `Patricio2_branch` (al día con `origin/develop`; último commit `8cb401e`)
- **Entorno:** Angular 22.1 / Vitest 4.1.11 / Node 24
- **Suites:** 99 aprobadas de 99
- **Pruebas:** 1508 aprobadas de 1508
- **Resultado:** suite completa al 100 %. Corrida del cambio «compatibilidad horaria TIMESTAMPTZ / hora de Chile (`America/Santiago`)».
- **Comando:** `npm test -- --watch=false --reporters=verbose`
- **Build:** `npm run build` aprobado, 0 errores y 0 advertencias
- **Base de datos:** Aplicada en el VPS el 16-11-2026 `database/migrations/20261116_timestamptz_chile.sql` (previo ensayo con `ROLLBACK` en `20261116_timestamptz_chile.ENSAYO.sql` y reinicio de `nury-postgrest`) e integrada al final de `database/nurybase_completo.sql` tras verificación de Patricio en la app. Verificado en `nury-postgres`: `TimeZone = America/Santiago` y las últimas ventas muestran `-03` (`id 3555`: `2026-11-16 15:46:39.918133-03`). Migraciones anteriores aplicadas hasta el 15-11-2026 (`cb0887f`).

## Compatibilidad TIMESTAMPTZ y hora de Chile (`America/Santiago`) — 16-11-2026

- **Pedido de Patricio:** revisar la zona horaria del VPS (`Etc/UTC`, con 3.530 ventas en `TIMESTAMP` sin zona) y aplicar el paso completo a hora de Chile (`Opción A`: migrar a `TIMESTAMPTZ` conservando el instante histórico + `TimeZone = 'America/Santiago'`).
- **Cambio en `src/`:**
  - Nuevo helper compartido `parsearFechaServidor` (`src/app/shared/utils/fecha-servidor.ts`) que respeta offsets explícitos (`Z`, `±HH:MM`, `±HHMM`, `±HH`) y asume UTC solo cuando llega sin zona.
  - `ventas-api.service.ts`: `primeraVenta` usa `parsearFechaServidor`; `instanteServidor` envía `.toISOString()` con `Z` explícita.
  - `dashboard.model.ts`: `fechaDeVenta` usa `parsearFechaServidor`.
  - `herramientas-asistente.model.ts`: `contarPorMedioPago` y `fechasEnHoraChile` usan `parsearFechaServidor`.
  - `herramientas-asistente.service.ts`: `ventasPeriodo` envía el rango `fecha_venta` con `Z` explícita.
  - `inventario.service.ts`: `inicioDelDiaEnUtc` envía `.toISOString()` con `Z` explícita (acorde a `movimientos_stock.creado_en` ya en `TIMESTAMPTZ`).
- **Scripts SQL creados e integrados en `database/nurybase_completo.sql`:**
  - `database/migrations/20261116_timestamptz_chile.ENSAYO.sql` (termina en `ROLLBACK`).
  - `database/migrations/20261116_timestamptz_chile.sql` (migración de las 25 columnas `timestamp without time zone`, recreación de las 5 vistas y actualización de `fn_versiones_receta`, `fn_anular_venta`, `fn_validar_anulacion_cajero`, `fn_registrar_almuerzo_empleado`, `fn_turnos_reporte` y reportes).
  - `database/nurybase_completo.sql`: agregada como sección `63`.
- **Pruebas nuevas o actualizadas:**
  - Nueva suite `src/app/shared/utils/fecha-servidor.spec.ts` (2 casos: sin zona en UTC y offsets `Z`, `-03:00`, `-0300`, `-03`).
  - `dashboard.model.spec.ts`: nuevo caso «respeta fechas con zona horaria explícita (TIMESTAMPTZ)».
  - `ventas-api.service.spec.ts`: actualizado filtro `fecha_venta` con `.000Z` y agregado caso con offset `-03:00` en `primeraVenta`.
  - `herramientas-asistente.model.spec.ts`, `herramientas-asistente.service.spec.ts` e `inventario.service.spec.ts`: actualizados filtros con `.000Z` y caso `-03:00`.
- **Resultado:** `Test Files 99 passed (99)` · `Tests 1508 passed (1508)`. Build: «Application bundle generation complete», 0 errores y 0 advertencias.

## Cajero con inventario de su sucursal, sin sugerido de compra — 15-11-2026

- **Pedido de Patricio:** el cajero debe ver el inventario pero no el sugerido de compra. Patricio eligió que además vea «Mermas y ajustes», pueda ajustar stock y editar mínimos; todo en su sucursal.
- **Cambio:** `inventario.ts` reemplaza `soloAlmuerzos` por `esCajero` y `puedeVer(vista)`: «Sugerencias de compra» solo admin, «Por comprar» todos menos el cajero; si la URL pide `?vista=compras` a un cajero, abre Existencias. `inventario.html` muestra al cajero Existencias, Mermas y ajustes, Almuerzo empleados y el botón «Ajustar stock». `puedeEditarMinimo` (`inventario.service.ts`) acepta al cajero en su sucursal.
- **Base:** necesita el lote C en el VPS (lectura de stock y movimientos, ajuste y mínimos para `nury_cajero`, limitado a su sucursal con `fn_sucursal_restringida`; `fn_articulos_por_comprar` cerrado al cajero).
- **Pruebas nuevas o actualizadas:**
  - `inventario.spec.ts`: «a cashier sees the stock of their branch and can adjust it, but not Por comprar» (reemplaza a la que exigía solo «Almuerzo empleados»); nueva «sends a cashier to existencias if the URL asks for ?vista=compras»; «does not show the lunch query to a cashier» ahora abre la pestaña de almuerzos.
  - `inventario.service.spec.ts`: `puedeEditarMinimo` con «cajero en su sucursal» → true y nuevo «cajero en otra sucursal» → false; el rechazo sin llamar a la API ahora usa «un cajero de otra sucursal».
- **Resultado:** `Test Files 98 passed (98)` · `Tests 1505 passed (1505)`. Build: «Application bundle generation complete», sin errores ni advertencias.

## Ventas a empleados fuera del análisis de clientes y límite de 30 s en consultas (H4.5) — 13-11-2026

- **Registrado el 15-11-2026 al revisar el commit `98e8814`, que no tenía entrada aquí.**
- **Ventas a empleados:** `VentaDashboardApi` lee `tipo_venta`. En `construirEscenario` (`dashboard.model.ts`) los kpis (total y ganancia) siguen contando las ventas a empleados, pero productos, familias, combos, horarios y días de la semana las excluyen, porque llevan descuento y distorsionan el análisis de clientes. Las tarjetas del dashboard lo dicen con «Sin contar ventas a empleados.» y la descripción de las herramientas del chat lo explica a la IA.
- **Límite de 30 s:** `TIEMPO_LIMITE_CONSULTA_MS` (`dashboard.model.ts`) corta la carga del dashboard, las consultas del chat y su respaldo local. Si el esquema no llegó a cargar, el respaldo local no intenta consultar y responde sin datos.
- **POS:** el 💡 del consejo del carro vacío pasa a icono Lucide `lightbulb`.
- **Pruebas:** nuevas o ampliadas en `dashboard.model.spec.ts`, `dashboard.spec.ts`, `asistente-dashboard.service.spec.ts`, `herramientas-asistente.service.spec.ts`, `herramientas-asistente.model.spec.ts`, `ventas-api.service.spec.ts`, `pos-layout.component.spec.ts` y `app-icon.component.spec.ts`.
- **Resultado (corrida del 15-11-2026):** `Test Files 98 passed (98)` · `Tests 1503 passed (1503)`. Build: «Application bundle generation complete».

## Logo de Nury's en el chat, veces que cae cada día y criterio visible de los combos (H4.5) — 11-11-2026

- **Logo del asistente:** las insignias «IA» y «Auto» de cada mensaje y el icono de globo de la cabecera del chat se reemplazan por el logo de Nury's (taza con barras). Se agregó `public/logo-nurys.svg`: el mismo dibujo de `favicon.svg` pero con colores fijos, porque el favicon cambia a trazos claros en modo oscuro y no se vería sobre el fondo claro del chat. La insignia es un círculo verde claro (#eaf4e6) de 28 px con borde. El origen de cada respuesta sigue escrito en la tarjeta («Generada por IA con…» / «Datos calculados por el sistema…»).
- **Veces que cae cada día en el período:** `DemandaDiaSemana.vecesEnPeriodo` y `textoVecesDia` («2 lunes», «1 sábado», «3 sábados»). Bajo cada columna de «Ventas por día de la semana» va cuántas veces cayó ese día, para ver que la suma depende de eso; el nombre accesible dice «Lunes: $X en 2 lunes, N ventas…». La nota lo explica.
- **Criterio de combos a la vista:** bajo el título «Se compran juntos» se explica que solo se recomienda actuar con combos de al menos 5 boletas y el 1% del total, y si ninguno alcanza lo dice en negrita: «Ningún combo alcanza todavía para recomendar una promoción.».
- **Antes de empezar** se trajeron por fast-forward los commits remotos `f038827` y `64bf288` (quitar el consejo del chat, montos en pesos, etc.); no hubo conflictos.
- **Pruebas nuevas (3) y actualizadas:**
  - `dashboard.spec.ts`: nueva «identifica al asistente con el logo de Nury's en vez de la palabra IA». Actualizadas «muestra las ventas por día de la semana…» (veces del día en la columna y en el nombre accesible) y «marca como «Poco frecuente»…» (texto del criterio).
  - `dashboard.model.spec.ts`: nueva «escribe el día en singular o plural» (`textoVecesDia`); «el día con más venta es el que suma más…» ahora comprueba «2 lunes», «1 viernes» y «1 sábado».
  - `asistente-dashboard.service.spec.ts`: datos de prueba con el campo nuevo.
- **Resultado:** suite de dashboard `Tests 290 passed (290)`. Suite completa `Test Files 97 passed (97)` · `Tests 1469 passed (1469)`. Build: «Application bundle generation complete», sin errores ni advertencias.
- **Detalle de combos con cada total explicado (pedido de Patricio, mismo día):** el detalle mezclaba dos totales sin decir cuál era cuál («3 de 21 boletas…» y «3 de las 1.101 boletas del período»). Ahora la primera frase dice «De las 21 boletas que llevan EMPANADA PINO, 3 también llevan CHAPARRITA.» y la segunda «Contando todas las boletas, aparecen juntos en 3 de las 1.101 boletas del período (menos del 1% del total).». El prompt del asistente aclara que `frecuenciaTexto` cuenta solo las boletas del producto principal y `aparicionTexto` todas las del período. Actualizadas «agrupa por familia, franja horaria y productos comprados juntos» (`dashboard.model.spec.ts`) y «explica los productos comprados juntos sin términos técnicos» (`dashboard.spec.ts`). Suite completa `Tests 1469 passed (1469)`; build sin errores ni advertencias.
- **Revisión en el navegador (sesión de admin, `localhost:4200/dashboard`, período «Trimestre», 390 px):** el chat muestra el logo en la cabecera y en el mensaje de bienvenida; bajo cada día aparece «6 lunes», «6 sábados», etc. (el trimestre lleva 6 semanas justas); la tarjeta de combos muestra el criterio y «Ningún combo alcanza todavía…»; el detalle muestra las dos frases nuevas. Sin desbordamiento horizontal. Se dejó el período en «Este mes».
- **Detalle de combos más corto (pedido de Patricio, mismo día):** se quitó el párrafo «Contando todas las boletas, aparecen juntos en 3 de las 1.101 boletas del período (menos del 1% del total). Se compran juntos 10 veces más de lo esperable.». Se eliminó `textoAfinidad` y su prueba («explica la afinidad en lenguaje simple según el lift»). El total del período solo aparece cuando explica por qué el combo es poco frecuente: `textoPocoFrecuente` nombra el dato que falla («Todavía es poco frecuente: se compraron juntos solo 3 veces en el período, menos del 1% de las 1.101 boletas. Para recomendar una promoción hacen falta…»). Pruebas: nueva «explica por qué un combo es poco frecuente con el dato que falla»; actualizadas «explica los productos comprados juntos sin términos técnicos» (ahora exige solo dos párrafos y sin «esperable»), «marca como «Poco frecuente»…», «no recomienda un combo que no llega al 1%…» y la del escenario. Suite completa `Tests 1469 passed (1469)`; build sin errores ni advertencias. Revisado en «Trimestre»: los tres combos muestran las dos frases nuevas.
- **Resumen de cada combo (pedido de Patricio, mismo día):** «14% de las veces» pasa a «14% de las boletas con EMPANADA PINO», para que diga de qué total sale. En los combos ese texto va siempre en su propia línea (`.mining-rule-card .fila-monto`), así los tres resúmenes quedan alineados en 390 px. Prueba actualizada: «explica los productos comprados juntos sin términos técnicos» ahora exige «100% de las boletas con Café». Suite completa `Tests 1469 passed (1469)`; build sin errores ni advertencias. Revisado en «Trimestre» a 390 px, sin desbordamiento.
- **Tres ajustes chicos (aprobados por Patricio, mismo día):**
  1. **Íconos Lucide en vez de emojis:** el 💡 ya no estaba en el dashboard (se fue con el consejo de la IA en 64bf288), pero quedaban ⚠️ y ⏱️ en los avisos, ➤ en el botón de enviar y ℹ️ en el pie del chat. Se cambiaron por `triangle-alert`, `clock`, `send-horizontal` e `info`, agregados a `AppIconComponent` junto con `sparkles` y `sigma`. El 💡 del POS (`pos-layout.component.html`) no se tocó, porque está fuera del dashboard.
  2. **«Cargando…» mientras carga:** `textoActualizacion` dice «Cargando…» mientras `cargandoDatos()` está activo, en vez de «Actualizado justo ahora».
  3. **Origen en la insignia del chat:** una marca en la esquina del logo muestra destellos sobre verde #3d5334 si respondió la IA, sigma sobre #68735e si lo calculó el sistema (`algoritmo` o `respaldo-local`) y un triángulo sobre #a64d34 si la IA respondió sin poder comprobarse.
  - **Pruebas nuevas en `dashboard.spec.ts`:** «la insignia marca el origen %s con %s» (4 casos) y «usa íconos Lucide y no emojis en avisos y en el chat». Se amplió «mientras carga otro período muestra el esqueleto…» para que exija «Cargando…». Suites del dashboard y de `app-icon`: `Tests 302 passed (302)`. Suite completa: `Test Files 97 passed (97)` · `Tests 1476 passed (1476)`. Build: «Application bundle generation complete», sin advertencias.
  - **Revisión en el navegador (sesión de admin, `localhost:4200/dashboard`, escritorio y 390 px):** se ve «Cargando…» junto al esqueleto. En el chat se ven el botón de enviar y el pie con íconos Lucide. Las tres marcas de origen se revisaron con mensajes de ejemplo cargados en el servicio del chat, porque la API `api.nury.cl` no respondía en ese momento (una consulta con sesión se cortó a los 15 s; Inventario tampoco cargaba). Los mensajes se borraron después. A 390 px no hay desbordamiento.
- **Segundo intento (pedido de Patricio, mismo día):** la API seguía degradada. `curl` sin sesión respondía 401 en 0,8 a 5,4 s; en el navegador, una consulta con sesión tardó 10 s en un intento y en otros se cortó a los 20 s. Primero la carga del dashboard terminó en error y se vio el aviso «No se pudieron cargar los datos del negocio» con el ícono `triangle-alert` en #a64d34 (antes ⚠️). Después, al pulsar «Actualizar», el dashboard quedó más de 2 minutos en «Cargando…» y la pregunta escrita al chat en «Consultando datos del negocio y catálogo...», sin respuesta.
- **Respuesta real de la IA (captura de Patricio, 12-11-2026):** a «¿Cuánto vendimos este mes y qué me recomiendas?» la IA respondió con el pie «Generada por IA con: Análisis del negocio», y la insignia mostró la marca de destellos sobre verde. Las marcas del sistema y de «sin comprobar» se vieron solo con mensajes de ejemplo.
- **Recomendaciones solo cuando se piden (pedido de Patricio, 12-11-2026):** `pideRecomendacion` (`asistente-dashboard.service.ts`) detecta preguntas como «¿qué me recomiendas?», «dame un consejo», «¿qué debería hacer…?», «¿qué me sugieres?» o «¿cómo puedo aumentar…?». Solo entonces se agrega después de la pregunta la línea `INSTRUCCION_RECOMENDACION`: de una a tres acciones, cada una junto a su dato, dentro de la respuesta o de la lista, sin sección aparte y sin cifras ni pantallas inventadas. El prompt dice que sin esa línea no se recomienda y que no se usa la palabra «recomendaciones» en el título. Se quitó «consejo» de la lista de campos del JSON, porque ya no existe. El campo `consejo` sigue ignorándose y el verificador de cifras no se tocó.
  - **Pruebas nuevas en `asistente-dashboard.service.spec.ts`:** «pide recomendaciones al modelo solo cuando la pregunta las pide», «la recomendación va en la respuesta y la lista, no en un campo aparte» y «pideRecomendacion(%s) es %s» (8 casos). Suites del dashboard: `Tests 305 passed (305)`. Suite completa: `Test Files 97 passed (97)` · `Tests 1486 passed (1486)`. Build sin errores ni advertencias.
  - **Probado con la IA real:** a «¿Cuánto vendimos este mes y qué me recomiendas?», la IA respondió con el total y tres acciones bajo «Recomendaciones para el negocio», cada una con su dato; el verificador la aceptó y la marca fue de IA. A «¿Qué día de la semana vendemos más este mes?» respondió solo con el dato (martes, $344.820 en 40 ventas), sin recomendaciones.
- **IVA: neto = total ÷ 1,19 (decisión de Patricio, 12-11-2026):** el sistema calculaba el neto como total × 0,81 y el IVA como total × 0,19, como si el IVA fuera el 19% del total. En realidad es el 19% del neto: con $1.800, el neto es $1.513 y el IVA $287, no $1.458 y $342. Se creó `src/app/shared/utils/iva.ts` (`TASA_IVA`, `netoSinIva`, `desglosarIva`; el IVA es total − neto, así ambos suman el total exacto). `PROPORCION_NETA` (`dashboard.model.ts`) pasa a 1 ÷ 1,19, y con eso cambian la ganancia limpia del dashboard, la proyección, los días de la semana y las herramientas del chat (`margen_producto`, `ranking_productos`). El POS usa `desglosarIva` en el resumen de venta (`pos-layout`) y en el comprobante (`payment-modal`).
  - **Pruebas:** nueva `iva.spec.ts` con 2 pruebas: el IVA es el 19% del neto; neto + IVA suman el total en varios montos. Se ampliaron «shows the employee, subtotal and 30% discount on an employee sale receipt (H2.12)» (comprobante: neto $1.529, IVA $291 de $1.820) y «shows subtotal, 30% employee discount and total to pay…» (resumen del POS). Se actualizaron las cifras escritas a mano con × 0,81 en `dashboard.model.spec.ts` (740, 488, 540, cierre 740, lunes 881), `herramientas-asistente.model.spec.ts` (CHAPARRITA: neto $2.521, IVA $479, margen $811 y 27%; receta $1.521; Pan 340; Café 3.702) y `herramientas-asistente.service.spec.ts` (811 y 27%; Café 1.481; Pan 640). Suites afectadas (dashboard, POS e IVA): `Tests 433 passed (433)`. Suite completa: `Test Files 98 passed (98)` · `Tests 1488 passed (1488)`. Build sin errores ni advertencias.
  - **Revisado en la app (sesión de Patricio, localhost:4200, 13-11-2026):** en el POS, una EMPANADA PINO de $3.300 muestra «Subtotal Neto: $2.773» e «IVA (19% incluido): $527», que suman el total; después se vació la comanda sin cobrar. En el dashboard (Este mes, todas las sucursales), la ganancia de cada producto coincide con el cálculo a mano: LAT JUGO JUMEX MANGO 335ML, $30.800 ÷ 1,19 − 22 × $680 = $10.922 (con × 0,81 daba $9.988); BON O BON CLASICO 15G, $10.000 ÷ 1,19 − 20 × $249 = $3.423. No se completó ninguna venta para ver el comprobante; queda cubierto por la prueba del comprobante de empleado.
- **No verificado:** el aviso de «estimación temprana» con su ícono nuevo en pantalla (cubierto por prueba); lector de pantalla.

## Respuestas del chat: sin consejo de la IA, montos en pesos y seguimiento con contexto (H4.5) — 11-11-2026

- **Sin consejo:** el modelo usaba el campo `consejo` para indicar pantallas y pasos que no existen («módulo de ventas», «módulo de sucursales»). El prompt ya no lo pide e `interpretarSalidaAsistente` ya no lo lee. Por decisión de Patricio también se quitó de las respuestas automáticas sin IA: se eliminaron el campo `consejoCard`, el recuadro «Consejo práctico sugerido» de `dashboard.html` y sus estilos. Una conversación guardada antes del cambio puede traer el campo, pero ya no se muestra.
- **Guía de pantallas reales:** `GUIA_ERP` suma Reportes (pestañas Sucursales, Productos, Cajeros y Promociones), Caja, Anulaciones, Administración, Dashboard (pestañas Ventas, Productos y Compras) y la lista completa del menú. El prompt pide nombrar las pantallas como aparecen en el menú, no por su ruta, y decir que no sabe cuando la guía no lo indica.
- **Pantallas inventadas, rechazadas por código:** `pantallasInexistentes` revisa lo que sigue a «módulo», «sección», «pestaña» o «apartado» (con «de», entre comillas o con mayúscula) contra `PANTALLAS_REALES`. Si no existe, la respuesta se rechaza y se pide corregir una vez, igual que con una cifra sin respaldo. No rechaza una negación («no existe un módulo de ventas») ni un uso general («módulo exclusivo», «sección anterior»). «Ventas» y «Compras» valen solo como pestañas.
- **Montos en pesos por código:** `montosEnPesos` (ahora en `herramientas-asistente.model.ts`) convierte «461820 pesos», «461820 CLP» y «$461820» en «$461.820» en la frase y en la lista, después de verificar las cifras. Un número suelto («promedio de 51313») se convierte solo si los resultados lo traen en un campo de monto y en ningún otro campo; si además coincide con una cantidad o un folio, queda como está. No toca años ni números seguidos de una unidad. `ticket_promedio` pasa a contarse como monto, también en los datos calculados. El prompt pide ese mismo formato.
- **Seguimiento con contexto:** la conversación previa que recibe el modelo ahora lleva primero el texto que el usuario leyó y su lista, y después los datos calculados. Antes la lista no se enviaba y los datos iban primero, por lo que el recorte a 500 caracteres podía dejar fuera la respuesta misma.
- **Sucursal en las respuestas:** `stock_articulo` aclara que entrega una fila por cada sucursal donde el artículo está registrado, y el prompt pide decirlo cuando el usuario tiene todas las sucursales y el resultado trae una sola.
- **Pruebas nuevas (6) y actualizadas (`asistente-dashboard.service.spec.ts`):** nuevas «escribe en pesos los montos que el modelo entrega sin formato», «montosEnPesos no toca años, cantidades ni montos ya formateados», «montosEnPesos formatea un número suelto solo si los resultados lo traen como monto», «pantallasInexistentes detecta módulos y pestañas que no están en el menú», «rechaza una respuesta que manda a una pantalla que no existe y pide corregirla» y «la conversación previa lleva primero lo que el usuario leyó, con su lista». Actualizadas «separa la respuesta en frase y lista, limpia el Markdown y descarta el consejo», «entrega la respuesta estructurada como tarjeta y pide ese formato al modelo», «rechaza una cifra inventada aunque venga en la lista», «responde sobre artículos inactivos» y «orienta sobre la carga de facturas XML» (ya sin consejo).
- **`dashboard.spec.ts`:** «muestra la respuesta de la IA en partes, frase y lista, sin recuadro de consejo» reemplaza a la que esperaba el recuadro.
- **Prueba dependiente de la hora, corregida (`dashboard.spec.ts`):** «explica los productos comprados juntos sin términos técnicos» esperaba «en la mañana, desde las 08:00 hrs», pero la venta de prueba usa la hora actual y fallaba al correr después de las 10:30. Ahora comprueba la forma de la frase con cualquier franja.
- **Resultado:** suite completa `Test Files 97 passed (97)` · `Tests 1467 passed (1467)`. Build: «Application bundle generation complete», sin errores ni advertencias.
- **Textos fijos sin rutas:** las respuestas automáticas sin IA nombran el menú y el botón en vez de la ruta: «entra a Facturas en el menú lateral y presiona «Cargar factura»», «En Punto de venta…» y «entra a Maestro de productos en el menú lateral y activa su interruptor». `GUIA_ERP` describe Facturas con su botón «Cargar factura» (antes «Carga de Facturas (/facturas/cargar)», que ya es un modal). Actualizada «orienta sobre la carga de facturas XML».
- **Revisión en el navegador con la IA real (sesión de admin, `localhost:4200/dashboard`, todas las sucursales, «Este mes»):** 4 preguntas, ninguna con recuadro de consejo.
  - «¿Cuánto vendió cada cajero este mes y cuál fue su promedio por venta?»: montos como «$914.060» y «$7.746», en la frase y en la lista.
  - «¿En qué pantalla del sistema reviso el desempeño por sucursal?»: «se revisa en la pantalla Reportes, ingresando a la pestaña Sucursales».
  - «¿Cuál es el stock de chaparrita?»: «10 unidades en Nury Providencia (Equipo de desarrollo)». Los datos calculados traen una sola fila, así que el artículo solo tiene stock registrado en esa sucursal y la respuesta original era correcta.
  - «¿Dónde es eso? Para ver el desempeño por sucursal»: respondió con las ventas del mes, aclarando que corresponden solo a Nury Providencia.
- **No verificado:** el rechazo de una pantalla inventada con la IA real (en estas preguntas no inventó ninguna; lo cubren las pruebas unitarias) y las respuestas automáticas sin IA en pantalla. Sigue dependiendo del modelo no nombrar una pantalla inventada de otra forma («ve a Ventas»).
- **Observado al probar:** una vez, al escribir y enviar con Enter de inmediato, el campo de texto no se vació y la pregunta siguiente salió mezclada con la anterior. No se repitió en los dos envíos siguientes; puede ser un efecto de la automatización. Queda anotado para revisarlo en el teléfono.

## Zoom de iPhone al escribir en el chat (H4.5) — 11-11-2026

- **Causa:** Safari en iPhone hace zoom al enfocar un campo con letra menor a 16 px y no lo deshace al salir. El campo del asistente (`.assistant-input-control`) usaba 12,5 px, y con el zoom el botón de enviar quedaba fuera de la pantalla.
- **Corrección (`dashboard.css`):** en pantallas táctiles (`@media (pointer: coarse)`) el campo usa 16 px. En escritorio sigue en 12,5 px.
- **Pruebas:** sin pruebas nuevas, porque es solo CSS. Suite completa `Test Files 97 passed (97)` · `Tests 1467 passed (1467)`. Build sin errores ni advertencias.
- **Revisión en el navegador (emulación móvil 375×812, táctil):** el campo mide 16 px, el botón de enviar queda dentro de la pantalla (borde derecho en 359 de 375 px) y no hay desborde horizontal.
- **No verificado:** en un iPhone real. La emulación no reproduce el zoom de Safari; falta que Patricio lo confirme en el teléfono, una vez publicado.

## Suma del período por día de la semana, selector recordado, umbral de combos y esqueleto de carga (H4.5) — 10-11-2026

- **Ventas por día de la semana muestra la suma del período** (decisión de Patricio): `construirVistaDiasSemana` usa `montoTotalClp` o `gananciaTotalClp`. `esDiaMayorVenta` marca el día que **suma** más pesos en el período; la tarjeta, la respuesta local del chat («$450.000 vendidos en el período (50 ventas)») y `analisis_dashboard` usan ese mismo criterio. La nota dice «sumando todo el período».
- **El selector se recuerda:** `seleccionarMetricaDias` guarda la métrica en `localStorage` (`CLAVE_METRICA_DIAS_SEMANA` = `nurybase.dashboard.metricaDiasSemana`) con el mismo patrón try/catch del sidebar; si no hay valor guardado parte en «Total vendido».
- **Umbral de combos recomendables:** `MIN_BOLETAS_RECOMENDACION = 5` y `MIN_PORCENTAJE_RECOMENDACION = 1` (% de las boletas del período). Un combo que no llega se sigue mostrando, pero con la etiqueta «Poco frecuente», va después de los recomendables y su consejo dice que es un dato para observar y cuál es el umbral. Campo nuevo `esRecomendable`, visible para la IA con la etiqueta «Alcanza para recomendar una promoción»; el prompt le pide no recomendar promociones con esos combos.
- **Redacción de combos:** el horario va con su artículo («al cierre», «al almuerzo», «a media mañana», «en la mañana») en vez de «en la cierre». La afinidad desde 10 veces se redondea a entero («63 veces», no «62,86 veces»); bajo 10 usa un decimal.
- **Esqueleto de carga:** al abrir el dashboard o cambiar período o sucursal, los KPIs, la proyección y el detalle se reemplazan por bloques grises animados con su misma forma, en vez de mostrar las cifras anteriores con un texto «Cargando…». El texto queda para lectores de pantalla (`.sr-only`, `role="status"`); los bloques tienen `aria-hidden`. Sin animación con `prefers-reduced-motion`. El refresco manual o automático sobre los mismos datos no muestra el esqueleto.
- **Pruebas nuevas (8) y actualizadas:**
  - `dashboard.model.spec.ts`: «el día con más venta es el que suma más en el período, aunque otro tenga mejor promedio», «recomienda un combo con al menos 5 boletas juntos y el 1% del total», «no recomienda un combo que no llega al 1% de las boletas, aunque se repita 5 veces», «dice cada horario con su artículo dentro de la frase», «muestra primero los combos que alcanzan para recomendar». Actualizadas la del escenario (combo no recomendable) y la de ganancia por día.
  - `dashboard.spec.ts`: «recuerda la métrica elegida en la tarjeta por día al volver a abrir el dashboard», «marca como «Poco frecuente» un combo que no alcanza para recomendar una promoción», «mientras carga otro período muestra el esqueleto en vez de las cifras anteriores». Actualizadas las de la tarjeta por día y la de afinidad (63 y 4,6 veces).
  - `asistente-dashboard.service.spec.ts`: «responde sobre el día con más venta en pesos…» ahora espera la suma del período.
- **Resultado:** suite de dashboard `Tests 282 passed (282)`. Suite completa `Test Files 97 passed (97)` · `Tests 1461 passed (1461)`. Build: «Application bundle generation complete», sin errores ni advertencias (el CSS del Dashboard sigue bajo el presupuesto).
- **Revisión en el navegador (sesión de admin, `localhost:4200/dashboard`):** el esqueleto aparece al cambiar a «Trimestre» y desaparece al llegar los datos; «Ganancia limpia» sigue elegida después de recargar; en «Trimestre» los tres combos salen como «Poco frecuente» (3 y 2 boletas de 1.100) con «al cierre» y «63 veces». Revisado a 800 y 390 px sin desbordamiento. Al terminar se dejó la preferencia borrada y el período en «Este mes».
- **No verificado:** el esqueleto con conexión lenta real (se vio con la carga normal del Trimestre); lector de pantalla.

## Texto de los combos, total vendido o ganancia por día de la semana y criterio único del día con más venta (H4.5) — 10-11-2026

- **Combos («Se compran juntos» › Ver detalle):** con 3 combos en 1.100 boletas la pantalla decía «3 de cada 1100 boletas (el 0% del total)». Ahora:
  - `textoAparicion` usa la fracción reducida solo si queda «de cada 10» o menos («2 de cada 3 boletas»). Si no, dice las cantidades reales con separador de miles: «3 de las 1.100 boletas del período». Con todas las boletas dice «todas las boletas del período».
  - `textoSoporte` (campo nuevo `soporteTexto`) nunca muestra «el 0%» para un combo que sí aparece: «menos del 1% del total».
  - El horario dice «Se compran juntos sobre todo en la mañana, desde las 08:00 hrs.» en vez de «Desde 08:00 hrs.».
- **Ventas por día de la semana:** selector «Total vendido | Ganancia limpia» en la tarjeta (parte en Total vendido). `DemandaDiaSemana` suma `gananciaTotalClp` y `promedioGananciaDiariaClp` (sin IVA y descontando costos; los productos sin costo no suman). `construirVistaDiasSemana(dias, metrica)` entrega `valorClp`, `alturaPct` y `esMayor`; una ganancia negativa muestra su valor sin barra. La nota bajo las columnas dice qué se está mirando en cada caso.
- **Un solo criterio para «el día con más venta»:** `esDiaMayorVenta` ahora marca el día con mayor **total vendido promedio por día** (antes, el de más boletas). Lo usan la tarjeta, la respuesta local del chat y el resultado de `analisis_dashboard` que recibe la IA. La respuesta local dice «el día con más venta es el Viernes, con $112.500 vendidos en promedio por día (50 ventas en el período)».
- **Pruebas nuevas (6) y actualizadas:**
  - `dashboard.model.spec.ts`: nuevas «marca como día con más venta el de más pesos, no el de más boletas, igual que la tarjeta», «con ganancia limpia la altura y el día destacado siguen a la ganancia, y una pérdida no tiene barra», «suma la ganancia limpia de cada día y su promedio», «si la fracción no queda chica dice las cantidades reales del período», «nunca muestra "el 0%" para un combo que sí aparece». Actualizadas las de columnas por día, textos de combo y escenario.
  - `dashboard.spec.ts`: nueva «cambia la tarjeta por día de la semana a ganancia limpia». Actualizadas «muestra las ventas por día de la semana…», «en el período Hoy no muestra la tarjeta…» y «explica los productos comprados juntos sin términos técnicos».
  - `asistente-dashboard.service.spec.ts`: «responde sobre el día de mayor volumen de ventas» pasa a «responde sobre el día con más venta en pesos, el mismo que destaca la tarjeta».
- **Resultado:** suite de dashboard `Test Files 7 passed (7)` · `Tests 274 passed (274)`. Suite completa `Test Files 97 passed (97)` · `Tests 1453 passed (1453)`. Build: «Application bundle generation complete», sin errores ni advertencias.
- **Revisión en el navegador (sesión de admin, `localhost:4200/dashboard`):** período «Trimestre», el combo EMPANADA PINO + CHAPARRITA muestra «3 de las 1.100 boletas del período (menos del 1% del total)». El selector cambia la tarjeta: jueves es el día con más venta ($278.437 promedio) y con más ganancia ($72.658 promedio). Revisado a 800 y 390 px, sin desbordamiento ni etiquetas cortadas.
- **No verificado:** una pregunta real al chat sobre el día con más venta después del cambio (cubierto por prueba unitaria); lector de pantalla.

## Gráficos en columnas, ventas por día de la semana, combos y respuestas del chat en partes (H4.5) — 10-11-2026

- **Movimiento por horario en vertical:** la tarjeta dejó las barras horizontales y usa columnas, con el mismo estilo de la proyección por tramos (`.proj-tramos` y `.columnas` comparten reglas en `dashboard.css`). El horario punta va en verde oscuro, con el valor en negrita y «horario punta» en el nombre accesible. El promedio se escribe con coma decimal.
- **Tarjeta nueva «Ventas por día de la semana»** (pestaña Ventas, bajo la de horarios): una columna por día, de lunes a domingo. La altura sigue al **promedio vendido por día** (`promedioVentaDiariaClp`, con IVA incluido) y bajo cada día va la cantidad de ventas del período. `construirVistaDiasSemana` (`dashboard.model.ts`) calcula la altura y marca `esMayorMonto`. No se muestra en el período «Hoy», donde solo habría un día.
- **Combos:** `textoAparicion` reduce la fracción sin redondear («4 de cada 6» pasa a «2 de cada 3»; «67 de cada 100» queda igual). Si el combo está en todas las boletas dice «todas las boletas». En pantalla el paréntesis ahora dice «(el N% del total)».
- **Chat en partes:** el modelo responde con `{"respuesta","titulo","puntos","consejo"}` y la pantalla lo muestra como frase principal, lista con encabezado y recuadro de consejo, en vez de un solo párrafo. `interpretarSalidaAsistente` quita el Markdown (`**`, `#`), acepta hasta 6 puntos y convierte en lista un texto del tipo «frase + viñetas». La lista y el consejo pasan por el mismo verificador de cifras y de nombres que la frase principal; `verificador-cifras.ts` no se modificó.
- **Pruebas nuevas (12):**
  - `dashboard.model.spec.ts` (4): «arma las columnas por día con la altura según el promedio vendido y marca el mayor monto», «sin ventas no marca ningún día ni divide por cero», «reduce la fracción sin redondear», «cuando están en todas las boletas lo dice en palabras».
  - `dashboard.spec.ts` (4): «muestra el movimiento por horario en columnas y marca el horario punta», «muestra las ventas por día de la semana con el monto y destaca el día con más venta», «en el período Hoy no muestra la tarjeta por día de la semana», «muestra la respuesta de la IA en partes: frase, lista y consejo». Se actualizó «explica los productos comprados juntos sin términos técnicos» al texto nuevo.
  - `asistente-dashboard.service.spec.ts` (4): «separa la respuesta en frase, lista y consejo, y limpia el Markdown», «entrega la respuesta estructurada como tarjeta y pide ese formato al modelo», «una respuesta de una sola frase sigue como texto simple», «rechaza una cifra inventada aunque venga en la lista o en el consejo».
- **Resultado:** suite de dashboard `Test Files 7 passed (7)` · `Tests 268 passed (268)`. Suite completa `Test Files 97 passed (97)` · `Tests 1447 passed (1447)`. Build aprobado sin errores ni advertencias (el CSS del Dashboard sigue bajo el presupuesto).
- **Revisión en el navegador (sesión de admin, `localhost:4200/dashboard`, período «Este mes»):** tarjetas revisadas a 1280, 1101, 768 y 390 px, sin desbordamiento horizontal ni etiquetas cortadas. Chat probado con una pregunta real («¿Qué día de la semana vendemos más este mes y qué me recomiendas?»): respondió con frase, encabezado, 4 puntos y consejo, origen «Generada por IA con: Análisis del negocio».
- **No verificado:** los períodos «Hoy», «Esta semana» y «Trimestre» en el navegador (solo por pruebas unitarias); una respuesta rechazada por el verificador con el formato nuevo en uso real; lector de pantalla.

## Timeouts por carga en la suite completa — 09-11-2026

- **Qué pasaba:** con `npm test -- --watch=false` fallaban 1 o 2 pruebas por superar los 5000 ms que trae Vitest por defecto. El archivo que fallaba cambiaba entre corridas (`inventario.spec.ts`, `ingresos-factura.spec.ts` y a veces `reportes.spec.ts`), y cada uno pasaba si se corría solo.
- **Causa:** siempre fallaba la **primera** prueba de cada archivo, porque es la que paga la compilación inicial del componente y sus hijos. Las siguientes reutilizan esa compilación. Tiempos medidos con cada archivo corrido solo:
  - `inventario.spec.ts` › «shows the loading state while stock is being fetched»: 753 ms, contra 171 y 131 ms de las dos siguientes. Con la suite completa en paralelo llegó a 5270 ms y falló.
  - `ingresos-factura.spec.ts` › «lists each entered invoice with who entered it, when and where»: 1198 ms, contra 110 a 420 ms del resto.
  - `reportes.spec.ts` › «asks the current week and the same days of the previous week with every branch»: 799 ms, contra 130 a 300 ms del resto.
- **Cambio:** solo esas tres pruebas tienen ahora un límite de 15 s (`}, 15_000);`), con un comentario que explica el motivo. No cambió lo que comprueban ni la configuración global de pruebas.
- **Resultado:** `Test Files 97 passed (97)` y `Tests 1435 passed (1435)`. Build aprobado sin errores ni advertencias.

## Actualización en tiempo real del período «Hoy» (H4.5) — 09-11-2026

- **Cambio:** el Dashboard se actualiza solo cada 3 minutos mientras se mira el día en curso, y se puede forzar con el botón «Actualizar».
  - `dashboard.ts`: una señal de refresco entra en el mismo `switchMap` de carga. Un refresco sobre los mismos datos no muestra el esqueleto «Cargando…» (se usa `actualizando`), conserva lo último cargado si falla y registra `ultimaActualizacion`. El refresco automático corre **solo** con período `'1d'` y la pestaña visible; al volver a la pestaña se refresca en el acto, con el mismo patrón de `visibilitychange` que Inventario (H3.2 T06).
  - `dashboard.model.ts`: `textoActualizado(desde, ahora)` devuelve «Actualizado justo ahora» bajo 60 s, «Actualizado hace N minutos» y «Actualizado hace N horas»; «Sin actualizar» si nunca se cargó.
  - Pantalla: botón «Actualizar» y texto de última actualización en la cabecera; el botón se deshabilita mientras hay un refresco en curso. Paleta de la guía y ancho completo en ≤640 px.
- **Pruebas:** 1435 pruebas en 97 archivos (1433 aprobadas). Suite de dashboard: **256/256 en 7 archivos**. Nuevas: `dashboard.model.spec.ts` (3 del texto de actualización: primer minuto, minutos y horas en singular/plural, sin carga) y `dashboard.spec.ts` (2: el botón vuelve a consultar sin esqueleto de carga y muestra «justo ahora»; el refresco automático solo ocurre en «Hoy»).
- **No verificado:** el paso real de los 3 minutos en el navegador (la prueba cubre el disparador y su condición, no el temporizador de 180 s); el texto «Actualizando…» no se anunció con lector de pantalla.



## Período «Hoy» (1d) en el Dashboard Ejecutivo y su proyección de cierre (H4.5) — 09-11-2026

- **Cambio:** se agrega el período de un día (`'1d'`) al Dashboard Ejecutivo y al Asistente.
  - `dashboard.model.ts`: `PeriodoDashboard` ahora es `'1d' | '7d' | '30d' | '90d'`; `TITULOS_PERIODO['1d']` = «Total vendido (hoy)», «Con cuánto cerraremos hoy», «hoy»; `calcularRangoPeriodo('1d')` abre el día local en curso y compara contra **ayer a la misma hora** mediante el nuevo `RangoPeriodo.finPrevio` (el resto de los períodos conserva su tramo previo exacto); `tramosDelGrafico('1d')` usa las franjas de `FRANJAS_HORARIAS` reutilizando el `indiceFranja` que ya existía.
  - Proyección del cierre: `calcularProyeccionCierre` combina lo vendido hoy con la misma hora de los días anteriores del **mismo día de la semana**. Devuelve `ProyeccionCierre` con estado `'disponible' | 'historial-insuficiente' | 'sin-ventas-a-esta-hora' | 'sin-ventas-hoy'`; sin al menos `MINIMO_OCURRENCIAS_PROYECCION = 3` días anteriores con ventas **no proyecta** y explica por qué con `mensaje`. `EscenarioDashboard.proyeccion` es obligatorio.
  - `dashboard-datos.service.ts`: solo para `'1d'` descarga `DIAS_HISTORIAL_PROYECCION = 28` días de ventas; los demás períodos consultan exactamente lo mismo que antes.
  - Pantalla: botón «Hoy» primero en el selector; la tarjeta de cierre muestra «—» y el mensaje del modelo (nunca una cifra inventada) cuando la proyección no está disponible.
  - Asistente: `analisis_dashboard` acepta `periodo: "1d"` y devuelve `proyeccion`; el prompt prohíbe inventar el cierre y el respaldo local responde preguntas del día en curso usando el mismo cálculo.
- **Pruebas:** 1430 pruebas en 97 archivos (1427 aprobadas). Suite de dashboard completa: **251/251 en 7 archivos**. Nuevas: `dashboard.model.spec.ts` (10: rango del día, comparación con ayer a la misma hora, proyección con 3 jueves anteriores, historial insuficiente, día sin ventas, días previos sin ventas a esa hora, ocurrencias con día en $0, tope de factor 100, bordes de franja 12:59/13:00, tramos por franja), `dashboard.spec.ts` (3: botón que carga '1d', mensaje sin cifra inventada, cierre visible cuando está disponible), `herramientas-asistente.service.spec.ts` (acepta '1d' y entrega el estado de proyección; no entrega el KPI de cierre cuando no hay proyección), `asistente-dashboard.service.spec.ts` (recibe el estado de la proyección y no inventa el cierre; muestra el cierre calculado cuando está disponible) y `herramientas-asistente.model.spec.ts`.
- **Correcciones tras la revisión de código de Antigravity (09-11-2026):**
  1. El KPI `proyeccion-ia` ya no viaja en el resultado de `analisis_dashboard` cuando la proyección no está disponible: antes contenía `montoClp = ganancia` y el verificador de cifras podía aceptar esa cifra como un cierre calculado.
  2. Nuevo estado `'sin-ventas-hoy'`: con el día sin ventas no se proyecta `$0` como cierre; antes `factor × 0` mostraba «Cierre estimado: $0» y el respaldo local afirmaba un cierre de cero pesos.
  3. `finPrevio` y la ventana de 28 días se calculan con la fecha y hora local, no restando milisegundos: el cambio de hora oficial de Chile movía `finPrevio` una hora.
  4. El porcentaje del mensaje dice «menos del 1 %» en vez de «0 %» cuando la fracción es menor a 0,5 %.
  5. El encabezado de la tarjeta ya no dice «Falta historial» cuando el estado es `'sin-ventas-a-esta-hora'`, y el guion del cierre lleva `aria-label`.
  6. Los detectores del respaldo local (`DIA_EN_CURSO`, `TEMA_VENTAS_DIA`) se acotaron: ya no interceptan «en lo que va del mes», rankings por día ni preguntas de «punto de venta», y sí reconocen ingresos y cierre del día.
- **Fallos de la corrida completa (no atribuibles):** en las corridas del 09-11-2026 la suite completa quedó en **1427 aprobadas de 1430**: tres pruebas agotan el `testTimeout` de 5000 ms y **el trío cambia entre corridas** (`ingresos-factura`, `inventario` y `reportes` se turnan). Ninguno de esos archivos fue modificado en esta tarea, no tocan el Dashboard y **cada uno pasa aislado**: `ingresos-factura` 11/11, `inventario` 103/103, `reportes` 13/13. Es saturación al ejecutar las 97 suites en paralelo (el entorno acumula 704 s), no un fallo del período «Hoy». **Pendiente:** acreditar el 100% en una corrida descargada, o ajustar `testTimeout`/paralelismo como tarea aparte, previa autorización.
- **Verificado en la app (09-11-2026):** revisión manual de Patricio en el navegador; dio el visto bueno al funcionamiento de la pantalla. No se registraron capturas ni los anchos exactos revisados. **No verificado:** el comportamiento con datos reales de varias semanas, porque hoy solo hay datos de prueba.



## Promociones en varias sucursales y en las tarjetas del POS (H5.2) — 08-11-2026

- **Cambio:** checklist de sucursales en el formulario (vacío = todas), promociones en la tarjeta de cada producto del POS con botón que agrega el combo completo, y filtro «En promoción».
- **Pantalla:** 11 pruebas nuevas en `promociones.spec.ts` (3), `promocion.spec.ts` (1), `promociones-api.service.spec.ts` (1), `pos-layout.component.spec.ts` (5) y `pos.service.spec.ts` (1). 1399/1399 OK, build limpio.
- **Base (pendiente de ejecutar):** `20261108_promociones_sucursales.sql` y su prueba `promociones_sucursales.sql` (6). Las pruebas SQL de H5.2 se actualizaron al modelo nuevo (`promocion_sucursales`) y hay que volver a correrlas.

## Promociones: creación, programación, POS, inventario y reportes (H5.2 T01 a T09) — 05-11-2026

- **Pantalla:** 979/979 OK. Pruebas de H5.2 en `promociones-api.service.spec.ts` (2), `gestion-negocio/models/promocion.spec.ts` (9), `gestion-negocio/pages/promociones/promociones.spec.ts` (9), `pos/models/promocion-pos.spec.ts` (6), `reportes/models/reporte-promociones.model.spec.ts` (6), `reportes/components/reporte-promociones/reporte-promociones.spec.ts` (7), y casos nuevos en `auth.guard.spec.ts` (3), `pos.service.spec.ts` (7), `pos-layout.component.spec.ts` (4), `reportes-api.service.spec.ts` (2) y `reportes.spec.ts` (1).
- **Zona horaria:** las pruebas de promociones también se ejecutaron con el proceso en `TZ=UTC`, `Asia/Tokyo` y `America/Santiago`: 34/34 en cada una.
- **Base (en `nury_pruebas`, 06-11-2026):** OK `promociones.sql` (9), `promociones_vigentes.sql` (9), `promociones_venta.sql` (9), `promociones_inventario.sql` (7), `promociones_margen.sql` (8), `reporte_promociones.sql` (7). Pendientes de correr como `postgres` (el usuario `dev_maher` no puede cambiarse a `nury_cajero`): `promociones_permisos.sql` (6), `guardar_promocion.sql` (7).
- **Detalle por criterio de aceptación y observaciones abiertas:** `docs/qa/h5-2-promociones.md`.

## Desglose de ventas por día de la semana en Dashboard y Asistente (H4.5) — 08-11-2026

- **Cambio:** Se implementa `construirDemandaDiaSemana` en `dashboard.model.ts` para desglosar el volumen y monto total vendido por día de la semana (Lunes a Domingo), calculando `cantidadVentas`, `montoTotalClp`, `promedioVentaDiariaClp` y marcando `esDiaMayorVenta: true` en el día con mayor afluencia. Se expone como `ventas_por_dia_semana` en la herramienta `analisis_dashboard` (`herramientas-asistente.service.ts`), se añaden sus etiquetas legibles y descripción en `herramientas-asistente.model.ts`, se instruye al prompt del asistente a consultar y destacar el día de mayor venta y se incorpora detección y respuesta de días de la semana en el respaldo local de `asistente-dashboard.service.ts`.
- **Pruebas:** `dashboard.model.spec.ts` (prueba de cálculo y desglose de 7 días con día de mayor venta) y `asistente-dashboard.service.spec.ts` (prueba de respuesta de respaldo local para el día de mayor volumen). 230/230 pruebas en dashboard; 1330/1330 pruebas aprobadas en 90 suites totales. Build limpio con 0 errores y 0 advertencias.

## Demanda intermitente en depurarSerieConsumo: Propuesta B (H4.5 T04) — 08-11-2026

- **Cambio:** En `depurarSerieConsumo` (`src/app/features/inventario/models/analisis-historico.model.ts`), cuando más de la mitad de los días son cero (`diasCero > muestraReferencia.length / 2`), el corte estadístico de picos (`Math.max(q3 + 1.5 * iqr, mediana * 1.8)`) se calcula solo sobre los días con venta cuando hay al menos 4 días con venta (`diasConVenta.length >= 4`), y la atenuación reemplaza el pico por la mediana de esos días con venta. Cuando hay menos de 4 días con venta en una serie mayormente en cero, no se aplica corte estadístico automático.
- **Pruebas:** `analisis-historico.model.spec.ts` (14/14 pruebas aprobadas, incluyendo los 3 escenarios de días mayormente en cero: menos de 4 días con venta, 4 o más días con venta de magnitud similar, y pico aislado con 4 o más días con venta). Suite total: 1328/1328 pruebas aprobadas en 90 suites. Build limpio con 0 errores y 0 advertencias.

## Soporte, confianza y lift en lenguaje del cliente (H4.5) — 07-11-2026

- **Cambio:** En la pantalla del Dashboard (`dashboard.html`), se reemplazan métricas técnicas por frases simples para el cliente: `aparicionTexto` ("X de cada Y boletas") y porcentaje de soporte, y para el lift se muestran frases naturales ("el doble de lo esperable", "el triple de lo esperable" o "tan seguido como lo esperable" cuando es menor a 1.2). Se añade `aparicionTexto` a `CompraConjuntaFrecuente` en `dashboard.model.ts` y se refuerza la instrucción en el prompt del asistente (`asistente-dashboard.service.ts`).
- **Pruebas:** `dashboard.model.spec.ts` y `dashboard.spec.ts` (1 prueba nueva de afinidad simple según lift). 228/228 pruebas en dashboard; 1300/1300 pruebas aprobadas en 87 suites. Build limpio con 0 errores y 0 advertencias.

## Algoritmos calculan e IA interpreta (H4.5 T04, T06, T07 y T11) — 05-11-2026

- **Cambio:** chat con herramientas deterministas y verificador de cifras y nombres; panel con cálculo propio e IA solo para el texto; serie de días operativos con IQR y regla sigma; soporte, confianza y lift; cierre por días operativos; cadena de 4 modelos; auditoría en el chat; conversación persistente con "Nueva conversación".
- **Pruebas nuevas:** `verificador-cifras.spec.ts`, `herramientas-asistente.model.spec.ts` y `herramientas-asistente.service.spec.ts`. Se ampliaron o reescribieron los specs de asistente, consultas, validador, contrato, predicción, modelo histórico, modelo de predicción, dashboard, orquestador, adaptadores y API de stock.
- **Bug corregido:** un artículo con stock negativo y consumo base 0 salía como "Stock suficiente". Ahora sugiere comprar. El stock negativo está permitido por diseño y no es un error.
- **Verificación manual en la app con sesión admin:**
  - 20 de 20 preguntas respondidas por IA, sin respaldo local, comparando cifras contra la API.
  - Gemma y Nemotron forzados como primer modelo mediante bloqueo temporal en la pestaña.
  - Panel con 4 artículos simulados a 30 días, solo en memoria: cifras idénticas con IA y desde caché.
  - Conversación conservada al ir a `/inventario` y volver, incluida una respuesta en curso. "Nueva conversación" la limpia.
- **Test inestable de `ingresos-factura`:** 0 fallos en 28 corridas: 10 del archivo solo, 10 de la suite, 3 con 2 builds en paralelo y 5 con los 12 núcleos saturados (de 24 a 44 s). No se reprodujo ni se modificó. El fallo original pudo deberse a la carga del momento, sin confirmar.
- **Caída al respaldo:** no se reprodujo en las tandas posteriores a las correcciones. Causa original sin confirmar; ahora el motivo queda visible en el mensaje y en la consola.
- **No verificado:** borrado del chat al cerrar sesión en la app real (cubierto por prueba unitaria, para no cerrar la sesión del usuario), cuentas de bodeguero y cajero, y la corrección de stock negativo en la app (cubierta por prueba unitaria).

## Asistente con lectura de toda la base y alerta real de inventario (H4.5 T09 y T11) — 05-11-2026

- **Cambio en el asistente:** el modelo pide lecturas en JSON, la app las ejecuta con la sesión del usuario y le devuelve las filas, hasta 3 rondas de consultas. Ya no depende del período ni de la sucursal en pantalla, y recuerda los últimos 6 mensajes.
- **Seguridad:** solo GET, que PostgREST ejecuta en una transacción de solo lectura. Quedan bloqueados `auditoria_usuarios`, `ventas_idempotencia`, contraseñas, usuario de acceso, XML original, hashes y claves de idempotencia.
- **Cambio en inventario:** la alerta de compra cuenta los artículos reales de `v_consumo_diario_articulos`, y solo se consulta para admin.
- **Pruebas nuevas:** `consultas-asistente.service.spec.ts` (17 intentos de saltarse el filtro, solo GET, límite de filas, resultados recortados, errores y reintento del esquema); rondas, historial y salida del modelo en `asistente-dashboard.service.spec.ts`; alerta real y por rol en `inventario.spec.ts`.
- **Incidencia:** una ejecución falló por tiempo de espera en `ingresos-factura.spec.ts` (5 s), archivo sin cambios en esta tarea. La repetición completa pasó 986/986. Se trata como test sensible a la carga del equipo, sin confirmar.
- **Verificación manual en la app con sesión admin (`localhost:4200`):**
  - Margen de CHAPARRITA: $720 y 24%, coincide con $3.000 × 0,81 − $1.710.
  - Octubre en toda la red: $581.930 y 37 ventas, coincide con el reporte oficial descontando la venta de noviembre.
  - Seguimiento "¿y qué cajero vendió más en ese mismo mes?": Nelson, $453.020, coincide con `fn_reporte_cajeros`.
  - Stock de BOT COCA COLA NORMAL 591ML: -3 y mínimo 0, coincide con la API.
  - Proveedor con más facturas: indicó correctamente que las 4 facturas no tienen `proveedor_id`.
  - Contraseña de un usuario: se negó, y el filtro la bloquea.
  - Rotación real de Gemini (`503`) a OpenRouter dentro de la app: funcionó.
  - `/inventario`: sin alerta falsa; ningún artículo llega a 28 días.
- **Incidencia no resuelta:** de 7 preguntas, la primera cayó al respaldo local tras una respuesta `200` de OpenRouter. No quedó capturado el contenido de esa respuesta, así que la causa no está confirmada.
- **No verificado:** cuentas de otros roles sobre este flujo y alerta con artículos reales de 28 días o más.

## Períodos, facturas por emisor y fechas en el chat (H4.5) — 06-11-2026

- **Cambio:** el código calcula qué períodos especiales tienen registros. Nueva herramienta `facturas_ingresadas`, con emisor y suma de montos. El verificador reconoce listas y rangos de fechas ("18 y 19 de septiembre"). "Venta neta" o "ingreso neto" se rechaza. El pie indica qué datos se consultaron.
- **Pruebas:** `verificador-cifras.spec.ts`, `herramientas-asistente.model.spec.ts`, `herramientas-asistente.service.spec.ts`, `asistente-dashboard.service.spec.ts`, `consultas-asistente.service.spec.ts` y `dashboard.spec.ts`.
- **Resultado:** 1299/1299 en 87 suites; build sin errores ni advertencias.
- **Verificación con la IA real, sesión admin:** Fiestas Patrias 3 de 3 con datos y sin rechazos; ventas del 18 y 19 de septiembre ($573.160, 68 ventas) y de octubre ($8.476.620, 980 ventas, 39 anuladas) iguales a la tabla `ventas`. Facturas por emisor sin atribuciones cruzadas, 5 de 5. Compras de octubre: $233.121 a PROVEEDOR DE PRUEBA SPA, 3 de 3, y $265.608 en total, 1 de 1. "¿Hay facturas de Soprole?": no hay.
- **No comprobado con la IA real:** el rechazo de "ingreso neto" no se activó en 3 pasadas preguntando por él, porque la IA no usó esa expresión; solo lo cubren pruebas unitarias.
- **Encontrado sin corregir:** en vacaciones, 1 de 5 afirmó que la demanda disminuye. En Fiestas Patrias, 1 de 3 dijo "en esos días" con un ranking del 5 al 20 de septiembre.

## Búsquedas, respuestas sin datos y respuestas no comprobables en el chat (H4.5) — 06-11-2026

- **Cambio:** las búsquedas de texto toleran guiones, espacios y acentos (`imatch`). El pie avisa si la IA respondió sin consultar datos. El prompt recibe la fecha de la primera venta y reglas para períodos con y sin registros. Si la respuesta de la IA no se puede comprobar, el chat lo dice y ya no habla de un fallo de conexión.
- **Pruebas:** `consultas-asistente.service.spec.ts` (`busquedaTolerante`, `primeraVenta`), `asistente-dashboard.service.spec.ts` (fecha en el prompt y origen `sin-verificar`) y `dashboard.spec.ts` (los 4 pies).
- **Resultado:** 1254/1254 en 86 suites; build sin errores ni advertencias.
- **Verificación con la IA real, sesión admin:** 51 preguntas en 3 rondas, con ajustes del prompt entre ellas. Coca Cola: 4 activos y el inactivo, en 4 de 4. "azucar" encuentra `Azúcar`, 2 de 2. Forzado 2 veces: mensaje nuevo. Caída simulada: respaldo local. Cifras comparadas con la API: ventas de Fiestas Patrias ($832.260, 105 ventas), efectivo, anuladas, facturas de octubre, septiembre, proveedores y cajero.
- **Encontrado sin corregir:** una respuesta atribuyó a un proveedor una factura de otro, y otra llamó "ingreso neto" a un monto con IVA.

## Verificación de nombres en el chat y el panel (H4.5) — 06-11-2026

- **Cambio:** las justificaciones del panel que traen nombres que no vienen de los datos del artículo se descartan y queda el texto del algoritmo. El prompt del chat prohíbe afirmar datos sin haberlos consultado y concluir cierres o caídas de un período sin registros.
- **Pruebas:** `validador-prediccion-ia.spec.ts`: descarta un nombre inventado y acepta los del artículo.
- **Resultado:** 1232/1232 en 86 suites; build sin errores ni advertencias.
- **Forzado con la IA real, sesión admin:** "Rodrigo Valenzuela" en medio de la oración se rechazó y no llegó al usuario. "Rodrigo" como primera palabra sí pasó: es un límite conocido.
- **Rechazos falsos:** 27 respuestas con preguntas variadas (Navidad, Excel, Transbank, SII, Coca Cola y otras), una pasada en 16 y repeticiones en el resto: ninguna palabra legítima rechazada por nombre. Se rechazaron 2 respuestas por cifras; una se corrigió y la otra terminó en "La IA no pudo comentar estos datos".
- **Panel con 30 artículos ficticios y la IA real, una pasada:** 30 de 30 interpretados, sin descartes.

## Chat conservado al recargar (H4.5) — 06-11-2026

- **Cambio:** la conversación se guarda en `sessionStorage`, atada a la sesión iniciada. Se borra al cerrar la pestaña, con "Nueva conversación", al cerrar sesión y al cambiar de usuario. Si la pestaña se recarga antes de la respuesta, el chat avisa que hay que volver a preguntar.
- **Pruebas:** `asistente-dashboard.service.spec.ts`: conserva la conversación con sus datos calculados, aviso si no llegó la respuesta, borrado con "Nueva conversación" y al cerrar sesión, otra sesión del mismo usuario y datos guardados dañados.
- **Resultado:** 1231/1231 en 86 suites; build sin errores ni advertencias.
- **Verificación en la app, sesión admin:** tras recargar siguen los mensajes y los desplegables recogidos; una pregunta de seguimiento ("¿Y cuánto vendió el segundo?") respondió bien, $453.020, igual que la API; recargar con una pregunta en curso muestra el aviso; "Nueva conversación" borra lo guardado. Cerrar sesión y cambiar de usuario quedan cubiertos solo por pruebas unitarias.

## Nombres ocultos para la IA en el chat (H4.5) — 05-11-2026

- **Cambio:** antes de enviar cada mensaje, el chat cambia los nombres de personas, proveedores y razones sociales por `PERSONA_3` o `PROVEEDOR_5`, y los repone en la respuesta y en lo que pide la IA a las herramientas. Si no puede leer la lista de nombres, no consulta a la IA y usa el respaldo local.
- **Pruebas:** `seudonimos-asistente.spec.ts` (nuevo: mayúsculas, acentos, nombres parecidos, nombre de pila único o repetido, cuentas de un cargo, comillas y seudónimos inexistentes), `consultas-asistente.service.spec.ts` (`nombresReales`) y `asistente-dashboard.service.spec.ts` (lo enviado, lo mostrado, los parámetros de las herramientas y la lectura fallida).
- **Resultado:** 1225/1225 en 86 suites; build sin errores ni advertencias.
- **Verificación con la IA real, sesión admin, una pasada:** 8 preguntas sobre cajeros, anulaciones, auditoría, proveedores y facturas, con 18 envíos a la IA. Ninguno de los 79 nombres revisados salió. Las 8 las respondió la IA, con una mediana de 5 s y un máximo de 8 s. Las cifras de cajeros y anulaciones y los cambios de rol coincidieron con la API.

## RUT y datos de contacto bloqueados en el chat (H4.5) — 05-11-2026

- **Cambio:** el chat ya no puede leer RUT, correos, teléfonos, direcciones de facturas ni el nombre del archivo XML, ni pedirlos, filtrarlos u ordenarlos. También se quitan de lo que devuelven los reportes, en cualquier nivel. Sigue leyendo el nombre del proveedor, la razón social y la dirección de las sucursales.
- **Pruebas:** `consultas-asistente.service.spec.ts`: 9 formas de pedirlos, lo que sigue permitido y la limpieza de un reporte con datos anidados.
- **Resultado:** 1210/1210 en 85 suites; build sin errores ni advertencias.
- **Verificación con la IA real, sesión admin, una pasada:** 9 preguntas, 2 de ellas repetidas tras corregir el prompt. Se revisó lo enviado a la IA contra los 78 valores reales de la base: ninguno salió, ni en lo enviado ni en las respuestas. Sigue respondiendo bien: 71 proveedores; 4 facturas de octubre por $265.608, igual que la API.

## Tanda de 20 preguntas y ajustes del chat y el panel (H4.5) — 05-11-2026

- **Cambio:** el chat ya no muestra el modelo ni motivos técnicos; las anulaciones sin responsable tienen nombre propio en el algoritmo; las fechas de la base llegan en hora de Chile; el panel marca por fila lo que interpretó la IA y registra en consola los textos descartados.
- **Pruebas:** `herramientas-asistente.model.spec.ts` (`fechasEnHoraChile`), `herramientas-asistente.service.spec.ts` (anulaciones, fechas y usuario no disponible), `asistente-dashboard.service.spec.ts` (motivos solo en consola), `prediccion-stock.service.spec.ts` (marca por artículo y descartes) y `panel-predictivo.spec.ts` (marca en la fila).
- **Resultado:** 1199/1199 en 85 suites; build sin errores ni advertencias.
- **Tanda con la IA real, sesión admin, una pasada:** 20 preguntas de ventas, medios de pago, anulaciones, productos, cajeros, margen, stock, receta, proveedores, facturas y auditoría.
  - Las 20 las respondió la IA, con una mediana de 5 s y un máximo de 11 s.
  - Todas las cifras coincidieron con lo leído directamente de la API (`ventas`, `detalle_venta`, `productos`, `v_costo_producto` y otras) y calculado aparte.
  - 3 respuestas describían mal un dato: "ventas netas" para un monto con IVA, "costos de la receta" para un producto sin receta y una fecha adelantada un día por la hora UTC. Se corrigieron y se volvieron a preguntar, sin repetirse.
- **Panel con 30 artículos ficticios y la IA real, 2 pasadas:** 5,1 s y 4,0 s; 30 de 30 interpretados, sin descartes.

## Datos calculados en el chat (H4.5) — 05-11-2026

- **Cambio:** cada respuesta del chat trae un desplegable "Datos calculados por el sistema", recogido por defecto, armado por el algoritmo con sus etiquetas. `ventas_periodo` usa nombres inequívocos y entrega cantidad y monto por medio de pago. El prompt pide lenguaje simple, no deducir lo que no viene y explicar las anulaciones sin responsable.
- **Pruebas:** `herramientas-asistente.model.spec.ts` (`construirBloquesDatos`, `contarPorMedioPago` y la cantidad por medio de pago solo si cuadra con el reporte), `herramientas-asistente.service.spec.ts` (lectura por medio de pago y totales aunque falle) y `asistente-dashboard.service.spec.ts` (datos calculados en la respuesta y si cae la IA).
- **Resultado:** 1193/1193 en 85 suites; build sin errores ni advertencias.
- **Verificación con la IA real, sesión admin:** 8 preguntas distintas: efectivo y débito de octubre, productos juntos del mes y del trimestre, quién anuló más, margen de CHAPARRITA, compras urgentes con duración y cómo cargar una factura. No se repitió la tanda de 20 preguntas contra la API.

## Duración del stock en días enteros (H4.5) — 05-11-2026

- **Cambio:** la duración se muestra en días enteros hacia abajo, con "menos de 1 día" bajo uno. La IA del panel y el chat también reciben días enteros; los umbrales siguen usando el valor exacto.
- **Pruebas:** `prediccion.model.spec.ts` (texto y redondeo), `prediccion-stock.service.spec.ts` (lo que recibe la IA) y `herramientas-asistente.service.spec.ts` (lo que recibe el chat).
- **Resultado:** 1185/1185 en 85 suites; build sin errores ni advertencias.
- **Verificación en la app:** en la primera página del panel, ninguna duración con decimales. No se probó una pregunta real en el chat.

## Rediseño del Dashboard Ejecutivo (H4.5) — 05-11-2026

- **Cambio:** tarjeta de proyección de cierre con barra de avance y aporte por tramo, en reemplazo del gráfico de líneas; pestañas Ventas, Productos y Compras; filas con "Ver detalle"; panel de compras con todos los artículos por páginas, cargado solo al abrir su pestaña; textos de interpretación del algoritmo reescritos; textos de productos comprados juntos sin términos técnicos.
- **Pruebas nuevas:** `dashboard.model.spec.ts` (`construirVistaProyeccion`: reparto por tramo, pérdidas y período vacío), `dashboard.spec.ts` (pestañas, carga diferida de compras, aviso de la pestaña, cambio de métrica, variación negativa en rojo y texto sin términos técnicos) y `panel-predictivo.spec.ts` (paginación, orden por urgencia, vuelta a la primera página al filtrar y textos sin cifras sin formato ni compras de cero).
- **Pruebas actualizadas:** `dashboard.spec.ts`, por 2 KPI en vez de 3 y el asistente abierto desde el botón flotante.
- **Pruebas de la IA del panel:** `prediccion-stock.service.spec.ts` (a la IA solo van los artículos de compra hoy o pronto, con los de hoy primero; sin ninguno no se llama a la IA; máximo de 30) y `prediccion-ia.contract.spec.ts` (el prompt pide lenguaje simple).
- **Resultado:** 1183/1183 en 85 suites; build sin errores ni advertencias.
- **Verificación con la IA real:** con 2 artículos urgentes de 362, respondió `gemini-3.5-flash-lite` al primer intento en menos de 2 s. El aviso dice solo "Interpretado por IA". No se probó con 30 artículos.
- **Verificación manual en la app con sesión admin, a 1440 px y 375 px:**
  - Altura de la página a 1440 px: de 5.162 px a menos de 1.000 px en Ventas y Productos, y 1.461 px en Compras con 5 artículos.
  - A 375 px, el panel de compras bajó de 11.322 px a páginas de 10 artículos.
  - Con 362 artículos, la pestaña Compras muestra la página 1 de 37, con lo que hay que comprar primero, y avanza de página.
  - La pestaña Compras muestra el aviso y lista artículos bajo el mínimo, incluido stock negativo.
  - Trimestre: $583.930 vendidos, $141.248 de ganancia y $359.954 de cierre; iguales a los mostrados antes del rediseño.
  - Sin desborde horizontal a 375 px, sin errores de consola, y el asistente abre y cierra.
  - `/inventario`: conserva filtros y los 25 artículos.
- **No verificado:** períodos con combos de `lift` alto (el texto "veces más" solo se comprobó en código) y cuentas de otros roles.

## Dashboard Ejecutivo y asistente con datos reales (H4.5 T11) — 05-11-2026

- **Cambio:** `/dashboard` y el contexto del chat dejan los escenarios de ejemplo y usan ventas, detalle, costos, stock, catálogo y sucursales desde PostgREST, sin SQL nuevo. Las preguntas rápidas ahora consultan al asistente. El panel predictivo ya no cae en artículos de ejemplo.
- **Pruebas nuevas:** `dashboard.model.spec.ts` (rango del período, IVA, descuentos, costos, variación, serie, franjas, combos, destacados y madurez) y 2 casos en `ventas-api.service.spec.ts`.
- **Pruebas actualizadas:** `dashboard.spec.ts` (datos simulados por servicio, error de API sin cifras de ejemplo), `asistente-dashboard.service.spec.ts`, `panel-predictivo.spec.ts` y `prediccion-stock.service.spec.ts`.
- **Verificación manual en la app con sesión admin (`localhost:4200`):**
  - Noviembre: $2.000 y 1 venta. Trimestre: $583.930 y 38 ventas. Ambos coinciden con `fn_reporte_ventas_sucursal` para la sucursal 1, la única con ventas en `v_ventas_por_sucursal`.
  - Selector con las 9 sucursales reales.
  - Pregunta rápida "¿Qué es lo que más se vende?": Gemini respondió con los productos y montos reales del período.
- **No verificado:** rendimiento con miles de ventas, y el aviso de error contra una caída real de la API (cubierto solo por prueba unitaria).

## Conexión real de la IA por el proxy Caddy (H4.5 T06, T07 y T11) — 05-11-2026

- **Configuración:** `app.config.ts` entrega `PROVEEDORES_IA_NURY`; solo quedan Gemini (`gemini-flash-lite-latest`, 25 s) y OpenRouter (`nvidia/nemotron-3.5-super-vl:free`, 60 s). Groq se eliminó del código y de los datos de prueba.
- **Pruebas nuevas (2):** `adaptadores-proveedor-ia.spec.ts` verifica que `formatoRespuesta: 'texto'` no fuerza JSON en Gemini ni en formato OpenAI.
- **Pruebas ampliadas:** `asistente-dashboard.service.spec.ts` verifica que el chat pide texto y marca `origen` (`ia` o `respaldo-local`) y `modeloIa`.
- **Verificación manual en la app con sesión admin (`localhost:4200`):**
  - Chat del dashboard: respuesta real de Gemini en 1,3 s, con la marca "Generada por IA".
  - Panel predictivo: respuesta real de Gemini validada y mostrada. Se simularon 30 días de historial en 5 artículos solo en la memoria del navegador, porque ningún artículo real llega a 28 días.
  - Proxy: `GET` 405, `POST` sin sesión o con token falso 401 y `OPTIONS` 204, con un solo `Access-Control-Allow-Origin`.
  - Nemotron: JSON válido en 32 s con el prompt real, probado directo por el proxy.
- **No verificado:** rotación a OpenRouter dentro de la app, panel con artículos reales de 28 días o más, y acceso con cuentas de bodeguero o cajero.

## Vista de Consumo Promedio Diario por Sucursal en PostgreSQL (H4.5 T02) — 05-11-2026

- **H4.5 T02, construcción y verificación de `v_consumo_diario_articulos`:**
  - Migración `database/migrations/20261105_consumo_diario_articulos.sql` aplicada con éxito y confirmada en producción sobre PostgreSQL 17 en el VPS (`nury-postgres`).
  - Cálculo de consumo: consulta agregada sobre las últimas 4 semanas (28 días) de `movimientos_stock`, computando ventas netas de anulaciones (`tipo_movimiento IN ('venta', 'anulacion_venta')`) y salidas por merma (`tipo_movimiento = 'merma'`).
  - Antigüedad del historial (`dias_con_historial`): cálculo exacto de días transcurridos desde el primer movimiento registrado (`CURRENT_DATE - min(creado_en)::date`). Permite al frontend marcar inequívocamente artículos con «Datos insuficientes para sugerir» cuando su antigüedad es menor a 28 días.
  - Regla de negocio de compras Just-in-Time: se descartó la adición de columnas de tiempo de reposición/días de entrega en `ingredientes`, respetando la operación real del local sin espacio masivo de acopio.
  - Exposición en PostgREST y seguridad: permisos revocados a `PUBLIC` y concedidos a `nury_admin` y `nury_bodeguero`. Verificado con `curl` sobre `127.0.0.1:3000/v_consumo_diario_articulos` respondiendo `401 Unauthorized (permission denied)` ante solicitudes no autenticadas, y consulta de privilegios confirmando `admin_puede_leer = t`, `bodeguero_puede_leer = t`, `cajero_rechazado = f`.
  - Respaldo de seguridad previo generado en `/opt/nurybase/backups/nury-backup-20261105-023526.dump` (361 KB).
  - Archivos versionados en repositorio: migración definitiva, script de ensayo (`.ENSAYO.sql`) y suite de pruebas (`database/tests/consumo_diario_articulos.sql`).

## Prompt del Sistema, Contrato JSON y Orquestador Multimodelo con Rotación Automática (H4.5 T05 y H4.5 T06) — 04-11-2026

- **H4.5 T05, diseño del prompt del sistema, estructura de entrada y contrato JSON de salida esperada:**
  - Nuevo contrato `src/app/features/inventario/models/prediccion-ia.contract.ts`:
    - `EntradaPrediccionIA`: estructura tipada con `fechaReferencia` (hora local Chile `YYYY-MM-DD`), reglas de umbrales operacionales (`umbralDiasHistorial: 28`, `umbralComprarHoyDias: 1.5`, `umbralProximoPedidoDias: 4`, `diasObjetivoCompra: 1`) y `articulos` (payload de T04 depurado y libre de datos personales sensibles).
    - `PrediccionArticuloIA` y `SalidaPrediccionIA`: contrato tipado de respuesta estricta con `articuloId`, `estado`, `tasaDiariaEstimada`, `diasHastaMinimo`, `fechaRecomendadaPedido`, `cantidadSugerida` y `justificacion`.
    - `ESQUEMA_SALIDA_PREDICCION_IA`: esquema JSON draft-07 estricto con los 7 campos obligatorios, enum de 4 estados (`comprar-hoy`, `proximo-pedido`, `estable`, `datos-insuficientes`), y justificación delimitada a 200 caracteres.
    - `PROMPT_SISTEMA_PREDICCION_IA`: instrucciones rigurosas de negocio para el modelo:
      1. Verificación obligatoria de al menos 4 semanas (28 días) de historial o `aptoParaPredecir: false` -> clasificar como `datos-insuficientes` con valores numéricos `null`, `cantidadSugerida: 0` y la frase exacta literal `"datos insuficientes para predecir"`.
      2. Tasa base limpia (`promedioDiarioBase`): picos aislados no inflan la tasa salvo repetición acreditada en >= 3 semanas distintas.
      3. Cobertura: `diasHastaMinimo = (stockActual - stockMinimo) / tasaDiariaEstimada` (0 si ya está bajo el mínimo; redondeo a 1 decimal). Umbrales de alerta: <= 1.5 días -> `comprar-hoy`; <= 4 días -> `proximo-pedido`; mayor -> `estable`.
      4. Cantidad sugerida: `stockMinimo + (tasa * diasObjetivoCompra) - stockActual` (redondeo al entero superior en productos, 1 decimal en materias primas).
      5. Prohibición estricta: NO computar tiempos ni plazos de entrega de proveedores, días fijos de reparto, clima ni eventos futuros no documentados.
      6. Formato de salida: JSON puro sin markdown ni preámbulos, exactamente una predicción por cada artículo recibido preservando `articuloId`.
    - Funciones constructoras `construirEntradaPrediccionIA()` y `construirMensajesPrediccionIA()`.
  - Cobertura: `prediccion-ia.contract.spec.ts` (17 pruebas unitarias con esquema integrado y copias profundas).
- **H4.5 T06, cliente de API de IA multimodelo con rotación automática (failover) y enfriamiento en memoria:**
  - Configuración e inyección (`src/app/core/ia/proveedores-ia.config.ts`):
    - Tipos `FormatoProveedorIA` (`'gemini'` | `'openai-compatible'`) y `AutenticacionProveedorIA` (`'sesion-nury'` | `'api-key'`).
    - Cadena de proveedores `PROVEEDORES_IA_NURY` apuntando a las rutas del proxy inverso Caddy en api.nury.cl (`/ia/gemini`, `/ia/openrouter`), sin exponer ninguna clave de API en el código cliente.
    - Tokens de inyección `IA_PROVEEDORES` (vacío por defecto hasta habilitación en VPS) e `IA_RELOJ` (para control temporal determinista en pruebas).
  - Adaptadores de petición y respuesta (`src/app/core/ia/adaptadores-proveedor-ia.ts`):
    - `prepararPeticionIA()`: genera URL, cabeceras y cuerpo específico para Gemini (`systemInstruction`, `contents`, `generationConfig.responseMimeType: 'application/json'`, `temperature: 0`) o modelos OpenAI compatibles (`messages`, `response_format: { type: 'json_object' }`, `temperature: 0`).
    - **Aislamiento crítico de seguridad del JWT:** si un proveedor declara `'sesion-nury'`, se valida de forma mandatoria que `baseUrl` comience con `environment.apiUrl` (`https://api.nury.cl`). Si la URL es externa, se bloquea y rechaza inmediatamente. Nunca se envía el JWT a endpoints de terceros. Con `'api-key'` se adjunta la clave propia (mediante `x-goog-api-key` en cabecera para Gemini o `Authorization: Bearer <key>` para OpenAI) sin incluir claves en parámetros URL.
    - `extraerTextoRespuestaIA()`: parsea y valida el contenido de texto generado en `candidates[0].content.parts[0].text` o `choices[0].message.content`, lanzando excepción si viene vacío o trunco para activar el failover.
  - Orquestador de failover y enfriamiento (`src/app/core/ia/orquestador-ia.service.ts`):
    - Instanciación de `HttpClient` directamente sobre `HttpBackend` (`new HttpClient(inject(HttpBackend))`), omitiendo `authInterceptor` para garantizar hermetismo absoluto de credenciales.
    - Verificación preventiva de conectividad: si `ConexionService.enLinea()` es falso, aborta al instante con `SinProveedoresIAError('sin-conexion')` sin despachar peticiones de red.
    - Rotación transparente: recorre la lista priorizada de proveedores disponibles. Ante fallos de proveedor (HTTP 429, 5xx, timeout, error de red), calcula el tiempo de enfriamiento, lo almacena en un mapa de memoria (`Map<string, number>`) y salta inmediatamente al siguiente proveedor de la cadena sin interrumpir al usuario.
    - Las solicitudes subsiguientes saltan en memoria los proveedores en enfriamiento y van directamente a los activos. Una vez vencido el enfriamiento, el proveedor se reintegra a la rotación.
    - Tiempos de enfriamiento aplicados:
      - HTTP 429 con `Retry-After`: tiempo especificado en cabecera (segundos o fecha HTTP).
      - HTTP 429 sin cabecera: 60 segundos.
      - HTTP 500 / 502 / 503 / 504 / timeout / status 0 / 200 sin texto: 30 segundos.
      - HTTP 401 / 403 (clave errónea o no admin) o 404 (ruta Caddy no creada): 1 hora.
      - HTTP 400 u otro 4xx: 0 segundos (error de solicitud, no del proveedor).
    - Métodos auxiliares `estadoProveedores()` para telemetría y `limpiarEnfriamientos()` para reinicio manual o pruebas.
  - Cobertura: `adaptadores-proveedor-ia.spec.ts` (15 pruebas unitarias con remocion de markdown fences) y `orquestador-ia.service.spec.ts` (18 pruebas unitarias con rango 5xx y TimeoutError). Total 33 pruebas en el modulo de infraestructura de IA (50 pruebas totales en el subsistema de IA).

## Filtro de Picos (Outliers), Refinamiento de Filtros y Permisos Exclusivos Admin en Inventario (H4.5 T04, H4.5 T08 y H4.5 T09) — 04-11-2026

- **H4.5 T04, depuración de picos históricos y estructuración de payload para IA:**
  - Nuevo modelo `src/app/features/inventario/models/analisis-historico.model.ts`: detección híbrida de picos por etiquetas explícitas (`esPromocion`, `esEventoEspecial`) y anomalías estadísticas combinando rango intercuartílico (Tukey IQR) y desviaciones estándar ($2\sigma$).
  - Estrategias de tratamiento `'atenuar'` (reemplazo por promedio base limpio) y `'excluir'` (omisión del día atípico), junto a `construirPayloadHistoricoIA()` para generar el contrato JSON compacto y limpio.
  - Cobertura: nueva suite `analisis-historico.model.spec.ts` (6 pruebas unitarias).
- **H4.5 T08, sincronización reactiva de sucursal y filtro por tipo de artículo en Panel Predictivo:**
  - En `panel-predictivo.ts` y `panel-predictivo.html`: `effect()` reactivo para sincronizar automáticamente `filtroSucursal` cuando cambia el selector de sucursal en la cabecera del Dashboard (`sucursalInicial`), e incorporación del filtro por **Tipo de artículo** (`Todos los tipos`, `Ingredientes`, `Productos`).
  - Cobertura: `panel-predictivo.spec.ts` (+2 pruebas unitarias, total 5) y `prediccion.model.spec.ts` (actualizada con filtrado por tipo).
- **H4.5 T09, restricción exclusiva de «Sugerencias de compra» al rol Administrador y alerta en Inventario:**
  - En `inventario.ts` e `inventario.html`: la pestaña `#tab-predicciones` (*«Sugerencias de compra»*) y el panel `<app-panel-predictivo>` ahora solo se renderizan cuando `esAdmin()` es verdadero (`rol === 'admin'`). Los roles `bodeguero` y `cajero` no tienen acceso a la pestaña y cualquier navegación directa a `?vista=predicciones` se redirige y limpia hacia `existencias` (o `almuerzos` para cajero).
  - Banner asistivo `.predictive-banner-alert` en la vista de Existencias para el administrador cuando existen artículos en estado `comprar-hoy`, con acción directa *«Ver sugerencias»*.
  - Cobertura: `inventario.spec.ts` (+3 pruebas unitarias verificando ocultamiento para bodeguero, redirección de URL y visibilidad/navegación del banner para admin; total 97 pruebas en `inventario.spec.ts`).

## Dashboard Ejecutivo (`/dashboard`), Asistente en Drawer Lateral y Sugerencias de Compra Diarias (H4.5 T01 y H4.5 T03) — 03-11-2026

- **H4.5 T01, diseño y maquetación del panel predictivo y Dashboard Ejecutivo de Administrador:**
  - Nueva entrada `Dashboard` (`/dashboard`) en el panel lateral (`Sidebar`), restringida exclusivamente al rol `admin` mediante `roleGuard`.
  - Página `Dashboard` (`src/app/features/dashboard/pages/dashboard/`): 3 tarjetas KPI financieras en CLP, gráfico vectorial SVG de evolución vs. estimación de cierre, ganancia limpia en pesos por familia de productos, concentración horaria de demanda, reglas de ventas combinadas y desempeño de catálogo.
  - **Asistente rápido en panel lateral deslizable (*Drawer Off-Canvas / estilo carrito POS*):** reubicado fuera del cuerpo principal para liberar espacio vertical. Se abre mediante botón de cabecera con badge «Chat» o botón flotante fijo inferior, desplegando un panel lateral sobre fondo difuminado (*backdrop*) con avatar de IA, chips de preguntas frecuentes predefinidas y burbujas de diálogo accesibles con recomendaciones de negocio orientativas. En móviles se abre como hoja inferior con altura delimitada (`height: 85dvh`), aislamiento de scroll táctil (`touch-action: pan-y`, `overscroll-behavior: contain`) y bloqueo dinámico del scroll del fondo (`body.assistant-drawer-open`, `.main-layout-content`) y atajo Escape.
  - **Corrección de desbordamiento de scroll fantasma inferior:** el drawer `<aside class="assistant-drawer">` se renderiza de forma estrictamente condicional dentro de `@if (asistenteAbierto())` para no ocupar espacio en el DOM cuando está cerrado, eliminando el espacio vacío que se generaba al forzar el scroll inferior del dashboard. Asimismo, en vista móvil se configuró anclaje explícito `position: fixed; top: 15dvh; right: 0; bottom: 0; left: 0;` (reemplazando `inset: auto 0 0 0;` que causaba que el navegador calculara la posición estática del elemento extendiendo el contenedor de scroll), y se definió `:host { display: block; min-width: 0; }` en el componente.
  - **Causa real del espacio vacío al forzar el scroll inferior (layout global):** `.main-layout-content` era el contenedor con scroll pero sin `position: relative`; los elementos `position: absolute` (p. ej. `<caption class="sr-only">` de la tabla predictiva) escapaban de su recorte y estiraban el `body`, que pasaba a ser desplazable al encadenarse el scroll. Corregido en `main-layout.css` con `position: relative` y `overscroll-behavior: contain`. Verificado: 61/61 suites, 841/841 pruebas y build sin errores ni advertencias.
  - Componente reutilizable `<app-panel-predictivo>` (`src/app/features/inventario/components/panel-predictivo/`): tabla limpia con duración estimada en días, columna «Sugerido para comprar», tarjetas con terminología asistiva («Sugerido comprar hoy», «Sugerido comprar pronto») y estado «Datos insuficientes para sugerir» (< 28 días).
  - Pestaña de Inventario renombrada a **«Sugerencias de compra»** (`#tab-predicciones`), preservando la consulta URL `?vista=predicciones`.
  - Cobertura: `dashboard.spec.ts` (3 pruebas: renderizado de KPIs/charts, apertura/cierre condicional de drawer deslizable en DOM y selección reactiva de preguntas/período), `panel-predictivo.spec.ts` (3 pruebas), actualización de `sidebar.spec.ts` e `inventario.spec.ts` (94 pruebas).
- **H4.5 T03, horizonte de reposición diaria Just-in-Time y validación del umbral mínimo de 4 semanas:**
  - Modelo `prediccion.model.ts`: horizonte de compra sugerida modificado a **1 día** por defecto (`diasObjetivo = 1`), adaptado a la restricción física de cafeterías universitarias donde bodegas y refrigeradores no admiten acopio semanal y operan con compras diarias.
  - Cobertura: `prediccion.model.spec.ts` (7 pruebas unitarias probando horizonte por defecto de 1 día, redondeo entero para productos y decimal para materias primas, y 7 días si se explicita).

## Cierre y pase a Finalizado de tareas H3.5 y H3.6 (H3.5 T07, H3.5 T08, H3.6 T02, H3.6 T03, H3.6 T04, H3.6 T08, H3.6 T09) — 27-10-2026

- **H3.5 T07, reactividad de estados, filtros y alertas:**
  - El listado de existencias, tarjetas del resumen, filtros combinados y el banner de alertas operan sobre señales reactivas (`computed()`).
  - Al guardar un nuevo mínimo o aplicar un ajuste que lleve el stock a un valor igual o superior al mínimo, el artículo pasa automáticamente a `state-estable` y la alerta de la sucursal desaparece de inmediato sin requerir recarga de página.
  - Cobertura: prueba unitaria en `inventario.spec.ts` (*«changes the minimum only in the branch of the edited row»*).
- **H3.5 T08, permisos y visibilidad de bodeguero y administrador:**
  - `sucursalesAutorizadas` y `puedeEditarMinimo` (`inventario.service.ts`): el administrador consulta y modifica mínimos en cualquier sucursal; el bodeguero solo en la sucursal que tiene asignada; el cajero no accede al módulo (protegido por `AuthGuard`).
  - En la base de datos: migración `20261022_stock_minimo_bodeguero.sql` con `GRANT UPDATE (stock_minimo)` a `nury_bodeguero` y `CHECK (stock_minimo >= 0)`.
  - Cobertura: 15 pruebas unitarias en `inventario.service.spec.ts` y ensayo SQL `stock_minimo_bodeguero.sql`.
- **H3.6 T02, modelo de ajustes en movimientos de inventario:**
  - Interfaces `AjusteStock` y `AjusteManualApi`: artículo, cantidad con signo, unidad, motivo (`nota`), usuario (`usuario_id`), fecha (`creado_en`) y sucursal.
  - Reutiliza `movimientos_stock` con `tipo_movimiento = 'ajuste'` y persistencia del responsable mediante `fn_usuario_actual_id()`.
  - Cobertura: `inventario.model.spec.ts` e `inventario.service.spec.ts`.
- **H3.6 T03, servicio de descuento transaccional:**
  - Función atómica `fn_ajustar_stock`: bloquea la fila con `FOR UPDATE`, valida existencias, actualiza stock e inserta el movimiento en una única transacción.
  - `StockApiService.ajustar()` consume `/rpc/fn_ajustar_stock` enviando la clave única de idempotencia.
  - Cobertura: ensayo SQL `ajuste_stock_idempotente.sql`.
- **H3.6 T04, validaciones de cantidad, stock disponible, motivo y permisos:**
  - `AjusteInventario`: valida motivo no vacío, cantidades numéricas finitas mayores a cero, bloqueo de decimales en productos de reventa y validación de stock disponible.
  - En la base: excepción `23514` ante decrementos que dejen stock negativo, y permisos restringidos exclusivamente a `nury_admin` y `nury_bodeguero`.
  - Cobertura: 20 pruebas en `ajuste-inventario.spec.ts` y ensayo SQL `ajuste_stock_permisos.sql`.
- **H3.6 T08, conexión de ajustes confirmados con el panel y reporte:**
  - El evento `(ajustado)` emitido por `<app-ajuste-inventario>` invoca `registrarAjuste()` en `inventario.ts`, mostrando feedback de éxito, disparando `actualizarExistencias()` para recalcular todas las alertas en tiempo real e incrementando `versionMermas` para actualizar la pestaña de mermas.
  - Cobertura: prueba unitaria en `inventario.spec.ts` (*«closes the modal, shows the result and refreshes the stock after an adjustment»*).
- **H3.6 T09, pruebas integrales de casos límite:**
  - Cobertura exhaustiva de materias primas vs productos normales, cantidades enteras/decimales, motivos vacíos, rechazo de stock negativo, permisos 403, idempotencia ante reintentos (UUID persistido) y totales agrupados por artículo y unidad en el reporte de mermas.
  - Cobertura: 20 pruebas en `ajuste-inventario.spec.ts`, 18 pruebas en `reporte-mermas.spec.ts` y ensayos SQL `ajuste_stock_idempotente.sql` y `ajuste_stock_permisos.sql`.
- **Estado de Trello:** Las 7 tarjetas fueron movidas formalmente a la columna **Finalizado** en el tablero del Sprint 2.

## Mínimos con permisos, estados en la base y aviso de stock sin revisar (H3.5 T03, H3.5 T04, H2.5 T06) — 24-10-2026

- **H3.5 T03, servicio de mínimos:**
  - `validarMinimo` pasa de la página al modelo (`inventario.model.ts`) y la usan el formulario y `InventarioService.actualizarMinimo`. Nueva regla: el mínimo de un producto de reventa debe ser entero (se cuenta por unidad).
  - `InventarioService.actualizarMinimo` revisa permiso y valor antes de llamar a la API, y si no cumplen falla con `MinimoRechazadoError` sin llamar a la API.
  - `puedeEditarMinimo`: el admin cambia mínimos en cualquier sucursal, el bodeguero solo en la suya y el cajero en ninguna.
  - `interpretarFalloMinimo` muestra el motivo del rechazo.
- **H3.5 T04, regla de estados en la base:**
  - Migración `20261024_estado_stock.sql`: `fn_estado_stock` (misma regla que `calcularEstadoStock`) y la vista `v_estado_stock` (`security_invoker`, sobre `v_existencias_articulos`, solo artículos activos, con estado y cantidad a reponer).
  - Elimina `v_ingredientes_bajo_stock`, que no distinguía agotados ni incluía productos y no la usaba ninguna pantalla.
  - Prueba SQL: `database/tests/estado_stock.sql`. Es un ensayo completo: crea lo mismo que la migración, lo prueba y termina en `ROLLBACK`. No usa comandos de psql, así que corre también en pgAdmin y DBeaver.
  - La migración usa `SET ROLE nury_admin` como las del 22-10. Aplicada en el VPS el 24-10-2026.
- **H2.5 T06, avisos en el POS:** si la consulta de stock insuficiente falla tras registrar la venta, la venta se marca con `stockSinVerificar` y el comprobante avisa "No pudimos revisar el stock de esta venta" en vez de no decir nada. El aviso queda fuera del ticket impreso.
- **Pruebas nuevas (29):**
  - `inventario.service.spec.ts`: 15. Cubren rechazos por rol y sucursal, rechazos por valor y `puedeEditarMinimo`.
  - `inventario.model.spec.ts`: 10, de `validarMinimo`.
  - `fallo-minimo.spec.ts`: 1.
  - `inventario.spec.ts`: 1, mínimo decimal en un producto.
  - `pos.service.spec.ts`: 1.
  - `payment-modal.component.spec.ts`: 1.
- **Nota:** en la primera corrida completa, la primera prueba de `inventario.spec.ts` superó los 5 s por el arranque en frío. Corrida sola y en la segunda corrida completa pasó.

## Reemplazo de emojis por iconos vectoriales Lucide (Option 1) — 23-10-2026

- **Componente SVG Standalone (`AppIconComponent`):** Creado en `src/app/shared/components/app-icon/app-icon.component.ts` con selector `<app-icon [name]="name" [size]="size" />`. Contiene los paths vectoriales limpios y oficiales de Lucide (`banknote`, `credit-card`, `ticket`, `key-round`, `check-circle` / `circle-check`) con `stroke="currentColor"`.
- **Integración en Apertura y Cierre de Caja (`features/caja`):**
  - En `caja.model.ts`: `PAYMENT_METHOD_META` actualizado con identificadores vectoriales (`'banknote'`, `'credit-card'`, `'ticket'`).
  - En `cierre-caja.component.ts`: Importado `AppIconComponent` en sus `imports`.
  - En `cierre-caja.component.html`: reemplazados emojis de inicio (`key-round`), turno cerrado (`check-circle`), desgloses y boletas con `<app-icon>`.
  - En `cierre-caja.component.css`: alineación vertical con `inline-flex`/`flex`, `align-items: center`, `gap: 8px`, herencia de color `#3d5334`.
- **Integración en Modal de Pago POS (`features/pos`):**
  - En `payment-modal.component.ts`: Importado `AppIconComponent`.
  - En `payment-modal.component.html`: botones de medio de pago con íconos vectoriales (`banknote` para Efectivo, `credit-card` para Débito/Crédito, `ticket` para Pluxee/Edenred).
  - En `payment-modal.component.css`: `.method-icon` centrado en 24×24 con color adaptable (#5c7149 inactivo, #384c2d activo).
- **Pruebas y Build:**
  - Nueva suite `app-icon.component.spec.ts` (7 pruebas unitarias).
  - 44/44 suites y 642/642 pruebas unitarias aprobadas (100% PASS).
  - `npm run build` aprobado con 0 errores y 0 advertencias.

## Cierre de correcciones de base de datos — 22-10-2026

- **Historial de ajustes bodeguero (Pedido 11):** Aplicada la migración `database/migrations/20261021_historial_ajustes_bodeguero.sql` en producción/VPS. Concede `SELECT` en `movimientos_stock` y en `usuarios (id, nombre)`. Resuelve el error 403 en Inventario > "Mermas y ajustes".
- **Stock mínimo bodeguero y no negatividad (Pedidos 4 y 6):** Nueva migración `database/migrations/20261022_stock_minimo_bodeguero.sql` y prueba `database/tests/stock_minimo_bodeguero.sql`. Restricción `CHECK (stock_minimo >= 0)` en `stock_sucursal` y `stock_producto_sucursal`, y `GRANT UPDATE (stock_minimo)` para `nury_bodeguero`. Aplicada en VPS.
- **Zona horaria en movimientos (Pedido 10):** Nueva migración `database/migrations/20261022_movimientos_timestamptz.sql` y prueba `database/tests/movimientos_timestamptz.sql`. Convierte `movimientos_stock.creado_en` a `TIMESTAMPTZ` con `DEFAULT now()`. Aplicada en VPS.
- **Validación Angular:** Suite completa ejecutada con **43/43 suites y 635/635 pruebas aprobadas (100% PASS)** sin regresiones.


## Ajustes visuales pedidos por Patricio — 21-10-2026

- Cambios: "Nury's" con mayúscula (menú, cabecera del POS y login); medios de pago en dos filas parejas; aviso de efectivo pendiente en tamaño de texto; Sodexo se muestra como Pluxee (la clave interna sigue siendo `sodexo`); anulación de ventas responsiva (tarjetas cuando la tabla no cabe, sin scroll lateral de 375 a 1440 px).
- Historial de ajustes del bodeguero: la API respondía 403 en `movimientos_stock` y `usuarios`. Nueva migración `database/migrations/20261021_historial_ajustes_bodeguero.sql` y su prueba `database/tests/historial_ajustes_bodeguero.sql`, **pendientes de aplicar en el VPS**.
- Sin casos nuevos de Vitest (solo textos y estilos); las expectativas existentes siguen pasando: **43/43 suites y 635/635 pruebas**.
- Se reemplazaron los marcadores de conflicto (`<<<<<<<`/`>>>>>>>`) que venían commiteados en el resumen desde `39ee64c`.
- Verificado en el navegador con sesión real (sucursal de desarrollo): bodeguero en Mermas y ajustes (403 confirmado), admin en POS, modal de pago y anulación en 375, 900 y 1280 px. No se cobró ni se anuló nada.

## Retiro de la pantalla de facturas — 15-10-2026

- Eliminados el componente, plantilla, estilos y datos de ejemplo de la pantalla, junto con su ruta, entrada del menú, ícono exclusivo y referencia en los destinos del login.
- Actualizadas las expectativas existentes del sidebar para administrador y bodeguero; sin casos nuevos.
- Verificado que el código fuente y el build de producción ya no contienen referencias a la pantalla eliminada.
- Primera ejecución mediante `npm test`: npm no propagó los argumentos del runner y se interrumpió sin resultado. La ejecución directa de Angular CLI indicada arriba finalizó con **35/35 suites y 425/425 pruebas aprobadas**.

> El registro del 19-09 indicaba 69 pruebas en esta rama. La implementación anterior de anulación sigue pendiente de reconstrucción y verificación.

## Inventario por suite — 20-10-2026

| Archivo | Pruebas | Estado |
| --- | ---: | --- |
| `src/app/app.routes.spec.ts` | 2 | PASS |
| `src/app/app.spec.ts` | 3 | PASS |
| `src/app/core/api/ingredientes-api.service.spec.ts` | 5 | PASS |
| `src/app/core/api/productos-api.service.spec.ts` | 5 | PASS |
| `src/app/core/api/recetas-api.service.spec.ts` | 4 | PASS |
| `src/app/core/api/stock-api.service.spec.ts` | 10 | PASS |
| `src/app/core/api/recetas-api.service.spec.ts` | 5 | PASS |
| `src/app/core/api/stock-api.service.spec.ts` | 8 | PASS |
| `src/app/core/api/sucursales-api.service.spec.ts` | 8 | PASS |
| `src/app/core/api/turnos-api.service.spec.ts` | 1 | PASS |
| `src/app/core/api/ventas-api.service.spec.ts` | 10 | PASS |
| `src/app/core/guards/auth.guard.spec.ts` | 19 | PASS |
| `src/app/core/services/app-loader.service.spec.ts` | 5 | PASS |
| `src/app/core/services/barcode-scanner.spec.ts` | 5 | PASS |
| `src/app/core/services/conexion.service.spec.ts` | 3 | PASS |
| `src/app/features/anulacion-venta/pages/anulacion-venta/anulacion-venta.spec.ts` | 14 | PASS |
| `src/app/features/auth/pages/login/login.component.spec.ts` | 12 | PASS |
| `src/app/features/auth/services/auth.service.spec.ts` | 7 | PASS |
| `src/app/features/caja/pages/cierre-caja/cierre-caja.component.spec.ts` | 21 | PASS |
| `src/app/features/caja/services/caja.service.spec.ts` | 11 | PASS |
| `src/app/features/gestion-negocio/pages/gestion-negocio/gestion-negocio.spec.ts` | 5 | PASS |
| `src/app/features/gestion-negocio/pages/sucursales/sucursales.spec.ts` | 9 | PASS |
| `src/app/features/inventario/components/ajuste-inventario/ajuste-inventario.spec.ts` | 19 | PASS |
| `src/app/features/inventario/components/reporte-mermas/reporte-mermas.spec.ts` | 18 | PASS |
| `src/app/features/inventario/models/fallo-ajuste.spec.ts` | 18 | PASS |
| `src/app/features/inventario/models/fallo-minimo.spec.ts` | 11 | PASS |
| `src/app/features/inventario/models/inventario.model.spec.ts` | 24 | PASS |
| `src/app/features/inventario/pages/inventario/inventario.spec.ts` | 74 | PASS |
| `src/app/features/inventario/services/inventario.service.spec.ts` | 22 | PASS |
| `src/app/features/pos/components/payment-modal/payment-modal.component.spec.ts` | 19 | PASS |
| `src/app/features/inventario/components/ajuste-inventario/ajuste-inventario.spec.ts` | 20 | PASS |
| `src/app/features/inventario/components/reporte-mermas/reporte-mermas.spec.ts` | 13 | PASS |
| `src/app/features/inventario/models/fallo-ajuste.spec.ts` | 18 | PASS |
| `src/app/features/inventario/models/fallo-minimo.spec.ts` | 9 | PASS |
| `src/app/features/inventario/models/inventario.model.spec.ts` | 21 | PASS |
| `src/app/features/inventario/pages/inventario/inventario.spec.ts` | 66 | PASS |
| `src/app/features/inventario/services/inventario.service.spec.ts` | 18 | PASS |
| `src/app/features/pos/components/payment-modal/payment-modal.component.spec.ts` | 21 | PASS |
| `src/app/features/pos/models/pos-icons.spec.ts` | 4 | PASS |
| `src/app/features/pos/pages/pos-layout/pos-layout.component.spec.ts` | 22 | PASS |
| `src/app/features/pos/services/pos.service.spec.ts` | 30 | PASS |
| `src/app/features/pos/services/recuperar-turno.spec.ts` | 8 | PASS |
| `src/app/features/products/components/receta-producto-modal/receta-producto-modal.spec.ts` | 6 | PASS |
| `src/app/features/products/pages/product-master/product-master.spec.ts` | 25 | PASS |
| `src/app/layout/sidebar/sidebar.spec.ts` | 10 | PASS |
| `src/app/shared/components/app-icon/app-icon.component.spec.ts` | 7 | PASS |
| `src/app/shared/components/coffee-loader/coffee-loader.spec.ts` | 7 | PASS |

## Ajustes visuales del dashboard de Reportes — ejecución del 05-11-2026

- Revisión en el navegador (Sebastián): los filtros de sucursal pasan a un desplegable con casillas («Todas las sucursales», el nombre de la elegida o «N sucursales»; se cierra con un clic fuera o Escape) y el período a un select como los de Inventario (Día, Semana, Mes, Rango personalizado) con su fecha («Semana del», «Mes de»). La página toma el mismo ancho, márgenes, fondo y fuente que Inventario (antes tenía un ancho máximo menor y quedaba más espacio a los lados). En Cajeros, «0 turnos» pasa a «sin turno registrado».
- Pruebas: `filtros-reporte.spec.ts` (desplegable con varias sucursales y vuelta a todas, cierre con clic fuera y Escape, período y rango) y `reportes.spec.ts` actualizado. `features/reportes`: 9/9 archivos y 52/52 pruebas; `ngc` sin errores.

## Desplegables de orden y categoría con el diseño de los filtros (Reportes) — ejecución del 09-11-2026

- Los select del navegador de Reportes («Ordenar cajeros por», «Categoría» y «Ordenar productos por») pasan a un desplegable propio (`desplegable`) con el mismo diseño que los de sucursales, período y turno: botón con la opción elegida («Ordenar por: monto facturado») y lista con marca; se cierra al elegir, con Escape o al hacer clic fuera. En celular ocupa todo el ancho.
- Prueba: `desplegable.spec.ts` (3); `reporte-cajeros.spec.ts` y `reporte-productos.spec.ts` eligen el orden y la categoría desde el desplegable. Reportes: 13 archivos, 80/80; `ngc` sin errores.

## Alto margen y poco volumen (H4.4 T05) — ejecución del 07-11-2026

- Al revisar los criterios de H4.4 faltaba el segundo caso límite: productos de alto margen pero volumen casi nulo (candidatos a promocionar). Pestaña Productos: tarjeta «Alto margen, poco volumen» junto a «Alto volumen, bajo margen» (una al lado de la otra; en tablet y celular una bajo la otra): productos con costo completo que están a la vez en el 25 % con mejor margen % y en el 25 % que menos unidades vendió; con menos de 4 productos con costo no se destaca nada (los cuartos no distinguen). Umbrales en `UMBRALES_MARGEN` (`margenSuperior`, `volumenInferior`).
- Prueba: `margen.model.spec.ts` (+2: alto margen y poco volumen, sin costo completo o menos de 4 productos), `reporte-productos.spec.ts` (+1). Reportes: 12 archivos, 77/77; `ngc` sin errores.

## Margen por producto con el costo actual (H4.4 T03, T04 y T05) — ejecución del 07-11-2026

- `database/migrations/20261106_costo_actual_productos.sql`: `fn_costo_actual_productos()` (STABLE, SECURITY DEFINER, solo admin) da el costo actual de cada producto: con receta, la receta vigente × costo promedio de cada ingrediente (como `v_costo_producto`), contando los ingredientes con costo 0; sin receta, el último precio de compra por factura; sin ninguno, `sin_costo` con costo vacío (no se supone 0). Decisión del 06-11: costo actual, no el del día de la venta.
- Pestaña Productos: columna Margen ($, % sobre lo cobrado y costo unitario), orden por margen en pesos o en porcentaje (sin costo al final) y margen total en el encabezado. Casos límite (T04): «Sin costo» en los productos sin receta ni precio de compra (no cuentan en el total), aviso «costo incompleto» cuando la receta tiene ingredientes sin costo, margen negativo en rojo y bajo el umbral en ámbar, porcentaje vacío sin monto, y si falla la carga de costos se ven las ventas sin margen. T05: tarjeta «Alto volumen, bajo margen» con el 25 % de productos que más unidades vendió, al menos 3 unidades y margen bajo 15 % (umbrales en `UMBRALES_MARGEN`, propuestos; se cambian en un solo lugar).
- Prueba: `database/tests/costo_actual_productos.sql` (receta completa, receta con ingrediente sin costo, precio de compra, sin costo e inactivo, la receta manda sobre el precio de compra, el costo cambia con el costo actual, permisos). Front: `margen.model.spec.ts` (6), `reporte-productos.spec.ts` (+4), `reportes.service.spec.ts` (+1), `reportes-api.service.spec.ts` (+1). Reportes, API y Dashboard: 20 archivos, 259/259; `ngc` sin errores.

## Reporte de cajeros por turno real (H4.3 T03) — ejecución del 06-11-2026

- `database/migrations/20261106_reporte_cajeros_turno.sql`: `fn_turnos_reporte(p_sucursales, p_desde, p_hasta)` lista los turnos que empezaron en el período o que tienen ventas en él (cajero, sucursal, inicio y fin en hora de Chile; fin vacío = abierto) con ventas válidas, total y anuladas del turno completo, y una fila final «Sin turno registrado» con las ventas del período sin turno. `fn_reporte_cajeros` suma `p_turno` opcional: un id = solo las ventas de ese turno aunque crucen la medianoche; 0 = solo las sin turno; sin indicar = igual que antes (la pantalla y el asistente del Dashboard no cambian). Ambas STABLE, SECURITY DEFINER, solo admin.
- Pestaña Cajeros: desplegable «Turno» (`selector-turno`), con el mismo diseño que los de sucursales y período: todos los turnos, cada turno real con su horario y cifras, o sin turno registrado. Con un turno elegido la tabla muestra solo ese turno y no se compara con el período anterior (se avisa con una nota); las tarjetas de arriba siguen siendo del período. Al cambiar sucursales o período vuelve a «Todos los turnos».
- Prueba: `database/tests/reporte_cajeros_turno.sql`: orden de los turnos, turno que cruza la medianoche con sus cifras completas, turno abierto, anuladas aparte, fila sin turno, filtro de sucursal, reporte con un turno / con 0 / sin turno (igual que antes), turno sin ventas, turno negativo, período inválido, permisos y que no quede la versión de tres parámetros. `reporte_cajeros.sql` actualiza la firma en su revisión de permisos. Front: `turno.model.spec.ts` (4), `selector-turno.spec.ts` (3), `reportes.spec.ts` (+1), `reportes.service.spec.ts` (+2), `reportes-api.service.spec.ts` (+1). Reportes, API y Dashboard: 19 archivos, 247/247; `ngc` sin errores.

## Cuadratura del reporte con movimientos_stock (H4.1 T04) — ejecución del 05-11-2026

- `database/migrations/20261105_cuadratura_ventas_stock.sql`: `fn_cuadratura_ventas_stock(p_sucursales, p_desde, p_hasta)` (STABLE, SECURITY DEFINER, solo admin). Por sucursal y artículo compara lo que las ventas válidas del período debieron descontar (producto sin receta en la venta: su cantidad; con receta: cada ingrediente de la versión usada × cantidad) con los movimientos `venta` menos `anulacion_venta` de esas mismas ventas (por `referencia_id`, no por fecha del movimiento). Una venta anulada y repuesta neta 0 y no aparece; una anulada sin reponer aparece como diferencia. Los almuerzos (`consumo_interno`) no se mezclan. Devuelve esperado, registrado, diferencia y si cuadra; primero lo que no cuadra.
- Dashboard: en la pestaña Sucursales, tarjeta «Cuadratura con el inventario» (`cuadratura-stock`): «Cuadra» con los artículos revisados, o cuántos no cuadran con una tabla de lo esperado según las ventas, lo registrado en el inventario y la diferencia. Se consulta aparte: si falla, el resto del reporte se sigue viendo.
- Prueba: `database/tests/cuadratura_ventas_stock.sql` con ventas reales (`fn_registrar_venta_idempotente`): venta mixta que cuadra (pan 4, queso 60 con la versión usada aunque la receta cambió después, bebida 3), venta anulada y repuesta fuera, almuerzo fuera, venta anulada sin reponer con diferencia +1 y primero en la lista, filtros de sucursal y período, período inválido y permisos. Front: `cuadratura-stock.spec.ts` (3), `reportes.spec.ts` (+2: se muestra en Sucursales y no rompe el reporte si falla), `reportes.service.spec.ts` (+1), `reportes-api.service.spec.ts` (+1).
- Al traer `develop` (05-11) no compilaba: `inventario.ts` tenía `esAdmin` declarado dos veces (H4.5 T09 y H2.13 T07, idénticos). Se dejó uno con el comentario de ambos usos. `prediccion-stock.service.spec.ts` (H4.5) falla con la zona UTC y pasa con America/Santiago (fecha que depende de la zona horaria del equipo). Suite: 86 archivos, 1176/1177 (esa prueba en UTC); `ngc` sin errores.

## Filtro de ventas por período: sin ventas y período anterior (H4.2 T01, T02, T03 y T05) — ejecución del 04-11-2026

- T01: si el período elegido no tiene ventas (ni anuladas) en las sucursales elegidas, el dashboard muestra «Sin ventas en este período» y lo que hubo en el período anterior («Semana anterior: 8 ventas por $40.000.» o «tampoco hubo ventas»), en vez de tarjetas en 0. En la pestaña Sucursales, una sucursal sin ventas (por ejemplo, recién abierta) lo dice en su barra y en el detalle; Productos y Cajeros muestran el mismo mensaje.
- T02: cada tarjeta muestra, junto a su valor y la variación, el mismo indicador del período anterior («Semana anterior: $40.000»); las columnas de comparación de Sucursales, Productos y Cajeros muestran el valor anterior y la variación. El período anterior es de igual duración según el filtro: día anterior; semana: los mismos días de la semana anterior (lunes a miércoles contra lunes a miércoles); mes: los mismos días del mes anterior (sin pasar su último día); rango: los mismos días inmediatamente antes. Se nombra «Día anterior», «Semana anterior», «Mes anterior» o «N días anteriores».
- T03: `database/tests/reportes_sin_ventas.sql`: sucursal recién abierta en 0 en el resumen (sola o junto a otra) y sin productos ni cajeros; período sin ventas con el resumen en 0 y listas vacías, sin errores. Siguen pasando las pruebas de T02, T03 y cajeros.
- Pruebas front: `periodo.model.spec.ts` (período anterior por tipo y su nombre), `reporte-sucursales.spec.ts` (+1: sucursal sin ventas y período nombrado), `reporte-productos.spec.ts` y `reporte-cajeros.spec.ts` (valor anterior), `reportes.spec.ts` (+2: sin ventas con el período anterior; mes contra los mismos días del mes anterior). `features/reportes`: 8/8 archivos y 45/45 pruebas; `ngc` sin errores.

## Dashboard de Reportes con datos reales: sucursales, productos y cajeros (H4.1 T01 y T06, H4.3 T02) — ejecución del 04-11-2026

- `database/migrations/20261104_reporte_cajeros.sql`: `fn_reporte_cajeros(p_sucursales, p_desde, p_hasta)` (STABLE, SECURITY DEFINER, solo admin), mismo período y filtro que T02. Por cajero: sucursales donde vendió, turnos, ventas, total vendido, venta promedio y productos (unidades), sin anuladas; las anuladas aparte (cantidad y monto). Ventas sin cajero como «Sin cajero», al final. Prueba `database/tests/reporte_cajeros.sql`: cajera que vende en dos sucursales, anulada aparte, venta del día anterior fuera, orden por total, filtro por sucursal, cuadratura con el total de T02 y permisos; falla sin la migración y pasa con ella.
- `/reportes` es un dashboard: filtros compartidos arriba (`filtros-reporte`: sucursales como botones, «Todas» o varias; período día, semana lunes a domingo, mes o rango, sin pasar de hoy); cuatro tarjetas (total vendido, ventas, ticket promedio y anuladas) con la variación contra el período anterior de igual largo; destacados (sucursal que más vendió, producto estrella y cajero con más ventas, que llevan a su pestaña); y pestañas con `?vista=`:
  - Sucursales (`reporte-sucursales`): total por sucursal en barras con su variación, medios de pago apilados y detalle con normales, empleados, anuladas y variación.
  - Productos (`reporte-productos`): las sucursales elegidas juntas; unidades, ventas y monto por separado, % del monto y variación; búsqueda sin tildes, categoría, orden por monto, unidades o ventas; 20 primeros y «Ver todos».
  - Cajeros (`reporte-cajeros`): las cuatro métricas de H4.3, orden por cualquiera, variación de la métrica elegida contra su propio período anterior; anulaciones aparte con su frecuencia.
- Datos reales con `ReportesService` (seis consultas en paralelo: período actual y anterior de las tres funciones) y sucursales activas reales. Mientras se cambian los filtros se mantienen los datos anteriores atenuados; error con reintento y aviso sin permiso (403). Responsive: tablas a tarjetas en tablet y celular. Pendiente: margen por producto (H4.4, falta definir el costo) y filtro por turno (H4.3 T03).
- Pruebas: `filtros-reporte.spec.ts`, `reporte-sucursales.spec.ts`, `reporte-productos.spec.ts`, `reporte-cajeros.spec.ts`, `reportes.spec.ts` (consultas actual y anterior, tarjetas, destacados, pestañas y URL, recarga al elegir sucursales, 403 y reintento), `periodo.model.spec.ts`, `reporte-ventas.model.spec.ts`, `reportes.service.spec.ts` (+1) y `reportes-api.service.spec.ts` (+1). Suite completa: 70/70 archivos y 885/885 pruebas; `ngc` sin errores.

## Ruta /reportes, menú y servicio de reportes (H4.1 T05) — ejecución del 04-11-2026

- Ruta `/reportes` con `roleGuard` solo para el administrador y entrada «Reportes» en el menú, después de Dashboard (ícono de informe). La página (`features/reportes/pages/reportes`) es por ahora la base navegable: encabezado y la sección «Ventas por sucursal» en construcción; se diseña en T01 y se conecta en T06. Desempeño por cajero (H4.3) y rendimiento por producto (H4.4) se suman como pestañas.
- `core/api/reportes-api.service.ts`: `resumenVentasSucursal` y `productosVendidosSucursal` (POST a `fn_reporte_ventas_sucursal` y `fn_reporte_productos_sucursal`); una lista de sucursales vacía se envía como null (todas). `features/reportes/services/reportes.service.ts` convierte las filas al modelo de la pantalla (números, medios de pago, normales/empleado y anuladas aparte, «Sin sucursal» con id null).
- Pruebas: `reportes-api.service.spec.ts` (3), `reportes.service.spec.ts` (2), `reportes.spec.ts` (1), `auth.guard.spec.ts` +3 (admin entra a /reportes; cajero y bodeguero no) y `sidebar.spec.ts` (Reportes en el menú del admin). 5/5 archivos y 38/38 pruebas; `ngc` sin errores.

## Productos vendidos por sucursal (H4.1 T03) — ejecución del 04-11-2026

- `database/migrations/20261104_reporte_productos_sucursal.sql`: `fn_reporte_productos_sucursal(p_sucursales, p_desde, p_hasta)` (STABLE, SECURITY DEFINER, solo admin), con el mismo período y filtro de sucursales que T02. Una fila por sucursal y producto: categoría, si tiene receta (para la cuadratura de T04), unidades, número de ventas, monto bruto (subtotales), descuento y monto. Sin ventas anuladas. El 30 % de las ventas a empleado se descuenta sobre el total de la venta (no por línea), así que aquí se reparte entre sus líneas según el subtotal: la suma de los montos de una sucursal es su total del resumen de T02. Orden: sucursal y mayor monto primero; «Sin sucursal» al final.
- Prueba: `database/tests/reporte_productos_sucursal.sql` (zona UTC): café y sándwich en A (3 y 2 unidades; 450 y 900 de descuento de empleado repartido), café en B con la venta de las 23:30 de Chile, anulada fuera, venta de las 23:00 del día anterior fuera del 20 y dentro del 19, «Sin sucursal», orden, cuadratura con T02 (9.150 = suma de productos de A), período inválido y permisos. Falla sin la migración y pasa con ella; sigue pasando `reporte_ventas_sucursal.sql`.

## Resumen de ventas por sucursal y período (H4.1 T02) — ejecución del 04-11-2026

- `database/migrations/20261104_reporte_ventas_sucursal.sql`: `fn_reporte_ventas_sucursal(p_sucursales, p_desde, p_hasta)` (STABLE, SECURITY DEFINER, solo admin). Devuelve una fila por sucursal, nunca solo la suma: ventas válidas, total, ticket promedio, totales por medio de pago (JSON), normales y de empleado por separado, y anuladas aparte (no suman al total). `p_sucursales` NULL = todas las activas; las pedidas aparecen aunque no vendan (en 0) y una inactiva aparece si vendió. Fechas en días de Chile, ambos incluidos; los límites se pasan a la zona de `fecha_venta` (la del servidor, UTC en el VPS) para usar el índice. Rechaza períodos sin fecha, invertidos o de más de un año (22023).
- "Sin sucursal": en producción `ventas.sucursal_id` es NOT NULL y hay 0 ventas sin sucursal (verificado el 04-11); igual, una venta sin sucursal saldría en su propia fila «Sin sucursal», al final, en vez de quedar fuera.
- Prueba: `database/tests/reporte_ventas_sucursal.sql` (zona UTC como el VPS): A y B por separado el 20-oct (A: 4 ventas, 7.500, ticket 1.875, 3 normales por 6.000, 1 de empleado por 1.500, 1 anulada por 5.000 aparte y medios de pago; B: 1 venta por 4.000); la venta de las 23:30 de Chile (02:30 UTC del día siguiente) cuenta en su día y la de las 23:00 del día anterior no; rango de dos días; venta sin sucursal (se quita el NOT NULL solo dentro de la prueba) como «Sin sucursal»; sucursal activa sin ventas en 0 e inactiva sin ventas fuera; nunca filas repetidas; períodos inválidos; permisos (solo admin). Falla sin la migración y pasa con ella.

## Inventario > Por comprar: artículos críticos para la compra del día siguiente — ejecución del 30-10-2026

- Pedido: las compras se hacen a diario; una pestaña en Inventario con los artículos críticos que se vayan agregando solos, para saber qué comprar mañana. Decisiones (30-10): crítico = stock bajo mínimo + consumo diario; entran materias primas y productos de reventa.
- `database/migrations/20261030_articulos_por_comprar.sql`: `fn_articulos_por_comprar(p_sucursal_id, p_dias)` (STABLE, SECURITY DEFINER, para admin y bodeguero). Consumo diario = ventas menos anulaciones de los últimos `p_dias` días (1 a 90, por defecto 7) ÷ `p_dias`; entra si `stock_actual < stock_minimo + consumo_diario`; sugerido = la diferencia (productos en unidades enteras hacia arriba, materias primas a 3 decimales). Usa `v_existencias_articulos` (activos; productos con receta no son artículo). Sin mínimo ni ventas no entra. Ordena por sucursal y agotados primero. Devuelve también `vendido` (total del periodo): la pantalla y las planillas muestran «Vendido (7 días)» en vez del promedio diario, que en productos daba fracciones sin sentido (1 bebida en 7 días = 0,143 por día); el cálculo sigue usando el promedio. Como cambió la lista de columnas, la migración hace `DROP FUNCTION IF EXISTS` antes de crearla.
- Inventario: pestaña «Por comprar» (`lista-compras`) entre Existencias y Mermas, con `?vista=compras`. Filtros de sucursal y de periodo de ventas (1, 7, 14 o 30 días), resumen por motivo (agotado, bajo el mínimo, no alcanza para mañana), tabla en computador y tarjetas en tablet/celular, y descarga en Excel («Descargar Excel», .xlsx con números reales, encabezado fijo con filtros y «Comprar» en negrita; generado por `shared/utils/xlsx.ts`, sin dependencias nuevas) o en CSV (`;`, coma decimal y BOM). Se recalcula sola cuando la revisión de 2 s (H3.2 T06) detecta un cambio de stock, mínimo o movimientos, sin ocultar la lista anterior. El bodeguero queda en su sucursal (front). Con cuatro pestañas, en el celular se desplazan de lado.
- Pruebas: `database/tests/articulos_por_comprar.sql` (sin ventas nada en A y la bebida en negativo de B; pan vendido 14, 2 por día, objetivo 12 → comprar 6 y bebida 0,286 por día → 2 con 7 días; 18 y 3 con 1 día; una venta de hace 10 días solo cuenta en 30 días (23,8 por día, 27,8 por comprar); una venta anulada deja de contar; orden; periodo 0 rechazado; permisos). Falla sin la migración y pasa con ella; siguen pasando `version_inventario.sql` y `venta_idempotente.sql`. Front: `xlsx.spec.ts` (ZIP válido con CRC, celdas de texto y número, filtro, anchos, nombres de hoja, columnas AA/AAA), `compras.model.spec.ts` (motivos, conteo, CSV y hoja), `lista-compras.spec.ts` (11), `inventario.service.spec.ts` +3, `stock-api.service.spec.ts` +1 e `inventario.spec.ts` +2 (abre con `?vista=compras` y la lista se recalcula con una venta). `features/inventario`, `core/api` y `shared/utils`: 23/23 archivos y 316/316 pruebas. `ngc` sin errores. Un .xlsx de ejemplo generado con este código abre sin errores en openpyxl y LibreOffice.

## Recetas: versiones, conexión con el descuento y prueba integral (H5.3 T06, T07 y T08) — ejecución del 27-10-2026

- **H5.3 T06** (conservar la versión usada en ventas anteriores): ya se cumplía desde H2.5 T02 (`20261020_versiones_receta.sql`): cada cambio de receta crea una versión, `trg_detalle_venta_receta_version` guarda en cada línea de venta la versión vigente y `fn_aplicar_venta` descuenta los insumos de esa versión. Editar solo afecta a las ventas futuras; la anulación devuelve lo descontado en su momento (desde el kardex).
- **H5.3 T07** (conectar recetas con H2.5 y H3.2): ya se cumplía: la receta del Maestro es la que lee la venta; con insumos descuenta ingredientes (H2.5), sin receta o sin insumos descuenta el stock propio (H3.2).
- **H5.3 T08**: `database/tests/recetas_integral_h53.sql`: (1) creación; (2) validaciones: cantidad 0, otra unidad, duplicado e ingrediente inactivo rechazados; (3) venta con la receta original (pan −2, queso −30, bebida −2 de stock propio) que guarda su versión; (4) edición (queso 40, se agrega jamón) crea versión nueva; (5) la venta siguiente usa la versión nueva (queso −40, jamón −20); (6) la venta anterior conserva su versión, su kardex (30 de queso, sin jamón) y al anularla devuelve 30 de queso, no 40; `fn_versiones_receta` muestra las versiones; (7) productos normales: la bebida sin receta ni versiones; al quitar todos los insumos el sándwich pasa a stock propio sin cambiar ventas anteriores; (8) permisos de recetas por rol. Falla sin `20261020_versiones_receta.sql` y pasa con ella; siguen pasando `validaciones_receta.sql` y `permisos_recetas.sql`. Front ya cubierto: `receta-producto-modal.spec.ts` (69 en products) y `recetas-api.service.spec.ts`.

## Panel y alertas al día sin recargar (H3.2 T06) — ejecución del 27-10-2026

- Revisión: el panel de Inventario (H3.4) y sus alertas de mínimo (H3.5) solo volvían a consultar al abrir, al reconectar y tras una acción propia; una venta hecha en el POS no se veía hasta recargar. No había canal de tiempo real (H3.4 T06 descartada: sin WebSockets).
- Decisión (27-10): consulta liviana periódica con detección de cambios.
- `database/migrations/20261027_version_inventario.sql`: `fn_version_inventario()` (STABLE, SECURITY DEFINER, para admin y bodeguero) devuelve `{stock, movimientos}`: huella md5 del stock actual y del mínimo de cada fila de `stock_sucursal` y `stock_producto_sucursal` (cambia con ventas, anulaciones, compras, ajustes, mermas y también al editar un mínimo, que no deja movimiento) y el id del último movimiento del kardex. 0,04 ms por consulta en la base de prueba.
- Inventario: mientras la pestaña está visible, cada 2 s (`INTERVALO_REVISION_MS`) pide la versión; si cambió el stock recarga las existencias sin ocultar los datos (estados, alertas y contadores se recalculan solos) y si hay movimientos nuevos refresca el reporte de mermas. Pestaña oculta: no consulta; al volver, revisa de inmediato. Si una consulta falla, mantiene los datos y sigue revisando. `StockApiService.versionInventario()` e `InventarioService.versionInventario()`.
- Pruebas: `database/tests/version_inventario.sql` (no cambia sin cambios; cambia con una venta de compuesto, una de reventa y un cambio de mínimo; liviana; permisos), falla sin la migración y pasa con ella. `inventario.spec.ts` +4 con tiempo simulado (revisa cada 2 s y recarga solo si cambió, un mínimo también recarga, pausa con la pestaña oculta, un fallo no borra los datos) y `stock-api.service.spec.ts` +1. `features/inventario` y `core/api`: 18/18 archivos y 260/260 pruebas. `ngc` sin errores.

## Prueba integral del descuento por ventas (H3.2 T07) — ejecución del 27-10-2026

- `database/tests/descuento_integral_h32.sql`, en una transacción con dos sucursales, pan y queso compartidos por sándwich y tostada, y una bebida de reventa: (1) producto normal: 2 bebidas descuentan 2 de su stock, sin ingredientes; (2) compuesto: 3 sándwiches descuentan 6 de pan y 90 de queso, sin stock propio; (3) venta mixta con ingredientes compartidos (pan −8, queso −120, bebida −1, 5 movimientos); (4) sucursales: la B queda intacta y no se vende donde no hay turno; (5) reintento con la misma clave: misma venta, sin descuento nuevo; (6) fallo a mitad de venta: se conservan todos los valores anteriores (ventas, movimientos, stock y clave) y la misma clave sirve para reintentar corregida; (7) anulación: repone exactamente lo descontado, una sola vez; (8) el kardex cuadra con el stock.
- Falla sin `20261026_venta_idempotente.sql` y pasa con todas las migraciones de H2.5 y H3.2.
- Se complementa con: `venta_concurrente.py` (concurrencia real: 320/320 ventas simultáneas sin errores), `detalle_venta_una_vez.sql` (no admite líneas nuevas en una venta ya registrada, con dos transacciones reales), `venta_concurrente.sql`, `venta_idempotente.sql`, `stock_insuficiente_venta.sql`, `reglas_consumo_receta.sql` y `reponer_stock_anulacion.sql`.

## Ventas simultáneas y sucursal de la venta (H3.2 T05) — ejecución del 27-10-2026

- Revisión: sin cantidades perdidas ya se cumplía (venta, compra, ajuste y anulación bloquean la fila de stock con `FOR UPDATE` antes de calcular el saldo) y el descuento usa `ventas.sucursal_id`, con turno abierto del cajero en esa sucursal.
- **Riesgo encontrado:** cada línea bloquea sus filas en el orden en que llegan; dos ventas con los mismos ingredientes en orden cruzado se esperaban una a la otra y PostgreSQL cortaba una con `deadlock detected`. Reproducido con `database/tests/venta_concurrente.py` (4 conexiones × 10 ventas): **17 de 40 ventas fallaron**, aunque las que entraron cuadraban.
- `database/migrations/20261027_venta_concurrente.sql`: `fn_registrar_venta_idempotente` llama antes de registrar a `fn_bloquear_stock_venta(sucursal, items)`, que crea en 0 las filas de stock que falten (como haría la venta) y bloquea todas las que tocará la venta en su sucursal, siempre en el mismo orden (ingredientes por id, luego productos sin receta por id). `fn_registrar_venta` no cambia. `fn_bloquear_stock_venta` no es ejecutable desde la API.
- Con la migración: **320 de 320 ventas simultáneas** (8 conexiones × 40) sin errores, stock exacto (harina 9360, bebida 9680) y la otra sucursal intacta; de 16 s a 0,4 s en el caso de 40 ventas.
- Prueba `database/tests/venta_concurrente.sql`: descuenta solo en la sucursal de la venta (pan y bebida de la sucursal B intactos, kardex con la sucursal correcta), no vende donde el cajero no tiene turno, el bloqueo previo solo crea filas en la sucursal de la venta y no es ejecutable por el cajero. Siguen pasando `venta_idempotente`, `detalle_venta_una_vez`, `stock_insuficiente_venta`, `reponer_stock_anulacion`, `reglas_consumo_receta`, `venta_empleado` (10/10, con datos de muestra), `movimientos_articulos`, `catalogo_integral_h33` y `validaciones_receta`.

## Consumos aplicados una sola vez por venta (H3.2 T03) — ejecución del 27-10-2026

- Revisión: los consumos por receta (H2.5) y el stock propio (H3.2) ya eran un único proceso: `fn_aplicar_venta` corre una vez por línea de `detalle_venta` dentro de la transacción de `fn_registrar_venta`. Los reintentos del POS no duplican (H2.5 T05).
- **Faltaba:** el trigger solo actúa al insertar. Verificado en producción (27-10): el admin tiene INSERT, UPDATE y DELETE sobre `detalle_venta` (cajero y bodeguero no), así que por la API se podía agregar una línea a una venta ya registrada o anulada (descontaba otra vez), cambiar producto o cantidad (el stock no se ajustaba) o borrar una línea (no se devolvía).
- `database/migrations/20261027_detalle_venta_una_vez.sql`: `trg_ventas_en_curso` (AFTER INSERT en `ventas`) marca la venta en una variable local de la transacción (`set_config(..., true)`); `trg_detalle_venta_una_vez` (BEFORE INSERT/UPDATE/DELETE en `detalle_venta`) solo acepta líneas mientras la venta está en curso y no anulada, rechaza cambiar `venta_id`, `producto_id` o `cantidad`, y rechaza borrar líneas salvo al borrar la venta completa (CASCADE). Primero se probó comparar `creado_en` con `now()`, pero falla si dos transacciones van en un mismo envío (comparten la hora de inicio); la marca de transacción no depende de eso. El front no inserta, modifica ni borra líneas de venta.
- Prueba `database/tests/detalle_venta_una_vez.sql` con dos transacciones reales: venta mixta (sándwich con receta + bebida) que descuenta una vez cada consumo; luego agregar, cambiar cantidad o producto y borrar una línea se rechazan y el stock no cambia; la anulación repone todo y a la venta anulada no se le agregan líneas; limpieza final borrando la venta completa. Falla sin la migración y pasa con ella. Siguen pasando `venta_idempotente`, `stock_insuficiente_venta`, `reponer_stock_anulacion`, `reglas_consumo_receta`, `venta_empleado`, `movimientos_articulos`, `receta_ingrediente_activo` y `validaciones_receta`.

## Prueba integral del catálogo (H3.3 T08) — ejecución del 27-10-2026

- `database/tests/catalogo_integral_h33.sql`, en una sola transacción: (1) ambos tipos en `v_articulos` con su unidad (materia prima en su unidad, producto en "un") y el producto con receta fuera de bodega; (2) duplicados de nombre y de código de barras ignorando mayúsculas y espacios; (3) unidad obligatoria y fija; (4) desactivar materia prima y producto: siguen en el catálogo como inactivos, conservan receta, stock y movimientos (`v_movimientos_articulos`), y no se pueden asociar a una receta nueva ni vender; (5) permisos: bodeguero lee el catálogo y los movimientos, crea y desactiva materias primas sin cambiar unidad ni borrar, no toca productos; cajero sin acceso.
- Falla sin `20261027_nombres_unicos_normalizados.sql` y pasa con todas las migraciones de H3.3. Pasan también, con la misma base, las pruebas de cada tarea: `modelo_articulos`, `unidad_fija_ingrediente`, `catalogo_materias_primas_bodeguero`, `nombres_unicos_normalizados`, `receta_ingrediente_activo` y `movimientos_articulos`.
- Front que cubre la historia: `ingredientes-maestro.spec.ts` (14), `catalogo.model.spec.ts`, `catalogo.service.spec.ts`, `product-master.spec.ts` (pestañas por rol, duplicados) y `movimientos-articulo.spec.ts`.

## Validaciones de la receta (H5.3 T05) — ejecución del 27-10-2026

- Revisión: cantidad positiva (`CHECK cantidad_necesaria > 0`), sin duplicados (`UNIQUE (producto_id, ingrediente_id)`), unidad base y compatible (`trg_recetas_unidad_base`, H2.5 T01) y materias primas activas (`trg_recetas_ingrediente_activo`, H3.3 T07) ya estaban en la base.
- Modal de receta: (1) al quitar el **último** insumo pide confirmar, porque el producto queda sin receta y se vende descontando su propio stock ("al menos un ingrediente"); (2) la cantidad acepta hasta 3 decimales (la columna es NUMERIC(12,3) y redondeaba sin avisar); (3) un 400 de la base muestra su mensaje (unidad, inactivo) en vez de "La cantidad debe ser mayor a 0" para todo.
- Pruebas: `database/tests/validaciones_receta.sql` (cantidad 0 y negativa, otra unidad, ingrediente inactivo, duplicado, venta con receta que descuenta el ingrediente y producto sin insumos que pasa a stock propio) y `receta-producto-modal.spec.ts` +4 (confirmar el último, quitar sin preguntar si quedan otros, cantidades válidas, mensaje de la base). `features/products`: 5/5 archivos y 69/69 pruebas.

## Campos obligatorios y duplicados ignorando mayúsculas y espacios (H3.3 T05) — ejecución del 27-10-2026

- Alcance acordado: **ingredientes y productos**, para el **nombre** y también el **código de barras** (pedido de Sebastián: cada producto suele tener código y no debe repetirse aunque cambien mayúsculas o espacios).
- `database/migrations/20261027_nombres_unicos_normalizados.sql`: `fn_nombre_normalizado` (minúsculas, sin espacios en los extremos ni repetidos) y `fn_codigo_normalizado` (mayúsculas, sin espacios), ambas IMMUTABLE; índices únicos `ux_{ingredientes,productos}_nombre_normalizado` y `ux_{ingredientes,productos}_codigo_normalizado` (parciales, solo con código); trigger `fn_limpiar_nombre_y_codigo` que guarda el nombre limpio y el código sin espacios (vacío → NULL) y rechaza un nombre vacío (22023); CHECK de nombre no vacío. El ensayo lista primero los duplicados que impedirían crear los índices.
- Bloqueo del cambio de unidad: ya se cumplía de forma más estricta (`trg_ingredientes_unidad_fija` lo rechaza siempre, 20261023).
- Front: `catalogo.model.ts` suma `limpiarNombre`, `claveNombre`, `claveCodigo` y `codigoRepetido` (las tildes sí cuentan: "Piña" ≠ "Pina", igual que la base). Pestaña Ingredientes y formulario de productos del Maestro avisan nombre o código repetido antes de guardar y envían el nombre limpio y el código sin espacios.
- Pruebas: `database/tests/nombres_unicos_normalizados.sql` (limpieza; nombre y código repetidos con otras mayúsculas o espacios rechazados en las dos tablas; nombre vacío rechazado; código vacío a NULL; editar el mismo artículo permitido; unidad fija). Falla sin la migración y pasa con ella; `modelo_articulos.sql` y `stock_insuficiente_venta.sql` siguen pasando. Front: `catalogo.model.spec.ts` +3, `ingredientes-maestro.spec.ts` +1, `product-master.spec.ts` +1. `features/products` e `inventario`: 15/15 archivos y 274/274 pruebas. `ngc` sin errores.

## Permisos y desactivación sin borrar (H3.3 T07) — ejecución del 27-10-2026

- Revisión: permisos (admin y bodeguero sobre ingredientes, con permisos por columna y sin DELETE; productos solo admin) y desactivación (`activo = false`, sin borrar recetas, movimientos ni stock) ya se cumplían. La venta (`fn_registrar_venta`) y el ingreso de facturas (`fn_ingresar_factura_xml`) ya rechazaban artículos inactivos.
- **Faltaba:** por la API se podía agregar un ingrediente inactivo a una receta (la pantalla solo ofrece activos). `database/migrations/20261027_receta_ingrediente_activo.sql`: trigger `trg_recetas_ingrediente_activo` (BEFORE INSERT o UPDATE OF ingrediente_id) que lo rechaza (22023). Las recetas que ya lo tienen se conservan: se puede editar la cantidad, vender y quitarlo.
- **Arreglo en el modal de receta:** solo cargaba ingredientes activos, así que un insumo que se desactivó después aparecía como "Insumo desconocido". Ahora carga todos (`listar(false)`), muestra el nombre con la etiqueta "Inactivo" y para agregar solo ofrece activos.
- Pruebas: `database/tests/receta_ingrediente_activo.sql` (desactivar conserva receta y stock; agregar o cambiar a inactivo rechazado; la receta anterior sigue descontando; reactivar permite volver a usarlo). Falla sin la migración y pasa con ella; `reglas_consumo_receta.sql` sigue pasando. `receta-producto-modal.spec.ts` +2. `features/products`: 5/5 archivos y 60/60 pruebas. `ngc` sin errores.

## Ingredientes al Maestro de Productos — ejecución del 27-10-2026

- `origin/develop` integrado hasta `e0622a1` (merge del PR #81). Merge sin conflictos.
- Pedido de Sebastián: las materias primas que estaban en Inventario → Catálogo pasan al **Maestro de Productos**, en dos pestañas: **Productos** e **Ingredientes**.
- Se movió el componente con `git mv` a `features/products/components/ingredientes-maestro` (antes `features/inventario/components/catalogo-articulos`), junto con `catalogo.model.ts` y `catalogo.service.ts` y sus pruebas. Ahora lista solo materias primas (`v_articulos?tipo=eq.materia_prima`): sin filtro ni columna de tipo, sin acciones de productos. Textos en "ingrediente". Conserva: búsqueda, crear/editar con unidad fija, nombre repetido, activar/desactivar sin borrar y Movimientos.
- **Inventario** queda con Existencias y Mermas y ajustes (se quitó la pestaña Catálogo; `?vista=catalogo` abre Existencias). Movimientos sigue en Existencias.
- **Maestro:** pestañas con `role="tablist"` y la pestaña en la URL (`?vista=ingredientes`). Roles: admin ve ambas y edita todo; **bodeguero** entra al Maestro (ruta y menú), ve los productos sin editarlos y administra Ingredientes; cajero sigue solo con Productos, sin pestañas. "Nuevo producto" solo en la pestaña Productos.
- `/inventario/ingredientes` redirige ahora a `/product-master?vista=ingredientes`.
- Celular: el componente define el contenedor `inventory` para usar las mismas reglas (tabla a tarjetas, controles de 44 px, diálogo desde abajo); las pestañas del Maestro ocupan el ancho con 44 px de alto bajo 640 px.
- Pruebas: `product-master.spec.ts` +3 (pestañas para admin, bodeguero sin edición de productos, cajero sin pestañas), `ingredientes-maestro.spec.ts` adaptada (13), `catalogo.service.spec.ts` adaptada, `inventario.spec.ts` (sin Catálogo), `sidebar.spec.ts` (bodeguero ve el Maestro) y `app.routes.spec.ts` (nueva redirección). `features/products`, `features/inventario`, `layout` y rutas: 17/17 archivos y 280/280 pruebas. `ngc` sin errores. Sin cambios en la base.

## Reglas de cálculo del consumo por receta (H2.5 T01) — ejecución del 27-10-2026

- `origin/develop` sin cambios desde `b92f3db`.
- Revisión de `fn_aplicar_venta` (0004): consumo = `cantidad_necesaria × cantidad vendida`, ingredientes compartidos sumados por línea, productos sin receta con stock propio (H3.2) y saldo negativo permitido ya se cumplían. **Faltaba asegurar la unidad base:** `recetas.unidad_id` es columna propia y la venta la ignora; por la API se podía guardar una receta en "g" para un ingrediente en "kg".
- `database/migrations/20261027_receta_unidad_base.sql`: trigger `trg_recetas_unidad_base` (BEFORE INSERT/UPDATE de `unidad_id` o `ingrediente_id`) que completa la unidad vacía con la del ingrediente y rechaza una distinta (22023). Verificado en producción antes: ninguna receta tenía otra unidad. No cambia la pantalla (ya envía la unidad del ingrediente).
- `docs/reglas-descuento-inventario.md`: las reglas escritas para el equipo, con ejemplo y las pruebas que las cubren.
- Prueba `database/tests/reglas_consumo_receta.sql`: unidad completada, unidad distinta rechazada al crear y al editar, editar la cantidad permitido; venta con pan y empanada que comparten harina (0,900 kg), queso en negativo (−20 g) y bebida sin receta (−1 un). Falla sin la migración y pasa con ella; `stock_insuficiente_venta.sql` y `reponer_stock_anulacion.sql` siguen pasando.

## Venta idempotente y pruebas del descuento al vender (H2.5 T05 y T07) — ejecución del 26-10-2026

- **Problema encontrado:** el POS no enviaba ningún identificador por venta. Si la base guardaba la venta pero la respuesta no llegaba (corte de red o los 15 s de espera), el carrito seguía lleno y al volver a cobrar quedaban dos ventas y el inventario descontado dos veces.
- **Base:** `database/migrations/20261026_venta_idempotente.sql`. Tabla `ventas_idempotencia` (clave UUID, venta, cajero; sin acceso para los roles de la app) y `fn_registrar_venta_idempotente(p_clave, …mismos parámetros…)`, SECURITY DEFINER, para admin y cajero. Bloquea la clave (`pg_advisory_xact_lock`), devuelve la venta original si la clave ya existe y, si no, llama a `fn_registrar_venta` sin cambios y guarda la clave en la misma transacción. Rechaza la clave de otro cajero y una clave vacía. **No modifica `fn_registrar_venta`.**
- **POS:** `VentasApiService.registrar` llama a la función nueva con `p_clave`. `PosService` genera un UUID por venta (`shared/utils/clave-unica.ts`) y lo reutiliza solo si se reintenta la misma venta (mismo carrito, medio de pago, cajero y sucursal); al confirmarse o al cambiar la venta, la clave es nueva. El descuento de inventario sigue siendo el de siempre: `fn_aplicar_venta` dentro de la misma transacción, sin pasos manuales.
- **H2.5 T07 — `database/tests/venta_idempotente.sql`:** (1) cantidades múltiples con pan y queso compartidos por sándwich y tostada, y stock insuficiente (queso −20, bebida −2); (2) reintento con la misma clave: misma venta, sin ventas ni movimientos nuevos; (3) venta con un producto inexistente: no deja venta, descuento ni clave, y la misma clave sirve para reintentar ya corregida; (4) clave de otro cajero rechazada; (5) sin clave, rechazada; (6) venta de 20 líneas con 40 movimientos: **10,5 ms** en el Postgres local (máximo 2 s); permisos. Falla sin la migración y pasa con ella. Los casos de `stock_insuficiente_venta.sql` siguen vigentes.
- Pruebas nuevas en `pos.service.spec.ts` (+3): UUID por venta y otro para la siguiente; reintento tras un fallo con la misma clave y el carrito intacto; venta cambiada antes de reintentar lleva clave nueva. `features/pos`, `core/api` y rutas: 14/14 archivos y 137/137 pruebas. `ngc` sin errores.
- **Orden de despliegue:** aplicar la migración en el VPS antes de publicar el front; el POS nuevo llama a `fn_registrar_venta_idempotente`.

## Relación entre ventas y movimientos (H3.2 T01) y permisos de recetas (H5.3 T03) — ejecución del 26-10-2026

- `origin/develop` sin cambios desde `b92f3db`.
- **H3.2 T01 — base:** `database/migrations/20261026_movimientos_articulos.sql`, vista `v_movimientos_articulos`: una fila por movimiento del kardex con tipo, venta (`venta_id`), artículo y tipo de artículo (de `v_articulos`, H3.3), cantidad, unidad, stock resultante, fecha y sucursal. Un producto que vendió como reventa y después recibió receta conserva sus movimientos antiguos (nombre desde `productos`, unidad "un"). SELECT para admin y bodeguero, no para cajero. Ensayo en producción revisado el 26-10 (ventas 34 a 68, con anulaciones y materias primas en g). Prueba `database/tests/movimientos_articulos.sql`.
- **H3.2 T01 — pantalla:** botón "Movimientos" en cada fila de Existencias (historial de esa sucursal) y del Catálogo (todas las sucursales). Diálogo `components/movimientos-articulo` con fecha y hora, tipo, origen ("Venta #67", "Anulación de la venta #49", "Factura #12", "Ajuste manual"), cantidad con signo y unidad, stock resultante y sucursal; filtros por tipo; los 100 más recientes. Celular: tarjetas, filtros de 44 px y la tercera acción de Existencias baja de línea si no cabe.
- **H5.3 T03:** `RecetasApiService` ya tenía consultar, agregar, editar (solo cantidad), quitar y versiones, con sus pruebas, y el botón Receta es solo para admin. Permisos verificados en producción el 26-10: admin con SELECT/INSERT/UPDATE/DELETE en `recetas`; cajero y bodeguero sin escritura (el bodeguero lee solo `producto_id`); las ventas del cajero pasan por `fn_registrar_venta` (SECURITY DEFINER). Queda fijado en `database/tests/permisos_recetas.sql`. Se corrigió un comentario fuera de lugar en `recetas-api.service.ts`.
- Pruebas nuevas: `movimientos.model.spec.ts` (3), `movimientos.service.spec.ts` (2), `movimientos-articulo.spec.ts` (5), `catalogo-articulos.spec.ts` +1, `inventario.spec.ts` +1. `features/inventario`: 13/13 archivos y 234/234 pruebas. `ngc` sin errores. Las dos pruebas SQL pasan en el Postgres local.

## Retiro de la pantalla antigua de Ingredientes (H3.3 T04) — ejecución del 25-10-2026

- `origin/develop` sin cambios desde `b92f3db`.
- `/inventario/ingredientes` ahora redirige a `/inventario?vista=catalogo`, así los enlaces guardados abren la pestaña Catálogo. La ruta ya no tiene guard propio: lo aplica `/inventario` (admin y bodeguero, igual que antes).
- Se elimina `src/app/features/ingredientes/` (`catalogo-ingredientes` y sus rutas). No tenía pruebas ni entrada en el menú; nadie más la importaba (`ngc` y `tsc` del spec sin errores).
- Inventario guarda la pestaña en la URL (`?vista=mermas` / `?vista=catalogo`; Existencias sin parámetro) con `replaceUrl`, para no llenar el historial. Al recargar se mantiene la pestaña; un valor desconocido abre Existencias (`vistaDesdeUrl`).
- `IngredientesApiService` se mantiene: lo usa el Catálogo.
- Pruebas nuevas: `app.routes.spec.ts` +1 (redirección con `RouterTestingHarness`) e `inventario.spec.ts` +3 (valores válidos de la URL, apertura directa del Catálogo y la URL al cambiar de pestaña). `features/inventario`, `core`, `layout` y rutas: 25/25 archivos y 316/316 pruebas. `ngc` sin errores.

## Catálogo de Inventario conectado a la base (H3.3 T03) — ejecución del 25-10-2026

- `origin/develop` integrado hasta `b92f3db` (merge del PR #80: iconos Lucide en caja y POS, stock mínimo para bodeguero y `creado_en` con zona horaria). Merge sin conflictos.
- `services/catalogo.service.ts` deja los datos de ejemplo y usa la base:
  - Listado desde la vista `v_articulos` (materias primas y productos sin receta), ordenado por nombre; unidades desde `UnidadesMedidaApiService`.
  - Crear y editar materias primas con `IngredientesApiService` (`crear` / `actualizar`). Al editar solo se envían nombre y código de barras: la unidad nunca viaja, y si alguien la cambia por la API el trigger `trg_ingredientes_unidad_fija` lo rechaza.
  - Activar o desactivar con `IngredientesApiService.actualizarEstado` (materias primas) o `ProductosApiService.actualizarEstado` (productos). No se borra nada.
  - Después de cada cambio se vuelve a leer la fila desde `v_articulos`, así la pantalla muestra lo que quedó guardado, incluida la abreviatura de la unidad.
  - Errores en palabras simples: nombre repetido (409), sin permisos (401/403), sin conexión (0) y el mensaje de la base en los 400 (por ejemplo el del trigger de unidad fija).
- `IngredientesApiService.actualizar` acepta cambios parciales (`Partial<IngredienteActualizacion>`), para no pisar la categoría ni el estado al editar desde el Catálogo. La pantalla antigua de Ingredientes sigue enviando todos los campos, sin cambios.
- Pantalla: sin la etiqueta "Datos de ejemplo"; si falla activar o desactivar, se avisa en una franja roja y la fila queda como estaba. Se quitó `enUso` del modelo (no se usaba: la unidad queda fija siempre).
- Errores 409: distingue nombre repetido de código de barras repetido (ambos son UNIQUE en `ingredientes`).
- **Hallazgo de permisos (25-10, verificado en producción):** `nury_bodeguero` solo tenía SELECT sobre `ingredientes`, `productos` y `unidades_medida`, sin INSERT, UPDATE ni uso de `ingredientes_id_seq`. Al bodeguero le fallaba guardar también en la pantalla antigua de Ingredientes. Se agrega `database/migrations/20261025_catalogo_materias_primas_bodeguero.sql` (**aplicada en producción el 25-10**; ensayo verificado: permisos nuevos en true y unidad, costo y `productos.activo` en false): INSERT (nombre, unidad_id, categoria_id, codigo_barras), UPDATE (nombre, codigo_barras, activo, categoria_id) y USAGE de la secuencia. Nunca `unidad_id` ni `costo_unitario_promedio`, sin DELETE. Prueba `database/tests/catalogo_materias_primas_bodeguero.sql`: falla sin la migración y pasa con ella (Postgres de prueba con los permisos de lectura del VPS).
- Productos de reventa (decisión del 25-10): el bodeguero los ve pero no los activa ni desactiva, porque eso los saca de la venta en el POS; en su lugar ve "Lo gestiona el administrador". Sin permisos nuevos en `productos`.
- Probado en el front (`npm start`) con un usuario bodeguero, en computadora y celular: listado real, crear, editar con unidad bloqueada, nombre repetido, desactivar/activar y productos con "Lo gestiona el administrador".
- Pruebas nuevas: `catalogo.service.spec.ts` (9) y `catalogo-articulos.spec.ts` +1 (falla al cambiar estado) con el caso del bodeguero ampliado. `features/inventario` y `core/api`: 18/18 archivos y 265/265 pruebas. `ngc` sin errores.

## Sección Catálogo en Inventario (H3.3 T01) y ajuste de stock en celular — ejecución del 21-10-2026

- `origin/develop` integrado hasta `eac4d6b` (merge del PR #76, H3.3 T02).
- Pestaña nueva **"Catálogo"** en Inventario, junto a Existencias y Mermas y ajustes (`components/catalogo-articulos`):
  - Listado con nombre (y código de barras), tipo (materia prima / producto), unidad y estado (activo / inactivo), ordenado por nombre.
  - Búsqueda sin tildes por nombre o código de barras y filtro por tipo con conteo; "Limpiar filtros" cuando no hay coincidencias; carga con esqueleto y error con "Reintentar".
  - Modal de materia prima (crear y editar): nombre obligatorio y sin repetir, unidad obligatoria y fija desde la creación (criterio de H3.3: queda asociada permanentemente; al editar siempre está bloqueada) y código de barras opcional.
  - Productos normales: solo se listan y se activan o desactivan; "Editar en el Maestro" solo para admin (el bodeguero no tiene acceso al Maestro).
  - Desactivar no borra: el artículo queda inactivo y conserva su historial.
  - **Datos de ejemplo** (`services/catalogo.service.ts`, con la etiqueta en pantalla): H3.3 T03 lo conecta a `v_articulos` y a guardar.
  - Celular: usa las reglas compartidas de Inventario (`@container inventory`): la tabla pasa a tarjetas, campos de 16 px, botones de 44 px y el modal se abre desde abajo.
- Modal "Ajustar stock" en celular (≤ 640 px): se abre desde abajo como los otros diálogos, campos de 16 px (sin zoom del iPhone) y botones de 44 px. Sin cambios en computadora.
- Revisado contra los criterios de aceptación de H3.3 (nombre único y unidad obligatorios, sin duplicados, unidad permanente, edición sin perder historial, listado con unidad para el bodeguero): cumple en pantalla y en la base:
  - `database/migrations/20261023_unidad_fija_ingrediente.sql` (**aplicada en producción el 23-10**; verificado: cambiar la unidad del Queso da "no se puede cambiar: queda fija desde que se crea la materia prima"): el trigger `trg_ingredientes_unidad_fija` rechaza siempre el cambio de unidad, no solo cuando la materia prima está en uso. Prueba `database/tests/unidad_fija_ingrediente.sql` (2 casos; falla sin la migración y pasa con ella). `modelo_articulos.sql` actualizado a la regla nueva.
  - `database/migrations/20261023_unidad_lamina.sql` (**aplicada el 23-10**): unidad "Lámina" (`lám`), que pedía el criterio entre sus ejemplos.
- Pruebas nuevas: `catalogo.model.spec.ts` (4) y `catalogo-articulos.spec.ts` (10); `inventario.spec.ts` +1 (tercera pestaña). `features/inventario`: 9/9 archivos y 209/209 pruebas. `ngc` sin errores.

## Modelo de artículos del Catálogo de Inventario (H3.3 T02) — ejecución del 21-10-2026

- Antes de empezar se integró `origin/develop` hasta `96229ac` (avance rápido: PR #73 de Patricio, reporte real de ajustes y mermas, y PR #75 de Nelson, facturas XML).
- Un **artículo** es lo que tiene stock propio en bodega; no es una tabla nueva. Migración `database/migrations/20261021_modelo_articulos.sql` (**aplicada en producción el 21-10**: ensayo y real sin errores; `v_existencias_articulos` devolvió materias primas con su unidad y productos sin receta en "un", sin el sándwich con receta):
  - `v_articulos`: tipo (`materia_prima` desde `ingredientes`, `producto` desde `productos` sin receta), id, nombre, unidad (la del ingrediente; "un" para productos, que no se venden por peso), código de barras, activo y fecha de creación.
  - `v_existencias_articulos`: existencias de cada artículo por sucursal (`stock_sucursal` / `stock_producto_sucursal`) con unidad, stock y mínimo.
  - Ambas leen con los permisos de su dueño y solo admin y bodeguero pueden consultarlas: en producción el bodeguero **no tiene lectura sobre `recetas`** (ni a nivel de columna, verificado el 21-10) y la vista la necesita para excluir los productos con receta. No expone ingredientes ni cantidades de recetas.
  - Trigger `trg_ingredientes_unidad_fija`: la unidad de una materia prima con recetas, movimientos o stock no se puede cambiar (antes solo lo cuidaba la pantalla de ingredientes).
- Prueba SQL `database/tests/modelo_articulos.sql` (5 casos): catálogo con unidad e inactivos, producto con receta excluido, existencias por sucursal, unidad fija solo en uso y permisos, con el bodeguero consultando sin lectura sobre `recetas`. Mutación verificada: si los productos con receta entran al catálogo, falla el caso 2. `versiones_receta.sql` y `ajuste_stock_permisos.sql` siguen en PASS.
- Decisión para T01/T03/T04 (Sebastián, a prueba): en el Catálogo se crean y editan materias primas; los productos normales se listan y desactivan, y para crearlos o editarlos se va al Maestro de Productos (precio de venta). Si no resulta, se descarta.
- **Hallazgo:** como el bodeguero no puede leer `recetas`, hoy le fallan tres pantallas que consultan `GET /recetas?select=producto_id` para descartar productos con receta: el panel de Inventario (`InventarioService.listarExistencias`), el modal "Ajustar stock" (`AjusteInventario`) y la carga de facturas XML (`CargaFactura`). Con admin funcionan. **Resuelto el 21-10:** `GRANT SELECT (producto_id) ON recetas TO nury_bodeguero` aplicado en producción y verificado (`producto_id` true, `cantidad_necesaria` false); queda registrado en `database/migrations/20261021_permiso_recetas_bodeguero.sql` con su prueba `database/tests/permiso_recetas_bodeguero.sql`. A futuro esas pantallas pueden pasar a `v_articulos` / `v_existencias_articulos` (H3.3 T03).
- Sin cambios de Angular en esta tarea.

## Versión de receta usada en cada venta (H2.5 T02) — ejecución del 20-10-2026

- `origin/develop` sin cambios nuevos al empezar (`05608ee`). Nelson_Branch2 trae solo facturas XML: no toca recetas ni ventas.
- Decisión de Sebastián: se guarda la receta actual de cada producto compuesto como una versión y cada edición crea una versión nueva.
- Migración `database/migrations/20261020_versiones_receta.sql` (**no aplicada en el VPS**):
  - Tablas `recetas_version` (producto, número, vigente desde, creada por) y `recetas_version_detalle` (copia de los insumos). `recetas` sigue siendo la receta editable: el Maestro de Productos no cambia.
  - Trigger en `recetas`: cada cambio crea una versión con la copia completa; una sentencia de varias filas crea una sola y un cambio que deja la receta igual no crea ninguna. Quitar todos los insumos deja una versión vacía (el producto pasa a reventa). Guarda quién editó (`fn_usuario_actual_id`).
  - Las recetas existentes quedan como versión 1.
  - `detalle_venta.receta_version_id`: un trigger `BEFORE INSERT` guarda la versión vigente (la decide la base, no el cliente) y `fn_aplicar_venta` descuenta los insumos de esa versión, no de `recetas`. Así lo descontado y lo registrado coinciden aunque la receta se edite durante la venta. Cambio sobre la de 0004 limitado a 3 líneas (diff revisado).
- `fn_versiones_receta(p_producto_id)`: historial para el Maestro (número, vigente desde, autor, insumos y qué se agregó, quitó o cambió respecto de la versión anterior), `SECURITY DEFINER` para no dar lectura sobre `usuarios`; admin y cajero (los roles del Maestro).
- Maestro de Productos: el modal de receta muestra en una línea "Versión N desde el … · autor", debajo lo que cambió ("Queso 50 → 100 g", "+ Palta 30 g", "− Pan 2 un") y un "Ver versiones anteriores" plegado con los cambios de cada una. Se vuelve a pedir tras agregar, cambiar o quitar un insumo. Si la base todavía no tiene la función, la línea no se muestra y el modal funciona igual.
- Prueba SQL `database/tests/versiones_receta.sql` (8 casos): versión 1 al crear la receta, venta con su versión y descuento correcto, edición con autor y sin versión duplicada, agregar y quitar insumos con historial de la venta anterior, reventa sin versión, receta vaciada como reventa y versión enviada por el cliente ignorada, e historial del Maestro (orden, autor, insumos, cambios de cada versión, versión vacía, reventa sin versiones y permisos). Carga inicial probada aparte (receta previa → versión 1 con sus 2 insumos). Mutación verificada: sin la comparación de "receta igual", falla el caso 1.
- Los tests SQL de anulación, stock insuficiente, permisos e idempotencia del ajuste siguen en PASS con la migración.
- `recetas-api.service.spec.ts` pasa de 4 a 5 y `receta-producto-modal.spec.ts` (suite nueva, 6): línea de versión con sus cambios, historial plegado con los de cada versión, versión que deja el producto sin insumos, sin historial con una versión, recarga tras editar, base sin la función y producto simple.
- Resultado: `features` 360/360 (inventario + productos 196, POS + caja + auth + anulación + gestión 164). El grupo `core`/`layout`/`shared`/`app` (96) no pudo arrancar en la VM en esta última corrida ("Timeout waiting for worker"); pasó completo antes del cambio de los cambios por versión, y solo cambió la interfaz `VersionRecetaApi`. **Pendiente: `npm test` completo en la máquina de Sebastián.**

## Integración con `develop` (PR #71), aviso de stock insuficiente (H2.5 T04) y cantidades enteras en el ajuste — ejecución del 20-10-2026

- Se integró `origin/develop` hasta `05608ee` (PR #71 de Patricio: consulta real de existencias, mínimo en la base, sucursales según permisos y ajuste idempotente con la `0008`). Conflictos resueltos en `ajuste-inventario.spec.ts`, `inventario.service.spec.ts` y este registro, conservando las pruebas de ambos lados:
  - La prueba del 403 del modal se reescribió con los helpers de Patricio y el mensaje nuevo de `fallo-ajuste.ts`.
  - Las 3 pruebas del ajuste simulado de `InventarioService` quedan eliminadas (como en `develop`); la prueba de tiempo de respuesta de T09 se adaptó a la consulta real.
  - `database/tests/ajuste_stock_permisos.sql` usa la firma nueva de `fn_ajustar_stock` (con `uuid`).
- H2.5 T04: `fn_stock_insuficiente_venta` (migración `20261017_stock_insuficiente_venta.sql`, **no aplicada en el VPS**) y aviso en el modal de pago. `pos.service.spec.ts` pasa de 27 a 30, `payment-modal.component.spec.ts` de 19 a 21 y `ventas-api.service.spec.ts` de 9 a 10.
- Productos de reventa solo con cantidades enteras en el ajuste: 1 prueba nueva en `ajuste-inventario.spec.ts`.
- `ajuste_stock_idempotente.sql` de Patricio, que no se había podido ejecutar, pasa sus 6 casos con la `0008` en la base de prueba.
- Resultado: 35/35 suites y 449/449 pruebas.

## Reintentos del ajuste de stock sin aplicarlo dos veces (H3.6 T06) — ejecución del 17-10-2026

- `origin/develop` sin cambios nuevos al empezar.
- Base: `database/migrations/0008_ajuste_stock_idempotente.sql` agrega `clave_idempotencia` (UUID, índice único) a `movimientos_stock` y el parámetro `p_clave` a `fn_ajustar_stock`. Con la misma clave y los mismos datos devuelve el movimiento ya registrado sin tocar el stock; con otros datos lo rechaza (22023). Sin clave funciona como antes. **No aplicada en el VPS.**
- Prueba SQL: `database/tests/ajuste_stock_idempotente.sql` (6 casos, termina en `ROLLBACK`). **No ejecutada:** esta máquina no tiene Docker ni `psql`. Debe correrse en una base de pruebas antes de aplicar la 0008.
- Pantalla: el modal `ajuste-inventario` genera una clave por ajuste (`nuevaClave`, UUID v4 también fuera de https) y la repite si se reintenta con los mismos datos. Los errores se interpretan con `fallo-ajuste.ts` (antes sin uso): distingue sin conexión, sesión vencida, permisos y función no publicada, y en los rechazos de la base muestra el texto de `fn_ajustar_stock`. Ante un corte, el botón pasa a "Reintentar ajuste" y los datos quedan en el formulario. Con stock insuficiente o artículo inexistente vuelve a consultar el stock. Se eliminó `mensajeDeError`.
- `ajuste-inventario.spec.ts` pasa de 13 a 18: reintento tras un corte con la misma clave, clave nueva si cambian los datos, texto de la base y stock refrescado con 23514, sesión vencida y UUID sin `randomUUID`.
- `fallo-ajuste.spec.ts` pasa de 17 a 18: mensajes de datos inválidos con el texto de la base, stock negativo con el texto de la base y mensaje de conexión que no promete que no pasó nada.
- `stock-api.service.spec.ts` sigue en 8: el envío incluye `p_clave`.
- Resultado: 35/35 suites y 434/434 pruebas en 2 corridas consecutivas. `npm run build` aprobado, 0 errores y 0 advertencias.
- No se probó en el navegador: la pantalla usa la API compartida del VPS, donde la 0008 no está aplicada, y probarla ahí registraría ajustes reales.

## Reporte de mermas conectado a la base (H3.6 T07) y casos límite del panel de stock (H3.5 T09) — ejecución del 20-10-2026

- **Comando:** `npm test -- --watch=false --reporters=verbose`; `npm run build`.
- **Resultado:** 35 suites, 462/462 aprobadas en 3 corridas consecutivas; build con 0 errores y 0 advertencias.
- **H3.6 T07** (`listarMermas()` lee `movimientos_stock`: ajustes y mermas con cantidad negativa, con artículo, sucursal y usuario):
  - `stock-api.service.spec.ts` pasa de 8 a 10: parámetros de `listarSalidasManuales` con y sin sucursal.
  - `inventario.service.spec.ts` pasa de 17 a 21: se quitó la prueba de los datos de ejemplo; se agregaron el mapeo de un ingrediente y un producto, el admin con la sucursal del filtro o con todas, `hasta` enviado como el día siguiente (31-12 → 01-01), el bodeguero forzado a su sucursal y el bodeguero sin sucursal.
  - `reporte-mermas.spec.ts` pasa de 13 a 15: mensaje de falta de permiso con 403 (sin Reintentar) y "—" cuando el ajuste no tiene usuario.
- **H3.5 T09** (solo pruebas, sin cambios de código de producción):
  - `inventario.model.spec.ts` pasa de 21 a 24: stock negativo con mínimo 0, stock igual al mínimo con 3 decimales, faltante de 0,001 y conteo de agotados con mínimo 0.
  - `fallo-minimo.spec.ts` pasa de 9 a 11: 403 sin código y 22P02 con el mensaje genérico.
  - `inventario.spec.ts` pasa de 60 a 74: más mínimos inválidos (espacios, `-0,5`, `1e3`, `1000000000`) y válidos (punto decimal, espacios, 3 decimales, máximo de NUMERIC(12,3)), artículo agotado que sigue con alerta con mínimo 0, y el mismo artículo en dos sucursales (estado, alerta y conteo por sucursal; el mínimo solo cambia en la fila editada).
  - Cobertura revisada contra la tarjeta: los filtros combinados, "superior al mínimo" y los permisos de lectura por rol ya estaban cubiertos.
- **Otro cambio en el inventario:** `ajuste-inventario.spec.ts` figura con 19 (antes 18) por la prueba de `3e7ff94` (solo cantidades enteras al ajustar productos de reventa), que llegó con `develop`; no es de estas tareas.
- **Hallazgo sin corregir:** `validarMinimo('-0')` rechaza el valor con "Usa como máximo 3 decimales." en vez de "El mínimo no puede ser negativo.". No hay riesgo de datos.
- **Sin probar en el navegador contra la API real:** la consulta de mermas se verificó con pruebas y build; falta abrir el reporte con sesión de admin.
- **Ajuste del mismo día (filtro por tipo y hora UTC):** el reporte pasó a mostrar todos los ajustes manuales (entradas y salidas, con signo) y a tener el filtro "Todos los ajustes" / "Solo mermas"; las fechas de la base se leen como UTC y se muestran en hora de Chile. 466/466 y build sin advertencias.
  - `stock-api.service.spec.ts` sigue en 10: sin filtro por signo, límites con hora UTC y `tipo_movimiento=eq.merma` con "Solo mermas".
  - `inventario.service.spec.ts` pasa de 21 a 22: mapeo con signo, clase y hora UTC; fecha que ya trae zona; medianoche local convertida a UTC en los dos extremos del periodo.
  - `reporte-mermas.spec.ts` pasa de 15 a 18: totales que separan salidas y entradas, vista "Solo mermas" (consulta, conteo y estado vacío) y entradas con signo +.
  - **Verificado en el navegador** el 20-10-2026 con sesión de admin contra la API real: 10 ajustes en los últimos 7 días, horas en hora de Chile (el ajuste de las 17:50 aparece a las 17:50), "Registrado por" con el usuario en los ajustes nuevos y "—" en los antiguos, y "Solo mermas" vacío porque la base aún guarda todo como `ajuste`.

## Limpieza del ajuste simulado en `InventarioService` — ejecución del 17-10-2026

- `origin/develop` sin cambios nuevos al empezar.
- El ajuste real lo registra `AjusteInventario` con `fn_ajustar_stock`, así que `InventarioService.registrarAjuste` (simulado en memoria) ya no tenía uso fuera de sus pruebas. Se eliminaron el método, su estado (`existencias`, `resultadosPorClave`, `reemplazar`), el helper `errorPostgrest` y los tipos `SolicitudAjuste` y `ResultadoAjuste`. El reporte de mermas sigue con datos de ejemplo.
- `inventario.service.spec.ts` pasa de 20 a 17: se quitaron las 3 pruebas del ajuste simulado (descuento, reintento idempotente y rechazo por stock insuficiente). Los rechazos reales de `fn_ajustar_stock` ya los cubre `fallo-ajuste.spec.ts`. La idempotencia no tiene reemplazo: `fn_ajustar_stock` no recibe clave de idempotencia (queda registrado como pendiente).
- `inventario.spec.ts` sigue en 60: solo se quitó `registrarAjuste` del doble del servicio.
- Resultado: 35/35 suites y 428/428 pruebas. `npm run build` aprobado, 0 errores y 0 advertencias.

## Panel por dispositivo y sucursales según permisos (H3.4 T08) — ejecución del 16-10-2026

- `origin/develop` sin cambios nuevos al empezar.
- Sucursales según permisos:
  - El modal de ajuste (`ajuste-inventario`) cargaba todas las sucursales activas, así que un bodeguero podía ajustar stock de otra tienda. Ahora usa la misma regla del panel (`sucursalesAutorizadas`): el admin elige entre todas; el bodeguero solo ve la suya y queda elegida; sin sucursal no ve ninguna y se le explica por qué.
  - El encabezado del panel nombra lo que se consulta: "en todas las sucursales" para el admin y "de {su sucursal}" para el bodeguero.
  - El filtro de sucursal ya se ocultaba cuando hay una sola.
- Bodeguero sin sucursal: Patricio indicó que no deberían existir usuarios así. La base solo lo impedía para el cajero (`CHECK (rol <> 'cajero' OR sucursal_id IS NOT NULL)`) y el formulario de usuarios también. Ahora el formulario exige sucursal al cajero y al bodeguero; el admin puede quedar sin ella. El panel mantiene su mensaje por si aparece uno creado directo en la base. Consulta de solo lectura: hoy ningún usuario activo está sin sucursal.
- Dispositivos, revisado en vivo con datos reales: a 375 px (teléfono) tarjetas de una columna, botones y filtros de 44 px, sin desplazamiento horizontal, modal del mínimo como hoja inferior y modal de ajuste desplazable hasta "Aplicar ajuste"; a 768 px (tablet) tarjetas en dos columnas; a 1280 px tabla completa. No hizo falta cambiar estilos.
- `ajuste-inventario.spec.ts` pasa de 10 a 13: admin con todas las sucursales, bodeguero limitado a la suya y preseleccionada, y bodeguero sin sucursal.
- `gestion-negocio.spec.ts` pasa de 1 a 5: cajero y bodeguero sin sucursal rechazados, bodeguero con sucursal creado y admin sin sucursal permitido.
- `inventario.spec.ts` pasa de 57 a 60: encabezado para bodeguero, admin y bodeguero sin sucursal.
- Resultado: 35/35 suites y 431/431 pruebas en 2 corridas consecutivas. `npm run build` aprobado, 0 errores y 0 advertencias.

## Edición del mínimo conectada a la base (H3.5 T05) — ejecución del 16-10-2026

- `origin/develop` sin cambios nuevos al empezar (rama en `8d42e58`).
- El mínimo se guarda en la base:
  - `StockApiService.actualizarMinimo` hace un PATCH solo de `stock_minimo` en `stock_sucursal` o `stock_producto_sucursal`, filtrando por artículo y sucursal, y devuelve el valor guardado (`null` si la fila no existe). No toca `stock_actual`, así que no interfiere con ventas ni ajustes simultáneos.
  - `InventarioService.actualizarMinimo` usa `articuloId` y `sucursalId` de la existencia y falla con `MinimoSinFilaError` si la fila ya no está.
  - `interpretarFalloMinimo` (`features/inventario/models/fallo-minimo.ts`) da un mensaje por fallo: sin conexión, sesión vencida, sin permiso (403), mínimo negativo (23514, para cuando exista la restricción de H3.5 T02), número fuera de rango (22003), fila inexistente (además vuelve a consultar las existencias) y error del servidor. Todos aclaran que el mínimo no se modificó.
  - Las validaciones del formulario (vacío, negativo, no numérico, más de 3 decimales y máximo de NUMERIC(12,3)) se mantienen.
- `stock-api.service.spec.ts` pasa de 6 a 8: PATCH del producto (método, cuerpo, filtros, `select` y `Prefer`) y fila inexistente del ingrediente.
- `fallo-minimo.spec.ts` (suite nueva, 9): cada estado y código, y la fila inexistente que pide actualizar.
- `inventario.service.spec.ts` pasa de 17 a 20: producto, materia prima y fila inexistente.
- `inventario.spec.ts` pasa de 55 a 57: mensaje de permiso y reconsulta cuando la fila ya no existe.
- Verificación contra `api.nury.cl` con la sesión de admin de Patricio, solo en "Nury Providencia (Equipo de desarrollo)":
  - Permiso: un PATCH con filtro que no coincide con ninguna fila (id −1) respondió 200 en ambas tablas, sin modificar nada.
  - CHAPARRITA con mínimo 10: la base guardó 10 con `stock_actual` intacto (6), la fila pasó a "Crítico" con "Faltan 4 un para el mínimo" y el aviso sumó "1 en estado crítico".
  - Se restauró a 0 desde el mismo panel: la base volvió a 0 y la alerta de crítico desapareció.
- Resultado: 35/35 suites y 421/421 pruebas en 2 corridas consecutivas. `npm run build` aprobado, 0 errores y 0 advertencias.

## Consulta real de existencias en Inventario (H3.4 T03 y T04) — ejecución del 16-10-2026

- Antes de empezar se integró `origin/develop` hasta `5740f59` (avance rápido). Durante el trabajo Sebastián subió a `develop` el PR #68 (`cbec80c`), que tocaba los mismos archivos del panel. Para no mezclar, Patricio pidió descartar los cambios locales (se guardó un respaldo), traer `develop` hasta `2feb292` (avance rápido, sin conflictos) y rehacer el trabajo encima.
- Lo que trae `develop`:
  - Sebastián (PR #67 y #68): el ajuste real de stock (`fn_ajustar_stock`) se abre como modal desde "Ajustar stock" y desde "Ajustar" en cada fila (`ajuste-inventario`, 10 pruebas). Se eliminaron la pestaña "Ajuste de stock" y el formulario de descuento de ejemplo (`components/ajuste-stock` y sus 41 pruebas).
  - Antes ya habían llegado la reposición de stock al anular (`0007`, Sebastián) y la venta a empleado (H2.12, Maher).
  - Con eso la base quedó en 387 pruebas y 34 suites, todas aprobadas.
- El panel deja los datos de ejemplo y lee el stock real:
  - `StockApiService.listarStockIngredientes` y `listarStockProductos` consultan `stock_sucursal` y `stock_producto_sucursal` con el nombre del artículo, la unidad (solo ingredientes) y la sucursal. Solo incluyen artículos y sucursales activos (`!inner`) y, si se indica, una sola sucursal.
  - `InventarioService.listarExistencias` une ambas, deja fuera las filas de productos con receta (descuentan ingredientes), usa "un" como unidad de los productos y ordena por sucursal y artículo. Solo lista filas que ya existen: no completa con ceros los artículos sin stock registrado (decisión de Patricio).
  - Sucursales autorizadas (`sucursalesAutorizadas`): el admin ve todas; el bodeguero, solo la suya; sin sucursal asignada no se consulta nada y el panel lo explica. La base todavía no restringe la lectura por sucursal.
  - `ExistenciaStock` suma `articuloId` (ingrediente_id o producto_id) para conectar el mínimo.
  - Se quitó la etiqueta "Datos de ejemplo" de Existencias; el reporte de mermas la mantiene.
- El faltante para el mínimo (H3.5 T06) ya no aparece con mínimo 0, porque con stock negativo solo repetía el descuadre.
- `stock-api.service.spec.ts` pasa de 4 a 6: parámetros de las dos consultas, con y sin sucursal.
- `inventario.service.spec.ts` pasa de 4 a 17:
  - Sucursales autorizadas por rol (5).
  - Mapeo de ingredientes y productos con números en texto, orden, filas por sucursal, exclusión de productos con receta y unidad vacía.
  - Consulta del admin y del bodeguero, y bodeguero sin sucursal.
  - Las pruebas de las mermas y del descuento de ejemplo se mantienen sin depender de la consulta.
- `inventario.spec.ts` pasa de 52 a 55: bodeguero sin sucursal, sin etiqueta de datos de ejemplo y faltante oculto con mínimo 0.
- Verificación contra `api.nury.cl` con la sesión de admin de Patricio (solo lectura):
  - 8 filas reales de "Nury Providencia (Equipo de desarrollo)": 7 productos y 1 ingrediente (Queso, en g).
  - 6 empanadas como "Agotado" con descuadre, el aviso de 6 agotados y sin faltantes con mínimo 0.
  - "Ajustar" en la fila de CHAPARRITA abre el modal de Sebastián con el artículo elegido y su stock real (6). Se cerró sin guardar.
- Resultado: 34/34 suites y 405/405 pruebas en 2 corridas consecutivas. `npm run build` aprobado, 0 errores y 0 advertencias.

## Pruebas del panel de Inventario: actualización, tiempo de respuesta, reconexión, permisos, sucursales y estados (H3.4 T09) — ejecución del 16-10-2026

- Antes de empezar se sincronizó con `origin/develop` (sin cambios nuevos, `5740f59`).
- Contexto: desde el 16-10 el botón "Ajustar stock" del panel y el de cada fila abren como modal el ajuste real (`AjusteInventario`, `fn_ajustar_stock`). Se eliminó el modal de ejemplo `components/ajuste-stock` con su spec (41 pruebas), por eso la suite total baja respecto del 14-10.
- Cobertura de T09, criterio por criterio:
  - **Actualización:** hora "Actualizado a las …" visible tras la carga y renovada al volver a consultar después de un ajuste, con la cantidad nueva en la tabla (nuevo). Reconsulta tras ajustar (16-10).
  - **Tiempo de respuesta:** mientras la respuesta está pendiente se mantiene el estado de carga sin filas, y los datos aparecen en cuanto llegan, con una sola consulta (nuevo). `InventarioService.listarExistencias` no agrega espera propia: entrega las filas apenas la API responde (nuevo; adaptado el 20-10 a la consulta real de H3.4 T03, el tiempo total depende de la API).
  - **Reconexión:** ya cubierta en H3.4 T07 (datos visibles y aviso al desconectar, reconsulta sin ocultar datos, fallo con reintento, recarga si la carga inicial falló, respuesta tardía descartada, reconsulta de mermas).
  - **Permisos:** acceso a `/inventario` solo para admin y bodeguero, ya cubierto en `auth.guard.spec.ts`. Nuevo: si la base rechaza con 403, el modal muestra "Tu usuario no tiene permiso para registrar ajustes de stock. El stock no se modificó." (mensaje de `fallo-ajuste.ts` desde H3.6 T06) y no informa éxito al panel. Nuevo test SQL `database/tests/ajuste_stock_permisos.sql`: admin y bodeguero pueden ejecutar `fn_ajustar_stock`, cajero y `web_anon` no; el cajero recibe permiso denegado y solo queda el ajuste del bodeguero.
  - **Separación entre sucursales (nuevo):** el mismo artículo aparece una vez por sucursal con su cantidad, mínimo y estado; al elegir una sucursal solo se muestran y cuentan sus artículos; editar el mínimo en una fila no cambia la otra sucursal; el ajuste se abre en la sucursal de la fila.
  - **Estados de carga, vacío y error:** ya cubiertos (esqueleto y `aria-busy`, "Aún no hay existencias registradas.", sin coincidencias con "Limpiar filtros", error con "Reintentar").
- Al integrar con `develop` (20-10, PR #71 de Patricio) se suman: 6 pruebas en `inventario.spec.ts`, 1 en `ajuste-inventario.spec.ts` (403) y 1 en `inventario.service.spec.ts`.
- No se hizo verificación en navegador en esta ejecución (pendiente en la máquina de Sebastián).
- Nota de entorno: en la VM Linux de Cowork los `node_modules` son de Windows; las pruebas corren apuntando a binarios Linux descargados fuera del proyecto (`@esbuild/linux-x64` y `@rolldown/binding-linux-x64-gnu`), sin modificar `node_modules`.
- Resultado del 16-10, antes de integrar: 34/34 suites y 395/395 pruebas.

## Filtros combinables por estado y tipo y alertas visuales (H3.5 T06) — ejecución del 14-10-2026

- Antes de empezar se sincronizó con `origin/develop` (sin cambios nuevos).
- La regla de filtrado pasa del componente al modelo (`features/inventario/models/inventario.model.ts`) como funciones puras: `filtrarExistencias` combina estado, tipo, sucursal y texto (todos a la vez), `cumpleFiltroEstado`, `contarEstados`, `tieneDescuadre`, `faltanteParaMinimo` y `normalizarTexto`.
- Conteos que respetan los demás filtros: las opciones de los selectores de estado y de tipo muestran cuántos registros quedan al elegirlas (por ejemplo "Críticos (2)"), y las tarjetas de resumen cuentan con el tipo, la sucursal y la búsqueda aplicados.
- El aviso de alertas sigue contando toda la sucursal consultada: filtrar por tipo o buscar no esconde que hay agotados. "Ver alertas" y "Ver descuadres" quitan el tipo y la búsqueda para que la lista muestre exactamente lo que el aviso anunció, y siguen visibles mientras otro filtro esconda alguna alerta.
- Filtros aplicados visibles: "Mostrando X de Y registros", un chip por filtro que se quita de a uno y "Limpiar filtros".
- Alertas visuales: el aviso es rojo con ✕ si hay algún agotado y ámbar si solo hay críticos. Cada fila agotada o crítica indica cuánto falta para el mínimo ("Faltan 0,4 kg para el mínimo").
- `inventario.model.spec.ts` (suite nueva, 21): cada filtro de estado, combinaciones de estado, tipo, sucursal y texto, búsqueda sin tildes, orden original, conteos y faltante con decimales.
- `inventario.spec.ts` pasa de 44 a 53: conteos por opción con los otros filtros, tarjetas filtradas por tipo, aviso de la sucursal completa con filtros activos, "Ver alertas" desde una lista filtrada, sucursal conservada, chips y limpieza, color por gravedad, faltante por fila y retiro de la alerta al volver a estable. La prueba de columnas incluye el texto del faltante.
- Verificación en navegador (`/inventario`, sesión simulada de bodeguero que luego se eliminó): materias primas + "Con alerta" con aviso rojo de la sucursal completa, chips y faltantes a 1400 px; productos + "Con alerta" a 375 px con "Ver alertas" visible y sin desplazamiento horizontal.
- Resultado: 34/34 suites y 400/400 pruebas en 2 corridas consecutivas. `npm run build` aprobado, 0 errores y 0 advertencias.

## Mensajes de resultado del descuento manual de stock (H3.6 T05) — ejecución del 14-10-2026

- Antes de empezar se integró `origin/develop` (avance rápido hasta `884b2a8`, sin conflictos). Trae de Sebastián `fn_ajustar_stock` (`database/migrations/0005_ajuste_stock.sql`), `StockApiService` y la pantalla `/inventario/ajuste-stock`, además de permisos de cajero, recuperación de turno y recetas. Suma las suites `recetas-api` (4), `stock-api` (4), `turnos-api` (1) y `recuperar-turno` (8), y casos nuevos en otras suites de develop.
- El formulario de descuento (validaciones y confirmación de H3.6 T01) ahora distingue cada fallo del registro con `interpretarFalloAjuste` (`features/inventario/models/fallo-ajuste.ts`), que sigue los códigos de `fn_ajustar_stock`:
  - Sin conexión o error del servidor: se queda en la confirmación con "Reintentar" y la misma clave de idempotencia.
  - Stock insuficiente (23514), artículo o sucursal inexistente (23503) y datos inválidos (22023): vuelve al formulario con el aviso para corregir. En los dos primeros, y con producto con receta, el panel vuelve a consultar las existencias y el formulario valida contra el stock nuevo.
  - Sesión vencida (401), sin permiso (403 o 42501) y función no publicada (PGRST202): bloquea la confirmación y explica el motivo.
  - Todos los mensajes aclaran que el stock no se modificó.
- El servicio de ejemplo rechaza con la misma forma que PostgREST (`HttpErrorResponse` con `code` y `message`).
- `fallo-ajuste.spec.ts` (suite nueva, 17): cada código y estado HTTP, los textos de datos inválidos, cuándo pedir actualizar el stock y el error inesperado.
- `ajuste-stock.spec.ts` pasa de 35 a 41: vuelta al formulario por stock cambiado con validación contra el stock nuevo y clave nueva, datos inválidos, bloqueo por sesión y por permiso, función no disponible y reintento tras perder la conexión.
- `inventario.spec.ts` pasa de 43 a 44: el aviso del formulario vuelve a consultar las existencias sin cerrarlo.
- `inventario.service.spec.ts`: el rechazo por sobre el stock ahora se verifica con el código 23514.
- Verificación en navegador (`/inventario`, sesión simulada de bodeguero que luego se eliminó): rechazo por stock cambiado, vuelta al paso 1 con el aviso, foco en la cantidad, panel actualizado a 1 kg y validación "No puedes descontar más que el stock disponible (1 kg)". Confirmación bloqueada por permisos a 375 px. Sin desplazamiento horizontal ni errores de consola.
- Resultado: 33/33 suites y 370/370 pruebas en 2 corridas consecutivas. `npm run build` aprobado, 0 errores y 0 advertencias.

## Indicador de desconexión y recuperación al reconectar en Inventario (H3.4 T07) — ejecución del 08-10-2026

- Antes de empezar se sincronizó con `origin/develop` (sin cambios nuevos).
- Nuevo `core/services/conexion.service.ts`: sigue los eventos `online`/`offline` del navegador y avisa cada reconexión, incluso un corte breve entre dos renderizados. El canal de tiempo real (H3.4 T06) podrá sumar ahí su propio estado.
- El indicador y el aviso de desconexión del panel (H3.4 T01) ahora se activan de verdad. Al reconectar, el panel vuelve a consultar las existencias sin ocultar los últimos datos: muestra "Actualizando..." y la tabla atenuada con `aria-busy`. Si la carga inicial había fallado, la repite completa. El reporte de mermas también vuelve a consultar.
- Si la consulta tras reconectar falla, los datos anteriores siguen visibles y atenuados, el indicador dice "Datos sin actualizar" y aparece un aviso con "Reintentar". Una respuesta tardía de una reconexión anterior se descarta.
- `conexion.service.spec.ts` (suite nueva, 3): estado inicial del navegador, eventos y aviso de cada reconexión, y liberación de los listeners al destruir la app.
- `inventario.spec.ts` pasa de 38 a 43. La prueba de desconexión ahora usa el evento real `offline` en lugar de fijar el estado a mano, y se suman: reconsulta sin perder los datos, fallo con reintento, recarga cuando la carga inicial había fallado, respuesta tardía descartada y reconsulta de mermas.
- Verificación en navegador (`/inventario`, sesión simulada de bodeguero que luego se eliminó): desconexión, "Actualizando..." al reconectar, vuelta a "En línea" y aviso "Datos sin actualizar" con "Reintentar" a 800 px y 375 px, sin desplazamiento horizontal ni errores de consola.
- Resultado: 28/28 suites y 313/313 pruebas en 2 corridas consecutivas (12.05 a 13.01 s). `npm run build` aprobado, 0 errores y 0 advertencias.

## Filtro "Con descuadre" en Existencias — ejecución del 08-10-2026

- El filtro "Estado de stock" suma la opción "Con descuadre", que muestra solo los artículos con stock negativo y se combina con los filtros de tipo, sucursal y texto. El aviso de alertas tiene el acceso directo "Ver descuadres", que aplica el filtro y se oculta cuando ya está activo.
- El contador del panel ahora usa singular ("1 registro"); antes decía "1 registros".
- `inventario.spec.ts` pasa de 37 a 38. La prueba nueva cubre:
  - El acceso directo desde el aviso y el valor que queda en el filtro.
  - El conteo en singular.
  - La diferencia con el filtro de agotados, que también incluye el stock en cero.
  - El estado vacío al combinar el filtro con una sucursal sin descuadres.
- Validación en navegador (localhost con sesión de bodeguero simulada, sin llamadas al VPS): con "Ver descuadres" queda solo Leche entera de Nury Ñuñoa, con −2 L y la etiqueta de descuadre.
- Resultado automático: 27/27 suites aprobadas y 305/305 pruebas exitosas en dos corridas seguidas. Compilación de producción sin errores ni advertencias.

## Etiqueta de descuadre para stock negativo en Inventario — ejecución del 08-10-2026

- Las ventas descuentan stock aunque no alcance (`fn_aplicar_venta` no valida y `stock_sucursal` no tiene restricción de mínimo cero), así que un stock negativo indica compras o conteos sin registrar.
- Esas filas mantienen el estado "Agotado" del criterio de H3.5 y suman una etiqueta "Descuadre" con su explicación. El aviso de alertas agrega cuántos artículos de la sucursal consultada tienen stock negativo.
- El formulario de descuento distingue los dos bloqueos. Con stock en cero dice "Este artículo no tiene stock disponible"; con stock negativo explica el descuadre y pide ingresar primero la compra o el conteo pendiente.
- Pruebas:
  - `inventario.spec.ts` pasa de 36 a 37. La nueva prueba distingue descuadre de stock en cero, revisa el texto del aviso y que desaparezca al filtrar una sucursal sin negativos. La prueba del listado ahora espera "Agotado Descuadre" en la fila negativa.
  - `ajuste-stock.spec.ts` pasa de 34 a 35. El caso de bloqueo se separó en stock cero y stock negativo, cada uno con su mensaje.
- Validación en navegador (localhost con sesión de bodeguero simulada, sin llamadas al VPS): la etiqueta se ve bajo el estado a 1100 px sin desbordar la tabla, y en las tarjetas a 375 px sin desplazamiento horizontal.
- Resultado automático: 27/27 suites aprobadas y 304/304 pruebas exitosas en dos corridas seguidas. Compilación de producción sin errores ni advertencias.

## Descuento manual de stock y consulta de mermas en Inventario (H3.6 T01) — ejecución del 08-10-2026

- Antes de empezar se integró `origin/develop` (catálogo de ingredientes H3.3, Edenred en lugar de Pluxee y las mismas correcciones de `caja.service.spec.ts` y `pos-layout`). Hubo conflicto en `app.routes.ts` (se conservaron `inventario/ingredientes` e `inventario`) y en `caja.service.spec.ts` (misma limpieza de `sessionStorage`; se dejó la versión de `develop` con el comentario explicativo). Tras el merge: 24/24 suites y 245/245 pruebas, build limpio. El merge suma `ingredientes-api.service.spec.ts` (5 pruebas).
- Inventario ahora tiene pestañas "Existencias" y "Mermas y ajustes", y un botón "Descontar stock" en la cabecera y en cada fila con stock.
- Formulario de descuento (`AjusteStock`), en dos pasos:
  - Datos: sucursal; artículo agrupado por tipo, con la marca "sin stock"; stock, unidad y estado actuales; cantidad; motivo con sugerencias; vista previa del stock resultante.
  - Confirmación: resumen con el usuario que registra el ajuste.
  - Bloquea artículos con stock ≤ 0.
  - Valida: cantidad positiva, hasta 3 decimales y sin superar el stock; motivo obligatorio, que no puede estar vacío ni tener solo espacios, con máximo 200 caracteres.
  - Solo admin y bodeguero confirman. Cada revisión genera una clave de idempotencia y los reintentos reutilizan esa misma clave.
- Reporte de mermas (`ReporteMermas`):
  - Filtros de sucursal y periodo: hoy, 7 días, 30 días, este mes o personalizado. El rango personalizado se valida.
  - Totales agrupados por artículo y unidad (`agruparMermas`) y detalle con fecha, hora, cantidad con unidad, motivo, usuario y sucursal.
  - Estados de carga, vacío y error con reintento. Vuelve a consultar después de cada ajuste.
- Los estilos comunes pasaron a `features/inventario/styles/inventario-base.css`. `inventario.css` bajó de 18,3 kB a 11,8 kB, lejos del límite de advertencia de 20 kB.
- `InventarioService` sigue con datos de ejemplo en memoria: el descuento se refleja en las existencias y el reporte, y una clave repetida no descuenta dos veces. El servicio real queda para H3.6 T03 y el reporte real para H3.6 T07.
- Pruebas nuevas:
  - `ajuste-stock.spec.ts` (34):
    - 12 casos de `validarCantidadAjuste` y 5 de `validarMotivo`.
    - Apertura desde la fila y foco; artículos por sucursal y tipo; sucursal del usuario; bloqueo sin stock.
    - Errores de artículo, cantidad y motivo; sugerencia de motivo y vista previa.
    - Resumen de confirmación y volver; confirmación con datos normalizados.
    - Error con reintento usando la misma clave; clave nueva si cambian los datos.
    - Rol no autorizado; cierre con Cancelar o Escape, bloqueado mientras guarda.
  - `reporte-mermas.spec.ts` (13):
    - 3 casos de `agruparMermas`.
    - Consulta por defecto de 7 días, con totales y detalle.
    - Sucursal inicial y filtro de sucursal; periodos hoy, 30 días y mes; validación del rango personalizado.
    - Estado vacío; carga y error con reintento; nueva consulta tras un ajuste; un solo filtro de sucursal.
  - `inventario.service.spec.ts` (4): descuento con registro completo, reintento sin doble descuento, rechazo por sobre el stock y filtro de mermas por sucursal y periodo.
  - `inventario.spec.ts` pasa de 30 a 36: botón general deshabilitado al cargar, "Descontar" solo con stock, apertura desde la fila y por sucursal, actualización de fila, tarjetas y alertas tras el ajuste, cancelación y pestaña de mermas.
- Validación en navegador (localhost con sesión de bodeguero simulada, sin llamadas al VPS):
  - Descuento de 2,5 kg de Café en grano: la fila, las tarjetas, la alerta y el reporte se actualizaron sin recargar.
  - Tabla a 1100 px; se ajustó el relleno de las celdas porque las dos acciones desbordaban 49 px.
  - Tarjetas a 800 px.
  - Formulario como hoja inferior y reporte en tarjetas a 375 px, sin desplazamiento horizontal.
- Resultado automático: 27/27 suites aprobadas y 302/302 pruebas exitosas en dos corridas seguidas. Compilación de producción sin errores ni advertencias.

## Estados, alertas y edición del stock mínimo en Inventario (H3.5 T01) — ejecución del 07-10-2026

- Regla de estados según el criterio de H3.5 (`calcularEstadoStock`): agotado si el stock es ≤ 0; crítico si es positivo y menor que el mínimo; estable si es positivo e igual o mayor que el mínimo.
- El panel suma la columna Mínimo, la etiqueta de estado por fila, una franja de color en filas agotadas o críticas, tarjetas de resumen por estado (que también filtran), un aviso con el total de alertas de la sucursal consultada y el filtro "Estado de stock", combinable con tipo, sucursal y texto.
- Modal "Stock mínimo": muestra stock y estado actuales, acepta coma o punto decimal, rechaza vacío, negativo, texto no numérico y más de 3 decimales (`NUMERIC(12,3)`), y anticipa el estado resultante antes de guardar. Guarda con datos de ejemplo hasta H3.5 T03.
- `inventario.spec.ts` pasa de 8 a 30 pruebas:
  - 7 casos de `calcularEstadoStock`: negativo, cero, cero con mínimo cero, menor, igual y mayor al mínimo, y positivo con mínimo cero.
  - Listado con mínimo y estado; clases de alerta por fila y conteo por estado.
  - Aviso de alertas por sucursal consultada y botón "Ver alertas"; sin aviso cuando todo está estable.
  - Filtro de estado combinado con tipo y texto; tarjetas de resumen como filtro activable.
  - Edición: datos actuales, 4 valores inválidos con su mensaje, vista previa del estado, guardado con decimal con coma, mínimo 0 válido, error al guardar y cierre con Cancelar o Escape.
- Validación en navegador (localhost con sesión de bodeguero simulada, sin llamadas al VPS): tabla completa a 1100 px, tarjetas a 800 px y modal tipo hoja inferior a 375 px, sin desplazamiento horizontal. Se detectó que el `box-shadow` de la franja oscurecía en Chrome los bordes de la primera columna; se reemplazó por un fondo.
- Resultado automático: 23/23 suites aprobadas, 240/240 pruebas exitosas en dos ejecuciones seguidas. Compilación en modo producción sin errores ni advertencias (`npm run build`).

## Intermitencia de `caja.service.spec.ts` — corrección del 07-10-2026

- **Síntoma:** en cerca de 1 de 5 corridas fallaban 6 pruebas de cierre con diferencia de efectivo y de boletas. `pos.salesHistory()` traía ventas `id: 999` de otras pruebas (p. ej. "expected [ { id: 999, … }, …(3) ] to have a length of 1 but got 4") y el cierre lanzaba "Debes justificar la diferencia de efectivo antes de cerrar el turno.".
- **Causa:** el runner de Angular para Vitest (`@angular/build:unit-test`) usa `isolate: false` por defecto, así que todos los specs comparten el mismo `sessionStorage` de jsdom. Algunos specs dejaban ahí una sesión iniciada (`nury_session`, usuario 1) y un turno con ventas (`nury_turno`, usuario 1, ventas id 999), sin limpiarlos al terminar. `caja.service.spec.ts` usa el `AuthService` real y no limpiaba `sessionStorage`, así que el constructor de `PosService` restauraba ese turno ajeno (`restoreTurno`). Solo fallaba cuando el orden de los archivos dejaba ambas claves antes de esta suite, por eso era intermitente.
- **Reproducción determinista:** se sembraron temporalmente en el `beforeEach` de `caja.service.spec.ts` una sesión del usuario 1 y un `nury_turno` con 3 ventas id 999. La suite falló con los mismos mensajes ("Debes justificar…", "to have a length of 1 but got 4"). La siembra se retiró después.
- **Descartado:** `new Date()` en `FAKE_TURNO` y el `timeout(15000)` de `completeSale`. `CajaService` no filtra ventas por `hora_inicio`, y con `of(...)` síncrono el `timeout` nunca se dispara.
- **Corrección (solo pruebas, sin cambios de producción):**
  - `caja.service.spec.ts`: `sessionStorage.clear()` en `beforeEach` y `afterEach`, igual que `cierre-caja.component.spec.ts`.
  - `payment-modal.component.spec.ts`: `afterEach(() => sessionStorage.clear())` para no dejar sus ventas (usuario 1, id 999) a los specs siguientes.
  - `auth.service.spec.ts`: el `afterEach` también limpia `sessionStorage` para no dejar la sesión iniciada.
- **Comportamiento de producción:** no es un bug. Restaurar el turno del mismo usuario desde `sessionStorage` es la funcionalidad buscada (turno persistente al recargar, 30-09-2026).
- **Inventario corregido:** `caja.service.spec.ts` tiene 10 pruebas, no 26; con 10 el total de la tabla da 218.
- **Resultado automático:** `npm test -- --watch=false --reporters=verbose` ejecutado 8 veces seguidas: 8/8 corridas con 23/23 suites y 218/218 pruebas aprobadas, 0 fallos (conteo sobre el árbol de trabajo, que incluía el panel de Inventario aún sin commitear). `npm run build` sin errores ni advertencias.

## Panel de Inventario y ruta `/inventario` (H3.4 T01) — ejecución del 07-10-2026

- Se crea la ruta `/inventario` (admin y bodeguero), que ya aparecía en el menú pero no existía. El bodeguero entra ahí al iniciar sesión, en lugar de `/sin-acceso`.
- El panel usa datos de ejemplo (`InventarioService`) hasta que H3.4 T03 conecte la consulta real; la vista lo indica con la etiqueta "Datos de ejemplo".
- `inventario.spec.ts` (suite nueva, 8 pruebas):
  - Estado de carga con filas de esqueleto, filtros deshabilitados y `aria-busy`.
  - Listado con nombre, tipo, cantidad (formato es-CL, admite negativos), unidad y sucursal.
  - Estado vacío sin existencias.
  - Estado de error con "Reintentar" que vuelve a consultar.
  - Estado sin conexión: indicador "Sin conexión", aviso y datos atenuados pero visibles.
  - Filtros por texto sin tildes, tipo de artículo y sucursal.
  - "Limpiar filtros" cuando ningún artículo coincide.
  - El filtro de sucursal se oculta cuando hay una sola sucursal.
- `auth.guard.spec.ts`: 3 casos nuevos de acceso a `/inventario` (bodeguero y admin permitidos, cajero rechazado).
- `login.component.spec.ts`: las 3 pruebas del bodeguero ahora esperan `/inventario` como destino por defecto.
- `pos-layout.component.spec.ts`: la suite no compilaba en `develop` porque asignaba `isRegisterOpen.set(false)`, que ahora es un `computed`; se reemplazó por `posService.turnoActivo.set(null)`, igual que el resto de la suite.
- Validación en navegador (localhost con sesión de bodeguero simulada, sin llamadas al VPS): carga, listado, error y sin conexión en escritorio; tarjetas en tablet (768 px) y móvil (375 px) sin desplazamiento horizontal.
- **Prueba intermitente detectada (no relacionada con este cambio):** en 1 de 5 ejecuciones fallaron 6 pruebas de `caja.service.spec.ts` (cierres con diferencia de efectivo y boletas) porque el historial de ventas traía ventas de pruebas anteriores. Las otras 4 ejecuciones pasaron 218/218. **Resuelto el 07-10-2026** (ver sección "Intermitencia de `caja.service.spec.ts`").
- Resultado automático: 23/23 suites aprobadas, 218/218 pruebas exitosas. Compilación en modo producción sin errores ni advertencias (`npm run build`).

## Turno de caja persistente al recargar o volver a la URL — ejecución del 30-09-2026

- Problema: con un turno abierto, recargar o volver a entrar a `nury.cl` mantenía la sesión, pero mostraba "Aún no inicias tu turno" y perdía las ventas del turno. El turno solo vivía en memoria (`PosService`), mientras la sesión sí se guardaba en `sessionStorage`.
- `pos.service.spec.ts`: 5 pruebas nuevas (bloque "turno persistente entre recargas").
  - Tras una recarga se conserva la caja abierta con sus ventas, y las fechas vuelven como `Date`.
  - Se conservan también las ventas anuladas del turno.
  - Tras cerrar el turno, una recarga parte con la caja cerrada y sin datos guardados.
  - Un turno abierto no se traspasa a otro usuario en la misma pestaña.
  - Un turno guardado corrupto se descarta sin romper el POS.
- `app.routes.spec.ts` (suite nueva, 2 pruebas): la raíz lleva a `caja` sin turno abierto y a `pos` con turno abierto.
- `payment-modal.component.spec.ts`: ahora limpia `sessionStorage` antes de cada prueba, para que el turno guardado no se filtre entre pruebas.
- Validación en navegador (localhost con sesión de cajero simulada): con el turno iniciado, al recargar `/caja` se muestra "Turno actual · Cerrar turno" en lugar de "Iniciar Turno".
- Resultado automático: 20/20 suites aprobadas, 183/183 pruebas exitosas. Compilación en modo producción sin errores ni advertencias (`npm run build`).

## Loader "taza de café" en el login y el catálogo del POS — ejecución del 29-09-2026

- `coffee-loader.spec.ts` (suite nueva, 7 pruebas):
  - No se muestra si la vista ya está cargada, ni si la carga termina antes de 200 ms (sin destello).
  - Si apareció, se mantiene al menos 900 ms, luego hace el soplido (`blowing`) y desaparece al cabo de 1 s.
  - Dibuja la estela de vapor (trazado SVG cerrado) mientras está visible.
  - Avisa "La conexión está lenta" a los 6 s de carga.
  - En error muestra el mensaje con `role="alert"` y el botón "Reintentar" (emite `retry`); al reintentar la taza sigue en pantalla.
  - Con `showDelay = 0` aparece de inmediato como capa de pantalla completa.
- `app-loader.service.spec.ts` (suite nueva, 5 pruebas):
  - Sin sesión en curso está listo y las vistas usan su propio loader (`join` devuelve `false`).
  - Tras iniciar sesión sigue cargando hasta que termina la navegación y cada vista sumada está lista; después se cierra y una recarga posterior no lo reabre.
  - Termina apenas navega si la vista no carga nada más.
  - Si una vista falla informa error y reintenta solo esa vista; si falla la navegación, la reintenta.
- `login.component.spec.ts`: tras un login exitoso la entrada a la app queda cubierta por la taza a pantalla completa.
- `app.spec.ts`: la taza de pantalla completa no aparece hasta que se inicia una sesión.
- `pos.service.spec.ts`: el estado de carga del catálogo pasa a `ready` al recibir productos y a `error` si la API falla.
- `pos-layout.component.spec.ts`: 3 pruebas nuevas.
  - Un catálogo ya cargado no se cubre con la taza.
  - Si el catálogo falla, la taza sobre el catálogo muestra el error, se oculta el aviso de "sin productos" y "Reintentar" vuelve a pedir el catálogo.
  - Recién iniciada la sesión, el POS se suma a la taza de pantalla completa en vez de mostrar la suya.
- Resultado automático: 17/17 suites aprobadas, 143/143 pruebas exitosas. Compilación en modo producción sin errores ni advertencias (`npm run build`).

## Ventas: listado por sucursal en `VentasApiService` — ejecución del 01-10-2026

- **Rama:** `Patricio2_branch`
- `ventas-api.service.spec.ts` (suite nueva, 8 pruebas):
  - `listar` con una sucursal usa `sucursal_id=eq.N`, orden `fecha_venta.desc,id.desc` y no depende del turno abierto.
  - Con varias sucursales (admin multi-sucursal) usa `in.(1,2,3)` y elimina duplicados.
  - Sin sucursales no hace ninguna petición y devuelve `[]`, para no exponer ventas de otras sucursales.
  - `soloVigentes` agrega `anulada=eq.false`.
  - Rango de fechas inclusivo: `gte.<desde>T00:00:00` y `lt.<día siguiente>T00:00:00`, incluido el cambio de año.
  - `anular` sigue siendo un `PATCH` con `anulada=eq.false`, envía el motivo y falla si la venta no existe o ya estaba anulada.
- Alcance: solo el servicio; ninguna pantalla lo usa todavía. La lectura se verificó a mano con `GET /ventas` (200) contra `api.nury.cl` con sesión de admin.
- Pendiente de confirmar en el servidor: columna `anulada_motivo` (no apareció en `select=*`) y permiso de lectura de `ventas` para el rol cajero.
- Resultado automático (solo servicio): 21/21 suites aprobadas, 195/195 pruebas exitosas. Compilación en modo producción sin errores ni advertencias (`npm run build`).

### Pantalla de anulación conectada a `listar` — 01-10-2026

- `listar` recibe `desde`/`hasta` como instantes (el servidor guarda `fecha_venta` en UTC, así el filtro "hoy" no se corta de noche) y `incluirDetalle` para traer productos con `detalle_venta(...productos(nombre))`.
- `anulacion-venta.spec.ts` (suite nueva, 9 pruebas; las 3 últimas se detallan más abajo): carga el historial de la sucursal del usuario sin turno abierto; sin sucursal no consulta; error de carga visible; motivo de mínimo 5 caracteres antes de anular; anular envía el motivo, marca la fila y sincroniza el turno local; si anular falla, la venta sigue vigente y se muestra el error.
- `pos.service.spec.ts`: `sincronizarAnulacion` descuenta del turno una venta anulada desde otra pantalla e ignora ventas de otros turnos.
- Filtro por cajero (lista y tarjetas de totales; se combina con la búsqueda de texto; incluye "Sin cajero"): +1 prueba. El error de anulación muestra la respuesta del servidor (`El servidor rechazó la anulación (error 400): ...`): +1 prueba.
- Filtro por estado con botones **Todas / Vigentes / Anuladas** (`aria-pressed`; se combina con el filtro por cajero y la búsqueda; las tarjetas de totales no cambian con el estado): +1 prueba que recorre los tres botones, los combina con el cajero y verifica el mensaje "No hay ventas que coincidan con los filtros." cuando no hay resultados.
- Resultado automático (reejecutado el 01-10-2026, 18:54): 22/22 suites aprobadas, 205/205 pruebas exitosas. `npm run build` sin errores ni advertencias. Los avisos de *sourcemap* de `@zxing/browser` que imprime Vitest vienen de `node_modules` y no son del proyecto.
- Verificación visual en navegador (01-10-2026, sesión de admin iniciada por Patricio, `api.nury.cl`, sucursal 1, 11 ventas del día): **Todas** muestra TK-4 a TK-14; **Anuladas** muestra solo TK-8; **Vigentes** muestra las otras 10. Solo un botón queda con `aria-pressed="true"` y las tarjetas no cambian (10 vigentes, $72.300, 1 anulada). Solo se filtró; no se anuló ni se registró nada.
- Ícono de pestaña: se reemplazó el `favicon.ico` de Angular por uno propio elegido por Patricio: taza con barras de crecimiento, sin fondo ni vapor, taza y plato verde `#344337`, barras y café dorado `#c0935f`. En modo oscuro el SVG cambia la taza y el plato a crema `#f5f1e5` (`prefers-color-scheme`) para que no se pierda en pestañas oscuras. Son `public/favicon.svg` y `public/favicon.ico` (16/32/48 px, versión clara generada desde el mismo SVG) y se enlazaron en `src/index.html`. Se revisó a 16 px en pestaña clara y oscura. Ambos responden 200 en `ng serve` y se copian a `dist/`; `npm run build` sin errores ni advertencias. No requiere pruebas unitarias.
- **Intermitencia previa:** `caja.service.spec.ts` (6 pruebas) falla en algunas corridas con `salesHistory` con más ventas de las esperadas (estado compartido, usa el `AuthService` real y el `sessionStorage` del turno). También ocurre sobre el árbol sin estos cambios (1 de 4 corridas). No se atribuye a este cambio. **Resuelto el 07-10-2026** (ver sección "Intermitencia de `caja.service.spec.ts`").
- Revisión manual en navegador contra `api.nury.cl` (sesión de admin, sucursal 1): el historial muestra las 9 ventas del día con cajero y productos; filtro por cajero, búsqueda, rango de fechas y modal verificados. La primera anulación de TK-8 falló: el servidor respondía `42703 column ventas.anulada_motivo does not exist` (migración `0002_add_anulada_motivo_to_ventas.sql` sin aplicar en `api.nury.cl`). Tras crear la columna (`ALTER TABLE ventas ADD COLUMN IF NOT EXISTS anulada_motivo TEXT` + `NOTIFY pgrst, 'reload schema'`, ejecutado por Patricio en pgAdmin el 01-10-2026), **TK-8 se anuló con motivo "prueba"**: la API guarda `anulada=true`, `anulada_motivo='prueba'`, `anulada_por=1` (la sesión era de Nelson) y `anulada_en`; la pantalla la marca "Anulada", descuenta el total vigente ($68.400 → $65.400) y persiste al recargar.

## POS: comanda en modal móvil y categorías unificadas — ejecución del 29-09-2026

- `pos.service.spec.ts`: nueva prueba que verifica que las categorías con la misma palabra inicial se unifican en una sola pestaña (`ALIMENTOS - EMPANADAS` + `ALIMENTOS - SANDWICH` → `ALIMENTOS`; `Empanada Pino` + `EMPANADAS QUESO` → `Empanada`), ignorando mayúsculas, tildes y plural simple, y que las categorías sin palabra compartida conservan su nombre sin segmentos repetidos (`HELADOS - HELADOS` → `HELADOS`).
- `pos-layout.component.spec.ts`: 3 pruebas nuevas.
  - El filtro y el contador de la pestaña unificada incluyen todas sus subcategorías, y la búsqueda de texto encuentra productos por su subcategoría original.
  - El botón flotante del carrito abre la comanda como modal (`role="dialog"`) y el fondo la cierra.
  - "Continuar al pago" cierra el modal de la comanda y abre el modal de pago.
- Resultado automático: 14/14 suites aprobadas, 119/119 pruebas exitosas. Compilación en modo producción sin errores ni advertencias (`npm run build`).

## POS: íconos de producto por categoría — ejecución del 29-09-2026

- `pos-icons.spec.ts` (suite nueva, 4 pruebas):
  - Cada una de las categorías reales del catálogo recibe su ícono específico (empanada, chaparrita con ícono propio, handroll, sándwich, completo, pizza, café, lata, chicle, galleta, helado, lápiz, etc.).
  - Respaldo en orden: nombre del producto → familia (`ALIMENTOS`, `BEBESTIBLES`, `GOLOSINAS`, `HELADOS`) → bolsa genérica.
  - Alimentos, golosinas y helados nunca usan el ícono de vaso con bombilla.
  - Una clave de ícono desconocida usa la bolsa genérica.
- `pos.service.spec.ts`: el producto cargado desde la API recibe el ícono de su categoría (`ALIMENTOS - EMPANADAS` → `empanada`).
- `pos-layout.component.spec.ts`: cada tarjeta del catálogo dibuja el ícono asignado a su producto.
- Revisión visual de los 34 íconos en una hoja de muestra.
- Resultado automático: 15/15 suites aprobadas, 125/125 pruebas exitosas. Compilación en modo producción sin errores ni advertencias (`npm run build`).

## Retiro de perfiles demo del Login — ejecución del 25-09-2026

- Se retiró la sección de botones de acceso rápido y perfiles de demostración (`quick-access-section`, `demoAccounts`) de la pantalla de login (`login.component.html`, `login.component.ts`, `login.component.css`).
- Se validó mediante prueba unitaria en `login.component.spec.ts` que los botones y tarjetas de perfil de prueba no se renderizan en el template.
- Se configuró el consumo dinámico de `environment.apiUrl` en las suites de pruebas de autenticación y API para soportar cualquier URL de endpoint sin desacoples.
- Se aseguró el aislamiento de `TestBed` en `barcode-scanner.spec.ts`.
- Resultado automático: 13/13 suites aprobadas, 107/107 pruebas exitosas. Compilación en modo producción sin errores ni advertencias (`npm run build`).

## AuthGuard y sesión — ejecución del 19-09-2026

- Redirección exacta a `/login?returnUrl=%2Fpos` cuando no existe sesión.
- Acceso permitido con sesión válida.
- Bloqueo inmediato después de cerrar sesión.
- Bloqueo y limpieza de una sesión expirada.
- Restauración de sesión vigente desde `sessionStorage`.
- Expiración del TTL de 8 horas sin necesidad de recargar la pestaña.
- Regreso a una ruta interna solicitada después del login.
- Rechazo de `returnUrl` externo y fallback seguro a `/pos`.

## Roles UI por usuario de PostgreSQL — ejecución del 19-09-2026

- El sidebar no fija roles localmente: consume `AuthService.currentUser().rol`, obtenido desde `public.login()` mediante PostgREST.
- Cajero: muestra Home, Punto de venta y Caja.
- Bodeguero: muestra Home, Maestro Productos e Inventario.
- Administrador: muestra todas las opciones disponibles.
- Sin usuario autenticado: no renderiza enlaces dependientes de rol.
- Verificación de integración local: las tres cuentas de desarrollo devolvieron desde PostgreSQL los roles `cajero`, `admin` y `bodeguero` esperados.
- El login envía al bodeguero a `/product-master` y descarta un `returnUrl` al POS, que no está visible para su rol.
- Resultado automático: 5/5 pruebas del sidebar, 8/8 del login y 69/69 pruebas totales aprobadas.
- Validación asistida en navegador integrado: cajero, administrador y bodeguero mostraron sus menús esperados; aprobada por Patricio el 19 de septiembre de 2026.

### Revalidación — 25-09-2026

- `npm test -- --watch=false --reporters=verbose`: 13/13 suites y 107/107 pruebas aprobadas; incluye que bodeguero no ve ni puede abrir `/product-master`.
- `npm run build`: compilación de producción aprobada, sin errores ni advertencias.

## Procedimiento obligatorio

1. Ejecutar `npm test -- --watch=false --reporters=verbose`.
2. Registrar suites, casos nuevos, fecha, rama y resultado real.
3. Ejecutar `npm run build` y registrar errores o advertencias.
4. No marcar una tarea como finalizada hasta completar también su revisión manual cuando corresponda.

## Catálogo POS con categorías reales — 24-09-2026

- **Rama:** `Patricio2_branch`
- **Cambios:** Categorías derivadas del campo `productos.categoria`; filtro por nombre real; “Sin categoría” para valores vacíos.
- **Pruebas:** `npm test -- --watch=false --reporters=verbose` no pudo completar la compilación del bundle. Angular/esbuild reportó `Acceso denegado` al leer directorios del workspace y resolver CSS y dependencias locales. Una primera ejecución también detectó fixtures numéricos; fueron actualizados al nuevo tipo string antes del segundo intento.
- **Resultado:** Sin conteo de pruebas ejecutadas; suite bloqueada antes de su inicio por acceso al filesystem. No registrar como PASS.
- **Build:** `npm run build` también falló antes de compilar por `Acceso denegado` al resolver archivos del workspace y estilos globales; no atribuido a errores de TypeScript del cambio.

## Lector y carga de factura XML (H3.1 T03 y T04) — 16-10-2026

- **Rama:** Nelson_Branch2
- **Cambios:** src/app/features/facturas/ (lector DTE 33, página de carga y previsualización, rutas) y ruta inventario/facturas para admin y bodeguero en pp.routes.ts.
- **Pruebas:** 
px ng test --watch=false --include="src/app/features/facturas/**/*.spec.ts": 2/2 suites y 40/40 pruebas aprobadas (lector: 35; página: 5).
- **Pruebas completas:** 
px ng test --watch=false: 36/36 suites y 427/427 pruebas aprobadas.
- **Build:** 
px ng build: compilación aprobada, sin errores.
- **Pendiente:** revisión visual con sesión iniciada y datos reales (la guía la exige para cambios de interfaz). No registrar T04 como finalizada hasta completarla.
- **Revisión visual (16-10-2026):** navegador integrado con sesión iniciada, a 1440, 1280, 1101, 1100, 768 y 390 px. Factura válida de 17 líneas, tipo 34 y archivo no XML. Correcciones: el cuadro de totales ya no se estira a la altura del cuadro del emisor; el error dice «El archivo … no se puede ingresar». Sin desplazamiento horizontal en móvil (la tabla se desplaza dentro de su contenedor). Foco visible con teclado. Observación ajena a esta pantalla: en móvil el botón flotante del menú tapa el contenido al pasar por encima.
- **Pruebas después de las correcciones:** 2/2 suites y 40/40 pruebas de facturas aprobadas.
## Asociación de líneas con el catálogo (H3.1 T05) — 16-10-2026

- **Rama:** Nelson_Branch2
- **Cambios:** src/app/features/facturas/models/asociacion-lineas.ts y selector por línea en la página de carga (materias primas activas, productos activos sin receta o «No corresponde a inventario»), con contador de líneas pendientes. T04: la tabla indica si los montos son netos o con IVA.
- **Pruebas:** 
px ng test --watch=false: 37/37 suites y 439/439 pruebas aprobadas (facturas: 3 suites, 52 pruebas).
- **Build:** 
px ng build: compilación aprobada, sin errores.
- **Revisión visual:** navegador integrado con sesión y catálogo real (1 materia prima, 355 productos sin receta) a ~800 px: asociar, marcar no inventariable y contador. Se corrigió que el selector perdiera la opción elegida al redibujarse (prueba de regresión agregada) y se juntó el código del proveedor con la descripción para que la columna del catálogo quepa. Pendiente: revisión en móvil (el panel se cerró).- **Buscador por línea (16-10-2026):** campo «Buscar por nombre…» sobre cada selector; filtra materias primas y productos sin importar mayúsculas ni tildes, exige todas las palabras y conserva el artículo ya elegido. 
px ng test --watch=false: 37/37 suites y 446/446 pruebas aprobadas (facturas: 59). 
px ng build: aprobado. Revisión visual pendiente (el panel pidió iniciar sesión de nuevo).- **Revisión visual del buscador y móvil (16-10-2026):** con sesión y catálogo real. «empanada queso» deja 6 productos en la línea 1 sin afectar a las demás; lo elegido se conserva al cambiar la búsqueda. Corregido: «Sin coincidencias» no aparecía si ya había un artículo elegido. Corregido en móvil (390 px): la tabla medía 655 px y el selector quedaba fuera de la vista; ahora, hasta 768 px, cada línea es una tarjeta con etiquetas, sin desplazamiento lateral. En 1280 px sigue siendo tabla. 
px ng test --watch=false: 37/37 suites y 447/447 pruebas aprobadas. 
px ng build: aprobado.
## Menú «Cargar factura» — 17-10-2026

- **Rama:** Nelson_Branch2
- **Cambios:** opción «Cargar factura» en el menú lateral para admin y bodeguero (sidebar.ts, ícono en sidebar.html). La ruta pasa a /facturas/cargar para que el menú no marque «Inventario» al mismo tiempo. Pruebas del menú actualizadas.
- **Pruebas:** 
px ng test --watch=false: 37/37 suites y 447/447 pruebas aprobadas.
- **Build:** 
px ng build: aprobado.- **Revisión visual:** navegador integrado con sesión de administrador. La opción aparece con su ícono y nombre (menú contraído, expandido y móvil a 390 px); al abrirla solo se marca «Cargar factura», no «Inventario».

## Rediseño de «Cargar factura» — 17-10-2026

- **Rama:** Nelson_Branch2
- **Cambios:** la pantalla sigue el estilo del Maestro de productos: encabezado con subtítulo, zona de carga (también acepta arrastrar y soltar), tarjetas de resumen (proveedor, folio, total, líneas por asociar), avisos y errores con ícono, panel de datos del documento y tabla de líneas con cabeceras en mayúsculas. Bajo 1100 px las líneas pasan a tarjetas (dos columnas entre 801 y 1100 px, una en móvil).
- **Pruebas:** 
px ng test --watch=false: 37/37 suites y 448/448 pruebas aprobadas (nueva: arrastrar y soltar).
- **Build:** 
px ng build: aprobado.
- **Revisión visual:** navegador integrado con sesión a 1440, 1280, 1100, ancho del panel (~770) y 390 px; estado vacío, factura válida y tipo 34. Corregido durante la revisión: a 1100 px la descripción quedaba en ~100 px, por eso las tarjetas empiezan en 1100 px.
## Equivalencias y cantidad a ingresar (H3.1 T06) — 17-10-2026

- **Rama:** Nelson_Branch2
- **Base de datos (sin aplicar):** database/migrations/20261017_equivalencias_lineas_xml.sql y su .ENSAYO.sql (termina en ROLLBACK y prueba las reglas con filas de ejemplo). Agrega unidades_por_presentacion y cantidad_ingreso (columna calculada) a acturas_xml_pendientes_lineas, con reglas de equivalencia positiva y solo en líneas con artículo.
- **Pantalla:** cada línea asociada a un artículo pide «Cada presentación trae» con la unidad del catálogo (kg, L… o un) y muestra «Se sumarán X un (cantidad × equivalencia)». Acepta coma decimal y hasta 3 decimales. La línea sigue pendiente hasta tener una equivalencia válida; al cambiar de artículo se pide de nuevo.
- **Pruebas:** 
px ng test --watch=false: 37/37 suites y 472/472 pruebas aprobadas (facturas: 85).
- **Build:** 
px ng build: aprobado.
- **Pendiente:** ensayo y aplicación del SQL en pgAdmin; revisión visual en el navegador (el servidor de desarrollo estaba detenido).- **Revisión visual (17-10-2026):** navegador integrado con sesión y catálogo real. Línea con producto y equivalencia 1: «Se sumarán 16 un (16 × 1)». Línea con la materia prima Queso (en g) y 500,5: «Se sumarán 10.010 g (20 × 500,5)». Línea «No corresponde a inventario»: sin equivalencia. Equivalencia 0: error en terracota y la línea sigue pendiente. El contador baja al completar cada línea. Móvil (390 px) sin desplazamiento lateral. Corregido: faltaba el espacio entre la unidad y el paréntesis («16 un(16 × 1)»). 
px ng test --watch=false: 472/472; 
px ng build: aprobado.
## Permisos y sucursal de ingreso (H3.1 T07) — 17-10-2026

- **Rama:** Nelson_Branch2
- **Regla:** admin ingresa en cualquier sucursal activa; bodeguero solo en la suya (usuarios.sucursal_id) y sin sucursal asignada no puede ingresar; cajero y otros roles no ingresan. Supuesto: «resto de roles» se leyó como los de inventario (admin y bodeguero), igual que el menú y la ruta.
- **Servidor (sin aplicar):** database/migrations/20261017_permisos_ingreso_facturas.sql y su .ENSAYO.sql (termina en ROLLBACK; 18 pruebas con admin, bodeguero con y sin sucursal, cajero y un JWT que no corresponde al usuario). Agrega n_actor_ingreso(), n_validar_sucursal_ingreso(), un disparador que valida la sucursal y fija cargado_por, y RLS en las dos tablas de pendientes.
- **Pantalla:** panel «Sucursal que recibirá el stock» (el admin elige; el bodeguero ve la suya fija) y «Sucursal de destino» en los datos del documento. Sin permiso, no se muestra la zona de carga.
- **Pruebas:** 
px ng test --watch=false: 38/38 suites y 492/492 pruebas aprobadas (facturas: 105). 
px ng build: aprobado.
- **Pendiente:** ensayo y aplicación del SQL en pgAdmin; revisión visual en el navegador.- **Revisión visual (17-10-2026):** navegador integrado con sesión de administrador con sucursal propia. El selector lista las 9 sucursales activas reales y deja preseleccionada la del usuario. Al cargar una factura, «Sucursal de destino» encabeza los datos del documento y cambia al instante al elegir otra (probado con Vitacura). Sin elegir: borde terracota, «Elige la sucursal antes de confirmar la factura.» y «Sin elegir» en los datos. Móvil (390 px) sin desplazamiento lateral. **No probado en el navegador:** las vistas de bodeguero con sucursal, sin sucursal y de cajero, porque requieren iniciar sesión con esos roles; sí tienen pruebas automáticas.
## Confirmación transaccional e identidad única (H3.1 T08 y H3.7 T02) — 17-10-2026

- **Rama:** Nelson_Branch2
- **Servidor (sin aplicar):** database/migrations/20261017_ingresar_factura_xml.sql y su .ENSAYO.sql. Agrega a acturas_compra el origen y la identidad (RUT emisor normalizado + tipo + folio) con restricción única; las facturas manuales quedan fuera (NULL). n_ingresar_factura_xml vuelve a leer el XML en el servidor, valida permiso, sucursal, duplicados, totales y cada línea, y en una transacción crea la factura, el respaldo con el XML original y el detalle de compra (el stock lo suma n_aplicar_compra). Costo = monto neto ÷ cantidad a ingresar; el redondeo de precio_unitario (2 decimales) queda en descuento_monto para que el detalle sume exacto.
- **Prueba de los SQL en una base PostgreSQL 18 temporal** (esquema del repositorio + migraciones, borrada al terminar): ensayo T06 4/4, ensayo T07 18/18, ensayo T08 30/30 con el motivo de cada rechazo a la vista; el script de T08 se aplicó dos veces sin error. También se ingresó el XML real de ejemplo (17 líneas): el detalle suma exactamente el neto (.373) y todo se revirtió.
- **Corregido en los ensayos:** pgAdmin solo muestra la última instrucción, así que los resultados ahora salen como avisos; el ensayo de T06 ya no depende de datos existentes.
- **Pantalla:** barra fija «Confirmar ingreso» que dice qué falta; «Confirmando…» y doble clic ignorado; éxito con folio, sucursal y líneas; errores traducidos (ya ingresada, permisos, datos, conexión con «Reintentar»).
- **Pruebas:** 
px ng test --watch=false: 40/40 suites y 515/515 pruebas aprobadas. 
px ng build: aprobado.
- **Revisión visual:** con sesión de administrador, la barra indica las líneas pendientes y se activa al completar. Corregido en móvil: el botón flotante del menú tapaba «Confirmar ingreso». **No se pulsó Confirmar** contra el servidor real (T08 no está aplicado allí).

## Facturas ingresadas con carga en modal y rediseño — 26-10-2026

- **Rama:** Nelson_Branch2
- **Cambios:** «Facturas ingresadas» es la vista principal de Facturas; «Cargar factura» abre la carga en un modal (sin cierre al hacer clic fuera ni mientras se confirma). Cada factura pasa a una tarjeta compacta: proveedor, folio, RUT y emisión; sucursal, quién y cuándo, y líneas al stock; total a la derecha. Neto, IVA y archivo quedan en «Ver detalle». El modal es angosto sin factura y ancho con la tabla de líneas; su encabezado queda fijo al desplazarse (en el celular, solo el título). La razón social del proveedor ocupa hasta dos líneas.
- **Pruebas:** `npx ng test --watch=false`: 50/50 suites y 690/690 pruebas aprobadas.
- **Build:** `npx ng build`: aprobado.
- **Revisión visual:** navegador integrado con sesión de administrador a 1180, 768 y 375 px: lista, detalle abierto, modal vacío y modal con una factura ficticia de 4 líneas (folio 99999901, cargada en el navegador). **No se confirmó** ningún ingreso.

## Archivo XML con varias facturas — 01-11-2026

- **Rama:** Nelson_Branch2
- **Cambios:** un XML con varios documentos (envío del SII) ya no se rechaza. El modal lista sus facturas (proveedor, folio, RUT, emisión y total) y se ingresan de a una con el flujo de siempre. Al terminar, «Ingresar la siguiente del archivo (N)» vuelve a la lista con las ya ingresadas marcadas; «Facturas del archivo» vuelve sin ingresar. Un documento que no se puede leer aparece en la lista con su motivo.
- **Servidor:** sin cambios. Se envía cada factura como un archivo propio (su `<DTE>` con la firma, en UTF-8, nombre `<archivo>-folio-<folio>.xml`), así que `fn_ingresar_factura_xml` sigue recibiendo un documento por archivo. En una base PostgreSQL 18 temporal se comprobó que acepta `encoding="UTF-8"` y conserva la ñ.
- **Pruebas:** `npx ng test --watch=false`: 56/56 suites y 808/808 pruebas aprobadas (5 nuevas: 3 del lector y 2 del modal).
- **Build:** `npx ng build`: aprobado.
- **Revisión visual:** no realizada.

## Equivalencia leída de la descripción y sugerencia por capacidad — 01-11-2026

- **Rama:** Nelson_Branch2
- **Equivalencia:** si la descripción de un producto termina en «X 6», «PACK 24» o trae «6 x 500ml», «Cada presentación trae» se rellena con ese número (4 cajas × 6 = 24 un) y se avisa «Leído de la descripción… Corrígelo si no es así». Se corrige escribiendo otro número (1 = unidades sueltas). No se lee en materias primas (kg, L), porque «X 6» no dice cuánto trae cada presentación. Cantidades de 2 a 99.
- **Sugerencia:** si la descripción y el artículo traen capacidades distintas (1 L frente a 600 ml), no se sugiere ese artículo y la línea queda «Pendiente». «600 cc» y «0,6 L» siguen coincidiendo con «600ml».
- **Pruebas:** `npx ng test --watch=false`: 56/56 suites y 815/815 pruebas aprobadas (7 nuevas).
- **Build:** `npx ng build`: aprobado.
- **Revisión visual:** no realizada.

## Rediseño de «Artículo del catálogo» en las líneas — 01-11-2026

- **Rama:** Nelson_Branch2
- **Cambios (solo estilos y una clase):** la columna pasa de 300 a 340 px. Con un artículo elegido, el campo se ve como selección (fondo verde suave y nombre en negrita) y no como un buscador. «Cada presentación trae» queda en un recuadro tenue, con el campo de hasta 168 px en vez de ocupar todo el ancho, y «Se sumarán 24 un (4 × 6)» sale como una franja verde de resultado.
- **Pruebas:** `npx ng test --watch=false --include src/app/features/facturas`: 7/7 suites y 171/171 pruebas aprobadas.
- **Build:** `npx ng build`: aprobado.
- **Revisión visual:** no realizada (el navegador integrado pide iniciar sesión). Falta revisar a 1440, 1280, 1100, 768 y 390 px.

## Facturas ingresadas en tabla y equivalencia en columna propia — 01-11-2026

- **Rama:** Nelson_Branch2
- **Lista:** las facturas ingresadas pasan de tarjetas separadas a una tabla en un solo panel: proveedor (con RUT), folio, emisión, sucursal, ingreso (fecha y usuario), líneas, total y acciones con íconos (descargar XML y ver detalle). El detalle se despliega bajo su fila. Bajo 900 px cada fila pasa a ser una tarjeta dentro del mismo panel.
- **Carga:** «Cada presentación trae» sale de la celda del artículo y pasa a su propia columna, así la fila no se alarga hacia abajo. Los avisos se acortan («Sugerido por la descripción», «Leído de la descripción»; el detalle queda en el `title`). La lista de artículos flota sobre las filas siguientes en vez de empujarlas.
- **Pruebas:** `npx ng test --watch=false`: 56/56 suites y 815/815 pruebas aprobadas.
- **Build:** `npx ng build`: aprobado.
- **Revisión visual:** no realizada (el navegador integrado pide iniciar sesión).

## Sucursal reconocida por la dirección de la factura — 01-11-2026

- **Rama:** Nelson_Branch2
- **Lector:** lee las direcciones del emisor (`DirOrigen`), del receptor (`DirRecep`) y de despacho (`Transporte/DirDest`), cada una con su comuna.
- **Sucursal:** al abrir una factura, el administrador la ve con la sucursal elegida según la dirección de despacho y, si ninguna coincide, la de facturación, comparadas con `sucursales.direccion` (models/sucursal-por-direccion.ts). Coinciden si comparten número y una palabra de la calle; se toleran «Av.», tildes y letras perdidas por el proveedor («ESPA  A»). Si coinciden varias, no elige. Bajo el selector se explica por qué se eligió, a cuál corresponde si el usuario cambia, o que ninguna coincide. El bodeguero sigue con su sucursal fija.
- **Servidor (sin aplicar):** database/migrations/20261101_direcciones_factura_xml.sql y su .ENSAYO.sql. Agrega `direccion_emisor`, `direccion_receptor` y `direccion_despacho` a `facturas_xml_pendientes`; un disparador las lee del XML guardado al ingresar (fn_ingresar_factura_xml no cambia) y la migración completa las ya ingresadas.
- **Prueba de los SQL en una base PostgreSQL 18 temporal** (tabla mínima con el XML real de CCU y un disparador de permisos que rechaza los UPDATE, como en pgAdmin; borrada al terminar): ensayo 6/6 antes y después de aplicar; la migración aplicada dos veces sin error; el relleno completó la factura ya ingresada; una fila nueva se completa sola y un XML ilegible queda con direcciones vacías sin impedir el ingreso.
- **Pruebas:** `npx ng test --watch=false`: 57/57 suites y 822/822 pruebas aprobadas.
- **Build:** `npx ng build`: aprobado.
- **Revisión visual:** no realizada. **Pendiente:** ensayo y aplicación del SQL en pgAdmin; revisar que las sucursales tengan su dirección registrada.

## Varias sucursales con la misma dirección — 01-11-2026

- **Rama:** Nelson_Branch2
- **Caso:** «Nury's UPLA Ciencias» y «Nury's UPLA Casa Central» comparten «AVDA, Playa Ancha 850».
- **Cambio:** si la dirección de la factura coincide con varias sucursales, el selector ofrece solo esas, sin preseleccionar ninguna, con el aviso «2 sucursales comparten la dirección de despacho de la factura (…). Elige cuál recibe el stock.» «Ver todas las sucursales» vuelve a mostrar la lista completa por si la dirección de la factura está mal. Con una sola coincidencia se sigue eligiendo sola.
- **Pruebas:** `npx ng test --watch=false`: 57/57 suites y 823/823 pruebas aprobadas.
- **Build:** `npx ng build`: aprobado.
- **Revisión visual:** no realizada.

## Sucursal elegida dentro de cada factura — 01-11-2026

- **Rama:** Nelson_Branch2
- **Cambio:** el selector de sucursal deja de estar sobre la zona de carga y pasa a los datos de la factura abierta (pages/carga-factura/carga-factura.html). Cada factura parte con la sucursal por defecto del usuario (la propia del administrador, o ninguna) y luego se aplica la detección por dirección: en un archivo con varias facturas, una puede ir a una sucursal y otra a otra. El bodeguero sigue con su sucursal fija.
- **Pruebas:** `npx ng test --watch=false`: 57/57 suites y 823/823 pruebas aprobadas. Se ajustaron las que elegían la sucursal antes de cargar el archivo; la de un archivo con varias facturas ahora revisa que la segunda no herede la sucursal de la primera.
- **Build:** `npx ng build`: aprobado.
- **Revisión visual:** no realizada.

## Guía para obtener el XML desde el SII — 01-11-2026

- **Rama:** Nelson_Branch2
- **Cambio:** nueva guía en un modal (components/guia-xml/guia-xml.ts) con 11 pasos numerados: 7 para descargar el XML desde el SII (Servicios online → Factura electrónica → Sistema de facturación gratuito → Ver documentos recibidos → filtrar por fecha → «Archivo Respaldo») y 4 para subirlo a Nury. Incluye un enlace directo a «Ver documentos recibidos» del SII. Se abre con «¿Cómo obtengo el XML?» en «Facturas ingresadas» y con «¿Cómo descargo el XML desde el SII?» en la zona de carga. Cierra con el botón o Escape y devuelve el foco.
- **Imágenes:** public/ayuda/factura-xml/02 a 07 (.webp, desde las capturas del usuario). Sin imagen todavía: paso 1 (inicio de sesión en el SII) y pasos 8 a 11 (pantallas de Nury).
- **Pruebas:** `npx ng test --watch=false`: 58/58 suites y 828/828 pruebas aprobadas.
- **Build:** `npx ng build`: aprobado. Las 6 imágenes responden 200 `image/webp` en el servidor de desarrollo.
- **Revisión visual:** no realizada (el navegador integrado pide iniciar sesión).

## H4.5 Cierre Integral: T07, T10, T11 y Visualización Temprana desde el Minuto 1 (< 28 días) — 05-11-2026

- **Rama:** `Patricio2_branch`
- **Tareas cubiertas:**
  - **H4.5 T07:** Validador en tiempo de ejecución del esquema JSON devuelto por la IA (`validador-prediccion-ia.ts`), caché de predicciones con TTL de 4 horas por sucursal y fecha (`predictive-cache.service.ts`), y servicio integrado de predicción con respaldo determinista local automático (`prediccion-stock.service.ts`).
  - **H4.5 T10:** Verificación exhaustiva de todas las reglas de negocio de H4.5: umbral de 28 días, no consumo de cuota ante historial insuficiente, estimación preliminar desde el minuto 1 (< 28 días), validación del prompt sin tiempos de entrega, conmutación ante fallos de proveedores (`HTTP 429` / offline) y respaldo estadístico local determinista (Nivel 4).
  - **H4.5 T11:** Chatbot Asistente Ejecutivo funcional en el drawer deslizable de `/dashboard` con entrada dual (texto libre + chips rápidos), grounding vivo en tiempo real (ventas, margen limpio, catálogo de productos e insumos activos vs. inactivos, insumos críticos y madurez < 28 días), y guía paso a paso de uso del ERP NuryBase (`asistente-dashboard.service.ts`).
  - **Visualización desde el Minuto 1:** Banner informativo de madurez estadística tanto en `/dashboard` como en `panel-predictivo`, indicando claramente cuántos días de registros se están evaluando y cuántos días faltan para cumplir los 28 días necesarios para sacar conclusiones definitivas, mostrando a la vez en la tabla los datos preliminares de consumo diario, duración y compra sugerida calculados con los días reales de registro.
  - **PostgREST / PostgreSQL:** Incorporación de `StockApiService.listarConsumoDiarioArticulos()` para conectar el frontend con la vista `v_consumo_diario_articulos` de la base de datos de producción.
- **Suites nuevas y ampliadas:**
  - `validador-prediccion-ia.spec.ts` (8 pruebas): validación de sintaxis JSON, obligatoriedad de campos, tipos numéricos positivos, estados válidos, duplicados, longitud de justificación (<= 200) y coherencia de negocio frente a la entrada.
  - `predictive-cache.service.spec.ts` (5 pruebas): almacenamiento con clave compuesta `(sucursal|fecha|articulos)`, lectura antes del TTL, expiración automática con reloj virtual (`IA_RELOJ`), invalidación selectiva por sucursal e inmutabilidad por copia profunda.
  - `prediccion-stock.service.spec.ts` (7 pruebas): mapeo de `v_consumo_diario_articulos` calculando `consumoDiarioEfectivo` sobre días reales, resolución local en 0 ms para artículos con `< 28` días (ahorro de cuota), cache hit sin llamadas de red, llamada a IA con guardado en caché, conmutación a respaldo local determinista ante JSON corrupto y ante `SinProveedoresIAError` (429/offline).
  - `asistente-dashboard.service.spec.ts` (5 pruebas): inyección de grounding vivo en el prompt del sistema (ventas, margen, productos inactivos, madurez < 28 días) y motor local de contingencia que responde preguntas sobre catálogo inactivo, compras urgentes, facturas XML DTE 33 y horarios punta.
  - `prediccion.model.spec.ts` pasa de 7 a 11 pruebas: cálculo de días faltantes para el umbral de 28 días, consumo diario adaptado a días reales, estimación preliminar desde el minuto 1 y evaluación de madurez estadística global.
  - `panel-predictivo.spec.ts` pasa de 5 a 6 pruebas: renderizado del banner de madurez temprana y visualización de días faltantes y notas preliminares en la tabla.
  - `dashboard.spec.ts` pasa de 3 a 5 pruebas: renderizado del banner de madurez temprana en la cabecera y envío interactivo de preguntas libres desde el drawer recibiendo respuesta contextual.
  - `stock-api.service.spec.ts` pasa de 12 a 13 pruebas: consulta a `v_consumo_diario_articulos` con y sin filtro de sucursal.
- **Resultados de verificación:**
  - **Pruebas unitarias:** `npm test -- --watch=false` → **69 suites aprobadas (69/69), 938 pruebas aprobadas (938/938), 0 fallos, 0 omitidas (100% PASS)**.
  - **Compilación de producción:** `npm run build` → **0 errores y 0 advertencias**, respetando los presupuestos de tamaño de Angular.

