# Revisión de aceptación: H5.2 Creación y programación de promociones

Fecha: 5 de noviembre de 2026. Rama: `Maher2_Branch` (commit `266c962` + T09).

Tarea de prueba: H5.2 T09 (permisos del cajero, vigencia automática, inventario de promociones
combinadas y reportes con descuento).

## Resultado

- **Pantalla (Angular):** todos los casos cubiertos y ejecutados: 979/979 pruebas OK, build sin
  errores ni advertencias.
- **Base de datos:** las 6 pruebas SQL de H5.2 están escritas y cubren los cuatro criterios,
  pero **todavía no se ejecutaron**: las migraciones de H5.2 no están aplicadas en ninguna base
  (revisado el 05-11-2026 en `nury`: la tabla `promociones` sigue con el modelo anterior). Se
  ejecutan en una copia de la base siguiendo «Ejecución en la base» y se anota el resultado en
  la columna correspondiente.

| Criterio de aceptación | Pantalla | Base de datos |
| --- | --- | --- |
| Cajero aplica una promoción vigente, pero no la crea ni cambia su descuento o vigencia | Cumple | Pendiente de ejecutar |
| Una promoción programada empieza y termina sola dentro de su ventana | Cumple | Pendiente de ejecutar |
| Sándwich + café descuenta los ingredientes de ambas recetas y la anulación los repone | No aplica (lo hace la base) | Pendiente de ejecutar |
| Los reportes muestran lo vendido con descuento y el margen sacrificado, por producto y por período | Cumple | Pendiente de ejecutar |

### 1. Permisos del cajero

| Caso | Evidencia | Resultado |
| --- | --- | --- |
| El cajero no entra a la pantalla de promociones | `auth.guard.spec.ts`: «enforces cajero access to /gestion-negocio/promociones» (bloqueado); también bodeguero; el admin entra. | Cumple |
| El cajero ve en el POS las promociones vigentes de su sucursal | `pos-layout.component.spec.ts`: «shows the promotions of the branch with their products and discount». `pos.service.spec.ts`: «loads the promotions that apply now in the branch». | Cumple |
| El cajero aplica una promoción | `pos-layout.component.spec.ts`: «applies a promotion to the order with its discount, without an editable price». `pos.service.spec.ts`: «adds the promotion products together with their discount», «applies the promotion again or removes it as a whole». | Cumple |
| El cajero no puede cambiar el descuento en el POS | `pos-layout.component.spec.ts`: no hay campos de precio ni de descuento en la comanda. | Cumple |
| El POS no puede forzar un descuento (el precio lo calcula la base) | `pos.service.spec.ts`: «sends each promotion line with its promotion…». Base: `promociones_venta.sql` caso 1 (precio enviado $1, guardado el de la promoción). | Pantalla: Cumple. Base: pendiente |
| En la base el cajero no crea, no cambia descuento ni vigencia, ni borra | `database/tests/promociones_permisos.sql` caso 3. | Pendiente |
| En la base el cajero solo lee las vigentes de su sucursal (o de todas), no las de otra sucursal | `promociones_permisos.sql` casos 1, 2 y 4 (RLS). | Pendiente |
| El administrador ve y modifica todas; el bodeguero no accede | `promociones_permisos.sql` casos 5 y 6; `promociones.sql` caso 9. | Pendiente |

### 2. Vigencia automática

| Caso | Evidencia | Resultado |
| --- | --- | --- |
| Viernes 23:59 no aplica; sábado 00:00 empieza; domingo 23:58 sigue; domingo 23:59 termina | `database/tests/promociones_vigentes.sql` casos 1 a 4. | Pendiente |
| No se corre con la sesión en UTC ni en horario de invierno | `promociones_vigentes.sql` casos 0, 5 y 6. | Pendiente |
| La hora la decide el servidor, no el reloj del POS | `promociones_vigentes.sql` caso 8. `promociones-api.service.spec.ts`: «asks the server which promotions apply now…» (no envía la hora). | Pantalla: Cumple. Base: pendiente |
| El POS actualiza la lista solo, cada minuto | `pos-layout.component.spec.ts`: «checks the current promotions every minute, without reloading». | Cumple |
| Si una promoción aplicada termina antes de cobrar, se avisa y no se cobra | `pos-layout.component.spec.ts`: «warns and blocks charging…». Base: `promociones_venta.sql` caso 6 (rechaza una no vigente). | Pantalla: Cumple. Base: pendiente |
| La pantalla de administración programa en hora de Chile, sea cual sea la zona del equipo | `promocion.spec.ts` (gestión de negocio): conversión de hora de Chile en verano, invierno y días de cambio de hora; ejecutado también con el equipo en UTC, Tokio y Santiago. | Cumple |
| Estado de cada promoción (programada, vigente, terminada, desactivada) | `promocion.spec.ts`; `promociones.spec.ts`: «lists each promotion with its state…». | Cumple |

### 3. Inventario de promociones combinadas

| Caso | Evidencia | Resultado |
| --- | --- | --- |
| Sándwich + café con leche descuenta pan, queso, café y leche | `database/tests/promociones_inventario.sql` caso 1. | Pendiente |
| La promoción no es un producto (sin stock ni movimientos propios) | `promociones_inventario.sql` casos 2 y 3. | Pendiente |
| Promoción ×2, el mismo producto suelto y un producto sin receta | `promociones_inventario.sql` caso 4; `promociones_venta.sql` casos 2 y 3. | Pendiente |
| Anular la venta con promoción repone el stock | `promociones_inventario.sql` casos 5 a 7 (también la venta mixta y el cuadre del kardex). | Pendiente |
| Combos incompletos o desparejos se rechazan | `promociones_venta.sql` caso 6. | Pendiente |

### 4. Reportes con descuento

| Caso | Evidencia | Resultado |
| --- | --- | --- |
| Cada venta guarda promoción, precio original, descuento, precio final, costo y margen sacrificado | `database/tests/promociones_margen.sql` casos 1 a 8. | Pendiente |
| Por período: vendido con descuento y margen sacrificado, día a día | `database/tests/reporte_promociones.sql` casos 1 a 3. Pantalla: `reporte-promociones.spec.ts` «splits the results by day, week or month». | Pantalla: Cumple. Base: pendiente |
| Por producto: vendido con descuento, margen sacrificado y margen ganado | `reporte_promociones.sql` casos 4 y 5. Pantalla: «lists products sold with promotion, or every product on demand». | Pantalla: Cumple. Base: pendiente |
| Mismos filtros que el dashboard y solo para el administrador | `reportes.spec.ts`: «opens the Promociones tab with the same branches and period». `reporte_promociones.sql` casos 6 y 7. | Pantalla: Cumple. Base: pendiente |

## Evidencia automatizada

**Pantalla (Vitest), ejecutada el 05-11-2026:** `ng test --watch=false` → 78 archivos, 979/979
pruebas OK, 0 fallos. `ng build` sin errores ni advertencias. Node 24.21, Angular 22.1.

| Archivo | Pruebas |
| --- | ---: |
| `src/app/core/api/promociones-api.service.spec.ts` | 2 |
| `src/app/features/gestion-negocio/models/promocion.spec.ts` | 9 |
| `src/app/features/gestion-negocio/pages/promociones/promociones.spec.ts` | 9 |
| `src/app/core/guards/auth.guard.spec.ts` (3 de promociones) | 25 |
| `src/app/features/pos/models/promocion-pos.spec.ts` | 6 |
| `src/app/features/pos/services/pos.service.spec.ts` (7 de promociones) | 41 |
| `src/app/features/pos/pages/pos-layout/pos-layout.component.spec.ts` (4 de promociones) | 26 |
| `src/app/core/api/reportes-api.service.spec.ts` (2 de promociones) | 6 |
| `src/app/features/reportes/models/reporte-promociones.model.spec.ts` | 6 |
| `src/app/features/reportes/components/reporte-promociones/reporte-promociones.spec.ts` | 7 |
| `src/app/features/reportes/pages/reportes/reportes.spec.ts` (1 de promociones) | 10 |

**Base de datos (scripts que se deshacen solos: terminan con un error a propósito):**

| Archivo | Casos | Mensaje esperado | Resultado obtenido |
| --- | ---: | --- | --- |
| `database/tests/promociones.sql` | 9 | TODAS LAS PRUEBAS PASARON (9 de 9) | Pendiente |
| `database/tests/promociones_permisos.sql` | 6 | TODAS LAS PRUEBAS PASARON (6 de 6) | Pendiente |
| `database/tests/promociones_vigentes.sql` | 9 | TODAS LAS PRUEBAS PASARON (9 de 9) | Pendiente |
| `database/tests/promociones_venta.sql` | 9 | TODAS LAS PRUEBAS PASARON (9 de 9) | Pendiente |
| `database/tests/promociones_inventario.sql` | 7 | TODAS LAS PRUEBAS PASARON (7 de 7) | Pendiente |
| `database/tests/promociones_margen.sql` | 8 | TODAS LAS PRUEBAS PASARON (8 de 8) | Pendiente |
| `database/tests/reporte_promociones.sql` | 7 | TODAS LAS PRUEBAS PASARON (7 de 7) | Pendiente |
| `database/tests/guardar_promocion.sql` | 7 | TODAS LAS PRUEBAS PASARON (7 de 7) | Pendiente |
| `database/tests/promociones_sucursales.sql` | 6 | TODAS LAS PRUEBAS PASARON (6 de 6) | Pendiente |
| Regresión: `venta_empleado.sql`, `venta_idempotente.sql`, `detalle_venta_una_vez.sql`, `reponer_stock_anulacion.sql`, `almuerzo_fuera_de_ventas.sql` | — | Sus mensajes de éxito, sin «FALLO» | Pendiente |

## Ejecución en la base

En una **copia** de la base (Backup de `nury` → restaurar en `nury_pruebas`), con un usuario
dueño de las tablas o superusuario:

1. Aplicar las migraciones en este orden: `20261105_promociones.sql`,
   `20261105_promociones_permisos.sql`, `20261105_promociones_vigentes.sql`,
   `20261105_promociones_venta.sql`, `20261105_promociones_margen.sql`,
   `20261105_reporte_promociones.sql`, `20261105_guardar_promocion.sql`,
   `20261108_promociones_sucursales.sql`.
2. Correr cada prueba de la tabla anterior. pgAdmin muestra el mensaje final en rojo como
   «ERROR»: si dice «TODAS LAS PRUEBAS PASARON», está bien.
3. Anotar el resultado en la columna «Resultado obtenido» y, si algo falla, el mensaje «FALLO»
   completo.

## Recorrido manual para revisión del equipo

1. **Admin, Gestión de negocio → Promociones:** ver el listado con estado, vigencia y
   sucursales; abrir «Crear promoción» y comprobar los errores por campo (término antes del
   inicio, porcentaje sobre 100, sin productos, ninguna sucursal marcada); guardar una
   promoción para «Todas las sucursales» y otra para dos sucursales marcadas en la lista,
   editarla y desactivarla, y ver que el listado cambia de estado.
2. **Cajero:** el menú no muestra Administración y `/gestion-negocio/promociones` lo saca.
3. **Cajero, POS:** con una promoción vigente en su sucursal, aparece en «Promociones vigentes»;
   «Aplicar» agrega sus productos con el descuento; el resumen y el ticket muestran
   «Descuento promociones»; no hay dónde editar el precio. En otra sucursal no marcada, la
   promoción no aparece.
   - Al buscar un producto en promoción, su tarjeta muestra «Promo», el nombre de la
     promoción, lo que se agrega junto («+ 1 × Café») y el descuento; tocarla agrega todos
     los productos del combo a la comanda de una vez.
   - El filtro «En promoción» (al final de las categorías) deja solo esos productos y se
     combina con la búsqueda y la categoría.
4. **Inventario:** después de vender la promoción, el kardex del pan, queso, café y leche
   muestra la salida; anular la venta la repone.
5. **Admin, Reportes → Promociones:** aparecen lo vendido con descuento y el margen sacrificado,
   por período (día, semana, mes) y por producto.

## Observaciones abiertas

1. ~~Guardar y desactivar desde la pantalla no escribía en la base~~ (la T02 fue la maqueta).
   Resuelto: `fn_guardar_promocion` (20261105_guardar_promocion.sql) crea o edita la
   promoción con sus productos en una sola transacción y la pantalla desactiva con PATCH
   `activa = false`. Prueba: `database/tests/guardar_promocion.sql` (7 casos).
2. Las líneas **sin** promoción siguen aceptando el precio que envía el POS (comportamiento
   anterior a H5.2, del que depende `venta_empleado.sql`). Por la API se podría bajar el precio
   de un producto suelto.
3. Rendimiento por producto (H4.4) no existe como historia aparte: la pestaña «Productos» de
   Reportes ya se llama así. `fn_reporte_promociones_producto` queda lista para sumarle las
   columnas de promoción; coordinar con Sebastián.
4. En una venta recuperada del turno (recarga del POS), la línea con promoción muestra
   «Promoción» sin el nombre; el descuento sí queda bien.
